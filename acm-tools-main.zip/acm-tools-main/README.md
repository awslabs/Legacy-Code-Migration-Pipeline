# SMF Migration Toolkit

A comprehensive Python toolkit for IBM z/OS modernization and migration projects. The toolkit provides specialized tools for SMF analysis, legacy code analysis, and migration planning with a clean, extensible architecture.

## Table of Contents

- [Overview](#overview)
- [Tools Architecture](#tools-architecture)
- [Quick Start](#quick-start)
- [Tool Details](#tool-details)
  - [1. SMF Analyzer](#1-smf-analyzer)
  - [2. Legacy Analyzer](#2-legacy-analyzer)
  - [3. SMF Dashboard](#3-smf-dashboard)
  - [4. ATX Dependency Transformer](#4-atx-dependency-transformer)
  - [5. SMF Test Data Generator](#5-smf-test-data-generator)
  - [6. Migration Planner](#6-migration-planner)
- [Shared Infrastructure](#shared-infrastructure)
- [Data Flow](#data-flow)
- [Installation](#installation)
- [Integration](#integration)
- [Examples](#examples)
- [Automation Scripts](#automation-scripts)
- [Architecture](#architecture)
- [Extending the Toolkit](#extending-the-toolkit)
- [Documentation](#documentation)
- [Testing](#testing)
- [Contributing](#contributing)
- [References](#references)
- [Support](#support)

## Overview

The SMF Migration Toolkit is a comprehensive suite of specialized tools designed for mainframe modernization and migration projects. Built as a tools-based monorepo, it provides clear separation between different aspects of migration analysis while maintaining shared infrastructure for common functionality.

## Tools Architecture

The toolkit is organized into three main tools under the `tools/` directory:

```
smf-migration-toolkit/
├── tools/                          # Individual migration tools
│   ├── smf-analyzer/               # SMF data analysis tool
│   ├── legacy-analyzer/            # Legacy code analysis tool
│   ├── smf-dashboard/              # Web-based analysis interface
│   ├── atx/                        # ATX transformation tools
│   │   └── dependency_transformer/ # ATX to legacy_analyzer transformer
│   ├── smf-test-data-generator/    # Test data generation
│   └── migration-planner/          # Migration planning tool (future)
├── shared/                         # Shared infrastructure
│   ├── database/                   # Common database components
│   ├── utils/                      # Common utilities
│   └── config/                     # Shared configuration
├── config/                         # Top-level configuration
├── docs/                           # Documentation
└── examples/                       # Usage examples
```

### Tool Overview

- **SMF Analyzer**: Parse, load, and analyze IBM z/OS SMF records with support for multiple record types and cross-type analysis
- **Legacy Analyzer**: Comprehensive static code analysis for COBOL, JCL, PL/I, and other mainframe languages with dependency mapping and complexity assessment
- **SMF Dashboard**: Web-based interface for interactive SMF analysis with real-time querying and visualization
- **ATX Dependency Transformer**: Transform ATX tool outputs to legacy_analyzer format for migration planning
- **SMF Test Data Generator**: Generate realistic SMF test data for development and testing
- **Migration Planner**: Future tool for AI-assisted migration planning, rules extraction, and code generation (placeholder)

This project provides an integrated suite of tools for complete SMF data processing and legacy code analysis, enabling mainframe modernization and migration projects through automated analysis and AI-powered insights.

### 🚀 Quick Start: Complete CICS Application Analysis

**Want to analyze a CICS application in 5-15 minutes?**

```bash
# One command to analyze everything (CICS metadata, code, complexity)
./complete_analysis.sh ./your-app-directory ./results

# Or use the example scripts
python examples/analyze_with_cics_metadata.py \
  --source-dir ./your-app \
  --database ./results/analysis.db
```

**What you get:**
- ✅ All CICS transactions identified (ONLINE entry points)
- ✅ All JCL procedures identified (BATCH entry points)
- ✅ Complete code analysis (COBOL, JCL, Assembler)
- ✅ Complexity metrics for all programs
- ✅ Interactive HTML reports
- ✅ Service grouping recommendations
- ✅ API endpoint suggestions
- ✅ Migration roadmap with effort estimates

**See:** [Complete Analysis Guide](docs/COMPLETE_ANALYSIS_GUIDE.md) for step-by-step instructions.

### The Complete SMF Analysis Pipeline

The toolkit combines five specialized components that work together to transform raw mainframe performance data into actionable intelligence:

1. **smf_doc_parser** - Extract and organize SMF documentation from IBM sources
2. **smf_record_parser** - Parse binary SMF files into structured JSON (CLI + Python API)
   - **Enhanced format detection** - Automatically handles standard and non-standard SMF formats
   - See [File Format Detection Guide](smf_record_parser/docs/FILE_FORMAT_DETECTION.md)
3. **smf_loader** - Load parsed data into databases (SQLite, PostgreSQL, etc.)
4. **smf_queries** - Analyze data with pre-built queries and custom SQL (includes artifact lifecycle analysis queries)
5. **smf_inventory** - Load mainframe inventory data and extract source code dependencies for analysis

### Business Value & Use Cases

**For Modernization Projects:**
- **Workload Analysis**: Identify CPU-intensive applications, peak usage patterns, and resource bottlenecks
- **Migration Planning**: Quantify application dependencies, transaction volumes, and performance baselines
- **Cost Optimization**: Calculate MIPS/MSU consumption per application to estimate cloud migration costs
- **Risk Assessment**: Analyze job failure rates, error patterns, and system stability metrics
- **Artifact Cleanup**: Identify unreferenced JCL, programs, datasets, and copybooks for archival or removal
- **Dependency Analysis**: Map relationships between programs, copybooks, and datasets through static code analysis

**For AI-Powered Analysis:**
The toolkit's functions and methods can be integrated into AI agents to provide intelligent answers to complex questions:
- "Which applications consume the most CPU during business hours?"
- "What are the I/O patterns for our critical batch jobs?"
- "How has transaction response time changed over the past quarter?"
- "Which programs should we prioritize for modernization based on resource usage?"

AI agents can call the query engine programmatically, interpret results, and provide natural language explanations—making mainframe data accessible to non-technical stakeholders in modernization and migration projects.

### How the Tools Work Together

```
Performance Analysis Pipeline:
1. smf_doc_parser → Extracts IBM documentation for reference
2. smf_record_parser → Converts binary SMF files to structured JSON
3. smf_loader → Loads JSON into queryable databases
4. smf_queries → Analyzes SMF data and generates insights

Artifact Lifecycle Analysis Pipeline:
1. smf_inventory → Loads inventory data and extracts source code dependencies
2. smf_loader → Loads inventory/dependency data into database (with SMF data)
3. smf_queries → Compares inventory vs SMF usage to find unreferenced/missing artifacts
```

This pipeline transforms opaque binary mainframe data into structured, queryable information that can be analyzed by humans or AI agents, enabling data-driven decisions in modernization initiatives.

## Quick Start

### Complete Analysis Pipeline (Recommended)

Use the integrated pipeline script for end-to-end SMF analysis:

```bash
# Run complete analysis pipeline (parse + load + query + report)
python examples/smf_analysis_pipeline.py

# Use specific SMF file
python examples/smf_analysis_pipeline.py --input examples/data/jse/SMF.JUL18.rdw

# Use different output directory
python examples/smf_analysis_pipeline.py --output ./my_results

# Get help
python examples/smf_analysis_pipeline.py --help
```

**What it does:**
1. **Parse**: Automatically detects SMF file format and extracts all records
2. **Load**: Creates unified database with all record types for cross-analysis
3. **Query**: Runs 36+ pre-built queries across all SMF types and generates reports
4. **Report**: Creates comprehensive analysis summary with results in multiple formats

**Results include:**
- Parsed JSON files (by type and combined)
- SQLite database with all data
- Query results in JSON, CSV, and Markdown formats
- Comprehensive analysis summary report
- Performance metrics and statistics

### Option 1: Unified Database (Manual Steps)

Load all SMF record types into a single database for cross-type analysis:

```bash
# Step 1: Parse SMF file
python3 -m smf_record_parser parse examples/data/jse/SMF.APR4.TRS.DECOMPRESS --split both --output results

# Step 2: Create unified database with all types
python3 -m smf_loader load --unified --db smf_analytics.db --file results/SMF.APR4.TRS_ALL.json --create-schema

# Step 3: Run cross-type queries
python3 -m smf_queries run --db smf_analytics.db --query workload_distribution
python3 -m smf_queries run --db smf_analytics.db --query batch_cics_correlation --params date=2024-01-15
```

**Benefits:** Cross-record analysis, time correlation, complete performance picture  
**See:** [Unified Database Implementation](#unified-database-option-1) section below

### Option 2: Single-Type Database (Traditional)

```bash
# Step 1: Parse SMF file (creates JSON files + report)
python3 -m smf_record_parser parse examples/SMF30_1.Dat --split type --output results

# Step 2: Load Type 30 records into database
python3 -m smf_loader load --type 30 --db smf_data.db --file results/SMF30_1_030.json --create-schema

# Step 3: Query and analyze
python3 -m smf_queries list --db smf_data.db
python3 -m smf_queries run --db smf_data.db --query top_cpu_consumers
python3 -m smf_queries run --db smf_data.db --query cpu_statistics --format json > results.json
```

### Python API Usage

```python
# 1. Parse SMF file with multi-record support
from smf_record_parser import SMFFileParser

parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC")

# Parse all records from file
for record in parser.parse_file("examples/SMF30_1.Dat"):
    print(f"Type {record.record_type}: {record.system_id}")
    # Process record...

# 2. Load into database
from smf_loader import SMFLoader
from smf_loader.databases import SQLiteAdapter
from smf_loader.schemas import SMF30Schema

loader = SMFLoader(
    database=SQLiteAdapter('smf_data.db'),
    schema=SMF30Schema()
)
loader.create_schema()
loader.load_json_file('results/SMF30_1_030.json')
loader.close()

# 3. Query and analyze
from smf_queries import QueryEngine
from smf_queries.smf30_queries import SMF30_QUERIES

database = SQLiteAdapter('smf_data.db')
database.connect()

engine = QueryEngine(database)
engine.register_queries(SMF30_QUERIES)

result = engine.execute('top_cpu_consumers', limit=10)
print(result.to_json())

database.close()
```

## Project Structure

```
smf-migration-toolkit/
├── tools/                          # Individual migration tools
│   ├── smf-analyzer/               # SMF analysis tool
│   │   ├── smf_doc_parser/         # Documentation extraction
│   │   ├── smf_record_parser/      # Binary SMF file parser
│   │   ├── smf_loader/             # Database loading engine
│   │   ├── smf_queries/            # Query engine and pre-built queries
│   │   ├── __init__.py             # Tool API exports
│   │   ├── api.py                  # High-level SMF analyzer API
│   │   ├── requirements.txt        # SMF-specific dependencies
│   │   └── README.md               # SMF analyzer documentation
│   │
│   ├── legacy-analyzer/            # Legacy code analysis tool
│   │   ├── analysis/               # Flow and complexity analysis
│   │   ├── parsers/                # Multi-language parsers (COBOL, JCL, PL/I, etc.)
│   │   ├── inventory/              # Inventory management
│   │   ├── migration/              # Migration package planning
│   │   ├── models/                 # Data models
│   │   ├── utils/                  # Analysis utilities
│   │   ├── visualization/          # Flow visualization
│   │   ├── reports/                # Report generation
│   │   ├── metadata/               # Metadata management
│   │   ├── api.py                  # High-level legacy analyzer API
│   │   ├── requirements.txt        # Legacy analyzer dependencies
│   │   └── README.md               # Legacy analyzer documentation
│   │
│   └── migration-planner/          # Migration planning tool (future)
│       ├── __init__.py             # Placeholder API
│       ├── requirements.txt        # Placeholder requirements
│       └── README.md               # Placeholder documentation
│
├── shared/                         # Shared infrastructure
│   ├── database/                   # Common database components
│   │   ├── schemas/                # Database schemas
│   │   ├── adapters/               # Database adapters
│   │   └── __init__.py
│   ├── utils/                      # Common utilities
│   │   ├── file_utils.py           # File operations
│   │   ├── validation.py           # Validation functions
│   │   └── __init__.py
│   ├── config/                     # Shared configuration
│   │   ├── base_config.py          # Configuration management
│   │   └── __init__.py
│   └── __init__.py
│
├── config/                         # Top-level configuration files
│   ├── config.yaml                 # Main configuration
│   ├── inventory.yaml              # Inventory settings
│   ├── queries.yaml                # Query configurations
│   └── legacy_analyzer.yaml        # Legacy analyzer settings
│
├── docs/                           # User documentation
│   ├── tools/                      # Tool-specific documentation
│   │   ├── smf-analyzer/           # SMF analyzer docs
│   │   ├── legacy-analyzer/        # Legacy analyzer docs
│   │   └── migration-planner/      # Migration planner docs
│   ├── GETTING_STARTED.md          # Quick start guide
│   ├── INSTALLATION.md             # Installation instructions
│   ├── ARCHITECTURE.md             # Architecture overview
│   └── API_REFERENCE.md            # API documentation
│
├── examples/                       # Usage examples
│   ├── data/                       # Test data files
│   ├── smf_analysis_pipeline.py    # Complete SMF analysis
│   ├── legacy_analysis_example.py  # Legacy code analysis
│   └── complete_migration_workflow.py  # End-to-end workflow
│
├── tests/                          # Test suite
│   ├── unit/                       # Unit tests
│   │   ├── test_smf_analyzer/      # SMF analyzer tests
│   │   ├── test_legacy_analyzer/   # Legacy analyzer tests
│   │   └── test_shared/            # Shared infrastructure tests
│   ├── integration/                # Integration tests
│   └── property/                   # Property-based tests
│
├── smf_docs/                       # Parsed SMF documentation (output)
├── results/                        # Analysis results (output)
├── setup.py                        # Package configuration
├── requirements.txt                # Top-level requirements
├── requirements-dev.txt            # Development requirements
├── requirements-minimal.txt        # Minimal requirements
└── README.md                       # This file
```

## Tool Details

### 1. SMF Analyzer

The SMF Analyzer tool provides comprehensive analysis of IBM z/OS System Management Facilities (SMF) records. It includes four integrated components for parsing, loading, querying, and documenting SMF data.

#### Components

- **smf_record_parser**: Parse binary SMF files into structured JSON
- **smf_loader**: Load parsed data into databases with flexible schemas
- **smf_queries**: Analyze data with pre-built queries and custom SQL
- **smf_doc_parser**: Extract and organize SMF documentation from IBM sources

#### SMF Record Parser

Parse binary SMF files (with multiple record types) into structured JSON format.

**Features:**
- **Multi-record file support**: Parse files containing mixed record types (Type 2, 3, 30)
- **Automatic format detection**: Detects and handles VB, VBS, and standard SMF formats
- **Command-line interface**: Easy-to-use CLI with flexible output options
- **Multiple output modes**: Combined JSON, split by type, or both
- **Automatic reporting**: Generates detailed markdown reports
- **Version-aware parsing**: Supports z/OS V3R2
- **Encoding support**: EBCDIC and UTF-8
- **Type-safe data models**: Structured Python objects

**Command Line:**
```bash
# Parse and split by record type
python3 -m smf_record_parser parse examples/SMF30_1.Dat --split type --output results

# Creates:
#   results/SMF30_1_002.json (Type 2 - Dump Header)
#   results/SMF30_1_003.json (Type 3 - Dump Trailer)
#   results/SMF30_1_030.json (Type 30 - Job/Step Accounting)
#   results/SMF30_1_REPORT.md (Detailed parsing report)
```

**Python API:**
```python
from smf_record_parser import SMFFileParser

# Parse file with multiple record types
parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC")
for record in parser.parse_file("dump.dat"):
    print(f"Type {record.record_type}: {record.system_id}")
```

**File Format Detection:**

The parser automatically detects and handles different SMF file formats:

- **Standard Format**: 2-byte or 4-byte RDW (Record Descriptor Word)
- **VB Format**: Variable Blocked with 4-byte BDW (Block Descriptor Word) + RDW
- **VBS Format**: Variable Blocked Spanned for large records

```python
from smf_record_parser import SMFFileParser, SMFFileFormat

# Auto-detect format (default)
parser = SMFFileParser(encoding='EBCDIC')
for record in parser.parse_file('smf_data.txt'):
    print(f"Type {record.record_type}")

# Explicitly specify format if auto-detection fails
parser = SMFFileParser(
    encoding='EBCDIC',
    file_format=SMFFileFormat.VB  # or VBS, RDW4, SIMPLE
)
```

**Why Format Detection Matters:**

SMF files from different sources may use different formats. Incorrect format handling causes:
- Wrong record type identification (reading from wrong offsets)
- Corrupted field data
- Low data quality across all record types

The parser's auto-detection examines file structure and validates against known patterns to select the correct format automatically.

**See:** [File Format Detection Guide](smf_record_parser/docs/FILE_FORMAT_DETECTION.md) for detailed information on format detection, troubleshooting, and manual override options.

**Supported Record Types:**
- **Type 2**: Dump Header (with signature support) - Parsed and reported, not loaded to DB
- **Type 3**: Dump Trailer - Parsed and reported, not loaded to DB
- **Type 30**: Job/Step Accounting - Full support (parse, load, query)
- **Type 100**: DB2 Statistics - Full support with auto version detection (V10)
- **Type 101**: DB2 Accounting - Full support with auto version detection (V11, V12)
- **Type 102**: DB2 Performance - Full support with auto version detection (V11, V12, V13)
- **Type 110**: CICS Transaction Server - Full support (parse, load, query)

**Note**: Type 2 and Type 3 are structural markers containing only timestamps and system IDs. They are parsed and documented in reports but not loaded into the database, keeping the focus on data-bearing record types.

**Documentation:** 
- [CLI Documentation](smf_record_parser/CLI_README.md) - Command-line usage
- [Implementation Details](SMF_TYPE_2_IMPLEMENTATION.md) - Type 2 parser
- [Implementation Details](SMF_TYPE_3_IMPLEMENTATION.md) - Type 3 parser

#### SMF Loader

Load parsed JSON records into databases with a flexible, extensible architecture.

**Features:**
- Multiple database support (SQLite, PostgreSQL planned)
- Multiple record types (SMF 30, 100, 101, 102, 110)
- **Unified database option** - Load all record types into single database for cross-type analysis
- **DB2 version-specific schemas** - Dedicated schemas for DB2 statistics, accounting, and performance
- Strategy + Abstract Factory patterns
- Easy to extend

**Single-Type Usage:**
```python
from smf_loader import SMFLoader
from smf_loader.databases import SQLiteAdapter
from smf_loader.schemas import SMF30Schema

loader = SMFLoader(
    database=SQLiteAdapter('smf_data.db'),
    schema=SMF30Schema()
)
loader.create_schema()
loader.load_json_file('smf_records.json')
loader.close()
```

**Unified Database Usage (Recommended for Analytics):**
```bash
# Load all record types into single database
python -m smf_loader load --unified --db smf_analytics.db --file all_records.json --create-schema
```

```python
from smf_loader import SMFLoader
from smf_loader.databases import SQLiteAdapter
from smf_loader.schemas import UnifiedSMFSchema

loader = SMFLoader(
    database=SQLiteAdapter('smf_analytics.db'),
    schema=UnifiedSMFSchema()
)
loader.create_schema()
loader.load_json_file('all_records.json')  # Loads all types
loader.close()
```

**Documentation:** 
- [smf_loader/README.md](smf_loader/README.md) - General usage
- [smf_loader/UNIFIED_DATABASE_GUIDE.md](smf_loader/UNIFIED_DATABASE_GUIDE.md) - Unified database guide

#### SMF Query Engine

Analyze loaded data with pre-built queries and custom SQL.

**Query Files:**
- `smf30_queries.py` - Type 30 (Job/Step Accounting) queries
- `smf110_queries.py` - Type 110 (CICS Transaction Server) queries
- `cross_type_queries.py` - Cross-record-type queries
- `artifact_queries.py` - Artifact lifecycle analysis queries (unreferenced, missing, risk assessment, cleanup)

All queries use the unified schema with prefixed table names (`smf30_*`, `smf110_*`, `inventory_*`, `dependencies`).

**Features:**
- 9 pre-built queries for SMF Type 30
- 11 pre-built queries for SMF Type 110
- **7 cross-type queries** for unified database analysis
- **12+ artifact analysis queries** for inventory and dependency analysis
- Parameterized queries
- Multiple output formats (JSON, CSV, Markdown, Table)
- AI-friendly structured output
- Custom SQL support

**Single-Type Usage:**
```python
from smf_loader.databases import SQLiteAdapter
from smf_queries import QueryEngine
from smf_queries.smf30_queries import SMF30_QUERIES

database = SQLiteAdapter('smf_data.db')
database.connect()

engine = QueryEngine(database)
engine.register_queries(SMF30_QUERIES)

result = engine.execute('top_cpu_consumers', limit=10)

# Export in different formats
print(result.to_json())      # JSON
print(result.to_csv())       # CSV
print(result.to_markdown())  # Markdown table
```

**Cross-Type Analysis (Unified Database):**
```python
from smf_queries import QueryEngine, CROSS_TYPE_QUERIES

database = SQLiteAdapter('smf_analytics.db')
database.connect()

engine = QueryEngine(database)
engine.register_queries(CROSS_TYPE_QUERIES)

# Correlate batch jobs with CICS activity
result = engine.execute('batch_cics_correlation', date='2024-01-15')

# Analyze workload distribution across all types
result = engine.execute('workload_distribution')

# Find resource contention
result = engine.execute('resource_contention', date='2024-01-15')
```

**Available Queries:**
- **Type 30**: CPU Analysis, I/O Analysis, Storage, Completion
- **Type 110**: CICS transactions, performance, volume
- **Cross-Type**: Batch-CICS correlation, workload distribution, resource contention, time-correlated events
- **Artifact Analysis**: Unreferenced artifacts, missing artifacts, risk assessment, cleanup recommendations, dependency analysis

**Documentation:** See [smf_queries/README.md](smf_queries/README.md)

### 2. Legacy Analyzer

The Legacy Analyzer tool provides comprehensive static code analysis and migration planning capabilities for mainframe applications. It supports multiple programming languages and provides deep insights into code structure, dependencies, and complexity.

The Legacy Analyzer (formerly SMF Inventory) is a comprehensive system for analyzing legacy applications to support modernization and migration initiatives. It extends beyond simple inventory management to provide deep code analysis, program flow visualization, complexity assessment, and migration package planning.

**Features:**
- **Inventory Loading**: Load JCL, programs, datasets, copybooks, and CICS resources from CSV files
- **Static Code Analysis**: Parse COBOL, JCL, PL/I, RPG, Natural, and REXX source code to extract dependencies
- **Intelligent Language Detection**: Automatically detect programming language from file content, not just extension (handles `.txt` and other ambiguous extensions)
- **Program Flow Analysis**: Visualize complete program flows and call graphs
- **Complexity Assessment**: Calculate complexity metrics (LOC, cyclomatic complexity, dependencies)
- **Missing Code Detection**: Identify artifacts referenced but not in inventory
- **Migration Package Planning**: Group artifacts into logical migration packages
- **Circular Dependency Detection**: Find and report circular dependencies
- **Multi-Language Support**: COBOL, PL/I, JCL, RPG, Natural, REXX, Assembler
- **Cross-Language Dependencies**: Track dependencies across different languages
- **Visualization**: Export flows as Mermaid, Graphviz DOT, or JSON
- **Database Integration**: Store all data in unified database with SMF records
- **Mainframe Export Scripts**: JCL and REXX scripts to export inventory from z/OS

**What it does:**
- Loads inventory catalogs (what artifacts exist on the mainframe)
- Analyzes source code to find dependencies (what calls what, what includes what)
- Stores this data in database tables for querying

**What it doesn't do:**
- The actual artifact lifecycle analysis (finding unreferenced artifacts, risk assessment, cleanup recommendations) is performed by queries in the `smf_queries` module

**Quick Start:**
```bash
# 1. Load inventory data
python -m legacy_analyzer load --type jcl --file inventory/jcl_inventory.csv --db analyzer.db
python -m legacy_analyzer load --type programs --file inventory/program_inventory.csv --db analyzer.db
python -m legacy_analyzer load --type datasets --file inventory/dataset_inventory.csv --db analyzer.db

# 2. Analyze source code for dependencies (auto-detects all languages)
python -m legacy_analyzer analyze --source-dir /path/to/source --db analyzer.db

# Or analyze specific language
python -m legacy_analyzer analyze --source-dir /path/to/cobol --language COBOL --db analyzer.db

# 3. Analyze program flows
python -m legacy_analyzer flow analyze --program PAYROLL1 --db analyzer.db --output payroll_flow.json
python -m legacy_analyzer flow detect-circular --db analyzer.db

# 4. Calculate complexity metrics
python -m legacy_analyzer complexity analyze --db analyzer.db --output complexity_metrics.csv

# 5. Create migration packages
python -m legacy_analyzer package create --name "Payroll" --seeds PAYROLL1,PAYCALC --db analyzer.db
python -m legacy_analyzer package validate --name "Payroll" --db analyzer.db

# 6. Find unreferenced artifacts (using smf_queries)
python -m smf_queries run --db analyzer.db --query unreferenced_programs --params analysis_days=365
python -m smf_queries run --db analyzer.db --query artifact_risk_assessment
```

**Python API:**
```python
from smf_loader.databases import SQLiteAdapter
from tools.legacy_analyzer.inventory.inventory_loader import InventoryLoader
from tools.legacy_analyzer.parsers.parser_factory import ParserFactory
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer
from tools.legacy_analyzer.migration.package_builder import PackageBuilder
from smf_queries import QueryEngine

database = SQLiteAdapter('analyzer.db')
database.connect()

# Load inventory
loader = InventoryLoader(database)
loader.create_schema()
loader.load_jcl_inventory('jcl_inventory.csv')
loader.load_program_inventory('program_inventory.csv')

# Analyze source code
parser_factory = ParserFactory()
parser = parser_factory.get_parser_for_file('PAYROLL1.cbl')
dependencies = parser.parse_file('PAYROLL1.cbl')

# Analyze program flows
flow_analyzer = FlowAnalyzer(database)
flow = flow_analyzer.analyze_flow('PAYROLL1', max_depth=10)
circular_deps = flow_analyzer.detect_circular_dependencies()

# Calculate complexity
complexity_analyzer = ComplexityAnalyzer()
metrics = complexity_analyzer.analyze_program(
    program_name='PAYROLL1',
    source_code=cobol_code,
    language='COBOL',
    dependency_count_in=5,
    dependency_count_out=10
)

# Create migration packages
package_builder = PackageBuilder(database)
package = package_builder.create_package(
    name='Payroll Migration',
    seed_artifacts=['PAYROLL1', 'PAYCALC']
)

# Query for unreferenced artifacts
engine = QueryEngine(database)
unreferenced = engine.execute('unreferenced_programs', analysis_days=365)

database.close()
```

**Note:** Once inventory and dependency data is loaded, use the artifact analysis queries in `smf_queries` to:
- Find unreferenced artifacts (exist in inventory but not used in SMF records)
- Find missing artifacts (used in SMF records but not in inventory)
- Assess risk levels and generate cleanup recommendations
- Analyze dependencies between artifacts

See the [SMF Query Engine](#3-smf-query-engine) section for available artifact analysis queries.

**Configuration:**

Risk patterns and analysis settings are configured in `config/artifact_analysis.yaml`:

```yaml
analysis:
  default_window_days: 365
  min_usage_threshold: 1

risk_patterns:
  high_risk:
    - pattern: "DR%"
      reason: "Disaster Recovery"
    - pattern: "YEAREND%"
      reason: "Year-end Processing"
    - pattern: "AUDIT%"
      reason: "Audit/Compliance"
  
  medium_risk:
    - pattern: "BACKUP%"
      reason: "Backup Process"
    - pattern: "UTIL%"
      reason: "Utility Program"

cleanup:
  archive_threshold_days: 730
  review_threshold_days: 365
```

**Documentation:**
- [docs/GETTING_STARTED.md](docs/GETTING_STARTED.md) - Quick start guide
- [docs/INVENTORY_GUIDE.md](docs/INVENTORY_GUIDE.md) - Inventory management
- [docs/STATIC_ANALYSIS_GUIDE.md](docs/STATIC_ANALYSIS_GUIDE.md) - Code analysis
- [docs/FLOW_ANALYSIS_GUIDE.md](docs/FLOW_ANALYSIS_GUIDE.md) - Program flow analysis
- [docs/COMPLEXITY_GUIDE.md](docs/COMPLEXITY_GUIDE.md) - Complexity assessment
- [docs/MIGRATION_PACKAGES_GUIDE.md](docs/MIGRATION_PACKAGES_GUIDE.md) - Migration package planning
- [docs/MIGRATION_WORKFLOW_GUIDE.md](docs/MIGRATION_WORKFLOW_GUIDE.md) - Complete migration workflow
- [docs/QUERY_REFERENCE.md](docs/QUERY_REFERENCE.md) - Query documentation
- [docs/RISK_ASSESSMENT_GUIDE.md](docs/RISK_ASSESSMENT_GUIDE.md) - Risk analysis
- [docs/CLEANUP_WORKFLOW.md](docs/CLEANUP_WORKFLOW.md) - Cleanup procedures
- [docs/API_REFERENCE.md](docs/API_REFERENCE.md) - Python API reference
- [docs/CLI_REFERENCE.md](docs/CLI_REFERENCE.md) - Command-line interface

**Examples:**
- [examples/flow_analysis_example.py](examples/flow_analysis_example.py) - Program flow analysis
- [examples/complexity_analysis_example.py](examples/complexity_analysis_example.py) - Complexity assessment
- [examples/migration_package_example.py](examples/migration_package_example.py) - Migration package planning
- [examples/complete_migration_workflow.py](examples/complete_migration_workflow.py) - End-to-end migration
- [examples/complete_artifact_analysis.py](examples/complete_artifact_analysis.py) - Artifact lifecycle analysis
- [examples/inventory_loading_example.py](examples/inventory_loading_example.py) - Inventory loading
- [examples/cleanup_workflow_example.py](examples/cleanup_workflow_example.py) - Cleanup workflow

### 3. SMF Dashboard

The SMF Dashboard provides a web-based interface for interactive SMF analysis, making complex queries accessible to non-technical users and providing real-time visualization of mainframe performance data.

**Features:**
- **7-Tab Interface**: Data Management, Database Inspector, All Queries, ROI Analysis, Migration Planning, Infrastructure Sizing, Configuration
- **Real-Time Query Execution**: Run pre-built queries with custom parameters
- **Multi-Format Export**: JSON, CSV, Markdown export for all results
- **Session Management**: Persistent database selection across tabs
- **Configuration Management**: Centralized global configuration with validation
- **Progress Tracking**: Real-time feedback for long-running operations with cancellation support
- **Database Inspector**: Browse tables, view schemas, run custom SQL
- **Query Categories**: Infrastructure, Cost, Migration, Artifact Analysis, Cross-Type Analysis

**Quick Start:**
```bash
# Install dashboard dependencies
pip install -e ".[dashboard]"

# Start dashboard
smf-dashboard

# Or run directly
python -m tools.smf_dashboard.app

# Access at http://localhost:5001
```

**Features by Tab:**

1. **Data Management**: Upload SMF files, parse, and load into databases
2. **Database Inspector**: Browse tables, view schemas, execute custom SQL
3. **All Queries**: Run 36+ pre-built queries across all SMF types
4. **ROI Analysis**: Calculate migration costs and ROI projections
5. **Migration Planning**: Analyze flows, dependencies, and migration packages
6. **Infrastructure Sizing**: Estimate cloud infrastructure requirements
7. **Configuration**: Manage global settings and query parameters

**Production Deployment:**
```bash
# With Gunicorn (Linux/macOS)
export FLASK_ENV=production
export SECRET_KEY=your-secure-secret-key
gunicorn -w 4 -b 0.0.0.0:8000 tools.smf_dashboard.app:app

# With Waitress (Windows)
waitress-serve --host=0.0.0.0 --port=8000 tools.smf_dashboard.app:app
```

**Documentation:**
- [tools/smf_dashboard/README.md](tools/smf_dashboard/README.md) - Dashboard overview and setup
- [tools/smf_dashboard/docs/DEPLOYMENT.md](tools/smf_dashboard/docs/DEPLOYMENT.md) - Production deployment guide
- [tools/smf_dashboard/docs/USER_GUIDE.md](tools/smf_dashboard/docs/USER_GUIDE.md) - User interface guide
- [tools/smf_dashboard/docs/API.md](tools/smf_dashboard/docs/API.md) - REST API documentation
- [tools/smf_dashboard/docs/ARCHITECTURE.md](tools/smf_dashboard/docs/ARCHITECTURE.md) - Technical architecture

### 4. ATX Dependency Transformer

The ATX Dependency Transformer converts ATX tool outputs into legacy_analyzer-compatible format, enabling users with existing ATX analysis results to leverage legacy_analyzer workflows for migration planning without re-running static code analysis.

**Features:**
- **Transform ATX to Flows**: Convert ATX dependencies and metrics to migration flows
- **Transform ATX to Jobs**: Convert ATX JCL data to job orchestration format
- **Transform ATX to Entry Points**: Extract and classify entry points (CICS, JCL, inferred)
- **Complexity Calculation**: Calculate composite complexity scores and assign tiers
- **Dependency Resolution**: Compute flow-to-flow dependencies via call graph analysis
- **Multiple Sorting Strategies**: Export flows and jobs with 6+ sorting options
- **Configuration Support**: Customize complexity formulas, utility programs, and thresholds
- **Validation Engine**: Validate ATX inputs and transformation outputs
- **Dry-Run Mode**: Preview transformation without writing files

**Quick Start:**
```bash
# Transform all (flows, jobs, entry points)
python -m tools.atx.dependency_transformer transform all \
  --input-dir examples/atx \
  --output-dir results/atx_transformed

# Transform only flows
python -m tools.atx.dependency_transformer transform flows \
  --input-dir examples/atx \
  --output-dir results/flows

# Dry run with custom configuration
python -m tools.atx.dependency_transformer transform all \
  --input-dir examples/atx \
  --output-dir results/atx_transformed \
  --config config/atx_transformer.yaml \
  --dry-run \
  --verbose
```

**Input Requirements:**
- `dependencies.json` - ATX program dependencies and call relationships
- `assets.csv` - ATX code metrics (cyclomatic complexity, LOC)
- `program_to_dsn.json` - ATX data operations with access types

**Output Structure:**
```
output_dir/
├── flows/
│   ├── Business_Flows.json              # Main flows file
│   ├── flows_by_complexity_asc.json      # Simplest first
│   ├── flows_by_complexity_desc.json     # Most complex first
│   ├── flows_by_independence.json        # Minimal dependencies
│   └── flows_by_name.json                # Alphabetical
├── jobs/
│   ├── jobs.json                         # Main jobs file
│   ├── jobs_by_name.json                 # Alphabetical
│   ├── jobs_by_type.json                 # APPLICATION first
│   └── jobs_by_complexity.json           # Most complex first
├── entry_points.json                     # Entry points (JSON)
└── exports/
    └── entry_points.csv                  # Entry points (CSV)
```

**Documentation:**
- [tools/atx/dependency_transformer/README.md](tools/atx/dependency_transformer/README.md) - Tool overview and usage
- [tools/atx/dependency_transformer/docs/CLI_USAGE.md](tools/atx/dependency_transformer/docs/CLI_USAGE.md) - CLI reference
- [tools/atx/dependency_transformer/docs/ATX_TO_LEGACY_ANALYZER_MAPPING.md](tools/atx/dependency_transformer/docs/ATX_TO_LEGACY_ANALYZER_MAPPING.md) - Field mappings
- [tools/atx/dependency_transformer/docs/IMPROVEMENT_PLAN.md](tools/atx/dependency_transformer/docs/IMPROVEMENT_PLAN.md) - Future enhancements

**Configuration:**
```yaml
# config/atx_transformer.yaml
complexity:
  formula:
    cc_weight: 0.3
    loc_weight: 0.7
  thresholds:
    low: 10
    medium: 20
    high: 50

utility_programs:
  - IDCAMS
  - IEFBR14
  - SORT
  - IEBGENER
```

### 5. SMF Test Data Generator

The SMF Test Data Generator creates realistic SMF test data for development, testing, and demonstration purposes, supporting multiple record types with configurable workload patterns.

**Features:**
- **Multiple Record Types**: Generate SMF Type 30 (batch) and Type 110 (CICS) records
- **Realistic Patterns**: Configurable workload patterns and resource usage
- **Inventory Integration**: Uses real inventory data for artifact references
- **Distribution Strategies**: Multiple distribution strategies for realistic data patterns
- **Configurable Scenarios**: Customize date ranges, volumes, and characteristics
- **High-MIPS Scenarios**: Generate high-resource-usage test data
- **Validation**: Verify generated data matches expected patterns

**Quick Start:**
```bash
# Generate test data from configuration
python -m tools.smf_test_data_generator \
  --config examples/config/carddemo_smf_generation_inventory.yaml \
  --verbose

# Generate specific record type
python -m tools.smf_test_data_generator generate \
  --type 30 \
  --count 1000 \
  --output test_data.json

# Generate with inventory
python -m tools.smf_test_data_generator generate \
  --type 110 \
  --inventory inventory.yaml \
  --output cics_data.json
```

**Configuration Example:**
```yaml
# examples/config/carddemo_smf_generation_inventory.yaml
generation:
  date_range:
    start: "2025-01-01"
    end: "2026-02-04"
  
  smf_type_30:
    enabled: true
    count: 20000
    distribution: "realistic"
  
  smf_type_110:
    enabled: true
    count: 10000
    distribution: "peak_hours"

inventory:
  programs: "examples/data/program_inventory.csv"
  jcl: "examples/data/jcl_inventory.csv"
  transactions: "examples/data/cics_inventory.csv"
```

**Documentation:**
- [tools/smf_test_data_generator/doc/README.md](tools/smf_test_data_generator/doc/README.md) - Generator overview
- [tools/smf_test_data_generator/doc/USAGE.md](tools/smf_test_data_generator/doc/USAGE.md) - Detailed usage guide
- [tools/smf_test_data_generator/doc/API.md](tools/smf_test_data_generator/doc/API.md) - API reference
- [tools/smf_test_data_generator/doc/EXAMPLES.md](tools/smf_test_data_generator/doc/EXAMPLES.md) - Configuration examples

### 6. Migration Planner

The Migration Planner tool is designed for AI-assisted migration planning, rules extraction, and code generation. This tool is currently in planning phase and will provide:

**Planned Features:**
- **AI-Powered Analysis**: Integration with large language models for intelligent code analysis
- **Migration Rules Extraction**: Automatic extraction of business rules from legacy code
- **Code Generation**: Generate modern equivalents of legacy programs
- **Migration Strategy Planning**: Create comprehensive migration roadmaps
- **Risk Assessment**: Automated assessment of migration complexity and risks
- **Transformation Templates**: Reusable patterns for common migration scenarios

**Current Status:**
The Migration Planner is currently a placeholder with basic structure in place. Future development will focus on:
- LLM integration for code understanding
- Business rule extraction algorithms
- Code generation templates
- Migration planning workflows

**Documentation:**
- [tools/migration-planner/README.md](tools/migration-planner/README.md) - Placeholder documentation
- [docs/tools/migration-planner/](docs/tools/migration-planner/) - Future detailed documentation

## Shared Infrastructure

The toolkit includes shared infrastructure components that provide common functionality across all tools:

### Database Components
- **Schemas**: Common database schema definitions (in `shared/database/schemas/`)
- **Adapters**: Database connection and query adapters for SQLite, PostgreSQL (planned)
- **Migrations**: Schema migration utilities

### Utilities
- **File Operations**: Common file handling utilities
- **Validation**: Data validation functions used across tools
- **Configuration**: Shared configuration management

### Configuration Management
- **Base Configuration**: Common configuration loading and validation
- **Tool-Specific Configs**: Individual tool configuration management
- **Environment Handling**: Development, testing, and production environment support

## Data Flow

```
Binary SMF File (*.Dat, *.smf)
    ↓
smf_record_parser (CLI)
    ├→ Combined JSON (all records)
    ├→ Split JSON (by record type)
    └→ Markdown Report
    ↓
smf_loader (CLI)
    └→ Database (SQLite/PostgreSQL)
    ↓
smf_queries (CLI)
    └→ Analysis Results (JSON/CSV/Markdown/Table)
```

### Example: Complete Analysis Pipeline

```bash
# 1. Parse SMF dump file
python3 -m smf_record_parser parse examples/SMF30_1.Dat --split type -o results
# Output: SMF30_1_002.json, SMF30_1_003.json, SMF30_1_030.json, SMF30_1_REPORT.md

# 2. Load Type 30 records
python3 -m smf_loader load --type 30 --db smf_data.db --file results/SMF30_1_030.json --create-schema
# Output: Database with 2,967 records loaded

# 3. Run analysis queries
python3 -m smf_queries run --db smf_data.db --query top_cpu_consumers
python3 -m smf_queries run --db smf_data.db --query dataset_activity
python3 -m smf_queries run --db smf_data.db --query job_completion_rate
```

## Supported Record Types

| Record Type | Description | Parser | Loader | Queries | Notes |
|-------------|-------------|--------|--------|---------|-------|
| Type 2 | Dump Header | ✓ | ✗ | ✗ | Metadata only - captured in report |
| Type 3 | Dump Trailer | ✓ | ✗ | ✗ | Metadata only - captured in report |
| Type 30 | Job/Step Accounting | ✓ | ✓ | ✓ (9 queries) | Full support |
| Type 100 | DB2 Statistics | ✓ | ✓ | Planned | DB2 V10 - Auto version detection |
| Type 101 | DB2 Accounting | ✓ | ✓ | Planned | DB2 V11, V12 - Auto version detection |
| Type 102 | DB2 Performance | ✓ | ✓ | Planned | DB2 V11, V12, V13 - Auto version detection |
| Type 110 | CICS Transaction Server | ✓ | ✓ | ✓ (11 queries) | Full support - 6 subtypes, 7 tables |
| Type 70 | RMF System Resources | Planned | Planned | Planned | System-wide CPU, storage, I/O |
| Type 72 | RMF Workload Manager | Planned | Planned | Planned | Application-level performance |
| Type 74 | RMF Device Activity | Planned | Planned | Planned | Storage I/O and DASD performance |

**Design Note**: Type 2 and Type 3 records are structural markers (dump start/end) containing only timestamps and system IDs. They are parsed and documented in the markdown report but not loaded into the database, as they provide no analytical value. The focus is on data-bearing record types like Type 30 that contain business metrics and performance data.

### DB2 Record Support

The toolkit includes specialized support for DB2 SMF records (Types 100, 101, 102) with automatic version detection:

**Key Features:**
- **Automatic DB2 Version Detection**: Extracts DB2 version from each record's QWHSRELN field
- **Version-Specific Parsers**: Dedicated parsers for each DB2 version (V10-V13)
- **Fallback Parsing**: Automatically uses nearest parser when exact version unavailable
- **Database Integration**: Dedicated schemas for DB2 statistics, accounting, and performance data

**Supported Versions:**
- Type 100 (Statistics): DB2 V10
- Type 101 (Accounting): DB2 V11, V12
- Type 102 (Performance): DB2 V11, V12, V13

**Example Usage:**
```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# Parser automatically detects DB2 version
parser = SMFParserFactory.create_parser(100, record_data=record_data)
result = parser.parse(record_data, version="V10")

print(f"DB2 Version: {result.version}")
print(f"Subsystem: {result.sections['qwhs_header']['subsystem_name']}")
```

**Documentation:** See [DB2 Parser User Guide](docs/db2_parsers.md) for complete details on:
- DB2 version detection mechanism
- Parsing examples for each record type
- Fallback parser behavior
- Database loading and querying
- Field mappings and version differences
- Adding support for new DB2 versions

## Database Architecture

### Unified Database - Single Schema for All Record Types

Load all SMF record types into a single database for comprehensive analysis:

**Use Cases:**
- Cross-record-type queries (correlate batch jobs with CICS transactions)
- Time-correlated analysis (what was happening system-wide when X occurred)
- Complete performance picture (job + system + transaction data)
- AI/ML analysis across all data
- Dashboards and reporting

**Quick Start:**
```bash
python3 -m smf_loader load --unified --db smf_analytics.db --file records.json --create-schema
```

**Features:**
- Single database with all record types
- Common `smf_records` table for time correlation
- Type-specific tables with prefixes (`smf30_*`, `smf110_*`)
- 7 cross-type queries included
- Easy JOINs across record types

**Documentation:** See [Unified Database](#unified-database-option-1) section below

### Supported Database Engines

| Database | Status | Notes |
|----------|--------|-------|
| SQLite | ✓ | Built-in, no dependencies |
| PostgreSQL | Planned | Production-grade RDBMS |
| DuckDB | Planned | Analytics and columnar storage |

## Installation

### Prerequisites

- Python 3.8 or higher

### Install Dependencies

The project provides multiple requirements files for different use cases:

```bash
# For production/runtime use (minimal dependencies)
pip install -r requirements-minimal.txt

# For full functionality including documentation parsing
pip install -r requirements.txt

# For development (includes testing and code quality tools)
pip install -r requirements-dev.txt
```

### Install from source

```bash
git clone <repository-url>
cd smf
pip install -r requirements.txt
pip install -e .
```

### Quick Start Installation

For immediate use with the analysis pipeline:

```bash
git clone <repository-url>
cd smf
pip install -r requirements-minimal.txt
python examples/smf_analysis_pipeline.py
```

## Integration

### Integrating into Other Projects

The SMF Migration Toolkit can be integrated into other projects as a complete toolset. Two integration guides are available:

- **[INTEGRATION_SIMPLE.md](INTEGRATION_SIMPLE.md)** - Simple integration guide for copying the entire toolkit
- **[INTEGRATION_GUIDE.md](INTEGRATION_GUIDE.md)** - Comprehensive integration guide with multiple options (Git Submodule, Selective Copy, Python Package)

**Recommended Approach:**

Copy the entire toolkit to your project's tools directory:

```bash
# Copy entire toolkit
cp -r /path/to/smf-migration-toolkit /path/to/myproject/tools/acm-tools

# Your .gitignore will filter unwanted files automatically
```

This approach includes:
- ✅ All tools (SMF Analyzer, Legacy Analyzer, Dashboard, ATX Transformer, Test Data Generator)
- ✅ Complete documentation
- ✅ Configuration files and examples
- ✅ Shared infrastructure
- ✅ Test suites

See [INTEGRATION_SIMPLE.md](INTEGRATION_SIMPLE.md) for detailed instructions.

## Examples

### Complete Analysis Pipeline

The `examples/smf_analysis_pipeline.py` script provides a complete end-to-end SMF analysis workflow:

```bash
# Run with default settings (auto-selects largest SMF file)
python examples/smf_analysis_pipeline.py

# Specify input file and output directory
python examples/smf_analysis_pipeline.py \
    --input examples/data/jse/SMF.APR4.TRS.DECOMPRESS \
    --output ./analysis_results
```

**Pipeline Steps:**
1. **Parse SMF File**: Auto-detects format and extracts all record types
2. **Load Database**: Creates unified SQLite database with all data
3. **Run Queries**: Executes 36+ analysis queries across all record types
4. **Generate Reports**: Creates comprehensive summary with multiple output formats

**Example Results** (from SMF.APR4.TRS.DECOMPRESS):
- **85,961 total records** processed across 6 SMF types
- **Type 30**: 20,180 job/step accounting records
- **Type 110**: 11,015 CICS performance records  
- **Type 14/15**: 54,764 dataset activity records
- **36 successful queries** with results in JSON, CSV, and Markdown
- **Complete analysis** in under 2 minutes

**Generated Files:**
```
results/
├── SMF.APR4.TRS_ALL.json          # All records combined (85,961 records)
├── SMF.APR4.TRS_030.json          # Type 30 records only
├── SMF.APR4.TRS_110.json          # Type 110 records only
├── SMF.APR4.TRS_REPORT.md         # Parsing report
├── smf_analysis.db                # SQLite database (1.2GB)
├── SMF_ANALYSIS_SUMMARY.md        # Complete analysis summary
├── QUERY_EXECUTION_REPORT.md      # Query performance report
└── queries/                       # Individual query results
    ├── smf_type_30_job_step_accounting/
    ├── smf_type_110_cics_performance/
    ├── cross-type_analysis/
    └── artifact_lifecycle_analysis/
```

### Parse SMF Record

```python
from smf_record_parser.parsers import SMFParserFactory

parser = SMFParserFactory.create_parser(30, "V3R2", "EBCDIC")
with open('smf30.bin', 'rb') as f:
    parsed = parser.parse(f.read())

# Access parsed data
print(f"Job: {parsed.identification['job_name']}")
print(f"CPU: {parsed.processor['cpu_time']}")
```

### Load into Database

```bash
# Command line
python -m smf_loader load --type 30 --db smf_data.db --file smf_records.json --create-schema --stats
```

### Query Data

```bash
# List available queries
python -m smf_queries list --db smf_data.db

# Run a query
python -m smf_queries run --db smf_data.db --query top_cpu_consumers --params limit=10

# Export to different formats
python -m smf_queries run --db smf_data.db --query cpu_statistics --format json
python -m smf_queries run --db smf_data.db --query top_io_consumers --format csv
python -m smf_queries run --db smf_data.db --query cpu_by_program --format markdown
```

### SMF Analysis Pipeline

```bash
# Complete SMF analysis (recommended starting point)
python examples/smf_analysis_pipeline.py

# With custom settings
python examples/smf_analysis_pipeline.py \
    --input examples/data/jse/SMF.APR4.TRS.DECOMPRESS \
    --output ./my_analysis

# Pipeline processes:
# - 85,961 SMF records across 6 types
# - Creates unified database for cross-analysis  
# - Runs 36+ queries with comprehensive reporting
# - Generates results in JSON, CSV, and Markdown formats
```

### Artifact Lifecycle Analysis

```bash
# Complete artifact analysis workflow
python examples/complete_artifact_analysis.py \
    --smf-dir examples/data \
    --inventory-dir examples/data \
    --source-dir /path/to/source \
    --database smf_analytics.db \
    --output-dir reports

# Load inventory only
python examples/inventory_loading_example.py \
    --inventory-dir examples/data \
    --database smf_analytics.db

# Generate cleanup plan
python examples/cleanup_workflow_example.py \
    --database smf_analytics.db \
    --output-dir cleanup_plan \
    --analysis-days 365 \
    --min-inactive-days 730
```

### Export Results

```python
result = engine.execute('top_cpu_consumers', limit=100)

# Save as JSON
with open('results.json', 'w') as f:
    f.write(result.to_json())

# Save as CSV
with open('results.csv', 'w') as f:
    f.write(result.to_csv())

# Save as Markdown
with open('report.md', 'w') as f:
    f.write(f"# {result.description}\n\n")
    f.write(result.to_markdown())
```

## Automation Scripts

The `scripts/` directory contains automation scripts for common workflows:

### Analysis Scripts

- **complete_analysis.sh**: Complete CICS application analysis (metadata + code + complexity)
- **run_carddemo_analysis.sh**: Run complete analysis on CardDemo sample application
- **run_configurable_analysis.sh**: Configurable analysis script with custom parameters
- **run_all_projects_analysis.sh**: Batch analysis across multiple projects

**Usage:**
```bash
# Complete analysis with default settings
./scripts/complete_analysis.sh ./source-dir ./output-dir

# Configurable analysis
./scripts/run_configurable_analysis.sh \
  --source-dir ./code \
  --output-dir ./results \
  --database-path ./analysis.db
```

See [scripts/README_CONFIGURABLE_ANALYSIS.md](scripts/README_CONFIGURABLE_ANALYSIS.md) for detailed documentation.

### Data Loading Scripts

- **load_test_data.sh**: Load test data into separate databases
- **load_test_data_unified.sh**: Load test data into unified database
- **load_all_data.sh**: Load all available test data
- **copy_inventory_to_test_db.sh**: Copy inventory data between databases

### Dashboard Scripts

- **startDashboard.sh**: Start the SMF Dashboard
- **stopDashboard.sh**: Stop the SMF Dashboard
- **restart_dashboard.sh**: Restart the SMF Dashboard

### Test Data Scripts

- **regenerate_test_data.sh**: Regenerate all test data
- **regenerate_high_mips_data.sh**: Generate high-MIPS test scenarios
- **run_smftestdata_inventory.sh**: Generate SMF data from inventory

### Query Testing Scripts

- **test_queries.sh**: Test all query categories
- **test_cost_queries.sh**: Test cost analysis queries

## Architecture

All components follow consistent design principles:

- **Separation of Concerns**: Clear boundaries between components
- **Strategy Pattern**: Pluggable implementations
- **Extensibility**: Add features without modifying core code
- **Type Safety**: Strong interfaces and abstractions
- **Documentation**: Comprehensive docs and examples

## Unified Database (Option 1)

### Overview

The unified database approach consolidates multiple SMF record types into a single database, enabling powerful cross-record-type analysis.

### Architecture

**Common Table:**
- `smf_records` - All record types with `record_type` column for filtering

**Type-Specific Tables:**
- `smf30_*` - Job/Step Accounting (6 tables)
- `smf110_*` - CICS Transactions (6 tables)
- Future: `smf70_*`, `smf72_*`, `smf74_*`

### Creating a Unified Database

```bash
# Load all record types
python3 -m smf_loader load --unified --db smf_analytics.db --file all_records.json --create-schema

# Add more data later
python3 -m smf_loader load --unified --db smf_analytics.db --file more_records.json
```

### Cross-Type Queries

The toolkit includes 7 pre-built cross-type queries:

1. **workload_distribution** - Activity across all record types
2. **batch_cics_correlation** - Correlate batch jobs with CICS (Type 30 + 110)
3. **application_end_to_end** - Complete app performance (batch + CICS)
4. **resource_contention** - Failed jobs during high load
5. **storage_io_correlation** - Job I/O vs device performance (Type 30 + 74)
6. **system_cpu_utilization** - Job CPU vs system capacity (Type 30 + 70)
7. **time_correlated_events** - What happened at specific time

**Usage:**
```python
from smf_loader.databases import SQLiteAdapter
from smf_queries import QueryEngine, CROSS_TYPE_QUERIES

db = SQLiteAdapter('smf_analytics.db')
db.connect()

engine = QueryEngine(db)
engine.register_queries(CROSS_TYPE_QUERIES)

# Run cross-type queries
result = engine.execute('workload_distribution')
result.print_table()

result = engine.execute('batch_cics_correlation', date='2024-01-15')
result.to_csv('correlation.csv')
```

### Example: Find What Was Happening When Job Failed

```sql
SELECT 
    r.record_type,
    r.record_time,
    CASE r.record_type
        WHEN 30 THEN i30.job_name
        WHEN 110 THEN p110.product_name_generic
    END as identifier
FROM smf_records r
LEFT JOIN smf30_identification i30 ON r.record_id = i30.record_id AND r.record_type = 30
LEFT JOIN smf110_product p110 ON r.record_id = p110.record_id AND r.record_type = 110
WHERE r.record_date = '2024-01-15'
    AND r.record_time BETWEEN '14:30:00' AND '14:35:00'
ORDER BY r.record_time;
```

### When to Use Unified vs Single-Type

**Use Unified When:**
- ✅ Analyzing relationships between different workload types
- ✅ Time-correlated analysis needed
- ✅ Building dashboards or reports
- ✅ AI/ML analysis across all data

**Use Single-Type When:**
- ✅ Deep dive into one specific record type
- ✅ Smaller, faster database needed
- ✅ Type-specific optimization required

**You can have both!** Create unified for analytics and single-type for focused work.

### Performance Tips

1. **Always filter by record_type** for best performance:
   ```sql
   WHERE r.record_type = 30  -- Much faster
   ```

2. **Use date ranges** to limit data scanned:
   ```sql
   WHERE r.record_date BETWEEN '2024-01-01' AND '2024-01-31'
   ```

3. **Indexes are automatic** - All foreign keys and common query fields are indexed

### Complete Example

See [examples/unified_database_example.py](examples/unified_database_example.py) for a complete working example.

## Extending the Toolkit

### Add a New Record Type

1. **Parser**: Create parser in `smf_record_parser/parsers/`
2. **Schema**: Create schema in `smf_loader/schemas/`
3. **Queries**: Create queries in `smf_queries/`

### Add a New Database

Create adapter in `smf_loader/databases/`:

```python
from smf_loader.core.base_database import BaseDatabase

class PostgreSQLAdapter(BaseDatabase):
    @property
    def dialect(self) -> str:
        return 'postgresql'
    
    # Implement required methods
```

### Add a New Query

Create query in `smf_queries/`:

```python
from smf_queries.base_query import BaseQuery

class MyCustomQuery(BaseQuery):
    @property
    def name(self) -> str:
        return "my_query"
    
    def get_sql(self, **params) -> str:
        return "SELECT ..."
```

## Documentation

### Main Documentation

- **[README.md](README.md)** (this file) - Project overview, quick start, and architecture
- **[IMPLEMENTATION_COMPLETE.md](IMPLEMENTATION_COMPLETE.md)** - Complete implementation summary

### Component Documentation

#### SMF Record Parser
- **[CLI_README.md](smf_record_parser/CLI_README.md)** - Command-line interface and Python API
- **[FILE_FORMAT_DETECTION.md](smf_record_parser/docs/FILE_FORMAT_DETECTION.md)** - File format detection guide (VB/VBS/Standard)
- **[SMF_TYPE_2_IMPLEMENTATION.md](SMF_TYPE_2_IMPLEMENTATION.md)** - Type 2 (Dump Header) parser
- **[SMF_TYPE_3_IMPLEMENTATION.md](SMF_TYPE_3_IMPLEMENTATION.md)** - Type 3 (Dump Trailer) parser
- **[SMF_TYPE_6_README.md](smf_record_parser/docs/SMF_TYPE_6_README.md)** - Type 6 (Output Writer) parser
- **[SMF_PARSER_CLI_SUMMARY.md](SMF_PARSER_CLI_SUMMARY.md)** - CLI implementation summary

#### SMF Loader
- **[smf_loader/README.md](smf_loader/README.md)** - Loader usage and examples
- **[smf_loader/ARCHITECTURE.md](smf_loader/ARCHITECTURE.md)** - Detailed design documentation
- **[smf_loader/QUICK_START.md](smf_loader/QUICK_START.md)** - Quick start guide

#### SMF Query Engine
- **[smf_queries/README.md](smf_queries/README.md)** - Query engine documentation
- **[smf_queries/SMF_QUERY_ENGINE_SUMMARY.md](smf_queries/SMF_QUERY_ENGINE_SUMMARY.md)** - Implementation summary
- **[smf_queries/EXPORT_FORMATS_SUMMARY.md](smf_queries/EXPORT_FORMATS_SUMMARY.md)** - Export formats guide

#### Legacy Analyzer - Comprehensive Migration Analysis
- **[docs/GETTING_STARTED.md](docs/GETTING_STARTED.md)** - Quick start guide
- **[docs/INVENTORY_GUIDE.md](docs/INVENTORY_GUIDE.md)** - Inventory management and CSV formats
- **[docs/STATIC_ANALYSIS_GUIDE.md](docs/STATIC_ANALYSIS_GUIDE.md)** - Static code analysis for dependencies
- **[docs/LANGUAGE_DETECTION_GUIDE.md](docs/LANGUAGE_DETECTION_GUIDE.md)** - Intelligent language detection from file content
- **[MULTI_LANGUAGE_ANALYSIS_GUIDE.md](MULTI_LANGUAGE_ANALYSIS_GUIDE.md)** - Analyze multiple languages in one pass
- **[docs/FLOW_ANALYSIS_GUIDE.md](docs/FLOW_ANALYSIS_GUIDE.md)** - Program flow analysis and call graphs
- **[docs/COMPLEXITY_GUIDE.md](docs/COMPLEXITY_GUIDE.md)** - Complexity assessment and metrics
- **[docs/MIGRATION_PACKAGES_GUIDE.md](docs/MIGRATION_PACKAGES_GUIDE.md)** - Migration package planning
- **[docs/MIGRATION_WORKFLOW_GUIDE.md](docs/MIGRATION_WORKFLOW_GUIDE.md)** - Complete migration workflow
- **[docs/QUERY_REFERENCE.md](docs/QUERY_REFERENCE.md)** - Complete query reference
- **[docs/RISK_ASSESSMENT_GUIDE.md](docs/RISK_ASSESSMENT_GUIDE.md)** - Risk classification and assessment
- **[docs/CLEANUP_WORKFLOW.md](docs/CLEANUP_WORKFLOW.md)** - Complete cleanup workflow guide
- **[docs/API_REFERENCE.md](docs/API_REFERENCE.md)** - Python API documentation
- **[docs/CLI_REFERENCE.md](docs/CLI_REFERENCE.md)** - Command-line interface reference

### Configuration
- **[config/artifact_analysis.yaml](config/artifact_analysis.yaml)** - Risk patterns and analysis settings

### Reference
- **[legacy/README.md](legacy/README.md)** - Information about deprecated code
- **[MULTI_RECORD_FILE_PARSER.md](MULTI_RECORD_FILE_PARSER.md)** - Legacy documentation (see CLI_README instead)

## Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov

# Run specific component
pytest tests/test_parser.py
```

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

[Add your license information here]

## References

- IBM z/OS V3R2 SMF Documentation
- IBM System Management Facilities (SMF) Reference

## Support

For issues or questions:
1. Check component-specific README files
2. Review examples in `examples/` directories
3. Examine source code (well-commented)
4. Open an issue on GitHub
