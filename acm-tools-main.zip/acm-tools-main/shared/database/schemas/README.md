# Database Schemas Module

## Overview

The `shared/database/schemas/` module provides centralized database schema definitions for mainframe analysis tools. This module serves as a shared resource for:

- **smf_loader**: Loading SMF records and inventory data into databases
- **legacy_analyzer**: Analyzing mainframe artifacts and dependencies
- **smf_queries**: Querying loaded SMF and inventory data

## Architecture

```
shared/database/schemas/
├── __init__.py              # Main module exports
├── inventory_schema.py      # Mainframe artifact inventory tables
├── smf_schemas.py          # SMF record type schemas (30, 110, etc.)
├── unified_schema.py       # Combined schema for all record types
├── registry.py             # Schema registry for dynamic schema management
└── README.md               # This file
```

## Schema Types

### 1. Inventory Schema

The `InventorySchema` defines tables for storing mainframe artifact catalogs:

- **inventory_jcl**: JCL members and job definitions
- **inventory_programs**: Compiled programs and load modules
- **inventory_copybooks**: COBOL copybooks and include files
- **inventory_datasets**: MVS datasets and VSAM files
- **inventory_cics**: CICS resources (transactions, programs, files, mapsets)

The `inventory` table serves as the authoritative source for artifact metadata, including programming language information.

### 2. SMF Schemas

SMF (System Management Facilities) record type schemas define tables for storing parsed SMF data:

- **SMF30Schema**: Job/Step Accounting records
- **SMF110Schema**: CICS Transaction Server statistics
- **SMF14Schema**: INPUT dataset activity
- **SMF15Schema**: OUTPUT dataset activity
- **SMF17Schema**: Dataset scratch/deletion
- **SMF62Schema**: VSAM statistics
- **SMF64Schema**: VSAM component statistics

### 3. Unified Schema

The `UnifiedSMFSchema` combines all SMF record types into a single schema with a unified `smf_records` table.

### 4. Schema Registry

The `SchemaRegistry` provides dynamic schema management for registering and retrieving schemas by record type.

## Usage Examples

### Loading Inventory Data

```python
from shared.database.schemas import InventorySchema
from smf_loader import SMFLoader
from smf_loader.databases import SQLiteAdapter

# Create loader with inventory schema
schema = InventorySchema()
db = SQLiteAdapter('analysis.db')
loader = SMFLoader(db, schema)

# Tables are created automatically
loader.create_tables()
```

### Loading SMF Data

```python
from shared.database.schemas import SMF30Schema
from smf_loader import SMFLoader
from smf_loader.databases import SQLiteAdapter

# Create loader with SMF30 schema
schema = SMF30Schema()
db = SQLiteAdapter('smf_data.db')
loader = SMFLoader(db, schema)

# Load SMF records
loader.load_file('smf30_records.json')
```

## Migration from database_schemas

This module was moved from `database_schemas/` as part of the project reorganization. The original schemas remain in `smf_loader/schemas/` for backward compatibility, but new code should import from `shared/database/schemas/`.

### Migration Guide

**Before (old imports):**
```python
from database_schemas import SMF30Schema, InventorySchema
from smf_loader.schemas.inventory_schema import InventorySchema
```

**After (new imports):**
```python
from shared.database.schemas import SMF30Schema, InventorySchema
```

### Backward Compatibility

All existing imports continue to work. The schemas in `smf_loader/schemas/` are maintained for backward compatibility, and `shared/database/schemas/` re-exports them with additional enhancements.