"""
Consolidated SMF record type schemas.

This module provides placeholder SMF schema classes for the shared infrastructure.
During the reorganization phase, this provides basic functionality until the full
smf_loader integration is completed.
"""

from typing import Dict, Any, List


class SMF30Schema:
    """Placeholder SMF Type 30 schema for shared infrastructure."""
    
    @property
    def record_type(self) -> int:
        return 30
    
    @property
    def record_name(self) -> str:
        return "Job/Step Accounting"

class SMF110Schema:
    """Placeholder SMF Type 110 schema for shared infrastructure."""
    
    @property
    def record_type(self) -> int:
        return 110
    
    @property
    def record_name(self) -> str:
        return "CICS Transaction Server"

# Additional placeholder schemas
class SMF1Schema:
    @property
    def record_type(self) -> int:
        return 1
    
    @property
    def record_name(self) -> str:
        return "System Configuration"

class SMF4Schema:
    @property
    def record_type(self) -> int:
        return 4
    
    @property
    def record_name(self) -> str:
        return "Step Termination"

class SMF5Schema:
    @property
    def record_type(self) -> int:
        return 5
    
    @property
    def record_name(self) -> str:
        return "Job Termination"

class SMF6Schema:
    @property
    def record_type(self) -> int:
        return 6
    
    @property
    def record_name(self) -> str:
        return "Print/Punch Dataset"

class SMF7Schema:
    @property
    def record_type(self) -> int:
        return 7
    
    @property
    def record_name(self) -> str:
        return "Data Set Open/Close/EOV"

class SMF8Schema:
    @property
    def record_type(self) -> int:
        return 8
    
    @property
    def record_name(self) -> str:
        return "Data Set Activity"

class SMF9Schema:
    @property
    def record_type(self) -> int:
        return 9
    
    @property
    def record_name(self) -> str:
        return "DASD Volume Activity"

class SMF10Schema:
    @property
    def record_type(self) -> int:
        return 10
    
    @property
    def record_name(self) -> str:
        return "VSAM Activity"

class SMF11Schema:
    @property
    def record_type(self) -> int:
        return 11
    
    @property
    def record_name(self) -> str:
        return "VSAM Buffer Pool Activity"

class SMF14Schema:
    @property
    def record_type(self) -> int:
        return 14
    
    @property
    def record_name(self) -> str:
        return "INPUT Dataset Activity"

class SMF15Schema:
    @property
    def record_type(self) -> int:
        return 15
    
    @property
    def record_name(self) -> str:
        return "OUTPUT Dataset Activity"

class SMF16Schema:
    @property
    def record_type(self) -> int:
        return 16
    
    @property
    def record_name(self) -> str:
        return "DFSORT Statistics"

class SMF17Schema:
    @property
    def record_type(self) -> int:
        return 17
    
    @property
    def record_name(self) -> str:
        return "Dataset Scratch/Deletion"

class SMF18Schema:
    @property
    def record_type(self) -> int:
        return 18
    
    @property
    def record_name(self) -> str:
        return "Rename Dataset Activity"

class SMF19Schema:
    @property
    def record_type(self) -> int:
        return 19
    
    @property
    def record_name(self) -> str:
        return "Volume Mount/Dismount"

class SMF52Schema:
    @property
    def record_type(self) -> int:
        return 52
    
    @property
    def record_name(self) -> str:
        return "RACF Processing"


class SMF100Schema:
    """Schema for SMF Type 100 - DB2 Statistics records."""
    
    @property
    def record_type(self) -> int:
        return 100
    
    @property
    def record_name(self) -> str:
        return "DB2 Statistics"
    
    def get_table_definitions(self) -> Dict[str, Dict[str, Any]]:
        """Return table definitions for SMF Type 100 records."""
        return {
            'smf_records': {
                'columns': [
                    {'name': 'record_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'system_id', 'type': 'TEXT', 'nullable': False},
                    {'name': 'subsystem_id', 'type': 'TEXT'},
                    {'name': 'db2_version', 'type': 'TEXT'},
                    {'name': 'record_date', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_time', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_timestamp', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_length', 'type': 'INTEGER'},
                    {'name': 'ifcid', 'type': 'INTEGER'},
                    {'name': 'subsystem_name', 'type': 'TEXT'},
                    {'name': 'release_number', 'type': 'INTEGER'},
                    {'name': 'created_at', 'type': 'TIMESTAMP', 'default': 'CURRENT_TIMESTAMP'},
                ],
                'indexes': [
                    {'columns': ['record_date']},
                    {'columns': ['system_id']},
                    {'columns': ['ifcid']},
                    {'columns': ['subsystem_name']},
                ],
                'foreign_keys': []
            },
            'smf100_statistics': {
                'columns': [
                    {'name': 'stat_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'product_section_offset', 'type': 'INTEGER'},
                    {'name': 'product_section_length', 'type': 'INTEGER'},
                    {'name': 'product_section_count', 'type': 'INTEGER'},
                    {'name': 'has_correlation_header', 'type': 'INTEGER'},
                    {'name': 'has_trace_header', 'type': 'INTEGER'},
                    {'name': 'has_cpu_header', 'type': 'INTEGER'},
                    {'name': 'has_distributed_header', 'type': 'INTEGER'},
                    {'name': 'has_data_sharing_header', 'type': 'INTEGER'},
                    {'name': 'self_defining_section_offset', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            },
            'smf100_sql_statistics': {
                'columns': [
                    {'name': 'sql_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'select_count', 'type': 'INTEGER'},
                    {'name': 'insert_count', 'type': 'INTEGER'},
                    {'name': 'update_count', 'type': 'INTEGER'},
                    {'name': 'delete_count', 'type': 'INTEGER'},
                    {'name': 'describe_count', 'type': 'INTEGER'},
                    {'name': 'prepare_count', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            },
            'smf100_buffer_pool': {
                'columns': [
                    {'name': 'buffer_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'buffer_pool_id', 'type': 'INTEGER'},
                    {'name': 'getpage_requests', 'type': 'INTEGER'},
                    {'name': 'sync_read_io', 'type': 'INTEGER'},
                    {'name': 'sync_write_io', 'type': 'INTEGER'},
                    {'name': 'sequential_prefetch', 'type': 'INTEGER'},
                    {'name': 'list_prefetch', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                    {'columns': ['buffer_pool_id']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            },
            'smf100_latch_statistics': {
                'columns': [
                    {'name': 'latch_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'latch_type', 'type': 'TEXT'},
                    {'name': 'latch_requests', 'type': 'INTEGER'},
                    {'name': 'latch_suspensions', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                    {'columns': ['latch_type']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            },
            'smf100_ddf_statistics': {
                'columns': [
                    {'name': 'ddf_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'distributed_requests', 'type': 'INTEGER'},
                    {'name': 'remote_requests', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            }
        }
    
    def transform_record(self, json_record: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """Transform JSON record into database rows."""
        result = {}
        
        # Support both 'sections' (old format) and 'header' (new parser format)
        sections = json_record.get('sections') or json_record.get('header', {})
        
        # Extract SMF header section
        smf_header = sections.get('smf_header', {})
        qwhs_header = sections.get('qwhs_header', {})
        
        # Main header record - use 'smf_records' as the primary table for loader compatibility
        result['smf_records'] = [{
            'system_id': json_record.get('system_id', smf_header.get('system_id', 'UNKNOWN')),
            'subsystem_id': smf_header.get('subsystem_id'),
            'db2_version': json_record.get('version'),
            'record_date': json_record.get('date', '1970-01-01'),
            'record_time': json_record.get('timestamp', '00:00:00'),
            'record_timestamp': f"{json_record.get('date', '1970-01-01')} {json_record.get('timestamp', '00:00:00')}",
            'record_length': smf_header.get('record_length'),
            'ifcid': qwhs_header.get('ifcid'),
            'subsystem_name': qwhs_header.get('subsystem_name'),
            'release_number': qwhs_header.get('release_number'),
        }]
        
        # Statistics section
        product_section = sections.get('product_section', {})
        
        result['smf100_statistics'] = [{
            'record_id': None,  # Will be set by loader
            'product_section_offset': product_section.get('offset'),
            'product_section_length': product_section.get('length'),
            'product_section_count': product_section.get('count'),
            'has_correlation_header': 1 if 'correlation_header' in sections else 0,
            'has_trace_header': 1 if 'trace_header' in sections else 0,
            'has_cpu_header': 1 if 'cpu_header' in sections else 0,
            'has_distributed_header': 1 if 'distributed_header' in sections else 0,
            'has_data_sharing_header': 1 if 'data_sharing_header' in sections else 0,
            'self_defining_section_offset': sections.get('self_defining_section', {}).get('offset'),
        }]
        
        # Extract data sections
        data_sections = sections.get('data_sections', {})
        
        # Extract SQL statistics from QXST section (IFCID 2)
        qxst_data = data_sections.get('qxst', {})
        if qxst_data and not qxst_data.get('error'):
            result['smf100_sql_statistics'] = [{
                'record_id': None,  # Will be set by loader
                'select_count': qxst_data.get('select_count'),
                'insert_count': qxst_data.get('insert_count'),
                'update_count': qxst_data.get('update_count'),
                'delete_count': qxst_data.get('delete_count'),
                'describe_count': qxst_data.get('describe_count'),
                'prepare_count': qxst_data.get('prepare_count'),
            }]
        else:
            result['smf100_sql_statistics'] = []
        
        # Extract buffer pool statistics from QBST section (IFCID 2)
        qbst_data = data_sections.get('qbst', {})
        if qbst_data and not qbst_data.get('error'):
            result['smf100_buffer_pool'] = [{
                'record_id': None,  # Will be set by loader
                'buffer_pool_id': qbst_data.get('buffer_pool_id'),
                'getpage_requests': qbst_data.get('getpage_requests'),
                'sync_read_io': qbst_data.get('sync_read_io'),
                'sync_write_io': qbst_data.get('async_write_io'),  # Using async_write_io as sync_write_io
                'sequential_prefetch': qbst_data.get('seq_prefetch_requests'),
                'list_prefetch': qbst_data.get('list_prefetch_requests'),
            }]
        else:
            result['smf100_buffer_pool'] = []
        
        # Extract latch statistics from QVLS section (IFCID 1)
        qvls_data = data_sections.get('qvls', {})
        if qvls_data and not qvls_data.get('error'):
            latch_classes = qvls_data.get('latch_classes', {})
            latch_rows = []
            for latch_type, suspensions in latch_classes.items():
                if suspensions > 0:  # Only store non-zero latch statistics
                    latch_rows.append({
                        'record_id': None,  # Will be set by loader
                        'latch_type': latch_type,
                        'latch_requests': None,  # Not available in QVLS
                        'latch_suspensions': suspensions,
                    })
            result['smf100_latch_statistics'] = latch_rows
        else:
            result['smf100_latch_statistics'] = []
        
        # Extract DDF statistics from QLST section (IFCID 1)
        qlst_data = data_sections.get('qlst', {})
        if qlst_data and not qlst_data.get('error') and qlst_data.get('type') == 'varying_length_group':
            # Aggregate DDF statistics from all members
            total_distributed = 0
            total_remote = 0
            members = qlst_data.get('members', [])
            for member in members:
                total_distributed += member.get('conversations_started', 0)
                total_remote += member.get('sql_statements_received', 0)
            
            if total_distributed > 0 or total_remote > 0:
                result['smf100_ddf_statistics'] = [{
                    'record_id': None,  # Will be set by loader
                    'distributed_requests': total_distributed,
                    'remote_requests': total_remote,
                }]
            else:
                result['smf100_ddf_statistics'] = []
        else:
            result['smf100_ddf_statistics'] = []
        
        return result
    
    def validate_record(self, json_record: Dict[str, Any]) -> bool:
        """Validate that a JSON record matches this schema's record type."""
        return json_record.get('record_type') == self.record_type


class SMF101Schema:
    """Schema for SMF Type 101 - DB2 Accounting records."""
    
    @property
    def record_type(self) -> int:
        return 101
    
    @property
    def record_name(self) -> str:
        return "DB2 Accounting"
    
    def get_table_definitions(self) -> Dict[str, Dict[str, Any]]:
        """Return table definitions for SMF Type 101 records."""
        return {
            'smf_records': {
                'columns': [
                    {'name': 'record_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'system_id', 'type': 'TEXT', 'nullable': False},
                    {'name': 'subsystem_id', 'type': 'TEXT'},
                    {'name': 'db2_version', 'type': 'TEXT'},
                    {'name': 'record_date', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_time', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_timestamp', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_length', 'type': 'INTEGER'},
                    {'name': 'ifcid', 'type': 'INTEGER'},
                    {'name': 'subsystem_name', 'type': 'TEXT'},
                    {'name': 'release_number', 'type': 'INTEGER'},
                    {'name': 'created_at', 'type': 'TIMESTAMP', 'default': 'CURRENT_TIMESTAMP'},
                ],
                'indexes': [
                    {'columns': ['record_date']},
                    {'columns': ['system_id']},
                    {'columns': ['ifcid']},
                    {'columns': ['subsystem_name']},
                ],
                'foreign_keys': []
            },
            'smf101_accounting': {
                'columns': [
                    {'name': 'acct_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    # Timing fields - using TEXT for store_clock as values exceed SQLite INTEGER max
                    {'name': 'begin_store_clock', 'type': 'TEXT'},
                    {'name': 'end_store_clock', 'type': 'TEXT'},
                    {'name': 'begin_cpu_time', 'type': 'INTEGER'},
                    {'name': 'end_cpu_time', 'type': 'INTEGER'},
                    {'name': 'accumulated_cpu_in_db2', 'type': 'INTEGER'},
                    {'name': 'accumulated_elapsed_in_db2', 'type': 'INTEGER'},
                    # Wait times
                    {'name': 'accumulated_wait_io', 'type': 'INTEGER'},
                    {'name': 'accumulated_wait_lock', 'type': 'INTEGER'},
                    # Transaction counts
                    {'name': 'commit_count', 'type': 'INTEGER'},
                    {'name': 'abort_count', 'type': 'INTEGER'},
                    {'name': 'db2_entry_exit_count', 'type': 'INTEGER'},
                    # Flags and indicators
                    {'name': 'is_rollup', 'type': 'INTEGER'},  # Boolean: 0 or 1
                    {'name': 'class2_active', 'type': 'INTEGER'},  # Boolean: 0 or 1
                    {'name': 'class3_active', 'type': 'INTEGER'},  # Boolean: 0 or 1
                    {'name': 'package_count', 'type': 'INTEGER'},
                    {'name': 'reason_invoked', 'type': 'INTEGER'},
                    {'name': 'flags', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                    {'columns': ['is_rollup']},
                    {'columns': ['class2_active']},
                    {'columns': ['class3_active']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            },
            'smf101_sql_statistics': {
                'columns': [
                    {'name': 'sql_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'select_count', 'type': 'INTEGER'},
                    {'name': 'insert_count', 'type': 'INTEGER'},
                    {'name': 'update_count', 'type': 'INTEGER'},
                    {'name': 'delete_count', 'type': 'INTEGER'},
                    {'name': 'describe_count', 'type': 'INTEGER'},
                    {'name': 'prepare_count', 'type': 'INTEGER'},
                    {'name': 'open_count', 'type': 'INTEGER'},
                    {'name': 'close_count', 'type': 'INTEGER'},
                    {'name': 'fetch_count', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            },
            'smf101_buffer_manager': {
                'columns': [
                    {'name': 'buffer_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'buffer_pool_id', 'type': 'INTEGER'},
                    {'name': 'getpage_requests', 'type': 'INTEGER'},
                    {'name': 'sync_read_io', 'type': 'INTEGER'},
                    {'name': 'seq_prefetch_requests', 'type': 'INTEGER'},
                    {'name': 'list_prefetch_requests', 'type': 'INTEGER'},
                    {'name': 'dynamic_prefetch_requests', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                    {'columns': ['buffer_pool_id']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            },
            'smf101_correlation': {
                'columns': [
                    {'name': 'corr_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'authorization_id', 'type': 'TEXT'},
                    {'name': 'correlation_id', 'type': 'TEXT'},
                    {'name': 'connection_name', 'type': 'TEXT'},
                    {'name': 'plan_name', 'type': 'TEXT'},
                    {'name': 'connection_type', 'type': 'INTEGER'},
                ],
                'indexes': [
                    {'columns': ['record_id']},
                    {'columns': ['authorization_id']},
                    {'columns': ['plan_name']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            }
        }
    
    def transform_record(self, json_record: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """Transform JSON record into database rows."""
        result = {}
        
        # Support both 'sections' (old format) and 'header' (new parser format)
        sections = json_record.get('sections') or json_record.get('header', {})
        
        # Extract SMF header section
        smf_header = sections.get('smf_header', {})
        qwhs_header = sections.get('qwhs_header', {})
        
        # Main header record - use 'smf_records' as the primary table for loader compatibility
        result['smf_records'] = [{
            'system_id': json_record.get('system_id', smf_header.get('system_id', 'UNKNOWN')),
            'subsystem_id': smf_header.get('subsystem_id'),
            'db2_version': json_record.get('version'),
            'record_date': json_record.get('date', '1970-01-01'),
            'record_time': json_record.get('timestamp', '00:00:00'),
            'record_timestamp': f"{json_record.get('date', '1970-01-01')} {json_record.get('timestamp', '00:00:00')}",
            'record_length': smf_header.get('record_length'),
            'ifcid': qwhs_header.get('ifcid'),
            'subsystem_name': qwhs_header.get('subsystem_name'),
            'release_number': qwhs_header.get('release_number'),
        }]
        
        # Extract data sections
        data_sections = sections.get('data_sections', {})
        optional_headers = sections.get('optional_headers', {})
        
        # Accounting section - extract QWAC data
        qwac_data = data_sections.get('qwac', {})
        if qwac_data and not qwac_data.get('error'):
            result['smf101_accounting'] = [{
                'record_id': None,  # Will be set by loader
                'begin_store_clock': str(qwac_data.get('begin_store_clock')) if qwac_data.get('begin_store_clock') else None,
                'end_store_clock': str(qwac_data.get('end_store_clock')) if qwac_data.get('end_store_clock') else None,
                'begin_cpu_time': qwac_data.get('begin_cpu_time'),
                'end_cpu_time': qwac_data.get('end_cpu_time'),
                'accumulated_cpu_in_db2': qwac_data.get('accumulated_cpu_in_db2'),
                'accumulated_elapsed_in_db2': qwac_data.get('accumulated_elapsed_in_db2'),
                'accumulated_wait_io': qwac_data.get('accumulated_wait_io'),
                'accumulated_wait_lock': qwac_data.get('accumulated_wait_lock'),
                'commit_count': qwac_data.get('commit_count'),
                'abort_count': qwac_data.get('abort_count'),
                'db2_entry_exit_count': qwac_data.get('db2_entry_exit_count'),
                'is_rollup': 1 if qwac_data.get('is_rollup') else 0,
                'class2_active': 1 if qwac_data.get('class2_active') else 0,
                'class3_active': 1 if qwac_data.get('class3_active') else 0,
                'package_count': qwac_data.get('package_count'),
                'reason_invoked': qwac_data.get('reason_invoked'),
                'flags': qwac_data.get('flags'),
            }]
        else:
            result['smf101_accounting'] = []
        
        # SQL statistics section - extract QXST data
        qxst_data = data_sections.get('qxst', {})
        if qxst_data and not qxst_data.get('error'):
            result['smf101_sql_statistics'] = [{
                'record_id': None,  # Will be set by loader
                'select_count': qxst_data.get('select_count'),
                'insert_count': qxst_data.get('insert_count'),
                'update_count': qxst_data.get('update_count'),
                'delete_count': qxst_data.get('delete_count'),
                'describe_count': qxst_data.get('describe_count'),
                'prepare_count': qxst_data.get('prepare_count'),
                'open_count': qxst_data.get('open_count'),
                'close_count': qxst_data.get('close_count'),
                'fetch_count': qxst_data.get('fetch_count'),
            }]
        else:
            result['smf101_sql_statistics'] = []
        
        # Buffer manager section - extract QBAC data
        qbac_data = data_sections.get('qbac', {})
        if qbac_data and not qbac_data.get('error'):
            result['smf101_buffer_manager'] = [{
                'record_id': None,  # Will be set by loader
                'buffer_pool_id': qbac_data.get('buffer_pool_id'),
                'getpage_requests': qbac_data.get('getpage_requests'),
                'sync_read_io': qbac_data.get('sync_read_io'),
                'seq_prefetch_requests': qbac_data.get('seq_prefetch_requests'),
                'list_prefetch_requests': qbac_data.get('list_prefetch_requests'),
                'dynamic_prefetch_requests': qbac_data.get('dynamic_prefetch_requests'),
            }]
        else:
            result['smf101_buffer_manager'] = []
        
        # Correlation section - extract from optional headers
        correlation_header = optional_headers.get('correlation', {})
        if correlation_header:
            result['smf101_correlation'] = [{
                'record_id': None,  # Will be set by loader
                'authorization_id': correlation_header.get('authorization_id'),
                'correlation_id': correlation_header.get('correlation_id'),
                'connection_name': correlation_header.get('connection_name'),
                'plan_name': correlation_header.get('plan_name'),
                'connection_type': correlation_header.get('connection_type'),
            }]
        else:
            result['smf101_correlation'] = []
        
        return result
    
    def validate_record(self, json_record: Dict[str, Any]) -> bool:
        """Validate that a JSON record matches this schema's record type."""
        return json_record.get('record_type') == self.record_type


class SMF102Schema:
    """Schema for SMF Type 102 - DB2 Performance records."""
    
    @property
    def record_type(self) -> int:
        return 102
    
    @property
    def record_name(self) -> str:
        return "DB2 Performance"
    
    def get_table_definitions(self) -> Dict[str, Dict[str, Any]]:
        """Return table definitions for SMF Type 102 records."""
        return {
            'smf_records': {
                'columns': [
                    {'name': 'record_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'system_id', 'type': 'TEXT', 'nullable': False},
                    {'name': 'subsystem_id', 'type': 'TEXT'},
                    {'name': 'db2_version', 'type': 'TEXT'},
                    {'name': 'record_date', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_time', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_timestamp', 'type': 'TEXT', 'nullable': False},
                    {'name': 'record_length', 'type': 'INTEGER'},
                    {'name': 'ifcid', 'type': 'INTEGER'},
                    {'name': 'subsystem_name', 'type': 'TEXT'},
                    {'name': 'release_number', 'type': 'INTEGER'},
                    {'name': 'created_at', 'type': 'TIMESTAMP', 'default': 'CURRENT_TIMESTAMP'},
                ],
                'indexes': [
                    {'columns': ['record_date']},
                    {'columns': ['system_id']},
                    {'columns': ['ifcid']},
                    {'columns': ['subsystem_name']},
                ],
                'foreign_keys': []
            },
            'smf102_performance': {
                'columns': [
                    {'name': 'perf_id', 'type': 'INTEGER', 'primary_key': True, 'autoincrement': True},
                    {'name': 'record_id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'product_section_offset', 'type': 'INTEGER'},
                    {'name': 'product_section_length', 'type': 'INTEGER'},
                    {'name': 'product_section_count', 'type': 'INTEGER'},
                    {'name': 'has_correlation_header', 'type': 'INTEGER'},
                    {'name': 'has_trace_header', 'type': 'INTEGER'},
                    {'name': 'has_cpu_header', 'type': 'INTEGER'},
                    {'name': 'has_distributed_header', 'type': 'INTEGER'},
                    {'name': 'has_data_sharing_header', 'type': 'INTEGER'},
                    {'name': 'self_defining_section_offset', 'type': 'INTEGER'},
                    {'name': 'data_sections_json', 'type': 'TEXT'},  # JSON blob for data sections
                ],
                'indexes': [
                    {'columns': ['record_id']},
                ],
                'foreign_keys': [
                    {'column': 'record_id', 'references': 'smf_records(record_id)'}
                ]
            }
        }
    
    def transform_record(self, json_record: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """Transform JSON record into database rows."""
        import json as json_lib
        
        result = {}
        
        # Support both 'sections' (old format) and 'header' (new parser format)
        sections = json_record.get('sections') or json_record.get('header', {})
        
        # Extract SMF header section
        smf_header = sections.get('smf_header', {})
        qwhs_header = sections.get('qwhs_header', {})
        
        # Main header record - use 'smf_records' as the primary table for loader compatibility
        result['smf_records'] = [{
            'system_id': json_record.get('system_id', smf_header.get('system_id', 'UNKNOWN')),
            'subsystem_id': smf_header.get('subsystem_id'),
            'db2_version': json_record.get('version'),
            'record_date': json_record.get('date', '1970-01-01'),
            'record_time': json_record.get('timestamp', '00:00:00'),
            'record_timestamp': f"{json_record.get('date', '1970-01-01')} {json_record.get('timestamp', '00:00:00')}",
            'record_length': smf_header.get('record_length'),
            'ifcid': qwhs_header.get('ifcid'),
            'subsystem_name': qwhs_header.get('subsystem_name'),
            'release_number': qwhs_header.get('release_number'),
        }]
        
        # Performance section
        product_section = sections.get('product_section', {})
        
        # Serialize all data sections as JSON for flexible storage
        data_sections = {k: v for k, v in sections.items() 
                        if k not in ['smf_header', 'qwhs_header', 'product_section']}
        
        result['smf102_performance'] = [{
            'record_id': None,  # Will be set by loader
            'product_section_offset': product_section.get('offset'),
            'product_section_length': product_section.get('length'),
            'product_section_count': product_section.get('count'),
            'has_correlation_header': 1 if 'correlation_header' in sections else 0,
            'has_trace_header': 1 if 'trace_header' in sections else 0,
            'has_cpu_header': 1 if 'cpu_header' in sections else 0,
            'has_distributed_header': 1 if 'distributed_header' in sections else 0,
            'has_data_sharing_header': 1 if 'data_sharing_header' in sections else 0,
            'self_defining_section_offset': sections.get('self_defining_section', {}).get('offset'),
            'data_sections_json': json_lib.dumps(data_sections) if data_sections else None,
        }]
        
        return result
    
    def validate_record(self, json_record: Dict[str, Any]) -> bool:
        """Validate that a JSON record matches this schema's record type."""
        return json_record.get('record_type') == self.record_type


class UnifiedSMFSchema:
    """Unified schema for all SMF record types."""
    
    @property
    def record_name(self) -> str:
        return "Unified SMF Records"

class SchemaRegistry:
    """Registry for managing SMF schemas."""
    
    def __init__(self):
        self.schemas = {}
    
    def register(self, record_type: int, schema_class):
        self.schemas[record_type] = schema_class
    
    def get_schema(self, record_type: int):
        return self.schemas.get(record_type)

# Minimal set for testing
__all__ = [
    'SMF1Schema',
    'SMF4Schema',
    'SMF5Schema',
    'SMF6Schema',
    'SMF7Schema',
    'SMF8Schema',
    'SMF9Schema',
    'SMF10Schema',
    'SMF11Schema',
    'SMF14Schema',
    'SMF15Schema',
    'SMF16Schema',
    'SMF17Schema',
    'SMF18Schema',
    'SMF19Schema',
    'SMF30Schema',
    'SMF52Schema',
    'SMF100Schema',
    'SMF101Schema',
    'SMF102Schema',
    'SMF110Schema',
    'UnifiedSMFSchema',
    'SchemaRegistry',
]