# Legacy Analyzer Documentation

This directory contains comprehensive documentation for the Legacy Analyzer component of the SMF Toolkit.

## Overview

The Legacy Analyzer provides static code analysis for mainframe languages including dependency extraction, flow analysis, complexity metrics, and migration package planning. It supports COBOL, PL/I, JCL, REXX, Natural, RPG, and Assembler languages.

## Documentation Structure

### Core Features
- **[Language Detection](language_detection.md)** - Intelligent language detection and multi-language analysis
- **[Parsers](parsers/README.md)** - Language-specific parsers for dependency extraction
- **[Inventory Management](INVENTORY_MANAGEMENT.md)** - Artifact catalog and lifecycle analysis
- **[CSV Export Process](CSV_EXPORT_PROCESS.md)** - Complete guide to mainframe inventory export and CSV generation
- **[Reports](REPORTS.md)** - Analysis reports and output formats

### Advanced Features
- **[Service Grouping](SERVICE_GROUPING.md)** - Logical grouping of related artifacts
- **[CICS Metadata](CICS_METADATA_GUIDE.md)** - CICS resource analysis and integration
- **[CICS Reports](CICS_REPORTS.md)** - CICS-specific reporting capabilities
- **[Metadata Discovery](METADATA_DISCOVERY.md)** - Automated metadata extraction
- **[Reconciliation](RECONCILIATION.md)** - Data validation and consistency checking

### Data Export and Integration
- **[CSV Export Process](CSV_EXPORT_PROCESS.md)** - End-to-end process for extracting mainframe inventory data

## Quick Start

### Basic Analysis

```python
from smf_loader.databases.sqlite_adapter import SQLiteAdapter
from legacy_analyzer.static_analyzer import StaticCodeAnalyzer

# Initialize
db = SQLiteAdapter('analyzer.db')
db.connect()
analyzer = StaticCodeAnalyzer(db)

# Analyze all languages in a directory
result = analyzer.analyze_directory_multi_language('src/')

# View results
print(f"Processed: {result['files_processed']} files")
for lang, stats in result['by_language'].items():
    print(f"  {lang}: {stats['files']} files, {stats['dependencies']} deps")
```

### Dual-Source Inventory Loading

```python
from smf_loader.databases import SQLiteAdapter
from legacy_analyzer.inventory.inventory_loader import InventoryLoader

# Initialize
db = SQLiteAdapter('analyzer.db')
db.connect()
loader = InventoryLoader(db)

# Create inventory schema
loader.create_inventory_schema()

# Load mainframe catalog metadata from CSV files
# (See CSV Export Process guide for generating these files)
loader.load_inventory('jcl_inventory.csv', 'jcl')           # → inventory_jcl
loader.load_inventory('program_inventory.csv', 'programs')  # → inventory_programs  
loader.load_inventory('cics_inventory.csv', 'cics')         # → inventory_cics

# Source code analysis populates unified inventory automatically
# → inventory table (discovered artifacts from parsing)

db.commit()
```

### Language-Specific Analysis

```python
# Analyze specific language
analyzer.analyze_directory('src/cobol', 'COBOL')
analyzer.analyze_directory('src/jcl', 'JCL')
```

### Flow Analysis

```python
from legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer

# Load dependencies and analyze flows
dependencies = analyzer.load_dependencies()
flow_analyzer = FlowAnalyzer(dependencies)

# Analyze program flow
flow = flow_analyzer.analyze_flow('MAIN-PROGRAM')
print(f"Flow depth: {flow.depth}")
print(f"Programs: {len(flow.programs)}")
```

## Supported Languages

| Language | Parser | Extensions | Features |
|----------|--------|------------|----------|
| COBOL | ✅ | .cbl, .cob, .cpy | Programs, copybooks, CICS calls |
| PL/I | ✅ | .pli, .pl1, .inc | Programs, includes, CICS calls |
| JCL | ✅ | .jcl | Job control, EXEC statements |
| REXX | ✅ | .rexx, .rex | Scripts, procedures |
| Natural | ✅ | .nsp, .nsn, .nsc | Programs, subprograms, copycode |
| RPG | ✅ | .rpg, .rpgle | Programs, procedures |
| Assembler | ✅ | .asm, .s, .mac | Programs, macros, CSECT |

## Key Features

### Dual-Source Architecture
- **CSV Inventory**: Mainframe catalog metadata (CICS, JCL, programs, datasets)
- **Code Analysis**: Source code parsing and artifact discovery
- **Intelligent Integration**: Dependency-aware reconciliation and analysis

### Entry Point Detection
- **ONLINE Entry Points**: CICS transactions from catalog metadata
- **BATCH Entry Points**: JCL job executions from dependency analysis
- **INFERRED Entry Points**: Programs not called by others (code analysis)
- **Priority-based Classification**: ONLINE > BATCH > INFERRED precedence

### Enhanced Reconciliation
- **Dependency-aware Logic**: Distinguishes entry points from subprograms
- **Smart Severity Classification**: WARNING for potential missing entry points, INFO for utilities
- **Cross-validation**: Catalog metadata vs. actual source code comparison

### Intelligent Language Detection
- Content-based language detection for ambiguous extensions
- Handles `.txt`, `.dat`, `.mbr` files correctly
- Confidence scoring and detailed analysis

### Multi-Language Analysis
- Single-pass analysis of mixed-language codebases
- Language breakdown statistics
- Cross-language dependency tracking

### Dependency Analysis
- Program-to-program calls
- Copybook/include relationships
- Dataset references
- CICS resource usage

### Flow Analysis
- Program execution flows (cached in database)
- Call hierarchies
- Circular dependency detection
- Entry point identification

### Complexity Metrics
- Lines of code analysis
- Cyclomatic complexity
- Dependency counts
- Composite scoring

### Migration Support
- Artifact grouping and packaging
- Cross-reference analysis
- Impact assessment
- Migration planning reports

## Architecture

The Legacy Analyzer follows a modular architecture:

```
legacy_analyzer/
├── parsers/           # Language-specific parsers
├── analysis/          # Flow and complexity analysis
├── inventory/         # Artifact catalog management
├── migration/         # Migration planning tools
├── models/           # Data models
├── utils/            # Utilities and helpers
└── docs/             # Documentation (this directory)
```

### Core Components

- **StaticCodeAnalyzer** - Main orchestrator for analysis workflows
- **Language Parsers** - Extract dependencies from source code
- **FlowAnalyzer** - Build program execution flows and call graphs
- **ComplexityAnalyzer** - Calculate complexity metrics
- **InventoryLoader** - Manage artifact catalogs
- **DependencyLoader** - Store and retrieve dependency data

## Database Schema

The analyzer uses a normalized database schema:

- **inventory** - Artifact catalog with metadata
- **artifact_dependencies** - Dependency relationships
- **program_flows** - Analyzed program flows
- **complexity_metrics** - Complexity analysis results
- **inventory_*** - Specialized inventory tables

## Configuration

### Database Configuration

```python
# SQLite (default)
from smf_loader.databases.sqlite_adapter import SQLiteAdapter
db = SQLiteAdapter('analyzer.db')

# PostgreSQL (planned)
# from smf_loader.databases.postgresql_adapter import PostgreSQLAdapter
# db = PostgreSQLAdapter(connection_string)
```

### Analysis Configuration

```python
# Language detection settings
from legacy_analyzer.language_detector import LanguageDetector
detector = LanguageDetector(max_lines_to_scan=200)

# Complexity analysis settings
analyzer.analyze_directory_with_complexity(
    'src/',
    'COBOL',
    save_complexity=True
)
```

## Performance Guidelines

### Optimization Tips

1. **Use appropriate analysis method**:
   - `analyze_directory_multi_language()` for mixed codebases
   - `analyze_directory(dir, lang)` for known languages
   - Single file analysis for targeted analysis

2. **Configure scanning depth**:
   - Reduce `max_lines_to_scan` for faster detection
   - Increase for better accuracy on complex files

3. **Batch processing**:
   - Use directory-level methods for bulk analysis
   - Enable progress indicators for large codebases

4. **Database optimization**:
   - Use appropriate indexes
   - Consider batch inserts for large datasets
   - Regular database maintenance

### Performance Metrics

- Language detection: ~10-50ms per file
- Dependency extraction: ~50-200ms per file
- Flow analysis: ~100ms-1s per program
- Complexity analysis: ~20-100ms per file

## Testing

The analyzer includes comprehensive test coverage:

```bash
# Run all tests
pytest tests/

# Run specific test categories
pytest tests/test_language_detection.py
pytest tests/test_static_analyzer.py
pytest tests/test_flow_analyzer.py
```

## Troubleshooting

### Common Issues

1. **Language not detected**:
   - Check file contains recognizable code patterns
   - Verify file is not binary or corrupted
   - Use explicit language parameter if needed

2. **Dependencies not found**:
   - Verify parser supports the language constructs
   - Check for non-standard syntax or dialects
   - Review parser documentation for limitations

3. **Performance issues**:
   - Reduce scanning depth for language detection
   - Use language-specific analysis for known directories
   - Consider parallel processing for large codebases

4. **Database errors**:
   - Verify database schema is created
   - Check for sufficient disk space
   - Review connection parameters

### Debug Mode

Enable debug logging for detailed analysis:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Run analysis with debug output
result = analyzer.analyze_directory_multi_language('src/')
```

## Contributing

### Adding New Language Support

1. Create parser in `parsers/{language}_parser.py`
2. Inherit from `BaseDependencyParser`
3. Implement required methods
4. Add language patterns to `LanguageDetector`
5. Update documentation and tests

### Extending Analysis

1. Create new analyzer in `analysis/`
2. Follow existing patterns and interfaces
3. Add database schema if needed
4. Include comprehensive tests
5. Update documentation

## Related Documentation

- **[SMF Toolkit Overview](../../README.md)** - Main project documentation
- **[Database Schemas](../../shared/database/schemas/README.md)** - Schema definitions
- **[Configuration Guide](../../config/README.md)** - Configuration options
- **[API Reference](../../docs/API_REFERENCE.md)** - Complete API documentation

## Support

For questions, issues, or contributions:

1. Check existing documentation
2. Review test cases for examples
3. Enable debug logging for troubleshooting
4. Consult the main project documentation

The Legacy Analyzer is designed to be extensible and maintainable. The modular architecture allows for easy addition of new languages, analysis types, and output formats while maintaining backward compatibility.