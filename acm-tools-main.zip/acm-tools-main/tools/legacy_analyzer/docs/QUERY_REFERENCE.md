# Query Reference

## Table of Contents

- [Overview](#overview)
- [Query Configuration](#query-configuration)
- [Query Categories](#query-categories)
- [Configuration Parameters](#configuration-parameters)
- [Risk Classification](#risk-classification)
- [Cleanup Recommendations](#cleanup-recommendations)
- [Export Settings](#export-settings)
- [Integration Options](#integration-options)
- [Use Cases and Patterns](#use-cases-and-patterns)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [See Also](#see-also)

---

## Overview

The Legacy Analyzer query system provides powerful artifact lifecycle analysis capabilities through configurable queries. Unlike traditional SQL queries, these are Python-based analytical queries that combine data from multiple sources (inventory, dependencies, SMF records) to provide actionable insights for migration planning and cleanup.

### What Are Queries?

Queries in the Legacy Analyzer are:
- **Analytical Functions**: Python methods that analyze artifact usage patterns
- **Configurable**: Controlled by `config/queries.yaml` with sensible defaults
- **Multi-Source**: Combine inventory, dependency, and usage data
- **Action-Oriented**: Provide recommendations, not just data

### Key Capabilities

- **Artifact Lifecycle Analysis**: Identify unreferenced and missing artifacts
- **Risk Assessment**: Classify artifacts by removal risk (HIGH/MEDIUM/LOW)
- **Cleanup Planning**: Generate prioritized cleanup recommendations
- **Dependency Analysis**: Understand artifact relationships
- **Migration Planning**: Support flow-based and package-based migration

---

## Query Configuration

All query defaults are configured in `config/queries.yaml`. This file controls:
- Analysis time windows
- Usage thresholds
- Risk classification patterns
- Cleanup prioritization weights
- Export formats
- Integration settings

### Configuration File Location

```
config/queries.yaml
```

### Key Principle: Query-Time Filtering

**IMPORTANT**: Configuration parameters are query-time filters, NOT data loading restrictions.


- **Database**: Should contain ALL available data (complete history)
- **Queries**: Filter this data based on analysis windows and thresholds
- **Flexibility**: Change analysis parameters without reloading data

### Example Configuration Structure

```yaml
# Analysis window defaults
analysis_windows:
  default: 365
  presets:
    recent: 90
    standard: 365
    comprehensive: 730
    extended: 1095

# Usage thresholds
usage_thresholds:
  min_executions: 1
  min_dataset_accesses: 1
  min_copybook_references: 1
  min_missing_executions: 5

# Risk patterns
risk_patterns:
  high_risk:
    - pattern: "DR%"
      description: "Disaster Recovery procedures"
    - pattern: "YEAREND%"
      description: "Year-end processing"
  medium_risk:
    - pattern: "MONTH%"
      description: "Monthly processing"
```

---

## Query Categories

The Legacy Analyzer provides queries in five main categories:

### 1. Unreferenced Artifact Queries

Find artifacts in inventory that are not used within the analysis window.

**Purpose**: Identify potential cleanup candidates

**Queries**:
- Unreferenced JCL
- Unreferenced Programs
- Unreferenced Datasets
- Unreferenced Copybooks
- Unreferenced CICS Transactions

**Use Case**: "Which artifacts can we potentially remove or archive?"

### 2. Missing Artifact Queries

Find artifacts referenced in usage data but not in inventory.

**Purpose**: Identify documentation gaps and shadow IT

**Queries**:
- Missing JCL
- Missing Programs
- Missing Datasets

**Use Case**: "What's running in production that we don't know about?"


### 3. Dependency Queries

Explore relationships between artifacts.

**Purpose**: Understand artifact dependencies for impact analysis

**Queries**:
- Artifact Dependencies (forward and reverse)
- Dependency Tree (recursive)
- Circular Dependencies
- Orphaned Artifacts

**Use Case**: "What will break if we remove this artifact?"

### 4. Risk Assessment Queries

Classify artifacts by removal risk level.

**Purpose**: Prioritize review efforts and prevent critical artifact removal

**Queries**:
- Artifact Risk Assessment
- High-Risk Artifact Report
- Dependency-Based Risk Analysis

**Use Case**: "Which artifacts require careful review before removal?"

### 5. Cleanup Recommendation Queries

Generate prioritized cleanup recommendations.

**Purpose**: Create actionable cleanup plans with priority scoring

**Queries**:
- Cleanup Recommendations (prioritized)
- Archive Candidates
- Space Reclamation Analysis

**Use Case**: "What should we clean up first to maximize benefit?"

---

## Configuration Parameters

### Analysis Windows

Control how far back to look in usage data.

#### Default Window

```yaml
analysis_windows:
  default: 365  # 1 year
```

#### Preset Windows

```yaml
presets:
  recent: 90              # Last 3 months
  standard: 365           # Last year (default)
  comprehensive: 730      # Last 2 years
  extended: 1095          # Last 3 years
```

#### When to Use Each Window

- **Recent (90 days)**: Quick analysis of recent activity
- **Standard (365 days)**: Default for most analyses
- **Comprehensive (730 days)**: Thorough lifecycle analysis
- **Extended (1095 days)**: Critical artifact validation


#### Overriding at Query Time

You can override the default window when running queries:

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Use 2-year window instead of default
unreferenced = api.get_unreferenced_artifacts(
    artifact_type="PROGRAM",
    analysis_days=730  # Override default
)
```

### Usage Thresholds

Control minimum usage counts for filtering results.

#### Threshold Configuration

```yaml
usage_thresholds:
  min_executions: 1              # Minimum job/program executions
  min_dataset_accesses: 1        # Minimum dataset accesses
  min_copybook_references: 1     # Minimum copybook references
  min_missing_executions: 5      # Minimum for missing artifact reporting
  min_program_size_kb: 0         # Minimum program size to report
  min_dataset_size_mb: 0         # Minimum dataset size to report
```

#### Purpose of Thresholds

- **Filter Noise**: Exclude rarely-used artifacts from reports
- **Focus Effort**: Prioritize frequently-used missing artifacts
- **Size-Based Filtering**: Focus on large artifacts for space reclamation

#### Example: High-Frequency Missing Programs

```python
# Find missing programs executed at least 100 times
missing = api.get_missing_artifacts(
    artifact_type="PROGRAM",
    min_executions=100
)
```

### Validation Rules

Configuration values are validated:

```yaml
validation:
  analysis_windows:
    min_days: 1
    max_days: 3650  # 10 years maximum
  
  usage_thresholds:
    min_value: 0
    max_value: 1000
  
  cleanup:
    priority_weights_sum: 100  # Weights must sum to 100
    max_recommendations_limit: 1000
```

---

## Risk Classification

Risk classification helps prioritize review efforts and prevent accidental removal of critical artifacts.

### Risk Levels

#### HIGH Risk

Artifacts that should NOT be removed without extensive review.

**Characteristics**:
- Match critical naming patterns (DR%, YEAREND%, AUDIT%, etc.)
- Required for business continuity or compliance
- Infrequent but essential usage

**Examples**:
- `DRBACKUP1` - Disaster recovery procedure
- `YEAREND2024` - Year-end processing
- `AUDITREPORT` - Compliance reporting
- `SOXCONTROL` - Financial compliance


**Recommended Action**: REVIEW_REQUIRED

#### MEDIUM Risk

Artifacts that require review before removal.

**Characteristics**:
- Match periodic processing patterns (MONTH%, QUARTER%, ANNUAL%)
- Have dependencies from other artifacts
- May be used by external systems

**Examples**:
- `MONTHEND` - Monthly processing
- `QUARTERLY_RPT` - Quarterly reporting
- `INTERFACE_LOAD` - External interface
- Programs with 3+ dependencies

**Recommended Action**: ANALYZE_DEPENDENCIES

#### LOW Risk

Standalone artifacts with no critical patterns.

**Characteristics**:
- No critical naming patterns
- No dependencies from other artifacts
- Long period of inactivity (>2 years)

**Examples**:
- `TESTPROG1` - Old test program
- `TEMPCOPY` - Temporary copybook
- `OLDUTIL` - Unused utility

**Recommended Action**: ARCHIVE_CANDIDATE

### Risk Pattern Configuration

Risk patterns are defined in `config/queries.yaml`:

```yaml
risk_patterns:
  high_risk:
    - pattern: "DR%"
      description: "Disaster Recovery procedures"
      reason: "Critical for business continuity"
    
    - pattern: "YEAREND%"
      description: "Year-end processing"
      reason: "Required for annual financial close"
    
    - pattern: "AUDIT%"
      description: "Audit and compliance"
      reason: "Required for regulatory compliance"
    
    - pattern: "BACKUP%"
      description: "Backup procedures"
      reason: "Critical for data protection"
    
    - pattern: "EMERGENCY%"
      description: "Emergency procedures"
      reason: "Required for incident response"
    
    - pattern: "%CRITICAL%"
      description: "Explicitly marked as critical"
      reason: "Designated as critical by naming convention"
  
  medium_risk:
    - pattern: "MONTH%"
      description: "Monthly processing"
      reason: "Periodic processing - verify schedule"
    
    - pattern: "QUARTER%"
      description: "Quarterly processing"
      reason: "Periodic processing - verify schedule"
    
    - pattern: "ANNUAL%"
      description: "Annual processing"
      reason: "Infrequent but regular processing"
    
    - pattern: "INTERFACE%"
      description: "Interface programs"
      reason: "May be used by external systems"
```

### Customizing Risk Patterns

Add organization-specific patterns:

```yaml
risk_patterns:
  high_risk:
    - pattern: "PAYROLL%"
      description: "Payroll processing"
      reason: "Critical for employee payments"
    
    - pattern: "%PROD%"
      description: "Production artifacts"
      reason: "Active production use"
```


### Using Risk Assessment

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Get risk assessment for all unreferenced artifacts
risk_assessment = api.assess_artifact_risk()

# Filter by risk level
high_risk = [a for a in risk_assessment if a['risk_level'] == 'HIGH']
low_risk = [a for a in risk_assessment if a['risk_level'] == 'LOW']

# Review high-risk artifacts before any action
for artifact in high_risk:
    print(f"{artifact['name']}: {artifact['risk_reason']}")
```

---

## Cleanup Recommendations

Cleanup recommendations provide prioritized, actionable cleanup plans based on multiple factors.

### Priority Scoring

Priority scores are calculated using weighted factors:

```yaml
cleanup:
  priority_weights:
    size_weight: 40           # Weight for artifact size
    age_weight: 30            # Weight for time since last use
    risk_weight: 20           # Weight for risk level
    dependency_weight: 10     # Weight for dependency count
```

**Total must equal 100**

### Priority Score Formula

```
priority_score = 
    (risk_score * risk_weight / 100) +
    (age_score * age_weight / 100) +
    (size_score * size_weight / 100) +
    (dependency_score * dependency_weight / 100)
```

Where:
- **risk_score**: LOW=100, MEDIUM=50, HIGH=0
- **age_score**: Based on days inactive (older = higher)
- **size_score**: Based on artifact size (larger = higher)
- **dependency_score**: Based on dependency count (fewer = higher)

### Age Thresholds

```yaml
age_thresholds:
  very_old: 1095      # 3+ years - highest priority
  old: 730            # 2+ years - high priority
  moderate: 365       # 1+ years - moderate priority
  recent: 180         # 6+ months - low priority
```

### Size Thresholds

```yaml
size_thresholds:
  programs:
    large_kb: 1024    # Programs >= 1MB
    medium_kb: 512    # Programs >= 512KB
    small_kb: 100     # Programs >= 100KB
  
  datasets:
    large_mb: 1000    # Datasets >= 1GB
    medium_mb: 100    # Datasets >= 100MB
    small_mb: 10      # Datasets >= 10MB
```

### Recommendation Actions

Based on priority score and risk level:

- **ARCHIVE_NOW**: Low risk, >2 years inactive, high priority score
- **ARCHIVE_SOON**: Low risk, >1 year inactive, moderate priority score
- **REVIEW_DEPENDENCIES**: Medium risk, check dependencies first
- **MONITOR**: Continue monitoring, not ready for action
- **REVIEW_REQUIRED**: High risk, manual review needed


### Using Cleanup Recommendations

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Get top 50 cleanup recommendations
recommendations = api.get_cleanup_recommendations(top_n=50)

# Group by recommendation action
archive_now = [r for r in recommendations if r['recommendation'] == 'ARCHIVE_NOW']
review_deps = [r for r in recommendations if r['recommendation'] == 'REVIEW_DEPENDENCIES']

# Calculate potential space savings
total_space_mb = sum(r['size_mb'] for r in archive_now)
print(f"Potential space savings: {total_space_mb:.2f} MB")
```

### Customizing Priority Weights

Adjust weights based on your priorities:

```yaml
# Prioritize space reclamation
cleanup:
  priority_weights:
    size_weight: 60      # Emphasize large artifacts
    age_weight: 20
    risk_weight: 15
    dependency_weight: 5

# Prioritize old artifacts
cleanup:
  priority_weights:
    size_weight: 20
    age_weight: 50       # Emphasize age
    risk_weight: 20
    dependency_weight: 10
```

---

## Export Settings

Control how query results are exported.

### Export Formats

```yaml
export:
  default_format: "csv"
  
  csv:
    delimiter: ","
    quote_char: "\""
    include_header: true
    date_format: "%Y-%m-%d"
  
  json:
    indent: 2
    sort_keys: true
    ensure_ascii: false
  
  markdown:
    include_toc: true
    include_summary: true
    table_format: "github"
```

### Using Export Formats

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Export to CSV
api.export_unreferenced_artifacts(
    output_file="unreferenced.csv",
    format="csv"
)

# Export to JSON
api.export_cleanup_recommendations(
    output_file="cleanup_plan.json",
    format="json"
)

# Export to Markdown report
api.export_risk_assessment(
    output_file="risk_report.md",
    format="markdown"
)
```

### Report Content Settings

```yaml
report_content:
  include_executive_summary: true
  include_detailed_analysis: true
  include_recommendations: true
  include_risk_assessment: true
  include_dependency_analysis: true
  include_trend_analysis: false    # Requires historical data
  include_visualizations: false    # Requires additional libraries
```

---

## Integration Options

The Legacy Analyzer can integrate with external systems for workflow management.


### ServiceNow Integration

For change management workflows:

```yaml
integrations:
  servicenow:
    enabled: false
    instance_url: "https://your-instance.service-now.com"
    api_key: ""  # Use environment variable: SERVICENOW_API_KEY
```

**Use Case**: Automatically create change requests for artifact cleanup

### Jira Integration

For tracking cleanup tasks:

```yaml
integrations:
  jira:
    enabled: false
    server_url: "https://your-company.atlassian.net"
    api_token: ""  # Use environment variable: JIRA_API_TOKEN
    project_key: "CLEANUP"
```

**Use Case**: Create Jira tickets for each cleanup recommendation

### Slack Integration

For notifications:

```yaml
integrations:
  slack:
    enabled: false
    webhook_url: ""  # Use environment variable: SLACK_WEBHOOK_URL
    channel: "#mainframe-modernization"
```

**Use Case**: Notify team when high-risk artifacts are found

### Notification Triggers

```yaml
notifications:
  triggers:
    high_risk_artifacts_found: true
    cleanup_recommendations_ready: true
    missing_artifacts_threshold: 10
```

### Email Notifications

```yaml
notifications:
  email:
    enabled: false
    smtp_host: "smtp.example.com"
    smtp_port: 587
    smtp_user: "user@example.com"
    smtp_password: ""  # Use environment variable: SMTP_PASSWORD
    from_address: "artifact-analysis@example.com"
    to_addresses:
      - "analyst@example.com"
      - "manager@example.com"
```

---

## Use Cases and Patterns

### Use Case 1: Comprehensive Cleanup Analysis

**Goal**: Identify all cleanup opportunities across artifact types

**Workflow**:

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Step 1: Get unreferenced artifacts by type
unreferenced_jcl = api.get_unreferenced_artifacts(artifact_type="JCL")
unreferenced_programs = api.get_unreferenced_artifacts(artifact_type="PROGRAM")
unreferenced_datasets = api.get_unreferenced_artifacts(artifact_type="DATASET")
unreferenced_copybooks = api.get_unreferenced_artifacts(artifact_type="COPYBOOK")

# Step 2: Assess risk for all unreferenced artifacts
risk_assessment = api.assess_artifact_risk()

# Step 3: Get prioritized cleanup recommendations
recommendations = api.get_cleanup_recommendations(top_n=100)

# Step 4: Export results
api.export_cleanup_recommendations(
    output_file="cleanup_plan.csv",
    format="csv"
)

# Step 5: Calculate potential savings
total_artifacts = len(recommendations)
total_space_mb = sum(r['size_mb'] for r in recommendations)
print(f"Cleanup candidates: {total_artifacts}")
print(f"Potential space savings: {total_space_mb:.2f} MB")
```


### Use Case 2: Missing Artifact Investigation

**Goal**: Identify and document shadow IT and undocumented artifacts

**Workflow**:

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Step 1: Find missing artifacts (high-frequency only)
missing_jcl = api.get_missing_artifacts(
    artifact_type="JCL",
    min_executions=10
)

missing_programs = api.get_missing_artifacts(
    artifact_type="PROGRAM",
    min_executions=50
)

missing_datasets = api.get_missing_artifacts(
    artifact_type="DATASET",
    min_accesses=100
)

# Step 2: Prioritize by execution frequency
high_priority = [
    a for a in missing_programs 
    if a['execution_count'] > 100
]

# Step 3: Export for documentation
api.export_missing_artifacts(
    output_file="missing_artifacts_report.csv",
    format="csv"
)

# Step 4: Generate action items
for artifact in high_priority:
    print(f"ACTION: Document {artifact['name']} "
          f"(executed {artifact['execution_count']} times)")
```

### Use Case 3: Migration Scope Reduction

**Goal**: Reduce migration scope by excluding unreferenced artifacts

**Workflow**:

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Step 1: Get all artifacts from inventory
all_programs = api.get_inventory_artifacts(artifact_type="PROGRAM")
all_jcl = api.get_inventory_artifacts(artifact_type="JCL")

# Step 2: Get unreferenced artifacts (2-year window)
unreferenced_programs = api.get_unreferenced_artifacts(
    artifact_type="PROGRAM",
    analysis_days=730
)

unreferenced_jcl = api.get_unreferenced_artifacts(
    artifact_type="JCL",
    analysis_days=730
)

# Step 3: Calculate migration scope
total_programs = len(all_programs)
excluded_programs = len(unreferenced_programs)
migration_programs = total_programs - excluded_programs

total_jcl = len(all_jcl)
excluded_jcl = len(unreferenced_jcl)
migration_jcl = total_jcl - excluded_jcl

# Step 4: Report scope reduction
print(f"Programs: {migration_programs}/{total_programs} "
      f"({excluded_programs} excluded)")
print(f"JCL: {migration_jcl}/{total_jcl} "
      f"({excluded_jcl} excluded)")

reduction_pct = (excluded_programs + excluded_jcl) / (total_programs + total_jcl) * 100
print(f"Scope reduction: {reduction_pct:.1f}%")
```

### Use Case 4: Risk-Based Review Process

**Goal**: Prioritize review efforts based on risk level

**Workflow**:

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Step 1: Get risk assessment
risk_assessment = api.assess_artifact_risk()

# Step 2: Group by risk level
high_risk = [a for a in risk_assessment if a['risk_level'] == 'HIGH']
medium_risk = [a for a in risk_assessment if a['risk_level'] == 'MEDIUM']
low_risk = [a for a in risk_assessment if a['risk_level'] == 'LOW']

# Step 3: Create review workflow
print(f"HIGH RISK ({len(high_risk)}): Manual review required")
for artifact in high_risk:
    print(f"  - {artifact['name']}: {artifact['risk_reason']}")

print(f"\nMEDIUM RISK ({len(medium_risk)}): Dependency analysis required")
for artifact in medium_risk[:5]:  # Show first 5
    deps = api.get_artifact_dependencies(artifact['name'])
    print(f"  - {artifact['name']}: {len(deps)} dependencies")

print(f"\nLOW RISK ({len(low_risk)}): Archive candidates")
```


### Use Case 5: Periodic Cleanup Campaigns

**Goal**: Run quarterly cleanup campaigns with consistent criteria

**Workflow**:

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI
from datetime import datetime

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Step 1: Get cleanup recommendations
recommendations = api.get_cleanup_recommendations(top_n=100)

# Step 2: Filter by recommendation action
archive_now = [r for r in recommendations if r['recommendation'] == 'ARCHIVE_NOW']
archive_soon = [r for r in recommendations if r['recommendation'] == 'ARCHIVE_SOON']

# Step 3: Create campaign report
campaign_date = datetime.now().strftime("%Y-Q%q")
report_file = f"cleanup_campaign_{campaign_date}.md"

with open(report_file, 'w') as f:
    f.write(f"# Cleanup Campaign {campaign_date}\n\n")
    f.write(f"## Summary\n\n")
    f.write(f"- Archive Now: {len(archive_now)} artifacts\n")
    f.write(f"- Archive Soon: {len(archive_soon)} artifacts\n")
    f.write(f"- Total: {len(recommendations)} artifacts\n\n")
    
    f.write(f"## Archive Now ({len(archive_now)})\n\n")
    for artifact in archive_now:
        f.write(f"- {artifact['name']} ({artifact['type']}): "
                f"{artifact['size_mb']:.2f} MB, "
                f"{artifact['days_inactive']} days inactive\n")

# Step 4: Track progress over time
# (Store recommendations in tracking database)
```

---

## Best Practices

### 1. Start with Conservative Windows

Begin with longer analysis windows to avoid false positives:

```python
# Start with 2-year window
unreferenced = api.get_unreferenced_artifacts(
    artifact_type="PROGRAM",
    analysis_days=730  # 2 years
)

# Gradually reduce to 1 year after validation
```

### 2. Always Check Dependencies

Before removing any artifact, check dependencies:

```python
# Check what depends on this artifact
dependencies = api.get_artifact_dependencies(
    artifact_name="OLDPROG1",
    direction="reverse"  # What depends on this
)

if len(dependencies) > 0:
    print(f"WARNING: {len(dependencies)} artifacts depend on OLDPROG1")
    for dep in dependencies:
        print(f"  - {dep['source_artifact']}")
```

### 3. Respect Risk Levels

Never bypass high-risk artifact reviews:

```python
recommendations = api.get_cleanup_recommendations(top_n=100)

# Filter out high-risk artifacts
safe_recommendations = [
    r for r in recommendations 
    if r['risk_level'] != 'HIGH'
]

# High-risk artifacts require manual review
high_risk = [
    r for r in recommendations 
    if r['risk_level'] == 'HIGH'
]
print(f"Manual review required for {len(high_risk)} high-risk artifacts")
```

### 4. Document All Actions

Keep audit trail of cleanup decisions:

```python
import json
from datetime import datetime

# Document cleanup decision
cleanup_log = {
    'date': datetime.now().isoformat(),
    'artifact': 'OLDPROG1',
    'action': 'ARCHIVED',
    'reason': 'Unreferenced for 3+ years, low risk',
    'priority_score': 456.78,
    'approved_by': 'analyst@example.com'
}

with open('cleanup_audit.jsonl', 'a') as f:
    f.write(json.dumps(cleanup_log) + '\n')
```


### 5. Validate Configuration Changes

Test configuration changes before production use:

```python
# Test with small dataset first
test_recommendations = api.get_cleanup_recommendations(top_n=10)

# Verify priority scores make sense
for rec in test_recommendations:
    print(f"{rec['name']}: score={rec['priority_score']:.2f}, "
          f"risk={rec['risk_level']}, age={rec['days_inactive']}")

# If results look good, run full analysis
```

### 6. Use Appropriate Analysis Windows

Match window to artifact type and usage pattern:

```python
# Batch programs: 1 year is usually sufficient
batch_programs = api.get_unreferenced_artifacts(
    artifact_type="PROGRAM",
    analysis_days=365
)

# Year-end programs: Need 2+ years
yearend_programs = api.get_unreferenced_artifacts(
    artifact_type="PROGRAM",
    analysis_days=730,
    name_pattern="YEAREND%"
)

# Datasets: Shorter window (6 months) may be appropriate
datasets = api.get_unreferenced_artifacts(
    artifact_type="DATASET",
    analysis_days=180
)
```

### 7. Combine Multiple Data Sources

Use both inventory and usage data:

```python
# Find artifacts that are:
# 1. In inventory (documented)
# 2. Unreferenced (not used)
# 3. Low risk (safe to remove)

unreferenced = api.get_unreferenced_artifacts(artifact_type="PROGRAM")
risk_assessment = api.assess_artifact_risk()

# Create lookup for risk levels
risk_by_name = {r['name']: r['risk_level'] for r in risk_assessment}

# Filter for low-risk unreferenced artifacts
safe_cleanup = [
    u for u in unreferenced
    if risk_by_name.get(u['name']) == 'LOW'
]
```

### 8. Regular Review Cycles

Establish regular review cycles:

- **Monthly**: Review missing artifacts (shadow IT)
- **Quarterly**: Run cleanup campaigns
- **Annually**: Comprehensive lifecycle analysis
- **Ad-hoc**: Before major migrations

### 9. Stakeholder Communication

Share results with appropriate stakeholders:

```python
# Generate executive summary
recommendations = api.get_cleanup_recommendations(top_n=100)

summary = {
    'total_artifacts': len(recommendations),
    'space_savings_mb': sum(r['size_mb'] for r in recommendations),
    'by_risk': {
        'HIGH': len([r for r in recommendations if r['risk_level'] == 'HIGH']),
        'MEDIUM': len([r for r in recommendations if r['risk_level'] == 'MEDIUM']),
        'LOW': len([r for r in recommendations if r['risk_level'] == 'LOW'])
    },
    'by_action': {
        'ARCHIVE_NOW': len([r for r in recommendations if r['recommendation'] == 'ARCHIVE_NOW']),
        'REVIEW_DEPENDENCIES': len([r for r in recommendations if r['recommendation'] == 'REVIEW_DEPENDENCIES'])
    }
}

# Share with management
print(f"Cleanup Opportunity: {summary['total_artifacts']} artifacts")
print(f"Space Savings: {summary['space_savings_mb']:.2f} MB")
```

### 10. Incremental Approach

Start small and build confidence:

1. **Phase 1**: Analyze and report only (no actions)
2. **Phase 2**: Archive low-risk, very old artifacts (>3 years)
3. **Phase 3**: Expand to medium-risk with dependency analysis
4. **Phase 4**: Comprehensive cleanup program

---

## Troubleshooting

### Issue: No Unreferenced Artifacts Found

**Symptoms**: Query returns empty results

**Possible Causes**:
1. Analysis window too short
2. No usage data loaded
3. All artifacts are actively used

**Solutions**:

```python
# Check if usage data exists
api.validate_data_completeness()

# Try longer analysis window
unreferenced = api.get_unreferenced_artifacts(
    artifact_type="PROGRAM",
    analysis_days=1095  # 3 years
)

# Check inventory count
inventory = api.get_inventory_artifacts(artifact_type="PROGRAM")
print(f"Total programs in inventory: {len(inventory)}")
```


### Issue: Too Many Missing Artifacts

**Symptoms**: Hundreds or thousands of missing artifacts reported

**Possible Causes**:
1. Incomplete inventory data
2. Naming convention mismatches
3. Dynamic program names not captured

**Solutions**:

```python
# Filter by minimum execution count
missing = api.get_missing_artifacts(
    artifact_type="PROGRAM",
    min_executions=50  # Only frequently-used missing artifacts
)

# Check for naming patterns
missing_names = [m['name'] for m in missing]
# Look for patterns like TEMP%, TEST%, etc.

# Update inventory to include these artifacts
```

### Issue: Unexpected Risk Classifications

**Symptoms**: Artifacts classified at wrong risk level

**Possible Causes**:
1. Risk patterns don't match naming conventions
2. Dependency data incomplete
3. Custom patterns needed

**Solutions**:

```python
# Review risk patterns in config/queries.yaml
# Add organization-specific patterns

# Example: Add custom high-risk pattern
risk_patterns:
  high_risk:
    - pattern: "CUSTOM%"
      description: "Custom critical pattern"
      reason: "Organization-specific critical artifacts"

# Reload configuration and re-run assessment
```

### Issue: Priority Scores Don't Make Sense

**Symptoms**: Low-priority artifacts ranked higher than expected

**Possible Causes**:
1. Priority weights not aligned with goals
2. Size or age data missing
3. Risk scores not configured correctly

**Solutions**:

```python
# Adjust priority weights in config/queries.yaml
cleanup:
  priority_weights:
    size_weight: 60      # Emphasize size if space is priority
    age_weight: 20
    risk_weight: 15
    dependency_weight: 5

# Verify data completeness
recommendations = api.get_cleanup_recommendations(top_n=10)
for rec in recommendations:
    print(f"{rec['name']}: size={rec['size_mb']}, "
          f"age={rec['days_inactive']}, risk={rec['risk_level']}")
```

### Issue: Query Performance Slow

**Symptoms**: Queries take minutes to complete

**Possible Causes**:
1. Large database without indexes
2. Complex dependency analysis
3. Recursive queries

**Solutions**:

```python
# Check database size
import os
db_size_mb = os.path.getsize("analyzer.db") / (1024 * 1024)
print(f"Database size: {db_size_mb:.2f} MB")

# Ensure indexes exist
api.create_indexes()

# Limit result set
recommendations = api.get_cleanup_recommendations(
    top_n=50  # Reduce from 100
)

# Use non-recursive dependency queries
deps = api.get_artifact_dependencies(
    artifact_name="PROG1",
    recursive=False  # Faster
)
```

### Issue: Configuration Validation Errors

**Symptoms**: Configuration file rejected with validation errors

**Possible Causes**:
1. Priority weights don't sum to 100
2. Invalid threshold values
3. Malformed YAML

**Solutions**:

```yaml
# Ensure weights sum to 100
cleanup:
  priority_weights:
    size_weight: 40
    age_weight: 30
    risk_weight: 20
    dependency_weight: 10  # Total = 100

# Check threshold ranges
usage_thresholds:
  min_executions: 1      # Must be >= 0
  max_value: 1000        # Must be <= 1000

# Validate YAML syntax
# Use online YAML validator or:
python -c "import yaml; yaml.safe_load(open('config/queries.yaml'))"
```


### Getting Help

If you encounter issues not covered here:

1. **Check Logs**: Review analyzer logs for error messages
2. **Validate Data**: Ensure inventory and usage data are complete
3. **Test Configuration**: Validate YAML syntax and values
4. **Review Documentation**: See related guides below
5. **Contact Support**: Provide error messages and configuration

---

## See Also

### Related Documentation

- **[User Guide](USER_GUIDE.md)**: Complete end-user documentation
- **[API Reference](API.md)**: Python API for programmatic access
- **[CLI Reference](CLI_REFERENCE.md)**: Command-line interface
- **[Migration Guide](MIGRATION_GUIDE.md)**: Migration planning workflows
- **[Architecture](ARCHITECTURE.md)**: System architecture and design

### Advanced Topics

- **[Flow Analysis](advanced/FLOW_ANALYSIS.md)**: Program flow analysis
- **[Complexity Analysis](advanced/COMPLEXITY_ANALYSIS.md)**: Complexity metrics
- **[CICS Integration](advanced/CICS_INTEGRATION.md)**: CICS metadata integration

### Configuration Files

- **`config/queries.yaml`**: Query configuration (this document)
- **`config/inventory.yaml`**: Inventory configuration
- **`config/config.yaml`**: General configuration

### Example Scripts

- **`examples/run_migration_analysis.py`**: Complete analysis workflow
- **`examples/batch_migration_analysis.py`**: Batch processing
- **`examples/smf_analysis_pipeline.py`**: SMF data integration

---

## Quick Reference

### Common Query Patterns

```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

api = LegacyAnalyzerAPI(database_path="analyzer.db")

# Get unreferenced artifacts
unreferenced = api.get_unreferenced_artifacts(
    artifact_type="PROGRAM",
    analysis_days=365
)

# Get missing artifacts
missing = api.get_missing_artifacts(
    artifact_type="PROGRAM",
    min_executions=10
)

# Assess risk
risk = api.assess_artifact_risk()

# Get cleanup recommendations
cleanup = api.get_cleanup_recommendations(top_n=100)

# Get dependencies
deps = api.get_artifact_dependencies(
    artifact_name="PROG1",
    direction="both"
)
```

### Configuration Quick Reference

```yaml
# Analysis windows
analysis_windows:
  default: 365
  presets:
    recent: 90
    standard: 365
    comprehensive: 730

# Usage thresholds
usage_thresholds:
  min_executions: 1
  min_dataset_accesses: 1

# Risk patterns
risk_patterns:
  high_risk:
    - pattern: "DR%"
    - pattern: "YEAREND%"
  medium_risk:
    - pattern: "MONTH%"

# Cleanup weights
cleanup:
  priority_weights:
    size_weight: 40
    age_weight: 30
    risk_weight: 20
    dependency_weight: 10
```

### Risk Level Quick Reference

| Risk Level | Characteristics | Action |
|------------|----------------|--------|
| HIGH | Critical patterns (DR%, YEAREND%, AUDIT%) | REVIEW_REQUIRED |
| MEDIUM | Periodic patterns, has dependencies | ANALYZE_DEPENDENCIES |
| LOW | No critical patterns, no dependencies | ARCHIVE_CANDIDATE |

### Priority Score Quick Reference

| Score Range | Interpretation | Typical Action |
|-------------|----------------|----------------|
| 200+ | Very high priority | ARCHIVE_NOW |
| 100-200 | High priority | ARCHIVE_SOON |
| 50-100 | Medium priority | REVIEW_DEPENDENCIES |
| <50 | Low priority | MONITOR |

---

**Document Version**: 1.0  
**Last Updated**: February 3, 2026  
**Related Configuration**: `config/queries.yaml`
