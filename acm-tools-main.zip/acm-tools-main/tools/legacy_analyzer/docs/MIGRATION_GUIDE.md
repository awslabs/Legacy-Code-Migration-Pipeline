# Migration Guide

Complete guide for planning and executing mainframe modernization and migration projects using the Legacy Analyzer.

## Table of Contents

- [Overview](#overview)
- [Migration Approaches](#migration-approaches)
- [Prerequisites](#prerequisites)
- [Phase 1: Initial Assessment](#phase-1-initial-assessment)
- [Phase 2: Inventory Collection](#phase-2-inventory-collection)
- [Phase 3: Dependency Analysis](#phase-3-dependency-analysis)
- [Phase 4: Complexity Assessment](#phase-4-complexity-assessment)
- [Phase 5: Migration Planning](#phase-5-migration-planning)
- [Phase 6: Migration Execution](#phase-6-migration-execution)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)

## Overview

This guide provides a complete, step-by-step workflow for using the Legacy Analyzer to plan and execute a mainframe modernization or migration project. It covers the entire process from initial assessment through migration execution.

### What You'll Learn

- How to collect and analyze mainframe inventory
- How to extract and validate dependencies
- How to assess complexity and estimate effort
- How to plan migration using flows or packages
- How to execute migration in controlled waves
- Best practices for successful migration

## Migration Approaches

The Legacy Analyzer supports two complementary migration planning approaches:

### Flow-Based Migration (Recommended)

**What**: Organize migration around program execution flows starting from entry points

**Best For**:
- Modern cloud-native migrations
- Microservices architecture
- API-first approach
- Parallel team execution

**Benefits**:
- Natural business logic boundaries
- Clear entry points (CICS transactions, JCL jobs)
- Optimal sorting strategies for different phases
- Extended metadata for complete planning

**Example**: Migrate "Account Update Flow" (CICS transaction → programs → data)

### Package-Based Migration (Traditional)

**What**: Group related artifacts into logical packages by business domain

**Best For**:
- Lift-and-shift migrations
- Maintaining existing architecture
- Domain-driven migration
- Traditional waterfall approach

**Benefits**:
- Familiar to mainframe teams
- Clear domain boundaries
- Self-contained packages
- Wave-based execution

**Example**: Migrate "Payroll Package" (all payroll programs, copybooks, datasets)

### Dual Export Approach (Comprehensive)

**What**: Export both flows and jobs for complete migration planning

**Best For**:
- Complex migrations requiring both application and infrastructure planning
- Three-phase migration strategy
- Coordinated batch and online migration

**Benefits**:
- Complete system coverage
- Separate infrastructure from application migration
- Clear cross-references between jobs and flows
- Flexible execution strategies

## Prerequisites

### Required Data

- **Source Code**: COBOL, PL/I, JCL, copybooks, REXX, Natural, RPG, Assembler
- **Inventory Data**: CSV exports of programs, datasets, JCL, CICS resources
- **SMF Data** (optional): Usage metrics for prioritization

### Required Tools

- Python 3.8+
- Legacy Analyzer toolkit
- Database (SQLite included, PostgreSQL optional)
- jq (for JSON processing)
- Graphviz (optional, for visualizations)

### Recommended Setup

```bash
# Install Legacy Analyzer
pip install -e .

# Create project directory
mkdir migration_project
cd migration_project

# Create subdirectories
mkdir -p data/{inventory,source,smf}
mkdir -p reports/{flows,jobs,packages,waves}
mkdir -p config

# Copy configuration template
cp config/examples/migration_focused.yaml config/my_migration.yaml
```

## Phase 1: Initial Assessment

### Objective

Understand the scope and complexity of the legacy system.

### Steps

#### 1.1 Gather High-Level Information

Document the following:
- Number of programs, JCL jobs, copybooks
- Programming languages used
- Business domains/subsystems
- Known dependencies and integrations
- Current pain points
- Target platform (cloud, on-premise, hybrid)

#### 1.2 Set Migration Goals

Define:
- Timeline and budget constraints
- Risk tolerance
- Success criteria
- Migration approach (flow-based, package-based, or dual)

#### 1.3 Configure Analysis

Edit `config/my_migration.yaml`:

```yaml
analysis:
  max_flow_depth: 12  # Adjust based on system complexity
  max_workers: 8      # Adjust based on available CPU
  enable_caching: true

packages:
  max_artifacts: 150  # Adjust based on team capacity
  max_loc: 75000
  allow_external_deps: false  # Strict for migration

flows:
  default_sort: complexity-asc  # Start with simplest flows
  extended_scope: true  # Include all metadata

smf:
  enabled: true  # If SMF data available
```

## Phase 2: Inventory Collection

### Objective

Create a complete inventory of all artifacts in the legacy system.

### Steps

#### 2.1 Export Inventory from Mainframe

Use the provided mainframe export scripts in `tools/legacy_analyzer/inventory/exporters/`.

See the [Inventory Guide](USER_GUIDE.md#inventory-management) for detailed export instructions.

#### 2.2 Load Inventory into Database

```bash
# Create database
python -m legacy_analyzer analyze \
    --source-dir data/source \
    --db migration_project.db

# Load inventory data
python -m legacy_analyzer load \
    --type jcl \
    --file data/inventory/jcl_inventory.csv \
    --db migration_project.db

python -m legacy_analyzer load \
    --type programs \
    --file data/inventory/program_inventory.csv \
    --db migration_project.db

python -m legacy_analyzer load \
    --type datasets \
    --file data/inventory/dataset_inventory.csv \
    --db migration_project.db

python -m legacy_analyzer load \
    --type copybooks \
    --file data/inventory/copybook_inventory.csv \
    --db migration_project.db

# Load CICS metadata (recommended)
python -m legacy_analyzer metadata load-from-source \
    --source-dir data/source \
    --db migration_project.db
```

#### 2.3 Verify Inventory

```bash
# Check inventory counts
sqlite3 migration_project.db << EOF
SELECT 'JCL Jobs: ' || COUNT(*) FROM inventory_jcl;
SELECT 'Programs: ' || COUNT(*) FROM inventory_programs;
SELECT 'Datasets: ' || COUNT(*) FROM inventory_datasets;
SELECT 'Copybooks: ' || COUNT(*) FROM inventory_copybooks;
SELECT 'CICS Resources: ' || COUNT(*) FROM inventory_cics;
EOF
```

## Phase 3: Dependency Analysis

### Objective

Extract and analyze dependencies between artifacts.

### Steps

#### 3.1 Analyze Source Code

```bash
# Complete analysis (recommended)
python -m legacy_analyzer analyze \
    --source-dir data/source \
    --db migration_project.db \
    --parallel

# Or analyze by language
python -m legacy_analyzer analyze \
    --source-dir data/source/cobol \
    --languages COBOL \
    --db migration_project.db \
    --parallel
```

#### 3.2 Detect Entry Points

```bash
# Detect entry points with CICS metadata
python -m legacy_analyzer flow entry-points \
    --db migration_project.db \
    --use-metadata \
    --format markdown
```

#### 3.3 Identify Missing Artifacts

```bash
# Check completeness
sqlite3 migration_project.db << EOF
SELECT 
    'Total Dependencies: ' || COUNT(*),
    'Missing Artifacts: ' || SUM(CASE WHEN target_exists = 0 THEN 1 ELSE 0 END),
    'Completeness: ' || ROUND(100.0 * SUM(CASE WHEN target_exists = 1 THEN 1 ELSE 0 END) / COUNT(*), 1) || '%'
FROM artifact_dependencies;
EOF
```

**Action**: Investigate and add missing artifacts to inventory before proceeding. Target 95%+ completeness.

## Phase 4: Complexity Assessment

### Objective

Assess the complexity of each artifact to estimate migration effort.

### Steps

#### 4.1 Calculate Complexity Metrics

Complexity is automatically calculated during the `analyze` command. To view results:

```bash
# View complexity distribution
sqlite3 migration_project.db << EOF
SELECT 
    complexity_tier,
    COUNT(*) as count,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) as percentage
FROM complexity_metrics
GROUP BY complexity_tier
ORDER BY 
    CASE complexity_tier
        WHEN 'LOW' THEN 1
        WHEN 'MEDIUM' THEN 2
        WHEN 'HIGH' THEN 3
        WHEN 'VERY_HIGH' THEN 4
        WHEN 'GOD_PROGRAM' THEN 5
    END;
EOF
```

#### 4.2 Identify High-Complexity Programs

```bash
# Get top 20 most complex programs
sqlite3 migration_project.db << EOF
SELECT 
    program_name,
    lines_of_code,
    cyclomatic_complexity,
    complexity_tier
FROM complexity_metrics
ORDER BY composite_score DESC
LIMIT 20;
EOF
```

**Action**: Review high-complexity programs and consider:
- Refactoring before migration
- Breaking into smaller components
- Allocating extra resources for migration

## Phase 5: Migration Planning

Choose your migration planning approach:

### Option A: Flow-Based Planning (Recommended)

#### 5A.1 Build Migration Flows

```bash
# Build flows from entry points
python -m legacy_analyzer migration build-flows \
    --db migration_project.db
```

#### 5A.2 Export Flows with All Sorting Strategies

```bash
# Create output directory
mkdir -p reports/flows

# Export with all sorting strategies
python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_complexity_asc.json \
    --sort complexity-asc \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_complexity_desc.json \
    --sort complexity-desc \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_independence.json \
    --sort independence \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_dependencies.json \
    --sort dependencies \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_name.json \
    --sort name \
    --extended-scope
```

**Sorting Strategies Explained:**

| Strategy | Phase | Use Case | Risk | Speed | Best For |
|----------|-------|----------|------|-------|----------|
| **complexity-asc** ⭐ | 1 | Pilot/POC | Low | Fast | Starting migration, building confidence |
| **independence** | 2 | Parallel migration | Medium | Fast | Multiple teams, scaling up |
| **dependencies** | 4 | Shared infrastructure | Medium | Medium | Common components first |
| **complexity-desc** | 3 | Technical debt | High | Slow | Experienced teams, hard problems |
| **name** | - | Documentation | - | - | Reference documentation |

#### 5A.3 Review and Select Migration Strategy

```bash
# Compare flow counts and complexity distribution
for file in reports/flows/flows_by_*.json; do
    echo "=== $(basename $file) ==="
    jq '.summary' "$file"
    echo
done
```

**Recommended 4-Wave Approach:**

1. **Wave 1 (Pilot)**: Use `complexity-asc` - 5-10 simplest flows
2. **Wave 2 (Scale)**: Use `independence` - 10-15 independent flows in parallel
3. **Wave 3 (Infrastructure)**: Use `dependencies` - Shared components
4. **Wave 4 (Complex)**: Use `complexity-desc` - Remaining complex flows

#### 5A.4 Create Migration Waves

```bash
# Extract flows for each wave
jq '.flows[:10]' reports/flows/flows_by_complexity_asc.json > reports/waves/wave1_flows.json
jq '.flows[10:25]' reports/flows/flows_by_independence.json > reports/waves/wave2_flows.json
jq '.flows[:10]' reports/flows/flows_by_dependencies.json > reports/waves/wave3_flows.json
jq '.flows[:10]' reports/flows/flows_by_complexity_desc.json > reports/waves/wave4_flows.json
```

### Option B: Package-Based Planning (Traditional)

#### 5B.1 Create Packages by Business Domain

```bash
# Create package for Payroll subsystem
python -m legacy_analyzer package create \
    --name "Payroll Migration" \
    --seeds PAYROLL1,PAYCALC,TAXCALC \
    --db migration_project.db

# Create package for Billing subsystem
python -m legacy_analyzer package create \
    --name "Billing Migration" \
    --seeds BILLING1,BILLCALC,INVOICE1 \
    --db migration_project.db

# Create package for Customer Management
python -m legacy_analyzer package create \
    --name "Customer Management" \
    --seeds CUSTMGMT,CUSTUPD,CUSTRPT \
    --db migration_project.db
```

#### 5B.2 Validate Packages

```bash
# Validate all packages
python -m legacy_analyzer package validate-all \
    --db migration_project.db \
    --output reports/package_validation.csv
```

Review validation results:
- **Self-contained**: No external dependencies
- **Size constraints**: Within max_artifacts, max_loc, max_complexity
- **Conflicts**: No artifacts in multiple packages

#### 5B.3 Detect and Resolve Conflicts

```bash
# Find conflicting artifacts
python -m legacy_analyzer package conflicts \
    --db migration_project.db \
    --output reports/package_conflicts.csv
```

**Action**: Resolve conflicts by:
- Moving shared artifacts to separate "Common" package
- Duplicating artifacts across packages (if small)
- Refactoring to eliminate shared dependencies

#### 5B.4 Generate Migration Waves

```bash
# Suggest migration waves based on dependencies
python -m legacy_analyzer package waves \
    --max-packages-per-wave 5 \
    --db migration_project.db \
    --output reports/migration_waves.csv
```

### Option C: Dual Export Approach (Comprehensive)

#### 5C.1 Export Both Flows and Jobs

```bash
# Export flows (application logic)
python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_complexity_asc.json \
    --sort complexity-asc \
    --extended-scope

# Export jobs (batch orchestration)
for strategy in name type dependencies complexity; do
    python -m legacy_analyzer migration export-jobs \
        --db migration_project.db \
        --output-dir reports/jobs \
        --sort-by ${strategy}
done
```

**Job Sorting Strategies:**

| Strategy | Use Case | Benefits |
|----------|----------|----------|
| **name** | Documentation | Easy to locate specific jobs |
| **type** ⭐ | Three-phase migration | Separate infrastructure from application |
| **dependencies** | Execution order | Maintain correct job sequence |
| **complexity** | Risk assessment | Identify high-risk jobs early |

#### 5C.2 Understand Job Categorization

Jobs are automatically categorized:

- **APPLICATION**: Invoke custom programs (COBOL, PL/I, etc.)
  - Require program migration before job migration
  - Linked to program flows via `linkedFlow` field

- **INFRASTRUCTURE**: Only invoke utilities (IEFBR14, IDCAMS, SORT, etc.)
  - Can be migrated independently
  - May be replaced with cloud-native equivalents

#### 5C.3 Plan Three-Phase Migration

**Phase 1: Infrastructure Jobs (Weeks 1-4)**
```bash
# Extract infrastructure jobs
jq '.jobs[] | select(.jobType == "INFRASTRUCTURE")' \
    reports/jobs/jobs_by_type.json > reports/phase1_infrastructure_jobs.json
```

**Phase 2: Application Programs (Weeks 5-20)**
```bash
# Use flow export (already done)
cp reports/flows/flows_by_complexity_asc.json reports/phase2_application_flows.json
```

**Phase 3: Batch Orchestration (Weeks 21-24)**
```bash
# Extract application jobs
jq '.jobs[] | select(.jobType == "APPLICATION")' \
    reports/jobs/jobs_by_type.json > reports/phase3_orchestration_jobs.json
```

#### 5C.4 Cross-Reference Jobs and Flows

```bash
# Extract jobs that invoke specific flows
jq '.jobs[] | select(.linkedFlow == "FLOW_CBACT01C")' \
    reports/jobs/jobs_by_name.json

# Create cross-reference matrix
jq -n --slurpfile jobs reports/jobs/jobs_by_name.json \
      --slurpfile flows reports/flows/flows_by_name.json \
      '{
        jobs: $jobs[0].jobs | map({name: .jobName, flow: .linkedFlow}),
        flows: $flows[0].flows | map({name: .flowId, jobs: .invokedByJobs})
      }' > reports/job_flow_cross_reference.json
```

## Phase 6: Migration Execution

### Objective

Execute the migration in controlled waves.

### Steps

#### 6.1 Prepare Wave 1

```bash
# For flow-based migration
jq '.flows[:5]' reports/waves/wave1_flows.json > reports/current_wave.json

# For package-based migration
python -m legacy_analyzer package list-wave \
    --wave 1 \
    --db migration_project.db \
    --output reports/wave1_packages.csv
```

#### 6.2 Migrate Each Flow/Package

For each flow or package in the wave:

1. **Review Documentation**
   - Entry points and invocation methods
   - Program dependencies and call chains
   - Data access patterns
   - Complexity metrics

2. **Extract Source Code**
   - Gather all programs in the flow/package
   - Collect all copybooks
   - Document dataset access

3. **Migrate Code**
   - Convert COBOL to target language
   - Migrate JCL to orchestration tools
   - Migrate datasets to databases/files
   - Implement interfaces (REST APIs, message queues)

4. **Test Migrated Code**
   - Unit tests for individual programs
   - Integration tests for flow/package
   - Performance tests
   - Security tests

5. **Deploy and Validate**
   - Deploy to test environment
   - Validate against original system
   - Performance comparison
   - User acceptance testing

#### 6.3 Track Progress

```bash
# For flow-based migration
# Update tracking spreadsheet or project management tool

# For package-based migration
python -m legacy_analyzer package update-status \
    --name "Payroll Migration" \
    --status "COMPLETED" \
    --db migration_project.db

python -m legacy_analyzer package progress \
    --db migration_project.db
```

#### 6.4 Repeat for Subsequent Waves

Repeat steps 6.1-6.3 for Wave 2, Wave 3, etc.

## Best Practices

### Planning

1. **Start Small**: Begin with a pilot (5-10 flows or 1-2 packages)
2. **Validate Inventory**: Ensure 95%+ completeness before planning
3. **Resolve Circular Dependencies**: Break cycles before migration
4. **Document Assumptions**: Record all decisions and assumptions
5. **Plan for Rollback**: Have rollback procedures for each wave
6. **Use Extended Scope**: Always export with `--extended-scope` for complete metadata

### Execution

1. **Automate Where Possible**: Use code generation tools
2. **Test Thoroughly**: Comprehensive testing at each stage
3. **Monitor Performance**: Track performance metrics
4. **Maintain Traceability**: Link migrated code to original
5. **Preserve Business Logic**: Ensure functional equivalence
6. **Parallel Execution**: Use `independence` sorting for parallel teams

### Communication

1. **Regular Status Updates**: Weekly progress reports
2. **Stakeholder Engagement**: Keep business stakeholders informed
3. **Risk Communication**: Escalate issues early
4. **Documentation**: Maintain comprehensive documentation
5. **Knowledge Transfer**: Train team on new platform

### Quality

1. **Code Reviews**: Review all migrated code
2. **Automated Testing**: Implement CI/CD pipelines
3. **Performance Testing**: Validate performance requirements
4. **Security Testing**: Ensure security standards met
5. **Acceptance Testing**: Business user validation

## Troubleshooting

### Issue: Inventory Completeness < 90%

**Symptoms**: Many missing artifacts detected

**Solutions**:
1. Re-export inventory from mainframe
2. Check for additional source libraries
3. Review SMF data for undocumented programs
4. Search for shadow IT or undocumented systems
5. Document and accept known gaps

### Issue: Circular Dependencies

**Symptoms**: Circular dependency chains detected

**Solutions**:
1. Refactor code to break cycles
2. Introduce interfaces/abstractions
3. Migrate circular groups together
4. Document and accept (if unavoidable)

### Issue: No Flows Exported

**Symptoms**: Export command returns empty flows array

**Solutions**:
1. Verify entry points exist: `python -m legacy_analyzer flow entry-points --db migration_project.db`
2. Check that flows were built: `python -m legacy_analyzer migration build-flows --db migration_project.db`
3. Verify database has dependencies: `sqlite3 migration_project.db "SELECT COUNT(*) FROM artifact_dependencies;"`

### Issue: Missing Extended Metadata

**Symptoms**: Exported flows missing copybooks, datasets, JCL, or CICS data

**Solutions**:
1. Ensure `--extended-scope` flag is used
2. Verify inventory data is loaded (copybooks, datasets, JCL, CICS)
3. Check inventory tables: `sqlite3 migration_project.db "SELECT COUNT(*) FROM inventory_copybooks;"`
4. Reload inventory if necessary

### Issue: Package Too Large

**Symptoms**: Package exceeds size constraints

**Solutions**:
1. Split into multiple packages
2. Increase size constraints (if justified)
3. Remove non-essential artifacts
4. Refactor to reduce dependencies

### Issue: High Complexity Programs

**Symptoms**: Many VERY_HIGH complexity programs

**Solutions**:
1. Refactor before migration
2. Allocate extra resources
3. Consider rewrite instead of migration
4. Break into smaller components
5. Use `complexity-desc` sorting to tackle early

### Issue: Performance Problems

**Symptoms**: Analysis takes too long

**Solutions**:
1. Increase `max_workers` in config
2. Enable caching
3. Reduce `max_flow_depth`
4. Process in batches
5. Use more powerful hardware

## Success Metrics

Track these metrics throughout the migration:

### Quality Metrics
- **Inventory Completeness**: Target 95%+
- **Test Coverage**: Target 80%+
- **Defect Rate**: Target < 1% of migrated code
- **Performance Parity**: Target 100%

### Progress Metrics
- **Flows/Packages Migrated**: Count by wave
- **Velocity**: Flows/packages per week/sprint
- **Schedule Adherence**: Target ±10%
- **Budget Adherence**: Target ±10%

### Technical Metrics
- **Code Complexity**: Track before/after
- **Dependencies**: External dependencies eliminated
- **Reuse**: Shared components migrated once
- **Automation**: Percentage of automated migration

## Additional Resources

### Documentation
- [User Guide](USER_GUIDE.md) - Complete user documentation
- [CLI Reference](CLI_REFERENCE.md) - Command-line interface
- [API Reference](API.md) - Python API
- [Architecture](ARCHITECTURE.md) - System architecture

### Examples
- `examples/migration_package_example.py` - Package-based migration
- `run_carddemo_analysis.sh` - Complete analysis example

### Support
- GitHub Issues: Report bugs and request features
- Documentation: Comprehensive guides and references
- Examples: Working code samples

## Conclusion

Following this guide will help ensure a successful migration project. Remember:

1. **Plan Thoroughly**: Invest time in analysis and planning
2. **Start Small**: Pilot with low-risk flows/packages
3. **Test Extensively**: Quality is paramount
4. **Communicate Often**: Keep stakeholders informed
5. **Learn and Adapt**: Improve process with each wave
6. **Use the Right Approach**: Choose flow-based, package-based, or dual export based on your needs

Good luck with your migration!
