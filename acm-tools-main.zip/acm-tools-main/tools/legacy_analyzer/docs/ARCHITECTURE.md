# Legacy Analyzer Architecture

## Overview

The Legacy Analyzer is a comprehensive system for analyzing mainframe applications and planning migrations. It follows a modular, layered architecture with clear separation of concerns, enabling extensibility and maintainability.

## Table of Contents

- [High-Level Architecture](#high-level-architecture)
- [Component Overview](#component-overview)
- [Data Flow](#data-flow)
- [Database Schema](#database-schema)
- [Design Patterns](#design-patterns)
- [Extension Points](#extension-points)
- [Performance Considerations](#performance-considerations)
- [Technology Stack](#technology-stack)
- [Integration](#integration)

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         User Interfaces                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │  CLI (cli.py)│  │  Python API  │  │  Analysis Scripts    │  │
│  │              │  │  (api.py)    │  │  (examples/)         │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Orchestration Layer                           │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  AnalysisOrchestrator (analysis_orchestrator.py)         │   │
│  │  - Coordinates complete workflow                         │   │
│  │  - Manages phase execution                               │   │
│  │  - Handles error recovery                                │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Analysis Layer                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Flow         │  │ Complexity   │  │ Missing Code         │  │
│  │ Analyzer     │  │ Analyzer     │  │ Detector             │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Circular     │  │ Call Graph   │  │ Copybook             │  │
│  │ Detector     │  │ Builder      │  │ Analyzer             │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Parsing Layer                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ COBOL        │  │ PL/I         │  │ JCL                  │  │
│  │ Parser       │  │ Parser       │  │ Parser               │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Natural      │  │ RPG          │  │ Assembler            │  │
│  │ Parser       │  │ Parser       │  │ Parser               │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│  ┌──────────────┐  ┌──────────────┐                            │
│  │ REXX         │  │ CSD          │                            │
│  │ Parser       │  │ Parser       │                            │
│  └──────────────┘  └──────────────┘                            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Data Management Layer                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Inventory    │  │ Dependency   │  │ Migration            │  │
│  │ Manager      │  │ Loader       │  │ Flow Builder         │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Package      │  │ Interface    │  │ External Config      │  │
│  │ Builder      │  │ Schema Mgr   │  │ Loader               │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Database Layer                              │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  SQLite Adapter (from smf_loader)                        │   │
│  │  - Connection management                                 │   │
│  │  - Transaction handling                                  │   │
│  │  - Query execution                                       │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                   │
│                              ▼                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  SQLite Database                                         │   │
│  │  - Inventory tables (9 tables)                           │   │
│  │  - Dependency tables                                     │   │
│  │  - Migration flow tables                                 │   │
│  │  - Complexity metrics                                    │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Component Overview

### 1. User Interface Layer

#### CLI (cli.py)
- Command-line interface for all operations
- Argument parsing and validation
- Progress reporting
- Error handling and user feedback

#### Python API (api.py)
- High-level programmatic interface
- Context manager support
- Lazy component initialization
- Simplified method signatures

#### Analysis Scripts (examples/)
- Pre-built analysis workflows
- Integration examples
- Best practice demonstrations

### 2. Orchestration Layer

#### AnalysisOrchestrator
**Purpose**: Coordinates the complete analysis workflow with proper separation of concerns.

**Responsibilities**:
- Phase management (8 phases)
- Component coordination
- Error recovery
- State tracking
- Results aggregation

**Key Methods**:
- `run_complete_analysis()`: Full workflow
- `run_inventory_only()`: Inventory discovery
- `run_dependency_analysis_only()`: Dependency extraction
- `run_artifacts_only()`: Specialized artifact parsing

**Workflow Phases**:
1. **File Discovery**: Scan source directory
2. **Metadata Extraction**: Extract file metadata
3. **Schema Creation**: Create database tables
4. **Inventory Population**: Load artifacts into database
5. **Dependency Analysis**: Extract dependencies from source
6. **Dependency Validation**: Validate against inventory
7. **Dependency Storage**: Store validated dependencies
8. **Final Analysis**: Generate reports and metrics

### 3. Analysis Layer

#### FlowAnalyzer
**Purpose**: Analyze program execution flows and call hierarchies.

**Key Features**:
- Entry point detection (CICS, JCL, inferred)
- Call graph generation
- Flow depth calculation
- Circular dependency detection
- CICS metadata integration

**Algorithms**:
- Depth-first search for flow traversal
- Tarjan's algorithm for cycle detection
- Topological sorting for execution order

#### ComplexityAnalyzer
**Purpose**: Calculate complexity metrics for programs.

**Metrics Calculated**:
- Lines of code (LOC)
- Cyclomatic complexity
- Dependency counts (in/out)
- Composite complexity score
- Complexity tier (LOW, MEDIUM, HIGH, VERY_HIGH)
- God program detection

**Scoring Formula**:
```
base_score = (LOC × 0.3) + (cyclomatic × 0.4) + (dependencies × 0.3)
composite_score = base_score × language_factor
```

**Language Factors**:
- COBOL: 1.0 (baseline)
- Assembler: 1.5 (more complex)
- PL/I: 1.2
- Natural: 0.9
- JCL: 0.8

#### MissingCodeDetector
**Purpose**: Identify artifacts referenced but not found in inventory.

**Detection Methods**:
- Cross-reference dependencies with inventory
- Calculate completeness scores
- Severity assessment (HIGH, MEDIUM, LOW)
- Reference count tracking

**Completeness Calculation**:
```
completeness = found_artifacts / (found_artifacts + missing_artifacts)
```

#### CircularDependencyDetector
**Purpose**: Detect circular dependencies in the system.

**Detection Algorithm**:
- Build dependency graph
- Apply Tarjan's strongly connected components algorithm
- Identify cycles
- Calculate severity based on cycle size

#### CallGraphBuilder
**Purpose**: Build call graphs for visualization and analysis.

**Graph Types**:
- Program call graphs
- Copybook inclusion graphs
- Dataset access graphs
- Cross-language dependency graphs

#### CopybookAnalyzer
**Purpose**: Analyze copybook content for executable code detection.

**Analysis**:
- Detect executable statements (CALL, EXEC, etc.)
- Classify as data-only or executable
- Track usage patterns
- Identify shared copybooks

### 4. Parsing Layer

#### Language Parsers

All parsers inherit from `BaseDependencyParser` and implement:
- `parse()`: Extract dependencies from source
- `get_supported_patterns()`: File pattern matching
- `detect_language()`: Language identification

**COBOL Parser** (cobol_parser.py)
- CALL statement extraction
- COPY statement extraction
- File access (SELECT, FD)
- CICS command parsing
- Program boundary detection

**PL/I Parser** (pli_parser.py)
- CALL statement extraction
- %INCLUDE statement extraction
- File I/O operations
- CICS command parsing

**JCL Parser** (jcl_parser.py)
- EXEC PGM= extraction
- DD statement parsing
- Dataset references
- Job dependencies

**Natural Parser** (natural_parser.py)
- CALLNAT statement extraction
- INCLUDE statement extraction
- Data area references

**RPG Parser** (rpg_parser.py)
- CALL operation extraction
- /COPY directive extraction
- File declarations

**Assembler Parser** (asm_parser.py)
- CALL macro extraction
- COPY macro extraction
- CSECT detection
- External references

**REXX Parser** (rexx_parser.py)
- Function call extraction
- External command execution
- Dataset access

**CSD Parser** (csd_parser.py)
- CICS resource definitions
- Transaction parsing
- Program parsing
- File parsing
- Mapset parsing

### 5. Data Management Layer

#### InventoryManager
**Purpose**: Manage complete artifact inventory.

**Responsibilities**:
- File discovery and scanning
- Metadata extraction
- Schema creation
- Inventory population
- Specialized table management (CICS, JCL, programs, copybooks, datasets)

**Tables Managed**:
- `inventory`: Main artifact table
- `inventory_cics`: CICS resources
- `inventory_jcl`: JCL jobs
- `inventory_programs`: Program metadata
- `inventory_copybooks`: Copybook metadata
- `inventory_datasets`: Dataset metadata
- `program_file_mapping`: Program boundaries
- `copybook_analysis`: Executable code detection

#### DependencyLoader
**Purpose**: Load dependencies into database.

**Features**:
- Bulk insert optimization
- Duplicate detection
- Transaction management
- Error handling

#### MigrationFlowBuilder
**Purpose**: Build migration-focused flow data.

**Flow Components**:
- Entry point identification
- Scope (programs, copybooks, datasets)
- Inbound interfaces (external callers)
- Outbound interfaces (external callees)
- Data operations (read, write, update, delete)
- Complexity metrics
- Flow dependencies

**Sorting Strategies**:
- complexity-asc: Simplest first
- complexity-desc: Most complex first
- independence: Minimal dependencies
- dependencies: Most dependencies
- name: Alphabetical
- none: Database order

#### PackageBuilder
**Purpose**: Create migration packages from seed artifacts.

**Features**:
- Transitive dependency inclusion
- Constraint validation
- Conflict detection
- Self-containment checking

#### InterfaceSchemaManager
**Purpose**: Manage interface configuration for migration flows.

**Tables**:
- `interface_external_programs`: External program definitions
- `interface_external_callers`: External caller definitions

**Features**:
- External program configuration
- External caller configuration
- Auto-detection of programs without source
- Cross-flow call exclusion

#### ExternalConfigLoader
**Purpose**: Load external configuration from YAML files.

**Configuration Format**:
```yaml
external_programs:
  - name: UTILPROG
    description: Utility program
    
external_callers:
  - name: EXTJOB01
    description: External batch job
    caller_type: JCL
```

### 6. Database Layer

#### SQLiteAdapter
**Purpose**: Database connection and query execution.

**Features**:
- Connection pooling
- Transaction management
- Query execution
- Bulk operations
- Error handling

**Inherited from**: `smf_loader.databases.sqlite_adapter.SQLiteAdapter`

## Data Flow

### Complete Analysis Workflow

```
1. File Discovery
   ├─> Scan source directory
   ├─> Identify file types
   └─> Create Artifact objects

2. Metadata Extraction
   ├─> Extract file metadata
   ├─> Detect language
   └─> Identify artifact type

3. Schema Creation
   ├─> Create inventory tables
   ├─> Create dependency tables
   ├─> Create migration flow tables
   └─> Create complexity tables

4. Inventory Population
   ├─> Load main inventory
   ├─> Parse CSD files → inventory_cics
   ├─> Parse JCL files → inventory_jcl
   ├─> Populate programs → inventory_programs
   ├─> Populate copybooks → inventory_copybooks
   └─> Populate datasets → inventory_datasets

5. Dependency Analysis
   ├─> Parse source files
   ├─> Extract dependencies
   ├─> Detect program boundaries
   ├─> Analyze copybooks
   └─> Calculate complexity

6. Dependency Validation
   ├─> Cross-reference with inventory
   ├─> Create stub records for missing
   └─> Validate dependency types

7. Dependency Storage
   ├─> Store artifact_dependencies
   ├─> Store program_file_mapping
   ├─> Store copybook_analysis
   ├─> Update complexity with dependency counts
   ├─> Create CICS_TRANSACTION dependencies
   └─> Create JCL→PROGRAM dependencies

8. Final Analysis
   ├─> Build migration flows
   ├─> Generate reports
   └─> Export results
```

### Migration Flow Export Workflow

```
1. Build Flows
   ├─> Identify entry points
   ├─> Analyze program scope
   ├─> Detect interfaces
   ├─> Calculate complexity
   └─> Store in migration_flows tables

2. Export Flows
   ├─> Query migration_flows
   ├─> Apply filters
   ├─> Apply sorting strategy
   ├─> Include extended scope (optional)
   └─> Write JSON output

3. Job Export
   ├─> Query inventory_jcl
   ├─> Categorize (APPLICATION/INFRASTRUCTURE)
   ├─> Link to flows
   ├─> Detect dependencies
   └─> Write JSON output
```

## Database Schema

### Core Tables

#### inventory
Main artifact inventory table.

```sql
CREATE TABLE inventory (
    id INTEGER PRIMARY KEY,
    artifact_name TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    file_path TEXT,
    language TEXT,
    program_count INTEGER DEFAULT 1,
    dominant_language TEXT,
    dominant_type TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### artifact_dependencies
Cross-artifact dependencies.

```sql
CREATE TABLE artifact_dependencies (
    id INTEGER PRIMARY KEY,
    source_artifact_name TEXT NOT NULL,
    source_artifact_type TEXT NOT NULL,
    target_artifact_name TEXT NOT NULL,
    target_artifact_type TEXT NOT NULL,
    dependency_type TEXT NOT NULL,
    source_file_path TEXT,
    line_number INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### complexity_metrics
Program complexity metrics.

```sql
CREATE TABLE complexity_metrics (
    id INTEGER PRIMARY KEY,
    program_name TEXT NOT NULL UNIQUE,
    language TEXT NOT NULL,
    lines_of_code INTEGER NOT NULL,
    cyclomatic_complexity INTEGER NOT NULL,
    dependency_count_in INTEGER DEFAULT 0,
    dependency_count_out INTEGER DEFAULT 0,
    composite_score REAL NOT NULL,
    complexity_tier TEXT NOT NULL,
    comment_lines INTEGER DEFAULT 0,
    blank_lines INTEGER DEFAULT 0,
    total_lines INTEGER DEFAULT 0,
    language_factor REAL DEFAULT 1.0,
    is_god_program INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Specialized Tables

#### inventory_cics
CICS resource definitions.

```sql
CREATE TABLE inventory_cics (
    id INTEGER PRIMARY KEY,
    resource_type TEXT NOT NULL,
    resource_name TEXT NOT NULL,
    group_name TEXT,
    program_name TEXT,
    file_name TEXT,
    mapset_name TEXT,
    status TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### inventory_jcl
JCL job definitions.

```sql
CREATE TABLE inventory_jcl (
    id INTEGER PRIMARY KEY,
    job_name TEXT NOT NULL,
    file_path TEXT,
    step_count INTEGER DEFAULT 0,
    programs_executed TEXT,
    datasets_referenced TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### program_file_mapping
Program boundary detection.

```sql
CREATE TABLE program_file_mapping (
    id INTEGER PRIMARY KEY,
    file_id INTEGER NOT NULL,
    program_name TEXT NOT NULL,
    language TEXT NOT NULL,
    program_type TEXT,
    start_line INTEGER,
    end_line INTEGER,
    lines_of_code INTEGER,
    FOREIGN KEY (file_id) REFERENCES inventory(id)
);
```

#### copybook_analysis
Copybook executable code detection.

```sql
CREATE TABLE copybook_analysis (
    id INTEGER PRIMARY KEY,
    copybook_name TEXT NOT NULL,
    file_path TEXT,
    has_executable_code INTEGER DEFAULT 0,
    executable_statements TEXT,
    data_definitions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Migration Flow Tables

#### migration_flows
Main migration flow data.

```sql
CREATE TABLE migration_flows (
    id INTEGER PRIMARY KEY,
    flow_id TEXT NOT NULL UNIQUE,
    flow_name TEXT NOT NULL,
    entry_point_program TEXT NOT NULL,
    entry_point_type TEXT NOT NULL,
    business_domain TEXT,
    priority INTEGER DEFAULT 0,
    total_loc INTEGER DEFAULT 0,
    avg_complexity REAL DEFAULT 0.0,
    max_complexity REAL DEFAULT 0.0,
    complexity_tier TEXT,
    internal_dependencies INTEGER DEFAULT 0,
    external_dependencies INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### migration_flow_scope
Programs, copybooks, and datasets in flow scope.

```sql
CREATE TABLE migration_flow_scope (
    id INTEGER PRIMARY KEY,
    flow_id TEXT NOT NULL,
    artifact_name TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id)
);
```

#### migration_flow_interfaces
Inbound and outbound interfaces.

```sql
CREATE TABLE migration_flow_interfaces (
    id INTEGER PRIMARY KEY,
    flow_id TEXT NOT NULL,
    interface_type TEXT NOT NULL,
    artifact_name TEXT NOT NULL,
    artifact_type TEXT,
    caller_type TEXT,
    FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id)
);
```

### Interface Configuration Tables

#### interface_external_programs
External program definitions.

```sql
CREATE TABLE interface_external_programs (
    id INTEGER PRIMARY KEY,
    program_name TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### interface_external_callers
External caller definitions.

```sql
CREATE TABLE interface_external_callers (
    id INTEGER PRIMARY KEY,
    caller_name TEXT NOT NULL UNIQUE,
    description TEXT,
    caller_type TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Design Patterns

### 1. Strategy Pattern

**Used in**: Parsers, Database Adapters, Sorting Strategies

**Example**: Language parsers implement `BaseDependencyParser` interface.

```python
class BaseDependencyParser(ABC):
    @abstractmethod
    def parse(self, file_path: str) -> List[Dependency]:
        pass
    
    @abstractmethod
    def get_supported_patterns(self) -> List[str]:
        pass
```

### 2. Factory Pattern

**Used in**: Parser creation, Schema registry

**Example**: Parser factory creates appropriate parser based on language.

```python
def get_parser(language: str) -> BaseDependencyParser:
    if language == 'COBOL':
        return COBOLDependencyParser()
    elif language == 'PLI':
        return PLIDependencyParser()
    # ...
```

### 3. Builder Pattern

**Used in**: Migration flow building, Package building

**Example**: MigrationFlowBuilder constructs complex flow objects.

```python
builder = MigrationFlowBuilder(db_conn)
flow = builder.set_entry_point(program)
             .add_scope(programs)
             .add_interfaces(interfaces)
             .calculate_complexity()
             .build()
```

### 4. Repository Pattern

**Used in**: Data access layer

**Example**: InventoryManager abstracts database operations.

```python
class InventoryManager:
    def get_artifact(self, name: str) -> Artifact:
        # Abstract database query
        pass
    
    def save_artifact(self, artifact: Artifact):
        # Abstract database insert
        pass
```

### 5. Facade Pattern

**Used in**: LegacyAnalyzerAPI

**Example**: API provides simplified interface to complex subsystems.

```python
api = LegacyAnalyzerAPI("db.db")
flow = api.analyze_flow("PROG1")  # Hides complexity
```

### 6. Observer Pattern

**Used in**: Progress reporting

**Example**: Progress callbacks during long operations.

```python
def progress_callback(current, total, message):
    print(f"{current}/{total}: {message}")

analyzer.analyze(callback=progress_callback)
```

### 7. Template Method Pattern

**Used in**: Analysis orchestrator phases

**Example**: Orchestrator defines workflow template, subclasses implement steps.

```python
def run_complete_analysis(self):
    self._run_inventory_phases()
    self._run_dependency_analysis()
    self._run_dependency_validation()
    self._run_dependency_storage()
    self._run_final_analysis()
```

## Extension Points

### Adding New Language Parser

1. Create parser class inheriting from `BaseDependencyParser`
2. Implement `parse()` method
3. Implement `get_supported_patterns()` method
4. Register in parser factory
5. Add language factor to complexity analyzer

**Example**:

```python
class NewLanguageParser(BaseDependencyParser):
    def parse(self, file_path: str) -> List[Dependency]:
        # Parse source and extract dependencies
        pass
    
    def get_supported_patterns(self) -> List[str]:
        return ['*.new', '*.nlang']
```

### Adding New Analysis Feature

1. Create analyzer class in `analysis/` directory
2. Implement analysis logic
3. Add to AnalysisOrchestrator workflow
4. Create database tables if needed
5. Add API methods to LegacyAnalyzerAPI

### Adding New Database Adapter

1. Create adapter class inheriting from `BaseDatabase`
2. Implement required methods (connect, execute, etc.)
3. Register in database factory
4. Test with existing schemas

### Adding New Export Format

1. Add export method to appropriate exporter class
2. Implement format conversion logic
3. Add CLI option
4. Add API method

## Performance Considerations

### Database Optimization

1. **Indexes**: Created automatically on key columns
   - `artifact_name` in inventory
   - `source_artifact_name`, `target_artifact_name` in dependencies
   - `flow_id` in migration flow tables

2. **Bulk Operations**: Use bulk insert for large datasets
   ```python
   loader.bulk_insert(dependencies)  # Much faster than individual inserts
   ```

3. **Transactions**: Group related operations
   ```python
   with db.transaction():
       # Multiple operations
       pass
   ```

4. **Query Optimization**: Use appropriate indexes and joins
   ```sql
   -- Good: Uses index
   SELECT * FROM inventory WHERE artifact_name = 'PROG1';
   
   -- Bad: Full table scan
   SELECT * FROM inventory WHERE LOWER(artifact_name) = 'prog1';
   ```

### Parsing Optimization

1. **Parallel Processing**: Use multiprocessing for large codebases
   ```python
   analyzer.analyze(parallel=True, max_workers=8)
   ```

2. **Caching**: Cache parsed results to avoid re-parsing
   ```python
   cache_manager.get_or_parse(file_path)
   ```

3. **Incremental Analysis**: Only analyze changed files
   ```python
   analyzer.analyze_incremental(changed_files)
   ```

### Memory Management

1. **Streaming**: Process large files in chunks
2. **Lazy Loading**: Load data only when needed
3. **Resource Cleanup**: Use context managers

```python
with LegacyAnalyzerAPI("db.db") as api:
    # Resources automatically cleaned up
    pass
```

## Technology Stack

### Core Technologies

- **Python 3.8+**: Primary language
- **SQLite**: Default database
- **Regular Expressions**: Pattern matching in parsers

### Key Libraries

- **pathlib**: File system operations
- **sqlite3**: Database operations
- **typing**: Type hints
- **dataclasses**: Data models
- **abc**: Abstract base classes

### Optional Dependencies

- **pytest**: Testing framework
- **hypothesis**: Property-based testing
- **graphviz**: Graph visualization
- **pyyaml**: Configuration files

## Integration

### Integration with SMF Toolkit

The Legacy Analyzer is part of the larger SMF Migration Toolkit:

```
SMF Migration Toolkit
├── smf_record_parser: Parse SMF binary files
├── smf_loader: Load SMF data into databases
├── smf_queries: Query SMF data
├── legacy_analyzer: Analyze legacy code (this component)
└── smf_dashboard: Web-based dashboard
```

**Shared Components**:
- Database adapters (SQLiteAdapter)
- Configuration management
- Logging infrastructure

**Data Flow**:
```
SMF Records → smf_record_parser → smf_loader → Database
                                                    ↓
Source Code → legacy_analyzer → Database ← smf_queries
                                    ↓
                            smf_dashboard (visualization)
```

### External Tool Integration

**Graphviz**: For call graph visualization
```python
dot = api.export_flow_dot(flow)
# Use graphviz to render
```

**Excel/CSV**: For data analysis
```python
api.export_to_csv("results.csv")
```

**CI/CD**: For automated analysis
```bash
python -m tools.legacy_analyzer analyze --source-dir ./code --db analysis.db
```

## See Also

- **[User Guide](USER_GUIDE.md)**: End-user documentation
- **[API Reference](API.md)**: Python API documentation
- **[CLI Reference](CLI_REFERENCE.md)**: Command-line interface
- **[Parsers](PARSERS.md)**: Parser documentation and development
- **[Development Guide](DEVELOPMENT.md)**: Developer setup and guidelines

---

**Version**: 2.1.0  
**Last Updated**: February 3, 2026
