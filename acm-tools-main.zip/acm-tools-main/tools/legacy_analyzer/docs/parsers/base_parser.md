# Base Parser Interface

## Overview

The `BaseDependencyParser` is the abstract base class that defines the contract for all language-specific dependency parsers in the Legacy Analyzer system. It provides a consistent interface for parsing source code to extract dependencies and calculate complexity metrics.

## Purpose

The base parser interface ensures:
- **Consistency**: All parsers follow the same interface
- **Extensibility**: New language parsers can be easily added
- **Maintainability**: Common functionality is centralized
- **Testability**: Uniform testing approach across all parsers

## Class Definition

```python
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any

class BaseDependencyParser(ABC):
    """Abstract base class for language-specific dependency parsers."""
```

## Core Methods

### `parse(source_code: str) -> Dict[str, List[str]]`

**Purpose**: Extract dependencies from source code.

**Parameters**:
- `source_code` (str): The source code content to parse

**Returns**: Dictionary mapping dependency types to lists of artifact names

**Common dependency types**:
- `copybooks`: Include files, copybooks, headers
- `calls`: Called programs, functions, subroutines
- `cics_links`: CICS linked programs
- `datasets`: Dataset references
- `includes`: Included procedures or modules
- `sql_includes`: SQL include members
- `tables`: Database table references

**Example**:
```python
parser = COBOLDependencyParser()
dependencies = parser.parse(cobol_source)
# Returns: {
#     'copybooks': ['CUSTOMER-COPY', 'COMMON-FIELDS'],
#     'calls': ['VALIDATE-DATA', 'CALC-INTEREST'],
#     'cics_links': ['MENU-PROG'],
#     'tables': ['CUSTOMER', 'ACCOUNT']
# }
```

### `parse_with_complexity(source_code: str) -> Dict[str, Any]`

**Purpose**: Extract both dependencies and complexity metrics in a single pass.

**Parameters**:
- `source_code` (str): The source code content to parse

**Returns**: Dictionary containing:
- `dependencies`: Same as `parse()` method
- `complexity`: Complexity metrics (if calculator available)

**Example**:
```python
result = parser.parse_with_complexity(source_code)
# Returns: {
#     'dependencies': {...},
#     'complexity': {
#         'loc_metrics': {'loc': 150, 'comment_lines': 25},
#         'cyclomatic_complexity': 8,
#         'halstead_metrics': {...}
#     }
# }
```

### `get_supported_patterns() -> List[str]`

**Purpose**: Return list of dependency patterns this parser can detect.

**Returns**: List of pattern names

**Example**:
```python
patterns = parser.get_supported_patterns()
# Returns: ['COPY', 'CALL', 'CICS LINK', 'SQL INCLUDE']
```

### `get_supported_extensions() -> List[str]`

**Purpose**: Return list of file extensions this parser supports.

**Returns**: List of file extensions (with leading dot)

**Example**:
```python
extensions = parser.get_supported_extensions()
# Returns: ['.cbl', '.cob', '.cobol', '.cpy']
```

## Complexity Calculator Integration

Each parser can optionally include a complexity calculator:

```python
def __init__(self):
    super().__init__()
    self.complexity_calculator = LanguageComplexityCalculator()
```

The complexity calculator provides:
- **Lines of Code (LOC)**: Code, comment, blank line counts
- **Cyclomatic Complexity**: Decision point analysis
- **Halstead Metrics**: Vocabulary and volume analysis

## Implementation Guidelines

### 1. Inherit from BaseDependencyParser

```python
class MyLanguageParser(BaseDependencyParser):
    def __init__(self):
        super().__init__()
        self.complexity_calculator = MyLanguageComplexityCalculator()
```

### 2. Implement Required Methods

All abstract methods must be implemented:
- `parse()`
- `get_supported_patterns()`
- `get_supported_extensions()`

### 3. Use Consistent Return Format

Dependencies should follow standard naming conventions:
- Use lowercase with underscores: `sql_includes`, `cics_links`
- Return empty lists for missing dependency types
- Include metadata when relevant

### 4. Handle Edge Cases

- Empty or invalid source code
- Malformed syntax
- Missing dependencies
- Large files

### 5. Add Complexity Support

If complexity calculation is needed:
```python
def parse_with_complexity(self, source_code: str) -> Dict[str, Any]:
    dependencies = self.parse(source_code)
    result = {'dependencies': dependencies}
    
    if self.complexity_calculator:
        result['complexity'] = self.complexity_calculator.calculate_all_metrics(source_code)
    
    return result
```

## Error Handling

Parsers should handle errors gracefully:

```python
def parse(self, source_code: str) -> Dict[str, List[str]]:
    try:
        # Parsing logic
        return dependencies
    except Exception as e:
        # Log error and return empty dependencies
        return {
            'copybooks': [],
            'calls': [],
            'error': str(e)
        }
```

## Testing Pattern

Each parser should have comprehensive tests:

```python
def test_parse_basic_patterns():
    parser = MyLanguageParser()
    source = "COPY MYBOOK\nCALL MYPROG"
    
    result = parser.parse(source)
    
    assert 'MYBOOK' in result['copybooks']
    assert 'MYPROG' in result['calls']
```

## Integration with Parser Factory

Parsers are registered with the ParserFactory:

```python
# In parser_factory.py
ParserFactory.register_parser(
    'MYLANG',
    MyLanguageParser,
    extensions=['.myl', '.mylang']
)
```

## Performance Considerations

- **Regex Compilation**: Compile patterns in `__init__()`
- **Single Pass**: Extract all dependencies in one pass
- **Memory Efficiency**: Process large files in chunks if needed
- **Caching**: Cache compiled patterns and results when appropriate

## Common Patterns

### Pattern Compilation
```python
def __init__(self):
    super().__init__()
    self.copy_pattern = re.compile(r'COPY\s+([A-Z0-9\-]+)', re.IGNORECASE)
    self.call_pattern = re.compile(r'CALL\s+([A-Z0-9\-]+)', re.IGNORECASE)
```

### Dependency Extraction
```python
def parse(self, source_code: str) -> Dict[str, List[str]]:
    dependencies = {
        'copybooks': [],
        'calls': []
    }
    
    # Extract copybooks
    for match in self.copy_pattern.finditer(source_code):
        dependencies['copybooks'].append(match.group(1))
    
    # Extract calls
    for match in self.call_pattern.finditer(source_code):
        dependencies['calls'].append(match.group(1))
    
    return dependencies
```

### Deduplication
```python
# Remove duplicates while preserving order
dependencies['copybooks'] = list(dict.fromkeys(dependencies['copybooks']))
```

## See Also

- [Parser Factory](parser_factory.md) - Factory for creating parsers
- [COBOL Parser](cobol_parser.md) - COBOL implementation
- [JCL Parser](jcl_parser.md) - JCL implementation
- [Complexity Calculators](../complexity/README.md) - Complexity calculation