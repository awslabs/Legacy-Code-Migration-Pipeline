# JCL Parser (Job Control Language)

## Overview

The `JCLDependencyParser` extracts dependencies from JCL (Job Control Language) source code. JCL is a scripting language used on IBM mainframes to instruct the system on how to run batch jobs and manage system resources.

## Supported File Extensions

- `.jcl` - Standard JCL extension

## Dependency Patterns Detected

### Program Execution
- **EXEC PGM statements**: `//STEP1 EXEC PGM=PROGRAM1`
- **Program references**: Direct program execution

### Procedure Calls
- **EXEC PROC statements**: `//STEP1 EXEC PROC=PROCNAME`
- **Implicit procedures**: `//STEP1 EXEC PROCNAME`

### Code Inclusion
- **INCLUDE statements**: `//INCLUDE MEMBER=PROCNAME`
- **Member inclusion**: Include JCL procedures or common code

### Dataset References
- **DD DSN statements**: `//DDNAME DD DSN=DATASET.NAME`
- **Dataset dependencies**: Input and output dataset references
- **Symbolic parameters**: `&PARM` resolution in dataset names

## Example Usage

### Basic Dependency Extraction

```python
from legacy_analyzer.parsers.jcl_parser import JCLDependencyParser

parser = JCLDependencyParser()

jcl_source = """
//PAYROLL  JOB (ACCT),'PAYROLL PROCESSING',CLASS=A,MSGCLASS=X
//INCLUDE MEMBER=COMMON
//*
//STEP1    EXEC PGM=SORT
//SORTIN   DD DSN=PAYROLL.INPUT.DATA,DISP=SHR
//SORTOUT  DD DSN=PAYROLL.SORTED.DATA,DISP=(NEW,CATLG,DELETE),
//            UNIT=SYSDA,SPACE=(TRK,(100,10))
//SYSOUT   DD SYSOUT=*
//SYSIN    DD *
  SORT FIELDS=(1,6,CH,A)
/*
//*
//STEP2    EXEC PGM=PAYEDIT
//INPUT    DD DSN=PAYROLL.SORTED.DATA,DISP=SHR
//OUTPUT   DD DSN=PAYROLL.EDITED.DATA,DISP=(NEW,CATLG,DELETE)
//SYSOUT   DD SYSOUT=*
//*
//STEP3    EXEC PAYPROC
//STEP3.INPUT DD DSN=PAYROLL.EDITED.DATA,DISP=SHR
//STEP3.REPORT DD DSN=PAYROLL.REPORT,DISP=(NEW,CATLG,DELETE)
"""

dependencies = parser.parse(jcl_source)
print(dependencies)
```

**Output**:
```python
{
    'programs': ['SORT', 'PAYEDIT'],
    'procedures': ['PAYPROC'],
    'includes': ['COMMON'],
    'datasets': [
        'PAYROLL.INPUT.DATA',
        'PAYROLL.SORTED.DATA', 
        'PAYROLL.EDITED.DATA',
        'PAYROLL.REPORT'
    ]
}
```

### Complex JCL with Procedures

```python
jcl_complex = """
//BATCHJOB JOB (PROD),'BATCH PROCESSING'
//INCLUDE MEMBER=STDPROCS
//INCLUDE MEMBER=DATASETS
//*
//BACKUP   EXEC PGM=IEBGENER
//SYSUT1   DD DSN=MASTER.FILE,DISP=SHR
//SYSUT2   DD DSN=MASTER.BACKUP,DISP=(NEW,CATLG)
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DUMMY
//*
//PROCESS  EXEC PROC=STDPROC,PARM='UPDATE'
//PROCESS.INPUT DD DSN=MASTER.FILE,DISP=SHR
//PROCESS.OUTPUT DD DSN=UPDATED.FILE,DISP=(NEW,CATLG)
//*
//REPORT   EXEC PGM=REPORTER,PARM='SUMMARY'
//INPUT    DD DSN=UPDATED.FILE,DISP=SHR
//REPORT   DD DSN=DAILY.REPORT,DISP=(NEW,CATLG)
//SYSOUT   DD SYSOUT=*
"""

result = parser.parse(jcl_complex)
# Returns: {
#     'programs': ['IEBGENER', 'REPORTER'],
#     'procedures': ['STDPROC'],
#     'includes': ['STDPROCS', 'DATASETS'],
#     'datasets': ['MASTER.FILE', 'MASTER.BACKUP', 'UPDATED.FILE', 'DAILY.REPORT']
# }
```

## Advanced Features

### Symbolic Parameter Handling
Recognizes and preserves symbolic parameters in dataset names:

```jcl
//STEP1    EXEC PGM=PROGRAM1
//INPUT    DD DSN=&PREFIX..INPUT.DATA,DISP=SHR
//OUTPUT   DD DSN=&PREFIX..OUTPUT.DATA,DISP=(NEW,CATLG)
//WORK     DD DSN=&&TEMP,UNIT=SYSDA,SPACE=(TRK,10)
```

### Continuation Line Processing
Handles JCL continuation lines properly:

```jcl
//LONGDD   DD DSN=VERY.LONG.DATASET.NAME,
//            DISP=(NEW,CATLG,DELETE),
//            UNIT=SYSDA,
//            SPACE=(TRK,(100,10),RLSE),
//            DCB=(RECFM=FB,LRECL=80,BLKSIZE=8000)
```

### Procedure Step Qualification
Handles qualified DD names for procedure steps:

```jcl
//STEP1    EXEC PROC=MYPROC
//STEP1.INPUT DD DSN=INPUT.DATA,DISP=SHR
//STEP1.OUTPUT DD DSN=OUTPUT.DATA,DISP=(NEW,CATLG)
```

### Comment Filtering
Properly filters JCL comments:

```jcl
//* This is a comment line
//STEP1    EXEC PGM=PROGRAM1  * This is also a comment
//INPUT    DD DSN=DATA.FILE,DISP=SHR
```

## Real-World Example

### Input: Multi-Step Batch Job
```jcl
//CUSTPROC JOB (BATCH),'CUSTOMER PROCESSING',
//         CLASS=A,MSGCLASS=X,NOTIFY=&SYSUID
//*
//* Include common procedures and datasets
//INCLUDE MEMBER=CUSTPROCS
//INCLUDE MEMBER=DATASETS
//*
//* Step 1: Sort customer file
//SORT     EXEC PGM=SORT
//SORTIN   DD DSN=CUSTOMER.MASTER.FILE,DISP=SHR
//SORTOUT  DD DSN=CUSTOMER.SORTED.FILE,
//            DISP=(NEW,CATLG,DELETE),
//            UNIT=SYSDA,SPACE=(TRK,(500,50))
//SYSOUT   DD SYSOUT=*
//SYSIN    DD *
  SORT FIELDS=(1,10,CH,A)
/*
//*
//* Step 2: Validate customer data
//VALIDATE EXEC PGM=CUSTVAL,PARM='STRICT'
//INPUT    DD DSN=CUSTOMER.SORTED.FILE,DISP=SHR
//OUTPUT   DD DSN=CUSTOMER.VALID.FILE,DISP=(NEW,CATLG,DELETE)
//ERRORS   DD DSN=CUSTOMER.ERROR.FILE,DISP=(NEW,CATLG,DELETE)
//SYSOUT   DD SYSOUT=*
//*
//* Step 3: Update customer database
//UPDATE   EXEC PROC=DBUPDATE,
//         DB=CUSTDB,
//         TABLE=CUSTOMER
//UPDATE.INPUT DD DSN=CUSTOMER.VALID.FILE,DISP=SHR
//UPDATE.LOG   DD DSN=CUSTOMER.UPDATE.LOG,DISP=(NEW,CATLG)
//*
//* Step 4: Generate reports
//REPORTS  EXEC PGM=CUSTRPT,REGION=4M
//CUSTFILE DD DSN=CUSTOMER.MASTER.FILE,DISP=SHR
//SUMMARY  DD DSN=CUSTOMER.SUMMARY.RPT,DISP=(NEW,CATLG)
//DETAIL   DD DSN=CUSTOMER.DETAIL.RPT,DISP=(NEW,CATLG)
//SYSOUT   DD SYSOUT=*
//*
//* Step 5: Cleanup temporary files
//CLEANUP  EXEC PGM=IEFBR14
//DELETE1  DD DSN=CUSTOMER.SORTED.FILE,DISP=(OLD,DELETE)
//DELETE2  DD DSN=CUSTOMER.VALID.FILE,DISP=(OLD,DELETE)
```

### Output
```python
{
    'dependencies': {
        'programs': ['SORT', 'CUSTVAL', 'CUSTRPT', 'IEFBR14'],
        'procedures': ['DBUPDATE'],
        'includes': ['CUSTPROCS', 'DATASETS'],
        'datasets': [
            'CUSTOMER.MASTER.FILE',
            'CUSTOMER.SORTED.FILE',
            'CUSTOMER.VALID.FILE',
            'CUSTOMER.ERROR.FILE',
            'CUSTOMER.UPDATE.LOG',
            'CUSTOMER.SUMMARY.RPT',
            'CUSTOMER.DETAIL.RPT'
        ]
    }
}
```

## Integration with Static Analyzer

```python
from legacy_analyzer.static_analyzer import StaticCodeAnalyzer

analyzer = StaticCodeAnalyzer(db)

# Analyze single JCL file
result = analyzer.analyze_source_file('PAYROLL.jcl', language='JCL')

# Auto-detect in multi-language analysis
result = analyzer.analyze_directory_multi_language('src/')
if 'JCL' in result['by_language']:
    jcl_stats = result['by_language']['JCL']
    print(f"JCL: {jcl_stats['files']} files, {jcl_stats['dependencies']} deps")
```

## Dependency Type Mappings

When integrated with the static analyzer:

```python
'programs': ('PROGRAM', DependencyType.CALL),
'procedures': ('PROCEDURE', DependencyType.CALL),
'includes': ('PROCEDURE', DependencyType.COPY),
'datasets': ('DATASET', DependencyType.FILE)
```

## Supported Patterns

```python
parser.get_supported_patterns()
# Returns: [
#     'EXEC PGM',
#     'EXEC PROC',
#     'INCLUDE MEMBER',
#     'DD DSN'
# ]
```

## Common JCL Patterns

### File Processing Job
```jcl
//FILEPROC JOB (BATCH),'FILE PROCESSING'
//STEP1    EXEC PGM=SORT
//SORTIN   DD DSN=INPUT.FILE,DISP=SHR
//SORTOUT  DD DSN=SORTED.FILE,DISP=(NEW,CATLG)
//SYSIN    DD *
  SORT FIELDS=(1,10,CH,A)
/*

//STEP2    EXEC PGM=PROCESS
//INPUT    DD DSN=SORTED.FILE,DISP=SHR
//OUTPUT   DD DSN=PROCESSED.FILE,DISP=(NEW,CATLG)
```

### Procedure Usage
```jcl
//PROCJOB  JOB (BATCH),'PROCEDURE JOB'
//STEP1    EXEC PROC=COMPILE,
//         MEMBER=PROGRAM1,
//         LIB=SOURCE.LIB

//STEP2    EXEC PROC=LINKGO,
//         MEMBER=PROGRAM1,
//         LIB=OBJECT.LIB
```

### Conditional Processing
```jcl
//CONDJOB  JOB (BATCH),'CONDITIONAL JOB'
//STEP1    EXEC PGM=PROGRAM1
//INPUT    DD DSN=INPUT.FILE,DISP=SHR
//OUTPUT   DD DSN=OUTPUT.FILE,DISP=(NEW,CATLG)

//STEP2    EXEC PGM=PROGRAM2,COND=(0,NE,STEP1)
//INPUT    DD DSN=OUTPUT.FILE,DISP=SHR
//REPORT   DD DSN=FINAL.REPORT,DISP=(NEW,CATLG)
```

## Testing

The parser includes comprehensive tests:

```bash
pytest tests/test_jcl_parser.py -v
```

Test coverage includes:
- EXEC PGM statement parsing
- EXEC PROC statement parsing
- INCLUDE MEMBER statement parsing
- DD DSN statement parsing
- Continuation line handling
- Symbolic parameter preservation
- Real-world JCL jobs

## Limitations

1. **Dynamic Dataset Names**: Cannot resolve dataset names built at runtime
   ```jcl
   //STEP1    EXEC PGM=PROGRAM1
   //INPUT    DD DSN=*.STEP0.OUTPUT,DISP=SHR  /* Backward reference */
   ```

2. **Conditional Execution**: All steps treated as executed
   ```jcl
   //STEP2    EXEC PGM=PROGRAM2,COND=(0,NE,STEP1)  /* Always detected */
   ```

3. **Generation Data Groups**: GDG references not fully resolved
   ```jcl
   //INPUT    DD DSN=DATASET.GDG(+1),DISP=SHR  /* Detected as DATASET.GDG(+1) */
   ```

4. **Cataloged Procedure Expansion**: Procedures not expanded inline
   ```jcl
   //STEP1    EXEC PROC=MYPROC  /* MYPROC contents not analyzed */
   ```

## Performance

- **Parsing Speed**: ~800-1200 JCL files/second
- **Memory Usage**: Minimal overhead
- **Scalability**: Handles large JCL jobs efficiently

## Architecture Consistency

The JCL parser follows the same architectural patterns as other parsers:
- Inherits from `BaseDependencyParser`
- Implements required abstract methods
- Registered with ParserFactory
- Integrated with static analyzer

## See Also

- [Base Parser Interface](base_parser.md)
- [Parser Factory](parser_factory.md)
- [Multi-Language Analysis Guide](../../MULTI_LANGUAGE_ANALYSIS_GUIDE.md)
- [IBM JCL Documentation](https://www.ibm.com/docs/en/zos/2.4.0?topic=jcl-job-control-language)