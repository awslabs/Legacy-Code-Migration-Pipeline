# Parser Documentation

This directory contains comprehensive documentation for all language parsers in the Legacy Analyzer system.

## Overview

The Legacy Analyzer supports parsing and dependency extraction for 7 mainframe languages commonly used in enterprise environments. Each parser follows a consistent architecture based on the `BaseDependencyParser` interface and integrates seamlessly with the multi-language static analyzer.

## Supported Languages

| Language | Parser | Documentation | File Extensions |
|----------|--------|---------------|-----------------|
| **COBOL** | `COBOLDependencyParser` | [cobol_parser.md](cobol_parser.md) | `.cbl`, `.cob`, `.cobol`, `.cpy` |
| **JCL** | `JCLDependencyParser` | [jcl_parser.md](jcl_parser.md) | `.jcl` |
| **PL/I** | `PLIDependencyParser` | [pli_parser.md](pli_parser.md) | `.pli`, `.pl1`, `.inc` |
| **RPG** | `RPGDependencyParser` | [rpg_parser.md](rpg_parser.md) | `.rpg`, `.rpgle`, `.sqlrpgle`, `.rpg38`, `.mbr` |
| **Natural** | `NaturalDependencyParser` | [natural_parser.md](natural_parser.md) | `.NSP`, `.NSN`, `.NSC`, `.NSL`, `.NSG`, `.NSD`, `.NSA`, `.NS8` |
| **REXX** | `REXXDependencyParser` | [rexx_parser.md](rexx_parser.md) | `.rexx`, `.rex`, `.txt` |
| **Assembler** | `ASMDependencyParser` | [assembler_parser.md](assembler_parser.md) | `.asm`, `.mac` |

## Specialized Parsers

| Parser Type | Parser | Documentation | File Extensions |
|-------------|--------|---------------|-----------------|
| **CICS Metadata** | `CSDParser` | [csd_parser.md](csd_parser.md) | `.csd` |

## Core Components

### [Base Parser Interface](base_parser.md)
The abstract base class that defines the contract for all language parsers. Provides:
- Consistent interface for dependency extraction
- Optional complexity calculation integration
- Standard return formats and error handling

### [Parser Factory](parser_factory.md)
Centralized factory for creating and managing language parsers. Features:
- Auto-detection by file extension
- Language-based parser creation
- Dynamic parser registration
- Cross-language support

### [CSD Parser](csd_parser.md)
Specialized parser for CICS System Definition files. Features:
- CICS resource extraction (transactions, programs, files, mapsets)
- Entry point detection via CICS transactions
- File-to-dataset mapping
- CSV and JSON export capabilities

## Common Features

All parsers provide:

### Dependency Extraction
- **Program calls**: CALL statements, procedure invocations
- **Code inclusion**: COPY, INCLUDE, %INCLUDE statements
- **File references**: Dataset, table, and file dependencies
- **Cross-references**: External program and module references

### Smart Resolution
- **Dynamic calls**: Variable-to-value resolution where possible
- **Library references**: Library(member) format support
- **System filtering**: Built-in functions and keywords excluded
- **Context awareness**: Intelligent pattern matching

### Integration Support
- **Static analyzer**: Seamless integration with multi-language analysis
- **Complexity metrics**: Optional complexity calculation
- **Database loading**: Dependency storage and querying
- **Report generation**: Structured output for analysis

## Usage Patterns

### Single Language Analysis
```python
from legacy_analyzer.parsers.parser_factory import ParserFactory

# Create parser for specific language
parser = ParserFactory.create_parser('COBOL')
dependencies = parser.parse(source_code)

# With complexity metrics
result = parser.parse_with_complexity(source_code)
```

### Auto-Detection
```python
# Auto-detect parser from file extension
parser = ParserFactory.get_parser_for_file('PAYROLL.cbl')
if parser:
    dependencies = parser.parse_file('PAYROLL.cbl')
```

### Multi-Language Analysis
```python
from legacy_analyzer.static_analyzer import StaticCodeAnalyzer

analyzer = StaticCodeAnalyzer(db)
result = analyzer.analyze_directory_multi_language('src/')

# All 7 languages automatically detected and analyzed
for lang, stats in result['by_language'].items():
    print(f"{lang}: {stats['files']} files, {stats['dependencies']} deps")
```

### CICS Metadata Analysis
```python
from legacy_analyzer.parsers.csd_parser import CSDParser

# Parse CICS System Definition
parser = CSDParser()
csd_data = parser.parse_file('app/csd/CARDDEMO.csd')

# Extract entry points
entry_points = [
    t for t in csd_data.transactions 
    if t.status == 'ENABLED' and t.program_name
]

# Export to CSV
parser.to_csv(csd_data, 'cics_inventory.csv')
```

## Architecture

### Language Parser Hierarchy
```
BaseDependencyParser (Abstract)
├── COBOLDependencyParser
├── JCLDependencyParser  
├── PLIDependencyParser
├── RPGDependencyParser
├── NaturalDependencyParser
├── REXXDependencyParser
└── ASMDependencyParser
```

### Specialized Parsers
```
CSDParser (Standalone)
└── CICS System Definition parsing
```

### Complexity Calculators
Each parser can include an optional complexity calculator:
```
BaseComplexityCalculator (Abstract)
├── COBOLComplexityCalculator
├── PLIComplexityCalculator
├── NaturalComplexityCalculator
├── REXXComplexityCalculator
└── ASMComplexityCalculator
```

### Factory Registration
```python
# Parsers are registered with the factory
ParserFactory.register_parser(
    'COBOL',
    COBOLDependencyParser,
    extensions=['.cbl', '.cob', '.cobol', '.cpy']
)
```

## Language-Specific Features

### COBOL
- Dynamic CALL resolution via VALUE clauses
- CICS command parsing (LINK, START, file operations)
- SQL INCLUDE and table extraction
- Copybook inclusion with library references

### JCL
- Program execution (EXEC PGM)
- Procedure calls (EXEC PROC)
- Dataset references (DD DSN)
- Include member processing

### PL/I
- %INCLUDE statement parsing
- CICS LINK/XCTL commands
- File operation tracking
- Procedure call detection

### RPG
- Fixed and free format support
- /COPY and /INCLUDE statements
- File declarations (F-spec, DCL-F)
- SQL table extraction (with limitations)

### Natural
- CALLNAT and FETCH statements
- Data area references (USING)
- VIEW OF database mappings
- DDM file processing

### REXX
- CALL and function-style calls
- EXECIO dataset references
- ADDRESS environment commands
- Built-in function filtering

### Assembler (z/OS HLASM)
- COPY, CALL, LINK, XCTL patterns
- CSECT/DSECT detection
- System macro filtering
- z/OS-specific instruction recognition

## Testing

Each parser includes comprehensive tests:
```bash
# Run all parser tests
pytest tests/test_*_parser.py -v

# Run specific parser tests
pytest tests/test_cobol_parser.py -v
pytest tests/test_rexx_parser.py -v
pytest tests/test_asm_parser.py -v
```

## Performance

Typical parsing performance:
- **COBOL**: ~200-400 files/second
- **JCL**: ~800-1200 files/second
- **PL/I**: ~300-500 files/second
- **RPG**: ~300-500 files/second
- **Natural**: ~400-600 files/second
- **REXX**: ~500-1000 files/second
- **Assembler**: ~200-300 files/second

## Limitations

### Common Limitations
1. **Dynamic Resolution**: Limited to simple variable-to-value mappings
2. **Conditional Code**: All code paths treated as active
3. **Runtime Dependencies**: Cannot resolve dependencies determined at runtime
4. **Complex Expressions**: Pattern matching based, not full parsing

### Language-Specific Limitations
- **RPG**: Embedded SQL with C-spec continuation lines not supported
- **REXX**: `.txt` extension not auto-mapped (too generic)
- **Assembler**: IBM z/OS HLASM only (not x86/Intel assembler)

## Extension Points

### Adding New Language Parser
1. Create parser class inheriting from `BaseDependencyParser`
2. Implement required abstract methods
3. Add complexity calculator if needed
4. Register with ParserFactory
5. Add comprehensive tests
6. Document patterns and limitations

### Adding New Patterns
1. Add regex patterns to parser class
2. Implement extraction method
3. Update dependency type mappings
4. Add test cases
5. Update documentation

## Migration and Modernization

The parsers support mainframe modernization efforts by:

### Dependency Mapping
- Cross-language dependency tracking
- Call graph generation
- Impact analysis for changes
- Dead code identification

### Complexity Analysis
- Lines of code metrics
- Cyclomatic complexity
- Halstead metrics
- Maintainability assessment

### Migration Planning
- Package creation based on dependencies
- Risk assessment via complexity metrics
- Modernization candidate identification
- Legacy system understanding

## See Also

- [Multi-Language Analysis Guide](../../MULTI_LANGUAGE_ANALYSIS_GUIDE.md)
- [Static Analyzer Documentation](../static_analyzer.md)
- [Complexity Analysis Guide](../complexity/README.md)
- [Migration Planning Guide](../migration/README.md)
- [Metadata Discovery Guide](../METADATA_DISCOVERY.md)
- [Entry Point Detection Guide](../ENTRY_POINT_DETECTION.md)