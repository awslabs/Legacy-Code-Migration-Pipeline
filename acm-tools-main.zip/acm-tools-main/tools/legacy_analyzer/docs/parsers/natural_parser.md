# Natural Parser (Software AG)

## Overview

The `NaturalDependencyParser` extracts dependencies from Natural source code with **program/subprogram boundary detection**. Natural is a 4GL (Fourth Generation Language) developed by Software AG, commonly used with the Adabas database system for business application development on mainframes.

## Program-Level Enhancements

**Program/Subprogram Detection:**
- Identifies DEFINE DATA PROGRAM and DEFINE DATA SUBPROGRAM boundaries
- Extracts individual Natural program names and dependencies separately
- Handles Natural library structure and program relations

## Program Boundary Detection

The Natural parser can detect multiple programs and subprograms within Natural files:

### DEFINE DATA PROGRAM Detection
```natural
** Main Program
DEFINE DATA PROGRAM
LOCAL
1 #CUSTOMER-ID (N8)
1 #CUSTOMER-NAME (A30)
END-DEFINE

** Main program logic
READ CUSTOMER WITH CUSTOMER-ID = #CUSTOMER-ID
  CALLNAT 'VALIDATE-CUSTOMER' #CUSTOMER-ID
END-READ
END

** Subprogram in same file
DEFINE DATA SUBPROGRAM
PARAMETER
1 #INPUT-ID (N8)
LOCAL
1 #WORK-AREA (A50)
END-DEFINE

** Subprogram logic
IF #INPUT-ID > 0
  MOVE 'VALID' TO #WORK-AREA
END-IF
END
```

### Library Program Structure
```natural
** Library: CUSTLIB, Program: CUSTMAIN
DEFINE DATA PROGRAM
GLOBAL USING CUSTOMER-GDA
LOCAL
1 CUST-VIEW VIEW OF CUSTOMERS
END-DEFINE

INCLUDE CUST-VALIDATION
CALLNAT 'CUST-UPDATE' CUST-VIEW
END

** Library: CUSTLIB, Program: CUSTUPDT  
DEFINE DATA SUBPROGRAM
PARAMETER
1 CUSTOMER-REC
END-DEFINE

** Update logic
CALLNAT 'AUDIT-LOG' CUSTOMER-REC
END
```

### Program Type Classification
- **PROGRAM**: Main executable programs with DEFINE DATA PROGRAM
- **SUBPROGRAM**: Callable subprograms with DEFINE DATA SUBPROGRAM
- **COPYCODE**: Reusable code modules (no DEFINE DATA)
- **HELPROUTINE**: Helper routines and functions

### Program Metadata Extraction
For each detected program, the parser extracts:
- **Program name**: From file name or internal program identifier
- **Program type**: PROGRAM, SUBPROGRAM, COPYCODE, HELPROUTINE
- **Library context**: Natural library association
- **Start/end lines**: Precise DEFINE DATA boundaries
- **Dependencies**: Separate CALLNAT, FETCH, and USING tracking per program

hips
- Supports program type classification (PROGRAM, SUBPROGRAM, etc.)
- Maintains accurate program boundaries within Natural source files

## Supported File Extensions

- `.NSP` - Natural Program
- `.NSN` - Natural Subprogram  
- `.NSC` - Natural Copycode
- `.NSL` - Natural Local Data Area
- `.NSG` - Natural Global Data Area
- `.NSD` - Natural Data Definition Module (DDM)
- `.NSA` - Natural Application
- `.NS8` - Natural Text (8-character names)

## Dependency Patterns Detected

### Program Calls
- **CALLNAT statements**: `CALLNAT 'PROGNAME'`, `CALLNAT "PROGNAME"`
- **FETCH statements**: `FETCH 'PROGNAME'`, `FETCH RETURN 'PROGNAME'`

### Data Area References
- **USING statements**: `USING AJY00G00`, `GLOBAL USING AJY00G00`, `LOCAL USING AJY00L00`
- **Global data areas**: References to shared data structures

### Code Inclusion
- **INCLUDE statements**: `INCLUDE COPYCODE`
- **Copycode references**: Reusable code modules

### Database Access
- **VIEW OF statements**: `VIEW OF EMPLOYEES`, `1 EMPLOYEE VIEW OF EMPLOYEES`
- **Data access operations**: `READ EMPLOYEE WITH NAME`, `FIND EMPL1 WITH PERSONNEL-ID`
- **Database files**: Physical file references from DDM files

### View Definitions
- **VIEW mappings**: `1 EMPL1 VIEW OF EMPLOYEES`
- **Physical file mappings**: Logical to physical file relationships

## Example Usage

### Basic Dependency Extraction

```python
from legacy_analyzer.parsers.natural_parser import NaturalDependencyParser

parser = NaturalDependencyParser()

natural_source = """
** Natural Program - Employee Processing
DEFINE DATA
GLOBAL USING AJY00G00
LOCAL USING AJY00L00
LOCAL
1 EMPLOYEE VIEW OF EMPLOYEES
  2 PERSONNEL-ID
  2 NAME
  2 SALARY
END-DEFINE

INCLUDE COMMON-ROUTINES

READ EMPLOYEE WITH NAME = 'SMITH'
  CALLNAT 'VALIDATE-EMP' EMPLOYEE
  CALLNAT 'CALC-BONUS' EMPLOYEE.SALARY
  
  IF EMPLOYEE.SALARY > 50000
    FETCH 'HIGH-EARNER-PROC'
  END-IF
END-READ

CALLNAT 'PRINT-REPORT'
END
"""

dependencies = parser.parse(natural_source)
print(dependencies)
```

**Output**:
```python
{
    'callnats': ['VALIDATE-EMP', 'CALC-BONUS', 'PRINT-REPORT'],
    'fetches': ['HIGH-EARNER-PROC'],
    'includes': ['COMMON-ROUTINES'],
    'global_using': ['AJY00G00'],
    'local_using': ['AJY00L00'],
    'views': ['EMPLOYEES'],
    'view_definitions': [('EMPLOYEE', 'EMPLOYEES')],
    'data_access': ['EMPLOYEE']
}
```

### DDM File Processing

```python
# Example: Processing a Natural DDM (.NSD) file
ddm_source = """
* Natural Data Definition Module
* DB: 001 FILE: 011  - EMPLOYEES
* DB: 001 FILE: 012  - DEPARTMENTS
* DB: 001 FILE: 013  - PROJECTS

T L DB F     LENG S D REMARK
- - -- ----- ---- - - ------------------------
  1 01 00001 0008 A   PERSONNEL-ID
  1 01 00002 0020 A   FIRST-NAME
  1 01 00003 0020 A   LAST-NAME
  1 01 00004 0008 P   SALARY
"""

result = parser.parse(ddm_source)
# Returns: {
#     'physical_files': ['EMPLOYEES', 'DEPARTMENTS', 'PROJECTS']
# }
```

## Advanced Features

### Global vs Local Data Area Detection
Distinguishes between global and local data area usage:

```natural
DEFINE DATA
GLOBAL USING AJY00G00    /* Global data area */
LOCAL USING AJY00L00     /* Local data area */
LOCAL
1 #WORK-VAR (A10)
END-DEFINE
```

### View-to-File Mapping
Tracks logical view to physical file relationships:

```natural
DEFINE DATA
LOCAL
1 EMP-VIEW VIEW OF EMPLOYEES
  2 EMP-ID
  2 EMP-NAME
1 DEPT-VIEW VIEW OF DEPARTMENTS  
  2 DEPT-ID
  2 DEPT-NAME
END-DEFINE
```

### Database Operation Detection
Identifies various database access patterns:

```natural
READ EMPLOYEE WITH PERSONNEL-ID = '12345'
FIND DEPARTMENT WITH DEPT-ID = EMP-VIEW.DEPT-ID
HISTOGRAM EMPLOYEE FOR SALARY
```

### Copycode Inclusion
Handles Natural copycode inclusion:

```natural
INCLUDE VALIDATION-ROUTINES
INCLUDE ERROR-HANDLING
INCLUDE COMMON-FUNCTIONS
```

## Real-World Example

### Input: Employee Management Program
```natural
** EMPMAN01 - Employee Management Program
DEFINE DATA
GLOBAL USING EMPLOYEE-GDA
LOCAL USING WORK-AREAS
LOCAL
1 EMP-VIEW VIEW OF EMPLOYEES
  2 PERSONNEL-ID
  2 FIRST-NAME
  2 LAST-NAME
  2 DEPARTMENT-CODE
  2 SALARY
  2 HIRE-DATE
1 DEPT-VIEW VIEW OF DEPARTMENTS
  2 DEPT-CODE
  2 DEPT-NAME
END-DEFINE

INCLUDE SCREEN-LAYOUTS
INCLUDE VALIDATION-RULES

INPUT 'Enter Personnel ID:' #PERSONNEL-ID

READ EMP-VIEW WITH PERSONNEL-ID = #PERSONNEL-ID
  IF NO RECORDS FOUND
    CALLNAT 'ERROR-HANDLER' 'Employee not found'
    STOP
  END-NOREC
  
  FIND DEPT-VIEW WITH DEPT-CODE = EMP-VIEW.DEPARTMENT-CODE
  
  CALLNAT 'DISPLAY-EMPLOYEE' EMP-VIEW DEPT-VIEW
  
  IF EMP-VIEW.SALARY > 75000
    FETCH RETURN 'EXEC-REVIEW-PROC'
  END-IF
  
  CALLNAT 'UPDATE-EMPLOYEE' EMP-VIEW
END-READ

CALLNAT 'AUDIT-LOG' 'Employee accessed' #PERSONNEL-ID
END
```

### Output
```python
{
    'dependencies': {
        'callnats': ['ERROR-HANDLER', 'DISPLAY-EMPLOYEE', 'UPDATE-EMPLOYEE', 'AUDIT-LOG'],
        'fetches': ['EXEC-REVIEW-PROC'],
        'includes': ['SCREEN-LAYOUTS', 'VALIDATION-RULES'],
        'global_using': ['EMPLOYEE-GDA'],
        'local_using': ['WORK-AREAS'],
        'views': ['EMPLOYEES', 'DEPARTMENTS'],
        'view_definitions': [('EMP-VIEW', 'EMPLOYEES'), ('DEPT-VIEW', 'DEPARTMENTS')],
        'data_access': ['EMP-VIEW', 'DEPT-VIEW']
    }
}
```

## Integration with Static Analyzer

```python
from legacy_analyzer.static_analyzer import StaticCodeAnalyzer

analyzer = StaticCodeAnalyzer(db)

# Analyze single Natural file
result = analyzer.analyze_source_file('EMPMAN01.NSP', language='NATURAL')

# Auto-detect in multi-language analysis
result = analyzer.analyze_directory_multi_language('src/')
if 'NATURAL' in result['by_language']:
    natural_stats = result['by_language']['NATURAL']
    print(f"Natural: {natural_stats['files']} files, {natural_stats['dependencies']} deps")
```

## Dependency Type Mappings

When integrated with the static analyzer:

```python
'callnats': ('PROGRAM', DependencyType.CALL),
'fetches': ('PROGRAM', DependencyType.CALL),
'includes': ('COPYBOOK', DependencyType.COPY),
'global_using': ('DATA_AREA', DependencyType.COPY),
'local_using': ('DATA_AREA', DependencyType.COPY),
'views': ('FILE', DependencyType.FILE)
```

## Supported Patterns

```python
parser.get_supported_patterns()
# Returns: [
#     'CALLNAT',
#     'FETCH',
#     'INCLUDE',
#     'USING',
#     'VIEW OF',
#     'READ/FIND',
#     'DDM_FILES'
# ]
```

## Natural File Types

### Program Files (.NSP)
Main executable programs:
```natural
** Main program logic
DEFINE DATA
...
END-DEFINE

** Program logic here
END
```

### Subprogram Files (.NSN)
Callable subprograms:
```natural
** Subprogram - can be called via CALLNAT
DEFINE DATA
PARAMETER
1 #INPUT-PARM (A10)
1 #OUTPUT-PARM (N5)
...
END-DEFINE

** Subprogram logic here
END
```

### Copycode Files (.NSC)
Reusable code modules:
```natural
** Common validation routines
** Included via INCLUDE statement
IF #VALUE < 0
  REINPUT 'Value must be positive'
END-IF
```

### Data Area Files (.NSL, .NSG)
Data structure definitions:
```natural
** Global Data Area (.NSG)
1 #GLOBAL-COUNTER (N5)
1 #GLOBAL-DATE (D)
1 #GLOBAL-USER (A8)
```

### DDM Files (.NSD)
Database definition modules:
```natural
* DB: 001 FILE: 011  - EMPLOYEES
T L DB F     LENG S D REMARK
- - -- ----- ---- - - ------------------------
  1 01 00001 0008 A   PERSONNEL-ID
  1 01 00002 0020 A   FIRST-NAME
```

## Common Natural Patterns

### Data Definition
```natural
DEFINE DATA
GLOBAL USING GLOBAL-DATA
LOCAL USING LOCAL-WORK
LOCAL
1 CUSTOMER-VIEW VIEW OF CUSTOMERS
  2 CUSTOMER-ID
  2 CUSTOMER-NAME
  2 CREDIT-LIMIT
1 #WORK-FIELDS
  2 #COUNTER (N3)
  2 #TOTAL-AMOUNT (P7.2)
END-DEFINE
```

### Database Processing
```natural
READ CUSTOMER-VIEW WITH CUSTOMER-ID = #INPUT-ID
  IF CUSTOMER-VIEW.CREDIT-LIMIT > 10000
    CALLNAT 'HIGH-CREDIT-PROC' CUSTOMER-VIEW
  END-IF
  
  FIND ORDER-VIEW WITH CUSTOMER-ID = CUSTOMER-VIEW.CUSTOMER-ID
    CALLNAT 'PROCESS-ORDER' ORDER-VIEW
  END-FIND
END-READ
```

### Error Handling
```natural
READ EMPLOYEE WITH PERSONNEL-ID = #EMP-ID
  IF NO RECORDS FOUND
    CALLNAT 'ERROR-MSG' 'Employee not found'
    ESCAPE ROUTINE
  END-NOREC
  
  ** Process employee record
END-READ
```

## Testing

The parser includes comprehensive tests:

```bash
pytest tests/test_natural_parser.py -v
```

Test coverage includes:
- CALLNAT statement parsing
- FETCH statement detection
- USING statement parsing
- VIEW OF statement detection
- INCLUDE statement parsing
- DDM file processing
- Real-world Natural programs

## Limitations

1. **Dynamic Calls**: Cannot resolve calls through variables
   ```natural
   MOVE 'SUBPROG' TO #PROGRAM-NAME
   CALLNAT #PROGRAM-NAME  /* Cannot detect SUBPROG */
   ```

2. **Conditional Includes**: All INCLUDE statements treated as active
   ```natural
   IF #DEBUG = 'Y'
     INCLUDE DEBUG-ROUTINES  /* Always detected */
   END-IF
   ```

3. **Complex View Definitions**: Simple pattern matching only
   ```natural
   1 COMPLEX-VIEW VIEW OF EMPLOYEES
     2 REDEFINE PERSONNEL-ID
       3 EMP-PREFIX (A2)
       3 EMP-NUMBER (N6)
   ```

## Performance

- **Parsing Speed**: ~400-600 Natural files/second
- **Memory Usage**: Minimal overhead
- **Scalability**: Handles large Natural applications efficiently

## Architecture Consistency

The Natural parser follows the same architectural patterns as other parsers:
- Inherits from `BaseDependencyParser`
- Implements required abstract methods
- Registered with ParserFactory
- Integrated with static analyzer

## See Also

- [Base Parser Interface](base_parser.md)
- [Parser Factory](parser_factory.md)
- [Multi-Language Analysis Guide](../../MULTI_LANGUAGE_ANALYSIS_GUIDE.md)
- [Natural Language Documentation](https://documentation.softwareag.com/natural/)