# COBOL Parser

## Overview

The `COBOLDependencyParser` extracts dependencies and calculates complexity metrics from COBOL (Common Business-Oriented Language) source code with **enhanced copybook analysis**. COBOL is a high-level programming language primarily used in business, finance, and administrative systems on mainframes.

## Copybook Analysis Enhancements

**Executable Code Detection:**
- Analyzes copybook content to distinguish executable code from data structures
- Tracks depe

## Enhanced Copybook Analysis

The COBOL parser performs deep analysis of copybook content to identify executable code:

### Executable vs Data Copybooks
```cobol
*> Data-only copybook (CUSTOMER-RECORD.cpy)
01  CUSTOMER-RECORD.
    05  CUST-ID         PIC 9(6).
    05  CUST-NAME       PIC X(30).
    05  CUST-BALANCE    PIC S9(7)V99 COMP-3.
    05  CUST-STATUS     PIC X.

*> Executable copybook (VALIDATION-ROUTINES.cpy)
VALIDATE-CUSTOMER-ID.
    IF CUST-ID = ZEROS OR CUST-ID = SPACES
        MOVE 'INVALID ID' TO ERROR-MESSAGE
        PERFORM ERROR-ROUTINE
    END-IF.

VALIDATE-CUSTOMER-STATUS.
    IF CUST-STATUS NOT = 'A' AND NOT = 'I'
        MOVE 'INVALID STATUS' TO ERROR-MESSAGE
        PERFORM ERROR-ROUTINE
    END-IF.
```

### Copybook Dependency Tracking
```cobol
*> Main program
IDENTIFICATION DIVISION.
PROGRAM-ID. CUSTOMER-PROC.

DATA DIVISION.
WORKING-STORAGE SECTION.
COPY CUSTOMER-RECORD.        *> Data copybook
COPY ERROR-HANDLING.         *> Executable copybook

PROCEDURE DIVISION.
    COPY VALIDATION-ROUTINES.    *> Executable copybook
    
    READ CUSTOMER-FILE INTO CUSTOMER-RECORD.
    PERFORM VALIDATE-CUSTOMER-ID.    *> From copybook
    IF ERROR-FLAG = 'Y'
        PERFORM DISPLAY-ERROR        *> From copybook
    END-IF.
```

### Nested Copybook Analysis
```cobol
*> Level 1: Main program
COPY MAIN-COPYBOOK.

*> Level 2: MAIN-COPYBOOK.cpy
COPY COMMON-ROUTINES.
COPY DATA-STRUCTURES.

*> Level 3: COMMON-ROUTINES.cpy  
COPY UTILITY-FUNCTIONS.
PERFORM-STANDARD-VALIDATION.
    CALL 'VALIDATION-PROGRAM'.

*> Level 3: UTILITY-FUNCTIONS.cpy
CALCULATE-INTEREST.
    COMPUTE INTEREST = PRINCIPAL * RATE.
```

### Circular Reference Detection
```cobol
*> COPYBOOK-A.cpy
COPY COPYBOOK-B.
PERFORM ROUTINE-A.

*> COPYBOOK-B.cpy  
COPY COPYBOOK-C.
PERFORM ROUTINE-B.

*> COPYBOOK-C.cpy
COPY COPYBOOK-A.    *> Circular reference detected
PERFORM ROUTINE-C.
```

### Copybook Analysis Results
For each analyzed copybook, the parser provides:
- **Executable code detection**: Boolean flag indicating presence of executable statements
- **Confidence level**: Float (0.0-1.0) representing analysis accuracy
- **Data structures**: List of data definitions found
- **Procedure calls**: List of PERFORM statements and CALL statements found
- **Program dependencies**: Dependencies discovered within the copybook content
- **Nested includes**: Recursive analysis of included copybooks

ndencies found within included copybooks
- Handles nested copybook includes and circular reference detection
- Provides confidence scoring for executable code detection
- Maintains separate dependency tracking for copybook-contained logic

## Supported File Extensions

- `.cbl` - Standard COBOL source extension
- `.cob` - Alternative COBOL source extension
- `.cobol` - Full name COBOL extension
- `.cpy` - COBOL copybook extension

## Dependency Patterns Detected

### Copybook Inclusion
- **COPY statements**: `COPY COPYBOOK1.`, `COPY MEMBER OF LIBRARY.`
- **Library references**: `COPY MEMBER IN LIBRARY.`
- **REPLACING clause**: `COPY COPYBOOK REPLACING ==TAG== BY ==VALUE==.`

### Program Calls
- **Static CALL statements**: `CALL 'PROGRAM1'`, `CALL "PROGRAM2"`
- **Dynamic CALL statements**: `CALL WS-PROGRAM-NAME` (with variable resolution)
- **Variable resolution**: Resolves program names from VALUE clauses

### CICS Integration
- **CICS LINK**: `EXEC CICS LINK PROGRAM('PROGNAME')`
- **CICS START**: `EXEC CICS START TRANSID('TRAN1')`
- **CICS File operations**: `EXEC CICS READ FILE('FILENAME')`
- **Dynamic CICS calls**: Resolves program names from variables

### SQL Integration
- **SQL INCLUDE**: `EXEC SQL INCLUDE SQLCA`
- **Table references**: `SELECT * FROM CUSTOMER`, `UPDATE ACCOUNT SET ...`

## Example Usage

### Basic Dependency Extraction

```python
from legacy_analyzer.parsers.cobol_parser import COBOLDependencyParser

parser = COBOLDependencyParser()

cobol_source = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAYROLL.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PROGRAM-NAME     PIC X(08) VALUE 'VALIDATE'.
       01  WS-UTIL-PROG        PIC X(08) VALUE 'DATEUTIL'.
       
       COPY PAYROLL-COPY.
       COPY EMPLOYEE IN COPYLIB.
       
       PROCEDURE DIVISION.
           CALL 'CALC-PAY' USING WS-EMPLOYEE-REC.
           CALL WS-PROGRAM-NAME USING WS-DATA.
           
           EXEC CICS LINK PROGRAM('DBUPDATE')
               COMMAREA(WS-COMMAREA)
           END-EXEC.
           
           EXEC SQL
               INCLUDE SQLCA
           END-EXEC.
           
           EXEC SQL
               SELECT * FROM EMPLOYEE
               WHERE EMP_ID = :WS-EMP-ID
           END-EXEC.
           
           STOP RUN.
"""

dependencies = parser.parse(cobol_source)
print(dependencies)
```

**Output**:
```python
{
    'copybooks': ['PAYROLL-COPY', 'EMPLOYEE'],
    'calls': ['CALC-PAY', 'VALIDATE'],  # VALIDATE resolved from WS-PROGRAM-NAME
    'cics_links': ['DBUPDATE'],
    'cics_starts': [],
    'cics_files': [],
    'sql_includes': ['SQLCA'],
    'sql_tables': ['EMPLOYEE']
}
```

### With Complexity Metrics

```python
result = parser.parse_with_complexity(cobol_source)
print(f"LOC: {result['complexity']['loc_metrics']['loc']}")
print(f"Cyclomatic Complexity: {result['complexity']['cyclomatic_complexity']}")
print(f"Copybooks: {len(result['dependencies']['copybooks'])}")
```

## Dynamic Call Resolution

The parser intelligently resolves dynamic CALL statements by analyzing variable VALUE clauses:

### Variable Declaration Analysis
```cobol
WORKING-STORAGE SECTION.
01  WS-EDIT-PROGRAM     PIC X(08) VALUE 'EDITPROG'.
01  WS-CALC-PROGRAM     PIC X(08) VALUE 'CALCUTIL'.
01  WS-DB-PROGRAM       PIC X(08) VALUE 'DBACCESS'.

PROCEDURE DIVISION.
    CALL WS-EDIT-PROGRAM USING WS-DATA.     * Resolves to 'EDITPROG'
    CALL WS-CALC-PROGRAM USING WS-AMOUNT.   * Resolves to 'CALCUTIL'
    
    EXEC CICS LINK PROGRAM(WS-DB-PROGRAM)   * Resolves to 'DBACCESS'
        COMMAREA(WS-AREA)
    END-EXEC.
```

### Multi-line VALUE Declarations
```cobol
01  WS-PROGRAM-TABLE.
    05  WS-PROG-1       PIC X(08) VALUE 'PROGRAM1'.
    05  WS-PROG-2       PIC X(08) VALUE 'PROGRAM2'.
    05  WS-PROG-3       PIC X(08) VALUE 'PROGRAM3'.
```

## Complexity Metrics

The parser includes a comprehensive complexity calculator:

### Lines of Code (LOC)
- **Code lines**: Executable COBOL statements
- **Comment lines**: Lines starting with `*` in column 7
- **Blank lines**: Empty lines
- **Total lines**: All lines

### Cyclomatic Complexity
Counts decision points including:
- **IF statements**: IF-THEN-ELSE constructs
- **EVALUATE statements**: EVALUATE-WHEN-OTHER constructs
- **PERFORM loops**: PERFORM UNTIL, PERFORM VARYING
- **SEARCH statements**: SEARCH and SEARCH ALL

### Halstead Metrics
- **Operators**: COBOL verbs and operators
- **Operands**: Variables, literals, data names
- **Vocabulary**: Unique operators + operands
- **Volume**: Length × log₂(Vocabulary)
- **Difficulty**: Complexity measure
- **Effort**: Programming effort estimate

## Advanced Features

### COPY Statement Variations
Handles all COPY statement formats:

```cobol
COPY COPYBOOK.                          * Simple copy
COPY MEMBER OF LIBRARY.                 * Library reference
COPY MEMBER IN LIBRARY.                 * Alternative syntax
COPY COPYBOOK REPLACING                 * With replacement
    ==:TAG:== BY ==:VALUE:==.
```

### CICS Command Parsing
Supports various CICS command formats:

```cobol
EXEC CICS LINK PROGRAM('STATIC') END-EXEC.
EXEC CICS LINK PROGRAM(WS-PROGRAM) END-EXEC.
EXEC CICS START TRANSID('TRAN1') END-EXEC.
EXEC CICS READ FILE('CUSTOMER') INTO(WS-REC) END-EXEC.
```

### SQL Statement Processing
Extracts SQL includes and table references:

```cobol
EXEC SQL INCLUDE SQLCA END-EXEC.
EXEC SQL INCLUDE CUSTOMER-TABLE END-EXEC.

EXEC SQL
    SELECT CUST_ID, CUST_NAME
    FROM CUSTOMER
    WHERE CUST_STATUS = 'A'
END-EXEC.

EXEC SQL
    UPDATE ACCOUNT
    SET BALANCE = :WS-NEW-BALANCE
    WHERE ACCT_ID = :WS-ACCT-ID
END-EXEC.
```

## Real-World Example

### Input: Customer Processing Program
```cobol
       IDENTIFICATION DIVISION.
       PROGRAM-ID. CUSTPROC.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-EDIT-PGM         PIC X(08) VALUE 'CUSTEDIT'.
       01  WS-UPDATE-PGM       PIC X(08) VALUE 'CUSTUPDT'.
       01  WS-REPORT-PGM       PIC X(08) VALUE 'CUSTRPT'.
       
       COPY CUSTOMER-COPY.
       COPY WS-COMMON IN COPYLIB.
       
       PROCEDURE DIVISION.
       MAIN-PROCESS.
           PERFORM INITIALIZE-PROGRAM.
           
           EXEC CICS READ FILE('CUSTOMER')
               INTO(CUSTOMER-RECORD)
               RIDFLD(WS-CUSTOMER-ID)
           END-EXEC.
           
           IF CUSTOMER-STATUS = 'A'
               CALL WS-EDIT-PGM USING CUSTOMER-RECORD
               IF RETURN-CODE = ZERO
                   CALL WS-UPDATE-PGM USING CUSTOMER-RECORD
               END-IF
           ELSE
               CALL WS-REPORT-PGM USING CUSTOMER-RECORD
           END-IF.
           
           EXEC SQL
               SELECT COUNT(*)
               INTO :WS-ORDER-COUNT
               FROM ORDERS
               WHERE CUST_ID = :WS-CUSTOMER-ID
           END-SQL.
           
           EXEC CICS LINK PROGRAM('ORDPROC')
               COMMAREA(WS-ORDER-DATA)
           END-EXEC.
           
           STOP RUN.
```

### Output
```python
{
    'dependencies': {
        'copybooks': ['CUSTOMER-COPY', 'WS-COMMON'],
        'calls': ['CUSTEDIT', 'CUSTUPDT', 'CUSTRPT'],  # Resolved from variables
        'cics_links': ['ORDPROC'],
        'cics_files': ['CUSTOMER'],
        'sql_tables': ['ORDERS']
    },
    'complexity': {
        'loc_metrics': {
            'loc': 25,
            'comment_lines': 0,
            'blank_lines': 3,
            'total_lines': 28
        },
        'cyclomatic_complexity': 3,  # Base(1) + IF(1) + IF(1)
        'halstead_metrics': {
            'vocabulary': 52,
            'length': 78,
            'volume': 445.2,
            'difficulty': 15.3,
            'effort': 6811.6
        }
    }
}
```

## Integration with Static Analyzer

```python
from legacy_analyzer.static_analyzer import StaticCodeAnalyzer

analyzer = StaticCodeAnalyzer(db)

# Analyze single COBOL file
result = analyzer.analyze_source_file('PAYROLL.cbl', language='COBOL', 
                                     calculate_complexity=True)

# Auto-detect in multi-language analysis
result = analyzer.analyze_directory_multi_language('src/')
if 'COBOL' in result['by_language']:
    cobol_stats = result['by_language']['COBOL']
    print(f"COBOL: {cobol_stats['files']} files, {cobol_stats['dependencies']} deps")
```

## Dependency Type Mappings

When integrated with the static analyzer:

```python
'calls': ('PROGRAM', DependencyType.CALL),
'cics_links': ('PROGRAM', DependencyType.CICS_LINK),
'cics_starts': ('TRANSACTION', DependencyType.CICS_START),
'copybooks': ('COPYBOOK', DependencyType.COPY),
'sql_includes': ('COPYBOOK', DependencyType.SQL_INCLUDE),
'cics_files': ('FILE', DependencyType.FILE),
'sql_tables': ('TABLE', DependencyType.TABLE)
```

## Supported Patterns

```python
parser.get_supported_patterns()
# Returns: [
#     'COPY',
#     'CALL',
#     'EXEC CICS LINK',
#     'EXEC CICS START', 
#     'EXEC CICS FILE',
#     'EXEC SQL INCLUDE',
#     'SQL TABLES'
# ]
```

## Common COBOL Patterns

### File Processing
```cobol
SELECT CUSTOMER-FILE ASSIGN TO CUSTFILE.

FD  CUSTOMER-FILE.
01  CUSTOMER-RECORD.
    05  CUST-ID         PIC 9(6).
    05  CUST-NAME       PIC X(30).
    05  CUST-BALANCE    PIC S9(7)V99 COMP-3.

PROCEDURE DIVISION.
    OPEN INPUT CUSTOMER-FILE.
    PERFORM UNTIL EOF-FLAG = 'Y'
        READ CUSTOMER-FILE
            AT END MOVE 'Y' TO EOF-FLAG
            NOT AT END PERFORM PROCESS-CUSTOMER
        END-READ
    END-PERFORM.
    CLOSE CUSTOMER-FILE.
```

### Error Handling
```cobol
EXEC CICS HANDLE CONDITION
    NOTFND(NOT-FOUND-ROUTINE)
    DUPREC(DUPLICATE-ROUTINE)
END-EXEC.

EXEC CICS READ FILE('CUSTOMER')
    INTO(CUSTOMER-RECORD)
    RIDFLD(WS-CUSTOMER-ID)
END-EXEC.
```

### Structured Programming
```cobol
EVALUATE CUSTOMER-TYPE
    WHEN 'I'
        PERFORM INDIVIDUAL-PROCESSING
    WHEN 'C'
        PERFORM CORPORATE-PROCESSING
    WHEN OTHER
        PERFORM ERROR-PROCESSING
END-EVALUATE.
```

## Testing

The parser includes comprehensive tests:

```bash
pytest tests/test_cobol_parser.py -v
```

Test coverage includes:
- COPY statement parsing
- Static and dynamic CALL statements
- CICS command parsing
- SQL statement processing
- Variable resolution
- Complexity calculation
- Real-world COBOL programs

## Limitations

1. **Complex Variable Resolution**: Only handles simple VALUE clauses
   ```cobol
   01  WS-PROG-NAME    PIC X(08).
   MOVE 'PROGRAM' TO WS-PROG-NAME.
   CALL WS-PROG-NAME.  /* Cannot resolve PROGRAM */
   ```

2. **Conditional Compilation**: All code treated as active
   ```cobol
   >>IF DEBUG-MODE
       COPY DEBUG-ROUTINES.  /* Always detected */
   >>END-IF
   ```

3. **Dynamic Table Names**: Cannot resolve SQL table names from variables
   ```cobol
   MOVE 'CUSTOMER' TO WS-TABLE-NAME.
   EXEC SQL
       SELECT * FROM :WS-TABLE-NAME  /* Cannot detect CUSTOMER */
   END-EXEC.
   ```

## Performance

- **Parsing Speed**: ~200-400 COBOL files/second
- **Memory Usage**: Minimal overhead
- **Scalability**: Handles large COBOL programs efficiently

## Architecture Consistency

The COBOL parser follows the same architectural patterns as other parsers:
- Inherits from `BaseDependencyParser`
- Includes complexity calculator integration
- Implements required abstract methods
- Registered with ParserFactory
- Integrated with static analyzer

## See Also

- [Base Parser Interface](base_parser.md)
- [Parser Factory](parser_factory.md)
- [COBOL Complexity Calculator](../complexity/cobol_complexity.md)
- [Multi-Language Analysis Guide](../../MULTI_LANGUAGE_ANALYSIS_GUIDE.md)