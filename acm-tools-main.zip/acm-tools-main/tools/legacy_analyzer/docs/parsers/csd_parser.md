# CSD Parser (CICS System Definition)

## Overview

The `CSDParser` extracts CICS resource definitions from CSD (CICS System Definition) files exported via DFHCSDUP utility. Unlike the language parsers, this is a specialized metadata parser that processes CICS configuration data to identify system resources and their relationships.

## Purpose

CSD files contain critical metadata for mainframe CICS applications:
- **Entry Points**: CICS transactions serve as explicit application entry points
- **Program Mappings**: Transaction-to-program associations
- **File Mappings**: CICS file-to-dataset relationships
- **System Configuration**: Resource groups and status information

## Supported Resource Types

### TRANSACTION Definitions
CICS transaction IDs and their associated programs:
```
DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
  PROGRAM(COACTUPC)
  DESCRIPTION(CREDIT CARD DEMO ACCOUNT UPDATE)
  STATUS(ENABLED)
```

### PROGRAM Definitions
Application programs with language and execution attributes:
```
DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
  LANGUAGE(COBOL)
  STATUS(ENABLED)
  DESCRIPTION(ACCOUNT UPDATE PROGRAM)
```

### FILE Definitions
VSAM file definitions with dataset mappings:
```
DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
  DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS)
  STATUS(ENABLED)
  DESCRIPTION(ACCOUNT DATA FILE)
```

### MAPSET Definitions
BMS screen map definitions:
```
DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
  STATUS(ENABLED)
  DESCRIPTION(CREDIT CARD ACCOUNT UPDATE MAP)
```

## Data Classes

### CSDData
Container for all parsed resources:
```python
@dataclass
class CSDData:
    transactions: List[CICSTransaction]
    programs: List[CICSProgram]
    files: List[CICSFile]
    mapsets: List[CICSMapset]
    
    def get_all_resources(self) -> List[CICSResource]
```

### CICSTransaction
CICS transaction definition:
```python
@dataclass
class CICSTransaction(CICSResource):
    program_name: Optional[str] = None
    # Inherits: resource_name, resource_type, group_name, status, description
```

### CICSProgram
CICS program definition:
```python
@dataclass
class CICSProgram(CICSResource):
    language: Optional[str] = None
    transaction_id: Optional[str] = None
    # Inherits: resource_name, resource_type, group_name, status, description
```

### CICSFile
CICS file definition:
```python
@dataclass
class CICSFile(CICSResource):
    dataset_name: Optional[str] = None
    # Inherits: resource_name, resource_type, group_name, status, description
```

### CICSMapset
CICS mapset definition:
```python
@dataclass
class CICSMapset(CICSResource):
    # Inherits: resource_name, resource_type, group_name, status, description
```

## Example Usage

### Basic Parsing

```python
from legacy_analyzer.parsers.csd_parser import CSDParser

# Create parser instance
parser = CSDParser()

# Parse CSD file
csd_data = parser.parse_file('app/csd/CARDDEMO.csd')

# Access parsed resources
print(f"Found {len(csd_data.transactions)} transactions")
print(f"Found {len(csd_data.programs)} programs")
print(f"Found {len(csd_data.files)} files")
print(f"Found {len(csd_data.mapsets)} mapsets")

# List all transactions
for trans in csd_data.transactions:
    print(f"Transaction: {trans.resource_name}")
    print(f"  Program: {trans.program_name}")
    print(f"  Group: {trans.group_name}")
    print(f"  Status: {trans.status}")
```

### Parse from String Content

```python
csd_content = """
DEFINE TRANSACTION(CAUP)
  GROUP(CARDDEMO)
  PROGRAM(COACTUPC)
  DESCRIPTION(ACCOUNT UPDATE)
  STATUS(ENABLED)

DEFINE PROGRAM(COACTUPC)
  GROUP(CARDDEMO)
  LANGUAGE(COBOL)
  STATUS(ENABLED)
"""

csd_data = parser.parse(csd_content)
```

### Export to CSV

```python
# Convert to CSV with header
parser.to_csv(csd_data, 'cics_inventory.csv', include_header=True)

# CSV format:
# resource_name,resource_type,group_name,status,program_name,dataset_name,description
# CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Account Update
# COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program
```

## Advanced Features

### Streaming Parser for Large Files
For CSD files larger than 10MB:

```python
# Automatic streaming for large files
csd_data = parser.parse_file('large_csd_file.csd', use_streaming=True)

# With progress callback
def progress_callback(current, total, message):
    print(f"Progress: {current}/{total} - {message}")

csd_data = parser.parse_file(
    'large_csd_file.csd',
    use_streaming=True,
    progress_callback=progress_callback
)
```

### Caching Support
Enable caching for repeated parsing:

```python
# Enable caching with custom cache size
parser = CSDParser(enable_cache=True, cache_size=100)

# First parse - cache miss
csd_data = parser.parse_file('app/csd/CARDDEMO.csd')

# Second parse - cache hit (if file unchanged)
csd_data = parser.parse_file('app/csd/CARDDEMO.csd')
```

### Validation
Validate parsed data and get issues:

```python
# Validate and get issues
issues = parser.validate_csd_data(csd_data)

# Check for errors
if issues['errors']:
    print("Errors found:")
    for error in issues['errors']:
        print(f"  - {error}")

# Check for warnings
if issues['warnings']:
    print("Warnings found:")
    for warning in issues['warnings']:
        print(f"  - {warning}")
```

### Strict Validation Mode
Enable strict validation to fail on warnings:

```python
parser = CSDParser(strict_validation=True)

try:
    csd_data = parser.parse_file('app/csd/CARDDEMO.csd')
except CSDSyntaxError as e:
    print(f"Validation failed: {e}")
```

## Real-World Example

### Input: CARDDEMO CSD File
```
* CICS System Definition for CardDemo Application
DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
  PROGRAM(COACTUPC)
  DESCRIPTION(CREDIT CARD DEMO ACCOUNT UPDATE)
  STATUS(ENABLED)
  PRIORITY(1)

DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
  LANGUAGE(COBOL)
  STATUS(ENABLED)
  CONCURRENCY(QUASIRENT)
  DESCRIPTION(ACCOUNT UPDATE PROGRAM)

DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
  DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS)
  STATUS(ENABLED)
  OPENTIME(FIRSTREF)
  DESCRIPTION(ACCOUNT DATA FILE)

DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
  STATUS(ENABLED)
  DESCRIPTION(CREDIT CARD ACCOUNT UPDATE MAP)
```

### Output
```python
{
    'transactions': [
        CICSTransaction(
            resource_name='CAUP',
            resource_type='TRANSACTION',
            group_name='CARDDEMO',
            status='ENABLED',
            program_name='COACTUPC',
            description='CREDIT CARD DEMO ACCOUNT UPDATE'
        )
    ],
    'programs': [
        CICSProgram(
            resource_name='COACTUPC',
            resource_type='PROGRAM',
            group_name='CARDDEMO',
            status='ENABLED',
            language='COBOL',
            description='ACCOUNT UPDATE PROGRAM'
        )
    ],
    'files': [
        CICSFile(
            resource_name='ACCTDAT',
            resource_type='FILE',
            group_name='CARDDEMO',
            status='ENABLED',
            dataset_name='AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS',
            description='ACCOUNT DATA FILE'
        )
    ],
    'mapsets': [
        CICSMapset(
            resource_name='COACTUP',
            resource_type='MAPSET',
            group_name='CARDDEMO',
            status='ENABLED',
            description='CREDIT CARD ACCOUNT UPDATE MAP'
        )
    ]
}
```

## Integration with Legacy Analyzer

### Entry Point Detection
CICS transactions serve as explicit entry points:

```python
# Extract entry points from CSD data
entry_points = []
for trans in csd_data.transactions:
    if trans.status == 'ENABLED' and trans.program_name:
        entry_points.append({
            'transaction_id': trans.resource_name,
            'program': trans.program_name,
            'group': trans.group_name,
            'type': 'CICS_TRANSACTION'
        })
```

### File-to-Dataset Mapping
Map CICS files to physical datasets:

```python
# Build file-to-dataset mapping
file_mappings = {}
for file in csd_data.files:
    if file.dataset_name:
        file_mappings[file.resource_name] = file.dataset_name

# Use in dependency analysis
for file_ref in program_dependencies['files']:
    if file_ref in file_mappings:
        physical_dataset = file_mappings[file_ref]
        print(f"File {file_ref} -> Dataset {physical_dataset}")
```

### Service Grouping
Use CICS groups for service boundaries:

```python
# Group resources by CICS group
from collections import defaultdict

groups = defaultdict(list)
for resource in csd_data.get_all_resources():
    groups[resource.group_name].append(resource)

# Analyze service boundaries
for group_name, resources in groups.items():
    transactions = [r for r in resources if r.resource_type == 'TRANSACTION']
    programs = [r for r in resources if r.resource_type == 'PROGRAM']
    files = [r for r in resources if r.resource_type == 'FILE']
    
    print(f"Service Group: {group_name}")
    print(f"  Transactions: {len(transactions)}")
    print(f"  Programs: {len(programs)}")
    print(f"  Files: {len(files)}")
```

## Command Line Interface

### Convert CSD to CSV
```bash
# Convert single CSD file
legacy-analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv

# Scan directory for CSD files
legacy-analyzer metadata scan \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --convert
```

### Batch Processing
```bash
# Process multiple CSD files
for csd_file in app/csd/*.csd; do
  legacy-analyzer metadata convert-csd \
    --input "$csd_file" \
    --output "exports/$(basename "$csd_file" .csd).csv"
done
```

## Supported CSD Formats

### Multi-Line Definitions
Handles definitions spanning multiple lines:

```
DEFINE TRANSACTION(CAUP)
  GROUP(CARDDEMO)
  PROGRAM(COACTUPC)
  DESCRIPTION(CREDIT CARD DEMO -
    ACCOUNT UPDATE TRANSACTION)
  STATUS(ENABLED)
```

### Inline Attributes
Supports all attributes on one line:

```
DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO) PROGRAM(COACTUPC) STATUS(ENABLED)
```

### Mixed Case
Keywords are case-insensitive:

```
Define Transaction(CAUP)
  Group(CARDDEMO)
  Program(COACTUPC)
```

### Comments
Comments are ignored:

```
* This is a comment
* Transaction definitions for CARDDEMO application
DEFINE TRANSACTION(CAUP)
  GROUP(CARDDEMO)
```

## Performance Characteristics

### File Size Handling
- **Small files** (<10MB): In-memory parsing
- **Large files** (>10MB): Streaming parser with progress reporting
- **Very large files** (>100MB): Chunked processing with caching

### Parsing Speed
- **Typical performance**: 1000-5000 definitions/second
- **Large files**: Progress reporting every 100 definitions
- **Memory usage**: ~1MB per 1000 definitions (in-memory mode)

### Caching
- **LRU cache**: Configurable size (default: 50 files)
- **Cache key**: File path + modification time
- **Hit rate**: Typically 80-90% in development workflows

## Error Handling

### Common Issues

#### File Not Found
```python
try:
    csd_data = parser.parse_file('missing.csd')
except FileNotFoundError as e:
    print(f"File not found: {e}")
```

#### Invalid Format
```python
try:
    csd_data = parser.parse(invalid_content)
except ValueError as e:
    print(f"Parsing error: {e}")
```

#### Encoding Issues
The parser handles EBCDIC and other mainframe encodings:
```python
# Parser automatically handles encoding issues
csd_data = parser.parse_file('ebcdic_file.csd')  # Uses errors='ignore'
```

### Validation Issues

#### Missing Attributes
```
WARNING: Transaction 'CAUP' has no PROGRAM attribute at line 15
WARNING: File 'ACCTDAT' has no dataset name defined at line 42
```

#### Duplicate Resources
```
WARNING: Duplicate transaction ID: CAUP
WARNING: Duplicate program name: COACTUPC
```

#### Invalid Names
```
WARNING: Transaction ID 'LONGNAME' exceeds 4 characters at line 25
```

## Testing

The CSD parser includes comprehensive tests:

```bash
# Run CSD parser tests
pytest tests/test_csd_parser.py -v

# Run specific test
pytest tests/test_csd_parser.py::test_parse_transaction -v
```

Test coverage includes:
- All resource type parsing
- Multi-line definition handling
- Error conditions and edge cases
- Large file streaming
- Caching functionality
- Real-world CSD files

## Limitations

1. **Unsupported Resource Types**: Some CICS resources are skipped:
   - LIBRARY, TDQUEUE, TSQUEUE, JOURNAL, CONNECTION, SESSIONS, PROFILE

2. **Attribute Extraction**: Only extracts commonly used attributes:
   - Other attributes are parsed but not stored in data classes

3. **Complex Definitions**: Simple pattern matching approach:
   - Cannot handle complex nested or conditional definitions

4. **Dynamic Resources**: Cannot resolve runtime-defined resources:
   - Only processes static CSD definitions

## Architecture

### Design Patterns
- **Data Classes**: Structured resource representation
- **Streaming Parser**: Memory-efficient large file processing
- **Caching**: LRU cache for repeated parsing
- **Progress Reporting**: Callback-based progress updates

### Integration Points
- **Metadata Discovery**: Auto-discovery of CSD files in source directories
- **Entry Point Detection**: CICS transactions as application entry points
- **Inventory Loading**: Integration with inventory database
- **Report Generation**: CSV and JSON export capabilities

## See Also

- [Metadata Discovery](../METADATA_DISCOVERY.md) - Auto-discovering CSD files
- [Entry Point Detection](../ENTRY_POINT_DETECTION.md) - Using CICS metadata
- [Inventory Loading](../inventory/README.md) - Loading CSD data into database
- [CLI Reference](../CLI_REFERENCE.md) - Command-line interface