# Service Grouping

## Table of Contents

- [Overview](#overview)
- [What is Service Grouping?](#what-is-service-grouping)
- [Quick Start](#quick-start)
- [Grouping Strategies](#grouping-strategies)
- [Confidence Levels](#confidence-levels)
- [Consolidation Score](#consolidation-score)
- [Recommendations](#recommendations)
- [CLI Usage](#cli-usage)
- [Python API](#python-api)
- [Use Cases](#use-cases)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [See Also](#see-also)

---

## Overview

Service Grouping Analysis helps identify logical service boundaries for modernization planning by examining CICS metadata, data access patterns, and program dependencies. This analysis is crucial for breaking down monolithic mainframe applications into microservices or service-oriented architectures.

### Why Service Grouping?

Service grouping provides:

- **Data-Driven Service Boundaries**: Identify logical services based on actual system structure
- **Microservices Planning**: Decompose monoliths into manageable services
- **Domain-Driven Design**: Discover bounded contexts and service boundaries
- **Migration Strategy**: Prioritize and plan service migration
- **Risk Assessment**: Understand service complexity and dependencies

### Key Features

- Multiple grouping strategies (CICS GROUP, data ownership, shared programs)
- Confidence scoring (HIGH, MEDIUM, LOW)
- Consolidation score (0-100) for merge recommendations
- Integration with CICS metadata and dependency analysis
- Multiple output formats (text, JSON, CSV)

---

## What is Service Grouping?

Service grouping analyzes mainframe applications to identify logical service boundaries using multiple strategies:

1. **CICS GROUP Grouping**: Groups based on CICS System Definition groups
2. **Data Ownership Grouping**: Groups based on shared dataset access
3. **Shared Programs Grouping**: Groups based on common utility programs

Each strategy provides different insights into potential service boundaries, helping you make informed decisions about service decomposition.

---

## Quick Start

### 5-Minute Quick Start

```bash
# Step 1: Load CICS metadata
python -m tools.legacy_analyzer metadata load-from-source \
    --source-dir ./app \
    --db analyzer.db

# Step 2: Analyze source code
python -m tools.legacy_analyzer analyze \
    --source-dir ./app \
    --db analyzer.db

# Step 3: Generate service candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --output service_candidates.txt

# Step 4: Filter by confidence
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH
```

### Prerequisites

- CICS metadata loaded (for CICS GROUP grouping)
- Program dependencies analyzed
- Database with inventory and dependency data


---

## Grouping Strategies

### Strategy 1: CICS GROUP Grouping

CICS groups are logical groupings defined in the CSD (CICS System Definition) that often represent functional areas or applications. These make natural service boundaries.

**How It Works**:
1. Queries `inventory_cics` table for transactions grouped by CICS GROUP
2. Groups entry points that belong to the same CICS GROUP
3. Identifies shared data and programs within each group
4. Calculates consolidation score based on cohesion

**When to Use**:
- When CICS metadata is available
- When CICS groups align with business functions
- As a starting point for service decomposition
- For ONLINE (transaction-based) services

**Example**:

```
CICS Group: CARDDEMO
  Transactions: CAUP, CADD, CADEL, CALIST
  Programs: COACTUPC, COACTADD, COACTDEL, COACTLST
  Shared Data: ACCTDAT, CUSTDAT
  Consolidation Score: 85
  Recommendation: CONSIDER_MERGE
```

**CLI Usage**:

```bash
# Analyze CICS GROUP candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy cics-group \
    --output cics_services.txt
```

**Python API**:

```python
from tools.legacy_analyzer.analysis.service_grouping import ServiceGroupingAnalyzer

analyzer = ServiceGroupingAnalyzer('analyzer.db')

# Get CICS GROUP candidates
cics_candidates = analyzer.analyze_cics_group_candidates()

for candidate in cics_candidates:
    print(f"Service: {candidate.name}")
    print(f"  CICS Group: {candidate.cics_group}")
    print(f"  Entry Points: {len(candidate.entry_points)}")
    print(f"  Confidence: {candidate.confidence}")
    print(f"  Score: {candidate.consolidation_score}")
```

### Strategy 2: Data Ownership Grouping

Programs that access the same datasets often represent a logical service boundary. This strategy identifies programs that share data access patterns.

**How It Works**:
1. Analyzes `artifact_dependencies` table for program-to-dataset relationships
2. Finds clusters of programs that access the same datasets
3. Groups programs with significant data overlap
4. Calculates consolidation score based on shared data

**When to Use**:
- When database/dataset access patterns are well-defined
- When data ownership is a key architectural concern
- For identifying bounded contexts in Domain-Driven Design
- For data-centric services

**Example**:

```
Service: Customer Data Service
  Primary Dataset: CUSTDAT
  Programs: COUSR00C, COUSR01C, COUSR02C
  Shared Data: CUSTDAT, CUSTADDR, CUSTPHONE
  Consolidation Score: 72
  Recommendation: CONSIDER_MERGE
```

**CLI Usage**:

```bash
# Analyze data ownership candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy data-ownership \
    --output data_services.txt
```

**Python API**:

```python
# Get data ownership candidates
data_candidates = analyzer.analyze_data_ownership_candidates()

for candidate in data_candidates:
    print(f"Service: {candidate.name}")
    print(f"  Primary Dataset: {candidate.primary_dataset}")
    print(f"  Programs: {len(candidate.entry_points)}")
    print(f"  Shared Data: {len(candidate.shared_data)}")
```

### Strategy 3: Shared Programs Grouping

Entry points that call the same utility programs or subprograms may represent a logical service boundary.

**How It Works**:
1. Analyzes `artifact_dependencies` table for program-to-program CALL relationships
2. Identifies utility programs called by multiple entry points
3. Groups entry points that share significant program dependencies
4. Calculates consolidation score based on shared programs

**When to Use**:
- When utility programs represent shared business logic
- When identifying cross-cutting concerns
- For understanding code reuse patterns
- For identifying shared service layers

**Example**:

```
Service: Shared Validation Service
  Shared Programs: VALDATE, VALCUST, VALACCT
  Entry Points: COACTUPC, COACTADD, COACTDEL
  Consolidation Score: 45
  Recommendation: NEEDS_REVIEW
```

**CLI Usage**:

```bash
# Analyze shared programs candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy shared-programs \
    --output shared_services.txt
```

**Python API**:

```python
# Get shared programs candidates
shared_candidates = analyzer.analyze_shared_programs_candidates()

for candidate in shared_candidates:
    print(f"Service: {candidate.name}")
    print(f"  Shared Programs: {len(candidate.shared_programs)}")
    print(f"  Entry Points: {len(candidate.entry_points)}")
```

### Combining Strategies

Use multiple strategies together for comprehensive analysis:

```python
# Analyze all strategies
all_candidates = analyzer.analyze_all_strategies()

# Group by confidence
high_confidence = [c for c in all_candidates if c.confidence == 'HIGH']
medium_confidence = [c for c in all_candidates if c.confidence == 'MEDIUM']
low_confidence = [c for c in all_candidates if c.confidence == 'LOW']

print(f"HIGH confidence: {len(high_confidence)}")
print(f"MEDIUM confidence: {len(medium_confidence)}")
print(f"LOW confidence: {len(low_confidence)}")
```


---

## Confidence Levels

Service candidates are assigned confidence levels based on the strength of the grouping:

### HIGH Confidence

**Criteria**:
- 3+ entry points with 2+ shared resources (data or programs)
- Strong cohesion indicators
- Clear service boundary
- Consolidation score ≥ 60

**Characteristics**:
- Well-defined service boundary
- Strong data or program cohesion
- Multiple entry points
- Clear business domain

**Example**:
```
Service: Account Management Service
  Entry Points: 5
  Shared Data: 3 datasets
  Shared Programs: 4 programs
  Consolidation Score: 85
  Confidence: HIGH
  Recommendation: CONSIDER_MERGE
```

### MEDIUM Confidence

**Criteria**:
- 2+ entry points with 1+ shared resources
- Moderate cohesion indicators
- Potential service boundary
- Consolidation score 30-59

**Characteristics**:
- Moderate cohesion
- Some shared resources
- May need additional analysis
- Borderline service boundary

**Example**:
```
Service: Reporting Service
  Entry Points: 2
  Shared Data: 1 dataset
  Shared Programs: 2 programs
  Consolidation Score: 45
  Confidence: MEDIUM
  Recommendation: NEEDS_REVIEW
```

### LOW Confidence

**Criteria**:
- Few entry points or no shared resources
- Weak cohesion indicators
- Unclear service boundary
- Consolidation score < 30

**Characteristics**:
- Weak cohesion
- Limited shared resources
- May be better kept separate
- Requires manual review

**Example**:
```
Service: Utility Programs
  Entry Points: 1
  Shared Data: 0 datasets
  Shared Programs: 1 program
  Consolidation Score: 15
  Confidence: LOW
  Recommendation: KEEP_SEPARATE
```

### Filtering by Confidence

**CLI**:

```bash
# Only HIGH confidence
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH

# MEDIUM or higher
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence MEDIUM

# All candidates (default)
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db
```

**Python API**:

```python
# Filter by confidence
high_confidence = [c for c in candidates if c.confidence == 'HIGH']
medium_or_higher = [c for c in candidates if c.confidence in ['HIGH', 'MEDIUM']]
```

---

## Consolidation Score

The consolidation score (0-100) indicates the strength of the service grouping.

### Calculation

**Formula**:
```
Base Score    = min(entry_point_count × 10, 40)
Data Score    = min(shared_dataset_count × 5, 30)
Program Score = min(shared_program_count × 3, 30)

Consolidation Score = Base Score + Data Score + Program Score
```

**Components**:
- **Base Score** (0-40): Number of entry points
- **Data Score** (0-30): Number of shared datasets
- **Program Score** (0-30): Number of shared programs

### Interpretation

**80-100: Very Strong Candidate**
- High cohesion
- Multiple entry points
- Significant shared resources
- Clear service boundary
- **Action**: Strong candidate for consolidation

**60-79: Strong Candidate**
- Good cohesion
- Several entry points
- Good shared resources
- Well-defined boundary
- **Action**: Good candidate for consolidation

**40-59: Moderate Candidate**
- Moderate cohesion
- Some entry points
- Some shared resources
- Needs review
- **Action**: Manual review required

**0-39: Weak Candidate**
- Weak cohesion
- Few entry points
- Limited shared resources
- Unclear boundary
- **Action**: Consider keeping separate

### Example Calculations

**Example 1: High Score**
```
Entry Points: 5 → Base Score = 40 (capped)
Shared Data: 4 → Data Score = 20
Shared Programs: 6 → Program Score = 18

Consolidation Score = 40 + 20 + 18 = 78
Interpretation: Strong candidate
```

**Example 2: Medium Score**
```
Entry Points: 3 → Base Score = 30
Shared Data: 2 → Data Score = 10
Shared Programs: 3 → Program Score = 9

Consolidation Score = 30 + 10 + 9 = 49
Interpretation: Moderate candidate
```

**Example 3: Low Score**
```
Entry Points: 1 → Base Score = 10
Shared Data: 0 → Data Score = 0
Shared Programs: 1 → Program Score = 3

Consolidation Score = 10 + 0 + 3 = 13
Interpretation: Weak candidate
```

---

## Recommendations

Each service candidate receives a recommendation based on its consolidation score and characteristics.

### CONSIDER_MERGE

**Criteria**:
- Consolidation score ≥ 60
- 3+ entry points
- Strong cohesion

**Meaning**:
- Strong candidate for a single service
- High cohesion and clear boundaries
- Recommended for consolidation

**Action**:
- Plan as a single microservice
- Define service API
- Identify service boundaries
- Plan migration strategy

**Example**:
```
✅ CONSIDER_MERGE: Account Management Service
   Score: 85
   Entry Points: 5
   Shared Data: 3
   Shared Programs: 4
```

### NEEDS_REVIEW

**Criteria**:
- Consolidation score 30-59
- 2+ entry points
- Moderate cohesion

**Meaning**:
- Borderline case requiring manual review
- May need additional analysis
- Could go either way

**Action**:
- Review with business stakeholders
- Analyze business domain
- Consider splitting or merging
- Validate with technical team

**Example**:
```
⚠️ NEEDS_REVIEW: Reporting Service
   Score: 45
   Entry Points: 2
   Shared Data: 1
   Shared Programs: 2
```

### KEEP_SEPARATE

**Criteria**:
- Consolidation score < 30
- < 2 entry points
- Weak cohesion

**Meaning**:
- Weak cohesion
- Better as separate services or components
- Not recommended for consolidation

**Action**:
- Keep as separate services
- Consider as utility components
- May be cross-cutting concerns
- Review for potential removal

**Example**:
```
❌ KEEP_SEPARATE: Utility Programs
   Score: 15
   Entry Points: 1
   Shared Data: 0
   Shared Programs: 1
```


---

## CLI Usage

### Basic Commands

**Analyze All Strategies**:

```bash
# Generate service candidates report
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --output service_candidates.txt
```

**Filter by Confidence**:

```bash
# Only HIGH confidence candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH

# MEDIUM or higher
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence MEDIUM
```

**Specific Strategy**:

```bash
# CICS GROUP only
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy cics-group

# Data ownership only
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy data-ownership

# Shared programs only
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy shared-programs
```

### Output Formats

**Text Format (Default)**:

```bash
# Human-readable report
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --output service_candidates.txt
```

**Example Output**:
```
SERVICE GROUPING ANALYSIS REPORT
================================================================================

SERVICE CANDIDATES BY CICS GROUP: 1
--------------------------------------------------------------------------------

🟢 Carddemo Service
   Confidence:     HIGH
   Recommendation: ✅ CONSIDER_MERGE
   Entry Points:   18
   CICS Group:     CARDDEMO
   Shared Data:    5 dataset(s)
                   • ACCTDAT
                   • CUSTDAT
                   • TRANSACT
   Shared Programs: 8 program(s)
                   • CBACT01C
                   • CBACT02C
                   • CBSTATUS
   Consolidation Score: 85
```

**JSON Format**:

```bash
# Machine-readable format
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --format json \
    --output service_candidates.json
```

**Example Output**:
```json
{
  "service_candidates": [
    {
      "name": "Carddemo Service",
      "entry_points": ["COACTUPC", "COACTADD", "COACTDEL"],
      "grouping_reason": "CICS_GROUP",
      "confidence": "HIGH",
      "cics_group": "CARDDEMO",
      "shared_data": ["ACCTDAT", "CUSTDAT"],
      "shared_programs": ["CBACT01C", "CBACT02C"],
      "consolidation_score": 85,
      "recommendation": "CONSIDER_MERGE"
    }
  ],
  "summary": {
    "total_candidates": 3,
    "by_grouping_reason": {
      "CICS_GROUP": 1,
      "DATA_OWNERSHIP": 1,
      "SHARED_PROGRAMS": 1
    },
    "by_confidence": {
      "HIGH": 2,
      "MEDIUM": 1
    }
  }
}
```

**CSV Format**:

```bash
# Spreadsheet-friendly format
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --format csv \
    --output service_candidates.csv
```

### Complete Workflow

```bash
# Step 1: Load CICS metadata
python -m tools.legacy_analyzer metadata load-from-source \
    --source-dir ./app \
    --db analyzer.db

# Step 2: Analyze source code
python -m tools.legacy_analyzer analyze \
    --source-dir ./app \
    --db analyzer.db

# Step 3: Generate service candidates (all formats)
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --output service_candidates.txt

python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --format json \
    --output service_candidates.json

python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --format csv \
    --output service_candidates.csv

# Step 4: Filter by confidence
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH \
    --output high_confidence_services.txt
```

---

## Python API

### Basic Usage

```python
from tools.legacy_analyzer.analysis.service_grouping import ServiceGroupingAnalyzer

# Initialize analyzer
analyzer = ServiceGroupingAnalyzer('analyzer.db')

# Analyze all strategies
candidates = analyzer.analyze_all_strategies()

# Print results
for candidate in candidates:
    print(f"Service: {candidate.name}")
    print(f"  Strategy: {candidate.grouping_reason}")
    print(f"  Confidence: {candidate.confidence}")
    print(f"  Score: {candidate.consolidation_score}")
    print(f"  Recommendation: {candidate.recommendation}")
    print()
```

### Strategy-Specific Analysis

```python
# CICS GROUP candidates
cics_candidates = analyzer.analyze_cics_group_candidates()

# Data ownership candidates
data_candidates = analyzer.analyze_data_ownership_candidates()

# Shared programs candidates
shared_candidates = analyzer.analyze_shared_programs_candidates()
```

### Filtering and Sorting

```python
# Filter by confidence
high_confidence = [c for c in candidates if c.confidence == 'HIGH']
medium_or_higher = [c for c in candidates if c.confidence in ['HIGH', 'MEDIUM']]

# Filter by recommendation
consider_merge = [c for c in candidates if c.recommendation == 'CONSIDER_MERGE']

# Sort by consolidation score
sorted_candidates = sorted(candidates, key=lambda c: c.consolidation_score, reverse=True)

# Top 5 candidates
top_5 = sorted_candidates[:5]
```

### Detailed Analysis

```python
# Get detailed information
for candidate in high_confidence:
    print(f"\n{'='*80}")
    print(f"Service: {candidate.name}")
    print(f"{'='*80}")
    
    print(f"\nEntry Points ({len(candidate.entry_points)}):")
    for ep in candidate.entry_points:
        print(f"  • {ep}")
    
    print(f"\nShared Data ({len(candidate.shared_data)}):")
    for data in candidate.shared_data:
        print(f"  • {data}")
    
    print(f"\nShared Programs ({len(candidate.shared_programs)}):")
    for prog in candidate.shared_programs:
        print(f"  • {prog}")
    
    print(f"\nMetrics:")
    print(f"  Consolidation Score: {candidate.consolidation_score}")
    print(f"  Confidence: {candidate.confidence}")
    print(f"  Recommendation: {candidate.recommendation}")
```

### Export Results

```python
import json

# Export to JSON
candidates_dict = [c.to_dict() for c in candidates]
with open('service_candidates.json', 'w') as f:
    json.dump(candidates_dict, f, indent=2)

# Export to CSV
import csv

with open('service_candidates.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['Name', 'Strategy', 'Confidence', 'Score', 'Recommendation', 'Entry Points'])
    
    for c in candidates:
        writer.writerow([
            c.name,
            c.grouping_reason,
            c.confidence,
            c.consolidation_score,
            c.recommendation,
            len(c.entry_points)
        ])
```

### Integration with Other Tools

```python
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer

# Analyze service complexity
flow_analyzer = FlowAnalyzer(database)
complexity_analyzer = ComplexityAnalyzer(database)

for candidate in high_confidence:
    print(f"\nService: {candidate.name}")
    
    # Analyze flow for each entry point
    total_programs = set()
    for ep in candidate.entry_points:
        flow = flow_analyzer.analyze_flow(ep)
        total_programs.update(flow.programs)
    
    print(f"  Total Programs in Flows: {len(total_programs)}")
    
    # Calculate total complexity
    total_complexity = 0
    for program in total_programs:
        complexity = complexity_analyzer.analyze_program(program)
        total_complexity += complexity.total_score
    
    print(f"  Total Complexity: {total_complexity}")
    print(f"  Average Complexity: {total_complexity / len(total_programs):.2f}")
```


---

## Use Cases

### Use Case 1: Microservices Decomposition

Identify logical microservices from a monolithic mainframe application:

```bash
# Step 1: Analyze service candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH \
    --output microservices.json

# Step 2: Review HIGH confidence candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH \
    --format json \
    --output high_confidence_services.json
```

```python
# Programmatic analysis
analyzer = ServiceGroupingAnalyzer('analyzer.db')
candidates = analyzer.analyze_all_strategies()

# Filter HIGH confidence with CONSIDER_MERGE recommendation
microservices = [
    c for c in candidates 
    if c.confidence == 'HIGH' and c.recommendation == 'CONSIDER_MERGE'
]

# Generate microservice specifications
for service in microservices:
    print(f"\nMicroservice: {service.name}")
    print(f"  Entry Points: {len(service.entry_points)}")
    print(f"  Data Ownership: {', '.join(service.shared_data)}")
    print(f"  Complexity Score: {service.consolidation_score}")
```

### Use Case 2: Domain-Driven Design

Identify bounded contexts using data ownership patterns:

```bash
# Analyze data ownership candidates
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy data-ownership \
    --output bounded_contexts.txt
```

```python
# Find bounded contexts
data_candidates = analyzer.analyze_data_ownership_candidates()

# Group by primary dataset
contexts = {}
for candidate in data_candidates:
    if candidate.primary_dataset:
        if candidate.primary_dataset not in contexts:
            contexts[candidate.primary_dataset] = []
        contexts[candidate.primary_dataset].append(candidate)

# Print bounded contexts
for dataset, candidates in contexts.items():
    print(f"\nBounded Context: {dataset}")
    for candidate in candidates:
        print(f"  Service: {candidate.name}")
        print(f"  Programs: {len(candidate.entry_points)}")
```

### Use Case 3: Migration Wave Planning

Prioritize services for migration based on complexity and dependencies:

```python
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer

analyzer = ServiceGroupingAnalyzer('analyzer.db')
complexity_analyzer = ComplexityAnalyzer(database)

candidates = analyzer.analyze_all_strategies()
high_confidence = [c for c in candidates if c.confidence == 'HIGH']

# Calculate complexity for each service
service_metrics = []
for candidate in high_confidence:
    total_complexity = 0
    for program in candidate.entry_points:
        complexity = complexity_analyzer.analyze_program(program)
        total_complexity += complexity.total_score
    
    service_metrics.append({
        'name': candidate.name,
        'complexity': total_complexity,
        'programs': len(candidate.entry_points),
        'score': candidate.consolidation_score
    })

# Sort by complexity (ascending) for migration waves
sorted_services = sorted(service_metrics, key=lambda x: x['complexity'])

# Define migration waves
wave_1 = sorted_services[:3]  # Simplest services
wave_2 = sorted_services[3:6]  # Medium complexity
wave_3 = sorted_services[6:]   # Most complex

print("Migration Wave 1 (Low Complexity):")
for service in wave_1:
    print(f"  • {service['name']}: complexity={service['complexity']}")
```

### Use Case 4: API Design

Design REST APIs based on service boundaries:

```python
# Generate API specifications
candidates = analyzer.analyze_cics_group_candidates()

for candidate in candidates:
    if candidate.confidence == 'HIGH':
        print(f"\nAPI: {candidate.name}")
        print(f"Base Path: /{candidate.name.lower().replace(' ', '-')}")
        print(f"\nEndpoints:")
        
        for ep in candidate.entry_points:
            # Map entry point to REST endpoint
            endpoint = ep.lower().replace('co', '').replace('c', '')
            print(f"  POST /{endpoint}")
            print(f"    Description: {ep} transaction")
            print(f"    Request: {ep}Request")
            print(f"    Response: {ep}Response")
```

### Use Case 5: Team Organization

Organize development teams around service boundaries:

```bash
# Generate team assignments
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH \
    --format json \
    --output team_assignments.json
```

```python
# Assign teams to services
candidates = analyzer.analyze_all_strategies()
high_confidence = [c for c in candidates if c.confidence == 'HIGH']

# Calculate team size based on complexity
for i, candidate in enumerate(high_confidence, 1):
    programs = len(candidate.entry_points)
    complexity = candidate.consolidation_score
    
    # Estimate team size (1 dev per 5 programs, min 2, max 8)
    team_size = max(2, min(8, programs // 5))
    
    print(f"\nTeam {i}: {candidate.name}")
    print(f"  Size: {team_size} developers")
    print(f"  Programs: {programs}")
    print(f"  Complexity: {complexity}")
    print(f"  Entry Points: {', '.join(candidate.entry_points[:5])}")
    if len(candidate.entry_points) > 5:
        print(f"    ... and {len(candidate.entry_points) - 5} more")
```

---

## Best Practices

### 1. Start with CICS GROUP Grouping

CICS groups are often well-aligned with business functions and provide a good starting point:

```bash
# Analyze CICS GROUP candidates first
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy cics-group \
    --min-confidence HIGH
```

### 2. Validate with Data Ownership

Cross-reference CICS GROUP candidates with data ownership patterns to validate boundaries:

```python
# Compare CICS GROUP and data ownership
cics_candidates = analyzer.analyze_cics_group_candidates()
data_candidates = analyzer.analyze_data_ownership_candidates()

# Find overlaps
for cics_service in cics_candidates:
    matching_data = [
        d for d in data_candidates 
        if set(d.entry_points) & set(cics_service.entry_points)
    ]
    
    if matching_data:
        print(f"\n{cics_service.name} validated by data ownership:")
        for data_service in matching_data:
            print(f"  • {data_service.name}")
```

### 3. Review Shared Programs

Identify cross-cutting concerns and shared utilities that may need special handling:

```python
# Find shared programs across services
shared_candidates = analyzer.analyze_shared_programs_candidates()

for candidate in shared_candidates:
    if len(candidate.shared_programs) > 5:
        print(f"\nCross-cutting concern: {candidate.name}")
        print(f"  Shared by {len(candidate.entry_points)} entry points")
        print(f"  Programs: {', '.join(candidate.shared_programs)}")
```

### 4. Iterate and Refine

Service boundaries are not always clear-cut. Use the analysis as a starting point:

```python
# Iterative refinement
iteration = 1
while True:
    candidates = analyzer.analyze_all_strategies()
    high_confidence = [c for c in candidates if c.confidence == 'HIGH']
    
    print(f"\nIteration {iteration}:")
    print(f"  HIGH confidence: {len(high_confidence)}")
    
    # Review and adjust
    # ... manual review process ...
    
    if input("Continue refining? (y/n): ").lower() != 'y':
        break
    
    iteration += 1
```

### 5. Consider Multiple Strategies

Different grouping strategies may reveal different insights:

```bash
# Compare all strategies
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --output all_strategies.txt

python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy cics-group \
    --output cics_strategy.txt

python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy data-ownership \
    --output data_strategy.txt
```

### 6. Document Decisions

Document service boundary decisions and rationale:

```python
# Generate documentation
candidates = analyzer.analyze_all_strategies()

with open('service_boundaries.md', 'w') as f:
    f.write('# Service Boundary Decisions\n\n')
    
    for candidate in candidates:
        if candidate.confidence == 'HIGH':
            f.write(f'## {candidate.name}\n\n')
            f.write(f'**Decision**: {candidate.recommendation}\n\n')
            f.write(f'**Rationale**:\n')
            f.write(f'- Strategy: {candidate.grouping_reason}\n')
            f.write(f'- Confidence: {candidate.confidence}\n')
            f.write(f'- Score: {candidate.consolidation_score}\n')
            f.write(f'- Entry Points: {len(candidate.entry_points)}\n\n')
```

### 7. Validate with Stakeholders

Review service boundaries with business and technical stakeholders:

```bash
# Generate stakeholder review report
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH \
    --format json \
    --output stakeholder_review.json
```

### 8. Consider Team Structure

Align service boundaries with team structure and organizational constraints:

```python
# Consider team capacity
max_services_per_team = 3
available_teams = 5

candidates = analyzer.analyze_all_strategies()
high_confidence = [c for c in candidates if c.confidence == 'HIGH']

# Group services for teams
services_per_team = len(high_confidence) // available_teams

print(f"Recommended: {services_per_team} services per team")
```

### 9. Plan for Shared Services

Identify and plan for shared services and utilities:

```python
# Identify shared services
shared_candidates = analyzer.analyze_shared_programs_candidates()

shared_services = [
    c for c in shared_candidates 
    if len(c.entry_points) > 3 and c.confidence in ['HIGH', 'MEDIUM']
]

print(f"\nShared Services to Plan: {len(shared_services)}")
for service in shared_services:
    print(f"  • {service.name}: used by {len(service.entry_points)} services")
```

### 10. Track Evolution

Track service boundary evolution over time:

```python
import datetime
import json

# Save snapshot
timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
candidates = analyzer.analyze_all_strategies()

snapshot = {
    'timestamp': timestamp,
    'candidates': [c.to_dict() for c in candidates]
}

with open(f'service_boundaries_{timestamp}.json', 'w') as f:
    json.dump(snapshot, f, indent=2)
```


---

## Troubleshooting

### Issue: No Service Candidates Found

**Symptoms**:
- `service candidates` command returns empty list
- No candidates in any strategy
- Analysis completes but shows 0 results

**Possible Causes**:
1. No CICS metadata loaded
2. No program dependencies analyzed
3. Insufficient data for grouping
4. Database tables missing

**Solutions**:

1. **Load CICS metadata**:
```bash
python -m tools.legacy_analyzer metadata load-from-source \
    --source-dir ./app \
    --db analyzer.db
```

2. **Analyze source code**:
```bash
python -m tools.legacy_analyzer analyze \
    --source-dir ./app \
    --db analyzer.db
```

3. **Check database tables**:
```bash
sqlite3 analyzer.db ".tables"

# Should see:
# - inventory_cics
# - artifact_dependencies
# - inventory_programs
```

4. **Verify data exists**:
```sql
-- Check CICS transactions
SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION';

-- Check dependencies
SELECT COUNT(*) FROM artifact_dependencies;

-- Check programs
SELECT COUNT(*) FROM inventory_programs;
```

### Issue: Low Confidence Candidates

**Symptoms**:
- Most candidates have LOW confidence
- Few or no HIGH confidence candidates
- Weak consolidation scores

**Possible Causes**:
- Few entry points per group
- Limited shared resources
- Weak cohesion
- Fine-grained CICS groups

**Solutions**:

1. **Review grouping strategy**:
```bash
# Try different strategies
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --strategy data-ownership
```

2. **Combine related candidates**:
```python
# Manually merge related candidates
low_confidence = [c for c in candidates if c.confidence == 'LOW']

# Group by shared data
merged = {}
for candidate in low_confidence:
    for data in candidate.shared_data:
        if data not in merged:
            merged[data] = []
        merged[data].append(candidate)
```

3. **Validate with business domain knowledge**:
- Review with business stakeholders
- Understand functional boundaries
- Consider organizational structure

### Issue: Too Many Candidates

**Symptoms**:
- Dozens or hundreds of service candidates
- Difficult to review all candidates
- Many small, fragmented services

**Possible Causes**:
- Fine-grained CICS groups
- Many small programs
- Fragmented data access
- Over-decomposition

**Solutions**:

1. **Filter by confidence**:
```bash
# Focus on HIGH confidence only
python -m tools.legacy_analyzer service candidates \
    --db analyzer.db \
    --min-confidence HIGH
```

2. **Filter by recommendation**:
```python
# Only CONSIDER_MERGE recommendations
consider_merge = [
    c for c in candidates 
    if c.recommendation == 'CONSIDER_MERGE'
]
```

3. **Consolidate related candidates**:
```python
# Group by CICS group or data ownership
consolidated = {}
for candidate in candidates:
    key = candidate.cics_group or candidate.primary_dataset
    if key not in consolidated:
        consolidated[key] = []
    consolidated[key].append(candidate)
```

4. **Increase minimum thresholds**:
```python
# Custom filtering
filtered = [
    c for c in candidates 
    if c.consolidation_score >= 50 and len(c.entry_points) >= 3
]
```

### Issue: Conflicting Strategies

**Symptoms**:
- Different strategies suggest different groupings
- Same programs in multiple service candidates
- Unclear which strategy to follow

**Possible Causes**:
- Programs serve multiple purposes
- Cross-cutting concerns
- Shared utilities
- Complex dependencies

**Solutions**:

1. **Compare strategies**:
```python
# Analyze overlap
cics_candidates = analyzer.analyze_cics_group_candidates()
data_candidates = analyzer.analyze_data_ownership_candidates()

# Find programs in multiple candidates
all_programs = set()
program_count = {}

for candidate in cics_candidates + data_candidates:
    for program in candidate.entry_points:
        all_programs.add(program)
        program_count[program] = program_count.get(program, 0) + 1

# Programs in multiple candidates
shared = {p: c for p, c in program_count.items() if c > 1}
print(f"Programs in multiple candidates: {len(shared)}")
```

2. **Prioritize by confidence**:
```python
# Use highest confidence strategy
all_candidates = analyzer.analyze_all_strategies()
sorted_candidates = sorted(
    all_candidates, 
    key=lambda c: (c.confidence, c.consolidation_score),
    reverse=True
)
```

3. **Manual resolution**:
- Review with technical team
- Consider business domain
- Document decisions

### Issue: Missing Shared Resources

**Symptoms**:
- Candidates show no shared data or programs
- Expected relationships not detected
- Weak consolidation scores

**Possible Causes**:
- Incomplete dependency analysis
- Missing source files
- Parser errors
- Dynamic dependencies not detected

**Solutions**:

1. **Re-analyze dependencies**:
```bash
python -m tools.legacy_analyzer analyze \
    --source-dir ./app \
    --db analyzer.db \
    --force
```

2. **Check parser logs**:
```bash
grep "ERROR" analyzer.log
grep "WARNING" analyzer.log
```

3. **Verify source completeness**:
```bash
# Check for missing files
python -m tools.legacy_analyzer inventory check \
    --db analyzer.db \
    --source-dir ./app
```

4. **Review dynamic dependencies**:
```sql
-- Check for dynamic calls
SELECT * FROM artifact_dependencies 
WHERE dependency_type LIKE '%DYNAMIC%';
```

### Issue: Incorrect CICS Groups

**Symptoms**:
- CICS GROUP grouping produces unexpected results
- Programs grouped incorrectly
- Missing expected groups

**Possible Causes**:
- Incorrect CICS metadata
- CSD file parsing errors
- Outdated metadata

**Solutions**:

1. **Verify CICS metadata**:
```sql
-- Check CICS groups
SELECT DISTINCT group_name FROM inventory_cics 
WHERE resource_type='TRANSACTION';

-- Check program assignments
SELECT resource_name, program_name, group_name 
FROM inventory_cics 
WHERE resource_type='TRANSACTION'
ORDER BY group_name;
```

2. **Reload CICS metadata**:
```bash
# Re-export from mainframe
# Re-load into database
python -m tools.legacy_analyzer metadata load-from-source \
    --source-dir ./app \
    --db analyzer.db \
    --force
```

3. **Manual correction**:
```sql
-- Update incorrect group assignments
UPDATE inventory_cics 
SET group_name='CORRECT_GROUP' 
WHERE resource_name='TRAN01';
```

---

## See Also

### Related Documentation

- **[Entry Point Detection](../../docs/ENTRY_POINT_DETECTION.md)** - Entry point identification
- **[CICS Integration](CICS_INTEGRATION.md)** - CICS metadata integration
- **[Flow Analysis](FLOW_ANALYSIS.md)** - Program flow analysis
- **[Complexity Analysis](COMPLEXITY_ANALYSIS.md)** - Complexity assessment
- **[Migration Guide](../MIGRATION_GUIDE.md)** - Migration planning process
- **[API Reference](../API.md)** - Python API documentation
- **[CLI Reference](../CLI_REFERENCE.md)** - Command-line interface

### Related Tools

- **Service Grouping Analyzer** - `tools.legacy_analyzer.analysis.service_grouping`
- **Entry Point Detector** - `tools.legacy_analyzer.analysis.entry_point_detector`
- **Flow Analyzer** - `tools.legacy_analyzer.analysis.flow_analyzer`
- **Complexity Analyzer** - `tools.legacy_analyzer.analysis.complexity_analyzer`
- **Migration Package Builder** - `tools.legacy_analyzer.migration.package_builder`

### Examples

- **Service Grouping Example** - `examples/service_grouping_example.py`
- **Microservices Decomposition** - `examples/microservices_decomposition.py`
- **Migration Wave Planning** - `examples/migration_wave_planning.py`

### External Resources

- **Domain-Driven Design** - Eric Evans
- **Microservices Patterns** - Chris Richardson
- **Building Microservices** - Sam Newman
- **Monolith to Microservices** - Sam Newman

---

**Document Version**: 1.0  
**Last Updated**: February 2026  
**Part of**: Legacy Analyzer Documentation Suite
