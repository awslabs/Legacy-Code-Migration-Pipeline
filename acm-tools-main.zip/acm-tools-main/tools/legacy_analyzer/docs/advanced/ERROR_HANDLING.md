# Error Handling

## Table of Contents

- [Overview](#overview)
- [Error Handling Framework](#error-handling-framework)
- [Quick Start](#quick-start)
- [Error Recovery](#error-recovery)
- [Transaction Management](#transaction-management)
- [Logging](#logging)
- [Validation](#validation)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [See Also](#see-also)

---

## Overview

The Legacy Analyzer includes a comprehensive error handling and recovery framework that ensures robust analysis even when encountering malformed code, parsing errors, or system failures.

### Why Error Handling?

Error handling provides:

- **Robustness**: Continue analysis despite errors in individual files
- **Data Integrity**: Atomic operations with automatic rollback
- **Diagnostics**: Detailed logging for troubleshooting
- **Recovery**: Automatic recovery from common parsing errors
- **Validation**: Accuracy checks for analysis results

### Key Features

- Automatic error recovery for malformed program boundaries
- Transaction management with rollback capability
- Comprehensive logging with performance tracking
- Accuracy validation for program detection
- Graceful degradation and fallback strategies

---

## Error Handling Framework

The framework consists of four main components:

### 1. Error Recovery

Handles recovery from parsing errors and malformed code:

- Automatic correction of invalid program boundaries
- Generation of missing program names
- Validation of recovered data
- Fallback to file-level analysis when needed

### 2. Transaction Management

Provides atomic database operations:

- Context manager for atomic operations
- Automatic rollback on exceptions
- Transaction state tracking
- Emergency cleanup capabilities

### 3. Logging

Specialized logging for analysis operations:

- Operation timing and performance metrics
- Error logging with full context
- Recovery attempt tracking
- Configurable log levels

### 4. Validation

Validates analysis accuracy:

- Program boundary completeness checks
- Dependency reasonableness validation
- Language-specific validation rules
- Accuracy scoring and thresholds

---

## Quick Start

### 5-Minute Quick Start

```python
from tools.legacy_analyzer.enhanced_static_analyzer import EnhancedStaticCodeAnalyzer
from smf_loader.databases.sqlite_adapter import SQLiteAdapter

# Step 1: Create database adapter
db_adapter = SQLiteAdapter("analysis.db")
db_adapter.connect()

# Step 2: Create enhanced analyzer with error handling
analyzer = EnhancedStaticCodeAnalyzer(
    database=db_adapter,
    log_file="analysis.log",
    accuracy_threshold=0.8
)

# Step 3: Analyze files with automatic error handling
result = analyzer.analyze_source_file(
    file_path="program.cbl",
    language="COBOL",
    enable_program_level=True
)

# Step 4: Check results
if result.get('fallback_analysis'):
    print(f"Fallback used: {result.get('fallback_reason')}")

# Step 5: Get statistics
stats = analyzer.get_enhanced_statistics()
print(f"Success rate: {stats['combined_summary']['overall_success_rate']:.2%}")

# Step 6: Cleanup
analyzer.cleanup()
db_adapter.close()
```

### Prerequisites

- Database adapter configured
- Source files accessible
- Write permissions for log files


---

## Error Recovery

### Overview

Error recovery automatically handles common parsing errors and malformed code structures.

### Recovery Strategies

**1. Boundary Correction**

Fixes invalid program boundaries:

```python
from tools.legacy_analyzer.analysis.error_handling import (
    ProgramBoundaryErrorRecovery,
    ErrorContext
)

recovery = ProgramBoundaryErrorRecovery()

context = ErrorContext(
    operation="boundary_detection",
    file_path="program.rpg",
    language="RPG"
)

result = recovery.recover_malformed_boundaries(
    source_code=source_code,
    language="RPG",
    malformed_programs=malformed_programs,
    error_context=context
)

if result.success:
    if result.recovered_data:
        # Use recovered program boundaries
        programs = result.recovered_data
        print(f"Recovered {len(programs)} programs")
    elif result.fallback_data:
        # Use fallback strategy
        use_file_level = result.fallback_data.get('use_file_level', False)
        print("Using file-level analysis as fallback")
```

**2. Fallback to File-Level Analysis**

When program-level detection fails:

```python
# Automatic fallback in EnhancedStaticCodeAnalyzer
result = analyzer.analyze_source_file(
    file_path="complex_program.cbl",
    language="COBOL",
    enable_program_level=True
)

if result.get('fallback_analysis'):
    print(f"Fallback reason: {result.get('fallback_reason')}")
    print("Analysis completed at file level")
```

**3. Graceful Degradation**

Continue analysis with warnings:

```python
# Analysis continues even with errors
try:
    result = analyzer.analyze_source_file(file_path, language)
    
    # Check for warnings
    if 'warnings' in result:
        for warning in result['warnings']:
            print(f"Warning: {warning}")
    
    # Partial results still available
    if 'dependencies' in result:
        print(f"Found {len(result['dependencies'])} dependencies")
        
except Exception as e:
    # Only critical errors raise exceptions
    print(f"Critical error: {e}")
```

### Recovery Result Handling

```python
# Check recovery result
if recovery_result.success:
    if recovery_result.recovered_data:
        # Recovery successful
        programs = recovery_result.recovered_data
        print(f"Recovered: {len(programs)} programs")
    elif recovery_result.fallback_data:
        # Fallback strategy
        use_file_level = recovery_result.fallback_data.get('use_file_level')
        print("Using fallback strategy")
    
    # Check warnings
    if recovery_result.warnings:
        for warning in recovery_result.warnings:
            print(f"Warning: {warning}")
else:
    # Recovery failed
    print(f"Recovery failed: {recovery_result.error_message}")
```

---

## Transaction Management

### Overview

Transaction management ensures atomic database operations with automatic rollback on errors.

### Basic Usage

```python
from tools.legacy_analyzer.analysis.error_handling import TransactionManager

transaction_manager = TransactionManager(database)

# Atomic operation with automatic rollback
with transaction_manager.atomic_operation(
    "analyze_file",
    rollback_data={'file': 'test.cbl'}
) as tx_id:
    # All operations are atomic
    database.insert_rows('dependencies', dependency_data)
    database.insert_rows('inventory', inventory_data)
    database.insert_rows('programs', program_data)
    
    # Automatic commit on success
    # Automatic rollback on exception
```

### Nested Transactions

```python
# Outer transaction
with transaction_manager.atomic_operation("batch_analysis") as outer_tx:
    
    # Process multiple files
    for file_path in file_paths:
        # Inner transaction for each file
        with transaction_manager.atomic_operation(
            "analyze_file",
            rollback_data={'file': file_path}
        ) as inner_tx:
            # Analyze file
            result = analyzer.analyze_source_file(file_path, language)
            
            # Insert results
            database.insert_rows('dependencies', result['dependencies'])
```

### Manual Transaction Control

```python
# Start transaction
tx_id = transaction_manager.begin_transaction("manual_operation")

try:
    # Perform operations
    database.insert_rows('table1', data1)
    database.insert_rows('table2', data2)
    
    # Commit
    transaction_manager.commit_transaction(tx_id)
    
except Exception as e:
    # Rollback on error
    transaction_manager.rollback_transaction(tx_id)
    raise
```

### Emergency Cleanup

```python
# Force rollback all active transactions
transaction_manager.force_rollback_all()

# Check active transactions
active_txs = transaction_manager.get_active_transactions()
if active_txs:
    print(f"Warning: {len(active_txs)} active transactions")
```

---

## Logging

### Overview

Comprehensive logging with performance tracking and error context.

### Basic Logging

```python
from tools.legacy_analyzer.analysis.error_handling import (
    ProgramAnalysisLogger,
    ErrorContext,
    ErrorSeverity
)

# Create logger
logger = ProgramAnalysisLogger(
    log_file="analysis.log",
    enable_performance_logging=True
)

# Log operation
context = ErrorContext(
    operation="file_analysis",
    file_path="test.cbl",
    language="COBOL"
)

logger.log_operation_start("analyze_file", context)

# ... perform analysis ...

logger.log_operation_end(
    "analyze_file",
    success=True,
    details={"programs": 2, "dependencies": 15}
)
```

### Error Logging

```python
# Log errors with context
try:
    result = analyzer.analyze_source_file(file_path, language)
except Exception as e:
    logger.log_error_with_context(
        error=e,
        context=context,
        severity=ErrorSeverity.HIGH
    )
    raise
```

### Performance Logging

```python
# Automatic performance tracking
logger = ProgramAnalysisLogger(
    log_file="analysis.log",
    enable_performance_logging=True
)

# Operations are automatically timed
logger.log_operation_start("parse_file", context)
# ... operation ...
logger.log_operation_end("parse_file", success=True)

# View performance metrics in log file
# [2026-02-03 10:15:23] INFO: Operation 'parse_file' completed in 1.23s
```

### Log Levels

```python
import logging

# Configure log level
logger = ProgramAnalysisLogger(
    log_file="analysis.log",
    log_level=logging.DEBUG  # DEBUG, INFO, WARNING, ERROR, CRITICAL
)

# Different severity levels
logger.log_error_with_context(e, context, ErrorSeverity.LOW)     # WARNING
logger.log_error_with_context(e, context, ErrorSeverity.MEDIUM)  # ERROR
logger.log_error_with_context(e, context, ErrorSeverity.HIGH)    # CRITICAL
```

### Custom Log Messages

```python
# Log custom messages
logger.logger.info("Starting batch analysis")
logger.logger.warning("File not found, skipping")
logger.logger.error("Database connection failed")
```


---

## Validation

### Overview

Validation ensures accuracy of program detection and dependency tracking.

### Basic Validation

```python
from tools.legacy_analyzer.analysis.error_handling import (
    ProgramBoundaryAccuracyValidator
)

# Create validator
validator = ProgramBoundaryAccuracyValidator(accuracy_threshold=0.8)

# Validate program detection
result = validator.validate_program_detection_accuracy(
    file_path="test.rpg",
    source_code=source_code,
    language="RPG",
    detected_programs=programs,
    program_dependencies=dependencies
)

# Check validation result
if result.is_valid:
    print(f"Validation passed (score: {result.accuracy_score:.2%})")
else:
    print(f"Validation failed:")
    for error in result.errors:
        print(f"  • {error}")
    
    for warning in result.warnings:
        print(f"  ⚠ {warning}")
```

### Validation Checks

**1. Boundary Completeness**

Ensures all programs have valid boundaries:

```python
# Checks performed:
# - Start line < end line
# - Lines within file bounds
# - No overlapping boundaries
# - Program names are valid
```

**2. Dependency Reasonableness**

Validates dependency relationships:

```python
# Checks performed:
# - Dependencies reference valid programs
# - No self-dependencies
# - Dependency types are valid
# - Line numbers are reasonable
```

**3. Language-Specific Rules**

Applies language-specific validation:

```python
# COBOL: Check PROCEDURE DIVISION
# RPG: Check procedure boundaries
# PL/I: Check procedure blocks
# JCL: Check EXEC statements
```

### Validation Statistics

```python
# Get validation summary
summary = validator.get_validation_summary()

print(f"Total validations: {summary['total_validations']}")
print(f"Passed: {summary['passed']}")
print(f"Failed: {summary['failed']}")
print(f"Pass rate: {summary['pass_rate']:.2%}")
print(f"Average score: {summary['average_score']:.2%}")
```

### Custom Validation Thresholds

```python
# Strict validation (90% accuracy required)
strict_validator = ProgramBoundaryAccuracyValidator(accuracy_threshold=0.9)

# Lenient validation (70% accuracy required)
lenient_validator = ProgramBoundaryAccuracyValidator(accuracy_threshold=0.7)

# Adjust threshold dynamically
validator.accuracy_threshold = 0.85
```

---

## Best Practices

### 1. Always Use Transactions

```python
# Good: Atomic operations
with transaction_manager.atomic_operation("bulk_insert") as tx_id:
    database.insert_rows('table1', data1)
    database.insert_rows('table2', data2)

# Bad: Manual transaction management
database.begin_transaction()
try:
    database.insert_rows('table1', data1)
    database.insert_rows('table2', data2)
    database.commit()
except:
    database.rollback()
```

### 2. Provide Rich Error Context

```python
# Good: Detailed context
context = ErrorContext(
    operation="program_detection",
    file_path=file_path,
    language=language,
    program_name=program_name,
    line_number=line_number,
    additional_info={"parser_version": "2.0"}
)

# Bad: Minimal context
context = ErrorContext(operation="analysis")
```

### 3. Handle Recovery Results

```python
# Good: Check and act on recovery results
recovery_result = error_recovery.recover_malformed_boundaries(...)

if recovery_result.success:
    if recovery_result.recovered_data:
        programs = recovery_result.recovered_data
    elif recovery_result.fallback_data:
        use_file_level = True
else:
    raise AnalysisError(recovery_result.error_message)

# Bad: Ignore recovery results
error_recovery.recover_malformed_boundaries(...)
# Continue without checking
```

### 4. Monitor Performance and Accuracy

```python
# Regular monitoring
stats = analyzer.get_enhanced_statistics()
success_rate = stats['combined_summary']['overall_success_rate']

if success_rate < 0.9:
    print("Warning: Low success rate")
    
    # Check validation
    validation_summary = stats['enhanced_statistics']['validation_summary']
    if validation_summary['pass_rate'] < 0.8:
        print("Consider adjusting accuracy threshold")
```

### 5. Use Appropriate Log Levels

```python
# Production: INFO or WARNING
logger = ProgramAnalysisLogger(log_file="prod.log", log_level=logging.INFO)

# Development: DEBUG
logger = ProgramAnalysisLogger(log_file="dev.log", log_level=logging.DEBUG)

# Troubleshooting: DEBUG with performance logging
logger = ProgramAnalysisLogger(
    log_file="debug.log",
    log_level=logging.DEBUG,
    enable_performance_logging=True
)
```

### 6. Clean Up Resources

```python
# Always cleanup
try:
    analyzer = EnhancedStaticCodeAnalyzer(database, log_file="analysis.log")
    result = analyzer.analyze_source_file(file_path, language)
finally:
    analyzer.cleanup()
    database.close()
```

### 7. Handle Validation Failures

```python
# Check validation and take action
validation_result = validator.validate_program_detection_accuracy(...)

if not validation_result.is_valid:
    if validation_result.accuracy_score < 0.5:
        # Critical failure - use fallback
        use_file_level_analysis = True
    else:
        # Partial success - log warnings and continue
        for warning in validation_result.warnings:
            logger.logger.warning(warning)
```

### 8. Batch Operations with Error Handling

```python
# Process multiple files with error handling
results = []
errors = []

for file_path in file_paths:
    try:
        with transaction_manager.atomic_operation("analyze_file") as tx_id:
            result = analyzer.analyze_source_file(file_path, language)
            results.append(result)
    except Exception as e:
        errors.append({'file': file_path, 'error': str(e)})
        logger.log_error_with_context(e, context, ErrorSeverity.MEDIUM)

# Report summary
print(f"Processed: {len(results)}/{len(file_paths)}")
print(f"Errors: {len(errors)}")
```

### 9. Use Factory for Consistent Setup

```python
from tools.legacy_analyzer.analysis.error_handling import create_error_handler

# Create complete error handling suite
error_recovery, transaction_manager, logger, validator = create_error_handler(
    database=db_adapter,
    log_file="analysis.log",
    accuracy_threshold=0.8
)

# All components configured consistently
```

### 10. Test Error Handling

```python
# Test error recovery
def test_error_recovery():
    # Create malformed data
    malformed_programs = [
        {'name': '', 'start_line': 100, 'end_line': 50}  # Invalid
    ]
    
    # Test recovery
    result = error_recovery.recover_malformed_boundaries(
        source_code=source_code,
        language="COBOL",
        malformed_programs=malformed_programs,
        error_context=context
    )
    
    assert result.success
    assert len(result.recovered_data) > 0
```

---

## Troubleshooting

### Issue: High Transaction Rollback Rate

**Symptoms**:
- Many transactions being rolled back
- Database operations failing frequently
- Data inconsistency warnings

**Possible Causes**:
- Database connection instability
- Incorrect database schema
- Concurrent access conflicts
- Insufficient permissions

**Solutions**:

1. **Check database connection**:
```python
# Test connection
try:
    database.execute("SELECT 1")
    print("Database connection OK")
except Exception as e:
    print(f"Database connection failed: {e}")
```

2. **Verify schema**:
```bash
# Check tables exist
sqlite3 analyzer.db ".schema"
```

3. **Monitor active transactions**:
```python
active_txs = transaction_manager.get_active_transactions()
print(f"Active transactions: {len(active_txs)}")
```

4. **Force cleanup if needed**:
```python
transaction_manager.force_rollback_all()
```

### Issue: Low Validation Pass Rate

**Symptoms**:
- Most validations failing
- Low accuracy scores
- Many validation warnings

**Possible Causes**:
- Accuracy threshold too high
- Program boundary detection issues
- Source code quality problems
- Language-specific parsing errors

**Solutions**:

1. **Adjust accuracy threshold**:
```python
# Lower threshold temporarily
validator.accuracy_threshold = 0.7
```

2. **Check validation details**:
```python
result = validator.validate_program_detection_accuracy(...)
print(f"Score: {result.accuracy_score:.2%}")
print(f"Errors: {result.errors}")
print(f"Warnings: {result.warnings}")
```

3. **Review program boundaries**:
```python
for program in detected_programs:
    print(f"{program['name']}: lines {program['start_line']}-{program['end_line']}")
```

### Issue: Frequent Fallbacks to File-Level

**Symptoms**:
- Most files using fallback analysis
- Program-level detection rarely succeeds
- Many "fallback_analysis" flags in results

**Possible Causes**:
- Program boundary detection not working
- Language-specific parser issues
- Complex or non-standard code structure

**Solutions**:

1. **Check fallback reasons**:
```python
result = analyzer.analyze_source_file(file_path, language)
if result.get('fallback_analysis'):
    print(f"Fallback reason: {result.get('fallback_reason')}")
```

2. **Review parser logs**:
```bash
grep "fallback" analysis.log
grep "ERROR" analysis.log
```

3. **Test program detection**:
```python
# Test boundary detection directly
from tools.legacy_analyzer.parsers import get_parser

parser = get_parser(language)
programs = parser.detect_program_boundaries(source_code)
print(f"Detected {len(programs)} programs")
```

### Issue: Memory Issues with Large Files

**Symptoms**:
- Out of memory errors
- Slow performance on large files
- System becomes unresponsive

**Solutions**:

1. **Process files in batches**:
```python
# Process in smaller batches
batch_size = 100
for i in range(0, len(file_paths), batch_size):
    batch = file_paths[i:i+batch_size]
    process_batch(batch)
```

2. **Use streaming for large files**:
```python
# Read file in chunks
def process_large_file(file_path):
    with open(file_path, 'r') as f:
        while True:
            chunk = f.read(1024 * 1024)  # 1MB chunks
            if not chunk:
                break
            process_chunk(chunk)
```

3. **Monitor memory usage**:
```python
import psutil
import os

process = psutil.Process(os.getpid())
memory_mb = process.memory_info().rss / 1024 / 1024
print(f"Memory usage: {memory_mb:.2f} MB")
```

### Issue: Logging Performance Impact

**Symptoms**:
- Analysis slower than expected
- Large log files
- Disk I/O bottleneck

**Solutions**:

1. **Reduce log level**:
```python
# Use INFO instead of DEBUG
logger = ProgramAnalysisLogger(
    log_file="analysis.log",
    log_level=logging.INFO
)
```

2. **Disable performance logging**:
```python
logger = ProgramAnalysisLogger(
    log_file="analysis.log",
    enable_performance_logging=False
)
```

3. **Use log rotation**:
```python
import logging.handlers

handler = logging.handlers.RotatingFileHandler(
    "analysis.log",
    maxBytes=10*1024*1024,  # 10MB
    backupCount=5
)
```

---

## See Also

### Related Documentation

- **[Flow Analysis](FLOW_ANALYSIS.md)** - Program flow analysis
- **[Complexity Analysis](COMPLEXITY_ANALYSIS.md)** - Complexity assessment
- **[PARSERS](../PARSERS.md)** - Language parser reference
- **[API Reference](../API.md)** - Python API documentation
- **[CLI Reference](../CLI_REFERENCE.md)** - Command-line interface

### Related Tools

- **Enhanced Static Analyzer** - `tools.legacy_analyzer.enhanced_static_analyzer`
- **Error Recovery** - `tools.legacy_analyzer.analysis.error_handling`
- **Transaction Manager** - `tools.legacy_analyzer.analysis.error_handling`
- **Program Analysis Logger** - `tools.legacy_analyzer.analysis.error_handling`

### Examples

- **Error Handling Tests** - `tmpscripts/test_error_handling.py`
- **Integration Tests** - `tmpscripts/integration_test_error_handling.py`

---

**Document Version**: 1.0  
**Last Updated**: February 2026  
**Part of**: Legacy Analyzer Documentation Suite
