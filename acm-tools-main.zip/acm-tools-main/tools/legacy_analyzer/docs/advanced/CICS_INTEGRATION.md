# CICS Integration

## Table of Contents

- [Overview](#overview)
- [Why CICS Metadata Matters](#why-cics-metadata-matters)
- [Quick Start](#quick-start)
- [Integration Workflows](#integration-workflows)
- [CSD File Parsing](#csd-file-parsing)
- [Metadata Discovery](#metadata-discovery)
- [Entry Point Detection](#entry-point-detection)
- [Transaction Reports](#transaction-reports)
- [Service Grouping](#service-grouping)
- [Reconciliation](#reconciliation)
- [Database Schema](#database-schema)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [See Also](#see-also)

---

## Overview

CICS (Customer Information Control System) Integration enables the Legacy Analyzer to parse and integrate CICS System Definition (CSD) files and other mainframe metadata to provide comprehensive analysis for modernization planning.

### What is CICS Integration?

CICS Integration provides:

- **Explicit Entry Point Detection**: Identify CICS transactions (ONLINE) vs batch jobs (BATCH) vs inferred entry points
- **Transaction-to-Program Mapping**: Map 4-character transaction IDs to programs for API endpoint planning
- **Confidence Scoring**: Distinguish EXPLICIT (from metadata) vs INFERRED (from code analysis) entry points
- **Dataset Relationships**: Link CICS file definitions to MVS datasets for data flow analysis
- **Service Boundaries**: Use CICS GROUP definitions to identify logical service boundaries
- **Modernization Planning**: Generate API endpoint suggestions and service grouping recommendations

### Key Features

- Parse CICS System Definition (CSD) files
- Extract TRANSACTION, PROGRAM, FILE, and MAPSET definitions
- Auto-discover CSD and CSV files in source directories
- Enhanced entry point detection with confidence levels
- Comprehensive transaction reports with call trees and complexity
- Service grouping analysis for microservices planning
- Metadata reconciliation for data quality validation

---

## Why CICS Metadata Matters

Traditional code analysis can only infer entry points by finding programs that aren't called by others. With CICS metadata integration, you get:

| Without Metadata | With Metadata |
|------------------|---------------|
| ❓ Guessed entry points | ✅ Explicit CICS transactions |
| ❓ Unknown transaction IDs | ✅ Transaction-to-program mapping |
| ❓ Inferred confidence only | ✅ EXPLICIT vs INFERRED confidence |
| ❓ No dataset mappings | ✅ File-to-dataset relationships |
| ❓ Unclear service boundaries | ✅ CICS GROUP-based grouping |


### Benefits of CICS Integration

**For Migration Planning:**
- Map transaction IDs to RESTful API endpoints
- Identify service boundaries using CICS GROUPs
- Understand data dependencies for each transaction
- Prioritize migration based on complexity and dependencies

**For Analysis:**
- Explicit entry point identification (no guessing)
- Complete call tree analysis from transaction entry
- Data lineage tracking (CICS files to MVS datasets)
- Confidence scoring for all entry points

**For Documentation:**
- Comprehensive transaction inventory
- Transaction-to-program mappings
- API endpoint suggestions
- Service grouping recommendations

---

## Quick Start

### 5-Minute Quick Start

Get started with CICS integration in 5 minutes:

```bash
# Step 1: Discover and load CICS metadata (one command)
python -m tools.legacy_analyzer metadata load-from-source \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --db analysis.db \
  --keep-csv exports/cics_inventory.csv

# Step 2: Analyze source code
python -m tools.legacy_analyzer analyze \
  --source-dir ./examples/code/cobol/carddemoV2/app \
  --db analysis.db

# Step 3: Generate entry points report with CICS metadata
python -m tools.legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --format json \
  --output entry_points/entry_points.json
```

**Result**: Entry points categorized as ONLINE (CICS), BATCH (JCL), or INFERRED with confidence levels!

### Prerequisites

Before using CICS integration:

- Python 3.8 or higher
- Legacy Analyzer installed
- Access to CSD files or ability to export from mainframe
- Source code for dependency analysis (optional but recommended)

---

## Integration Workflows

Choose the workflow that best fits your environment:

### Workflow Decision Tree

```
Do you have mainframe access?
├─ YES: Can you run REXX scripts?
│  ├─ YES → Workflow A: REXX Export (Recommended)
│  └─ NO  → Workflow B: CSD Conversion
└─ NO: Do you have CSD files?
   ├─ YES → Workflow C: Integrated Automated
   └─ NO  → Export CSD using DFHCSDUP, then use B or C
```

### Workflow A: Mainframe REXX Export (Recommended)

**Best for**: Production environments with mainframe access

**Advantages**:
- ✅ Most accurate (direct from CICS)
- ✅ Enhanced CSV format with all metadata
- ✅ Can be automated for regular exports
- ✅ Includes descriptions, languages, datasets

**Process**:

1. Upload REXX script to mainframe
2. Run script to extract CICS definitions
3. Download enhanced CSV file
4. Load into database

```bash
# On mainframe (TSO)
TSO %EXTRACT_CICS_CSD

# Download CSV
sftp user@mainframe.company.com
get 'EXPORT.CICS.INVENTORY.CSV' cics_inventory.csv

# Load into database
python -m tools.legacy_analyzer load \
  --type cics \
  --file cics_inventory.csv \
  --db analysis.db
```

**REXX Script Location**: `tools/legacy_analyzer/inventory/exporters/rexx/EXTRACT_CICS_CSD.rexx`


### Workflow B: CSD File Conversion

**Best for**: Environments with CSD files but no mainframe access

**Advantages**:
- ✅ Works with offline CSD files
- ✅ No mainframe access required
- ✅ Can process historical CSD snapshots
- ✅ Validates CSD content before loading

**Process**:

```bash
# Step 1: Convert CSD to CSV
python -m tools.legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv

# Step 2: Load CSV into database
python -m tools.legacy_analyzer load \
  --type cics \
  --file exports/cics_inventory.csv \
  --db analysis.db
```

### Workflow C: Integrated Automated (One Command)

**Best for**: Automated pipelines and fastest workflow

**Advantages**:
- ✅ Fastest workflow (one command)
- ✅ Auto-discovers CSD files
- ✅ Converts and loads automatically
- ✅ Perfect for CI/CD integration

**Process**:

```bash
# One command does everything
python -m tools.legacy_analyzer metadata load-from-source \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --db analysis.db \
  --keep-csv exports/cics_inventory.csv
```

**What it does**:
1. Scans source directory for CSD files
2. Parses CSD files
3. Converts to enhanced CSV format
4. Loads into database
5. Optionally saves CSV for review

### Workflow Comparison

| Feature | Workflow A | Workflow B | Workflow C |
|---------|-----------|-----------|-----------|
| **Environment** | Mainframe | CSD files | Local files |
| **Complexity** | Medium | Low | Lowest |
| **Speed** | Fast | Medium | Fastest |
| **Accuracy** | Highest | High | High |
| **Automation** | Schedulable | Manual | Automated |
| **Setup Time** | 30-60 min | 5 min | 2 min |

---

## CSD File Parsing

### CSD File Format

CICS System Definition (CSD) files contain resource definitions in a structured format:

```
DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
  PROGRAM(COACTUPC)
  STATUS(ENABLED)
  DESCRIPTION(ACCOUNT UPDATE)

DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
  LANGUAGE(COBOL)
  STATUS(ENABLED)
  DESCRIPTION(ACCOUNT UPDATE PROGRAM)

DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
  DATASET(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS)
  STATUS(ENABLED)
```

### Supported Resource Types

- **TRANSACTION**: CICS transaction definitions (4-character IDs)
- **PROGRAM**: Program definitions with language and status
- **FILE**: File definitions with dataset mappings
- **MAPSET**: BMS mapset definitions

### Enhanced CSV Format

The parser converts CSD to enhanced CSV with 8 columns:

```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Account Update,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data File,
```

### Using the CSD Parser

**Command Line**:

```bash
# Basic conversion
python -m tools.legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv

# Dry run (preview without writing)
python -m tools.legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv \
  --dry-run
```

**Python API**:

```python
from tools.legacy_analyzer.parsers.csd_parser import CSDParser

# Parse CSD file
parser = CSDParser()
csd_data = parser.parse_file('app/csd/CARDDEMO.csd')

# Convert to CSV
parser.to_csv(csd_data, 'exports/cics_inventory.csv')

# Access parsed data
for resource in csd_data:
    print(f"{resource['resource_type']}: {resource['resource_name']}")
```


---

## Metadata Discovery

### Auto-Discovery

The metadata scanner automatically discovers CSD and CSV files in your source directory:

```bash
# Scan directory for metadata files
python -m tools.legacy_analyzer metadata scan \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --recursive
```

**Output**:
```
Discovered files:
  CSD files:  1
  CSV files:  1

CSD files found:
  - /path/to/CARDDEMO.csd

CSV files found:
  - /path/to/cics_inventory.csv
```

### Python API

```python
from tools.legacy_analyzer.metadata.scanner import MetadataFileScanner

# Create scanner
scanner = MetadataFileScanner()

# Scan directory
metadata = scanner.scan_directory(
    source_dir='./examples/code/cobol/carddemoV2',
    recursive=True
)

# Access discovered files
print(f"Found {len(metadata.csd_files)} CSD files")
print(f"Found {len(metadata.csv_files)} CSV files")

for csd_file in metadata.csd_files:
    print(f"CSD: {csd_file}")
```

### File Type Detection

The scanner identifies files by:
- **Extension**: `.csd` for CSD files, `.csv` for CSV files
- **Content**: Validates file format
- **Pattern**: Matches naming conventions

---

## Entry Point Detection

### Enhanced Entry Point Detection

With CICS metadata, entry points are categorized by source:

- **ONLINE**: CICS transactions (from metadata)
- **BATCH**: JCL jobs (from JCL analysis)
- **INFERRED**: Programs not called by others (from code analysis)

### Confidence Levels

- **EXPLICIT**: From CICS metadata or JCL (high confidence)
- **INFERRED**: From code analysis (lower confidence)

### Using Entry Point Detection

**Command Line**:

```bash
# Generate entry points report with metadata
python -m tools.legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --format json \
  --output entry_points/entry_points.json

# Filter by entry point type
python -m tools.legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --entry-point-type ONLINE \
  --format table
```

**Python API**:

```python
from tools.legacy_analyzer.analysis.entry_point_detector import EntryPointDetector
import sqlite3

conn = sqlite3.connect('analysis.db')
detector = EntryPointDetector(conn)

# Detect all entry points
entry_points = detector.detect_entry_points(
    all_programs={'PROG1', 'PROG2', 'PROG3'},
    called_programs={'PROG2'},
    include_disabled=False
)

# Filter by type
online_entry_points = [
    ep for ep in entry_points 
    if ep.entry_point_type == 'ONLINE'
]

# Filter by confidence
explicit_entry_points = [
    ep for ep in entry_points 
    if ep.confidence == 'EXPLICIT'
]

conn.close()
```

### Entry Point Report Format

```json
{
  "metadata": {
    "generated_at": "2026-02-03T10:30:00",
    "total_entry_points": 18,
    "by_type": {
      "ONLINE": 18,
      "BATCH": 0,
      "INFERRED": 0
    },
    "by_confidence": {
      "EXPLICIT": 18,
      "INFERRED": 0
    }
  },
  "entry_points": [
    {
      "program_name": "COACTUPC",
      "entry_point_type": "ONLINE",
      "confidence": "EXPLICIT",
      "transaction_id": "CAUP",
      "cics_group": "CARDDEMO",
      "status": "ENABLED",
      "description": "Account Update"
    }
  ]
}
```


---

## Transaction Reports

### Overview

CICS Transaction Reports provide comprehensive analysis of each transaction including:

- Transaction details (ID, program, group, status)
- Call tree analysis (program dependencies)
- Data dependencies (files and datasets)
- Complexity metrics (aggregated across call tree)
- Modernization suggestions (API endpoints)

### Generating Reports

**Command Line**:

```bash
# Generate JSON report
python -m tools.legacy_analyzer report cics-transactions \
  --db analysis.db \
  --output reports/cics_transactions.json

# Generate HTML report
python -m tools.legacy_analyzer report cics-transactions \
  --db analysis.db \
  --output reports/cics_transactions.html \
  --format html

# Include disabled transactions
python -m tools.legacy_analyzer report cics-transactions \
  --db analysis.db \
  --include-disabled \
  --output reports/cics_all_transactions.json
```

**Python API**:

```python
from tools.legacy_analyzer.reports.cics_report import CICSReportGenerator
import sqlite3

conn = sqlite3.connect('analysis.db')
generator = CICSReportGenerator(conn)

# Generate report for single transaction
report = generator.generate_transaction_report('CAUP')

if report:
    print(f"Transaction: {report.transaction_id}")
    print(f"Program: {report.program}")
    print(f"Call Tree Depth: {report.call_tree.depth}")
    print(f"Complexity: {report.complexity.tier}")
    print(f"API Suggestion: {report.modernization.suggested_api_endpoint}")

# Generate report for all transactions
all_reports = generator.generate_all_transactions_report(
    include_disabled=False
)

conn.close()
```

### Report Structure

Each transaction report includes:

**Transaction Details**:
- Transaction ID (4-character code)
- Program name
- CICS group
- Status (ENABLED/DISABLED)
- Description
- Mapset (if applicable)

**Call Tree**:
- Maximum depth
- List of all programs
- Total program count

**Data Dependencies**:
- CICS files accessed
- MVS datasets (mapped from files)

**Complexity Metrics**:
- Composite score (sum across call tree)
- Complexity tier (LOW/MEDIUM/HIGH/VERY_HIGH)
- Total lines of code
- Total cyclomatic complexity

**Modernization Suggestions**:
- Suggested API endpoint
- HTTP method (GET/POST/PUT/DELETE)
- Suggested service name

### API Endpoint Mapping

The report automatically suggests API endpoints based on transaction descriptions:

| Transaction | Description | Suggested Endpoint | HTTP Method |
|-------------|-------------|-------------------|-------------|
| CAUP | Account Update | PUT /accounts/{id} | PUT |
| CALI | Account List | GET /accounts | GET |
| CADD | Add Account | POST /accounts | POST |
| CDEL | Delete Account | DELETE /accounts/{id} | DELETE |
| CAVW | Account View | GET /accounts/{id} | GET |

---

## Service Grouping

### Overview

Service Grouping Analysis identifies logical service boundaries for microservices architecture planning using three strategies:

1. **CICS GROUP**: Group by CICS GROUP definitions
2. **Data Ownership**: Group by shared data access patterns
3. **Shared Programs**: Group by shared program dependencies

### Generating Service Candidates

**Command Line**:

```bash
# Analyze using all strategies
python -m tools.legacy_analyzer service candidates \
  --db analysis.db \
  --strategy all \
  --format json \
  --output reports/service_candidates.json

# Analyze using specific strategy
python -m tools.legacy_analyzer service candidates \
  --db analysis.db \
  --strategy cics-group \
  --min-confidence HIGH \
  --format json \
  --output reports/service_candidates_cics.json
```

**Python API**:

```python
from tools.legacy_analyzer.analysis.service_grouping import ServiceGroupingAnalyzer
import sqlite3

conn = sqlite3.connect('analysis.db')
analyzer = ServiceGroupingAnalyzer(conn)

# Analyze by CICS GROUP
candidates = analyzer.analyze_by_cics_group()

for candidate in candidates:
    print(f"Service: {candidate.name}")
    print(f"  Entry Points: {len(candidate.entry_points)}")
    print(f"  Confidence: {candidate.confidence}")
    print(f"  Recommendation: {candidate.recommendation}")

conn.close()
```

### Service Candidate Structure

```json
{
  "name": "Account Management Service",
  "entry_points": [
    {
      "transaction_id": "CAUP",
      "program_name": "COACTUPC",
      "description": "Account Update"
    },
    {
      "transaction_id": "CAVW",
      "program_name": "COACTVWC",
      "description": "Account View"
    }
  ],
  "cics_group": "CARDDEMO",
  "shared_data": ["ACCTDAT", "CUSTDAT"],
  "shared_programs": ["CBACT01C", "CBACT02C"],
  "confidence": "HIGH",
  "recommendation": "CONSIDER_MERGE"
}
```

### Confidence Levels

- **HIGH**: Strong evidence for grouping (same CICS GROUP + shared data)
- **MEDIUM**: Moderate evidence (shared data or programs)
- **LOW**: Weak evidence (minimal sharing)

### Recommendations

- **CONSIDER_MERGE**: Strong candidate for single service
- **NEEDS_REVIEW**: Requires manual review
- **KEEP_SEPARATE**: Better as separate services


---

## Reconciliation

### Overview

Metadata Reconciliation validates CICS metadata against source code inventory to identify:

- Missing programs (in metadata but not in source)
- Orphaned definitions (in source but not in metadata)
- Status mismatches
- Data quality issues

### Running Reconciliation

**Command Line**:

```bash
# Run reconciliation
python -m tools.legacy_analyzer metadata reconcile \
  --db analysis.db \
  --format json \
  --output reports/reconciliation.json
```

**Python API**:

```python
from tools.legacy_analyzer.metadata.reconciliation import MetadataReconciler
import sqlite3

conn = sqlite3.connect('analysis.db')
reconciler = MetadataReconciler(conn)

# Run reconciliation
issues = reconciler.reconcile()

# Analyze results
print(f"Total issues: {len(issues)}")

missing_programs = [i for i in issues if i['issue_type'] == 'MISSING_PROGRAM']
orphaned_defs = [i for i in issues if i['issue_type'] == 'ORPHANED_DEFINITION']

print(f"Missing programs: {len(missing_programs)}")
print(f"Orphaned definitions: {len(orphaned_defs)}")

conn.close()
```

### Issue Types

- **MISSING_PROGRAM**: Program in CICS metadata but not in source code
- **ORPHANED_DEFINITION**: Program in source but not in CICS metadata
- **STATUS_MISMATCH**: Status differs between metadata and source
- **NAMING_MISMATCH**: Name format inconsistencies

### Reconciliation Report

```json
{
  "summary": {
    "total_issues": 15,
    "by_type": {
      "MISSING_PROGRAM": 5,
      "ORPHANED_DEFINITION": 8,
      "STATUS_MISMATCH": 2
    }
  },
  "issues": [
    {
      "issue_type": "MISSING_PROGRAM",
      "resource_name": "OLDPROG1",
      "resource_type": "PROGRAM",
      "severity": "MEDIUM",
      "description": "Program defined in CICS but not found in source code",
      "recommendation": "Verify program location or remove from CICS"
    }
  ]
}
```

---

## Database Schema

### inventory_cics Table

The `inventory_cics` table stores CICS resource definitions:

```sql
CREATE TABLE inventory_cics (
    resource_name VARCHAR(8) PRIMARY KEY,
    resource_type VARCHAR(20) NOT NULL,
    group_name VARCHAR(20),
    status VARCHAR(10) DEFAULT 'ENABLED',
    program_name VARCHAR(44),
    dataset_name VARCHAR(44),
    description TEXT,
    language VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Key Columns**:

- `resource_name`: Transaction ID, program name, file name, or mapset name
- `resource_type`: TRANSACTION, PROGRAM, FILE, or MAPSET
- `group_name`: CICS GROUP for service boundary hints
- `status`: ENABLED or DISABLED
- `program_name`: For TRANSACTION type, the program it invokes
- `dataset_name`: For FILE type, the MVS dataset name
- `description`: Optional description
- `language`: For PROGRAM type, the programming language

### Querying CICS Metadata

```sql
-- Get all CICS transactions
SELECT * FROM inventory_cics 
WHERE resource_type = 'TRANSACTION' 
AND status = 'ENABLED';

-- Get transaction-to-program mappings
SELECT resource_name AS transaction_id, 
       program_name, 
       group_name, 
       description
FROM inventory_cics 
WHERE resource_type = 'TRANSACTION';

-- Get file-to-dataset mappings
SELECT resource_name AS file_name, 
       dataset_name, 
       group_name
FROM inventory_cics 
WHERE resource_type = 'FILE';

-- Count resources by type
SELECT resource_type, COUNT(*) 
FROM inventory_cics 
GROUP BY resource_type;

-- Get resources by CICS GROUP
SELECT group_name, 
       resource_type, 
       COUNT(*) 
FROM inventory_cics 
GROUP BY group_name, resource_type;
```

---

## Best Practices

### 1. Load CICS Metadata First

Always load CICS metadata before analyzing source code:

```bash
# ✅ Correct order
python -m tools.legacy_analyzer metadata load-from-source \
  --source-dir . --db analysis.db

python -m tools.legacy_analyzer analyze \
  --source-dir . --db analysis.db

# ❌ Wrong order
python -m tools.legacy_analyzer analyze \
  --source-dir . --db analysis.db

python -m tools.legacy_analyzer metadata load-from-source \
  --source-dir . --db analysis.db
```

### 2. Use Enhanced CSV Format

Always use the enhanced CSV format with all 8 columns:

```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Account Update,
```

### 3. Run Reconciliation Regularly

Run reconciliation after CICS configuration changes:

```bash
python -m tools.legacy_analyzer metadata reconcile --db analysis.db
```

### 4. Focus on EXPLICIT Confidence

Prioritize EXPLICIT confidence entry points for migration:

```python
# Filter by confidence
explicit_eps = [ep for ep in entry_points if ep.confidence == 'EXPLICIT']
```

### 5. Use CICS GROUPs for Service Boundaries

Start with CICS GROUP-based service grouping:

```bash
python -m tools.legacy_analyzer service candidates \
  --db analysis.db \
  --strategy cics-group \
  --min-confidence HIGH
```

### 6. Version Control CSD Files

Keep CSD files in version control:

```bash
git add app/csd/CARDDEMO.csd
git commit -m "Update CICS definitions for release 2.1"
```

### 7. Automate Regular Exports

Schedule regular CICS metadata exports:

```bash
# crontab entry
0 2 * * * /path/to/export_cics_metadata.sh
```


---

## Troubleshooting

### Issue: No CICS Metadata Found

**Symptom**: Entry points report shows no ONLINE entry points

**Solution**:

```bash
# Check if CICS metadata is loaded
sqlite3 analysis.db "SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION';"

# If 0, load CICS metadata
python -m tools.legacy_analyzer metadata load-from-source \
  --source-dir . --db analysis.db
```

### Issue: CSD Parsing Errors

**Symptom**: CSD parser reports errors or warnings

**Solution**:

```bash
# Use dry-run to preview
python -m tools.legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv \
  --dry-run

# Check CSD file format
head -50 app/csd/CARDDEMO.csd
```

### Issue: No Call Trees in Reports

**Symptom**: Transaction reports show call tree depth of 0

**Solution**:

```bash
# Run dependency analysis
python -m tools.legacy_analyzer analyze \
  --source-dir ./cobol --db analysis.db

# Verify dependencies loaded
sqlite3 analysis.db "SELECT COUNT(*) FROM artifact_dependencies;"
```

### Issue: Missing Complexity Metrics

**Symptom**: Complexity section is null in reports

**Solution**:

```bash
# Run complexity analysis
python -m tools.legacy_analyzer complexity analyze \
  --source-dir ./cobol --db analysis.db

# Verify complexity metrics loaded
sqlite3 analysis.db "SELECT COUNT(*) FROM complexity_metrics;"
```

### Issue: Service Candidates Not Found

**Symptom**: Service grouping returns no candidates

**Solution**:

```bash
# Verify CICS metadata loaded
sqlite3 analysis.db "SELECT COUNT(*) FROM inventory_cics;"

# Verify dependencies analyzed
sqlite3 analysis.db "SELECT COUNT(*) FROM artifact_dependencies;"

# Try lower confidence threshold
python -m tools.legacy_analyzer service candidates \
  --db analysis.db \
  --min-confidence LOW
```

### Issue: Reconciliation Shows Many Issues

**Symptom**: Hundreds of discrepancies reported

**Solution**:

1. Verify comparing correct environment
2. Ensure all source directories scanned
3. Review naming conventions (COBOL names vs file names)
4. Check for case sensitivity issues

### Getting Help

If issues persist:

1. Check logs for error messages
2. Validate data loaded correctly using SQL queries
3. Review configuration files
4. Enable verbose logging with `--verbose` flag
5. Consult related documentation (see below)

---

## See Also

### Core Documentation

- **[User Guide](../USER_GUIDE.md)**: Complete end-user documentation
- **[API Reference](../API.md)**: Python API for programmatic access
- **[CLI Reference](../CLI_REFERENCE.md)**: Command-line interface
- **[Migration Guide](../MIGRATION_GUIDE.md)**: Migration planning workflows
- **[Architecture](../ARCHITECTURE.md)**: System architecture and design

### Related Advanced Topics

- **[Flow Analysis](FLOW_ANALYSIS.md)**: Program flow analysis
- **[Complexity Analysis](COMPLEXITY_ANALYSIS.md)**: Complexity metrics
- **[Service Grouping](SERVICE_GROUPING.md)**: Service boundary identification

### External Resources

- [IBM CICS Documentation](https://www.ibm.com/docs/en/cics-ts)
- [DFHCSDUP Reference](https://www.ibm.com/docs/en/cics-ts/latest?topic=utilities-dfhcsdup-csd-utility)
- [CICS System Definition Guide](https://www.ibm.com/docs/en/cics-ts/latest?topic=administration-cics-system-definition)

### Example Scripts

- `examples/analyze_with_cics_metadata.py`: Complete metadata discovery and analysis
- `examples/generate_cics_reports.py`: Transaction report generation
- `examples/service_grouping_analysis.py`: Service boundary analysis

---

## Complete Workflow Example

Here's a complete workflow from CSD file to service candidates:

```bash
#!/bin/bash
# complete_cics_workflow.sh

DB="analysis.db"
SOURCE_DIR="./examples/code/cobol/carddemoV2"
REPORTS_DIR="reports"

mkdir -p "$REPORTS_DIR"

echo "Step 1: Loading CICS metadata..."
python -m tools.legacy_analyzer metadata load-from-source \
  --source-dir "$SOURCE_DIR" \
  --db "$DB" \
  --keep-csv "$REPORTS_DIR/cics_inventory.csv"

echo "Step 2: Analyzing source code..."
python -m tools.legacy_analyzer analyze \
  --source-dir "$SOURCE_DIR/app" \
  --db "$DB"

echo "Step 3: Calculating complexity..."
python -m tools.legacy_analyzer complexity analyze \
  --source-dir "$SOURCE_DIR/app" \
  --db "$DB"

echo "Step 4: Generating entry points report..."
python -m tools.legacy_analyzer flow entry-points \
  --db "$DB" \
  --use-metadata \
  --format json \
  --output "$REPORTS_DIR/entry_points.json"

echo "Step 5: Generating CICS transaction reports..."
python -m tools.legacy_analyzer report cics-transactions \
  --db "$DB" \
  --format html \
  --output "$REPORTS_DIR/cics_transactions.html"

echo "Step 6: Analyzing service candidates..."
python -m tools.legacy_analyzer service candidates \
  --db "$DB" \
  --strategy all \
  --format json \
  --output "$REPORTS_DIR/service_candidates.json"

echo "Step 7: Running reconciliation..."
python -m tools.legacy_analyzer metadata reconcile \
  --db "$DB" \
  --format json \
  --output "$REPORTS_DIR/reconciliation.json"

echo "✓ Analysis complete! Reports saved to $REPORTS_DIR/"
echo ""
echo "Next steps:"
echo "  1. Review entry points: $REPORTS_DIR/entry_points.json"
echo "  2. Open HTML report: $REPORTS_DIR/cics_transactions.html"
echo "  3. Review service candidates: $REPORTS_DIR/service_candidates.json"
echo "  4. Check reconciliation: $REPORTS_DIR/reconciliation.json"
```

---

**Document Version**: 1.0  
**Last Updated**: February 3, 2026  
**Related Tools**: CSD Parser, Metadata Scanner, Entry Point Detector, CICS Report Generator
