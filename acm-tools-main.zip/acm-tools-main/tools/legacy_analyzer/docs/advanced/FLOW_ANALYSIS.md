# Flow Analysis

## Table of Contents

- [Overview](#overview)
- [What is Flow Analysis?](#what-is-flow-analysis)
- [Quick Start](#quick-start)
- [Entry Point Detection](#entry-point-detection)
- [Program Flow Analysis](#program-flow-analysis)
- [Call Graph Analysis](#call-graph-analysis)
- [Circular Dependency Detection](#circular-dependency-detection)
- [Visualization](#visualization)
- [Use Cases](#use-cases)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [See Also](#see-also)

---

## Overview

Flow Analysis helps you understand how programs call each other and interact within your legacy system. It traces execution paths, identifies entry points, detects circular dependencies, and visualizes call hierarchies.

### Why Flow Analysis?

Flow analysis provides:

- **Entry Point Identification**: Find programs that serve as system entry points
- **Call Hierarchy Understanding**: Trace program execution paths
- **Impact Analysis**: Determine what's affected by changes
- **Circular Dependency Detection**: Identify problematic call cycles
- **Migration Planning**: Identify self-contained subsystems
- **Visualization**: Generate diagrams for documentation

### Key Features

- Multi-source entry point detection (CICS, JCL, code analysis)
- Confidence scoring (EXPLICIT vs INFERRED)
- Recursive flow analysis with depth control
- Call graph generation
- Circular dependency detection
- Multiple visualization formats (Mermaid, Graphviz, JSON)

---

## What is Flow Analysis?

Flow analysis traces execution paths through a system by following program calls. Starting from an entry point, it recursively identifies all called programs, building a complete picture of the call hierarchy.

### Key Concepts

**Entry Point**: A program that can be invoked from outside the application
- **ONLINE**: CICS transactions (from CSD metadata)
- **BATCH**: JCL jobs (from JCL dependencies)
- **INFERRED**: Programs not called by others (from code analysis)

**Confidence Levels**:
- **EXPLICIT**: From metadata (CICS, JCL) - high reliability
- **INFERRED**: From code analysis - medium reliability

**Call Depth**: Number of levels in the call hierarchy

**Call Graph**: Directed graph showing all program-to-program relationships

**Circular Dependency**: Cycle where Program A calls Program B, which eventually calls Program A

---

## Quick Start

### 5-Minute Quick Start

```bash
# Step 1: Detect entry points (with metadata if available)
python -m tools.legacy_analyzer flow entry-points \
    --db analyzer.db \
    --use-metadata \
    --format json \
    --output entry_points.json

# Step 2: Analyze a program flow
python -m tools.legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db analyzer.db \
    --output payroll_flow.json

# Step 3: Detect circular dependencies
python -m tools.legacy_analyzer flow detect-circular \
    --db analyzer.db \
    --output circular_deps.csv

# Step 4: Visualize the flow
python -m tools.legacy_analyzer flow visualize \
    --program PAYROLL1 \
    --format mermaid \
    --output payroll_flow.mmd \
    --db analyzer.db
```

### Prerequisites

- Dependencies analyzed (program calls extracted)
- Database with dependency data
- Optional: CICS metadata loaded for enhanced entry point detection


---

## Entry Point Detection

### Overview

Entry Point Detection identifies programs that serve as entry points into the application using a multi-source, priority-based approach.

### Detection Algorithm

**Priority Order**:
1. **ONLINE** (CICS Transactions) → EXPLICIT confidence
2. **BATCH** (JCL Jobs) → EXPLICIT confidence
3. **INFERRED** (Code Analysis) → INFERRED confidence

**Process**:
1. Query CICS metadata for ONLINE entry points
2. Query JCL dependencies for BATCH entry points
3. Analyze call graph for INFERRED entry points
4. Merge with priority (higher priority overrides lower)
5. Return deduplicated list

### Data Sources

**1. CICS Metadata (ONLINE)**

Source: `inventory_cics` table  
Confidence: EXPLICIT

```sql
SELECT resource_name, program_name, group_name, status, description
FROM inventory_cics
WHERE resource_type = 'TRANSACTION'
  AND status = 'ENABLED'
```

**Example**:
```python
EntryPoint(
    program_name='COACTUPC',
    entry_type='ONLINE',
    confidence='EXPLICIT',
    source='CSD',
    transaction_id='CAUP',
    cics_group='CARDDEMO',
    status='ENABLED'
)
```

**2. JCL Dependencies (BATCH)**

Source: `artifact_dependencies` table  
Confidence: EXPLICIT

```sql
SELECT DISTINCT target_artifact_name, source_artifact_name
FROM artifact_dependencies
WHERE source_type = 'JCL'
  AND dependency_type = 'EXEC_PGM'
  AND target_type = 'PROGRAM'
```

**Example**:
```python
EntryPoint(
    program_name='CBACT01C',
    entry_type='BATCH',
    confidence='EXPLICIT',
    source='JCL',
    jcl_name='DAILYJOB'
)
```

**3. Code Analysis (INFERRED)**

Source: Call graph analysis  
Confidence: INFERRED

```python
# Programs never called by others
inferred_entry_points = all_programs - called_programs
```

**Example**:
```python
EntryPoint(
    program_name='UTILPROG',
    entry_type='INFERRED',
    confidence='INFERRED',
    source='CODE_ANALYSIS'
)
```

### Using Entry Point Detection

**Command Line**:

```bash
# Basic entry points (code analysis only)
python -m tools.legacy_analyzer flow entry-points \
    --db analyzer.db

# Enhanced with metadata
python -m tools.legacy_analyzer flow entry-points \
    --db analyzer.db \
    --use-metadata \
    --format json \
    --output entry_points.json

# Include disabled CICS transactions
python -m tools.legacy_analyzer flow entry-points \
    --db analyzer.db \
    --use-metadata \
    --include-disabled \
    --format table
```

**Python API**:

```python
from tools.legacy_analyzer.analysis.entry_point_detector import EntryPointDetector
import sqlite3

conn = sqlite3.connect('analyzer.db')
detector = EntryPointDetector(conn)

# Detect entry points
entry_points = detector.detect_entry_points(
    all_programs={'PROG1', 'PROG2', 'PROG3'},
    called_programs={'PROG2'},
    include_disabled=False
)

# Filter by type
online = [ep for ep in entry_points if ep.entry_point_type == 'ONLINE']
batch = [ep for ep in entry_points if ep.entry_point_type == 'BATCH']
inferred = [ep for ep in entry_points if ep.entry_point_type == 'INFERRED']

# Filter by confidence
explicit = [ep for ep in entry_points if ep.confidence == 'EXPLICIT']

conn.close()
```

### Confidence Levels

**EXPLICIT Confidence**:
- Definition: Entry point explicitly defined in metadata
- Reliability: High (based on actual system configuration)
- Use Cases: Production mapping, API design, service boundaries

**INFERRED Confidence**:
- Definition: Entry point inferred from code structure
- Reliability: Medium (may include utilities or dead code)
- Use Cases: Completeness checking, identifying missing metadata


---

## Program Flow Analysis

### Overview

Program flow analysis traces execution paths starting from an entry point, recursively identifying all called programs.

### Analyzing Single Programs

**Command Line**:

```bash
# Analyze program flow
python -m tools.legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db analyzer.db \
    --output payroll_flow.json

# Limit depth
python -m tools.legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --max-depth 5 \
    --db analyzer.db
```

**Python API**:

```python
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from tools.legacy_analyzer.databases import SQLiteAdapter

database = SQLiteAdapter('analyzer.db')
database.connect()

analyzer = FlowAnalyzer(database)

# Analyze flow
flow = analyzer.analyze_flow('PAYROLL1', max_depth=10)

print(f"Start Program: {flow.start_program}")
print(f"Flow Depth: {flow.depth}")
print(f"Total Programs: {len(flow.programs)}")
print(f"Programs: {', '.join(flow.programs)}")

database.close()
```

### Batch Analysis

Analyze multiple entry points:

```python
# Analyze multiple flows
entry_points = ['PAYROLL1', 'BILLING1', 'CUSTMGMT']

flows = {}
for program in entry_points:
    flow = analyzer.analyze_flow(program, max_depth=10)
    flows[program] = flow
    print(f"{program}: {len(flow.programs)} programs, depth {flow.depth}")
```

### Flow Depth Calculation

Calculate how deep a program is in the call hierarchy:

```python
# Calculate depth for multiple programs
programs = ['PAYROLL1', 'PAYCALC', 'TAXCALC', 'DBACCESS']

for program in programs:
    depth = analyzer.calculate_flow_depth(program)
    print(f"{program}: depth = {depth}")
```

### Advanced Options

**Include Copybooks and Datasets**:

```python
# Analyze with copybooks and datasets
flow = analyzer.analyze_flow(
    'PAYROLL1',
    max_depth=10,
    include_copybooks=True,
    include_datasets=True
)
```

**Filter by Dependency Type**:

```python
# Only include CALL dependencies
flow = analyzer.analyze_flow(
    'PAYROLL1',
    max_depth=10,
    dependency_types=['CALL']
)
```

---

## Call Graph Analysis

### Overview

A call graph shows all program-to-program relationships in your system.

### Building Call Graphs

**Python API**:

```python
from tools.legacy_analyzer.analysis.call_graph import CallGraph

# Build call graph for multiple programs
programs = ['PAYROLL1', 'PAYCALC', 'TAXCALC', 'DBACCESS']
call_graph = analyzer.build_call_graph(programs)

print(f"Nodes: {len(call_graph.nodes)}")
print(f"Edges: {len(call_graph.edges)}")

# Print call relationships
for caller, callee in call_graph.edges:
    print(f"{caller} -> {callee}")
```

### Call Graph Properties

**Nodes**: Programs in the graph  
**Edges**: Call relationships (caller → callee)  
**Degree**: Number of connections for each node

```python
# Analyze node degrees
for node in call_graph.nodes:
    in_degree = call_graph.in_degree(node)
    out_degree = call_graph.out_degree(node)
    print(f"{node}: in={in_degree}, out={out_degree}")
```

---

## Circular Dependency Detection

### Overview

Circular dependencies occur when Program A calls Program B, which eventually calls Program A. These can cause issues during migration.

### Detecting Circular Dependencies

**Command Line**:

```bash
# Detect all circular dependencies
python -m tools.legacy_analyzer flow detect-circular \
    --db analyzer.db \
    --output circular_deps.csv

# Visualize circular dependencies
python -m tools.legacy_analyzer flow visualize-circular \
    --db analyzer.db \
    --output circular_deps.mmd
```

**Python API**:

```python
# Detect circular dependencies
circular_deps = analyzer.detect_circular_dependencies()

if circular_deps:
    print(f"Found {len(circular_deps)} circular dependency chain(s):")
    for i, cycle in enumerate(circular_deps, 1):
        cycle_str = ' -> '.join(cycle.programs)
        print(f"Cycle {i}: {cycle_str} -> {cycle.programs[0]}")
else:
    print("No circular dependencies found")
```

### Handling Circular Dependencies

**Options**:
1. **Document**: Record all circular dependencies
2. **Refactor**: Break cycles by introducing interfaces
3. **Migrate Together**: Migrate circular groups as a unit
4. **Use Interfaces**: Break dependencies with abstraction layers

**Example Refactoring**:

```
Before:
  PROG_A -> PROG_B -> PROG_C -> PROG_A

After:
  PROG_A -> INTERFACE_X <- PROG_B
  PROG_B -> INTERFACE_Y <- PROG_C
  PROG_C -> INTERFACE_Z <- PROG_A
```


---

## Visualization

### Overview

Flow analysis supports multiple visualization formats for documentation and communication.

### Mermaid Format

Mermaid diagrams can be embedded in Markdown:

**Generate Mermaid**:

```bash
python -m tools.legacy_analyzer flow visualize \
    --program PAYROLL1 \
    --format mermaid \
    --output payroll_flow.mmd \
    --db analyzer.db
```

**Python API**:

```python
# Generate Mermaid diagram
mermaid_output = flow.to_mermaid()

# Save to file
with open('flow_diagram.mmd', 'w') as f:
    f.write(mermaid_output)
```

**Example Output**:

```mermaid
graph TD
    PAYROLL1[PAYROLL1]
    PAYCALC[PAYCALC]
    TAXCALC[TAXCALC]
    DBACCESS[DBACCESS]
    
    PAYROLL1 --> PAYCALC
    PAYROLL1 --> TAXCALC
    PAYCALC --> DBACCESS
    TAXCALC --> DBACCESS
```

### Graphviz DOT Format

DOT format can be rendered with Graphviz tools:

**Generate DOT**:

```bash
python -m tools.legacy_analyzer flow visualize \
    --program PAYROLL1 \
    --format dot \
    --output payroll_flow.dot \
    --db analyzer.db

# Render with Graphviz
dot -Tpng payroll_flow.dot -o payroll_flow.png
```

**Python API**:

```python
# Generate DOT format
dot_output = flow.to_dot()

# Save to file
with open('flow_diagram.dot', 'w') as f:
    f.write(dot_output)
```

### JSON Format

JSON format for programmatic processing:

```python
# Generate JSON
json_output = flow.to_json()

# Save to file
with open('flow_data.json', 'w') as f:
    f.write(json_output)
```

**Example JSON**:

```json
{
  "start_program": "PAYROLL1",
  "depth": 3,
  "total_programs": 4,
  "programs": ["PAYROLL1", "PAYCALC", "TAXCALC", "DBACCESS"],
  "edges": [
    {"from": "PAYROLL1", "to": "PAYCALC"},
    {"from": "PAYROLL1", "to": "TAXCALC"},
    {"from": "PAYCALC", "to": "DBACCESS"},
    {"from": "TAXCALC", "to": "DBACCESS"}
  ]
}
```

### Visualization Options

**Layout Direction**:
- `TB`: Top to bottom (default)
- `LR`: Left to right
- `BT`: Bottom to top
- `RL`: Right to left

**Node Limits**:

```python
# Limit visualization to 100 nodes
flow.to_mermaid(max_nodes=100)
```

---

## Use Cases

### Use Case 1: Understanding System Architecture

Analyze entry points to understand system structure:

```bash
# Find all entry points
python -m tools.legacy_analyzer flow entry-points \
    --db analyzer.db \
    --use-metadata \
    --format json \
    --output entry_points.json

# Analyze each entry point
# Extract program names from JSON and analyze
python -m tools.legacy_analyzer flow analyze \
    --program PROGRAM_NAME \
    --db analyzer.db \
    --output flows/PROGRAM_NAME_flow.json
```

### Use Case 2: Impact Analysis

Determine what programs are affected by changes:

```bash
# Find all programs that call DBACCESS
python -m tools.legacy_analyzer flow reverse \
    --program DBACCESS \
    --db analyzer.db \
    --output dbaccess_callers.csv
```

```python
# Programmatic impact analysis
def analyze_impact(program_name, analyzer):
    # Find all callers
    callers = analyzer.get_callers(program_name)
    
    # Find all programs in caller flows
    impacted = set()
    for caller in callers:
        flow = analyzer.analyze_flow(caller)
        impacted.update(flow.programs)
    
    return impacted

impacted_programs = analyze_impact('DBACCESS', analyzer)
print(f"Changing DBACCESS impacts {len(impacted_programs)} programs")
```

### Use Case 3: Migration Planning

Identify self-contained subsystems:

```bash
# Analyze flow for migration package
python -m tools.legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db analyzer.db \
    --output payroll_flow.json

# Check for external dependencies
python -m tools.legacy_analyzer flow external-deps \
    --program PAYROLL1 \
    --db analyzer.db
```

```python
# Find self-contained flows
def find_self_contained_flows(entry_points, analyzer):
    self_contained = []
    
    for program in entry_points:
        flow = analyzer.analyze_flow(program)
        external_deps = analyzer.get_external_dependencies(flow.programs)
        
        if len(external_deps) == 0:
            self_contained.append({
                'program': program,
                'size': len(flow.programs),
                'depth': flow.depth
            })
    
    return self_contained

# Find flows with no external dependencies
flows = find_self_contained_flows(entry_points, analyzer)
for flow in sorted(flows, key=lambda x: x['size']):
    print(f"{flow['program']}: {flow['size']} programs, depth {flow['depth']}")
```

### Use Case 4: Circular Dependency Resolution

Find and document circular dependencies:

```bash
# Detect circular dependencies
python -m tools.legacy_analyzer flow detect-circular \
    --db analyzer.db \
    --output circular_deps.csv

# Visualize circular dependencies
python -m tools.legacy_analyzer flow visualize-circular \
    --db analyzer.db \
    --output circular_deps.mmd
```

```python
# Analyze circular dependency impact
circular_deps = analyzer.detect_circular_dependencies()

for cycle in circular_deps:
    print(f"\nCircular Dependency:")
    print(f"  Programs: {' -> '.join(cycle.programs)}")
    print(f"  Size: {len(cycle.programs)} programs")
    
    # Find all flows that include this cycle
    affected_flows = []
    for entry_point in entry_points:
        flow = analyzer.analyze_flow(entry_point)
        if any(p in flow.programs for p in cycle.programs):
            affected_flows.append(entry_point)
    
    print(f"  Affects {len(affected_flows)} flows")
```

### Use Case 5: Documentation Generation

Generate architecture documentation:

```python
# Generate comprehensive documentation
def generate_architecture_docs(entry_points, analyzer, output_dir):
    import os
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate overview
    with open(f'{output_dir}/README.md', 'w') as f:
        f.write('# System Architecture\n\n')
        f.write(f'Total Entry Points: {len(entry_points)}\n\n')
        
        # Entry point summary
        f.write('## Entry Points\n\n')
        for ep in entry_points:
            f.write(f'- **{ep.program_name}** ({ep.entry_point_type})\n')
    
    # Generate flow diagrams
    for ep in entry_points:
        flow = analyzer.analyze_flow(ep.program_name)
        mermaid = flow.to_mermaid()
        
        with open(f'{output_dir}/{ep.program_name}.md', 'w') as f:
            f.write(f'# {ep.program_name} Flow\n\n')
            f.write(f'Type: {ep.entry_point_type}\n')
            f.write(f'Depth: {flow.depth}\n')
            f.write(f'Programs: {len(flow.programs)}\n\n')
            f.write('```mermaid\n')
            f.write(mermaid)
            f.write('\n```\n')

generate_architecture_docs(entry_points, analyzer, 'docs/architecture')
```

---

## Best Practices

### 1. Start with Entry Points

Always begin flow analysis from entry points rather than arbitrary programs:

```python
# Good: Start from entry points
entry_points = detector.detect_entry_points(all_programs, called_programs)
for ep in entry_points:
    flow = analyzer.analyze_flow(ep.program_name)

# Avoid: Analyzing random programs
flow = analyzer.analyze_flow('RANDOM_PROG')  # May not be an entry point
```

### 2. Use Metadata When Available

Load CICS and JCL metadata for accurate entry point detection:

```bash
# Load CICS metadata
python -m tools.legacy_analyzer metadata load-from-source \
    --source-dir ./app \
    --db analyzer.db

# Then use enhanced detection
python -m tools.legacy_analyzer flow entry-points \
    --db analyzer.db \
    --use-metadata
```

### 3. Limit Flow Depth for Large Systems

For systems with deep call hierarchies, limit depth to improve performance:

```python
# Limit to 10 levels
flow = analyzer.analyze_flow('PAYROLL1', max_depth=10)
```

### 4. Document Circular Dependencies

Always document circular dependencies found during analysis:

```python
circular_deps = analyzer.detect_circular_dependencies()

with open('circular_dependencies.md', 'w') as f:
    f.write('# Circular Dependencies\n\n')
    for i, cycle in enumerate(circular_deps, 1):
        f.write(f'## Cycle {i}\n\n')
        f.write(f'Programs: {" → ".join(cycle.programs)} → {cycle.programs[0]}\n\n')
```

### 5. Validate Flow Results

Review generated flows for accuracy and completeness:

```python
# Check for missing programs
flow = analyzer.analyze_flow('PAYROLL1')
expected_programs = {'PAYROLL1', 'PAYCALC', 'TAXCALC', 'DBACCESS'}
missing = expected_programs - set(flow.programs)

if missing:
    print(f"Warning: Missing programs in flow: {missing}")
```

### 6. Use Visualizations for Communication

Generate visual diagrams to communicate architecture to stakeholders:

```bash
# Generate Mermaid diagrams for all entry points
# Extract program names from JSON and visualize
python -m tools.legacy_analyzer flow visualize \
    --program PROGRAM_NAME \
    --format mermaid \
    --output diagrams/PROGRAM_NAME.mmd \
    --db analyzer.db
```

### 7. Combine with Complexity Analysis

Use flow analysis together with complexity metrics for comprehensive assessment:

```python
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer

complexity_analyzer = ComplexityAnalyzer(database)

# Analyze flow and complexity
flow = analyzer.analyze_flow('PAYROLL1')
for program in flow.programs:
    complexity = complexity_analyzer.analyze_program(program)
    print(f"{program}: complexity={complexity.total_score}, depth={flow.depth}")
```

### 8. Track Changes Over Time

Re-analyze flows after code changes to track evolution:

```python
# Save flow snapshots
import datetime

timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
flow = analyzer.analyze_flow('PAYROLL1')
flow.to_json(f'flows/PAYROLL1_{timestamp}.json')
```

### 9. Filter by Confidence Level

Focus on EXPLICIT confidence entry points for production planning:

```python
entry_points = detector.detect_entry_points(all_programs, called_programs)
explicit_entries = [ep for ep in entry_points if ep.confidence == 'EXPLICIT']

# Analyze only explicit entry points
for ep in explicit_entries:
    flow = analyzer.analyze_flow(ep.program_name)
```

### 10. Export Results for Review

Export flow analysis results for team review and documentation:

```bash
# Export to multiple formats
python -m tools.legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db analyzer.db \
    --output payroll_flow.json

python -m tools.legacy_analyzer flow visualize \
    --program PAYROLL1 \
    --format mermaid \
    --output payroll_flow.mmd \
    --db analyzer.db
```

---

## Troubleshooting

### Issue: Flow Analysis is Slow

**Symptoms**:
- Analysis takes several minutes
- System becomes unresponsive
- Memory usage increases significantly

**Solutions**:

1. **Reduce max_flow_depth**:
```python
# Limit to 5 levels instead of 10
flow = analyzer.analyze_flow('PAYROLL1', max_depth=5)
```

2. **Enable caching**:
```python
# Cache flow results
from tools.legacy_analyzer.utils.cache_manager import CacheManager

cache = CacheManager('flow_cache.db')
analyzer = FlowAnalyzer(database, cache=cache)
```

3. **Use parallel processing**:
```python
from concurrent.futures import ThreadPoolExecutor

def analyze_program(program):
    return analyzer.analyze_flow(program, max_depth=5)

with ThreadPoolExecutor(max_workers=4) as executor:
    flows = list(executor.map(analyze_program, entry_points))
```

4. **Filter by dependency type**:
```python
# Only analyze CALL dependencies
flow = analyzer.analyze_flow('PAYROLL1', dependency_types=['CALL'])
```

### Issue: Circular Dependencies Detected

**Symptoms**:
- `detect_circular_dependencies()` returns cycles
- Flow analysis shows programs calling each other
- Migration planning is blocked

**Solutions**:

1. **Document the cycles**:
```bash
python -m tools.legacy_analyzer flow detect-circular \
    --db analyzer.db \
    --output circular_deps.csv
```

2. **Refactor code to break cycles**:
```
Before: PROG_A → PROG_B → PROG_C → PROG_A

After:  PROG_A → INTERFACE_X ← PROG_B
        PROG_B → INTERFACE_Y ← PROG_C
        PROG_C → INTERFACE_Z ← PROG_A
```

3. **Migrate circular groups together**:
```python
# Identify circular groups
circular_deps = analyzer.detect_circular_dependencies()
for cycle in circular_deps:
    print(f"Migrate together: {', '.join(cycle.programs)}")
```

4. **Use interfaces to break dependencies**:
- Introduce abstraction layers
- Use dependency injection
- Implement service interfaces

### Issue: Missing Programs in Flow

**Symptoms**:
- Expected programs not appearing in flow
- Flow depth is shallower than expected
- Call relationships missing

**Solutions**:

1. **Check inventory completeness**:
```sql
-- Verify all programs are in inventory
SELECT COUNT(*) FROM inventory_programs;
SELECT COUNT(DISTINCT source_artifact_name) FROM artifact_dependencies;
```

2. **Verify source code was analyzed**:
```bash
# Re-analyze source code
python -m tools.legacy_analyzer analyze \
    --source-dir ./app \
    --db analyzer.db
```

3. **Check for dynamic calls**:
```python
# Dynamic calls (CALL with variable) may not be detected
# Review parser logs for warnings
```

4. **Review parser logs**:
```bash
# Check for parsing errors
grep "ERROR" analyzer.log
grep "WARNING" analyzer.log
```

### Issue: Visualization Too Large

**Symptoms**:
- Mermaid/DOT diagrams are unreadable
- Too many nodes and edges
- Diagram rendering fails

**Solutions**:

1. **Reduce max_flow_depth**:
```python
flow = analyzer.analyze_flow('PAYROLL1', max_depth=3)
```

2. **Filter by dependency type**:
```python
flow = analyzer.analyze_flow('PAYROLL1', dependency_types=['CALL'])
```

3. **Split into multiple diagrams**:
```python
# Create separate diagrams for each level
for depth in range(1, 6):
    flow = analyzer.analyze_flow('PAYROLL1', max_depth=depth)
    flow.to_mermaid(f'flow_depth_{depth}.mmd')
```

4. **Use max_nodes limit**:
```python
# Limit to 50 nodes
mermaid = flow.to_mermaid(max_nodes=50)
```

### Issue: No Entry Points Found

**Symptoms**:
- `detect_entry_points()` returns empty list
- All programs appear to be called by others
- No ONLINE or BATCH entry points

**Solutions**:

1. **Load CICS metadata**:
```bash
python -m tools.legacy_analyzer metadata load-from-source \
    --source-dir ./app \
    --db analyzer.db
```

2. **Check for JCL dependencies**:
```bash
# Verify JCL was analyzed
python -m tools.legacy_analyzer analyze \
    --source-dir ./jcl \
    --language jcl \
    --db analyzer.db
```

3. **Include INFERRED entry points**:
```python
entry_points = detector.detect_entry_points(
    all_programs=all_programs,
    called_programs=called_programs,
    include_inferred=True
)
```

4. **Check database tables**:
```sql
-- Verify tables exist
SELECT name FROM sqlite_master WHERE type='table';

-- Check for CICS transactions
SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION';

-- Check for JCL dependencies
SELECT COUNT(*) FROM artifact_dependencies WHERE source_type='JCL';
```

### Issue: Incorrect Entry Point Types

**Symptoms**:
- ONLINE programs classified as BATCH
- BATCH programs classified as INFERRED
- Confidence levels seem wrong

**Solutions**:

1. **Verify metadata is loaded**:
```sql
-- Check CICS metadata
SELECT * FROM inventory_cics WHERE resource_type='TRANSACTION' LIMIT 5;

-- Check JCL dependencies
SELECT * FROM artifact_dependencies WHERE source_type='JCL' LIMIT 5;
```

2. **Check priority merging**:
```python
# Priority: ONLINE > BATCH > INFERRED
# Verify program appears in correct source
```

3. **Review status filtering**:
```python
# Include disabled transactions
entry_points = detector.detect_entry_points(include_disabled=True)
```

---

## See Also

### Related Documentation

- **[Entry Point Detection](../../docs/ENTRY_POINT_DETECTION.md)** - Detailed entry point detection guide
- **[CICS Integration](CICS_INTEGRATION.md)** - CICS metadata integration and workflows
- **[Complexity Analysis](COMPLEXITY_ANALYSIS.md)** - Program complexity assessment
- **[Migration Guide](../MIGRATION_GUIDE.md)** - Complete migration planning process
- **[API Reference](../API.md)** - Python API documentation
- **[CLI Reference](../CLI_REFERENCE.md)** - Command-line interface reference

### Related Tools

- **Flow Analyzer** - `tools.legacy_analyzer.analysis.flow_analyzer`
- **Entry Point Detector** - `tools.legacy_analyzer.analysis.entry_point_detector`
- **Call Graph** - `tools.legacy_analyzer.analysis.call_graph`
- **Complexity Analyzer** - `tools.legacy_analyzer.analysis.complexity_analyzer`

### Examples

- **Flow Analysis Example** - `examples/flow_analysis_example.py`
- **Entry Point Detection Example** - `examples/entry_point_detection_example.py`
- **Circular Dependency Example** - `examples/circular_dependency_example.py`

---

**Document Version**: 1.0  
**Last Updated**: February 2026  
**Part of**: Legacy Analyzer Documentation Suite

