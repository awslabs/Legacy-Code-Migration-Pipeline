# Complexity Analysis

## Table of Contents

- [Overview](#overview)
- [What is Complexity Analysis?](#what-is-complexity-analysis)
- [Quick Start](#quick-start)
- [Complexity Metrics](#complexity-metrics)
- [Complexity Tiers](#complexity-tiers)
- [Program-Level Analysis](#program-level-analysis)
- [Flow-Level Analysis](#flow-level-analysis)
- [Configuration](#configuration)
- [Use Cases](#use-cases)
- [Language-Specific Considerations](#language-specific-considerations)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [See Also](#see-also)

---

## Overview

Complexity Analysis evaluates the difficulty of migrating artifacts by calculating metrics like lines of code, cyclomatic complexity, and dependency counts. This analysis helps prioritize migration efforts, estimate resources, and identify refactoring candidates.

### Why Complexity Analysis?

Complexity analysis provides:

- **Migration Effort Estimation**: Quantify the work required for each program or flow
- **Risk Assessment**: Identify high-complexity programs that need extra attention
- **Resource Allocation**: Assign appropriate skill levels based on complexity
- **Refactoring Identification**: Find "god programs" that should be refactored first
- **Wave Planning**: Group programs by complexity for phased migration

### Key Features

- **Multiple Metrics**: LOC, cyclomatic complexity, dependencies, composite score
- **Tier Classification**: LOW, MEDIUM, HIGH, VERY_HIGH tiers
- **God Program Detection**: Identify excessively complex programs
- **Flow Aggregation**: Calculate complexity across entire migration flows
- **Maintainability Index**: Assess long-term maintainability
- **Customizable Thresholds**: Adjust for your environment

---

## What is Complexity Analysis?

Complexity analysis evaluates programs based on multiple factors:

### Core Metrics

1. **Lines of Code (LOC)**: Size of the program (non-comment, non-blank lines)
2. **Cyclomatic Complexity**: Number of decision points (IF, PERFORM, EVALUATE)
3. **Dependency Count**: Number of incoming and outgoing dependencies
4. **Composite Score**: Weighted combination of all metrics
5. **Complexity Tier**: Classification (LOW, MEDIUM, HIGH, VERY_HIGH)

### Analysis Levels

- **Program-Level**: Individual program complexity
- **Flow-Level**: Aggregate complexity across migration flows
- **System-Level**: Overall system complexity statistics

---

## Quick Start

### 5-Minute Quick Start

```bash
# Step 1: Analyze program complexity
python -m tools.legacy_analyzer complexity analyze \
    --source-dir ./cobol \
    --db analyzer.db

# Step 2: View complexity statistics
python -m tools.legacy_analyzer complexity stats \
    --db analyzer.db

# Step 3: Find high-complexity programs
python -m tools.legacy_analyzer complexity top \
    --limit 50 \
    --db analyzer.db \
    --output high_complexity.csv

# Step 4: Identify god programs
python -m tools.legacy_analyzer complexity god-programs \
    --db analyzer.db \
    --output refactoring_candidates.csv
```

### Prerequisites

- Source code analyzed (dependencies extracted)
- Database with program inventory
- Python 3.8 or higher


---

## Complexity Metrics

### Lines of Code (LOC)

Counts non-comment, non-blank lines of executable code.

**What it measures**: Program size and volume

**Calculation**:
- Excludes comment lines
- Excludes blank lines
- Includes all executable statements

**Example**:
```cobol
   IDENTIFICATION DIVISION.          ← Counted
   PROGRAM-ID. PAYROLL1.             ← Counted
   * This is a comment                ← Excluded
                                      ← Excluded (blank)
   PROCEDURE DIVISION.               ← Counted
       PERFORM PROCESS-PAY.          ← Counted
```

**Python API**:
```python
loc = metrics.lines_of_code
print(f"Lines of Code: {loc}")
```

### Cyclomatic Complexity

Counts decision points in the code (branches and loops).

**What it measures**: Code complexity and testability

**Decision Points**:
- **COBOL**: IF, PERFORM VARYING, EVALUATE, WHEN, AND, OR
- **PL/I**: IF, DO WHILE, SELECT, WHEN, &, |
- **JCL**: IF/THEN/ELSE, COND parameters

**Formula**: `Cyclomatic = 1 + number of decision points`

**Example**:
```cobol
   IF WS-AMOUNT > 1000              ← +1 decision point
       IF WS-TYPE = 'A'             ← +1 decision point
           PERFORM PROCESS-A
       ELSE
           PERFORM PROCESS-B
       END-IF
   END-IF.
   
   EVALUATE WS-STATUS               ← +1 decision point
       WHEN 'ACTIVE'                ← +1 decision point
           PERFORM ACTIVE-PROCESS
       WHEN 'INACTIVE'              ← +1 decision point
           PERFORM INACTIVE-PROCESS
   END-EVALUATE.
```

**Cyclomatic Complexity**: 1 + 5 = 6

**Python API**:
```python
cyclomatic = metrics.cyclomatic_complexity
print(f"Cyclomatic Complexity: {cyclomatic}")
```

### Dependency Counts

Counts incoming and outgoing program dependencies.

**What it measures**: Integration complexity

**Types**:
- **Incoming (deps_in)**: Programs that call this program
- **Outgoing (deps_out)**: Programs this program calls

**Example**:
```
PROG1 calls PROG2, PROG3
PROG4 calls PROG2
PROG5 calls PROG2

PROG2 dependencies:
  deps_in = 3 (called by PROG1, PROG4, PROG5)
  deps_out = 0 (calls no one)
```

**Python API**:
```python
deps_in = metrics.dependency_count_in
deps_out = metrics.dependency_count_out
print(f"Dependencies: {deps_in} in, {deps_out} out")
```

### Composite Score

Weighted combination of all metrics.

**Formula**:
```
composite_score = (LOC × loc_weight) + 
                  (cyclomatic × cyclomatic_weight) + 
                  ((deps_in + deps_out) × deps_weight)
```

**Default Weights**:
- LOC: 0.3 (30%)
- Cyclomatic: 0.4 (40%)
- Dependencies: 0.3 (30%)

**Example Calculation**:
```
Program: PAYROLL1
  LOC: 1200
  Cyclomatic: 60
  Dependencies: 5 in, 10 out

Composite Score = (1200 × 0.3) + (60 × 0.4) + (15 × 0.3)
                = 360 + 24 + 4.5
                = 388.5
```

**Python API**:
```python
score = metrics.composite_score
print(f"Composite Score: {score:.2f}")
```

### Maintainability Index

Calculates maintainability on a 0-100 scale (higher is better).

**Formula** (simplified):
```
MI = 171 - 5.2 × ln(Halstead Volume) 
         - 0.23 × Cyclomatic 
         - 16.2 × ln(LOC)
```

**Interpretation**:
- **85-100**: Highly maintainable (green)
- **65-85**: Moderately maintainable (yellow)
- **0-65**: Difficult to maintain (red)

**Python API**:
```python
mi = metrics.get_maintainability_index()
print(f"Maintainability Index: {mi:.2f}")
```

---

## Complexity Tiers

Programs are classified into tiers based on composite score:

### Tier Definitions

| Tier | Score Range | Description | Migration Effort |
|------|-------------|-------------|------------------|
| **LOW** | ≤ 10 | Simple programs | 1-2 days |
| **MEDIUM** | 11-25 | Moderate complexity | 3-5 days |
| **HIGH** | 26-50 | Complex programs | 1-2 weeks |
| **VERY_HIGH** | > 50 | Very complex | 2+ weeks |

### Tier Characteristics

**LOW Tier**:
- Small programs (< 500 LOC)
- Few decision points (< 10)
- Minimal dependencies (< 5)
- Easy to understand and migrate
- Suitable for junior developers

**MEDIUM Tier**:
- Medium programs (500-1500 LOC)
- Moderate decision points (10-30)
- Some dependencies (5-15)
- Standard migration effort
- Suitable for mid-level developers

**HIGH Tier**:
- Large programs (1500-3000 LOC)
- Many decision points (30-60)
- Significant dependencies (15-30)
- Requires careful planning
- Suitable for senior developers

**VERY_HIGH Tier**:
- Very large programs (> 3000 LOC)
- Excessive decision points (> 60)
- Complex dependencies (> 30)
- High risk, requires refactoring
- Requires architects

### God Programs

Programs with composite score > 100 (default threshold).

**Characteristics**:
- Extremely high complexity
- Multiple responsibilities
- Difficult to test and maintain
- High risk for migration

**Recommendation**: Refactor before migration

**Python API**:
```python
is_god = metrics.is_god_program
if is_god:
    print(f"WARNING: {metrics.program_name} is a god program!")
```


---

## Program-Level Analysis

### Analyzing Single Programs

**Command Line**:

```bash
# Analyze specific program
python -m tools.legacy_analyzer complexity analyze \
    --source-dir ./cobol \
    --program PAYROLL1 \
    --db analyzer.db
```

**Python API**:

```python
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer

analyzer = ComplexityAnalyzer()

# Analyze COBOL program
cobol_code = """
   IDENTIFICATION DIVISION.
   PROGRAM-ID. PAYROLL1.
   
   PROCEDURE DIVISION.
       IF WS-AMOUNT > 1000
           PERFORM PROCESS-LARGE
       ELSE
           PERFORM PROCESS-SMALL
       END-IF.
       STOP RUN.
"""

metrics = analyzer.analyze_program(
    program_name='PAYROLL1',
    source_code=cobol_code,
    language='COBOL',
    dependency_count_in=5,
    dependency_count_out=10
)

print(f"Program: {metrics.program_name}")
print(f"LOC: {metrics.lines_of_code}")
print(f"Cyclomatic: {metrics.cyclomatic_complexity}")
print(f"Composite Score: {metrics.composite_score:.2f}")
print(f"Tier: {metrics.complexity_tier}")
```

### Batch Analysis

Analyze multiple programs at once:

```python
# Analyze all programs
programs = {
    'PROG1': {
        'source_code': code1,
        'language': 'COBOL',
        'dependency_count_in': 5,
        'dependency_count_out': 10
    },
    'PROG2': {
        'source_code': code2,
        'language': 'PLI',
        'dependency_count_in': 3,
        'dependency_count_out': 7
    }
}

results = analyzer.analyze_all_programs(programs)

# Sort by complexity
for name, metrics in sorted(results.items(), 
                           key=lambda x: x[1].composite_score, 
                           reverse=True):
    print(f"{name}: Score={metrics.composite_score:.2f}, "
          f"Tier={metrics.complexity_tier}")
```

### Saving Results

```python
# Save to database
analyzer.save_metrics(metrics, database_connection)

# Export to CSV
analyzer.export_to_csv(results, 'complexity_metrics.csv')

# Export to JSON
analyzer.export_to_json(results, 'complexity_metrics.json')
```

---

## Flow-Level Analysis

### Overview

Flow-level complexity aggregates metrics across all programs in a migration flow.

**Purpose**:
- Estimate total migration effort for a flow
- Prioritize flows by complexity
- Identify high-risk flows
- Plan migration waves

### Calculation Process

1. **Query Database**: Retrieve complexity metrics for all programs in flow
2. **Sum Metrics**: Aggregate LOC and cyclomatic complexity
3. **Calculate Composite Score**: Apply weighted formula with normalization
4. **Determine Tier**: Classify flow based on composite score

### Composite Score Formula (Flow-Level)

```
Composite Score = (Normalized LOC × 0.4) + 
                  (Normalized Cyclomatic × 0.4) + 
                  (Normalized Programs × 0.2)
```

**Normalization Factors**:
- **LOC**: Divided by 50 (5,000 LOC = 100 points)
- **Cyclomatic**: Divided by 5 (500 cyclomatic = 100 points)
- **Programs**: Divided by 0.5 (50 programs = 100 points)

**Weights**:
- **LOC**: 40% (code volume)
- **Cyclomatic**: 40% (code complexity)
- **Program Count**: 20% (integration complexity)

### Flow Complexity Tiers

| Tier | Score Range | Description |
|------|-------------|-------------|
| **LOW** | < 25 | Simple flows, minimal complexity |
| **MEDIUM** | 25-50 | Moderate complexity, standard effort |
| **HIGH** | 50-75 | Complex flows, significant effort |
| **VERY_HIGH** | ≥ 75 | Highly complex, high risk |
| **UNKNOWN** | N/A | No complexity data available |

### Using Flow Complexity

**Python API**:

```python
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder
import sqlite3

# Connect to database
conn = sqlite3.connect('analyzer.db')
builder = MigrationFlowBuilder(conn)

# Calculate complexity for a flow
programs = ['PAYROLL1', 'PAYCALC', 'PAYDB', 'PAYUTIL']
result = builder.calculate_flow_complexity(programs)

# Access results
print(f"Total Programs: {result['totalPrograms']}")
print(f"Total Lines: {result['totalLines']}")
print(f"Cyclomatic: {result['cyclomaticComplexity']}")
print(f"Composite Score: {result['compositeScore']:.2f}")
print(f"Tier: {result['tier']}")

conn.close()
```

### Flow Complexity Examples

**Example 1: Simple Flow (LOW)**

```
Programs: UTIL1, UTIL2
  UTIL1: 200 LOC, 10 cyclomatic
  UTIL2: 150 LOC, 8 cyclomatic

Result:
  Total Programs: 2
  Total Lines: 350
  Cyclomatic: 18
  Composite Score: 6.40
  Tier: LOW
```

**Example 2: Standard Flow (MEDIUM)**

```
Programs: PAYROLL1, PAYCALC, PAYDB
  PAYROLL1: 1200 LOC, 60 cyclomatic
  PAYCALC: 800 LOC, 40 cyclomatic
  PAYDB: 500 LOC, 25 cyclomatic

Result:
  Total Programs: 3
  Total Lines: 2500
  Cyclomatic: 125
  Composite Score: 31.20
  Tier: MEDIUM
```

**Example 3: Complex Flow (HIGH)**

```
Programs: BILLING1, BILLCALC, BILLDB
  BILLING1: 2500 LOC, 125 cyclomatic
  BILLCALC: 1800 LOC, 90 cyclomatic
  BILLDB: 1200 LOC, 60 cyclomatic

Result:
  Total Programs: 3
  Total Lines: 5500
  Cyclomatic: 275
  Composite Score: 67.20
  Tier: HIGH
```

### Handling Missing Data

**No Complexity Data**:

```python
result = builder.calculate_flow_complexity(['UNKNOWN1', 'UNKNOWN2'])

# Result:
{
    'totalPrograms': 2,
    'totalLines': 0,
    'cyclomaticComplexity': 0,
    'compositeScore': 0.80,  # Only program count contributes
    'tier': 'UNKNOWN'
}
```

**Partial Data**:

```python
# PROG1 has data, PROG2 doesn't
result = builder.calculate_flow_complexity(['PROG1', 'PROG2'])

# Result includes:
# - Metrics from PROG1 only
# - Total program count includes both
# - Tier is determined (not UNKNOWN)
```


---

## Configuration

### Configuration File

Configure complexity analysis in `config/legacy_analyzer.yaml`:

```yaml
complexity:
  # Thresholds for tier classification
  thresholds:
    low: 10
    medium: 25
    high: 50
  
  # Weights for composite score
  weights:
    loc: 0.3
    cyclomatic: 0.4
    dependencies: 0.3
  
  # God program threshold
  god_program_threshold: 100
  
  # Performance settings
  parallel_processing: true
  max_workers: 4
  cache_results: true
```

### Custom Thresholds

Customize thresholds for your project:

```python
from tools.legacy_analyzer.models.complexity import ComplexityThresholds

custom_thresholds = ComplexityThresholds(
    low_threshold=15.0,
    medium_threshold=35.0,
    high_threshold=70.0,
    loc_weight=0.25,
    cyclomatic_weight=0.45,
    deps_weight=0.30
)

analyzer = ComplexityAnalyzer(thresholds=custom_thresholds)
```

### Adjusting Weights

Adjust weights based on your priorities:

```python
# Emphasize cyclomatic complexity
thresholds = ComplexityThresholds(
    loc_weight=0.2,
    cyclomatic_weight=0.6,  # Higher weight
    deps_weight=0.2
)

# Emphasize dependencies
thresholds = ComplexityThresholds(
    loc_weight=0.2,
    cyclomatic_weight=0.3,
    deps_weight=0.5  # Higher weight
)
```

---

## Use Cases

### Use Case 1: Migration Effort Estimation

Estimate effort based on complexity:

```python
# Get all programs with complexity
programs = database.execute_query("""
    SELECT program_name, composite_score, complexity_tier
    FROM complexity_metrics
    ORDER BY composite_score DESC
""")

# Estimate effort (1 day per 10 complexity points)
total_effort = 0
for program, score, tier in programs:
    effort_days = score / 10
    total_effort += effort_days
    print(f"{program}: {effort_days:.1f} days ({tier})")

print(f"\nTotal Estimated Effort: {total_effort:.1f} days")
```

### Use Case 2: Resource Allocation

Allocate resources based on complexity distribution:

```bash
# Get complexity statistics
python -m tools.legacy_analyzer complexity stats \
    --db analyzer.db

# Output:
# LOW: 60% - Junior developers
# MEDIUM: 30% - Mid-level developers
# HIGH: 8% - Senior developers
# VERY_HIGH: 2% - Architects
```

### Use Case 3: Identifying Refactoring Candidates

Find programs that should be refactored before migration:

```bash
# Get god programs
python -m tools.legacy_analyzer complexity god-programs \
    --db analyzer.db \
    --output refactoring_candidates.csv
```

```python
# Programmatic approach
god_programs = database.execute_query("""
    SELECT program_name, composite_score, lines_of_code, cyclomatic_complexity
    FROM complexity_metrics
    WHERE composite_score > 100
    ORDER BY composite_score DESC
""")

for program, score, loc, cyclomatic in god_programs:
    print(f"REFACTOR: {program}")
    print(f"  Score: {score:.2f}")
    print(f"  LOC: {loc}")
    print(f"  Cyclomatic: {cyclomatic}")
```

### Use Case 4: Risk Assessment

Identify high-risk programs (high complexity + high usage):

```python
# High complexity + high usage = high risk
high_risk = database.execute_query("""
    SELECT c.program_name, c.composite_score, s.execution_count
    FROM complexity_metrics c
    JOIN smf_usage s ON c.program_name = s.program_name
    WHERE c.complexity_tier IN ('HIGH', 'VERY_HIGH')
      AND s.execution_count > 1000
    ORDER BY c.composite_score DESC
""")

for program, score, executions in high_risk:
    print(f"HIGH RISK: {program}")
    print(f"  Complexity: {score:.2f}")
    print(f"  Executions: {executions}")
```

### Use Case 5: Wave Planning

Group flows by complexity for phased migration:

```python
# Group flows by tier
flows_by_tier = {
    'LOW': [],
    'MEDIUM': [],
    'HIGH': [],
    'VERY_HIGH': []
}

for flow_id, programs in all_flows.items():
    result = builder.calculate_flow_complexity(programs)
    if result['tier'] != 'UNKNOWN':
        flows_by_tier[result['tier']].append(flow_id)

# Plan waves
print("Wave 1 (LOW complexity):")
for flow_id in flows_by_tier['LOW']:
    print(f"  - {flow_id}")

print("\nWave 2 (MEDIUM complexity):")
for flow_id in flows_by_tier['MEDIUM']:
    print(f"  - {flow_id}")

print("\nWave 3 (HIGH complexity):")
for flow_id in flows_by_tier['HIGH']:
    print(f"  - {flow_id}")
```

---

## Language-Specific Considerations

### COBOL

**Decision Points**:
- IF statements
- PERFORM VARYING
- EVALUATE/WHEN
- AND/OR operators

**Example**:
```cobol
   IF WS-AMOUNT > 1000              ← +1
       AND WS-TYPE = 'A'            ← +1 (AND)
       PERFORM PROCESS-LARGE
   END-IF.
   
   EVALUATE WS-STATUS               ← +1
       WHEN 'ACTIVE'                ← +1
           PERFORM ACTIVE-PROCESS
       WHEN 'INACTIVE'              ← +1
           PERFORM INACTIVE-PROCESS
   END-EVALUATE.
```

**Cyclomatic**: 1 + 5 = 6

### PL/I

**Decision Points**:
- IF statements
- DO WHILE/UNTIL
- SELECT/WHEN
- & (AND) and | (OR) operators

**Example**:
```pli
   IF amount > 1000 &               ← +1 (IF)
      type = 'A' THEN               ← +1 (&)
       CALL process_large;
   
   SELECT (status);                 ← +1
       WHEN ('ACTIVE')              ← +1
           CALL active_process;
       WHEN ('INACTIVE')            ← +1
           CALL inactive_process;
   END;
```

**Cyclomatic**: 1 + 5 = 6

### JCL

**Decision Points**:
- IF/THEN/ELSE
- COND parameters

**Example**:
```jcl
//STEP1    EXEC PGM=PROG1
//STEP2    EXEC PGM=PROG2,COND=(0,NE,STEP1)    ← +1
//STEP3    IF (STEP1.RC = 0) THEN              ← +1
//           EXEC PGM=PROG3
//         ELSE                                  ← +1
//           EXEC PGM=PROG4
//         ENDIF
```

**Cyclomatic**: 1 + 3 = 4

**Note**: JCL has simpler complexity model than procedural languages


---

## Best Practices

### 1. Establish Baselines

Analyze current system first to establish baselines:

```bash
# Analyze all programs
python -m tools.legacy_analyzer complexity analyze \
    --source-dir ./cobol \
    --db analyzer.db

# Get statistics
python -m tools.legacy_analyzer complexity stats \
    --db analyzer.db
```

### 2. Set Realistic Thresholds

Adjust thresholds for your environment:

```python
# Review distribution
stats = analyzer.get_statistics()
print(f"Average Score: {stats['average_score']:.2f}")
print(f"Median Score: {stats['median_score']:.2f}")
print(f"90th Percentile: {stats['p90_score']:.2f}")

# Adjust thresholds based on distribution
custom_thresholds = ComplexityThresholds(
    low_threshold=stats['p25_score'],
    medium_threshold=stats['p50_score'],
    high_threshold=stats['p75_score']
)
```

### 3. Track Trends Over Time

Monitor complexity over time:

```python
# Store historical data
history = []
for date, metrics in historical_metrics:
    history.append({
        'date': date,
        'average_score': metrics['average_score'],
        'god_program_count': metrics['god_program_count']
    })

# Plot trends
import matplotlib.pyplot as plt
dates = [h['date'] for h in history]
scores = [h['average_score'] for h in history]
plt.plot(dates, scores)
plt.title('Average Complexity Over Time')
plt.show()
```

### 4. Combine with Other Metrics

Use complexity with flow analysis and usage data:

```python
# Combine complexity with usage
analysis = database.execute_query("""
    SELECT c.program_name, 
           c.composite_score, 
           c.complexity_tier,
           u.execution_count,
           d.dependency_count
    FROM complexity_metrics c
    LEFT JOIN usage_stats u ON c.program_name = u.program_name
    LEFT JOIN dependency_counts d ON c.program_name = d.program_name
    ORDER BY c.composite_score DESC
""")
```

### 5. Refactor Before Migration

Address god programs early:

```python
# Identify refactoring candidates
refactor_candidates = database.execute_query("""
    SELECT program_name, composite_score
    FROM complexity_metrics
    WHERE composite_score > 100
    ORDER BY composite_score DESC
""")

# Create refactoring plan
for program, score in refactor_candidates:
    print(f"REFACTOR: {program} (score: {score:.2f})")
    print(f"  1. Break into smaller modules")
    print(f"  2. Extract common functionality")
    print(f"  3. Simplify decision logic")
```

### 6. Document Decisions

Record threshold choices and rationale:

```yaml
# complexity_config.yaml
complexity:
  thresholds:
    low: 15  # Adjusted from 10 based on baseline analysis
    medium: 35  # Adjusted from 25 based on team capacity
    high: 70  # Adjusted from 50 based on risk tolerance
  
  rationale: |
    Thresholds adjusted based on:
    - Baseline analysis showing median score of 28
    - Team composition (60% mid-level, 30% senior, 10% junior)
    - Risk tolerance for migration project
    - Historical refactoring success rates
```

### 7. Use Parallel Processing

Enable parallel processing for large codebases:

```python
analyzer = ComplexityAnalyzer(
    parallel_processing=True,
    max_workers=8
)

# Analyze in batches
results = analyzer.analyze_all_programs(programs)
```

### 8. Cache Results

Cache complexity results to avoid recomputation:

```python
analyzer = ComplexityAnalyzer(cache_results=True)

# First analysis (computed)
metrics1 = analyzer.analyze_program('PROG1', code, 'COBOL')

# Second analysis (cached)
metrics2 = analyzer.analyze_program('PROG1', code, 'COBOL')
```

### 9. Incremental Analysis

Only re-analyze changed programs:

```python
# Get programs modified since last analysis
modified_programs = get_modified_programs(since_date)

# Analyze only modified programs
for program in modified_programs:
    metrics = analyzer.analyze_program(
        program_name=program,
        source_code=get_source_code(program),
        language=get_language(program)
    )
    analyzer.save_metrics(metrics, database)
```

### 10. Validate Results

Validate complexity calculations:

```python
# Spot check high-complexity programs
high_complexity = database.execute_query("""
    SELECT program_name, composite_score, lines_of_code, cyclomatic_complexity
    FROM complexity_metrics
    WHERE complexity_tier = 'VERY_HIGH'
    LIMIT 10
""")

for program, score, loc, cyclomatic in high_complexity:
    print(f"\nProgram: {program}")
    print(f"  Score: {score:.2f}")
    print(f"  LOC: {loc}")
    print(f"  Cyclomatic: {cyclomatic}")
    
    # Manual review
    source = get_source_code(program)
    print(f"  Manual LOC count: {count_lines(source)}")
    print(f"  Manual decision points: {count_decisions(source)}")
```

---

## Troubleshooting

### Issue: Complexity Seems Too High/Low

**Symptoms**: Scores don't match expectations

**Solutions**:

1. **Adjust Thresholds**:
```python
# Lower thresholds if scores seem high
custom_thresholds = ComplexityThresholds(
    low_threshold=15,
    medium_threshold=35,
    high_threshold=70
)
```

2. **Modify Weights**:
```python
# Reduce LOC weight if programs are large but simple
custom_thresholds = ComplexityThresholds(
    loc_weight=0.2,
    cyclomatic_weight=0.5,
    deps_weight=0.3
)
```

3. **Review Calculation**:
```python
# Debug calculation
metrics = analyzer.analyze_program(program, code, language)
print(f"LOC: {metrics.lines_of_code} × {analyzer.thresholds.loc_weight}")
print(f"Cyclomatic: {metrics.cyclomatic_complexity} × {analyzer.thresholds.cyclomatic_weight}")
print(f"Dependencies: {metrics.dependency_count_in + metrics.dependency_count_out} × {analyzer.thresholds.deps_weight}")
print(f"Total: {metrics.composite_score}")
```

### Issue: God Programs Not Detected

**Symptoms**: No god programs found despite complex codebase

**Solutions**:

1. **Lower Threshold**:
```yaml
complexity:
  god_program_threshold: 75  # Lower from 100
```

2. **Check Analysis**:
```python
# Verify programs were analyzed
count = database.execute_query("""
    SELECT COUNT(*) FROM complexity_metrics
""")[0][0]
print(f"Programs analyzed: {count}")
```

3. **Verify Source Code**:
```python
# Check if source code is available
programs_without_source = database.execute_query("""
    SELECT program_name 
    FROM inventory_programs
    WHERE program_name NOT IN (
        SELECT program_name FROM complexity_metrics
    )
""")
```

### Issue: Analysis is Slow

**Symptoms**: Complexity analysis takes too long

**Solutions**:

1. **Enable Parallel Processing**:
```python
analyzer = ComplexityAnalyzer(
    parallel_processing=True,
    max_workers=8
)
```

2. **Increase Workers**:
```yaml
complexity:
  max_workers: 16  # Increase from 4
```

3. **Use Caching**:
```python
analyzer = ComplexityAnalyzer(cache_results=True)
```

4. **Process in Batches**:
```python
batch_size = 100
for i in range(0, len(programs), batch_size):
    batch = programs[i:i+batch_size]
    results = analyzer.analyze_all_programs(batch)
    save_results(results)
```

### Issue: Flow Complexity Shows UNKNOWN

**Symptoms**: Flow complexity tier is UNKNOWN

**Solutions**:

1. **Check Complexity Data**:
```python
# Verify complexity metrics exist
for program in flow_programs:
    result = database.execute_query("""
        SELECT composite_score 
        FROM complexity_metrics 
        WHERE program_name = ?
    """, (program,))
    if not result:
        print(f"Missing complexity data for {program}")
```

2. **Run Complexity Analysis**:
```bash
python -m tools.legacy_analyzer complexity analyze \
    --source-dir ./cobol \
    --db analyzer.db
```

3. **Handle Partial Data**:
```python
result = builder.calculate_flow_complexity(programs)
if result['tier'] == 'UNKNOWN':
    print("Warning: No complexity data available")
    print("Run complexity analysis first")
```

---

## See Also

### Core Documentation

- **[User Guide](../USER_GUIDE.md)**: Complete end-user documentation
- **[API Reference](../API.md)**: Python API for programmatic access
- **[CLI Reference](../CLI_REFERENCE.md)**: Command-line interface
- **[Migration Guide](../MIGRATION_GUIDE.md)**: Migration planning workflows

### Related Advanced Topics

- **[Flow Analysis](FLOW_ANALYSIS.md)**: Program flow analysis
- **[CICS Integration](CICS_INTEGRATION.md)**: CICS metadata integration
- **[Service Grouping](SERVICE_GROUPING.md)**: Service boundary identification

### Configuration Files

- `config/legacy_analyzer.yaml`: Complexity configuration
- `config/complexity_thresholds.yaml`: Custom thresholds

### Example Scripts

- `examples/complexity_analysis_example.py`: Complete working examples
- `tools/legacy_analyzer/migration/demo_complexity_calculation.py`: Demo script

---

**Document Version**: 1.0  
**Last Updated**: February 3, 2026  
**Related Components**: ComplexityAnalyzer, MigrationFlowBuilder, ComplexityMetrics
