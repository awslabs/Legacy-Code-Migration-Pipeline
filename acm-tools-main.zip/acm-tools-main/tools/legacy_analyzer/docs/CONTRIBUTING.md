# Contributing Guide

## Table of Contents

- [Overview](#overview)
- [Getting Started](#getting-started)
- [Contribution Workflow](#contribution-workflow)
- [Code Standards](#code-standards)
- [Testing Requirements](#testing-requirements)
- [Documentation](#documentation)
- [Pull Request Process](#pull-request-process)
- [Code Review](#code-review)
- [Community Guidelines](#community-guidelines)
- [See Also](#see-also)

---

## Overview

Thank you for considering contributing to the Legacy Analyzer! This guide will help you understand our development process and standards.

### Ways to Contribute

- **Bug Reports**: Report issues you encounter
- **Feature Requests**: Suggest new features or improvements
- **Code Contributions**: Submit bug fixes or new features
- **Documentation**: Improve or expand documentation
- **Testing**: Add test cases or improve test coverage
- **Examples**: Provide usage examples

### Before You Start

1. Read this contributing guide
2. Review the [Development Guide](DEVELOPMENT.md)
3. Check existing issues and pull requests
4. Discuss major changes in an issue first

---

## Getting Started

### 1. Fork and Clone

```bash
# Fork the repository on GitHub
# Then clone your fork
git clone https://github.com/YOUR_USERNAME/smf.git
cd smf

# Add upstream remote
git remote add upstream https://github.com/ORIGINAL_OWNER/smf.git
```

### 2. Set Up Development Environment

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install development dependencies
pip install -r requirements-dev.txt

# Install package in editable mode
pip install -e .

# Verify setup
pytest tests/ -v
```

### 3. Create a Branch

```bash
# Update your fork
git checkout main
git pull upstream main

# Create feature branch
git checkout -b feature/your-feature-name

# Or for bug fixes
git checkout -b fix/issue-description
```

---

## Contribution Workflow

### 1. Make Changes

```bash
# Make your changes
# Edit files as needed

# Run tests frequently
pytest tests/ -v

# Check code style
black tools/legacy_analyzer/
flake8 tools/legacy_analyzer/
```

### 2. Commit Changes

```bash
# Stage changes
git add .

# Commit with descriptive message
git commit -m "Add feature: description of feature"

# Follow commit message conventions (see below)
```

### 3. Push Changes

```bash
# Push to your fork
git push origin feature/your-feature-name
```

### 4. Create Pull Request

1. Go to your fork on GitHub
2. Click "New Pull Request"
3. Select your branch
4. Fill out the PR template
5. Submit the pull request

---

## Code Standards

### Python Style

Follow PEP 8 with these modifications:

- **Line Length**: 100 characters (not 79)
- **Quotes**: Use double quotes for strings
- **Type Hints**: Required for all function signatures
- **Docstrings**: Required for all public functions and classes

### Code Formatting

**Use Black for formatting**:

```bash
# Format all code
black tools/legacy_analyzer/

# Check formatting
black --check tools/legacy_analyzer/
```

**Configuration** (in `pyproject.toml`):

```toml
[tool.black]
line-length = 100
target-version = ['py38', 'py39', 'py310', 'py311', 'py312']
```

### Linting

**Use Flake8 for linting**:

```bash
# Lint code
flake8 tools/legacy_analyzer/

# Configuration in .flake8
```

**Configuration** (in `.flake8`):

```ini
[flake8]
max-line-length = 100
exclude = .git,__pycache__,venv,build,dist
ignore = E203,W503
```

### Type Checking

**Use Mypy for type checking**:

```bash
# Type check code
mypy tools/legacy_analyzer/
```

**Example with type hints**:

```python
from typing import List, Dict, Optional

def analyze_program(
    program_name: str,
    source_code: str,
    language: str = "COBOL"
) -> Dict[str, any]:
    """
    Analyze a program and extract dependencies.
    
    Args:
        program_name: Name of the program
        source_code: Source code content
        language: Programming language (default: COBOL)
    
    Returns:
        Dictionary containing analysis results
    
    Raises:
        ValueError: If program_name is empty
        ParseError: If source code cannot be parsed
    """
    if not program_name:
        raise ValueError("program_name cannot be empty")
    
    dependencies: List[Dict[str, str]] = []
    # ... implementation ...
    
    return {"program": program_name, "dependencies": dependencies}
```

### Docstring Format

Use Google-style docstrings:

```python
def function_name(param1: str, param2: int) -> bool:
    """
    Brief description of function.
    
    Longer description if needed. Can span multiple lines
    and include additional details about the function.
    
    Args:
        param1: Description of param1
        param2: Description of param2
    
    Returns:
        Description of return value
    
    Raises:
        ValueError: When param1 is invalid
        TypeError: When param2 is not an integer
    
    Example:
        >>> result = function_name("test", 42)
        >>> print(result)
        True
    """
    pass
```

### Naming Conventions

**Classes**:
```python
class ProgramAnalyzer:  # PascalCase
    pass

class COBOLDependencyParser:  # Acronyms in uppercase
    pass
```

**Functions and Variables**:
```python
def analyze_program():  # snake_case
    pass

program_name = "TEST"  # snake_case
dependency_count = 0
```

**Constants**:
```python
MAX_DEPTH = 10  # UPPER_SNAKE_CASE
DEFAULT_LANGUAGE = "COBOL"
```

**Private Members**:
```python
class Analyzer:
    def __init__(self):
        self._internal_state = {}  # Leading underscore
    
    def _helper_method(self):  # Leading underscore
        pass
```

---

## Testing Requirements

### Test Coverage

- **Minimum Coverage**: 80% for new code
- **Target Coverage**: 90% or higher
- **Critical Paths**: 100% coverage required

### Writing Tests

**Test Structure**:

```python
import pytest
from tools.legacy_analyzer.parsers.cobol_parser import COBOLDependencyParser

class TestCOBOLParser:
    """Tests for COBOL parser."""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance."""
        return COBOLDependencyParser()
    
    def test_parse_call_statement(self, parser):
        """Test parsing of CALL statement."""
        # Arrange
        source_code = "CALL 'SUBPROG'."
        
        # Act
        dependencies = parser.parse(source_code, "test.cbl")
        
        # Assert
        assert len(dependencies) == 1
        assert dependencies[0]["target"] == "SUBPROG"
        assert dependencies[0]["type"] == "CALL"
    
    def test_parse_empty_code(self, parser):
        """Test parsing of empty source code."""
        dependencies = parser.parse("", "test.cbl")
        assert len(dependencies) == 0
    
    def test_parse_invalid_syntax(self, parser):
        """Test handling of invalid syntax."""
        with pytest.raises(ParseError):
            parser.parse("INVALID SYNTAX", "test.cbl")
```

### Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_cobol_parser.py -v

# Run specific test
pytest tests/test_cobol_parser.py::TestCOBOLParser::test_parse_call_statement -v

# Run with coverage
pytest --cov=tools.legacy_analyzer --cov-report=html tests/

# Run only fast tests
pytest tests/ -m "not slow"
```

### Test Categories

**Mark tests appropriately**:

```python
import pytest

@pytest.mark.unit
def test_unit_function():
    """Unit test."""
    pass

@pytest.mark.integration
def test_integration_feature():
    """Integration test."""
    pass

@pytest.mark.slow
def test_slow_operation():
    """Slow test."""
    pass
```

### Test Data

**Use fixtures for test data**:

```python
@pytest.fixture
def sample_cobol_code():
    """Sample COBOL code for testing."""
    return """
           IDENTIFICATION DIVISION.
           PROGRAM-ID. TESTPROG.
           PROCEDURE DIVISION.
               CALL 'SUBPROG'.
               STOP RUN.
    """

@pytest.fixture
def temp_database(tmp_path):
    """Temporary test database."""
    db_path = tmp_path / "test.db"
    db = SQLiteAdapter(str(db_path))
    db.connect()
    yield db
    db.close()
```

---

## Documentation

### Documentation Requirements

All contributions must include appropriate documentation:

- **Code Comments**: For complex logic
- **Docstrings**: For all public functions and classes
- **User Documentation**: For new features
- **API Documentation**: For new APIs
- **Examples**: For new functionality

### Updating Documentation

**When adding a new feature**:

1. Update relevant user guide (e.g., `USER_GUIDE.md`)
2. Update API reference (`API.md`)
3. Update CLI reference if applicable (`CLI_REFERENCE.md`)
4. Add examples to `examples/` directory
5. Update README if needed

**Documentation style**:

```markdown
# Feature Name

## Overview

Brief description of the feature.

## Usage

### Basic Usage

\`\`\`python
# Example code
from tools.legacy_analyzer import NewFeature

feature = NewFeature()
result = feature.execute()
\`\`\`

### Advanced Usage

\`\`\`python
# Advanced example
feature = NewFeature(option1=True, option2="value")
result = feature.execute_advanced()
\`\`\`

## Parameters

- **option1** (bool): Description of option1
- **option2** (str): Description of option2

## Returns

Description of return value.

## Examples

See `examples/new_feature_example.py` for complete examples.
```

### Code Examples

**Provide working examples**:

```python
"""
Example: Using the New Feature

This example demonstrates how to use the new feature
to accomplish a specific task.
"""

from tools.legacy_analyzer import NewFeature

def main():
    # Initialize feature
    feature = NewFeature()
    
    # Execute feature
    result = feature.execute()
    
    # Process results
    print(f"Result: {result}")

if __name__ == "__main__":
    main()
```

---

## Pull Request Process

### Before Submitting

**Checklist**:

- [ ] Code follows style guidelines
- [ ] All tests pass
- [ ] New tests added for new functionality
- [ ] Test coverage meets requirements (80%+)
- [ ] Documentation updated
- [ ] Commit messages follow conventions
- [ ] Branch is up to date with main

### PR Title Format

Use conventional commit format:

```
feat: Add CICS transaction analysis
fix: Correct COBOL parser CALL statement handling
docs: Update API reference for flow analyzer
test: Add integration tests for complexity analyzer
refactor: Simplify dependency resolution logic
perf: Optimize database query performance
```

### PR Description Template

```markdown
## Description

Brief description of changes.

## Type of Change

- [ ] Bug fix (non-breaking change fixing an issue)
- [ ] New feature (non-breaking change adding functionality)
- [ ] Breaking change (fix or feature causing existing functionality to change)
- [ ] Documentation update

## Related Issues

Fixes #123
Relates to #456

## Changes Made

- Change 1
- Change 2
- Change 3

## Testing

Describe testing performed:
- Unit tests added/updated
- Integration tests added/updated
- Manual testing performed

## Documentation

- [ ] Code comments added/updated
- [ ] Docstrings added/updated
- [ ] User documentation updated
- [ ] API documentation updated
- [ ] Examples added/updated

## Checklist

- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Tests added and passing
- [ ] Documentation updated
- [ ] No new warnings generated
```

### Commit Message Format

Follow conventional commits:

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types**:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `test`: Test changes
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `chore`: Maintenance tasks

**Examples**:

```
feat(parser): Add support for Natural language

Implement Natural language parser with support for:
- CALL statements
- INCLUDE statements
- Program boundary detection

Closes #123
```

```
fix(flow): Correct circular dependency detection

Fix issue where circular dependencies were not detected
when the cycle involved more than 3 programs.

Fixes #456
```


---

## Code Review

### Review Process

1. **Automated Checks**: CI/CD runs tests and checks
2. **Peer Review**: At least one reviewer required
3. **Maintainer Review**: Final approval from maintainer
4. **Merge**: Squash and merge to main

### Review Criteria

**Code Quality**:
- Follows style guidelines
- Well-structured and readable
- Appropriate error handling
- No code smells or anti-patterns

**Testing**:
- Adequate test coverage
- Tests are meaningful and comprehensive
- Edge cases covered
- Tests pass consistently

**Documentation**:
- Code is well-documented
- User documentation updated
- API documentation complete
- Examples provided

**Performance**:
- No obvious performance issues
- Efficient algorithms used
- Database queries optimized
- Memory usage reasonable

### Responding to Review Comments

**Be responsive**:
- Address all review comments
- Ask questions if unclear
- Make requested changes promptly
- Update PR description if scope changes

**Example responses**:

```markdown
> Consider using a list comprehension here

Good suggestion! Changed to:
\`\`\`python
dependencies = [parse_line(line) for line in lines if is_valid(line)]
\`\`\`

> This function is quite long. Can it be split?

Agreed. I've refactored it into three smaller functions:
- `_extract_calls()`
- `_extract_includes()`
- `_extract_datasets()`

> Can you add a test for the error case?

Added test `test_parse_invalid_syntax()` in commit abc123.
```

### Review Etiquette

**As a reviewer**:
- Be respectful and constructive
- Explain the reasoning behind suggestions
- Distinguish between required changes and suggestions
- Acknowledge good work

**As an author**:
- Don't take feedback personally
- Ask for clarification if needed
- Thank reviewers for their time
- Be open to suggestions

---

## Community Guidelines

### Code of Conduct

We are committed to providing a welcoming and inclusive environment:

- **Be Respectful**: Treat everyone with respect
- **Be Collaborative**: Work together constructively
- **Be Professional**: Maintain professional conduct
- **Be Inclusive**: Welcome diverse perspectives

### Communication Channels

- **GitHub Issues**: Bug reports and feature requests
- **Pull Requests**: Code contributions and discussions
- **Discussions**: General questions and ideas

### Getting Help

**Before asking**:
1. Check existing documentation
2. Search existing issues
3. Review examples

**When asking**:
- Provide context and details
- Include error messages
- Share relevant code snippets
- Describe what you've tried

**Example good question**:

```markdown
## Issue: COBOL parser not detecting CALL statements

**Environment**:
- Python 3.9
- Legacy Analyzer v1.0.0
- OS: Ubuntu 20.04

**Description**:
The COBOL parser is not detecting CALL statements in my source code.

**Source Code**:
\`\`\`cobol
CALL 'SUBPROG' USING PARAM1.
\`\`\`

**Expected**: Should detect CALL to SUBPROG
**Actual**: No dependencies found

**What I've tried**:
- Verified file is being parsed
- Checked parser logs (no errors)
- Tested with simpler CALL statement

**Logs**:
\`\`\`
[DEBUG] Parsing file: test.cbl
[DEBUG] Found 0 dependencies
\`\`\`
```

### Recognition

We value all contributions:

- Contributors listed in CONTRIBUTORS.md
- Significant contributions acknowledged in release notes
- Active contributors may be invited as maintainers

---

## See Also

### Related Documentation

- **[Development Guide](DEVELOPMENT.md)** - Development environment setup
- **[Architecture](ARCHITECTURE.md)** - System architecture
- **[User Guide](USER_GUIDE.md)** - User documentation
- **[API Reference](API.md)** - Python API documentation

### External Resources

- **PEP 8**: https://pep8.org/
- **Conventional Commits**: https://www.conventionalcommits.org/
- **Google Python Style Guide**: https://google.github.io/styleguide/pyguide.html
- **pytest Documentation**: https://docs.pytest.org/

### Quick Reference

**Common Commands**:

```bash
# Setup
python -m venv venv
source venv/bin/activate
pip install -r requirements-dev.txt
pip install -e .

# Development
black tools/legacy_analyzer/
flake8 tools/legacy_analyzer/
mypy tools/legacy_analyzer/
pytest tests/ -v

# Testing
pytest tests/ --cov=tools.legacy_analyzer
pytest tests/ -k "cobol"
pytest tests/ -m "not slow"

# Git
git checkout -b feature/my-feature
git add .
git commit -m "feat: add my feature"
git push origin feature/my-feature
```

**Style Quick Reference**:

```python
# Good
def analyze_program(program_name: str, language: str = "COBOL") -> Dict[str, any]:
    """Analyze a program and extract dependencies."""
    dependencies: List[Dict[str, str]] = []
    return {"program": program_name, "dependencies": dependencies}

# Bad
def analyze(p,l='COBOL'):
    d=[]
    return {'program':p,'dependencies':d}
```

**Test Quick Reference**:

```python
# Good
class TestCOBOLParser:
    @pytest.fixture
    def parser(self):
        return COBOLDependencyParser()
    
    def test_parse_call_statement(self, parser):
        """Test parsing of CALL statement."""
        source_code = "CALL 'SUBPROG'."
        dependencies = parser.parse(source_code, "test.cbl")
        assert len(dependencies) == 1
        assert dependencies[0]["target"] == "SUBPROG"

# Bad
def test():
    p=COBOLDependencyParser()
    d=p.parse("CALL 'SUBPROG'.","test.cbl")
    assert len(d)==1
```

---

## Thank You!

Thank you for contributing to the Legacy Analyzer! Your contributions help make mainframe modernization more accessible and efficient.

**Questions?**

If you have questions about contributing, please:
1. Check this guide and the Development Guide
2. Search existing issues and discussions
3. Open a new issue with your question

We appreciate your interest in improving the Legacy Analyzer!

---

**Document Version**: 1.0  
**Last Updated**: February 2026  
**Part of**: Legacy Analyzer Documentation Suite
