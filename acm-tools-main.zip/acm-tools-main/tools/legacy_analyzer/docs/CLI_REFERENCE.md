# CLI Reference

Complete command-line interface reference for the Legacy Analyzer tool.

## Table of Contents

- [Overview](#overview)
- [Breaking Changes (v3.0.0)](#breaking-changes-v300)
- [Global Options](#global-options)
- [Commands](#commands)
  - [analyze](#analyze)
  - [load](#load)
  - [flow](#flow)
  - [migration](#migration)
  - [metadata](#metadata)
  - [service](#service)
- [Common Workflows](#common-workflows)
- [Exit Codes](#exit-codes)

## Overview

The Legacy Analyzer provides a comprehensive CLI for analyzing mainframe applications. All commands follow the pattern:

```bash
python -m legacy_analyzer <command> [subcommand] [options]
```

Or using the shorter alias:

```bash
python -m tools.legacy_analyzer <command> [subcommand] [options]
```

## Breaking Changes (v3.0.0)

**IMPORTANT:** Version 3.0.0 introduces breaking changes to output formats and file structure.

### Removed Format Options

The following format options have been removed:

1. **`--format text`** - Removed from all commands
   - **Replacement:** Use `--format markdown` instead
   - **Affected commands:** `flow entry-points`, `service identify`

2. **`--format csv`** - Removed from entry-points command
   - **Replacement:** Use `--format json` or `--format markdown` instead
   - **Affected commands:** `flow entry-points`

### Changed Output Structure

Entry points files are now organized in a dedicated folder:

**Before (v2.x):**
```
results/analysis/
├── reports/
│   └── entry_points.txt
└── entry_points.json
```

**After (v3.0.0):**
```
results/analysis/
├── entry_points/
│   ├── entry_points.md    (renamed from .txt)
│   └── entry_points.json  (moved from root)
└── reports/
    └── analysis_summary.md
```

### Migration Guide

If you have scripts using the old format options, update them as follows:

```bash
# OLD (will fail with error)
python -m legacy_analyzer flow entry-points --db analysis.db --format text
python -m legacy_analyzer flow entry-points --db analysis.db --format csv

# NEW (correct)
python -m legacy_analyzer flow entry-points --db analysis.db --format markdown
python -m legacy_analyzer flow entry-points --db analysis.db --format json
```

### Error Messages

When using removed format options, you will see:

```bash
$ python -m legacy_analyzer flow entry-points --db test.db --format text
error: argument --format: invalid choice: 'text' (choose from 'json', 'markdown')

$ python -m legacy_analyzer flow entry-points --db test.db --format csv
error: argument --format: invalid choice: 'csv' (choose from 'json', 'markdown')
```

## Global Options

These options are available for all commands:

- `--help`, `-h`: Show help message and exit
- `--version`: Show version information

## Commands

### analyze

Perform complete source code analysis including inventory discovery, dependency extraction, and validation.

```bash
python -m legacy_analyzer analyze --source-dir <directory> --db <database> [options]
```

**Required Options:**
- `--source-dir`: Source code directory to analyze
- `--db`: Path to SQLite database file (will be created if it doesn't exist)

**Optional Options:**
- `--languages`: Comma-separated list of languages to analyze (default: COBOL,PLI,JCL,REXX,NATURAL,RPG,ASM)
- `--parallel`: Enable parallel processing (default: True)
- `--no-parallel`: Disable parallel processing
- `--max-workers`: Maximum number of parallel workers (default: CPU count)
- `--cache-dir`: Directory for caching parsed results (default: .cache)
- `--no-cache`: Disable caching
- `--program-level`: Enable program-level analysis for multi-program files
- `--copybook-analysis`: Enable advanced copybook analysis

**Examples:**

```bash
# Basic analysis
python -m legacy_analyzer analyze \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --db results/analysis.db

# Analysis with specific languages
python -m legacy_analyzer analyze \
  --source-dir ./mainframe/src \
  --db analysis.db \
  --languages COBOL,JCL

# Analysis with parallel processing disabled
python -m legacy_analyzer analyze \
  --source-dir ./src \
  --db analysis.db \
  --no-parallel

# Analysis with program-level granularity
python -m legacy_analyzer analyze \
  --source-dir ./src \
  --db analysis.db \
  --program-level

# Analysis with copybook analysis
python -m legacy_analyzer analyze \
  --source-dir ./src \
  --db analysis.db \
  --copybook-analysis
```

**What It Does:**

1. **Inventory Discovery**: Scans source directory and discovers all artifacts
2. **Dependency Extraction**: Parses source files and extracts dependencies
3. **Validation**: Validates dependencies and calculates completeness score
4. **Database Storage**: Stores all results in SQLite database

**Output:**

The command provides detailed progress information and a comprehensive summary:

```
============================================================
COMPLETE ANALYSIS SUMMARY
============================================================
FILE-LEVEL STATISTICS:
  Total files discovered:         191
  Files with dependencies:        156
  Multi-program files:            12
  Single-program files:           144
  Mixed content files:            3

DEPENDENCY STATISTICS:
  Total dependencies found:       487
  Dependencies stored:            487
  Missing artifacts detected:     23
  Inventory completeness:         95.3%

LANGUAGE BREAKDOWN:
  COBOL: 156 files
  JCL: 35 files
============================================================
```

### load

Load inventory data from CSV files into the database.

```bash
python -m legacy_analyzer load --type <type> --file <file> --db <database> [options]
```

**Required Options:**
- `--type`: Type of inventory to load (choices: programs, copybooks, datasets, jcl, cics)
- `--file`: Path to CSV file
- `--db`: Path to SQLite database file

**Optional Options:**
- `--create-schema`: Create database schema if it doesn't exist (default: True)
- `--no-create-schema`: Don't create schema automatically

**CSV Format Requirements:**

Each inventory type requires specific CSV columns:

**Programs CSV:**
```csv
program_name,language,source_file,description
CBACT01C,COBOL,/path/to/CBACT01C.cbl,Account validation program
CBACT02C,COBOL,/path/to/CBACT02C.cbl,Account update program
```

**Copybooks CSV:**
```csv
copybook_name,source_file,description
CUSTCOPY,/path/to/CUSTCOPY.cpy,Customer record layout
ACCTCOPY,/path/to/ACCTCOPY.cpy,Account record layout
```

**Datasets CSV:**
```csv
dataset_name,type,description
ACCTDAT,VSAM,Account master file
CUSTDAT,VSAM,Customer master file
```

**JCL CSV:**
```csv
jcl_name,source_file,description
DAILYJOB,/path/to/DAILYJOB.jcl,Daily batch processing
MONTHJOB,/path/to/MONTHJOB.jcl,Monthly reporting
```

**CICS CSV:**
```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Account Update,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data File,
```

**Examples:**

```bash
# Load programs inventory
python -m legacy_analyzer load \
  --type programs \
  --file inventory/programs.csv \
  --db analysis.db

# Load copybooks inventory
python -m legacy_analyzer load \
  --type copybooks \
  --file inventory/copybooks.csv \
  --db analysis.db

# Load CICS metadata
python -m legacy_analyzer load \
  --type cics \
  --file exports/cics_inventory.csv \
  --db analysis.db

# Load without creating schema (assumes schema exists)
python -m legacy_analyzer load \
  --type programs \
  --file programs.csv \
  --db analysis.db \
  --no-create-schema
```

**Output:**

```
Loading programs inventory from CSV...

------------------------------------------------------------
LOAD SUMMARY
------------------------------------------------------------
Total processed:  156
Inserted:         156
Updated:          0
------------------------------------------------------------
```

### flow

Analyze program flows and detect entry points.

#### flow entry-points

Detect and list entry points in the codebase.

```bash
python -m legacy_analyzer flow entry-points --db <database> [options]
```

**Required Options:**
- `--db`: Path to database file

**Optional Options:**
- `--format`: Output format (choices: json, markdown; default: markdown)
- `--output`: Output file path (if not specified, prints to stdout)
- `--use-metadata`: Use CICS/JCL metadata for enhanced detection
- `--include-disabled`: Include disabled CICS transactions
- `--include-inferred`: Include inferred entry points from code analysis

**Breaking Changes (v3.0.0):**
- The `text` format option has been removed. Use `markdown` instead.
- The `csv` format option has been removed for entry-points. Use `json` or `markdown` instead.

**Entry Point Types:**

- **ONLINE**: CICS transaction entry points
- **BATCH**: JCL job entry points  
- **INFERRED**: Programs not called by any other program

**Examples:**

```bash
# Detect entry points (markdown format, default)
python -m legacy_analyzer flow entry-points --db analysis.db

# Detect with metadata enhancement
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata

# Export to JSON
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --format json \
  --output entry_points/entry_points.json

# Export to markdown with custom path
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --format markdown \
  --output entry_points/entry_points.md

# Include disabled transactions
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --include-disabled
```

**Markdown Output Example:**

```
================================================================================
ENTRY POINT DETECTION
================================================================================

ONLINE Entry Points (8):
--------------------------------------------------------------------------------

  Program: COACTUPC
    Confidence: HIGH
    Source: CICS_METADATA
    Transaction: CAUP
    Status: ENABLED
    Description: Credit Card Account Update

  Program: COACTUP
    Confidence: HIGH
    Source: CICS_METADATA
    Transaction: CACT
    Status: ENABLED
    Description: Credit Card Account List

BATCH Entry Points (12):
--------------------------------------------------------------------------------

  Program: CBACT01C
    Confidence: HIGH
    Source: JCL_METADATA
    JCL: DALYREJS
    Description: Account validation batch job

INFERRED Entry Points (3):
--------------------------------------------------------------------------------

  Program: UTILPROG
    Confidence: INFERRED
    Source: CODE_ANALYSIS
    Description: Program not called by any other program

================================================================================
SUMMARY STATISTICS
================================================================================
Total Entry Points: 23

By Entry Type:
  BATCH: 12
  INFERRED: 3
  ONLINE: 8

By Confidence Level:
  HIGH: 20
  INFERRED: 3
================================================================================
```

**JSON Output Example:**

```json
{
  "entry_points": [
    {
      "program_name": "COACTUPC",
      "entry_type": "ONLINE",
      "confidence": "HIGH",
      "source": "CICS_METADATA",
      "transaction_id": "CAUP",
      "status": "ENABLED",
      "description": "Credit Card Account Update"
    }
  ],
  "summary": {
    "total_entry_points": 23,
    "by_entry_type": {
      "ONLINE": 8,
      "BATCH": 12,
      "INFERRED": 3
    },
    "by_confidence": {
      "HIGH": 20,
      "INFERRED": 3
    }
  }
}
```

#### flow analyze

Analyze program flow starting from a specific program (not yet implemented).

```bash
python -m legacy_analyzer flow analyze --program <program> --db <database>
```

#### flow graph

Generate visual graph of program dependencies (not yet implemented).

```bash
python -m legacy_analyzer flow graph --db <database> --output <file>
```

#### flow circular

Detect circular dependencies (not yet implemented).

```bash
python -m legacy_analyzer flow circular --db <database>
```

### migration

Build and export migration flows and job orchestration metadata.

#### migration build-flows

Build migration flows from analyzed dependencies.

```bash
python -m legacy_analyzer migration build-flows --db <database> [options]
```

**Required Options:**
- `--db`: Path to database file

**Optional Options:**
- `--external-config`: Path to external interface configuration file (YAML)

**Examples:**

```bash
# Build flows with default settings
python -m legacy_analyzer migration build-flows --db analysis.db

# Build flows with external interface configuration
python -m legacy_analyzer migration build-flows \
  --db analysis.db \
  --external-config config/external_interfaces.yaml
```

**External Interface Configuration Format:**

```yaml
external_interfaces:
  inbound:
    - program: COACTUPC
      interface_type: CICS_TRANSACTION
      transaction_id: CAUP
      description: Account update transaction
    
    - program: CBACT01C
      interface_type: JCL_JOB
      jcl_name: DALYREJS
      description: Daily account processing
  
  outbound:
    - program: DBUTIL01
      interface_type: DATABASE
      target: DB2_ACCOUNTS
      description: Account database access
```

**Output:**

```
Connecting to database: analysis.db

Building migration flows...

✓ Successfully built 35 migration flows
  Time elapsed: 2.34 seconds

Sample flow IDs:
  - FLOW_COACTUPC
  - FLOW_COACTUP
  - FLOW_CBACT01C
  - FLOW_CBACT02C
  - FLOW_CBCUS01C
  ... and 30 more
```

#### migration export-flows

Export migration flows to JSON format.

```bash
python -m legacy_analyzer migration export-flows --db <database> --output <file> [options]
```

**Required Options:**
- `--db`: Path to database file
- `--output`: Output JSON file path

**Optional Options:**
- `--flows`: Comma-separated list of specific flow IDs to export
- `--min-complexity`: Minimum complexity score filter
- `--business-domain`: Filter by business domain
- `--extended-scope`: Include extended scope information
- `--sort`: Sort order (choices: complexity-asc, complexity-desc, name, entry-type)

**Examples:**

```bash
# Export all flows
python -m legacy_analyzer migration export-flows \
  --db analysis.db \
  --output flows.json

# Export specific flows
python -m legacy_analyzer migration export-flows \
  --db analysis.db \
  --output selected_flows.json \
  --flows FLOW_COACTUPC,FLOW_CBACT01C

# Export with complexity filter
python -m legacy_analyzer migration export-flows \
  --db analysis.db \
  --output complex_flows.json \
  --min-complexity 50

# Export with sorting
python -m legacy_analyzer migration export-flows \
  --db analysis.db \
  --output flows_by_complexity.json \
  --sort complexity-asc

# Export with extended scope
python -m legacy_analyzer migration export-flows \
  --db analysis.db \
  --output flows_extended.json \
  --extended-scope
```

**Output:**

```
Connecting to database: analysis.db

Exporting all flows...

✓ Successfully exported 35 flows
  Output file: flows.json
  Time elapsed: 0.45 seconds

Summary:
  Total flows: 35
  By complexity:
    LOW: 12
    MEDIUM: 18
    HIGH: 5
  By entry type:
    BATCH: 12
    ONLINE: 20
    INFERRED: 3
```

**JSON Output Format:**

```json
{
  "flows": [
    {
      "flowId": "FLOW_COACTUPC",
      "entryPoint": {
        "program": "COACTUPC",
        "primaryType": "ONLINE",
        "transactionId": "CAUP",
        "confidence": "HIGH"
      },
      "programs": [
        "COACTUPC",
        "CBACT01C",
        "CBACT02C"
      ],
      "complexity": {
        "totalPrograms": 3,
        "totalDependencies": 5,
        "maxDepth": 2,
        "tier": "LOW",
        "score": 15
      },
      "interfaces": {
        "inbound": [
          {
            "type": "CICS_TRANSACTION",
            "transactionId": "CAUP",
            "description": "Account update transaction"
          }
        ],
        "outbound": [
          {
            "type": "DATABASE",
            "target": "ACCTDAT",
            "operations": ["READ", "UPDATE"]
          }
        ]
      }
    }
  ],
  "metadata": {
    "exportDate": "2026-02-03T10:30:00Z",
    "database": "analysis.db",
    "totalFlows": 35,
    "sortOrder": "complexity-asc"
  }
}
```

#### migration export-jobs

Export JCL job orchestration metadata to JSON format.

```bash
python -m legacy_analyzer migration export-jobs --db <database> [options]
```

**Required Options:**
- `--db`: Path to database file

**Optional Options:**
- `--output-dir`: Output directory for JSON files (default: current directory)
- `--sort-by`: Sort strategy (choices: name, type, dependencies, complexity; default: name)

**Sort Strategies:**

1. **name** (Default): Alphabetical sorting by job name
2. **type**: Groups APPLICATION jobs before INFRASTRUCTURE jobs
3. **dependencies**: Topological sort based on job dependencies
4. **complexity**: Sorts by number of steps (descending)

**Job Categories:**

- **APPLICATION**: Jobs that invoke at least one custom program
- **INFRASTRUCTURE**: Jobs that only invoke utility programs (IEFBR14, IDCAMS, SORT, etc.)

**Examples:**

```bash
# Export jobs with default settings (sorted by name)
python -m legacy_analyzer migration export-jobs --db analysis.db

# Export jobs sorted by type
python -m legacy_analyzer migration export-jobs \
  --db analysis.db \
  --output-dir results/jobs \
  --sort-by type

# Export jobs sorted by dependencies (execution order)
python -m legacy_analyzer migration export-jobs \
  --db analysis.db \
  --output-dir results/jobs \
  --sort-by dependencies

# Export jobs sorted by complexity
python -m legacy_analyzer migration export-jobs \
  --db analysis.db \
  --output-dir results/jobs \
  --sort-by complexity

# Export all sorting strategies for comparison
for strategy in name type dependencies complexity; do
  python -m legacy_analyzer migration export-jobs \
    --db analysis.db \
    --output-dir results/jobs \
    --sort-by ${strategy}
done
```

**Output:**

```
Connecting to database: analysis.db

Exporting JCL jobs...
  Sort strategy: name

✓ Successfully exported 35 jobs
  Output file: jobs_by_name.json
  Time elapsed: 0.23 seconds

Summary:
  Total jobs: 35
  Application jobs: 28
  Infrastructure jobs: 7
```

**JSON Output Format:**

```json
{
  "jobs": [
    {
      "jobName": "DALYREJS",
      "jobType": "APPLICATION",
      "hasCustomCode": true,
      "linkedFlow": "FLOW_CBACT01C",
      "steps": [
        {
          "stepName": "STEP01",
          "program": "IEFBR14",
          "type": "UTILITY",
          "purpose": "Allocate or delete datasets",
          "flowEntry": false
        },
        {
          "stepName": "STEP02",
          "program": "CBACT01C",
          "type": "CUSTOM",
          "purpose": "Execute CBACT01C",
          "flowEntry": true
        }
      ],
      "datasets": [
        "ACCTDAT",
        "CUSTDAT"
      ],
      "dependencies": {
        "mustRunAfter": ["DAILYEXT"],
        "mustRunBefore": ["DAILYRPT"]
      }
    }
  ],
  "summary": {
    "totalJobs": 35,
    "applicationJobs": 28,
    "infrastructureJobs": 7,
    "exportDate": "2026-02-03T10:30:00.000Z",
    "database": "analysis.db",
    "sortedBy": "name"
  }
}
```

### metadata

Manage CICS and other metadata.

#### metadata convert-csd

Convert CICS System Definition (CSD) files to enhanced CSV format.

```bash
python -m legacy_analyzer metadata convert-csd --input <csd_file> --output <csv_file> [options]
```

**Required Options:**
- `--input`: Path to CSD file
- `--output`: Path to output CSV file

**Optional Options:**
- `--dry-run`: Show what would be extracted without writing file

**Examples:**

```bash
# Convert CSD file to CSV
python -m legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv

# Dry run to preview extraction
python -m legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv \
  --dry-run
```

**What It Extracts:**

- **TRANSACTION** definitions with program associations
- **PROGRAM** definitions with language and status
- **FILE** definitions with dataset mappings
- **MAPSET** definitions for screen layouts

**Output:**

```
Parsing CSD file: app/csd/CARDDEMO.csd

Parsing Summary:
  Transactions: 8
  Programs:     11
  Files:        5
  Mapsets:      5
  Total:        29

Writing CSV to: exports/cics_inventory.csv

✓ Conversion completed successfully
  Output file: exports/cics_inventory.csv
```

**CSV Output Format:**

```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Account Update,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data File,
COACTUP,MAPSET,CARDDEMO,ENABLED,,,Credit Card Account Update Map,
```

#### metadata load-from-source

Discover, convert, and load CICS metadata in a single command.

```bash
python -m legacy_analyzer metadata load-from-source --source-dir <directory> --db <database> [options]
```

**Required Options:**
- `--source-dir`: Source directory to scan for CSD files
- `--db`: Path to SQLite database file

**Optional Options:**
- `--keep-csv`: Save converted CSV file to this path
- `--recursive`: Scan subdirectories recursively (default: True)
- `--no-recursive`: Do not scan subdirectories

**What It Does:**

1. **Scan**: Discovers all `.csd` files in the source directory
2. **Convert**: Parses CSD files and converts them to enhanced CSV format
3. **Load**: Imports the CSV data into the database

**Examples:**

```bash
# Basic usage - scan, convert, and load in one command
python -m legacy_analyzer metadata load-from-source \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --db results/analysis/analysis.db

# Keep the converted CSV file for review
python -m legacy_analyzer metadata load-from-source \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --db results/analysis/analysis.db \
  --keep-csv exports/cics_inventory.csv

# Scan only the specified directory (no subdirectories)
python -m legacy_analyzer metadata load-from-source \
  --source-dir ./app/csd \
  --db analyzer.db \
  --no-recursive
```

**Output:**

```
============================================================
CICS METADATA LOAD FROM SOURCE
============================================================
Source directory: ./examples/code/cobol/carddemoV2
Database:         results/analysis/analysis.db
Recursive:        True
============================================================

[Step 1/3] Scanning for CSD files...
------------------------------------------------------------

✓ Found 1 CSD file(s):
  - app/csd/CARDDEMO.csd

[Step 2/3] Converting CSD files to CSV...
------------------------------------------------------------

[1/1] Processing: CARDDEMO.csd
  ✓ Parsed successfully
    Transactions: 8
    Programs:     11
    Files:        5
    Mapsets:      5
    Total:        29

------------------------------------------------------------
CONVERSION SUMMARY
------------------------------------------------------------
Total Transactions: 8
Total Programs:     11
Total Files:        5
Total Mapsets:      5
Total Resources:    29
------------------------------------------------------------

Writing CSV file...
  ✓ Using temporary CSV file

[Step 3/3] Loading CSV into database...
------------------------------------------------------------

Connecting to database: results/analysis/analysis.db
Ensuring inventory schema exists...

Loading CICS inventory from CSV...

------------------------------------------------------------
LOAD SUMMARY
------------------------------------------------------------
Total processed:  29
Inserted:         29
Updated:          0
------------------------------------------------------------

✓ Temporary CSV file cleaned up

============================================================
✓ LOAD FROM SOURCE COMPLETED SUCCESSFULLY
============================================================
CSD files processed:  1
Resources loaded:     29
Database:             results/analysis/analysis.db
============================================================

Next steps:
  - Use 'flow entry-points' to see entry points with CICS metadata
  - Use 'report executive' to generate comprehensive analysis
  - Query the 'inventory_cics' table directly for CICS resources
```

#### metadata scan

Scan a directory for CICS metadata files.

```bash
python -m legacy_analyzer metadata scan --source-dir <directory> [options]
```

**Required Options:**
- `--source-dir`: Source directory to scan

**Optional Options:**
- `--file-types`: Types of files to scan for (choices: csd, csv, all; default: all)
- `--convert`: Auto-convert discovered CSD files to CSV
- `--output-dir`: Output directory for converted CSV files (used with --convert)
- `--recursive`: Scan subdirectories recursively (default: True)
- `--no-recursive`: Do not scan subdirectories

**Examples:**

```bash
# Scan and list all metadata files
python -m legacy_analyzer metadata scan \
  --source-dir ./examples/code/cobol/carddemoV2

# Scan for CSD files only
python -m legacy_analyzer metadata scan \
  --source-dir ./app \
  --file-types csd

# Scan and auto-convert CSD files
python -m legacy_analyzer metadata scan \
  --source-dir ./app \
  --convert \
  --output-dir ./exports
```

**Output:**

```
Scanning directory: ./examples/code/cobol/carddemoV2
  File types: csd, csv
  Recursive: True

Scan Results:
  CSD files:  1
  CSV files:  0
  Total:      1

CSD Files:
  - app/csd/CARDDEMO.csd

✓ Scan completed successfully
```

### service

Identify service grouping candidates for microservices migration.

#### service identify

Identify potential service boundaries using various grouping strategies.

```bash
python -m legacy_analyzer service identify --db <database> [options]
```

**Required Options:**
- `--db`: Path to database file

**Optional Options:**
- `--format`: Output format (choices: json, markdown; default: markdown)
- `--output`: Output file path (if not specified, prints to stdout)
- `--min-confidence`: Minimum confidence level (choices: LOW, MEDIUM, HIGH; default: MEDIUM)
- `--strategies`: Comma-separated list of grouping strategies to use

**Breaking Changes (v3.0.0):**
- The `text` format option has been removed. Use `markdown` instead.

**Grouping Strategies:**

- **cics_group**: Group by CICS group name
- **shared_data**: Group by shared data access patterns
- **call_patterns**: Group by call relationship patterns
- **business_domain**: Group by inferred business domain

**Examples:**

```bash
# Identify service candidates (markdown format, default)
python -m legacy_analyzer service identify --db analysis.db

# Identify with specific strategies
python -m legacy_analyzer service identify \
  --db analysis.db \
  --strategies cics_group,shared_data

# Export to JSON
python -m legacy_analyzer service identify \
  --db analysis.db \
  --format json \
  --output service_candidates.json

# Filter by confidence level
python -m legacy_analyzer service identify \
  --db analysis.db \
  --min-confidence HIGH
```

**Output:**

```
================================================================================
SERVICE GROUPING CANDIDATES
================================================================================

CICS Group:
--------------------------------------------------------------------------------

Service: CARDDEMO_ACCOUNT_SERVICE
  Confidence: HIGH
  Recommendation: Strong candidate for microservice
  Consolidation Score: 85
  CICS Group: CARDDEMO
  Entry Points (3):
    - COACTUPC (Transaction: CAUP)
    - COACTUP (Transaction: CACT)
    - CBACT01C
  Shared Data (2):
    - ACCTDAT
    - CUSTDAT
  Shared Programs (2):
    - CBACT01C
    - CBACT02C

================================================================================
SUMMARY STATISTICS
================================================================================
Total Service Candidates: 5

By Grouping Strategy:
  CICS Group: 3
  Shared Data: 2

By Confidence Level:
  HIGH: 3
  MEDIUM: 2
================================================================================
```

## Common Workflows

### Complete Analysis Workflow

```bash
# 1. Analyze source code
python -m legacy_analyzer analyze \
  --source-dir /path/to/cobol \
  --db analyzer.db

# 2. Load CICS metadata (optional but recommended)
python -m legacy_analyzer metadata load-from-source \
  --source-dir /path/to/cobol \
  --db analyzer.db

# 3. Detect entry points
python -m legacy_analyzer flow entry-points \
  --db analyzer.db \
  --use-metadata \
  --output entry_points.json

# 4. Build migration flows
python -m legacy_analyzer migration build-flows \
  --db analyzer.db

# 5. Export flows for migration planning
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows.json \
  --extended-scope

# 6. Export job orchestration metadata
python -m legacy_analyzer migration export-jobs \
  --db analyzer.db \
  --output-dir results/jobs \
  --sort-by dependencies

# 7. Identify service candidates
python -m legacy_analyzer service identify \
  --db analyzer.db \
  --output service_candidates.json
```

### Quick Entry Point Analysis

```bash
# Analyze and detect entry points
python -m legacy_analyzer analyze \
  --source-dir ./src \
  --db analysis.db

python -m legacy_analyzer metadata load-from-source \
  --source-dir ./src \
  --db analysis.db

python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --format json \
  --output entry_points/entry_points.json
```

### CICS Metadata Workflow

```bash
# Option 1: Integrated workflow (recommended)
python -m legacy_analyzer metadata load-from-source \
  --source-dir ./app \
  --db analyzer.db

# Option 2: Manual workflow (more control)
# Step 1: Convert CSD to CSV
python -m legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv

# Step 2: Review/edit CSV (optional)
# ... manual review ...

# Step 3: Load CSV into database
python -m legacy_analyzer load \
  --type cics \
  --file exports/cics_inventory.csv \
  --db analyzer.db
```

## Exit Codes

- `0`: Success
- `1`: Error occurred

## See Also

- [User Guide](USER_GUIDE.md) - Complete user documentation
- [API Reference](API.md) - Python API documentation
- [Architecture](ARCHITECTURE.md) - System architecture
- [Migration Guide](MIGRATION_GUIDE.md) - Migration planning workflows
