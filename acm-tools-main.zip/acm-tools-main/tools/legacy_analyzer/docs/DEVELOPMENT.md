# Development Guide

## Table of Contents

- [Overview](#overview)
- [Getting Started](#getting-started)
- [Development Environment](#development-environment)
- [Project Structure](#project-structure)
- [Running Tests](#running-tests)
- [Code Style](#code-style)
- [Adding Features](#adding-features)
- [Debugging](#debugging)
- [Performance](#performance)
- [See Also](#see-also)

---

## Overview

This guide helps developers set up their environment, understand the codebase, and contribute to the Legacy Analyzer.

### Prerequisites

- Python 3.8 or higher
- Git
- SQLite (included with Python)
- Text editor or IDE (VS Code, PyCharm recommended)

### Quick Setup

```bash
# Clone repository
git clone <repository-url>
cd smf

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements-dev.txt

# Run tests
pytest tests/

# Install in development mode
pip install -e .
```

---

## Getting Started

### 1. Clone and Setup

```bash
# Clone repository
git clone <repository-url>
cd smf

# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install development dependencies
pip install -r requirements-dev.txt

# Install package in editable mode
pip install -e .
```

### 2. Verify Installation

```bash
# Run tests
pytest tests/ -v

# Check code style
black --check tools/legacy_analyzer/
flake8 tools/legacy_analyzer/

# Run type checking
mypy tools/legacy_analyzer/
```

### 3. Run Example Analysis

```bash
# Analyze example code
python -m tools.legacy_analyzer analyze \
    --source-dir examples/code/cobol/carddemoV2/app \
    --db test_analysis.db

# Check results
sqlite3 test_analysis.db "SELECT COUNT(*) FROM artifact_dependencies;"
```

---

## Development Environment

### Recommended Tools

**IDE/Editor**:
- VS Code with Python extension
- PyCharm Professional or Community
- Vim/Neovim with Python plugins

**Python Tools**:
- black (code formatting)
- flake8 (linting)
- mypy (type checking)
- pytest (testing)
- ipython (interactive shell)

### VS Code Setup

Create `.vscode/settings.json`:

```json
{
  "python.linting.enabled": true,
  "python.linting.flake8Enabled": true,
  "python.formatting.provider": "black",
  "python.formatting.blackArgs": ["--line-length", "100"],
  "editor.formatOnSave": true,
  "python.testing.pytestEnabled": true,
  "python.testing.unittestEnabled": false
}
```

### PyCharm Setup

1. Open project in PyCharm
2. Configure Python interpreter (File → Settings → Project → Python Interpreter)
3. Enable pytest (File → Settings → Tools → Python Integrated Tools)
4. Configure black formatter (File → Settings → Tools → Black)

### Environment Variables

Create `.env` file:

```bash
# Development settings
LEGACY_ANALYZER_DEBUG=1
LEGACY_ANALYZER_LOG_LEVEL=DEBUG

# Test database
TEST_DB_PATH=test_analysis.db

# Performance settings
LEGACY_ANALYZER_CACHE_ENABLED=1
LEGACY_ANALYZER_PARALLEL_WORKERS=4
```

---

## Project Structure

### Directory Layout

```
tools/legacy_analyzer/
├── __init__.py              # Package initialization
├── api.py                   # High-level API
├── cli.py                   # Command-line interface
├── static_analyzer.py       # Main analyzer
├── enhanced_static_analyzer.py  # Enhanced analyzer with error handling
│
├── parsers/                 # Language parsers
│   ├── __init__.py
│   ├── base_parser.py       # Base parser class
│   ├── cobol_parser.py      # COBOL parser
│   ├── pli_parser.py        # PL/I parser
│   ├── jcl_parser.py        # JCL parser
│   ├── rexx_parser.py       # REXX parser
│   ├── natural_parser.py    # Natural parser
│   ├── rpg_parser.py        # RPG parser
│   └── assembler_parser.py  # Assembler parser
│
├── analysis/                # Analysis modules
│   ├── __init__.py
│   ├── flow_analyzer.py     # Flow analysis
│   ├── complexity_analyzer.py  # Complexity metrics
│   ├── entry_point_detector.py  # Entry point detection
│   ├── service_grouping.py  # Service grouping
│   └── error_handling.py    # Error handling framework
│
├── inventory/               # Inventory management
│   ├── __init__.py
│   ├── inventory_loader.py  # Inventory loader
│   └── exporters/           # CICS/metadata exporters
│
├── migration/               # Migration planning
│   ├── __init__.py
│   ├── package_builder.py   # Migration packages
│   ├── interface_schema.py  # Interface schema
│   └── interface_loader.py  # Interface loader
│
├── models/                  # Data models
│   ├── __init__.py
│   ├── complexity.py        # Complexity metrics
│   └── flow.py              # Flow models
│
├── utils/                   # Utilities
│   ├── __init__.py
│   ├── cache_manager.py     # Caching
│   └── parallel_processor.py  # Parallel processing
│
└── docs/                    # Documentation
    ├── USER_GUIDE.md
    ├── API.md
    ├── ARCHITECTURE.md
    └── advanced/
```

### Key Modules

**Parsers** (`parsers/`):
- Language-specific dependency extraction
- Inherit from `BaseDependencyParser`
- Return standardized dependency format

**Analysis** (`analysis/`):
- Flow analysis and entry point detection
- Complexity calculation
- Service grouping for microservices

**Inventory** (`inventory/`):
- Load JCL, programs, datasets, copybooks
- CICS metadata management
- Inventory validation

**Migration** (`migration/`):
- Migration package creation
- Interface schema management
- Dependency resolution

---

## Running Tests

### Basic Test Execution

```bash
# Run all tests
pytest tests/

# Run with verbose output
pytest tests/ -v

# Run specific test file
pytest tests/test_cobol_parser.py -v

# Run specific test
pytest tests/test_cobol_parser.py::test_parse_call_statement -v
```

### Test Coverage

```bash
# Run with coverage
pytest --cov=tools.legacy_analyzer tests/

# Generate HTML coverage report
pytest --cov=tools.legacy_analyzer --cov-report=html tests/

# View coverage report
open htmlcov/index.html
```

### Test Categories

```bash
# Unit tests only
pytest tests/unit/

# Integration tests only
pytest tests/integration/

# Parser tests
pytest tests/test_*_parser.py

# Analysis tests
pytest tests/test_flow_analyzer.py tests/test_complexity_analyzer.py
```

### Running Specific Tests

```bash
# Run tests matching pattern
pytest tests/ -k "cobol"

# Run tests with marker
pytest tests/ -m "slow"

# Skip slow tests
pytest tests/ -m "not slow"
```

### Test Fixtures

Common fixtures in `tests/conftest.py`:

```python
@pytest.fixture
def temp_db():
    """Temporary test database"""
    db = SQLiteAdapter(':memory:')
    db.connect()
    yield db
    db.close()

@pytest.fixture
def sample_cobol_code():
    """Sample COBOL code for testing"""
    return """
           IDENTIFICATION DIVISION.
           PROGRAM-ID. TESTPROG.
           PROCEDURE DIVISION.
               CALL 'SUBPROG'.
               STOP RUN.
    """
```

---

## Code Style

### Python Style Guide

Follow PEP 8 with these modifications:

- Line length: 100 characters (not 79)
- Use double quotes for strings
- Use type hints for function signatures

### Formatting with Black

```bash
# Format all code
black tools/legacy_analyzer/

# Check formatting without changes
black --check tools/legacy_analyzer/

# Format specific file
black tools/legacy_analyzer/parsers/cobol_parser.py
```

### Linting with Flake8

```bash
# Lint all code
flake8 tools/legacy_analyzer/

# Lint specific file
flake8 tools/legacy_analyzer/parsers/cobol_parser.py

# Show statistics
flake8 --statistics tools/legacy_analyzer/
```

### Type Checking with Mypy

```bash
# Type check all code
mypy tools/legacy_analyzer/

# Type check specific file
mypy tools/legacy_analyzer/parsers/cobol_parser.py

# Strict mode
mypy --strict tools/legacy_analyzer/
```

### Code Style Examples

**Good**:
```python
from typing import List, Dict, Optional

def analyze_program(
    program_name: str,
    source_code: str,
    language: str = "COBOL"
) -> Dict[str, any]:
    """
    Analyze a program and extract dependencies.
    
    Args:
        program_name: Name of the program
        source_code: Source code content
        language: Programming language (default: COBOL)
    
    Returns:
        Dictionary containing analysis results
    """
    dependencies: List[Dict[str, str]] = []
    
    # Process source code
    for line in source_code.split("\n"):
        if "CALL" in line:
            dependencies.append({"type": "CALL", "target": extract_target(line)})
    
    return {"program": program_name, "dependencies": dependencies}
```

**Bad**:
```python
def analyze(p,s,l='COBOL'):  # No type hints, unclear names
    d=[]  # Unclear variable name
    for line in s.split('\n'):  # Single quotes
        if 'CALL' in line: d.append({'type':'CALL','target':extract_target(line)})  # Too long
    return {'program':p,'dependencies':d}
```


---

## Adding Features

### Adding a New Language Parser

**Step 1: Create Parser File**

Create `tools/legacy_analyzer/parsers/newlang_parser.py`:

```python
from typing import List, Dict, Set
from .base_parser import BaseDependencyParser

class NewLangDependencyParser(BaseDependencyParser):
    """Parser for NewLang source code."""
    
    def __init__(self):
        super().__init__()
        self.language = "NEWLANG"
    
    def parse(self, source_code: str, file_path: str) -> List[Dict[str, str]]:
        """
        Parse NewLang source code and extract dependencies.
        
        Args:
            source_code: Source code content
            file_path: Path to source file
        
        Returns:
            List of dependency dictionaries
        """
        dependencies = []
        
        for line_num, line in enumerate(source_code.split("\n"), 1):
            # Parse CALL statements
            if "CALL" in line.upper():
                target = self._extract_call_target(line)
                if target:
                    dependencies.append({
                        "source": file_path,
                        "target": target,
                        "type": "CALL",
                        "line_number": line_num
                    })
        
        return dependencies
    
    def _extract_call_target(self, line: str) -> str:
        """Extract target from CALL statement."""
        # Implementation specific to NewLang syntax
        pass
    
    def get_supported_patterns(self) -> Set[str]:
        """Return file patterns for NewLang files."""
        return {"*.nl", "*.newlang"}
```

**Step 2: Register Parser**

Add to `tools/legacy_analyzer/parsers/__init__.py`:

```python
from .newlang_parser import NewLangDependencyParser

PARSER_REGISTRY = {
    "COBOL": COBOLDependencyParser,
    "PLI": PLIDependencyParser,
    "JCL": JCLDependencyParser,
    "NEWLANG": NewLangDependencyParser,  # Add here
}
```

**Step 3: Add Tests**

Create `tests/test_newlang_parser.py`:

```python
import pytest
from tools.legacy_analyzer.parsers.newlang_parser import NewLangDependencyParser

def test_parse_call_statement():
    parser = NewLangDependencyParser()
    source_code = "CALL SUBPROG"
    
    dependencies = parser.parse(source_code, "test.nl")
    
    assert len(dependencies) == 1
    assert dependencies[0]["target"] == "SUBPROG"
    assert dependencies[0]["type"] == "CALL"

def test_supported_patterns():
    parser = NewLangDependencyParser()
    patterns = parser.get_supported_patterns()
    
    assert "*.nl" in patterns
    assert "*.newlang" in patterns
```

**Step 4: Update Documentation**

Add to `docs/PARSERS.md`:

```markdown
### NewLang Parser

Parses NewLang source code and extracts dependencies.

**Supported Patterns**: `*.nl`, `*.newlang`

**Dependency Types**:
- CALL: Program calls
- INCLUDE: File includes

**Example**:
\`\`\`newlang
CALL SUBPROG
INCLUDE COPYBOOK
\`\`\`
```

### Adding a New Analysis Feature

**Step 1: Create Analysis Module**

Create `tools/legacy_analyzer/analysis/new_analyzer.py`:

```python
from typing import List, Dict
from smf_loader.databases.base_database import BaseDatabase

class NewAnalyzer:
    """New analysis feature."""
    
    def __init__(self, database: BaseDatabase):
        self.database = database
    
    def analyze(self, program_name: str) -> Dict[str, any]:
        """
        Perform new analysis on a program.
        
        Args:
            program_name: Name of program to analyze
        
        Returns:
            Analysis results
        """
        # Query database
        query = """
            SELECT * FROM artifact_dependencies
            WHERE source_artifact_name = ?
        """
        results = self.database.execute(query, (program_name,))
        
        # Perform analysis
        analysis_result = self._process_results(results)
        
        return analysis_result
    
    def _process_results(self, results: List[tuple]) -> Dict[str, any]:
        """Process query results."""
        # Implementation
        pass
```

**Step 2: Add CLI Command**

Add to `tools/legacy_analyzer/cli.py`:

```python
@cli.command()
@click.option('--program', required=True, help='Program name')
@click.option('--db', required=True, help='Database path')
def new_analysis(program: str, db: str):
    """Run new analysis on a program."""
    from .analysis.new_analyzer import NewAnalyzer
    from smf_loader.databases import SQLiteAdapter
    
    database = SQLiteAdapter(db)
    database.connect()
    
    analyzer = NewAnalyzer(database)
    result = analyzer.analyze(program)
    
    print(json.dumps(result, indent=2))
    
    database.close()
```

**Step 3: Add Tests**

Create `tests/test_new_analyzer.py`:

```python
import pytest
from tools.legacy_analyzer.analysis.new_analyzer import NewAnalyzer

@pytest.fixture
def analyzer(temp_db):
    return NewAnalyzer(temp_db)

def test_analyze(analyzer, temp_db):
    # Setup test data
    temp_db.execute("""
        INSERT INTO artifact_dependencies (source_artifact_name, target_artifact_name)
        VALUES ('PROG1', 'PROG2')
    """)
    
    # Run analysis
    result = analyzer.analyze('PROG1')
    
    # Verify results
    assert result is not None
    assert 'program' in result
```

**Step 4: Update Documentation**

Add to `docs/API.md` and `docs/CLI_REFERENCE.md`.

### Adding a New Database Adapter

**Step 1: Create Adapter**

Create `smf_loader/databases/newdb_adapter.py`:

```python
from .base_database import BaseDatabase
from typing import List, Dict, Any

class NewDBAdapter(BaseDatabase):
    """Adapter for NewDB database."""
    
    def connect(self):
        """Connect to database."""
        # Implementation
        pass
    
    def close(self):
        """Close database connection."""
        # Implementation
        pass
    
    def execute(self, query: str, params: tuple = None) -> List[tuple]:
        """Execute query."""
        # Implementation
        pass
    
    def insert_rows(self, table: str, rows: List[Dict[str, Any]]):
        """Insert rows into table."""
        # Implementation
        pass
```

**Step 2: Register Adapter**

Add to `smf_loader/databases/__init__.py`:

```python
from .newdb_adapter import NewDBAdapter

DATABASE_ADAPTERS = {
    "sqlite": SQLiteAdapter,
    "newdb": NewDBAdapter,
}
```

---

## Debugging

### Using Python Debugger

**Set Breakpoint**:

```python
import pdb

def analyze_program(program_name: str):
    # Set breakpoint
    pdb.set_trace()
    
    # Code execution pauses here
    result = perform_analysis(program_name)
    return result
```

**Debugger Commands**:
- `n` (next): Execute next line
- `s` (step): Step into function
- `c` (continue): Continue execution
- `p variable`: Print variable value
- `l`: List source code
- `q`: Quit debugger

### VS Code Debugging

Create `.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Python: Current File",
      "type": "python",
      "request": "launch",
      "program": "${file}",
      "console": "integratedTerminal"
    },
    {
      "name": "Python: Analyze",
      "type": "python",
      "request": "launch",
      "module": "tools.legacy_analyzer",
      "args": [
        "analyze",
        "--source-dir", "examples/code/cobol/carddemoV2/app",
        "--db", "test.db"
      ],
      "console": "integratedTerminal"
    }
  ]
}
```

### Logging for Debugging

```python
import logging

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='debug.log'
)

logger = logging.getLogger(__name__)

def analyze_program(program_name: str):
    logger.debug(f"Starting analysis for {program_name}")
    
    try:
        result = perform_analysis(program_name)
        logger.debug(f"Analysis completed: {result}")
        return result
    except Exception as e:
        logger.error(f"Analysis failed: {e}", exc_info=True)
        raise
```

### Database Debugging

```python
# Enable SQL logging
import sqlite3

sqlite3.enable_callback_tracebacks(True)

# Log all SQL queries
def trace_callback(statement):
    print(f"SQL: {statement}")

connection.set_trace_callback(trace_callback)
```

### Common Debugging Scenarios

**1. Parser Not Finding Dependencies**:

```python
# Add debug logging to parser
def parse(self, source_code: str, file_path: str):
    logger.debug(f"Parsing {file_path}")
    logger.debug(f"Source code length: {len(source_code)}")
    
    dependencies = []
    for line_num, line in enumerate(source_code.split("\n"), 1):
        logger.debug(f"Line {line_num}: {line}")
        # ... parsing logic ...
    
    logger.debug(f"Found {len(dependencies)} dependencies")
    return dependencies
```

**2. Database Query Issues**:

```python
# Log query and results
query = "SELECT * FROM dependencies WHERE source = ?"
logger.debug(f"Query: {query}")
logger.debug(f"Params: {params}")

results = database.execute(query, params)
logger.debug(f"Results: {len(results)} rows")
```

**3. Performance Issues**:

```python
import time

def analyze_program(program_name: str):
    start_time = time.time()
    
    result = perform_analysis(program_name)
    
    elapsed = time.time() - start_time
    logger.debug(f"Analysis took {elapsed:.2f} seconds")
    
    return result
```

---

## Performance

### Profiling

**Using cProfile**:

```bash
# Profile script
python -m cProfile -o profile.stats analyze_script.py

# View results
python -m pstats profile.stats
>>> sort cumulative
>>> stats 20
```

**Using line_profiler**:

```python
# Install
pip install line_profiler

# Add decorator
@profile
def analyze_program(program_name: str):
    # Function code
    pass

# Run profiler
kernprof -l -v analyze_script.py
```

### Optimization Tips

**1. Use Batch Operations**:

```python
# Good: Batch insert
dependencies = []
for file in files:
    deps = parse_file(file)
    dependencies.extend(deps)

database.insert_rows('dependencies', dependencies)

# Bad: Individual inserts
for file in files:
    deps = parse_file(file)
    for dep in deps:
        database.insert_rows('dependencies', [dep])
```

**2. Cache Expensive Operations**:

```python
from functools import lru_cache

@lru_cache(maxsize=1000)
def get_program_complexity(program_name: str) -> float:
    # Expensive calculation
    return calculate_complexity(program_name)
```

**3. Use Parallel Processing**:

```python
from concurrent.futures import ThreadPoolExecutor

def analyze_files(file_paths: List[str]):
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(analyze_file, file_paths))
    return results
```

**4. Optimize Database Queries**:

```python
# Good: Single query with JOIN
query = """
    SELECT d.*, p.complexity
    FROM dependencies d
    JOIN programs p ON d.target = p.name
    WHERE d.source = ?
"""

# Bad: Multiple queries
dependencies = db.execute("SELECT * FROM dependencies WHERE source = ?", (prog,))
for dep in dependencies:
    complexity = db.execute("SELECT complexity FROM programs WHERE name = ?", (dep['target'],))
```

### Memory Management

**1. Process Large Files in Chunks**:

```python
def process_large_file(file_path: str):
    with open(file_path, 'r') as f:
        while True:
            chunk = f.read(1024 * 1024)  # 1MB chunks
            if not chunk:
                break
            process_chunk(chunk)
```

**2. Use Generators**:

```python
# Good: Generator (memory efficient)
def get_dependencies(file_paths: List[str]):
    for file_path in file_paths:
        yield parse_file(file_path)

# Bad: List (loads all into memory)
def get_dependencies(file_paths: List[str]):
    return [parse_file(fp) for fp in file_paths]
```

**3. Clean Up Resources**:

```python
# Use context managers
with database.connect() as conn:
    # Operations
    pass
# Connection automatically closed

# Or explicit cleanup
try:
    database.connect()
    # Operations
finally:
    database.close()
```

---

## See Also

### Related Documentation

- **[Contributing Guide](CONTRIBUTING.md)** - Contribution guidelines
- **[Architecture](ARCHITECTURE.md)** - System architecture
- **[API Reference](API.md)** - Python API documentation
- **[User Guide](USER_GUIDE.md)** - User documentation

### External Resources

- **Python Style Guide**: https://pep8.org/
- **pytest Documentation**: https://docs.pytest.org/
- **Black Formatter**: https://black.readthedocs.io/
- **Type Hints**: https://docs.python.org/3/library/typing.html

---

**Document Version**: 1.0  
**Last Updated**: February 2026  
**Part of**: Legacy Analyzer Documentation Suite
