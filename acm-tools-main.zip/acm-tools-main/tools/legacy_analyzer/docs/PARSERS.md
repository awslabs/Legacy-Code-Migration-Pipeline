# Parser Reference

Complete reference for language parsers in the Legacy Analyzer, including architecture, supported languages, capabilities, and development guidelines.

## Table of Contents

- [Overview](#overview)
- [Supported Languages](#supported-languages)
- [Parser Architecture](#parser-architecture)
- [Language Detection](#language-detection)
- [Using Parsers](#using-parsers)
- [Parser Capabilities](#parser-capabilities)
- [Adding New Parsers](#adding-new-parsers)
- [Testing](#testing)
- [Performance](#performance)
- [Troubleshooting](#troubleshooting)

## Overview

The Legacy Analyzer includes a comprehensive parser framework for analyzing mainframe programming languages. The parsers extract dependencies, detect program boundaries, analyze complexity, and support multi-language codebases.

### Key Features

- **7 Mainframe Languages**: COBOL, PL/I, JCL, REXX, Natural, RPG, Assembler
- **Program-Level Analysis**: Detect individual programs within multi-program files
- **Automatic Language Detection**: Content-based detection for ambiguous file extensions
- **Dependency Extraction**: Calls, copybooks/includes, datasets, external references
- **Complexity Metrics**: Language-specific complexity calculations
- **Multi-Language Support**: Analyze mixed-language codebases in a single pass

## Supported Languages

| Language | Parser | Multi-Program | Complexity | Status |
|----------|--------|---------------|------------|--------|
| **COBOL** | `COBOLDependencyParser` | ✅ Yes | ✅ Yes | Production |
| **PL/I** | `PLIDependencyParser` | ✅ Yes | ✅ Yes | Production |
| **JCL** | `JCLDependencyParser` | ➖ N/A | ✅ Yes | Production |
| **REXX** | `REXXDependencyParser` | ✅ Yes | ✅ Yes | Production |
| **Natural** | `NaturalDependencyParser` | ✅ Yes | ✅ Yes | Production |
| **RPG** | `RPGDependencyParser` | ✅ Yes | ✅ Yes | Production |
| **Assembler** | `ASMDependencyParser` | ✅ Yes | ✅ Yes | Production |

### File Extensions

| Language | Extensions |
|----------|-----------|
| COBOL | `.cbl`, `.cob`, `.cobol`, `.cpy` |
| PL/I | `.pli`, `.pl1`, `.inc` |
| JCL | `.jcl` |
| REXX | `.rexx`, `.rex` |
| Natural | `.NSP`, `.NSN`, `.NSC`, `.NSL`, `.NSG`, `.NSD`, `.NSA`, `.NS8` |
| RPG | `.rpg`, `.rpgle`, `.sqlrpgle`, `.rpg38`, `.mbr` |
| Assembler | `.asm`, `.s`, `.mac` |

## Parser Architecture

### Base Classes

All parsers inherit from `BaseDependencyParser`:

```python
from abc import ABC, abstractmethod

class BaseDependencyParser(ABC):
    @abstractmethod
    def parse(self, source_code: str) -> ParseResult:
        """Parse source code and extract dependencies."""
        pass
    
    @abstractmethod
    def get_supported_patterns(self) -> List[str]:
        """Get list of supported dependency patterns."""
        pass
    
    @abstractmethod
    def get_supported_extensions(self) -> List[str]:
        """Get list of supported file extensions."""
        pass
```

### Parse Results

Enhanced parsers return `EnhancedParseResult`:

```python
@dataclass
class EnhancedParseResult:
    # Program boundaries (for multi-program files)
    programs: List[ProgramBoundary]
    
    # Dependencies per program
    program_dependencies: Dict[str, Dict[str, List[str]]]
    
    # File-level dependencies (legacy compatibility)
    dependencies: Dict[str, List[str]]
    
    # Copybook/include analysis
    copybook_analysis: List[CopybookAnalysisResult]
    
    # Complexity metrics
    complexity: Optional[ComplexityMetrics]
```

### Program Boundary Model

```python
@dataclass
class ProgramBoundary:
    program_name: str           # Name of the program
    start_line: int            # Starting line number
    end_line: int              # Ending line number
    program_type: ProgramType  # MAIN, PROCEDURE, CSECT, SUBPROGRAM
    language: str              # Programming language
    entry_points: List[str]    # Entry point names
    file_path: str             # Source file path
    confidence_level: float    # Detection confidence (0.0-1.0)
    metadata: Optional[Dict]   # Additional metadata
```

## Language Detection

The Legacy Analyzer includes intelligent language detection that combines extension-based guessing with content analysis.

### Detection Algorithm

1. **Extension-Based Detection** (Primary)
   - Checks file extension against known mappings
   - Returns immediately if extension is definitive
   - Skips content analysis for known extensions

2. **Content-Based Detection** (Fallback)
   - Used when extension is unknown or ambiguous
   - Analyzes file content for language-specific patterns
   - Returns language with highest confidence score

3. **Pattern Matching**
   - Each language has unique syntax patterns with confidence weights
   - High confidence (10 points): Definitive patterns
   - Medium confidence (5 points): Common patterns
   - Low confidence (2 points): Keywords

### Using Language Detection

```python
from legacy_analyzer.language_detector import LanguageDetector

detector = LanguageDetector()

# Simple detection
language = detector.detect_language('path/to/file.txt')
print(f"Detected language: {language}")

# Detection with confidence information
language, confidence, details = detector.detect_with_confidence('path/to/file.txt')
print(f"Language: {language}")
print(f"Confidence: {confidence}")  # 'high', 'medium', 'low', or 'none'
print(f"Method: {details['method']}")  # 'extension' or 'content'
```

### Detection Patterns

#### COBOL
- **High confidence**: `IDENTIFICATION DIVISION`, `PROCEDURE DIVISION`, `PROGRAM-ID`
- **Medium confidence**: `DATA DIVISION`, `WORKING-STORAGE SECTION`
- **Low confidence**: Level numbers (01-49), COBOL keywords

#### PL/I
- **High confidence**: `NAME: PROCEDURE`, `PUT/GET` statements
- **Medium confidence**: `DCL` (DECLARE), `EXEC CICS`
- **Low confidence**: PL/I data types (FIXED, FLOAT, BIT, CHAR)

#### JCL
- **High confidence**: `//NAME JOB`, `//NAME EXEC`, `//NAME DD`
- **Medium confidence**: `//*` comments, `PROC` statements

#### REXX
- **High confidence**: `ARG` statement, `PARSE` statement, `INTERPRET`
- **Medium confidence**: `SAY` statement, `SIGNAL ON/OFF`
- **Low confidence**: REXX keywords (RETURN, EXIT, CALL)

#### Natural
- **High confidence**: `DEFINE DATA`, `END-DEFINE`, `CALLNAT`
- **Medium confidence**: `FETCH`, `END-FOR`, `END-IF`
- **Low confidence**: Natural-specific keywords

#### RPG
- **High confidence**: RPG spec types (H, F, D, I, C, O, P), `DCL-` statements
- **Medium confidence**: RPG operations (CHAIN, SETLL, READE)

#### Assembler
- **High confidence**: `CSECT`, `ENTRY` statements
- **Medium confidence**: Common opcodes (BALR, LA, MVC), `DC`/`DS` statements

## Using Parsers

### Parser Factory

The `ParserFactory` provides centralized parser creation:

```python
from legacy_analyzer.parsers.parser_factory import ParserFactory

# Create parser by language name
cobol_parser = ParserFactory.create_parser('COBOL')

# Auto-detect parser from file extension
parser = ParserFactory.get_parser_for_file('PAYROLL.cbl')

# Get supported languages
languages = ParserFactory.get_supported_languages()
print(f"Supported: {', '.join(languages)}")
```

### Basic Parsing

```python
from legacy_analyzer.parsers.parser_factory import ParserFactory

# Get appropriate parser
parser = ParserFactory.get_parser_for_file("PAYROLL.rpgle")

# Parse file
result = parser.parse_file("PAYROLL.rpgle")

# Access file-level dependencies
calls = result.dependencies.get('calls', [])
copybooks = result.dependencies.get('copybooks', [])

# Access program-level data
for program in result.programs:
    print(f"Program: {program.program_name}")
    prog_deps = result.program_dependencies.get(program.program_name, {})
    print(f"  Calls: {prog_deps.get('calls', [])}")
```

### Multi-Language Analysis

```python
from legacy_analyzer.static_analyzer import StaticCodeAnalyzer
from smf_loader.databases import SQLiteAdapter

# Initialize
db = SQLiteAdapter('analyzer.db')
db.connect()
analyzer = StaticCodeAnalyzer(db)

# Analyze entire directory - auto-detects all languages
result = analyzer.analyze_directory_multi_language('src/')

# View results by language
for language, stats in result['by_language'].items():
    print(f"{language}: {stats['files']} files, {stats['dependencies']} dependencies")
```

### With Complexity Analysis

```python
# Analyze with complexity metrics
result = analyzer.analyze_directory_multi_language(
    'src/',
    calculate_complexity=True
)

print(f"Calculated complexity for {len(result['complexity_metrics'])} programs")
```

## Parser Capabilities

### COBOL Parser

**Features:**
- Program boundary detection (`PROGRAM-ID` sections)
- CALL statement extraction
- COPY statement analysis (with executable code detection)
- File operations (READ, WRITE, REWRITE, DELETE)
- Dataset access patterns
- Copybook analysis for executable content

**Program Boundaries:**
- Markers: `IDENTIFICATION DIVISION` / `END PROGRAM`
- Nested programs supported
- Confidence scoring for detection

**Example:**
```python
from legacy_analyzer.parsers.cobol_parser import COBOLDependencyParser

parser = COBOLDependencyParser()
result = parser.parse_file("MAINPROG.cbl")

# Check copybook analysis
for copybook_result in result.copybook_analysis:
    if copybook_result.has_executable_code:
        print(f"Executable copybook: {copybook_result.copybook_name}")
```

### PL/I Parser

**Features:**
- Procedure detection (with OPTIONS(MAIN))
- CALL statement extraction
- %INCLUDE statement analysis (with executable code detection)
- File operations
- EXEC CICS statement detection

**Program Boundaries:**
- Markers: `PROCEDURE` / `END`
- Main program detection via OPTIONS(MAIN)
- Nested procedures supported

### JCL Parser

**Features:**
- Job step extraction
- Program execution detection (EXEC PGM=)
- Dataset references (DD statements)
- Procedure calls (EXEC PROC=)
- Job dependencies

**Note:** JCL is job-level, not program-level

### REXX Parser

**Features:**
- Procedure/function detection
- CALL statement extraction
- External command detection
- Function calls
- Label references

**Program Boundaries:**
- Markers: Function/procedure definitions
- Main script vs. functions
- Label-based procedures

### Natural Parser

**Features:**
- Program/subprogram detection
- CALLNAT statement extraction
- FETCH statement detection
- Database operations (FIND, READ, UPDATE)
- Data area references

**Program Boundaries:**
- Markers: `DEFINE DATA PROGRAM/SUBPROGRAM` / `END`
- Clear program type identification
- Entry point detection

### RPG Parser

**Features:**
- Procedure detection (H-spec, F-spec, P-spec)
- CALLP/CALL statement extraction
- /COPY statement detection
- File operations (CHAIN, SETLL, READE)
- SQL table references (limited)

**Program Boundaries:**
- Markers: `P ProcName B` (Begin) / `P ProcName E` (End)
- Main program vs. procedures
- Entry point identification

**Known Limitations:**
- Embedded SQL with C-spec continuation lines not fully supported

### Assembler Parser

**Features:**
- CSECT (Control Section) detection
- ENTRY point identification
- CALL/LINK statement extraction
- External reference detection
- Macro expansion tracking

**Program Boundaries:**
- Markers: `CSECT`, `ENTRY`, `END`
- Multiple CSECTs per file
- Entry point detection

## Adding New Parsers

### Step 1: Create Parser Class

Create a new parser in `tools/legacy_analyzer/parsers/{language}_parser.py`:

```python
from .base_parser import BaseDependencyParser
from ..models.dependency import ParseResult

class FortranDependencyParser(BaseDependencyParser):
    def parse(self, source_code: str) -> ParseResult:
        """Parse Fortran source code."""
        dependencies = {
            'includes': [],
            'calls': [],
            'modules': []
        }
        
        # Parse source code
        for line in source_code.split('\n'):
            # Extract INCLUDE statements
            if 'INCLUDE' in line.upper():
                # Extract include file
                pass
            
            # Extract CALL statements
            if 'CALL' in line.upper():
                # Extract called subroutine
                pass
        
        return ParseResult(dependencies=dependencies)
    
    def get_supported_patterns(self) -> List[str]:
        """Return supported dependency patterns."""
        return ['INCLUDE', 'CALL', 'USE']
    
    def get_supported_extensions(self) -> List[str]:
        """Return supported file extensions."""
        return ['.f', '.f90', '.for']
```

### Step 2: Create Complexity Calculator

Create `{language}_complexity_calculator.py`:

```python
from .base_complexity_calculator import BaseComplexityCalculator

class FortranComplexityCalculator(BaseComplexityCalculator):
    def calculate_complexity(self, source_code: str) -> ComplexityMetrics:
        """Calculate Fortran-specific complexity."""
        # Implement complexity calculation
        pass
```

### Step 3: Register Parser

Register in `parser_factory.py`:

```python
from .fortran_parser import FortranDependencyParser

ParserFactory.register_parser(
    'FORTRAN',
    FortranDependencyParser,
    extensions=['.f', '.f90', '.for']
)
```

### Step 4: Add Language Detection Patterns

Update `language_detector.py`:

```python
'FORTRAN': {
    'PROGRAM': 10,
    'SUBROUTINE': 10,
    'FUNCTION': 10,
    'IMPLICIT': 5,
    'DIMENSION': 5,
    'REAL': 2,
    'INTEGER': 2
}
```

### Step 5: Write Tests

Create `tests/test_fortran_parser.py`:

```python
import pytest
from legacy_analyzer.parsers.fortran_parser import FortranDependencyParser

def test_fortran_include_detection():
    source = """
    PROGRAM MAIN
        INCLUDE 'common.inc'
        CALL SUBROUTINE1
    END PROGRAM
    """
    
    parser = FortranDependencyParser()
    result = parser.parse(source)
    
    assert 'common.inc' in result.dependencies['includes']
    assert 'SUBROUTINE1' in result.dependencies['calls']
```

## Testing

### Unit Tests

Each parser has comprehensive unit tests:

```bash
# Test specific parser
pytest tests/test_cobol_parser.py -v

# Test all parsers
pytest tests/test_*_parser.py -v

# Test parser factory
pytest tests/test_parser_factory.py -v

# Test language detection
pytest tests/test_language_detector.py -v
```

### Property-Based Tests

Property-based tests validate parser behavior:

```bash
# Test multi-program detection
pytest tests/test_rpg_multi_program_properties.py -v
pytest tests/test_asm_multi_program_properties.py -v
```

### Integration Tests

```bash
# Test program-level integration
pytest tests/test_program_level_integration_simple.py -v

# Test multi-language integration
pytest tests/test_multi_language_integration.py -v
```

## Performance

### Optimization Strategies

1. **Lazy Loading**: Parse program boundaries first, detailed analysis on demand
2. **Caching**: Cache parse results for frequently accessed files
3. **Parallel Processing**: Process multiple files concurrently
4. **Incremental Analysis**: Only re-parse changed sections

### Performance Metrics

- **Language Detection**: ~10-50ms per file
- **Parsing**: ~100-500ms per file (depends on size and complexity)
- **Multi-Language Analysis**: ~100-200 files/second for small files

### Configuration

Adjust scan depth for language detection:

```python
# Scan only first 100 lines (faster)
detector = LanguageDetector(max_lines_to_scan=100)

# Scan more lines for better accuracy
detector = LanguageDetector(max_lines_to_scan=500)
```

## Troubleshooting

### Issue: File Detected as Wrong Language

**Solution**: Check content scores:

```python
language, confidence, details = detector.detect_with_confidence('file.txt')
print(f"Content scores: {details['content_scores']}")
```

If wrong language has higher score, file may contain ambiguous patterns.

### Issue: File Not Detected (Returns None)

**Possible Causes:**
- Documentation file (no code patterns)
- Data file
- Minimal code
- Unsupported language

**Solution**: Check if file contains recognizable code patterns.

### Issue: Low Confidence Detection

**Solutions:**
- Increase `max_lines_to_scan` to scan more of file
- Verify file contains typical language patterns
- Check if file uses non-standard syntax

### Issue: Parse Errors

**Solutions:**
- Check file encoding (should be ASCII or UTF-8)
- Verify file is valid source code
- Check parser logs for specific errors
- Enable debug logging for detailed information

### Issue: Missing Dependencies

**Solutions:**
- Check parser configuration
- Verify source code encoding
- Review parser logs for errors
- Add custom parsing rules if needed

### Issue: Performance Problems

**Solutions:**
- Use pattern to limit files: `pattern='*.cbl'`
- Disable complexity: `calculate_complexity=False`
- Use single-language method for known directories
- Enable caching
- Increase `max_workers` for parallel processing

## Best Practices

### For Users

1. **Use Multi-Language Analysis**: Single call for mixed-language codebases
2. **Enable Caching**: Improves performance for repeated analysis
3. **Validate Results**: Check completeness and accuracy
4. **Handle Errors Gracefully**: Files may fail to parse
5. **Use Appropriate Scan Depth**: Balance accuracy vs. performance

### For Developers

1. **Inherit from Base Classes**: Use `BaseDependencyParser` and `BaseComplexityCalculator`
2. **Implement All Methods**: Complete the abstract interface
3. **Add Comprehensive Tests**: Unit, integration, and property-based tests
4. **Document Limitations**: Clearly document known limitations
5. **Handle Edge Cases**: Graceful degradation for malformed code
6. **Use Confidence Scoring**: Indicate detection confidence
7. **Optimize Performance**: Minimize file I/O and regex operations

## Migration from File-Level Analysis

### Backward Compatibility

Enhanced parsers maintain backward compatibility:

```python
# Legacy file-level access still works
result = parser.parse_file("PROG.cbl")
file_level_deps = result.dependencies  # Still available

# New program-level access
program_level_deps = result.program_dependencies  # Enhanced
```

### Migration Strategy

1. **Phase 1**: Deploy enhanced parsers with dual output
2. **Phase 2**: Update analysis components to use program-level data
3. **Phase 3**: Migrate existing data from file-level to program-level
4. **Phase 4**: Deprecate file-level interfaces (optional)

## Additional Resources

### Documentation
- [User Guide](USER_GUIDE.md) - Complete user documentation
- [CLI Reference](CLI_REFERENCE.md) - Command-line interface
- [API Reference](API.md) - Python API
- [Architecture](ARCHITECTURE.md) - System architecture

### Examples
- `examples/parser_factory_demo.py` - Parser factory usage
- `examples/multi_language_analysis.py` - Multi-language analysis

### Source Code
- `tools/legacy_analyzer/parsers/` - Parser implementations
- `tools/legacy_analyzer/language_detector.py` - Language detection
- `tools/legacy_analyzer/parsers/parser_factory.py` - Parser factory

## Summary

The Legacy Analyzer parser framework provides:

✅ **Comprehensive**: 7 mainframe languages supported  
✅ **Intelligent**: Automatic language detection  
✅ **Accurate**: Program-level dependency tracking  
✅ **Flexible**: Multi-language analysis in single pass  
✅ **Extensible**: Easy to add new parsers  
✅ **Tested**: Comprehensive test coverage  
✅ **Documented**: Complete reference documentation  
✅ **Production-Ready**: Used in real-world migrations  

The parser framework is a core component of the Legacy Analyzer, enabling accurate dependency extraction, complexity analysis, and migration planning for mainframe applications.
