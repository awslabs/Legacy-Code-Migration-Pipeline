# Legacy Analyzer User Guide

## Introduction

Welcome to the Legacy Analyzer! This comprehensive tool helps you analyze mainframe applications, perform static code analysis, track dependencies, and plan migrations. Whether you're assessing a legacy system for modernization or planning a complete migration to the cloud, this guide will help you get the most out of the Legacy Analyzer.

## Table of Contents

- [Getting Started](#getting-started)
- [Core Workflows](#core-workflows)
- [Feature Guide](#feature-guide)
- [Common Use Cases](#common-use-cases)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [FAQ](#faq)

## Getting Started

### What You'll Need

1. **SMF Data** (optional): SMF records (Types 14, 15, 17, 30, 62, 64, 110) for usage analysis
2. **Inventory Data**: CSV exports of your mainframe artifacts (JCL, programs, datasets, etc.)
3. **Source Code**: COBOL, PL/I, JCL, copybooks, and other mainframe source files
4. **Python 3.8+**: With the SMF Toolkit installed
5. **SQLite**: For the analysis database (included with Python)

### Quick Start (5 Minutes)

Get up and running with a complete analysis in just a few commands:

```bash
# 1. Create output directories
mkdir -p ./results/analysis

# 2. Analyze source code with CICS metadata
python -m tools.legacy_analyzer analyze \
  --source-dir ./mainframe-code \
  --db ./results/analysis.db

# 3. Check what was discovered
python -m tools.legacy_analyzer status --db ./results/analysis.db

# 4. Build migration flows
python -m tools.legacy_analyzer.api build-flows --db ./results/analysis.db

# 5. Export flows for migration planning
python -m tools.legacy_analyzer.api export-flows \
  --db ./results/analysis.db \
  --output flows.json
```

### Installation

```bash
# Install from project root
pip install -e .

# Or install with development dependencies
pip install -e ".[dev]"
```

### Verify Installation

```bash
# Check that the tool is installed
python -m tools.legacy_analyzer --version

# View available commands
python -m tools.legacy_analyzer --help
```

### Output Structure

After running a complete analysis, the Legacy Analyzer creates the following output structure:

```
results/{project}_analysis/
├── {project}.db              # SQLite database with all analysis data
├── entry_points/             # Entry point artifacts
│   ├── entry_points.json     # Entry points in JSON format
│   └── entry_points.md       # Entry points in Markdown format
├── flows/                    # Program flow analysis
│   └── *.json                # Individual flow files
├── jobs/                     # JCL job exports
│   └── *.json                # Individual job files
└── reports/                  # Analysis reports
    └── analysis_summary.md   # Comprehensive analysis summary
```

**Key Points**:
- The `entry_points/` folder contains all entry point artifacts (JSON and Markdown formats)
- The `reports/` folder contains analysis summaries in Markdown format
- All report files use `.md` extension (not `.txt`)
- The `temp/` folder (if created during analysis) is automatically cleaned up
- The `exports/` folder is no longer used

**Supported Output Formats**:
- **JSON**: Structured data for programmatic use
- **Markdown**: Human-readable documentation format
- **CSV**: Spreadsheet-compatible format (for some reports)

**Note**: The default format for entry points is now Markdown. Use `--format json` to generate JSON output instead.

## Core Workflows

### Workflow 1: Initial Assessment

**Objective**: Understand the scope and complexity of your legacy system.

**Steps**:

1. **Gather High-Level Information**
   - Document number of programs, JCL jobs, copybooks
   - Identify programming languages used
   - List business domains/subsystems
   - Note known dependencies and integrations

2. **Load Inventory Data**
   ```bash
   # Load JCL inventory
   python -m tools.legacy_analyzer load --type jcl \
       --file inventory/jcl_inventory.csv \
       --db analysis.db

   # Load program inventory
   python -m tools.legacy_analyzer load --type programs \
       --file inventory/program_inventory.csv \
       --db analysis.db

   # Load dataset inventory
   python -m tools.legacy_analyzer load --type datasets \
       --file inventory/dataset_inventory.csv \
       --db analysis.db
   ```

3. **Verify Inventory**
   ```bash
   python -m tools.legacy_analyzer status --db analysis.db
   ```

   Expected output:
   ```
   JCL Members: 1,234
   Programs: 5,678
   Datasets: 2,345
   Copybooks: 890
   CICS Resources: 456
   ```

### Workflow 2: Dependency Analysis

**Objective**: Extract and analyze dependencies between artifacts.

**Steps**:

1. **Analyze Source Code**
   ```bash
   # Analyze COBOL source
   python -m tools.legacy_analyzer analyze \
       --source-dir ./cobol \
       --language COBOL \
       --db analysis.db

   # Analyze PL/I source
   python -m tools.legacy_analyzer analyze \
       --source-dir ./pli \
       --language PLI \
       --db analysis.db

   # Analyze JCL
   python -m tools.legacy_analyzer analyze \
       --source-dir ./jcl \
       --language JCL \
       --db analysis.db
   ```

2. **Analyze Program Flows**
   ```bash
   # Analyze flows for all entry points
   python -m tools.legacy_analyzer flow analyze-all \
       --db analysis.db \
       --output reports/flows
   ```

3. **Detect Circular Dependencies**
   ```bash
   python -m tools.legacy_analyzer flow detect-circular \
       --db analysis.db \
       --output reports/circular_dependencies.csv
   ```

4. **Identify Missing Artifacts**
   ```bash
   # Find missing programs
   python -m smf_queries run \
       --db analysis.db \
       --query missing_programs \
       --format csv \
       --output reports/missing_programs.csv
   ```

### Workflow 3: Complexity Assessment

**Objective**: Assess the complexity of each artifact to estimate migration effort.

**Steps**:

1. **Calculate Complexity Metrics**
   ```bash
   python -m tools.legacy_analyzer complexity analyze \
       --db analysis.db \
       --output reports/complexity_metrics.csv
   ```

2. **Review Complexity Distribution**
   ```bash
   python -m tools.legacy_analyzer complexity stats \
       --db analysis.db
   ```

   Expected output:
   ```
   Total Programs: 5,678
   LOW: 3,456 (60.9%)
   MEDIUM: 1,789 (31.5%)
   HIGH: 389 (6.9%)
   VERY_HIGH: 44 (0.8%)
   God Programs: 12 (0.2%)
   ```

3. **Identify High-Complexity Programs**
   ```bash
   python -m tools.legacy_analyzer complexity top \
       --limit 50 \
       --db analysis.db \
       --output reports/high_complexity_programs.csv
   ```

### Workflow 4: Migration Flow Export

**Objective**: Export and organize migration flows for optimal migration sequencing.

**Steps**:

1. **Identify Entry Points**
   ```bash
   python -m tools.legacy_analyzer flow entry-points \
       --db analysis.db \
       --use-metadata \
       --format json
   ```
   
   This creates `entry_points/entry_points.json` in the default output location.

2. **Export Flows with Different Sorting Strategies**
   ```bash
   # Simplest flows first (recommended for pilot)
   python -m tools.legacy_analyzer migration export-flows \
       --db analysis.db \
       --output flows_by_complexity_asc.json \
       --sort complexity-asc \
       --extended-scope

   # Independent flows (for parallel migration)
   python -m tools.legacy_analyzer migration export-flows \
       --db analysis.db \
       --output flows_by_independence.json \
       --sort independence \
       --extended-scope
   ```

3. **Create Migration Waves**
   ```bash
   # Extract first 10 flows for Wave 1 (Pilot)
   jq '.flows[:10]' flows_by_complexity_asc.json > wave1_flows.json

   # Extract next 15 flows for Wave 2 (Scale)
   jq '.flows[10:25]' flows_by_complexity_asc.json > wave2_flows.json
   ```

### Workflow 5: CICS Metadata Integration

**Objective**: Integrate CICS metadata for accurate entry point identification.

**Steps**:

1. **Convert CSD to CSV**
   ```bash
   python -m tools.legacy_analyzer metadata convert-csd \
       --input app/csd/CARDDEMO.csd \
       --output exports/cics_inventory.csv
   ```

2. **Load CICS Inventory**
   ```bash
   python -m tools.legacy_analyzer load \
       --type cics \
       --file exports/cics_inventory.csv \
       --db analysis.db
   ```

3. **Generate Entry Points Report**
   ```bash
   python -m tools.legacy_analyzer flow entry-points \
       --db analysis.db \
       --use-metadata \
       --format json
   ```
   
   This creates `entry_points/entry_points.json` in the default output location.

## Feature Guide

### Inventory Management

The Legacy Analyzer maintains a comprehensive inventory of all mainframe artifacts.

**Supported Artifact Types**:
- JCL jobs and procedures
- Programs (COBOL, PL/I, Natural, RPG, Assembler)
- Copybooks and includes
- Datasets (VSAM, sequential, partitioned)
- CICS resources (transactions, programs, files, mapsets)

**Loading Inventory**:

```bash
# Load from CSV files
python -m tools.legacy_analyzer load \
    --type <artifact_type> \
    --file <csv_file> \
    --db <database>
```

**Viewing Inventory**:

```bash
# View inventory statistics
python -m tools.legacy_analyzer status --db analysis.db

# Query specific artifact types
sqlite3 analysis.db \
  "SELECT artifact_type, COUNT(*) FROM inventory GROUP BY artifact_type;"
```

### Static Code Analysis

Extract dependencies and relationships from source code.

**Supported Languages**:
- COBOL (.cbl, .cob, .cobol, .cpy)
- PL/I (.pli, .pl1, .inc)
- JCL (.jcl)
- REXX (.rexx, .rex)
- Natural (.nsp, .nsn, .nsc)
- RPG (.rpg, .rpgle)
- Assembler (.asm, .s, .mac)

**Running Analysis**:

```bash
# Analyze specific language
python -m tools.legacy_analyzer analyze \
    --source-dir <directory> \
    --language <language> \
    --db <database>

# Analyze all languages
python -m tools.legacy_analyzer analyze \
    --source-dir <directory> \
    --db <database>
```

**What Gets Extracted**:
- CALL statements (program dependencies)
- COPY/INCLUDE statements (copybook dependencies)
- File access (dataset dependencies)
- CICS commands (transaction dependencies)
- Macro calls (assembler dependencies)

### Flow Analysis

Analyze program execution flows and call hierarchies.

**Entry Point Detection**:
- **ONLINE**: CICS transactions from metadata
- **BATCH**: JCL EXEC statements
- **INFERRED**: Programs never called by others

**Building Call Graphs**:

```bash
# Analyze specific program flow
python -m tools.legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db analysis.db \
    --output flow.json

# Analyze all entry points
python -m tools.legacy_analyzer flow analyze-all \
    --db analysis.db \
    --output flows/
```

**Circular Dependency Detection**:

```bash
python -m tools.legacy_analyzer flow detect-circular \
    --db analysis.db \
    --output circular_deps.csv
```

### Complexity Analysis

Calculate complexity metrics for effort estimation.

**Metrics Calculated**:
- Lines of code (LOC)
- Cyclomatic complexity
- Dependency counts (in/out)
- Composite complexity score
- Complexity tier (LOW, MEDIUM, HIGH, VERY_HIGH)

**Running Complexity Analysis**:

```bash
python -m tools.legacy_analyzer complexity analyze \
    --source-dir <directory> \
    --db <database> \
    --language <language>
```

**Complexity Tiers**:
- **LOW (< 10)**: Simple, easy to migrate
- **MEDIUM (10-25)**: Standard complexity, manageable
- **HIGH (25-50)**: Complex, requires careful planning
- **VERY_HIGH (> 50)**: Very complex, requires refactoring

**God Program Detection**:

Programs with excessive complexity that should be refactored:

```bash
python -m tools.legacy_analyzer complexity god-programs \
    --db analysis.db \
    --output god_programs.csv
```

### Migration Planning

Create migration packages and export flows for execution.

**Flow Export Strategies**:

1. **complexity-asc**: Simplest flows first (recommended for pilot)
2. **complexity-desc**: Most complex flows first (for experienced teams)
3. **independence**: Minimal dependencies first (for parallel migration)
4. **dependencies**: Most dependencies first (for shared infrastructure)
5. **name**: Alphabetical order (for documentation)
6. **none**: Database order (no sorting)

**Exporting Flows**:

```bash
python -m tools.legacy_analyzer migration export-flows \
    --db analysis.db \
    --output flows.json \
    --sort <strategy> \
    --extended-scope
```

**Extended Scope Metadata**:

When `--extended-scope` is used, each flow includes:
- **Copybooks**: All copybooks used with usage counts
- **Datasets**: All datasets accessed with operation types
- **JCL**: All JCL jobs that execute programs
- **CICS Resources**: Transactions, files, and mapsets

**Job Export**:

Export JCL jobs with orchestration and dependencies:

```bash
python -m tools.legacy_analyzer migration export-jobs \
    --db analysis.db \
    --output-dir jobs/ \
    --sort-by <strategy>
```

**Job Categorization**:
- **APPLICATION**: Jobs that invoke custom programs
- **INFRASTRUCTURE**: Jobs that only invoke utilities

### Missing Code Detection

Identify artifacts that are referenced but not found in inventory.

**Finding Missing Artifacts**:

```bash
# Find all missing artifacts
python -m tools.legacy_analyzer missing detect-all \
    --db analysis.db \
    --output missing_artifacts.csv

# Find specific types
python -m tools.legacy_analyzer missing detect-programs \
    --db analysis.db

python -m tools.legacy_analyzer missing detect-copybooks \
    --db analysis.db

python -m tools.legacy_analyzer missing detect-datasets \
    --db analysis.db
```

**Completeness Score**:

```bash
python -m tools.legacy_analyzer missing completeness \
    --db analysis.db
```

Expected output:
```
Inventory Completeness: 94.5%
Missing Programs: 23
Missing Copybooks: 12
Missing Datasets: 45
```

### Reporting

Generate comprehensive reports in multiple formats.

**Report Types**:
- Executive summary
- Complexity distribution
- Flow analysis
- Missing artifacts
- CICS transactions
- Service grouping

**Generating Reports**:

```bash
# Executive summary
python -m tools.legacy_analyzer report executive \
    --db analysis.db \
    --format html \
    --output reports/summary.html

# Complexity report
python -m tools.legacy_analyzer report complexity \
    --db analysis.db \
    --format markdown \
    --output reports/complexity.md

# Flow report
python -m tools.legacy_analyzer report flows \
    --db analysis.db \
    --format json \
    --output reports/flows.json
```

**Supported Formats**:
- JSON: Structured data for programmatic use
- CSV: Spreadsheet-compatible format
- HTML: Interactive web reports
- Markdown: Documentation-friendly format

## Common Use Cases

### Use Case 1: Mainframe Modernization Assessment

**Scenario**: You need to assess a mainframe application for modernization.

**Steps**:

1. Load inventory and analyze source code
2. Calculate complexity metrics
3. Identify entry points and flows
4. Generate executive summary report
5. Present findings to stakeholders

**Commands**:

```bash
# Complete analysis
./complete_analysis.sh ./source-dir ./results

# Generate executive summary
python -m tools.legacy_analyzer report executive \
    --db ./results/analysis.db \
    --format html \
    --output ./results/executive_summary.html
```

### Use Case 2: Cloud Migration Planning

**Scenario**: You're planning a migration to AWS/Azure/GCP.

**Steps**:

1. Analyze dependencies and flows
2. Export flows with complexity-asc sorting
3. Create migration waves (pilot, scale, complete)
4. Export jobs for batch orchestration
5. Generate migration package documentation

**Commands**:

```bash
# Export flows for migration
python -m tools.legacy_analyzer migration export-flows \
    --db analysis.db \
    --output flows_by_complexity.json \
    --sort complexity-asc \
    --extended-scope

# Export jobs
python -m tools.legacy_analyzer migration export-jobs \
    --db analysis.db \
    --output-dir jobs/ \
    --sort-by type

# Create wave plan
jq '.flows[:10]' flows_by_complexity.json > wave1_pilot.json
jq '.flows[10:25]' flows_by_complexity.json > wave2_scale.json
jq '.flows[25:]' flows_by_complexity.json > wave3_complete.json
```

### Use Case 3: Technical Debt Assessment

**Scenario**: You need to identify and prioritize technical debt.

**Steps**:

1. Calculate complexity metrics
2. Identify god programs
3. Detect circular dependencies
4. Find missing artifacts
5. Prioritize refactoring efforts

**Commands**:

```bash
# Find god programs
python -m tools.legacy_analyzer complexity god-programs \
    --db analysis.db \
    --output god_programs.csv

# Find circular dependencies
python -m tools.legacy_analyzer flow detect-circular \
    --db analysis.db \
    --output circular_deps.csv

# Find missing artifacts
python -m tools.legacy_analyzer missing detect-all \
    --db analysis.db \
    --output missing_artifacts.csv
```

### Use Case 4: Service Decomposition

**Scenario**: You want to decompose a monolithic application into microservices.

**Steps**:

1. Analyze CICS transactions and groups
2. Identify shared data access patterns
3. Group related transactions
4. Generate service candidates
5. Create service boundary recommendations

**Commands**:

```bash
# Generate service grouping analysis
python examples/service_grouping_analysis.py \
    --database analysis.db \
    --output-dir services/ \
    --strategy all \
    --min-confidence LOW
```

### Use Case 5: Cleanup and Decommissioning

**Scenario**: You need to identify unused code for cleanup.

**Steps**:

1. Load SMF usage data
2. Identify unreferenced artifacts
3. Assess risk levels
4. Generate cleanup recommendations
5. Create decommissioning plan

**Commands**:

```bash
# Find unreferenced artifacts
python -m smf_queries run \
    --db analysis.db \
    --query unreferenced_artifacts \
    --params analysis_days=365 \
    --format csv \
    --output unreferenced.csv

# Assess risk
python -m smf_queries run \
    --db analysis.db \
    --query artifact_risk_assessment \
    --format csv \
    --output risk_assessment.csv
```

## Best Practices

### Data Collection

1. **Complete Inventory**: Ensure all artifacts are in inventory before analysis
2. **Source Code Access**: Have access to all source code, including copybooks
3. **CICS Metadata**: Include CSD files for accurate entry point detection
4. **SMF Data**: Collect at least 90 days of SMF data for usage analysis
5. **Documentation**: Gather existing documentation and architecture diagrams

### Analysis Execution

1. **Start Small**: Test on a small subsystem first
2. **Incremental Analysis**: Analyze one language at a time
3. **Verify Results**: Spot-check analysis results against known dependencies
4. **Handle Errors**: Review and resolve parsing errors
5. **Parallel Processing**: Use `--parallel` flag for large codebases

### Migration Planning

1. **Pilot First**: Start with simplest flows (complexity-asc)
2. **Parallel Execution**: Use independence sorting for parallel teams
3. **Infrastructure First**: Migrate infrastructure jobs before application jobs
4. **Validate Completeness**: Ensure inventory is complete before planning
5. **Document Decisions**: Keep records of migration decisions and rationale

### Performance Optimization

1. **Database Indexes**: Indexes are created automatically
2. **Batch Processing**: Process large datasets in chunks
3. **Parallel Analysis**: Use multiple workers for source code analysis
4. **Disk Space**: Ensure adequate disk space for databases
5. **Memory**: Allocate sufficient memory for large codebases

### Quality Assurance

1. **Validate Dependencies**: Cross-check extracted dependencies
2. **Review Complexity**: Verify complexity scores make sense
3. **Check Completeness**: Aim for >95% inventory completeness
4. **Test Flows**: Validate flow analysis against known call chains
5. **Peer Review**: Have results reviewed by domain experts

## Troubleshooting

### Common Issues

#### Issue: No Entry Points Detected

**Symptom**:
```
✓ Total entry points detected: 0
```

**Solutions**:
1. Verify CICS metadata is loaded
2. Check that JCL analysis has been run
3. Ensure database path is correct
4. Re-run metadata loading

**Verification**:
```bash
sqlite3 analysis.db \
  "SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION';"
```

#### Issue: Dependencies Not Found

**Symptom**:
```
Dependencies stored: 0
```

**Solutions**:
1. Verify source code paths are correct
2. Check file extensions match language
3. Ensure source code is readable
4. Review parsing errors in logs

**Verification**:
```bash
python -m tools.legacy_analyzer analyze \
    --source-dir ./cobol \
    --language COBOL \
    --db analysis.db \
    --verbose
```

#### Issue: Complexity Metrics Missing

**Symptom**:
```
Error: no such table: complexity_metrics
```

**Solution**:
Run complexity analysis:
```bash
python -m tools.legacy_analyzer complexity analyze \
    --source-dir ./cobol \
    --db analysis.db \
    --language COBOL
```

#### Issue: Database Locked

**Symptom**:
```
Error: database is locked
```

**Solutions**:
1. Close other applications accessing the database
2. Wait for current operations to complete
3. Check for zombie processes
4. Restart the analysis

#### Issue: Out of Memory

**Symptom**:
```
MemoryError: Unable to allocate array
```

**Solutions**:
1. Process files in smaller batches
2. Increase available memory
3. Use `--max-workers` to limit parallelism
4. Close other applications

#### Issue: Parsing Errors

**Symptom**:
```
Error parsing file: PROG001.cbl
```

**Solutions**:
1. Check file encoding (should be ASCII or UTF-8)
2. Verify file is valid source code
3. Check for special characters
4. Review parser logs for details

### Performance Issues

#### Slow Analysis

**Symptoms**:
- Analysis takes hours to complete
- High CPU usage
- Disk thrashing

**Solutions**:
1. Use SSD for database storage
2. Reduce `--max-workers` if CPU-bound
3. Increase `--max-workers` if I/O-bound
4. Process files in batches
5. Use `--parallel` flag

#### Large Database Size

**Symptoms**:
- Database file is very large (>10GB)
- Queries are slow
- Disk space running low

**Solutions**:
1. Run VACUUM to compact database
2. Archive old analysis results
3. Use separate databases for different analyses
4. Consider PostgreSQL for very large datasets

### Getting Help

If you encounter issues not covered here:

1. **Check Logs**: Review application logs for errors
2. **Check Documentation**: See other guides in `docs/` directory
3. **Check Examples**: Review example scripts in `examples/` directory
4. **Report Issues**: Contact support or file an issue

**Log Locations**:
- Application logs: `logs/legacy_analyzer.log`
- Parser logs: `logs/parser.log`
- Database logs: `logs/database.log`

## FAQ

### General Questions

**Q: What mainframe languages are supported?**

A: COBOL, PL/I, JCL, REXX, Natural, RPG, and Assembler.

**Q: Do I need SMF data to use the Legacy Analyzer?**

A: No, SMF data is optional. It's used for usage analysis and prioritization, but the core analysis works without it.

**Q: Can I analyze multiple applications in the same database?**

A: Yes, but it's recommended to use separate databases for different applications to avoid confusion.

**Q: How long does analysis take?**

A: Depends on codebase size. Typical applications (1000-5000 programs) take 10-30 minutes.

### Technical Questions

**Q: What database is used?**

A: SQLite by default. PostgreSQL support is planned for very large datasets.

**Q: Can I run analysis on Windows?**

A: Yes, the Legacy Analyzer works on Windows, macOS, and Linux.

**Q: How much disk space do I need?**

A: Plan for 2-3x the size of your source code. A typical database is 100MB-1GB.

**Q: Can I customize complexity thresholds?**

A: Yes, see the API documentation for `set_complexity_thresholds()`.

### Migration Questions

**Q: What sorting strategy should I use for migration?**

A: Start with `complexity-asc` for pilot, then use `independence` for parallel migration.

**Q: How do I handle circular dependencies?**

A: Identify them with `detect-circular`, then refactor or accept the coupling.

**Q: Should I migrate infrastructure jobs first?**

A: Yes, infrastructure jobs can often be migrated independently and replaced with cloud-native equivalents.

**Q: How do I coordinate job and flow migration?**

A: Use the `linkedFlow` field in job exports to coordinate timing.

### Data Questions

**Q: How do I export inventory from the mainframe?**

A: See the `inventory/exporters/` directory for REXX scripts.

**Q: What if my inventory is incomplete?**

A: Use `missing completeness` to assess completeness. Aim for >95% before migration planning.

**Q: Can I load data from multiple sources?**

A: Yes, you can load inventory from CSV, analyze source code, and load SMF data all into the same database.

**Q: How do I update inventory after changes?**

A: Re-run the load commands. Data is appended or updated as appropriate.

## Next Steps

### For New Users

1. **Complete the Quick Start**: Get familiar with basic commands
2. **Read the CLI Reference**: Learn all available commands
3. **Try the Examples**: Run example scripts in `examples/` directory
4. **Explore the API**: Use the Python API for custom analysis

### For Migration Planning

1. **Read the Migration Guide**: Comprehensive migration workflow
2. **Review Flow Export**: Understand sorting strategies
3. **Study Job Export**: Learn about batch orchestration
4. **Plan Waves**: Create a phased migration plan

### For Developers

1. **Read the API Reference**: Complete Python API documentation
2. **Study the Architecture**: Understand system design
3. **Review Parsers**: Learn how language parsers work
4. **Contribute**: See the Contributing guide

## Additional Resources

- **[CLI Reference](CLI_REFERENCE.md)**: Complete command-line reference
- **[API Reference](API.md)**: Python API documentation
- **[Migration Guide](MIGRATION_GUIDE.md)**: Complete migration workflow
- **[Architecture](ARCHITECTURE.md)**: System architecture and design
- **[Parsers](PARSERS.md)**: Parser documentation and development
- **[CICS Integration](advanced/CICS_INTEGRATION.md)**: CICS metadata integration
- **[Complexity Analysis](advanced/COMPLEXITY_ANALYSIS.md)**: Complexity metrics and scoring
- **[Flow Analysis](advanced/FLOW_ANALYSIS.md)**: Flow analysis algorithms

---

**Need Help?** Check the [README](../README.md) for installation instructions, or contact support for assistance.

**Version**: 2.1.0  
**Last Updated**: February 3, 2026
