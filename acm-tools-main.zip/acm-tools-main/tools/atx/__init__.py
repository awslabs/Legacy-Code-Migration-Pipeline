"""
ATX tools package.

Contains tools for working with ATX (Application Transformation eXplorer) outputs.
"""

__version__ = "1.0.0"
