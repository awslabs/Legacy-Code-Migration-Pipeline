"""
ATX Dependency Transformer

Transforms ATX tool outputs into legacy_analyzer-compatible format.
"""

from .models.atx_models import ATXDependency, ATXAssetMetrics, ATXDataOperation
from .models.legacy_models import (
    Flow,
    Job,
    EntryPoint,
    EntryPointRecord,
    Scope,
    Program,
    DataOperations,
    Complexity,
    FlowDependencies,
)
from .models.config_models import TransformationConfig

__version__ = "1.0.0"

__all__ = [
    "ATXDependency",
    "ATXAssetMetrics",
    "ATXDataOperation",
    "Flow",
    "Job",
    "EntryPoint",
    "EntryPointRecord",
    "Scope",
    "Program",
    "DataOperations",
    "Complexity",
    "FlowDependencies",
    "TransformationConfig",
]
