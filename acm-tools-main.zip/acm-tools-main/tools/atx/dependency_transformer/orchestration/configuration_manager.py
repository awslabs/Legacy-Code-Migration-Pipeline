"""
Configuration management for ATX Dependency Transformer.

This module provides the ConfigurationManager class for loading, validating,
and managing transformation configuration from YAML files.
"""

import yaml
from pathlib import Path
from typing import Optional, Dict, Any
from ..models.config_models import TransformationConfig


class ConfigurationManager:
    """
    Manages configuration loading and validation.
    
    Loads configuration from YAML files, provides default configuration,
    and validates configuration values.
    """
    
    def __init__(self, config_path: Optional[Path] = None):
        """
        Initialize ConfigurationManager.
        
        Args:
            config_path: Optional path to YAML configuration file.
                        If None, uses default configuration.
        """
        self.config_path = config_path
        self._config: Optional[TransformationConfig] = None
    
    def load(self) -> TransformationConfig:
        """
        Load configuration from file or use defaults.
        
        Returns:
            TransformationConfig instance
            
        Raises:
            FileNotFoundError: If config_path is specified but file doesn't exist
            ValueError: If configuration is invalid
            yaml.YAMLError: If YAML parsing fails
        """
        if self.config_path is None:
            # Use default configuration
            self._config = self.get_default_config()
            return self._config
        
        # Load from file
        config_path = Path(self.config_path)
        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        if not config_path.is_file():
            raise ValueError(f"Configuration path is not a file: {config_path}")
        
        try:
            with open(config_path, 'r') as f:
                config_dict = yaml.safe_load(f)
        except yaml.YAMLError as e:
            raise yaml.YAMLError(f"Failed to parse YAML configuration: {e}")
        
        if config_dict is None:
            # Empty file, use defaults
            self._config = self.get_default_config()
            return self._config
        
        # Validate and create configuration
        self._config = self._validate_and_create_config(config_dict)
        return self._config
    
    def get_config(self) -> TransformationConfig:
        """
        Get the loaded configuration.
        
        Returns:
            TransformationConfig instance
            
        Raises:
            RuntimeError: If configuration hasn't been loaded yet
        """
        if self._config is None:
            raise RuntimeError("Configuration not loaded. Call load() first.")
        return self._config
    
    @staticmethod
    def get_default_config() -> TransformationConfig:
        """
        Get default configuration.
        
        Returns:
            TransformationConfig with default values
        """
        return TransformationConfig()
    
    def _validate_and_create_config(self, config_dict: Dict[str, Any]) -> TransformationConfig:
        """
        Validate configuration dictionary and create TransformationConfig.
        
        Args:
            config_dict: Dictionary loaded from YAML file
            
        Returns:
            TransformationConfig instance
            
        Raises:
            ValueError: If configuration is invalid
        """
        # Validate complexity formula weights
        if "complexity" in config_dict:
            complexity = config_dict["complexity"]
            if "formula" in complexity:
                formula = complexity["formula"]
                if "cc_weight" in formula:
                    cc_weight = formula["cc_weight"]
                    if not isinstance(cc_weight, (int, float)):
                        raise ValueError(
                            f"complexity.formula.cc_weight must be a number, got {type(cc_weight).__name__}"
                        )
                    if cc_weight < 0:
                        raise ValueError(
                            f"complexity.formula.cc_weight must be non-negative, got {cc_weight}"
                        )
                
                if "loc_weight" in formula:
                    loc_weight = formula["loc_weight"]
                    if not isinstance(loc_weight, (int, float)):
                        raise ValueError(
                            f"complexity.formula.loc_weight must be a number, got {type(loc_weight).__name__}"
                        )
                    if loc_weight < 0:
                        raise ValueError(
                            f"complexity.formula.loc_weight must be non-negative, got {loc_weight}"
                        )
            
            # Validate complexity tier thresholds
            if "tiers" in complexity:
                tiers = complexity["tiers"]
                if "low_threshold" in tiers:
                    low_threshold = tiers["low_threshold"]
                    if not isinstance(low_threshold, (int, float)):
                        raise ValueError(
                            f"complexity.tiers.low_threshold must be a number, got {type(low_threshold).__name__}"
                        )
                    if low_threshold < 0:
                        raise ValueError(
                            f"complexity.tiers.low_threshold must be non-negative, got {low_threshold}"
                        )
                
                if "medium_threshold" in tiers:
                    medium_threshold = tiers["medium_threshold"]
                    if not isinstance(medium_threshold, (int, float)):
                        raise ValueError(
                            f"complexity.tiers.medium_threshold must be a number, got {type(medium_threshold).__name__}"
                        )
                    
                    # Check that medium_threshold > low_threshold
                    low_threshold = tiers.get("low_threshold", 10.0)
                    if medium_threshold <= low_threshold:
                        raise ValueError(
                            f"complexity.tiers.medium_threshold ({medium_threshold}) must be greater than "
                            f"low_threshold ({low_threshold})"
                        )
        
        # Validate utility_programs is a list
        if "utility_programs" in config_dict:
            utility_programs = config_dict["utility_programs"]
            if not isinstance(utility_programs, list):
                raise ValueError(
                    f"utility_programs must be a list, got {type(utility_programs).__name__}"
                )
            for i, program in enumerate(utility_programs):
                if not isinstance(program, str):
                    raise ValueError(
                        f"utility_programs[{i}] must be a string, got {type(program).__name__}"
                    )
        
        # Validate transformation options
        if "transformation" in config_dict:
            transformation = config_dict["transformation"]
            bool_fields = [
                "include_inferred_entry_points",
                "warn_on_missing_metrics",
                "fail_on_invalid_schema",
            ]
            for field in bool_fields:
                if field in transformation:
                    value = transformation[field]
                    if not isinstance(value, bool):
                        raise ValueError(
                            f"transformation.{field} must be a boolean, got {type(value).__name__}"
                        )
        
        # Validate output options
        if "output" in config_dict:
            output = config_dict["output"]
            bool_fields = [
                "generate_sorted_variants",
                "generate_csv_exports",
                "pretty_print_json",
            ]
            for field in bool_fields:
                if field in output:
                    value = output[field]
                    if not isinstance(value, bool):
                        raise ValueError(
                            f"output.{field} must be a boolean, got {type(value).__name__}"
                        )
            
            if "indent_size" in output:
                indent_size = output["indent_size"]
                if not isinstance(indent_size, int):
                    raise ValueError(
                        f"output.indent_size must be an integer, got {type(indent_size).__name__}"
                    )
                if indent_size < 0:
                    raise ValueError(
                        f"output.indent_size must be non-negative, got {indent_size}"
                    )
        
        # Create configuration using from_dict
        try:
            config = TransformationConfig.from_dict(config_dict)
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid configuration: {e}")
        
        return config
    
    def save(self, output_path: Path) -> None:
        """
        Save current configuration to YAML file.
        
        Args:
            output_path: Path where to save the configuration
            
        Raises:
            RuntimeError: If configuration hasn't been loaded yet
        """
        if self._config is None:
            raise RuntimeError("Configuration not loaded. Call load() first.")
        
        config_dict = self._config.to_dict()
        
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w') as f:
            yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)
