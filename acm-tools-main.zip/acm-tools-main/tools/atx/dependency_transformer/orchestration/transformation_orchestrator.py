"""
Transformation orchestrator.

This module coordinates the complete transformation pipeline, managing the
flow from ATX inputs through validation, transformation, and output generation.
"""

import time
from pathlib import Path
from typing import Optional, List

from ..models.config_models import (
    TransformationConfig,
    TransformationReport,
    ValidationResult,
)
from ..models.legacy_models import Flow, Job, EntryPointRecord
from ..loaders.atx_dependency_loader import ATXDependencyLoader
from ..loaders.atx_assets_loader import ATXAssetsLoader
from ..loaders.atx_data_operations_loader import ATXDataOperationsLoader
from ..loaders.path_resolver import PathResolver
from ..analysis.call_graph_analyzer import CallGraphAnalyzer
from ..analysis.complexity_calculator import ComplexityCalculator
from ..analysis.dependency_resolver import DependencyResolver
from ..transformers.flow_transformer import FlowTransformer
from ..transformers.job_transformer import JobTransformer
from ..transformers.entry_point_transformer import EntryPointTransformer
from ..writers.flow_writer import FlowWriter
from ..writers.job_writer import JobWriter
from ..writers.entry_point_writer import EntryPointWriter
from .validation_engine import ValidationEngine


class TransformationOrchestrator:
    """
    Orchestrates the complete transformation pipeline.
    
    Coordinates loading ATX data, validating inputs, transforming to legacy
    analyzer format, and writing outputs. Supports dry-run mode for validation
    without writing files.
    """
    
    def __init__(self, config: Optional[TransformationConfig] = None):
        """
        Initialize orchestrator with configuration.
        
        Args:
            config: Transformation configuration (uses defaults if None)
        """
        self.config = config or TransformationConfig()
        self.validation_engine = ValidationEngine()
        
        # Initialize components (will be populated during transformation)
        self.dependency_loader: Optional[ATXDependencyLoader] = None
        self.assets_loader: Optional[ATXAssetsLoader] = None
        self.data_ops_loader: Optional[ATXDataOperationsLoader] = None
        self.path_resolver: Optional[PathResolver] = None
        self.call_graph: Optional[CallGraphAnalyzer] = None
        self.complexity_calc: Optional[ComplexityCalculator] = None
        self.dependency_resolver: Optional[DependencyResolver] = None
    
    def transform_all(self, input_dir: str, output_dir: str, 
                     dry_run: bool = False) -> TransformationReport:
        """
        Execute complete transformation (flows, jobs, entry points).
        
        Args:
            input_dir: Directory containing ATX input files
            output_dir: Directory for output files
            dry_run: If True, validate but don't write files
            
        Returns:
            TransformationReport with statistics and status
        """
        start_time = time.time()
        report = TransformationReport(success=False, dry_run=dry_run)
        
        try:
            # Validate inputs
            validation_result = self.validate_inputs(input_dir)
            report.warnings.extend(validation_result.warnings)
            report.errors.extend(validation_result.errors)
            
            if not validation_result.valid:
                report.success = False
                report.execution_time_seconds = time.time() - start_time
                return report
            
            # Load data
            self._load_data(input_dir, report)
            
            # Build analysis components
            self._build_analyzers(report)
            
            # Transform flows
            flows = self._transform_flows(report)
            report.flows_generated = len(flows)
            
            # Transform jobs
            jobs = self._transform_jobs(report)
            report.jobs_generated = len(jobs)
            
            # Transform entry points
            entry_points = self._transform_entry_points(report)
            report.entry_points_generated = len(entry_points)
            
            # Count programs processed
            if self.dependency_loader:
                report.programs_processed = len(self.dependency_loader.get_programs())
            
            # Write outputs (unless dry-run)
            if not dry_run:
                self._write_outputs(output_dir, flows, jobs, entry_points, report)
            
            report.success = True
            
        except Exception as e:
            report.add_error(
                category="TRANSFORMATION_ERROR",
                message=f"Transformation failed: {str(e)}",
                fatal=True
            )
            report.success = False
        
        report.execution_time_seconds = time.time() - start_time
        return report
    
    def transform_flows(self, input_dir: str, output_dir: str,
                       dry_run: bool = False) -> TransformationReport:
        """
        Transform only flows.
        
        Args:
            input_dir: Directory containing ATX input files
            output_dir: Directory for output files
            dry_run: If True, validate but don't write files
            
        Returns:
            TransformationReport with statistics and status
        """
        start_time = time.time()
        report = TransformationReport(success=False, dry_run=dry_run)
        
        try:
            # Validate inputs
            validation_result = self.validate_inputs(input_dir)
            report.warnings.extend(validation_result.warnings)
            report.errors.extend(validation_result.errors)
            
            if not validation_result.valid:
                report.success = False
                report.execution_time_seconds = time.time() - start_time
                return report
            
            # Load data
            self._load_data(input_dir, report)
            
            # Build analysis components
            self._build_analyzers(report)
            
            # Transform flows
            flows = self._transform_flows(report)
            report.flows_generated = len(flows)
            
            # Count programs processed
            if self.dependency_loader:
                report.programs_processed = len(self.dependency_loader.get_programs())
            
            # Write outputs (unless dry-run)
            if not dry_run:
                output_path = Path(output_dir)
                output_path.mkdir(parents=True, exist_ok=True)
                
                flow_writer = FlowWriter(self.config)
                flow_writer.write(flows, str(output_path))
            
            report.success = True
            
        except Exception as e:
            report.add_error(
                category="TRANSFORMATION_ERROR",
                message=f"Flow transformation failed: {str(e)}",
                fatal=True
            )
            report.success = False
        
        report.execution_time_seconds = time.time() - start_time
        return report
    
    def transform_jobs(self, input_dir: str, output_dir: str,
                      dry_run: bool = False) -> TransformationReport:
        """
        Transform only jobs.
        
        Args:
            input_dir: Directory containing ATX input files
            output_dir: Directory for output files
            dry_run: If True, validate but don't write files
            
        Returns:
            TransformationReport with statistics and status
        """
        start_time = time.time()
        report = TransformationReport(success=False, dry_run=dry_run)
        
        try:
            # Validate inputs
            validation_result = self.validate_inputs(input_dir)
            report.warnings.extend(validation_result.warnings)
            report.errors.extend(validation_result.errors)
            
            if not validation_result.valid:
                report.success = False
                report.execution_time_seconds = time.time() - start_time
                return report
            
            # Load data (only dependency loader needed for jobs)
            input_path = Path(input_dir)
            dependencies_file = input_path / "dependencies.json"
            
            self.dependency_loader = ATXDependencyLoader()
            self.dependency_loader.load(str(dependencies_file))
            
            # Transform jobs
            jobs = self._transform_jobs(report)
            report.jobs_generated = len(jobs)
            
            # Count programs processed
            if self.dependency_loader:
                report.programs_processed = len(self.dependency_loader.get_programs())
            
            # Write outputs (unless dry-run)
            if not dry_run:
                output_path = Path(output_dir)
                output_path.mkdir(parents=True, exist_ok=True)
                
                job_writer = JobWriter(self.config)
                job_writer.write(jobs, str(output_path))
            
            report.success = True
            
        except Exception as e:
            report.add_error(
                category="TRANSFORMATION_ERROR",
                message=f"Job transformation failed: {str(e)}",
                fatal=True
            )
            report.success = False
        
        report.execution_time_seconds = time.time() - start_time
        return report
    
    def transform_entry_points(self, input_dir: str, output_dir: str,
                              dry_run: bool = False) -> TransformationReport:
        """
        Transform only entry points.
        
        Args:
            input_dir: Directory containing ATX input files
            output_dir: Directory for output files
            dry_run: If True, validate but don't write files
            
        Returns:
            TransformationReport with statistics and status
        """
        start_time = time.time()
        report = TransformationReport(success=False, dry_run=dry_run)
        
        try:
            # Validate inputs
            validation_result = self.validate_inputs(input_dir)
            report.warnings.extend(validation_result.warnings)
            report.errors.extend(validation_result.errors)
            
            if not validation_result.valid:
                report.success = False
                report.execution_time_seconds = time.time() - start_time
                return report
            
            # Load data (dependency loader and call graph needed)
            input_path = Path(input_dir)
            dependencies_file = input_path / "dependencies.json"
            
            self.dependency_loader = ATXDependencyLoader()
            self.dependency_loader.load(str(dependencies_file))
            
            # Build call graph
            self.call_graph = CallGraphAnalyzer()
            # Build program_calls dictionary from dependencies
            program_calls = {}
            for dep in self.dependency_loader.get_all_dependencies():
                calls = self.dependency_loader.get_program_calls(dep.name)
                if calls or dep.type == 'COB':  # Include all programs
                    program_calls[dep.name] = calls
            
            self.call_graph.build_call_graph(program_calls)
            
            # Transform entry points
            entry_points = self._transform_entry_points(report)
            report.entry_points_generated = len(entry_points)
            
            # Count programs processed
            if self.dependency_loader:
                report.programs_processed = len(self.dependency_loader.get_programs())
            
            # Write outputs (unless dry-run)
            if not dry_run:
                output_path = Path(output_dir)
                output_path.mkdir(parents=True, exist_ok=True)
                
                entry_point_writer = EntryPointWriter(self.config)
                entry_point_writer.write_json(entry_points, str(output_path / "entry_points.json"))
                
                if self.config.output.generate_csv_exports:
                    exports_dir = output_path / "exports"
                    exports_dir.mkdir(parents=True, exist_ok=True)
                    entry_point_writer.write_csv(entry_points, str(exports_dir / "entry_points.csv"))
            
            report.success = True
            
        except Exception as e:
            report.add_error(
                category="TRANSFORMATION_ERROR",
                message=f"Entry point transformation failed: {str(e)}",
                fatal=True
            )
            report.success = False
        
        report.execution_time_seconds = time.time() - start_time
        return report
    
    def validate_inputs(self, input_dir: str) -> ValidationResult:
        """
        Validate ATX input files.
        
        Args:
            input_dir: Directory containing ATX input files
            
        Returns:
            ValidationResult with validation status and messages
        """
        return self.validation_engine.validate_input_directory(input_dir)
    
    def _load_data(self, input_dir: str, report: TransformationReport):
        """
        Load all ATX input files.
        
        Args:
            input_dir: Directory containing ATX input files
            report: Report to add warnings/errors to
        """
        input_path = Path(input_dir)
        
        # Load dependencies
        dependencies_file = input_path / "dependencies.json"
        self.dependency_loader = ATXDependencyLoader()
        self.dependency_loader.load(str(dependencies_file))
        
        # Load assets
        assets_file = input_path / "assets.csv"
        self.assets_loader = ATXAssetsLoader()
        try:
            self.assets_loader.load(str(assets_file))
        except Exception as e:
            if self.config.transformation.warn_on_missing_metrics:
                report.add_warning(
                    category="MISSING_DATA",
                    message=f"Failed to load assets.csv: {str(e)}",
                    context={"file": str(assets_file)}
                )
        
        # Load data operations
        data_ops_file = input_path / "program_to_dsn.json"
        self.data_ops_loader = ATXDataOperationsLoader()
        try:
            self.data_ops_loader.load(str(data_ops_file))
        except Exception as e:
            report.add_warning(
                category="MISSING_DATA",
                message=f"Failed to load program_to_dsn.json: {str(e)}",
                context={"file": str(data_ops_file)}
            )
    
    def _build_analyzers(self, report: TransformationReport):
        """
        Build analysis components.
        
        Args:
            report: Report to add warnings/errors to
        """
        # Build path resolver with default search paths
        search_paths = ['.', './examples/code']
        self.path_resolver = PathResolver(search_paths=search_paths)
        
        # Build call graph
        self.call_graph = CallGraphAnalyzer()
        if self.dependency_loader:
            # Build program_calls dictionary from dependencies
            program_calls = {}
            for dep in self.dependency_loader.get_all_dependencies():
                calls = self.dependency_loader.get_program_calls(dep.name)
                if calls or dep.type == 'COB':  # Include all programs, even if they don't call anything
                    program_calls[dep.name] = calls
            
            self.call_graph.build_call_graph(program_calls)
        
        # Build complexity calculator
        self.complexity_calc = ComplexityCalculator(self.config.complexity)
        
        # Build dependency resolver (needs call graph)
        self.dependency_resolver = DependencyResolver(self.call_graph)
    
    def _transform_flows(self, report: TransformationReport) -> List[Flow]:
        """
        Transform flows.
        
        Args:
            report: Report to add warnings/errors to
            
        Returns:
            List of transformed flows
        """
        if not all([self.dependency_loader, self.call_graph, 
                   self.complexity_calc, self.path_resolver]):
            raise ValueError("Required components not initialized")
        
        transformer = FlowTransformer(
            dependency_loader=self.dependency_loader,
            assets_loader=self.assets_loader,
            data_ops_loader=self.data_ops_loader,
            path_resolver=self.path_resolver,
            call_graph=self.call_graph,
            complexity_calc=self.complexity_calc,
            config=self.config
        )
        
        flows = transformer.transform()
        
        return flows
    
    def _transform_jobs(self, report: TransformationReport) -> List[Job]:
        """
        Transform jobs.
        
        Args:
            report: Report to add warnings/errors to
            
        Returns:
            List of transformed jobs
        """
        if not self.dependency_loader:
            raise ValueError("Dependency loader not initialized")
        
        transformer = JobTransformer(
            dependency_loader=self.dependency_loader,
            config=self.config
        )
        
        jobs = transformer.transform()
        
        return jobs
    
    def _transform_entry_points(self, report: TransformationReport) -> List[EntryPointRecord]:
        """
        Transform entry points.
        
        Args:
            report: Report to add warnings/errors to
            
        Returns:
            List of transformed entry points
        """
        if not all([self.dependency_loader, self.call_graph]):
            raise ValueError("Required components not initialized")
        
        transformer = EntryPointTransformer(
            dependency_loader=self.dependency_loader,
            call_graph=self.call_graph,
            config=self.config
        )
        
        entry_points = transformer.transform()
        
        return entry_points
    
    def _write_outputs(self, output_dir: str, flows: List[Flow], 
                      jobs: List[Job], entry_points: List[EntryPointRecord],
                      report: TransformationReport):
        """
        Write all outputs.
        
        Args:
            output_dir: Directory for output files
            flows: Flows to write
            jobs: Jobs to write
            entry_points: Entry points to write
            report: Report to add warnings/errors to
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Write flows
        flow_writer = FlowWriter(self.config)
        flow_writer.write(flows, str(output_path))
        
        # Write jobs
        job_writer = JobWriter(self.config)
        job_writer.write(jobs, str(output_path))
        
        # Write entry points
        entry_point_writer = EntryPointWriter(self.config)
        entry_point_writer.write_json(entry_points, str(output_path / "entry_points.json"))
        
        if self.config.output.generate_csv_exports:
            exports_dir = output_path / "exports"
            exports_dir.mkdir(parents=True, exist_ok=True)
            entry_point_writer.write_csv(entry_points, str(exports_dir / "entry_points.csv"))
