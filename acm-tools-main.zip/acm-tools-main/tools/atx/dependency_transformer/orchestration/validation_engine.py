"""
Validation engine for ATX input files.

This module provides validation for ATX input files, checking for:
- File existence and readability
- JSON/CSV format validity
- ATX schema structure conformance
- Data consistency
"""

import json
import csv
from pathlib import Path
from typing import Dict, Any, List, Optional

from ..models.config_models import ValidationResult, ValidationError, ValidationWarning


class ValidationEngine:
    """
    Validates ATX input files before transformation.
    
    Performs comprehensive validation of ATX input files including:
    - File existence and readability
    - JSON/CSV format validation
    - Schema structure validation
    - Data consistency checks
    """
    
    # Required files for transformation
    REQUIRED_FILES = {
        "dependencies.json": "ATX dependencies file",
        "assets.csv": "ATX assets metrics file",
        "program_to_dsn.json": "ATX data operations file",
    }
    
    # Required fields in dependencies.json entries
    DEPENDENCY_REQUIRED_FIELDS = ["name", "path", "type", "dependencies"]
    
    # Required fields in assets.csv
    ASSETS_REQUIRED_FIELDS = [
        "Name", "Path", "File type", "Cyclomatic Complexity",
        "Total lines", "Empty Lines", "Effective Lines", "Comment Lines"
    ]
    
    # Required fields in program_to_dsn.json entries
    DATA_OPS_REQUIRED_FIELDS = [
        "fileName", "filePath", "dataSourceName", "accessType"
    ]
    
    def __init__(self):
        """Initialize the validation engine."""
        pass
    
    def validate_input_directory(self, input_dir: str) -> ValidationResult:
        """
        Validate all required input files in the directory.
        
        Args:
            input_dir: Path to directory containing ATX input files
            
        Returns:
            ValidationResult with validation status, errors, and warnings
        """
        result = ValidationResult(valid=True)
        input_path = Path(input_dir)
        
        # Check if directory exists
        if not input_path.exists():
            result.add_error(
                "MISSING_DIRECTORY",
                f"Input directory does not exist: {input_dir}",
                {"path": input_dir},
                fatal=True
            )
            return result
        
        if not input_path.is_dir():
            result.add_error(
                "INVALID_DIRECTORY",
                f"Input path is not a directory: {input_dir}",
                {"path": input_dir},
                fatal=True
            )
            return result
        
        # Check for required files
        for filename, description in self.REQUIRED_FILES.items():
            file_path = input_path / filename
            if not file_path.exists():
                result.add_error(
                    "MISSING_FILE",
                    f"Required file not found: {filename} ({description})",
                    {"file": filename, "path": str(file_path)},
                    fatal=True
                )
            elif not file_path.is_file():
                result.add_error(
                    "INVALID_FILE",
                    f"Path is not a file: {filename}",
                    {"file": filename, "path": str(file_path)},
                    fatal=True
                )
        
        # If any required files are missing, stop here
        if result.has_fatal_errors():
            return result
        
        # Validate each file's format and schema
        self._validate_dependencies_file(input_path / "dependencies.json", result)
        self._validate_assets_file(input_path / "assets.csv", result)
        self._validate_data_operations_file(input_path / "program_to_dsn.json", result)
        
        return result
    
    def _validate_dependencies_file(self, file_path: Path, result: ValidationResult):
        """
        Validate dependencies.json file.
        
        Args:
            file_path: Path to dependencies.json
            result: ValidationResult to update with findings
        """
        try:
            # Check if file is readable
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except PermissionError:
            result.add_error(
                "PERMISSION_DENIED",
                f"Cannot read file: {file_path.name}",
                {"file": str(file_path)},
                fatal=True
            )
            return
        except json.JSONDecodeError as e:
            result.add_error(
                "INVALID_JSON",
                f"Invalid JSON format in {file_path.name}: {str(e)}",
                {"file": str(file_path), "line": e.lineno, "column": e.colno},
                fatal=True
            )
            return
        except Exception as e:
            result.add_error(
                "READ_ERROR",
                f"Error reading {file_path.name}: {str(e)}",
                {"file": str(file_path)},
                fatal=True
            )
            return
        
        # Validate schema structure
        if not isinstance(data, list):
            result.add_error(
                "SCHEMA_ERROR",
                f"{file_path.name} must contain a JSON array",
                {"file": str(file_path), "type": type(data).__name__},
                fatal=True
            )
            return
        
        if len(data) == 0:
            result.add_warning(
                "EMPTY_FILE",
                f"{file_path.name} contains no entries",
                {"file": str(file_path)}
            )
            return
        
        # Validate entries
        missing_fields_count = 0
        for i, entry in enumerate(data):
            if not isinstance(entry, dict):
                result.add_error(
                    "SCHEMA_ERROR",
                    f"Entry {i} in {file_path.name} is not a JSON object",
                    {"file": str(file_path), "entry_index": i},
                    fatal=False
                )
                continue
            
            # Check for required fields
            missing_fields = [
                field for field in self.DEPENDENCY_REQUIRED_FIELDS
                if field not in entry
            ]
            
            if missing_fields:
                missing_fields_count += 1
                if missing_fields_count <= 5:  # Only report first 5
                    result.add_warning(
                        "MISSING_FIELDS",
                        f"Entry {i} in {file_path.name} missing fields: {', '.join(missing_fields)}",
                        {"file": str(file_path), "entry_index": i, "missing": missing_fields}
                    )
        
        if missing_fields_count > 5:
            result.add_warning(
                "MISSING_FIELDS",
                f"{missing_fields_count - 5} more entries with missing fields in {file_path.name}",
                {"file": str(file_path), "count": missing_fields_count - 5}
            )
    
    def _validate_assets_file(self, file_path: Path, result: ValidationResult):
        """
        Validate assets.csv file.
        
        Args:
            file_path: Path to assets.csv
            result: ValidationResult to update with findings
        """
        try:
            # Check if file is readable
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                
                # Check for required fields in header
                if reader.fieldnames is None:
                    result.add_error(
                        "SCHEMA_ERROR",
                        f"{file_path.name} has no header row",
                        {"file": str(file_path)},
                        fatal=True
                    )
                    return
                
                missing_fields = [
                    field for field in self.ASSETS_REQUIRED_FIELDS
                    if field not in reader.fieldnames
                ]
                
                if missing_fields:
                    result.add_error(
                        "SCHEMA_ERROR",
                        f"{file_path.name} missing required columns: {', '.join(missing_fields)}",
                        {"file": str(file_path), "missing": missing_fields},
                        fatal=True
                    )
                    return
                
                # Validate rows
                row_count = 0
                invalid_rows = 0
                for i, row in enumerate(reader, start=2):  # Start at 2 (header is row 1)
                    row_count += 1
                    
                    # Check for empty required fields
                    empty_fields = [
                        field for field in self.ASSETS_REQUIRED_FIELDS
                        if not row.get(field, "").strip()
                    ]
                    
                    if empty_fields:
                        invalid_rows += 1
                        if invalid_rows <= 5:  # Only report first 5
                            result.add_warning(
                                "EMPTY_FIELDS",
                                f"Row {i} in {file_path.name} has empty fields: {', '.join(empty_fields)}",
                                {"file": str(file_path), "row": i, "empty": empty_fields}
                            )
                
                if row_count == 0:
                    result.add_warning(
                        "EMPTY_FILE",
                        f"{file_path.name} contains no data rows",
                        {"file": str(file_path)}
                    )
                
                if invalid_rows > 5:
                    result.add_warning(
                        "EMPTY_FIELDS",
                        f"{invalid_rows - 5} more rows with empty fields in {file_path.name}",
                        {"file": str(file_path), "count": invalid_rows - 5}
                    )
                    
        except PermissionError:
            result.add_error(
                "PERMISSION_DENIED",
                f"Cannot read file: {file_path.name}",
                {"file": str(file_path)},
                fatal=True
            )
        except csv.Error as e:
            result.add_error(
                "INVALID_CSV",
                f"Invalid CSV format in {file_path.name}: {str(e)}",
                {"file": str(file_path)},
                fatal=True
            )
        except Exception as e:
            result.add_error(
                "READ_ERROR",
                f"Error reading {file_path.name}: {str(e)}",
                {"file": str(file_path)},
                fatal=True
            )
    
    def _validate_data_operations_file(self, file_path: Path, result: ValidationResult):
        """
        Validate program_to_dsn.json file.
        
        Args:
            file_path: Path to program_to_dsn.json
            result: ValidationResult to update with findings
        """
        try:
            # Check if file is readable
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except PermissionError:
            result.add_error(
                "PERMISSION_DENIED",
                f"Cannot read file: {file_path.name}",
                {"file": str(file_path)},
                fatal=True
            )
            return
        except json.JSONDecodeError as e:
            result.add_error(
                "INVALID_JSON",
                f"Invalid JSON format in {file_path.name}: {str(e)}",
                {"file": str(file_path), "line": e.lineno, "column": e.colno},
                fatal=True
            )
            return
        except Exception as e:
            result.add_error(
                "READ_ERROR",
                f"Error reading {file_path.name}: {str(e)}",
                {"file": str(file_path)},
                fatal=True
            )
            return
        
        # Validate schema structure
        if not isinstance(data, list):
            result.add_error(
                "SCHEMA_ERROR",
                f"{file_path.name} must contain a JSON array",
                {"file": str(file_path), "type": type(data).__name__},
                fatal=True
            )
            return
        
        if len(data) == 0:
            result.add_warning(
                "EMPTY_FILE",
                f"{file_path.name} contains no entries",
                {"file": str(file_path)}
            )
            return
        
        # Validate entries
        missing_fields_count = 0
        for i, entry in enumerate(data):
            if not isinstance(entry, dict):
                result.add_error(
                    "SCHEMA_ERROR",
                    f"Entry {i} in {file_path.name} is not a JSON object",
                    {"file": str(file_path), "entry_index": i},
                    fatal=False
                )
                continue
            
            # Check for required fields
            missing_fields = [
                field for field in self.DATA_OPS_REQUIRED_FIELDS
                if field not in entry
            ]
            
            if missing_fields:
                missing_fields_count += 1
                if missing_fields_count <= 5:  # Only report first 5
                    result.add_warning(
                        "MISSING_FIELDS",
                        f"Entry {i} in {file_path.name} missing fields: {', '.join(missing_fields)}",
                        {"file": str(file_path), "entry_index": i, "missing": missing_fields}
                    )
        
        if missing_fields_count > 5:
            result.add_warning(
                "MISSING_FIELDS",
                f"{missing_fields_count - 5} more entries with missing fields in {file_path.name}",
                {"file": str(file_path), "count": missing_fields_count - 5}
            )
    
    def validate_file_exists(self, file_path: str) -> ValidationResult:
        """
        Validate that a single file exists and is readable.
        
        Args:
            file_path: Path to file to validate
            
        Returns:
            ValidationResult with validation status
        """
        result = ValidationResult(valid=True)
        path = Path(file_path)
        
        if not path.exists():
            result.add_error(
                "MISSING_FILE",
                f"File does not exist: {file_path}",
                {"path": file_path},
                fatal=True
            )
        elif not path.is_file():
            result.add_error(
                "INVALID_FILE",
                f"Path is not a file: {file_path}",
                {"path": file_path},
                fatal=True
            )
        else:
            # Try to read the file
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    f.read(1)  # Try to read one character
            except PermissionError:
                result.add_error(
                    "PERMISSION_DENIED",
                    f"Cannot read file: {file_path}",
                    {"path": file_path},
                    fatal=True
                )
            except Exception as e:
                result.add_error(
                    "READ_ERROR",
                    f"Error reading file: {str(e)}",
                    {"path": file_path},
                    fatal=True
                )
        
        return result
