"""
Main entry point for ATX Dependency Transformer module.

Enables execution via: python -m tools.atx.dependency_transformer
"""

from .cli import main

if __name__ == "__main__":
    main()
