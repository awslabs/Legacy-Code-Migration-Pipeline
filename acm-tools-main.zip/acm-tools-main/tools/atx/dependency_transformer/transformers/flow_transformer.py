"""
Flow Transformer.

Transforms ATX data to legacy_analyzer flow format.
Builds flows from entry points with scope, complexity, and data operations.
"""

from typing import List, Dict, Set, Optional
from ..models.atx_models import ATXDependency, ATXAssetMetrics, ATXDataOperation
from ..models.legacy_models import (
    Flow, EntryPoint, EntryPointType, Caller, Scope, Program,
    DataOperations, DatabaseOperation, DatasetOperation, Complexity,
    FlowDependencies
)
from ..models.config_models import TransformationConfig
from ..loaders.atx_dependency_loader import ATXDependencyLoader
from ..loaders.atx_assets_loader import ATXAssetsLoader
from ..loaders.atx_data_operations_loader import ATXDataOperationsLoader
from ..loaders.path_resolver import PathResolver
from ..analysis.call_graph_analyzer import CallGraphAnalyzer
from ..analysis.complexity_calculator import ComplexityCalculator
from ..analysis.dependency_resolver import DependencyResolver


class FlowTransformer:
    """
    Transforms ATX data to legacy_analyzer flow format.
    
    Builds flows from entry points (TRANSACTION and JCL types) with:
    - Entry point structure with callers and resolved file paths (for JCL)
    - Scope (programs, copybooks, datasets) using transitive dependencies
    - Resolved local file paths for each program in scope
    - Data operations from program_to_dsn
    - Complexity metrics
    - Flow IDs and names
    """
    
    def __init__(
        self,
        dependency_loader: ATXDependencyLoader,
        assets_loader: ATXAssetsLoader,
        data_ops_loader: ATXDataOperationsLoader,
        path_resolver: PathResolver,
        call_graph: CallGraphAnalyzer,
        complexity_calc: ComplexityCalculator,
        config: TransformationConfig
    ):
        """
        Initialize with all required data sources.
        
        Args:
            dependency_loader: Loaded ATX dependency data
            assets_loader: Loaded ATX assets/metrics data
            data_ops_loader: Loaded ATX data operations
            path_resolver: Path resolver for mapping ATX paths to local paths
            call_graph: Built call graph analyzer
            complexity_calc: Complexity calculator
            config: Transformation configuration
        """
        if not dependency_loader.is_loaded():
            raise ValueError("ATXDependencyLoader must be loaded before transformation")
        if not assets_loader.is_loaded():
            raise ValueError("ATXAssetsLoader must be loaded before transformation")
        if not data_ops_loader.is_loaded():
            raise ValueError("ATXDataOperationsLoader must be loaded before transformation")
        if not call_graph.is_built():
            raise ValueError("CallGraphAnalyzer must be built before transformation")
        
        self.dependency_loader = dependency_loader
        self.assets_loader = assets_loader
        self.data_ops_loader = data_ops_loader
        self.path_resolver = path_resolver
        self.call_graph = call_graph
        self.complexity_calc = complexity_calc
        self.config = config
        
        # Cache for metrics lookup
        self._metrics_cache = assets_loader.get_all_metrics()
    
    def transform(self) -> List[Flow]:
        """
        Transform ATX data to flows.
        
        Creates flows from:
        - TRANSACTION types (CICS transactions) -> ONLINE flows
        - JCL types with "Exec program" -> BATCH flows
        
        Then resolves flow-to-flow dependencies.
        
        Returns:
            List of Flow objects with dependencies populated
        """
        flows = []
        
        # Transform TRANSACTION entries to flows
        transactions = self.dependency_loader.get_transactions()
        for transaction in transactions:
            flow = self._transform_transaction_to_flow(transaction)
            if flow:
                flows.append(flow)
        
        # Transform JCL entries to flows
        jcl_jobs = self.dependency_loader.get_jcl_jobs()
        for jcl in jcl_jobs:
            flow = self._transform_jcl_to_flow(jcl)
            if flow:
                flows.append(flow)
        
        # Resolve flow-to-flow dependencies
        self._resolve_flow_dependencies(flows)
        
        return flows
    
    def _transform_transaction_to_flow(self, transaction: ATXDependency) -> Optional[Flow]:
        """
        Transform a TRANSACTION entry to a flow.
        
        Args:
            transaction: ATX transaction dependency
            
        Returns:
            Flow object or None if no entry program found
        """
        # Find the entry program from dependencies
        entry_program = self._find_entry_program(transaction)
        if not entry_program:
            return None
        
        # Build entry point (no file path for CICS transactions)
        entry_point = self._build_entry_point(
            program=entry_program,
            entry_type="CICS_TRANSACTION",
            caller_source=transaction.name,
            caller_metadata={"transaction_id": transaction.name},
            caller_file_path=None  # CICS transactions don't have file paths
        )
        
        # Build scope with transitive dependencies
        scope = self._build_scope(entry_program)
        
        # Build data operations
        programs_in_scope = [p.name for p in scope.programs]
        data_operations = self._build_data_operations(programs_in_scope)
        
        # Calculate complexity
        complexity = self._calculate_complexity(programs_in_scope)
        
        # Generate flow ID and name
        flow_id = self._generate_flow_id(transaction.name, "TRANSACTION")
        flow_name = f"CICS Transaction: {transaction.name}"
        
        # Create flow
        flow = Flow(
            flow_id=flow_id,
            name=flow_name,
            entry_point=entry_point,
            scope=scope,
            interfaces={},
            data_operations=data_operations,
            complexity=complexity,
            dependencies=FlowDependencies(),  # Will be populated later
            invoked_by_jobs=[]
        )
        
        return flow
    
    def _transform_jcl_to_flow(self, jcl: ATXDependency) -> Optional[Flow]:
        """
        Transform a JCL entry to a flow.
        
        Args:
            jcl: ATX JCL dependency
            
        Returns:
            Flow object or None if no entry program found
        """
        # Find the entry program from "Exec program" dependencies
        entry_program = self._find_entry_program(jcl)
        if not entry_program:
            return None
        
        # Resolve JCL file path
        jcl_file_path = self.path_resolver.resolve_path(jcl.path) if jcl.path else None
        
        # Build entry point with resolved file path in metadata
        entry_point = self._build_entry_point(
            program=entry_program,
            entry_type="JCL",
            caller_source=jcl.name,
            caller_metadata={"jcl_name": jcl.name, "jobName": jcl.name},
            caller_file_path=jcl_file_path
        )
        
        # Build scope with transitive dependencies
        scope = self._build_scope(entry_program)
        
        # Build data operations
        programs_in_scope = [p.name for p in scope.programs]
        data_operations = self._build_data_operations(programs_in_scope)
        
        # Calculate complexity
        complexity = self._calculate_complexity(programs_in_scope)
        
        # Generate flow ID and name
        flow_id = self._generate_flow_id(jcl.name, "JCL")
        flow_name = f"JCL Job: {jcl.name}"
        
        # Create flow
        flow = Flow(
            flow_id=flow_id,
            name=flow_name,
            entry_point=entry_point,
            scope=scope,
            interfaces={},
            data_operations=data_operations,
            complexity=complexity,
            dependencies=FlowDependencies(),  # Will be populated later
            invoked_by_jobs=[]
        )
        
        return flow
    
    def _find_entry_program(self, entry_dep: ATXDependency) -> Optional[str]:
        """
        Find the entry program from a TRANSACTION or JCL dependency.
        
        Looks for:
        - "Start program" dependencies (CICS transactions)
        - "Exec program" dependencies (JCL)
        - "Call program" dependencies (fallback)
        
        Args:
            entry_dep: ATX dependency (TRANSACTION or JCL)
            
        Returns:
            Entry program name or None if not found
        """
        for dep in entry_dep.dependencies:
            dep_type = dep.get('dependencyType', '')
            
            # Check for entry program patterns
            if ('Start program' in dep_type or 
                'Exec program' in dep_type or
                'Call program' in dep_type):
                program_name = dep.get('name', '')
                if program_name:
                    return program_name
        
        return None
    
    def _build_entry_point(
        self,
        program: str,
        entry_type: str,
        caller_source: str,
        caller_metadata: Dict,
        caller_file_path: Optional[str] = None
    ) -> EntryPoint:
        """
        Build entry point structure from ATX data.
        
        Includes resolved file paths in JCL caller metadata.
        
        Args:
            program: Entry program name
            entry_type: Type of entry point (CICS_TRANSACTION, JCL, etc.)
            caller_source: Source that invokes this entry point
            caller_metadata: Additional metadata about the caller
            caller_file_path: Resolved local file path for JCL callers (optional)
            
        Returns:
            EntryPoint object
        """
        # Add file path to metadata if provided (for JCL callers)
        if caller_file_path:
            caller_metadata = caller_metadata.copy()
            caller_metadata["filePath"] = caller_file_path
        
        caller = Caller(source=caller_source, metadata=caller_metadata)
        entry_point_type = EntryPointType(type=entry_type, callers=[caller])
        
        entry_point = EntryPoint(
            program=program,
            types=[entry_point_type],
            primary_type=entry_type
        )
        
        return entry_point
    
    def _build_scope(self, entry_program: str) -> Scope:
        """
        Build scope (programs, copybooks, datasets) for a flow.
        
        Uses transitive dependencies from call graph to find all programs
        in the flow's scope, then extracts copybooks and datasets.
        Includes resolved file paths for each program in scope.
        
        Args:
            entry_program: Entry program name
            
        Returns:
            Scope object with programs, copybooks, and datasets
        """
        # Get all programs in scope (entry program + transitive dependencies)
        programs_in_scope = {entry_program}
        transitive_deps = self.call_graph.get_transitive_dependencies(entry_program)
        programs_in_scope.update(transitive_deps)
        
        # Build Program objects with utility flag and resolved file paths
        programs = []
        for prog_name in sorted(programs_in_scope):
            is_utility = self.config.is_utility_program(prog_name)
            
            # Get program dependency to access its path
            prog_dep = self.dependency_loader.get_by_name(prog_name)
            
            # Resolve file path if program dependency exists
            file_path = None
            if prog_dep and prog_dep.path:
                file_path = self.path_resolver.resolve_path(prog_dep.path)
            
            # Determine language from file extension or type
            language = self._determine_language(prog_dep) if prog_dep else "UNKNOWN"
            
            # Create Program object with file_path and language
            program = Program(
                name=prog_name,
                is_utility=is_utility,
                file_path=file_path,
                language=language
            )
            
            programs.append(program)
        
        # Collect copybooks from all programs in scope and resolve paths
        copybook_names = set()
        for prog_name in programs_in_scope:
            prog_copybooks = self.dependency_loader.get_copybooks(prog_name)
            copybook_names.update(prog_copybooks)
        
        # Build Copybook objects with resolved file paths
        copybooks = []
        for copybook_name in sorted(copybook_names):
            # Try to find copybook in dependencies to get its path
            copybook_dep = self.dependency_loader.get_by_name(copybook_name)
            
            # Resolve file path if copybook dependency exists
            file_path = None
            if copybook_dep and copybook_dep.path:
                file_path = self.path_resolver.resolve_path(copybook_dep.path)
            
            # If no path found, try common copybook extensions and search
            if not file_path:
                # Try common copybook file patterns
                for ext in ['.cpy', '.CPY', '.copy', '.COPY']:
                    # Remove extension if already present
                    base_name = copybook_name.rsplit('.', 1)[0] if '.' in copybook_name else copybook_name
                    search_name = f"{base_name}{ext}"
                    
                    # Search in common copybook directories
                    for search_dir in ['app/cpy', 'app/cpy-bms', 'cpy', 'copybooks']:
                        test_path = f"examples/code/cobol/carddemoV2/{search_dir}/{search_name}"
                        from pathlib import Path
                        if Path(test_path).exists():
                            file_path = test_path
                            break
                    
                    if file_path:
                        break
            
            # Create Copybook object
            from ..models.legacy_models import Copybook
            copybook = Copybook(
                name=copybook_name.rsplit('.', 1)[0] if '.' in copybook_name else copybook_name,
                file_path=file_path
            )
            
            copybooks.append(copybook)
        
        # Collect datasets from all programs in scope
        datasets = set()
        for prog_name in programs_in_scope:
            # Get datasets from dependencies
            prog_datasets = self.dependency_loader.get_datasets(prog_name)
            datasets.update(prog_datasets)
            
            # Get datasets from data operations
            data_ops_datasets = self.data_ops_loader.get_datasets_for_program(prog_name)
            datasets.update(data_ops_datasets)
        
        scope = Scope(
            programs=programs,
            copybooks=copybooks,
            datasets=sorted(datasets)
        )
        
        return scope
    
    def _determine_language(self, prog_dep: ATXDependency) -> str:
        """
        Determine programming language from program dependency.
        
        Args:
            prog_dep: ATX program dependency
            
        Returns:
            Language string (COBOL, PL/I, ASM, etc.)
        """
        if not prog_dep:
            return "UNKNOWN"
        
        # Check file extension
        if prog_dep.path:
            path_lower = prog_dep.path.lower()
            if path_lower.endswith('.cbl') or path_lower.endswith('.cob'):
                return "COBOL"
            elif path_lower.endswith('.pli') or path_lower.endswith('.pl1'):
                return "PL/I"
            elif path_lower.endswith('.asm') or path_lower.endswith('.s'):
                return "ASM"
            elif path_lower.endswith('.rex') or path_lower.endswith('.rexx'):
                return "REXX"
            elif path_lower.endswith('.jcl'):
                return "JCL"
            elif path_lower.endswith('.nat'):
                return "NATURAL"
            elif path_lower.endswith('.rpg'):
                return "RPG"
        
        # Check type field
        if prog_dep.type:
            type_upper = prog_dep.type.upper()
            if 'COB' in type_upper:
                return "COBOL"
            elif 'PLI' in type_upper or 'PL1' in type_upper:
                return "PL/I"
            elif 'ASM' in type_upper:
                return "ASM"
            elif 'REXX' in type_upper:
                return "REXX"
            elif 'JCL' in type_upper:
                return "JCL"
            elif 'NAT' in type_upper:
                return "NATURAL"
            elif 'RPG' in type_upper:
                return "RPG"
        
        return "UNKNOWN"
    
    def _build_data_operations(self, programs: List[str]) -> DataOperations:
        """
        Build data operations from program_to_dsn.json.
        
        Extracts all data operations (READ, WRITE, UPDATE) for programs
        in the flow's scope.
        
        Args:
            programs: List of program names in the flow's scope
            
        Returns:
            DataOperations object with databases and datasets
        """
        databases = []
        datasets = []
        
        for program in programs:
            operations = self.data_ops_loader.get_operations_for_program(program)
            
            for op in operations:
                access_types = op.get_access_types()
                
                # Create separate operations for each access type
                for access_type in access_types:
                    # Determine if it's a database or dataset operation
                    data_source_type = op.data_source_type or "UNKNOWN"
                    
                    if data_source_type in ["DB2", "IMS", "IDMS"]:
                        # Database operation
                        db_op = DatabaseOperation(
                            type=data_source_type,
                            operation=access_type,
                            target=op.data_source_name,
                            program=program
                        )
                        databases.append(db_op)
                    else:
                        # Dataset operation (VSAM, PS, etc.)
                        ds_op = DatasetOperation(
                            operation=access_type,
                            dataset=op.data_source_name,
                            program=program
                        )
                        datasets.append(ds_op)
        
        data_operations = DataOperations(
            databases=databases,
            datasets=datasets
        )
        
        return data_operations
    
    def _calculate_complexity(self, programs: List[str]) -> Complexity:
        """
        Calculate flow complexity metrics.
        
        Aggregates complexity across all programs in the flow.
        
        Args:
            programs: List of program names in the flow's scope
            
        Returns:
            Complexity object
        """
        complexity_data = self.complexity_calc.calculate_flow_complexity(
            programs=programs,
            metrics=self._metrics_cache
        )
        
        complexity = Complexity(
            total_programs=complexity_data["total_programs"],
            total_lines=complexity_data["total_lines"],
            cyclomatic_complexity=complexity_data["cyclomatic_complexity"],
            composite_score=complexity_data["composite_score"],
            tier=complexity_data["tier"]
        )
        
        return complexity
    
    def _generate_flow_id(self, source_name: str, source_type: str) -> str:
        """
        Generate flow ID from source name and type.
        
        Args:
            source_name: Name of the source (transaction ID, JCL name)
            source_type: Type of source (TRANSACTION, JCL)
            
        Returns:
            Flow ID string
        """
        # Clean source name (remove special characters, convert to uppercase)
        clean_name = source_name.replace('.', '_').replace('-', '_').upper()
        
        # Generate ID
        if source_type == "TRANSACTION":
            flow_id = f"FLOW_CICS_{clean_name}"
        elif source_type == "JCL":
            flow_id = f"FLOW_BATCH_{clean_name}"
        else:
            flow_id = f"FLOW_{clean_name}"
        
        return flow_id
    
    def _resolve_flow_dependencies(self, flows: List[Flow]) -> None:
        """
        Resolve flow-to-flow dependencies using DependencyResolver.
        
        Updates each flow's dependencies with requiredFlows and dependentFlows.
        
        Args:
            flows: List of Flow objects to update
        """
        # Create DependencyResolver
        resolver = DependencyResolver(self.call_graph)
        
        # Prepare flow data for resolver
        flow_data = []
        for flow in flows:
            flow_data.append({
                "flow_id": flow.flow_id,
                "name": flow.name,
                "programs": [p.name for p in flow.scope.programs]
            })
        
        # Resolve dependencies
        dependencies = resolver.resolve_flow_dependencies(flow_data)
        
        # Update flows with dependency information
        for flow in flows:
            if flow.flow_id in dependencies:
                dep_info = dependencies[flow.flow_id]
                flow.dependencies.required_flows = dep_info["required_flows"]
                flow.dependencies.dependent_flows = dep_info["dependent_flows"]

