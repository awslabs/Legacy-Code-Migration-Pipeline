"""
Entry Point Transformer

Transforms ATX data to legacy_analyzer entry point format.
Extracts CICS transactions, JCL entry points, and inferred entry points.
"""

from typing import List, Set, Optional
from ..models.atx_models import ATXDependency
from ..models.legacy_models import EntryPointRecord
from ..models.config_models import TransformationConfig
from ..loaders.atx_dependency_loader import ATXDependencyLoader
from ..analysis.call_graph_analyzer import CallGraphAnalyzer


class EntryPointTransformer:
    """Transforms ATX data to legacy_analyzer entry point format."""
    
    def __init__(
        self,
        dependency_loader: ATXDependencyLoader,
        call_graph: CallGraphAnalyzer,
        config: TransformationConfig
    ):
        """
        Initialize with dependency loader and call graph.
        
        Args:
            dependency_loader: Loader for ATX dependencies
            call_graph: Call graph analyzer for inferred entry points
            config: Transformation configuration
        """
        self.dependency_loader = dependency_loader
        self.call_graph = call_graph
        self.config = config
    
    def transform(self) -> List[EntryPointRecord]:
        """
        Transform ATX data to entry points.
        
        Returns:
            List of entry point records
        """
        entry_points = []
        seen_programs = set()
        
        # Extract CICS transactions as ONLINE entry points
        cics_entry_points = self._extract_cics_entry_points()
        for ep in cics_entry_points:
            entry_points.append(ep)
            seen_programs.add(ep.program_name)
        
        # Extract JCL entry points as BATCH entry points
        jcl_entry_points = self._extract_jcl_entry_points()
        for ep in jcl_entry_points:
            if ep.program_name not in seen_programs:
                entry_points.append(ep)
                seen_programs.add(ep.program_name)
        
        # Extract inferred entry points from call graph
        if self.config.transformation.include_inferred_entry_points:
            inferred_entry_points = self._extract_inferred_entry_points()
            for ep in inferred_entry_points:
                if ep.program_name not in seen_programs:
                    entry_points.append(ep)
                    seen_programs.add(ep.program_name)
        
        return entry_points
    
    def _extract_cics_entry_points(self) -> List[EntryPointRecord]:
        """
        Extract ONLINE entry points from TRANSACTION types.
        
        Returns:
            List of CICS transaction entry points
        """
        entry_points = []
        seen_programs = set()  # Track programs to avoid duplicates
        transactions = self.dependency_loader.get_transactions()
        
        for transaction in transactions:
            # Extract transaction ID from name or path
            transaction_id = self._extract_transaction_id(transaction)
            
            # Find all programs executed by this transaction
            programs = self._find_transaction_programs(transaction)
            
            for program_name in programs:
                if program_name not in seen_programs:
                    entry_point = EntryPointRecord(
                        program_name=program_name,
                        entry_type="ONLINE",
                        confidence="EXPLICIT",
                        source="CSD",
                        description=f"CICS Transaction {transaction_id}",
                        transaction_id=transaction_id,
                        jcl_name=None,
                        status="ENABLED"
                    )
                    entry_points.append(entry_point)
                    seen_programs.add(program_name)
        
        return entry_points
    
    def _extract_jcl_entry_points(self) -> List[EntryPointRecord]:
        """
        Extract BATCH entry points from JCL types.
        
        Returns:
            List of JCL entry points
        """
        entry_points = []
        seen_programs = set()  # Track programs to avoid duplicates
        jcl_jobs = self.dependency_loader.get_jcl_jobs()
        
        for jcl_job in jcl_jobs:
            # Extract JCL name from file name
            jcl_name = self._extract_jcl_name(jcl_job)
            
            # Find programs executed by this JCL
            programs = self._find_jcl_programs(jcl_job)
            
            for program_name in programs:
                if program_name not in seen_programs:
                    entry_point = EntryPointRecord(
                        program_name=program_name,
                        entry_type="BATCH",
                        confidence="EXPLICIT",
                        source="JCL",
                        description=f"JCL Job {jcl_name}",
                        transaction_id=None,
                        jcl_name=jcl_name,
                        status="ENABLED"
                    )
                    entry_points.append(entry_point)
                    seen_programs.add(program_name)
        
        return entry_points
    
    def _extract_inferred_entry_points(self) -> List[EntryPointRecord]:
        """
        Find programs with no callers (inferred entry points).
        
        Returns:
            List of inferred entry points
        """
        entry_points = []
        inferred_programs = self.call_graph.find_entry_points()
        
        for program_name in inferred_programs:
            entry_point = EntryPointRecord(
                program_name=program_name,
                entry_type="INFERRED",
                confidence="INFERRED",
                source="CODE_ANALYSIS",
                description="Program with no inbound calls",
                transaction_id=None,
                jcl_name=None,
                status=None
            )
            entry_points.append(entry_point)
        
        return entry_points
    
    def _extract_transaction_id(self, transaction: ATXDependency) -> str:
        """
        Extract transaction ID from transaction entry.
        
        Args:
            transaction: ATX transaction dependency
            
        Returns:
            Transaction ID
        """
        # Transaction ID is typically the name
        return transaction.name
    
    def _find_transaction_programs(self, transaction: ATXDependency) -> List[str]:
        """
        Find all programs executed by a CICS transaction.
        
        Args:
            transaction: ATX transaction dependency
            
        Returns:
            List of program names
        """
        programs = []
        
        # Look for "COB" dependencies (COBOL programs)
        for dep in transaction.dependencies:
            dep_type = dep.get("type", "")
            if dep_type == "COB":
                # Extract program name from file name (remove .cbl extension)
                program_file = dep.get("name", "")
                if program_file.endswith(".cbl"):
                    program_name = program_file[:-4]  # Remove .cbl
                else:
                    program_name = program_file
                
                if program_name:
                    programs.append(program_name)
        
        return programs
    
    def _extract_jcl_name(self, jcl_job: ATXDependency) -> str:
        """
        Extract JCL name from JCL entry.
        
        Args:
            jcl_job: ATX JCL dependency
            
        Returns:
            JCL name
        """
        # Extract name from file name (remove extension)
        name = jcl_job.name
        if "." in name:
            name = name.split(".")[0]
        return name
    
    def _find_jcl_programs(self, jcl_job: ATXDependency) -> List[str]:
        """
        Find programs executed by a JCL job.
        
        Args:
            jcl_job: ATX JCL dependency
            
        Returns:
            List of program names
        """
        programs = []
        
        # Look for "COB" dependencies (COBOL programs executed by JCL)
        for dep in jcl_job.dependencies:
            dep_type = dep.get("type", "")
            if dep_type == "COB":
                program_file = dep.get("name", "")
                if program_file:
                    # Extract program name from file name (remove extension)
                    if "." in program_file:
                        program_name = program_file.rsplit(".", 1)[0]
                    else:
                        program_name = program_file
                    programs.append(program_name)
        
        return programs
