"""
Job Transformer.

Transforms ATX JCL data to legacy_analyzer job format, including:
- Job extraction from JCL entries
- Job step extraction from "Exec program" dependencies
- Dataset extraction from "Dataset use" dependencies
- Job type classification (APPLICATION vs INFRASTRUCTURE)
- Custom code detection
"""

from typing import List, Optional
from pathlib import Path
from ..models.atx_models import ATXDependency
from ..models.legacy_models import Job, JobStep, JobDependencies
from ..models.config_models import TransformationConfig
from ..loaders.atx_dependency_loader import ATXDependencyLoader


class JobTransformer:
    """
    Transforms ATX JCL data to legacy_analyzer job format.
    
    Extracts jobs from ATX dependencies.json, including:
    - Job name from JCL file name
    - Job steps from "Exec program" dependencies
    - Datasets from "Dataset use" dependencies
    - Job type classification based on program types
    - Custom code detection
    """
    
    def __init__(
        self,
        dependency_loader: ATXDependencyLoader,
        config: TransformationConfig
    ):
        """
        Initialize the job transformer.
        
        Args:
            dependency_loader: Loaded ATX dependency data
            config: Transformation configuration
        """
        self.dependency_loader = dependency_loader
        self.config = config
    
    def transform(self) -> List[Job]:
        """
        Transform ATX JCL entries to jobs.
        
        Returns:
            List of Job objects
        """
        jobs = []
        
        # Get all JCL entries
        jcl_entries = self.dependency_loader.get_jcl_jobs()
        
        for jcl_entry in jcl_entries:
            job = self._transform_jcl_to_job(jcl_entry)
            if job:
                jobs.append(job)
        
        return jobs
    
    def _transform_jcl_to_job(self, jcl_entry: ATXDependency) -> Optional[Job]:
        """
        Transform a single JCL entry to a Job.
        
        Args:
            jcl_entry: ATX JCL dependency entry
            
        Returns:
            Job object or None if transformation fails
        """
        # Extract job name from file name (remove extension)
        job_name = self._extract_job_name(jcl_entry.name)
        
        # Extract job steps
        steps = self._extract_steps(jcl_entry)
        
        # Extract datasets
        datasets = self._extract_datasets(jcl_entry)
        
        # Get all programs executed in this job
        programs = [step.program for step in steps]
        
        # Classify job type
        job_type = self._classify_job_type(programs)
        
        # Determine if job has custom code
        has_custom_code = self._determine_has_custom_code(programs)
        
        # Create job
        job = Job(
            job_name=job_name,
            job_type=job_type,
            has_custom_code=has_custom_code,
            linked_flow=None,  # Will be set later if needed
            steps=steps,
            datasets=datasets,
            dependencies=JobDependencies()  # Will be computed later if needed
        )
        
        return job
    
    def _extract_job_name(self, jcl_file_name: str) -> str:
        """
        Extract job name from JCL file name.
        
        Args:
            jcl_file_name: JCL file name (e.g., "MYJOB.jcl" or "MYJOB")
            
        Returns:
            Job name without extension
        """
        # Remove file extension if present
        name = Path(jcl_file_name).stem
        
        # If no extension was removed, use the original name
        if not name:
            name = jcl_file_name
        
        return name
    
    def _extract_steps(self, jcl_entry: ATXDependency) -> List[JobStep]:
        """
        Extract job steps from "Exec program" dependencies.
        
        Args:
            jcl_entry: ATX JCL dependency entry
            
        Returns:
            List of JobStep objects
        """
        steps = []
        step_counter = 1
        
        for dependency in jcl_entry.dependencies:
            dep_type = dependency.get('dependencyType', '')
            
            # Check for "Exec program" pattern
            if 'Exec program' in dep_type or 'exec program' in dep_type.lower():
                program_name = dependency.get('name', '')
                
                if program_name:
                    # Determine if this is a utility or custom program
                    is_utility = self.config.is_utility_program(program_name)
                    step_type = "UTILITY" if is_utility else "CUSTOM"
                    
                    # Create step name (STEP001, STEP002, etc.)
                    step_name = f"STEP{step_counter:03d}"
                    
                    step = JobStep(
                        step_name=step_name,
                        program=program_name,
                        type=step_type,
                        purpose="",  # Could be enhanced with metadata
                        flow_entry=False  # Will be set later if needed
                    )
                    
                    steps.append(step)
                    step_counter += 1
        
        return steps
    
    def _extract_datasets(self, jcl_entry: ATXDependency) -> List[str]:
        """
        Extract datasets from "Dataset use" dependencies.
        
        Args:
            jcl_entry: ATX JCL dependency entry
            
        Returns:
            List of dataset names
        """
        datasets = []
        
        for dependency in jcl_entry.dependencies:
            dep_type = dependency.get('dependencyType', '')
            name = dependency.get('name', '')
            dep_obj_type = dependency.get('type', '')
            
            # Check for dataset patterns
            if ('Dataset use' in dep_type or 'dataset' in dep_type.lower() or
                'DATASET' in dep_obj_type or 'VSAM' in dep_obj_type or
                'PS' in dep_obj_type or 'PDS' in dep_obj_type):
                if name and name not in datasets:
                    datasets.append(name)
        
        return datasets
    
    def _classify_job_type(self, programs: List[str]) -> str:
        """
        Classify job as APPLICATION or INFRASTRUCTURE.
        
        A job is classified as INFRASTRUCTURE if all executed programs
        are utility programs. Otherwise, it's APPLICATION.
        
        Args:
            programs: List of program names executed in the job
            
        Returns:
            "APPLICATION" or "INFRASTRUCTURE"
        """
        if not programs:
            # Empty job defaults to INFRASTRUCTURE
            return "INFRASTRUCTURE"
        
        # Check if all programs are utilities
        all_utilities = all(
            self.config.is_utility_program(program)
            for program in programs
        )
        
        return "INFRASTRUCTURE" if all_utilities else "APPLICATION"
    
    def _determine_has_custom_code(self, programs: List[str]) -> bool:
        """
        Determine if job executes custom code.
        
        A job has custom code if at least one executed program is not
        a utility program.
        
        Args:
            programs: List of program names executed in the job
            
        Returns:
            True if job has custom code, False otherwise
        """
        if not programs:
            return False
        
        # Check if any program is not a utility
        return any(
            not self.config.is_utility_program(program)
            for program in programs
        )
