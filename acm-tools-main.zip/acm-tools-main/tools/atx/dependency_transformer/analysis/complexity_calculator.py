"""
Complexity Calculator.

Calculates complexity metrics using legacy_analyzer formulas.
Provides composite score calculation, tier assignment, and flow complexity aggregation.
"""

from typing import Dict, List
from ..models.config_models import ComplexityConfig
from ..models.atx_models import ATXAssetMetrics


class ComplexityCalculator:
    """
    Calculates complexity metrics using legacy_analyzer formulas.
    
    Provides:
    - Composite score calculation with configurable weights
    - Tier assignment with configurable thresholds
    - Flow complexity aggregation
    """
    
    def __init__(self, config: ComplexityConfig = None):
        """
        Initialize with complexity formula configuration.
        
        Args:
            config: ComplexityConfig with formula weights and tier thresholds.
                   If None, uses default configuration.
        """
        if config is None:
            config = ComplexityConfig()
        
        self.config = config
        self._cc_weight = config.formula.cc_weight
        self._loc_weight = config.formula.loc_weight
        self._low_threshold = config.tiers.low_threshold
        self._medium_threshold = config.tiers.medium_threshold
    
    def calculate_composite_score(self, cc: int, loc: int) -> float:
        """
        Calculate composite complexity score.
        
        Formula: (CC × cc_weight) + (LOC / 100 × loc_weight)
        Default weights: CC=0.3, LOC=0.7
        
        Args:
            cc: Cyclomatic complexity
            loc: Lines of code
            
        Returns:
            Composite complexity score
        """
        if cc < 0:
            raise ValueError(f"Cyclomatic complexity must be non-negative, got {cc}")
        if loc < 0:
            raise ValueError(f"Lines of code must be non-negative, got {loc}")
        
        score = (cc * self._cc_weight) + (loc / 100.0 * self._loc_weight)
        return score
    
    def assign_tier(self, composite_score: float) -> str:
        """
        Assign complexity tier (LOW/MEDIUM/HIGH).
        
        Thresholds:
        - LOW: score < low_threshold (default: 10)
        - MEDIUM: low_threshold <= score < medium_threshold (default: 20)
        - HIGH: score >= medium_threshold
        
        Args:
            composite_score: Composite complexity score
            
        Returns:
            Tier string: "LOW", "MEDIUM", or "HIGH"
        """
        if composite_score < 0:
            raise ValueError(f"Composite score must be non-negative, got {composite_score}")
        
        if composite_score < self._low_threshold:
            return "LOW"
        elif composite_score < self._medium_threshold:
            return "MEDIUM"
        else:
            return "HIGH"
    
    def calculate_flow_complexity(
        self,
        programs: List[str],
        metrics: Dict[str, ATXAssetMetrics],
        warn_on_missing: bool = True
    ) -> Dict[str, any]:
        """
        Calculate aggregate complexity for a flow.
        
        Aggregates metrics across all programs in the flow and calculates
        composite score and tier.
        
        Args:
            programs: List of program names in the flow
            metrics: Dictionary mapping program names to ATXAssetMetrics
            warn_on_missing: If True, print warnings for programs with missing metrics
            
        Returns:
            Dictionary with complexity metrics:
            {
                "total_programs": int,
                "total_lines": int,
                "cyclomatic_complexity": int,
                "composite_score": float,
                "tier": str,
                "programs_with_metrics": int,
                "programs_without_metrics": List[str]
            }
        """
        if not programs:
            # Empty flow
            return {
                "total_programs": 0,
                "total_lines": 0,
                "cyclomatic_complexity": 0,
                "composite_score": 0.0,
                "tier": "LOW",
                "programs_with_metrics": 0,
                "programs_without_metrics": []
            }
        
        total_cc = 0
        total_loc = 0
        programs_with_metrics = 0
        programs_without_metrics = []
        
        for program in programs:
            if program in metrics:
                metric = metrics[program]
                total_cc += metric.cyclomatic_complexity
                total_loc += metric.total_lines
                programs_with_metrics += 1
            else:
                programs_without_metrics.append(program)
        
        # Warn about missing metrics
        if warn_on_missing and programs_without_metrics:
            print(f"Warning: Missing metrics for {len(programs_without_metrics)} program(s): "
                  f"{', '.join(programs_without_metrics[:5])}"
                  f"{' and ' + str(len(programs_without_metrics) - 5) + ' more' if len(programs_without_metrics) > 5 else ''}")
        
        # Calculate composite score
        composite_score = self.calculate_composite_score(total_cc, total_loc)
        tier = self.assign_tier(composite_score)
        
        return {
            "total_programs": len(programs),
            "total_lines": total_loc,
            "cyclomatic_complexity": total_cc,
            "composite_score": composite_score,
            "tier": tier,
            "programs_with_metrics": programs_with_metrics,
            "programs_without_metrics": programs_without_metrics
        }
    
    def calculate_program_complexity(
        self,
        program_name: str,
        metrics: Dict[str, ATXAssetMetrics]
    ) -> Dict[str, any]:
        """
        Calculate complexity for a single program.
        
        Args:
            program_name: Name of the program
            metrics: Dictionary mapping program names to ATXAssetMetrics
            
        Returns:
            Dictionary with complexity metrics:
            {
                "cyclomatic_complexity": int,
                "total_lines": int,
                "composite_score": float,
                "tier": str,
                "has_metrics": bool
            }
        """
        if program_name not in metrics:
            # No metrics available
            return {
                "cyclomatic_complexity": 0,
                "total_lines": 0,
                "composite_score": 0.0,
                "tier": "LOW",
                "has_metrics": False
            }
        
        metric = metrics[program_name]
        composite_score = self.calculate_composite_score(
            metric.cyclomatic_complexity,
            metric.total_lines
        )
        tier = self.assign_tier(composite_score)
        
        return {
            "cyclomatic_complexity": metric.cyclomatic_complexity,
            "total_lines": metric.total_lines,
            "composite_score": composite_score,
            "tier": tier,
            "has_metrics": True
        }
    
    def get_config(self) -> ComplexityConfig:
        """
        Get the current configuration.
        
        Returns:
            ComplexityConfig instance
        """
        return self.config
    
    def update_config(self, config: ComplexityConfig):
        """
        Update the configuration.
        
        Args:
            config: New ComplexityConfig instance
        """
        self.config = config
        self._cc_weight = config.formula.cc_weight
        self._loc_weight = config.formula.loc_weight
        self._low_threshold = config.tiers.low_threshold
        self._medium_threshold = config.tiers.medium_threshold
