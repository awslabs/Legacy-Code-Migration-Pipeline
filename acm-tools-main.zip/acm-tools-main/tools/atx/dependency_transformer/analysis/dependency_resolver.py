"""
Dependency Resolver.

Resolves dependencies between flows based on program call relationships.
Identifies required flows and dependent flows for migration planning.
"""

from typing import Dict, List, Set
from .call_graph_analyzer import CallGraphAnalyzer


class DependencyResolver:
    """
    Resolves dependencies between flows.
    
    Provides:
    - Flow-to-flow dependency resolution
    - Required flows identification (flows that must be migrated first)
    - Dependent flows identification (flows that depend on this flow)
    """
    
    def __init__(self, call_graph: CallGraphAnalyzer):
        """
        Initialize with a call graph analyzer.
        
        Args:
            call_graph: CallGraphAnalyzer instance with built call graph
        """
        if not call_graph.is_built():
            raise ValueError("Call graph must be built before creating DependencyResolver")
        
        self.call_graph = call_graph
    
    def resolve_flow_dependencies(
        self,
        flows: List[Dict[str, any]]
    ) -> Dict[str, Dict[str, List[str]]]:
        """
        Determine which flows require/depend on other flows.
        
        A flow F1 requires flow F2 if any program in F1's scope calls
        any program in F2's scope (and F2 is a different flow).
        
        Args:
            flows: List of flow dictionaries, each containing:
                   - "flow_id": unique flow identifier
                   - "name": flow name
                   - "programs": list of program names in the flow's scope
                   
        Returns:
            Dictionary mapping flow_id to dependency information:
            {
                "flow_id": {
                    "required_flows": [list of flow_ids that must be migrated first],
                    "dependent_flows": [list of flow_ids that depend on this flow]
                }
            }
        """
        # Build index of program to flow mapping
        program_to_flow = {}
        for flow in flows:
            flow_id = flow.get("flow_id", "")
            programs = flow.get("programs", [])
            for program in programs:
                if program not in program_to_flow:
                    program_to_flow[program] = []
                program_to_flow[program].append(flow_id)
        
        # Initialize result structure
        dependencies = {}
        for flow in flows:
            flow_id = flow.get("flow_id", "")
            dependencies[flow_id] = {
                "required_flows": [],
                "dependent_flows": []
            }
        
        # Compute dependencies
        for flow in flows:
            flow_id = flow.get("flow_id", "")
            programs = flow.get("programs", [])
            
            # Find required flows (flows this flow depends on)
            required_flow_ids = self.identify_required_flows(
                flow_id, programs, program_to_flow
            )
            dependencies[flow_id]["required_flows"] = sorted(required_flow_ids)
            
            # Update dependent flows (flows that depend on this flow)
            for required_flow_id in required_flow_ids:
                if required_flow_id in dependencies:
                    if flow_id not in dependencies[required_flow_id]["dependent_flows"]:
                        dependencies[required_flow_id]["dependent_flows"].append(flow_id)
        
        # Sort dependent flows for deterministic output
        for flow_id in dependencies:
            dependencies[flow_id]["dependent_flows"] = sorted(
                dependencies[flow_id]["dependent_flows"]
            )
        
        return dependencies
    
    def identify_required_flows(
        self,
        flow_id: str,
        programs: List[str],
        program_to_flow: Dict[str, List[str]]
    ) -> List[str]:
        """
        Identify flows that must be migrated before this flow.
        
        A flow is required if any program in the current flow's scope
        calls a program that is the entry point of another flow.
        
        Args:
            flow_id: ID of the current flow
            programs: List of program names in the current flow's scope
            program_to_flow: Mapping of program names to flow IDs
            
        Returns:
            List of flow IDs that are required by this flow
        """
        required_flows = set()
        
        # For each program in this flow's scope
        for program in programs:
            # Get all programs this program calls (direct and transitive)
            called_programs = self.call_graph.get_direct_callees(program)
            
            # Check if any called program belongs to a different flow
            for called_program in called_programs:
                if called_program in program_to_flow:
                    # Get flows that contain this called program
                    containing_flows = program_to_flow[called_program]
                    for containing_flow in containing_flows:
                        # Only add if it's a different flow
                        if containing_flow != flow_id:
                            required_flows.add(containing_flow)
        
        return list(required_flows)
    
    def identify_dependent_flows(
        self,
        flow_id: str,
        all_flows: List[Dict[str, any]]
    ) -> List[str]:
        """
        Identify flows that depend on this flow.
        
        A flow F2 depends on this flow F1 if any program in F2's scope
        calls any program in F1's scope.
        
        Args:
            flow_id: ID of the current flow
            all_flows: List of all flow dictionaries
            
        Returns:
            List of flow IDs that depend on this flow
        """
        # Find the current flow
        current_flow = None
        for flow in all_flows:
            if flow.get("flow_id") == flow_id:
                current_flow = flow
                break
        
        if current_flow is None:
            return []
        
        current_programs = set(current_flow.get("programs", []))
        dependent_flows = []
        
        # Check each other flow
        for flow in all_flows:
            other_flow_id = flow.get("flow_id", "")
            if other_flow_id == flow_id:
                continue  # Skip self
            
            other_programs = flow.get("programs", [])
            
            # Check if any program in the other flow calls any program in current flow
            for other_program in other_programs:
                called_programs = self.call_graph.get_direct_callees(other_program)
                
                # Check if any called program is in current flow
                if any(called in current_programs for called in called_programs):
                    dependent_flows.append(other_flow_id)
                    break  # Found dependency, no need to check more programs
        
        return sorted(dependent_flows)
    
    def get_migration_order(
        self,
        flows: List[Dict[str, any]]
    ) -> List[List[str]]:
        """
        Compute a migration order for flows based on dependencies.
        
        Returns flows grouped by migration wave, where each wave contains
        flows that can be migrated in parallel (no dependencies between them).
        
        Args:
            flows: List of flow dictionaries
            
        Returns:
            List of waves, where each wave is a list of flow IDs that can
            be migrated together
        """
        # Get dependencies
        dependencies = self.resolve_flow_dependencies(flows)
        
        # Track which flows have been scheduled
        scheduled = set()
        waves = []
        
        # Keep adding waves until all flows are scheduled
        while len(scheduled) < len(flows):
            current_wave = []
            
            # Find flows that can be scheduled in this wave
            for flow in flows:
                flow_id = flow.get("flow_id", "")
                
                # Skip if already scheduled
                if flow_id in scheduled:
                    continue
                
                # Check if all required flows are already scheduled
                required_flows = dependencies[flow_id]["required_flows"]
                if all(req in scheduled for req in required_flows):
                    current_wave.append(flow_id)
            
            # If no flows can be scheduled, we have a circular dependency
            if not current_wave:
                # Add remaining flows to a final wave
                remaining = [f.get("flow_id") for f in flows if f.get("flow_id") not in scheduled]
                if remaining:
                    waves.append(sorted(remaining))
                break
            
            # Add this wave and mark flows as scheduled
            waves.append(sorted(current_wave))
            scheduled.update(current_wave)
        
        return waves
    
    def has_circular_dependencies(
        self,
        flows: List[Dict[str, any]]
    ) -> bool:
        """
        Check if there are circular dependencies between flows.
        
        Args:
            flows: List of flow dictionaries
            
        Returns:
            True if circular dependencies exist
        """
        dependencies = self.resolve_flow_dependencies(flows)
        
        # Use DFS to detect cycles
        visited = set()
        rec_stack = set()
        
        def has_cycle(flow_id: str) -> bool:
            """DFS helper to detect cycles."""
            visited.add(flow_id)
            rec_stack.add(flow_id)
            
            # Check all required flows
            for required_flow in dependencies[flow_id]["required_flows"]:
                if required_flow not in visited:
                    if has_cycle(required_flow):
                        return True
                elif required_flow in rec_stack:
                    return True
            
            rec_stack.remove(flow_id)
            return False
        
        # Check each flow
        for flow in flows:
            flow_id = flow.get("flow_id", "")
            if flow_id not in visited:
                if has_cycle(flow_id):
                    return True
        
        return False
    
    def get_independent_flows(
        self,
        flows: List[Dict[str, any]]
    ) -> List[str]:
        """
        Get flows that have no dependencies (can be migrated first).
        
        Args:
            flows: List of flow dictionaries
            
        Returns:
            List of flow IDs with no required flows
        """
        dependencies = self.resolve_flow_dependencies(flows)
        
        independent = []
        for flow in flows:
            flow_id = flow.get("flow_id", "")
            if not dependencies[flow_id]["required_flows"]:
                independent.append(flow_id)
        
        return sorted(independent)
