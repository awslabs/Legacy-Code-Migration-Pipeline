"""
Call Graph Analyzer.

Builds and analyzes program call graphs from ATX dependencies.
Provides transitive dependency calculation, entry point detection,
and circular dependency detection.
"""

from typing import Dict, Set, List, Optional, Tuple
from collections import defaultdict, deque


class CallGraphAnalyzer:
    """
    Builds and analyzes program call graphs.
    
    Provides:
    - Directed graph construction from program calls
    - Transitive dependency calculation with memoization
    - Entry point detection (programs with no inbound calls)
    - Circular dependency detection
    """
    
    def __init__(self):
        """Initialize the analyzer."""
        self._call_graph: Dict[str, Set[str]] = defaultdict(set)
        self._reverse_graph: Dict[str, Set[str]] = defaultdict(set)
        self._transitive_cache: Dict[str, Set[str]] = {}
        self._all_programs: Set[str] = set()
        self._built = False
    
    def build_call_graph(self, program_calls: Dict[str, List[str]]) -> None:
        """
        Build directed graph of program calls.
        
        Args:
            program_calls: Dictionary mapping program names to lists of called programs
                          (e.g., {"PROG1": ["PROG2", "PROG3"], "PROG2": ["PROG4"]})
        """
        self._call_graph.clear()
        self._reverse_graph.clear()
        self._transitive_cache.clear()
        self._all_programs.clear()
        
        # Build forward and reverse graphs
        for caller, callees in program_calls.items():
            self._all_programs.add(caller)
            
            for callee in callees:
                self._all_programs.add(callee)
                self._call_graph[caller].add(callee)
                self._reverse_graph[callee].add(caller)
        
        # Ensure all programs are in the graph (even if they have no calls)
        for program in self._all_programs:
            if program not in self._call_graph:
                self._call_graph[program] = set()
            if program not in self._reverse_graph:
                self._reverse_graph[program] = set()
        
        self._built = True
    
    def get_transitive_dependencies(self, program_name: str) -> Set[str]:
        """
        Get all programs transitively called by the given program.
        
        Uses memoization to avoid recomputation. Performs depth-first
        traversal of the call graph.
        
        Args:
            program_name: Name of the program
            
        Returns:
            Set of all programs transitively called (excluding the program itself)
        """
        if not self._built:
            raise RuntimeError("Call graph not built. Call build_call_graph() first.")
        
        if program_name not in self._all_programs:
            return set()
        
        # Check cache
        if program_name in self._transitive_cache:
            return self._transitive_cache[program_name].copy()
        
        # Compute transitive closure using DFS
        visited = set()
        stack = [program_name]
        
        while stack:
            current = stack.pop()
            
            if current in visited:
                continue
            
            visited.add(current)
            
            # Add all direct callees to stack
            for callee in self._call_graph.get(current, set()):
                if callee not in visited:
                    stack.append(callee)
        
        # Remove the program itself from the result
        visited.discard(program_name)
        
        # Cache the result
        self._transitive_cache[program_name] = visited.copy()
        
        return visited
    
    def find_entry_points(self) -> List[str]:
        """
        Find programs with no inbound calls (inferred entry points).
        
        These are programs that are never called by other programs in the
        call graph, suggesting they might be entry points.
        
        Returns:
            List of program names with no inbound calls
        """
        if not self._built:
            raise RuntimeError("Call graph not built. Call build_call_graph() first.")
        
        entry_points = []
        
        for program in self._all_programs:
            # Check if program has no inbound calls
            if not self._reverse_graph.get(program, set()):
                entry_points.append(program)
        
        return sorted(entry_points)
    
    def detect_circular_dependencies(self) -> List[List[str]]:
        """
        Detect circular dependency chains.
        
        Uses Tarjan's algorithm to find strongly connected components (SCCs).
        Returns only SCCs with more than one node (actual cycles).
        
        Returns:
            List of circular dependency chains, where each chain is a list of program names
        """
        if not self._built:
            raise RuntimeError("Call graph not built. Call build_call_graph() first.")
        
        # Tarjan's algorithm for finding SCCs
        index_counter = [0]
        stack = []
        lowlinks = {}
        index = {}
        on_stack = defaultdict(bool)
        sccs = []
        
        def strongconnect(node: str):
            """Recursive helper for Tarjan's algorithm."""
            index[node] = index_counter[0]
            lowlinks[node] = index_counter[0]
            index_counter[0] += 1
            stack.append(node)
            on_stack[node] = True
            
            # Consider successors
            for successor in self._call_graph.get(node, set()):
                if successor not in index:
                    # Successor has not yet been visited
                    strongconnect(successor)
                    lowlinks[node] = min(lowlinks[node], lowlinks[successor])
                elif on_stack[successor]:
                    # Successor is on stack and hence in the current SCC
                    lowlinks[node] = min(lowlinks[node], index[successor])
            
            # If node is a root node, pop the stack and generate an SCC
            if lowlinks[node] == index[node]:
                scc = []
                while True:
                    successor = stack.pop()
                    on_stack[successor] = False
                    scc.append(successor)
                    if successor == node:
                        break
                sccs.append(scc)
        
        # Run Tarjan's algorithm on all nodes
        for node in self._all_programs:
            if node not in index:
                strongconnect(node)
        
        # Filter out single-node SCCs (not cycles)
        cycles = [scc for scc in sccs if len(scc) > 1]
        
        # Sort each cycle and sort the list of cycles for deterministic output
        cycles = [sorted(cycle) for cycle in cycles]
        cycles.sort()
        
        # Log warnings for detected cycles
        if cycles:
            print(f"Warning: Detected {len(cycles)} circular dependency chain(s):")
            for idx, cycle in enumerate(cycles, 1):
                cycle_str = " -> ".join(cycle) + f" -> {cycle[0]}"
                print(f"  Cycle {idx}: {cycle_str}")
        
        return cycles
    
    def get_direct_callees(self, program_name: str) -> Set[str]:
        """
        Get programs directly called by the given program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            Set of directly called program names
        """
        if not self._built:
            raise RuntimeError("Call graph not built. Call build_call_graph() first.")
        
        return self._call_graph.get(program_name, set()).copy()
    
    def get_direct_callers(self, program_name: str) -> Set[str]:
        """
        Get programs that directly call the given program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            Set of caller program names
        """
        if not self._built:
            raise RuntimeError("Call graph not built. Call build_call_graph() first.")
        
        return self._reverse_graph.get(program_name, set()).copy()
    
    def has_path(self, from_program: str, to_program: str) -> bool:
        """
        Check if there is a path from one program to another.
        
        Args:
            from_program: Source program name
            to_program: Target program name
            
        Returns:
            True if there is a path from from_program to to_program
        """
        if not self._built:
            raise RuntimeError("Call graph not built. Call build_call_graph() first.")
        
        if from_program not in self._all_programs or to_program not in self._all_programs:
            return False
        
        transitive_deps = self.get_transitive_dependencies(from_program)
        return to_program in transitive_deps
    
    def get_all_programs(self) -> Set[str]:
        """
        Get all programs in the call graph.
        
        Returns:
            Set of all program names
        """
        return self._all_programs.copy()
    
    def is_built(self) -> bool:
        """
        Check if the call graph has been built.
        
        Returns:
            True if build_call_graph() has been called
        """
        return self._built
    
    def get_call_depth(self, program_name: str) -> int:
        """
        Get the maximum call depth from the given program.
        
        Uses BFS to find the longest path in the call graph.
        
        Args:
            program_name: Name of the program
            
        Returns:
            Maximum call depth (0 if program calls nothing)
        """
        if not self._built:
            raise RuntimeError("Call graph not built. Call build_call_graph() first.")
        
        if program_name not in self._all_programs:
            return 0
        
        # BFS to find maximum depth
        queue = deque([(program_name, 0)])
        visited = {program_name}
        max_depth = 0
        
        while queue:
            current, depth = queue.popleft()
            max_depth = max(max_depth, depth)
            
            for callee in self._call_graph.get(current, set()):
                if callee not in visited:
                    visited.add(callee)
                    queue.append((callee, depth + 1))
        
        return max_depth
