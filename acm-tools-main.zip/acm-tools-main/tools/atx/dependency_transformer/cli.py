"""
Command-line interface for ATX Dependency Transformer.

Provides commands for transforming ATX tool outputs to legacy_analyzer format.
"""

import argparse
import sys
from pathlib import Path
from typing import Optional

from .orchestration.transformation_orchestrator import TransformationOrchestrator
from .orchestration.configuration_manager import ConfigurationManager
from .models.config_models import TransformationReport


def print_report(report: TransformationReport, verbose: bool = False):
    """
    Print transformation report to console.
    
    Args:
        report: Transformation report to print
        verbose: If True, print detailed information
    """
    print("\n" + "=" * 70)
    print("TRANSFORMATION REPORT")
    print("=" * 70)
    
    # Status
    status = "SUCCESS" if report.success else "FAILED"
    status_symbol = "✓" if report.success else "✗"
    print(f"\nStatus: {status_symbol} {status}")
    
    if report.dry_run:
        print("Mode: DRY RUN (no files written)")
    
    # Statistics
    print(f"\nStatistics:")
    print(f"  Flows generated:        {report.flows_generated}")
    print(f"  Jobs generated:         {report.jobs_generated}")
    print(f"  Entry points generated: {report.entry_points_generated}")
    print(f"  Programs processed:     {report.programs_processed}")
    print(f"  Execution time:         {report.execution_time_seconds:.2f}s")
    
    # Warnings
    if report.warnings:
        print(f"\nWarnings ({len(report.warnings)}):")
        for warning in report.warnings:
            print(f"  [{warning.category}] {warning.message}")
            if verbose and warning.context:
                for key, value in warning.context.items():
                    print(f"    {key}: {value}")
    
    # Errors
    if report.errors:
        print(f"\nErrors ({len(report.errors)}):")
        for error in report.errors:
            fatal_marker = " (FATAL)" if error.fatal else ""
            print(f"  [{error.category}]{fatal_marker} {error.message}")
            if verbose and error.context:
                for key, value in error.context.items():
                    print(f"    {key}: {value}")
    
    print("\n" + "=" * 70 + "\n")


def transform_all_command(args):
    """Execute transform all command."""
    if args.verbose:
        print(f"Loading configuration from: {args.config or 'defaults'}")
    
    # Load configuration
    if args.config:
        config_manager = ConfigurationManager(args.config)
        config = config_manager.load()
    else:
        config_manager = ConfigurationManager()
        config = config_manager.get_default_config()
    
    if args.verbose:
        print(f"Input directory:  {args.input_dir}")
        print(f"Output directory: {args.output_dir}")
        print(f"Dry run:          {args.dry_run}")
        print("\nStarting transformation...")
    
    # Create orchestrator and run transformation
    orchestrator = TransformationOrchestrator(config)
    report = orchestrator.transform_all(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        dry_run=args.dry_run
    )
    
    # Print report
    print_report(report, verbose=args.verbose)
    
    # Exit with appropriate code
    sys.exit(0 if report.success else 1)


def transform_flows_command(args):
    """Execute transform flows command."""
    if args.verbose:
        print(f"Loading configuration from: {args.config or 'defaults'}")
    
    # Load configuration
    if args.config:
        config_manager = ConfigurationManager(args.config)
        config = config_manager.load()
    else:
        config_manager = ConfigurationManager()
        config = config_manager.get_default_config()
    
    if args.verbose:
        print(f"Input directory:  {args.input_dir}")
        print(f"Output directory: {args.output_dir}")
        print(f"Dry run:          {args.dry_run}")
        print("\nStarting flow transformation...")
    
    # Create orchestrator and run transformation
    orchestrator = TransformationOrchestrator(config)
    report = orchestrator.transform_flows(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        dry_run=args.dry_run
    )
    
    # Print report
    print_report(report, verbose=args.verbose)
    
    # Exit with appropriate code
    sys.exit(0 if report.success else 1)


def transform_jobs_command(args):
    """Execute transform jobs command."""
    if args.verbose:
        print(f"Loading configuration from: {args.config or 'defaults'}")
    
    # Load configuration
    if args.config:
        config_manager = ConfigurationManager(args.config)
        config = config_manager.load()
    else:
        config_manager = ConfigurationManager()
        config = config_manager.get_default_config()
    
    if args.verbose:
        print(f"Input directory:  {args.input_dir}")
        print(f"Output directory: {args.output_dir}")
        print(f"Dry run:          {args.dry_run}")
        print("\nStarting job transformation...")
    
    # Create orchestrator and run transformation
    orchestrator = TransformationOrchestrator(config)
    report = orchestrator.transform_jobs(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        dry_run=args.dry_run
    )
    
    # Print report
    print_report(report, verbose=args.verbose)
    
    # Exit with appropriate code
    sys.exit(0 if report.success else 1)


def transform_entry_points_command(args):
    """Execute transform entry-points command."""
    if args.verbose:
        print(f"Loading configuration from: {args.config or 'defaults'}")
    
    # Load configuration
    if args.config:
        config_manager = ConfigurationManager(args.config)
        config = config_manager.load()
    else:
        config_manager = ConfigurationManager()
        config = config_manager.get_default_config()
    
    if args.verbose:
        print(f"Input directory:  {args.input_dir}")
        print(f"Output directory: {args.output_dir}")
        print(f"Dry run:          {args.dry_run}")
        print("\nStarting entry point transformation...")
    
    # Create orchestrator and run transformation
    orchestrator = TransformationOrchestrator(config)
    report = orchestrator.transform_entry_points(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        dry_run=args.dry_run
    )
    
    # Print report
    print_report(report, verbose=args.verbose)
    
    # Exit with appropriate code
    sys.exit(0 if report.success else 1)


def create_parser() -> argparse.ArgumentParser:
    """
    Create argument parser for CLI.
    
    Returns:
        Configured argument parser
    """
    parser = argparse.ArgumentParser(
        prog="atx-dependency-transformer",
        description="Transform ATX tool outputs to legacy_analyzer format",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Transform all (flows, jobs, entry points)
  python -m tools.atx.dependency_transformer transform all \\
      --input-dir examples/atx \\
      --output-dir results/atx_transformed

  # Transform only flows
  python -m tools.atx.dependency_transformer transform flows \\
      --input-dir examples/atx \\
      --output-dir results/flows

  # Dry run with custom configuration
  python -m tools.atx.dependency_transformer transform all \\
      --input-dir examples/atx \\
      --output-dir results/atx_transformed \\
      --config config/atx_transformer.yaml \\
      --dry-run \\
      --verbose
        """
    )
    
    # Create subparsers for commands
    subparsers = parser.add_subparsers(
        title="commands",
        description="Available transformation commands",
        dest="command",
        required=True
    )
    
    # Common arguments for all transform commands
    def add_common_args(subparser):
        """Add common arguments to a subparser."""
        subparser.add_argument(
            "--input-dir",
            type=str,
            required=True,
            help="Directory containing ATX input files (dependencies.json, assets.csv, program_to_dsn.json)"
        )
        subparser.add_argument(
            "--output-dir",
            type=str,
            required=True,
            help="Directory for output files"
        )
        subparser.add_argument(
            "--config",
            type=str,
            help="Path to configuration YAML file (uses defaults if not specified)"
        )
        subparser.add_argument(
            "--dry-run",
            action="store_true",
            help="Validate inputs and preview transformation without writing files"
        )
        subparser.add_argument(
            "--verbose",
            action="store_true",
            help="Enable verbose output with detailed progress and warnings"
        )
    
    # Transform command with subcommands
    transform_parser = subparsers.add_parser(
        "transform",
        help="Transform ATX data to legacy_analyzer format"
    )
    
    transform_subparsers = transform_parser.add_subparsers(
        title="transform commands",
        description="Specific transformation types",
        dest="transform_command",
        required=True
    )
    
    # Transform all command
    all_parser = transform_subparsers.add_parser(
        "all",
        help="Transform all (flows, jobs, entry points)"
    )
    add_common_args(all_parser)
    all_parser.set_defaults(func=transform_all_command)
    
    # Transform flows command
    flows_parser = transform_subparsers.add_parser(
        "flows",
        help="Transform only flows"
    )
    add_common_args(flows_parser)
    flows_parser.set_defaults(func=transform_flows_command)
    
    # Transform jobs command
    jobs_parser = transform_subparsers.add_parser(
        "jobs",
        help="Transform only jobs"
    )
    add_common_args(jobs_parser)
    jobs_parser.set_defaults(func=transform_jobs_command)
    
    # Transform entry-points command
    entry_points_parser = transform_subparsers.add_parser(
        "entry-points",
        help="Transform only entry points"
    )
    add_common_args(entry_points_parser)
    entry_points_parser.set_defaults(func=transform_entry_points_command)
    
    return parser


def main(argv=None):
    """
    Main entry point for CLI.
    
    Args:
        argv: Command-line arguments (uses sys.argv if None)
    """
    parser = create_parser()
    args = parser.parse_args(argv)
    
    # Execute the appropriate command
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
