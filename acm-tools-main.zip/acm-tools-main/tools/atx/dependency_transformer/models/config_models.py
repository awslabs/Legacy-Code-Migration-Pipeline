"""
Configuration data models.

These models represent the configuration structure for the ATX Dependency
Transformer, including complexity formulas, utility program lists, and
transformation options.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class ComplexityFormula:
    """
    Complexity formula configuration.
    
    Defines the weights used in the composite complexity score calculation:
    composite_score = (CC * cc_weight) + (LOC / 100 * loc_weight)
    """
    cc_weight: float = 0.3
    loc_weight: float = 0.7
    
    def __post_init__(self):
        """Validate weights are non-negative."""
        if self.cc_weight < 0:
            raise ValueError("cc_weight must be non-negative")
        if self.loc_weight < 0:
            raise ValueError("loc_weight must be non-negative")


@dataclass
class ComplexityTiers:
    """
    Complexity tier thresholds.
    
    Defines the thresholds for classifying complexity into tiers:
    - LOW: score < low_threshold
    - MEDIUM: low_threshold <= score < medium_threshold
    - HIGH: score >= medium_threshold
    """
    low_threshold: float = 10.0
    medium_threshold: float = 20.0
    
    def __post_init__(self):
        """Validate thresholds are in ascending order."""
        if self.low_threshold < 0:
            raise ValueError("low_threshold must be non-negative")
        if self.medium_threshold <= self.low_threshold:
            raise ValueError("medium_threshold must be greater than low_threshold")


@dataclass
class ComplexityConfig:
    """
    Complexity calculation configuration.
    
    Contains formula weights and tier thresholds for complexity calculation.
    """
    formula: ComplexityFormula = field(default_factory=ComplexityFormula)
    tiers: ComplexityTiers = field(default_factory=ComplexityTiers)


@dataclass
class TransformationOptions:
    """
    Transformation behavior options.
    
    Controls various aspects of the transformation process.
    """
    include_inferred_entry_points: bool = True
    warn_on_missing_metrics: bool = True
    fail_on_invalid_schema: bool = False


@dataclass
class OutputOptions:
    """
    Output formatting options.
    
    Controls how output files are generated and formatted.
    """
    generate_sorted_variants: bool = True
    generate_csv_exports: bool = True
    pretty_print_json: bool = True
    indent_size: int = 2
    
    def __post_init__(self):
        """Validate indent_size is positive."""
        if self.indent_size < 0:
            raise ValueError("indent_size must be non-negative")


@dataclass
class TransformationConfig:
    """
    Complete transformation configuration.
    
    Contains all configuration settings for the ATX Dependency Transformer,
    including complexity calculation, utility programs, transformation options,
    and output formatting.
    """
    complexity: ComplexityConfig = field(default_factory=ComplexityConfig)
    utility_programs: List[str] = field(default_factory=lambda: [
        "IDCAMS",
        "IEBGENER",
        "IEFBR14",
        "SORT",
        "DFSORT",
        "IEBCOPY",
        "IEBUPDTE",
    ])
    transformation: TransformationOptions = field(default_factory=TransformationOptions)
    output: OutputOptions = field(default_factory=OutputOptions)
    
    def is_utility_program(self, program_name: str) -> bool:
        """
        Check if a program is a utility program.
        
        Args:
            program_name: Name of the program to check
            
        Returns:
            True if the program is in the utility programs list
        """
        # Use casefold() for proper Unicode case-insensitive comparison
        # casefold() is more aggressive than lower() and handles edge cases
        # like Turkish İ correctly
        program_folded = program_name.casefold()
        return any(p.casefold() == program_folded for p in self.utility_programs)
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "TransformationConfig":
        """
        Create configuration from dictionary.
        
        Args:
            config_dict: Dictionary containing configuration values
            
        Returns:
            TransformationConfig instance
        """
        # Extract complexity configuration
        complexity_dict = config_dict.get("complexity", {})
        formula_dict = complexity_dict.get("formula", {})
        tiers_dict = complexity_dict.get("tiers", {})
        
        formula = ComplexityFormula(
            cc_weight=formula_dict.get("cc_weight", 0.3),
            loc_weight=formula_dict.get("loc_weight", 0.7),
        )
        
        tiers = ComplexityTiers(
            low_threshold=tiers_dict.get("low_threshold", 10.0),
            medium_threshold=tiers_dict.get("medium_threshold", 20.0),
        )
        
        complexity = ComplexityConfig(formula=formula, tiers=tiers)
        
        # Extract utility programs
        utility_programs = config_dict.get("utility_programs", [
            "IDCAMS",
            "IEBGENER",
            "IEFBR14",
            "SORT",
            "DFSORT",
            "IEBCOPY",
            "IEBUPDTE",
        ])
        
        # Extract transformation options
        transformation_dict = config_dict.get("transformation", {})
        transformation = TransformationOptions(
            include_inferred_entry_points=transformation_dict.get(
                "include_inferred_entry_points", True
            ),
            warn_on_missing_metrics=transformation_dict.get("warn_on_missing_metrics", True),
            fail_on_invalid_schema=transformation_dict.get("fail_on_invalid_schema", False),
        )
        
        # Extract output options
        output_dict = config_dict.get("output", {})
        output = OutputOptions(
            generate_sorted_variants=output_dict.get("generate_sorted_variants", True),
            generate_csv_exports=output_dict.get("generate_csv_exports", True),
            pretty_print_json=output_dict.get("pretty_print_json", True),
            indent_size=output_dict.get("indent_size", 2),
        )
        
        return cls(
            complexity=complexity,
            utility_programs=utility_programs,
            transformation=transformation,
            output=output,
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary.
        
        Returns:
            Dictionary representation of configuration
        """
        return {
            "complexity": {
                "formula": {
                    "cc_weight": self.complexity.formula.cc_weight,
                    "loc_weight": self.complexity.formula.loc_weight,
                },
                "tiers": {
                    "low_threshold": self.complexity.tiers.low_threshold,
                    "medium_threshold": self.complexity.tiers.medium_threshold,
                },
            },
            "utility_programs": self.utility_programs,
            "transformation": {
                "include_inferred_entry_points": self.transformation.include_inferred_entry_points,
                "warn_on_missing_metrics": self.transformation.warn_on_missing_metrics,
                "fail_on_invalid_schema": self.transformation.fail_on_invalid_schema,
            },
            "output": {
                "generate_sorted_variants": self.output.generate_sorted_variants,
                "generate_csv_exports": self.output.generate_csv_exports,
                "pretty_print_json": self.output.pretty_print_json,
                "indent_size": self.output.indent_size,
            },
        }


@dataclass
class ValidationWarning:
    """
    Warning message from validation.
    
    Represents a non-fatal issue found during validation that doesn't
    prevent transformation but should be noted.
    """
    category: str  # MISSING_DATA, INCONSISTENCY, FORMAT_ISSUE, etc.
    message: str
    context: Dict[str, Any] = field(default_factory=dict)
    
    def __str__(self) -> str:
        """String representation of warning."""
        context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
        if context_str:
            return f"[{self.category}] {self.message} ({context_str})"
        return f"[{self.category}] {self.message}"


@dataclass
class ValidationError:
    """
    Error message from validation.
    
    Represents a fatal issue found during validation that prevents
    transformation from proceeding.
    """
    category: str  # MISSING_FILE, INVALID_FORMAT, SCHEMA_ERROR, etc.
    message: str
    context: Dict[str, Any] = field(default_factory=dict)
    fatal: bool = True
    
    def __str__(self) -> str:
        """String representation of error."""
        context_str = ", ".join(f"{k}={v}" for k, v in self.context.items())
        fatal_str = " [FATAL]" if self.fatal else ""
        if context_str:
            return f"[{self.category}]{fatal_str} {self.message} ({context_str})"
        return f"[{self.category}]{fatal_str} {self.message}"


@dataclass
class ValidationResult:
    """
    Result of validation operation.
    
    Contains the validation status, any errors found, and any warnings.
    """
    valid: bool
    errors: List[ValidationError] = field(default_factory=list)
    warnings: List[ValidationWarning] = field(default_factory=list)
    
    def add_error(self, category: str, message: str, 
                  context: Optional[Dict[str, Any]] = None, fatal: bool = True):
        """Add an error to the validation result."""
        self.errors.append(ValidationError(
            category=category,
            message=message,
            context=context or {},
            fatal=fatal
        ))
        if fatal:
            self.valid = False
    
    def add_warning(self, category: str, message: str, 
                    context: Optional[Dict[str, Any]] = None):
        """Add a warning to the validation result."""
        self.warnings.append(ValidationWarning(
            category=category,
            message=message,
            context=context or {}
        ))
    
    def has_fatal_errors(self) -> bool:
        """Check if there are any fatal errors."""
        return any(error.fatal for error in self.errors)
    
    def get_summary(self) -> str:
        """Get a summary of validation results."""
        if self.valid:
            if self.warnings:
                return f"Valid with {len(self.warnings)} warning(s)"
            return "Valid"
        return f"Invalid: {len(self.errors)} error(s), {len(self.warnings)} warning(s)"


@dataclass
class TransformationReport:
    """
    Transformation execution report.
    
    Contains statistics and status information about a completed transformation,
    including counts of generated artifacts, warnings, errors, and execution time.
    """
    success: bool
    flows_generated: int = 0
    jobs_generated: int = 0
    entry_points_generated: int = 0
    programs_processed: int = 0
    warnings: List[ValidationWarning] = field(default_factory=list)
    errors: List[ValidationError] = field(default_factory=list)
    execution_time_seconds: float = 0.0
    dry_run: bool = False
    
    def add_warning(self, category: str, message: str, 
                    context: Optional[Dict[str, Any]] = None):
        """Add a warning to the report."""
        self.warnings.append(ValidationWarning(
            category=category,
            message=message,
            context=context or {}
        ))
    
    def add_error(self, category: str, message: str, 
                  context: Optional[Dict[str, Any]] = None, fatal: bool = True):
        """Add an error to the report."""
        self.errors.append(ValidationError(
            category=category,
            message=message,
            context=context or {},
            fatal=fatal
        ))
    
    def get_summary(self) -> str:
        """Get a summary of the transformation."""
        if self.dry_run:
            status = "Dry-run validation"
        elif self.success:
            status = "Success"
        else:
            status = "Failed"
        
        lines = [
            f"Transformation Status: {status}",
            f"Execution Time: {self.execution_time_seconds:.2f}s",
            f"Flows Generated: {self.flows_generated}",
            f"Jobs Generated: {self.jobs_generated}",
            f"Entry Points Generated: {self.entry_points_generated}",
            f"Programs Processed: {self.programs_processed}",
            f"Warnings: {len(self.warnings)}",
            f"Errors: {len(self.errors)}",
        ]
        
        return "\n".join(lines)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary."""
        return {
            "success": self.success,
            "flows_generated": self.flows_generated,
            "jobs_generated": self.jobs_generated,
            "entry_points_generated": self.entry_points_generated,
            "programs_processed": self.programs_processed,
            "warnings": [str(w) for w in self.warnings],
            "errors": [str(e) for e in self.errors],
            "execution_time_seconds": self.execution_time_seconds,
            "dry_run": self.dry_run,
        }
