"""
ATX input data models.

These models represent the structure of ATX tool outputs:
- dependencies.json: Program dependencies, calls, copybooks, datasets
- assets.csv: Code metrics (CC, LOC, comments)
- program_to_dsn.json: Data operations with access types
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class ATXDependency:
    """
    Represents an entry in dependencies.json.
    
    ATX dependencies.json contains entries for programs, JCL, transactions,
    and other artifacts with their dependencies.
    """
    name: str
    path: str
    type: str  # COB, JCL, TRANSACTION, CICS_FILE, etc.
    dependencies: List[Dict[str, Any]] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate required fields."""
        if not self.name:
            raise ValueError("ATXDependency.name cannot be empty")
        if not self.type:
            raise ValueError("ATXDependency.type cannot be empty")


@dataclass
class ATXAssetMetrics:
    """
    Represents metrics from assets.csv.
    
    ATX assets.csv contains code metrics for each program including
    cyclomatic complexity, lines of code, and comment statistics.
    """
    name: str
    path: str
    file_type: str
    cyclomatic_complexity: int = 0
    total_lines: int = 0
    empty_lines: int = 0
    effective_lines: int = 0
    comment_lines: int = 0
    
    def __post_init__(self):
        """Validate and normalize metrics."""
        if not self.name:
            raise ValueError("ATXAssetMetrics.name cannot be empty")
        
        # Ensure non-negative values
        self.cyclomatic_complexity = max(0, self.cyclomatic_complexity)
        self.total_lines = max(0, self.total_lines)
        self.empty_lines = max(0, self.empty_lines)
        self.effective_lines = max(0, self.effective_lines)
        self.comment_lines = max(0, self.comment_lines)


@dataclass
class ATXDataOperation:
    """
    Represents an entry in program_to_dsn.json.
    
    ATX program_to_dsn.json contains data operations showing which programs
    access which datasets and how (READ, WRITE, UPDATE).
    """
    file_name: str
    file_path: str
    data_source_name: str
    dd_name: Optional[str] = None
    logical_name: Optional[str] = None
    copybook_record_name: Optional[str] = None
    copybook_file_path: Optional[str] = None
    data_source_type: Optional[str] = None  # VSAM, DB2, etc.
    access_type: str = ""  # READ, WRITE, UPDATE, or combinations like "READ; WRITE"
    
    def __post_init__(self):
        """Validate required fields."""
        if not self.file_name:
            raise ValueError("ATXDataOperation.file_name cannot be empty")
        if not self.data_source_name:
            raise ValueError("ATXDataOperation.data_source_name cannot be empty")
    
    def get_access_types(self) -> List[str]:
        """
        Parse access_type string into list of individual access types.
        
        Returns:
            List of access types (e.g., ["READ", "WRITE"])
        """
        if not self.access_type:
            return []
        
        # Split by semicolon and clean up whitespace
        types = [t.strip().upper() for t in self.access_type.split(";")]
        return [t for t in types if t]
