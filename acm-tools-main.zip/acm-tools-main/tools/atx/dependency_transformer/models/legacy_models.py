"""
Legacy analyzer output data models.

These models represent the structure of legacy_analyzer outputs:
- Business_Flows.json: Flow definitions with entry points, scope, complexity
- jobs.json: Job definitions with steps, datasets, dependencies
- entry_points.json: Entry point catalog with types and sources
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class Caller:
    """
    Caller information for entry points.
    
    Represents a source that invokes an entry point (e.g., CICS transaction,
    JCL job step).
    """
    source: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EntryPointType:
    """
    Entry point type with callers.
    
    Represents a specific type of entry point (e.g., CICS_TRANSACTION, JCL)
    and the sources that invoke it.
    """
    type: str  # CICS_TRANSACTION, JCL, etc.
    callers: List[Caller] = field(default_factory=list)


@dataclass
class EntryPoint:
    """
    Flow entry point structure.
    
    Represents how a flow is invoked, including the entry program and
    all the ways it can be called.
    """
    program: str
    types: List[EntryPointType] = field(default_factory=list)
    primary_type: str = ""  # CICS_TRANSACTION, JCL, etc.
    
    def __post_init__(self):
        """Set primary_type if not provided."""
        if not self.primary_type and self.types:
            self.primary_type = self.types[0].type


@dataclass
class Program:
    """
    Program in scope.
    
    Represents a program within a flow's scope, indicating whether it's
    a utility program or custom code, along with its file path and language.
    """
    name: str
    is_utility: bool = False
    file_path: Optional[str] = None  # Resolved local file path
    language: str = "UNKNOWN"  # Programming language (COBOL, PL/I, ASM, etc.)


@dataclass
class Copybook:
    """
    Copybook in scope.
    
    Represents a copybook used by programs in the flow's scope.
    """
    name: str
    file_path: Optional[str] = None  # Resolved local file path


@dataclass
class Scope:
    """
    Flow scope structure.
    
    Represents all artifacts (programs, copybooks, datasets) that are part
    of a flow's execution scope.
    """
    programs: List[Program] = field(default_factory=list)
    copybooks: List[Copybook] = field(default_factory=list)
    datasets: List[str] = field(default_factory=list)


@dataclass
class DatabaseOperation:
    """
    Database operation.
    
    Represents a database access operation (VSAM, DB2, etc.) performed
    by a program in the flow.
    """
    type: str  # VSAM, DB2, IMS, etc.
    operation: str  # READ, WRITE, UPDATE
    target: str  # Database/dataset name
    program: str  # Program performing the operation


@dataclass
class DatasetOperation:
    """
    Dataset operation.
    
    Represents a dataset access operation performed by a program in the flow.
    """
    operation: str  # READ, WRITE, UPDATE
    dataset: str  # Dataset name
    program: str  # Program performing the operation


@dataclass
class DataOperations:
    """
    Data operations structure.
    
    Represents all data access operations (databases and datasets) performed
    by programs in a flow.
    """
    databases: List[DatabaseOperation] = field(default_factory=list)
    datasets: List[DatasetOperation] = field(default_factory=list)


@dataclass
class Complexity:
    """
    Complexity metrics.
    
    Represents complexity metrics for a flow, including program counts,
    code metrics, and calculated complexity scores.
    """
    total_programs: int = 0
    total_lines: int = 0
    cyclomatic_complexity: int = 0
    composite_score: float = 0.0
    tier: str = "LOW"  # LOW, MEDIUM, HIGH
    
    def __post_init__(self):
        """Validate tier value."""
        valid_tiers = ["LOW", "MEDIUM", "HIGH"]
        if self.tier not in valid_tiers:
            raise ValueError(f"Invalid tier: {self.tier}. Must be one of {valid_tiers}")


@dataclass
class FlowDependencies:
    """
    Flow dependencies.
    
    Represents dependencies between flows, indicating which flows must be
    migrated before/after this flow.
    """
    required_flows: List[str] = field(default_factory=list)
    dependent_flows: List[str] = field(default_factory=list)


@dataclass
class Flow:
    """
    Legacy analyzer flow structure.
    
    Represents a complete flow definition including entry point, scope,
    data operations, complexity, and dependencies.
    """
    flow_id: str
    name: str
    entry_point: EntryPoint
    scope: Scope = field(default_factory=Scope)
    interfaces: Dict[str, Any] = field(default_factory=dict)
    data_operations: DataOperations = field(default_factory=DataOperations)
    complexity: Complexity = field(default_factory=Complexity)
    dependencies: FlowDependencies = field(default_factory=FlowDependencies)
    invoked_by_jobs: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate required fields."""
        if not self.flow_id:
            raise ValueError("Flow.flow_id cannot be empty")
        if not self.name:
            raise ValueError("Flow.name cannot be empty")


@dataclass
class JobStep:
    """
    Job step structure.
    
    Represents a single step in a JCL job, including the program executed
    and its purpose.
    """
    step_name: str
    program: str
    type: str = "CUSTOM"  # CUSTOM, UTILITY
    purpose: str = ""
    flow_entry: bool = False
    
    def __post_init__(self):
        """Validate type value."""
        valid_types = ["CUSTOM", "UTILITY"]
        if self.type not in valid_types:
            raise ValueError(f"Invalid type: {self.type}. Must be one of {valid_types}")


@dataclass
class JobDependencies:
    """
    Job dependencies.
    
    Represents dependencies between jobs, indicating execution order
    requirements.
    """
    must_run_after: List[str] = field(default_factory=list)
    must_run_before: List[str] = field(default_factory=list)


@dataclass
class Job:
    """
    Legacy analyzer job structure.
    
    Represents a JCL job definition including steps, datasets, and
    dependencies.
    """
    job_name: str
    job_type: str = "APPLICATION"  # APPLICATION, INFRASTRUCTURE
    has_custom_code: bool = True
    linked_flow: Optional[str] = None
    steps: List[JobStep] = field(default_factory=list)
    datasets: List[str] = field(default_factory=list)
    dependencies: JobDependencies = field(default_factory=JobDependencies)
    
    def __post_init__(self):
        """Validate required fields and type value."""
        if not self.job_name:
            raise ValueError("Job.job_name cannot be empty")
        
        valid_types = ["APPLICATION", "INFRASTRUCTURE"]
        if self.job_type not in valid_types:
            raise ValueError(f"Invalid job_type: {self.job_type}. Must be one of {valid_types}")


@dataclass
class EntryPointRecord:
    """
    Entry point record structure.
    
    Represents an entry point in the entry points catalog, including
    type, confidence, and source information.
    """
    program_name: str
    entry_type: str  # ONLINE, BATCH, INFERRED
    confidence: str  # EXPLICIT, INFERRED
    source: str  # CSD, JCL, CODE_ANALYSIS
    description: Optional[str] = None
    transaction_id: Optional[str] = None
    jcl_name: Optional[str] = None
    status: Optional[str] = None  # ENABLED, DISABLED
    
    def __post_init__(self):
        """Validate required fields and enum values."""
        if not self.program_name:
            raise ValueError("EntryPointRecord.program_name cannot be empty")
        
        valid_entry_types = ["ONLINE", "BATCH", "INFERRED"]
        if self.entry_type not in valid_entry_types:
            raise ValueError(
                f"Invalid entry_type: {self.entry_type}. Must be one of {valid_entry_types}"
            )
        
        valid_confidence = ["EXPLICIT", "INFERRED"]
        if self.confidence not in valid_confidence:
            raise ValueError(
                f"Invalid confidence: {self.confidence}. Must be one of {valid_confidence}"
            )
        
        valid_sources = ["CSD", "JCL", "CODE_ANALYSIS"]
        if self.source not in valid_sources:
            raise ValueError(
                f"Invalid source: {self.source}. Must be one of {valid_sources}"
            )
