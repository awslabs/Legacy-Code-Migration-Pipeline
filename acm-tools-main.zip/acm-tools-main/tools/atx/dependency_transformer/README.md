# ATX Dependency Transformer

## Overview

The ATX Dependency Transformer is a data transformation tool that converts ATX tool outputs into legacy_analyzer-compatible format. This enables users with existing ATX analysis results to leverage legacy_analyzer workflows for migration planning without re-running static code analysis.

**Key Features:**
- ✅ **No source code parsing required** - purely data-driven transformation
- ✅ **85-90% field coverage** compared to legacy_analyzer
- ✅ **Fast execution** - processes 1000 programs in < 30 seconds
- ✅ **Configurable** - customize complexity formulas, utility programs, and thresholds
- ✅ **Multiple output formats** - JSON and CSV exports with various sort orders

## What It Does

The transformer converts three ATX output files into legacy_analyzer format:

**Input (ATX Outputs):**
- `dependencies.json` - Program dependencies, calls, copybooks, datasets
- `assets.csv` - Code metrics (cyclomatic complexity, lines of code)
- `program_to_dsn.json` - Data operations (READ, WRITE, UPDATE)

**Output (Legacy Analyzer Format):**
- `Business_Flows.json` - Migration flows with complexity and dependencies
- `jobs.json` - Batch jobs with steps and datasets
- `entry_points.json` - Entry points (ONLINE, BATCH, INFERRED)
- `entry_points.csv` - CSV export of entry points

## Quick Start

### Installation

The tool is part of the SMF Migration Toolkit:

```bash
# No installation needed - run directly
python -m tools.atx.dependency_transformer --help
```

### Basic Usage

Transform all artifacts (flows, jobs, entry points):

```bash
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed
```

### Example Output

```
======================================================================
TRANSFORMATION REPORT
======================================================================

Status: ✓ SUCCESS

Statistics:
  Flows generated:        50
  Jobs generated:         32
  Entry points generated: 61
  Programs processed:     28
  Execution time:         0.02s

======================================================================
```

## Architecture

The transformer follows a multi-phase pipeline:

```
┌─────────────────────────────────────────────────────────────┐
│                    ATX Input Files                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │dependencies  │  │  assets.csv  │  │program_to_dsn    │  │
│  │   .json      │  │              │  │    .json         │  │
│  └──────────────┘  └──────────────┘  └──────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              ATX Dependency Transformer                     │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Input Loaders (JSON, CSV parsers)                   │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Core Transformers                                    │  │
│  │  • FlowTransformer                                    │  │
│  │  • JobTransformer                                     │  │
│  │  • EntryPointTransformer                             │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Analysis Engines                                     │  │
│  │  • CallGraphAnalyzer                                  │  │
│  │  • ComplexityCalculator                              │  │
│  │  • DependencyResolver                                │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Output Writers (JSON, CSV formatters)               │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Legacy Analyzer Output Files                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │migration_    │  │   jobs.json  │  │entry_points.json │  │
│  │flows.json    │  │              │  │                  │  │
│  └──────────────┘  └──────────────┘  └──────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## Commands

### Transform All

Transform all outputs (flows, jobs, and entry points):

```bash
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed
```

### Transform Flows Only

Transform only migration flows:

```bash
python -m tools.atx.dependency_transformer transform flows \
    --input-dir examples/atx \
    --output-dir results/flows
```

### Transform Jobs Only

Transform only batch jobs:

```bash
python -m tools.atx.dependency_transformer transform jobs \
    --input-dir examples/atx \
    --output-dir results/jobs
```

### Transform Entry Points Only

Transform only entry points:

```bash
python -m tools.atx.dependency_transformer transform entry-points \
    --input-dir examples/atx \
    --output-dir results/entry_points
```

## Configuration

Customize transformation behavior with a YAML configuration file:

```yaml
# config/atx_transformer.yaml

complexity:
  weight_cc: 0.3
  weight_loc: 0.7
  tier_thresholds:
    low: 10.0
    medium: 20.0

transformation:
  utility_programs:
    - SORT
    - IEFBR14
    - IDCAMS
    - IEBGENER
    - IEBCOPY
  warn_on_missing_metrics: true

output:
  generate_sorted_variants: true
  generate_csv_exports: true
  indent_json: 2
```

Use custom configuration:

```bash
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed \
    --config config/atx_transformer.yaml
```

## Output Structure

### Complete Transformation

```
output_dir/
├── flows/
│   ├── Business_Flows.json          # Main flows file
│   ├── flows_by_name.json            # Sorted by name
│   ├── flows_by_complexity_asc.json  # Sorted by complexity ascending
│   ├── flows_by_complexity_desc.json # Sorted by complexity descending
│   └── flows_by_independence.json    # Sorted by dependency count
├── jobs/
│   ├── jobs.json                     # Main jobs file
│   ├── jobs_by_name.json             # Sorted by name
│   ├── jobs_by_type.json             # Sorted by type
│   └── jobs_by_complexity.json       # Sorted by complexity
├── entry_points.json                 # Main entry points file
└── exports/
    └── entry_points.csv              # CSV export
```

## Features

### Flow Transformation

Converts ATX dependencies into migration flows with:
- **Entry points** from CICS transactions and JCL jobs
- **Program scope** with transitive dependencies
- **Complexity metrics** (composite score, tier classification)
- **Data operations** (READ, WRITE, UPDATE)
- **Flow dependencies** (required flows, dependent flows)

### Job Transformation

Converts ATX JCL data into batch jobs with:
- **Job steps** with programs executed
- **Dataset usage** from JCL dependencies
- **Job type classification** (APPLICATION vs INFRASTRUCTURE)
- **Custom code detection** based on program types

### Entry Point Transformation

Extracts entry points with:
- **ONLINE entry points** from CICS transactions
- **BATCH entry points** from JCL jobs
- **INFERRED entry points** from call graph analysis
- **Confidence levels** (EXPLICIT vs INFERRED)
- **Source mapping** (CSD, JCL, CODE_ANALYSIS)

### Analysis Engines

- **CallGraphAnalyzer**: Builds program call graph and computes transitive dependencies
- **ComplexityCalculator**: Calculates composite scores and assigns tiers
- **DependencyResolver**: Resolves flow-to-flow dependencies

## Advanced Usage

### Dry Run Mode

Preview transformation without writing files:

```bash
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed \
    --dry-run \
    --verbose
```

### Verbose Logging

Enable detailed output for debugging:

```bash
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed \
    --verbose
```

### Integration with Legacy Analyzer

Use transformed outputs with legacy_analyzer workflows:

```bash
# Use transformed flows for migration planning
python -m tools.legacy_analyzer packages \
    --flows results/atx_transformed/flows/Business_Flows.json \
    --output migration_packages/

# Analyze transformed jobs
python -m tools.legacy_analyzer analyze-jobs \
    --jobs results/atx_transformed/jobs/jobs.json
```

## Input Requirements

The input directory must contain:

1. **dependencies.json** (required)
   - Program dependencies and call relationships
   - CICS transactions
   - JCL jobs
   - Copybook usage
   - Dataset references

2. **assets.csv** (required)
   - Code metrics (cyclomatic complexity, lines of code)
   - Program metadata

3. **program_to_dsn.json** (required)
   - Data operations (READ, WRITE, UPDATE)
   - Dataset access patterns

## Limitations and Known Issues

### Current Limitations

1. **Interface definitions** - Not captured in ATX data (inbound/outbound APIs)
2. **Job orchestration** - Job-to-job dependencies not available
3. **Semantic analysis** - Business logic classification requires heuristics
4. **ATX data completeness** - Quality depends on ATX tool coverage

### Known Issues

1. **Entry point classification** - Some JCL files may be classified as INFERRED instead of BATCH
2. **Utility program lists** - May differ from legacy_analyzer defaults
3. **Missing JCL files** - ATX may not capture all JCL files in codebase

See `docs/IMPROVEMENT_PLAN.md` for detailed analysis and improvement recommendations.

## Performance

- **Processing speed**: < 30 seconds for 1000 programs
- **Memory usage**: Efficient streaming for large files
- **Scalability**: Tested with projects up to 5000 programs

## Testing

The tool includes comprehensive test coverage:

```bash
# Run all tests
pytest tests/

# Run property-based tests
pytest tests/ -k "property" -v

# Run with coverage
pytest --cov=tools.atx.dependency_transformer tests/
```

**Test Coverage:**
- Unit tests for all components
- Property-based tests for correctness properties
- Integration tests with CardDemo example data
- Error handling tests for edge cases

## Documentation

- **CLI Usage Guide**: `docs/CLI_USAGE.md` - Detailed command-line reference
- **Mapping Analysis**: `docs/ATX_TO_LEGACY_ANALYZER_MAPPING.md` - Field-by-field comparison
- **Improvement Plan**: `docs/IMPROVEMENT_PLAN.md` - Known issues and roadmap

## Troubleshooting

### Missing Input Files

**Error**: Required ATX input file not found

**Solution**: Ensure all required files exist:
- `dependencies.json`
- `assets.csv`
- `program_to_dsn.json`

### Invalid JSON/CSV Format

**Error**: Malformed JSON or CSV file

**Solution**: Validate your ATX output files are properly formatted

### Missing Metrics

**Warning**: Program in dependencies.json not found in assets.csv

**Impact**: Default metrics (CC=0, LOC=0) will be used

**Solution**: Ensure assets.csv contains all programs from dependencies.json

### Permission Denied

**Error**: Cannot write to output directory

**Solution**: Check write permissions on the output directory

## Contributing

The tool follows standard Python development practices:

- **Code style**: Black formatter (line length: 100)
- **Type hints**: Full type annotations
- **Documentation**: Docstrings for all public APIs
- **Testing**: Pytest with property-based tests

## License

Part of the SMF Migration Toolkit.

## Support

For issues, questions, or contributions, please refer to the main SMF Migration Toolkit documentation.

## Version History

- **v1.0.0** - Initial release with flows, jobs, and entry points transformation
- Achieves 85-90% field coverage compared to legacy_analyzer
- Supports configurable complexity formulas and utility programs
- Includes comprehensive test suite with property-based testing
