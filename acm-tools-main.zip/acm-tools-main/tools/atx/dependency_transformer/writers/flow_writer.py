"""
Flow writer for ATX Dependency Transformer.

Writes flows to JSON files with multiple sort orders.
"""

import json
from pathlib import Path
from typing import List
from ..models.legacy_models import Flow


class FlowWriter:
    """
    Writes flows to JSON files with multiple sort orders.
    
    Generates:
    - Business_Flows.json: Main flows file
    - flows_by_name.json: Sorted by name
    - flows_by_complexity_asc.json: Sorted by complexity ascending
    - flows_by_complexity_desc.json: Sorted by complexity descending
    - flows_by_independence.json: Sorted by dependency count
    """
    
    def __init__(self, pretty_print: bool = True, indent: int = 2):
        """
        Initialize FlowWriter.
        
        Args:
            pretty_print: Whether to format JSON with indentation
            indent: Number of spaces for indentation
        """
        self.pretty_print = pretty_print
        self.indent = indent if pretty_print else None
    
    def write(self, flows: List[Flow], output_dir: str):
        """
        Write flows to output directory with all sort variants.
        
        Args:
            flows: List of flows to write
            output_dir: Output directory path
        """
        output_path = Path(output_dir)
        flows_dir = output_path / "flows"
        flows_dir.mkdir(parents=True, exist_ok=True)
        
        # Write main Business_Flows.json
        self.write_migration_flows(flows, str(flows_dir / "Business_Flows.json"))
        
        # Write sorted variants
        self.write_sorted_flows(flows, str(flows_dir))
    
    def write_migration_flows(self, flows: List[Flow], file_path: str):
        """
        Write main Business_Flows.json file.
        
        Args:
            flows: List of flows to write
            file_path: Output file path
            
        Raises:
            PermissionError: If write permission is denied
            OSError: If disk space is exhausted or other I/O error occurs
        """
        flows_data = [self._flow_to_dict(flow) for flow in flows]
        
        # Wrap in "flows" key to match legacy_analyzer schema
        output_data = {"flows": flows_data}
        
        try:
            with open(file_path, 'w') as f:
                json.dump(output_data, f, indent=self.indent)
        except PermissionError:
            raise PermissionError(
                f"Permission denied writing to {file_path}. "
                f"Check directory permissions and try again."
            )
        except OSError as e:
            if e.errno == 28:  # ENOSPC - No space left on device
                raise OSError(
                    f"Insufficient disk space to write {file_path}. "
                    f"Free up disk space and try again."
                )
            else:
                raise OSError(
                    f"Failed to write {file_path}: {e}. "
                    f"Check disk space and permissions."
                )
    
    def write_sorted_flows(self, flows: List[Flow], output_dir: str):
        """
        Write sorted variants (by name, complexity, independence).
        
        Args:
            flows: List of flows to write
            output_dir: Output directory path
        """
        output_path = Path(output_dir)
        
        # Sort by name
        flows_by_name = sorted(flows, key=lambda f: f.name)
        self._write_flows(flows_by_name, str(output_path / "flows_by_name.json"))
        
        # Sort by complexity ascending
        flows_by_complexity_asc = sorted(flows, key=lambda f: f.complexity.composite_score)
        self._write_flows(
            flows_by_complexity_asc,
            str(output_path / "flows_by_complexity_asc.json")
        )
        
        # Sort by complexity descending
        flows_by_complexity_desc = sorted(
            flows,
            key=lambda f: f.complexity.composite_score,
            reverse=True
        )
        self._write_flows(
            flows_by_complexity_desc,
            str(output_path / "flows_by_complexity_desc.json")
        )
        
        # Sort by independence (fewest dependencies first)
        flows_by_independence = sorted(
            flows,
            key=lambda f: len(f.dependencies.required_flows)
        )
        self._write_flows(
            flows_by_independence,
            str(output_path / "flows_by_independence.json")
        )
    
    def _write_flows(self, flows: List[Flow], file_path: str):
        """
        Write flows to a JSON file.
        
        Args:
            flows: List of flows to write
            file_path: Output file path
            
        Raises:
            PermissionError: If write permission is denied
            OSError: If disk space is exhausted or other I/O error occurs
        """
        flows_data = [self._flow_to_dict(flow) for flow in flows]
        
        try:
            with open(file_path, 'w') as f:
                json.dump(flows_data, f, indent=self.indent)
        except PermissionError:
            raise PermissionError(
                f"Permission denied writing to {file_path}. "
                f"Check directory permissions and try again."
            )
        except OSError as e:
            if e.errno == 28:  # ENOSPC - No space left on device
                raise OSError(
                    f"Insufficient disk space to write {file_path}. "
                    f"Free up disk space and try again."
                )
            else:
                raise OSError(
                    f"Failed to write {file_path}: {e}. "
                    f"Check disk space and permissions."
                )
    
    def _flow_to_dict(self, flow: Flow) -> dict:
        """
        Convert Flow object to dictionary for JSON serialization.
        
        Args:
            flow: Flow object to convert
            
        Returns:
            Dictionary representation of flow
        """
        return {
            "flowId": flow.flow_id,
            "name": flow.name,
            "entryPoint": {
                "program": flow.entry_point.program,
                "types": [
                    {
                        "type": ep_type.type,
                        "callers": [
                            {
                                "source": caller.source,
                                "metadata": caller.metadata
                            }
                            for caller in ep_type.callers
                        ]
                    }
                    for ep_type in flow.entry_point.types
                ],
                "primaryType": flow.entry_point.primary_type
            },
            "scope": {
                "programs": [
                    {
                        "name": prog.name,
                        "filePath": prog.file_path if prog.file_path else f"MISSING/MISSING/{prog.name}",
                        "language": prog.language,
                        "is_utility": prog.is_utility
                    }
                    for prog in flow.scope.programs
                ],
                "copybooks": [
                    {
                        "name": copybook.name,
                        "filePath": copybook.file_path if copybook.file_path else f"MISSING/MISSING/{copybook.name}"
                    }
                    for copybook in flow.scope.copybooks
                ],
                "datasets": flow.scope.datasets
            },
            "interfaces": flow.interfaces,
            "dataOperations": {
                "databases": [
                    {
                        "type": db_op.type,
                        "operation": db_op.operation,
                        "target": db_op.target,
                        "program": db_op.program
                    }
                    for db_op in flow.data_operations.databases
                ],
                "datasets": [
                    {
                        "operation": ds_op.operation,
                        "dataset": ds_op.dataset,
                        "program": ds_op.program
                    }
                    for ds_op in flow.data_operations.datasets
                ]
            },
            "complexity": {
                "totalPrograms": flow.complexity.total_programs,
                "totalLines": flow.complexity.total_lines,
                "cyclomaticComplexity": flow.complexity.cyclomatic_complexity,
                "compositeScore": flow.complexity.composite_score,
                "tier": flow.complexity.tier
            },
            "dependencies": {
                "requiredFlows": flow.dependencies.required_flows,
                "dependentFlows": flow.dependencies.dependent_flows
            },
            "invokedByJobs": flow.invoked_by_jobs
        }
