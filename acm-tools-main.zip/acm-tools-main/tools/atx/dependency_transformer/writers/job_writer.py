"""
Job writer for ATX Dependency Transformer.

Writes jobs to JSON files with multiple sort orders.
"""

import json
from pathlib import Path
from typing import List
from ..models.legacy_models import Job


class JobWriter:
    """
    Writes jobs to JSON files with multiple sort orders.
    
    Generates:
    - jobs.json: Main jobs file
    - jobs_by_name.json: Sorted by name
    - jobs_by_type.json: Sorted by type
    - jobs_by_complexity.json: Sorted by complexity (step count)
    """
    
    def __init__(self, pretty_print: bool = True, indent: int = 2):
        """
        Initialize JobWriter.
        
        Args:
            pretty_print: Whether to format JSON with indentation
            indent: Number of spaces for indentation
        """
        self.pretty_print = pretty_print
        self.indent = indent if pretty_print else None
    
    def write(self, jobs: List[Job], output_dir: str):
        """
        Write jobs to output directory with all sort variants.
        
        Args:
            jobs: List of jobs to write
            output_dir: Output directory path
        """
        output_path = Path(output_dir)
        jobs_dir = output_path / "jobs"
        jobs_dir.mkdir(parents=True, exist_ok=True)
        
        # Write main jobs.json
        self.write_jobs(jobs, str(jobs_dir / "jobs.json"))
        
        # Write sorted variants
        self.write_sorted_jobs(jobs, str(jobs_dir))
    
    def write_jobs(self, jobs: List[Job], file_path: str):
        """
        Write main jobs.json file.
        
        Args:
            jobs: List of jobs to write
            file_path: Output file path
            
        Raises:
            PermissionError: If write permission is denied
            OSError: If disk space is exhausted or other I/O error occurs
        """
        jobs_data = [self._job_to_dict(job) for job in jobs]
        
        try:
            with open(file_path, 'w') as f:
                json.dump(jobs_data, f, indent=self.indent)
        except PermissionError:
            raise PermissionError(
                f"Permission denied writing to {file_path}. "
                f"Check directory permissions and try again."
            )
        except OSError as e:
            if e.errno == 28:  # ENOSPC - No space left on device
                raise OSError(
                    f"Insufficient disk space to write {file_path}. "
                    f"Free up disk space and try again."
                )
            else:
                raise OSError(
                    f"Failed to write {file_path}: {e}. "
                    f"Check disk space and permissions."
                )
    
    def write_sorted_jobs(self, jobs: List[Job], output_dir: str):
        """
        Write sorted variants (by name, type, complexity).
        
        Args:
            jobs: List of jobs to write
            output_dir: Output directory path
        """
        output_path = Path(output_dir)
        
        # Sort by name
        jobs_by_name = sorted(jobs, key=lambda j: j.job_name)
        self._write_jobs(jobs_by_name, str(output_path / "jobs_by_name.json"))
        
        # Sort by type (APPLICATION first, then INFRASTRUCTURE)
        jobs_by_type = sorted(jobs, key=lambda j: (j.job_type, j.job_name))
        self._write_jobs(jobs_by_type, str(output_path / "jobs_by_type.json"))
        
        # Sort by complexity (number of steps, descending)
        jobs_by_complexity = sorted(
            jobs,
            key=lambda j: len(j.steps),
            reverse=True
        )
        self._write_jobs(jobs_by_complexity, str(output_path / "jobs_by_complexity.json"))
    
    def _write_jobs(self, jobs: List[Job], file_path: str):
        """
        Write jobs to a JSON file.
        
        Args:
            jobs: List of jobs to write
            file_path: Output file path
            
        Raises:
            PermissionError: If write permission is denied
            OSError: If disk space is exhausted or other I/O error occurs
        """
        jobs_data = [self._job_to_dict(job) for job in jobs]
        
        try:
            with open(file_path, 'w') as f:
                json.dump(jobs_data, f, indent=self.indent)
        except PermissionError:
            raise PermissionError(
                f"Permission denied writing to {file_path}. "
                f"Check directory permissions and try again."
            )
        except OSError as e:
            if e.errno == 28:  # ENOSPC - No space left on device
                raise OSError(
                    f"Insufficient disk space to write {file_path}. "
                    f"Free up disk space and try again."
                )
            else:
                raise OSError(
                    f"Failed to write {file_path}: {e}. "
                    f"Check disk space and permissions."
                )
    
    def _job_to_dict(self, job: Job) -> dict:
        """
        Convert Job object to dictionary for JSON serialization.
        
        Args:
            job: Job object to convert
            
        Returns:
            Dictionary representation of job
        """
        return {
            "jobName": job.job_name,
            "jobType": job.job_type,
            "hasCustomCode": job.has_custom_code,
            "linkedFlow": job.linked_flow,
            "steps": [
                {
                    "stepName": step.step_name,
                    "program": step.program,
                    "type": step.type,
                    "purpose": step.purpose,
                    "flowEntry": step.flow_entry
                }
                for step in job.steps
            ],
            "datasets": job.datasets,
            "dependencies": {
                "mustRunAfter": job.dependencies.must_run_after,
                "mustRunBefore": job.dependencies.must_run_before
            }
        }
