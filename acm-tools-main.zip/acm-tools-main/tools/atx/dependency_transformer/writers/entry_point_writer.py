"""
Entry point writer for ATX Dependency Transformer.

Writes entry points to JSON and CSV files.
"""

import json
import csv
from pathlib import Path
from typing import List
from ..models.legacy_models import EntryPointRecord


class EntryPointWriter:
    """
    Writes entry points to JSON and CSV files.
    
    Generates:
    - entry_points.json: Main entry points file
    - exports/entry_points.csv: CSV export
    """
    
    def __init__(self, pretty_print: bool = True, indent: int = 2):
        """
        Initialize EntryPointWriter.
        
        Args:
            pretty_print: Whether to format JSON with indentation
            indent: Number of spaces for indentation
        """
        self.pretty_print = pretty_print
        self.indent = indent if pretty_print else None
    
    def write(self, entry_points: List[EntryPointRecord], output_dir: str):
        """
        Write entry points to output directory in JSON and CSV formats.
        
        Args:
            entry_points: List of entry points to write
            output_dir: Output directory path
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Write JSON file
        self.write_json(entry_points, str(output_path / "entry_points.json"))
        
        # Write CSV file
        exports_dir = output_path / "exports"
        exports_dir.mkdir(parents=True, exist_ok=True)
        self.write_csv(entry_points, str(exports_dir / "entry_points.csv"))
    
    def write_json(self, entry_points: List[EntryPointRecord], file_path: str):
        """
        Write entry_points.json file.
        
        Args:
            entry_points: List of entry points to write
            file_path: Output file path
            
        Raises:
            PermissionError: If write permission is denied
            OSError: If disk space is exhausted or other I/O error occurs
        """
        entry_points_data = [self._entry_point_to_dict(ep) for ep in entry_points]
        
        try:
            with open(file_path, 'w') as f:
                json.dump(entry_points_data, f, indent=self.indent)
        except PermissionError:
            raise PermissionError(
                f"Permission denied writing to {file_path}. "
                f"Check directory permissions and try again."
            )
        except OSError as e:
            if e.errno == 28:  # ENOSPC - No space left on device
                raise OSError(
                    f"Insufficient disk space to write {file_path}. "
                    f"Free up disk space and try again."
                )
            else:
                raise OSError(
                    f"Failed to write {file_path}: {e}. "
                    f"Check disk space and permissions."
                )
    
    def write_csv(self, entry_points: List[EntryPointRecord], file_path: str):
        """
        Write entry_points.csv export.
        
        Args:
            entry_points: List of entry points to write
            file_path: Output file path
            
        Raises:
            PermissionError: If write permission is denied
            OSError: If disk space is exhausted or other I/O error occurs
        """
        try:
            if not entry_points:
                # Write empty CSV with headers
                with open(file_path, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        "program_name",
                        "entry_type",
                        "confidence",
                        "source",
                        "description",
                        "transaction_id",
                        "jcl_name",
                        "status"
                    ])
                return
            
            with open(file_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=[
                    "program_name",
                    "entry_type",
                    "confidence",
                    "source",
                    "description",
                    "transaction_id",
                    "jcl_name",
                    "status"
                ])
                
                writer.writeheader()
                
                for ep in entry_points:
                    writer.writerow({
                        "program_name": ep.program_name,
                        "entry_type": ep.entry_type,
                        "confidence": ep.confidence,
                        "source": ep.source,
                        "description": self._sanitize_csv_field(ep.description or ""),
                        "transaction_id": self._sanitize_csv_field(ep.transaction_id or ""),
                        "jcl_name": self._sanitize_csv_field(ep.jcl_name or ""),
                        "status": ep.status or ""
                    })
        except PermissionError:
            raise PermissionError(
                f"Permission denied writing to {file_path}. "
                f"Check directory permissions and try again."
            )
        except OSError as e:
            if e.errno == 28:  # ENOSPC - No space left on device
                raise OSError(
                    f"Insufficient disk space to write {file_path}. "
                    f"Free up disk space and try again."
                )
            else:
                raise OSError(
                    f"Failed to write {file_path}: {e}. "
                    f"Check disk space and permissions."
                )
    
    def _sanitize_csv_field(self, value: str) -> str:
        """
        Sanitize field value for CSV output.
        
        Replaces problematic characters that CSV module normalizes:
        - \r (carriage return) -> space
        - \n (newline) -> space
        
        Args:
            value: Field value to sanitize
            
        Returns:
            Sanitized value safe for CSV
        """
        return value.replace('\r', ' ').replace('\n', ' ')
    
    def _entry_point_to_dict(self, entry_point: EntryPointRecord) -> dict:
        """
        Convert EntryPointRecord object to dictionary for JSON serialization.
        
        Args:
            entry_point: EntryPointRecord object to convert
            
        Returns:
            Dictionary representation of entry point
        """
        result = {
            "programName": entry_point.program_name,
            "entryType": entry_point.entry_type,
            "confidence": entry_point.confidence,
            "source": entry_point.source
        }
        
        # Add optional fields only if they have values
        # Sanitize fields to match CSV output
        if entry_point.description:
            result["description"] = self._sanitize_csv_field(entry_point.description)
        
        if entry_point.transaction_id:
            result["transactionId"] = self._sanitize_csv_field(entry_point.transaction_id)
        
        if entry_point.jcl_name:
            result["jclName"] = self._sanitize_csv_field(entry_point.jcl_name)
        
        if entry_point.status:
            result["status"] = entry_point.status
        
        return result
