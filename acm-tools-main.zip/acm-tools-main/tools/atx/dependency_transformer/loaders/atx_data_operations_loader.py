"""
ATX Data Operations Loader.

Loads and parses ATX program_to_dsn.json file, providing indexed access
to data operations with access types.
"""

import json
from pathlib import Path
from typing import List, Dict, Optional
from ..models.atx_models import ATXDataOperation


class ATXDataOperationsLoader:
    """
    Loads and parses ATX program_to_dsn.json file.
    
    Provides indexed access to data operations showing which programs
    access which datasets and how (READ, WRITE, UPDATE).
    """
    
    def __init__(self):
        """Initialize the loader."""
        self._operations: List[ATXDataOperation] = []
        self._by_program: Dict[str, List[ATXDataOperation]] = {}
        self._loaded = False
    
    def load(self, file_path: str) -> List[ATXDataOperation]:
        """
        Load data operations from JSON file.
        
        Args:
            file_path: Path to program_to_dsn.json file
            
        Returns:
            List of ATXDataOperation objects
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If JSON is malformed or invalid
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Data operations file not found: {file_path}")
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except PermissionError:
            raise PermissionError(
                f"Permission denied reading data operations file: {file_path}. "
                f"Check file permissions and try again."
            )
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Invalid JSON in {file_path} at line {e.lineno}, column {e.colno}: {e.msg}. "
                f"Please verify the file is valid JSON format."
            )
        
        if not isinstance(data, list):
            raise ValueError(
                f"Schema mismatch in {file_path}: Expected a JSON array (list) at root level, "
                f"but got {type(data).__name__}. The program_to_dsn.json file should contain "
                f"an array of data operation objects."
            )
        
        # Parse operations
        self._operations = []
        skipped_count = 0
        for idx, item in enumerate(data):
            try:
                # Validate required fields
                if not isinstance(item, dict):
                    print(f"Warning: Skipping entry {idx}: Expected object, got {type(item).__name__}")
                    skipped_count += 1
                    continue
                
                file_name = item.get('fileName', '')
                if not file_name:
                    print(f"Warning: Skipping entry {idx}: Missing required field 'fileName'")
                    skipped_count += 1
                    continue
                
                op = ATXDataOperation(
                    file_name=file_name,
                    file_path=item.get('filePath', ''),
                    data_source_name=item.get('dataSourceName', ''),
                    dd_name=item.get('ddName'),
                    logical_name=item.get('logicalName'),
                    copybook_record_name=item.get('copybookRecordName'),
                    copybook_file_path=item.get('copybookFilePath'),
                    data_source_type=item.get('dataSourceType'),
                    access_type=item.get('accessType', '')
                )
                self._operations.append(op)
            except (ValueError, KeyError) as e:
                # Log warning but continue processing
                print(f"Warning: Skipping invalid data operation entry at index {idx} (fileName: {item.get('fileName', 'unknown')}): {e}")
                skipped_count += 1
                continue
        
        if skipped_count > 0:
            print(f"Warning: Skipped {skipped_count} invalid entries out of {len(data)} total entries")
        
        # Build index by program name
        self._build_index()
        self._loaded = True
        
        return self._operations
    
    def _build_index(self):
        """Build internal index for fast lookups by program name."""
        self._by_program = {}
        
        for op in self._operations:
            if op.file_name not in self._by_program:
                self._by_program[op.file_name] = []
            self._by_program[op.file_name].append(op)
    
    def get_operations_for_program(self, program_name: str) -> List[ATXDataOperation]:
        """
        Get all data operations for a specific program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            List of data operations for the program
        """
        return self._by_program.get(program_name, [])
    
    def get_access_types(self, program_name: str, dataset_name: str) -> List[str]:
        """
        Get access types (READ/WRITE/UPDATE) for a program-dataset pair.
        
        Args:
            program_name: Name of the program
            dataset_name: Name of the dataset
            
        Returns:
            List of access types (e.g., ['READ', 'WRITE'])
        """
        operations = self.get_operations_for_program(program_name)
        
        for op in operations:
            if op.data_source_name == dataset_name:
                return op.get_access_types()
        
        return []
    
    def get_all_operations(self) -> List[ATXDataOperation]:
        """
        Get all loaded data operations.
        
        Returns:
            List of all data operations
        """
        return self._operations
    
    def get_datasets_for_program(self, program_name: str) -> List[str]:
        """
        Get all datasets accessed by a program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            List of dataset names
        """
        operations = self.get_operations_for_program(program_name)
        return list(set(op.data_source_name for op in operations))
    
    def is_loaded(self) -> bool:
        """
        Check if data operations have been loaded.
        
        Returns:
            True if load() has been called successfully
        """
        return self._loaded
