"""
ATX Assets Loader.

Loads and parses ATX assets.csv file, providing indexed access
to code metrics (CC, LOC, comments).
"""

import csv
from pathlib import Path
from typing import Dict, Optional
from ..models.atx_models import ATXAssetMetrics


class ATXAssetsLoader:
    """
    Loads and parses ATX assets.csv file.
    
    Provides indexed access to code metrics including:
    - Cyclomatic complexity
    - Lines of code (total, effective, empty, comment)
    - File type information
    """
    
    def __init__(self):
        """Initialize the loader."""
        self._metrics: Dict[str, ATXAssetMetrics] = {}
        self._loaded = False
    
    def load(self, file_path: str) -> Dict[str, ATXAssetMetrics]:
        """
        Load assets from CSV file, indexed by program name.
        
        Args:
            file_path: Path to assets.csv file
            
        Returns:
            Dictionary mapping program names to ATXAssetMetrics
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If CSV is malformed or invalid
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Assets file not found: {file_path}")
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                
                # Verify required columns exist
                if not reader.fieldnames:
                    raise ValueError(
                        f"CSV file {file_path} has no headers. "
                        f"Expected CSV with headers: Name, Path, File type, etc."
                    )
                
                required_fields = ['Name', 'Path', 'File type']
                missing_fields = [f for f in required_fields if f not in reader.fieldnames]
                if missing_fields:
                    raise ValueError(
                        f"Schema mismatch in {file_path}: Missing required columns: {', '.join(missing_fields)}. "
                        f"Found columns: {', '.join(reader.fieldnames)}"
                    )
                
                # Parse rows
                self._metrics = {}
                skipped_count = 0
                for row_num, row in enumerate(reader, start=2):  # Start at 2 (header is row 1)
                    try:
                        name = row.get('Name', '').strip()
                        if not name:
                            print(f"Warning: Skipping row {row_num} in {file_path}: Empty name field")
                            skipped_count += 1
                            continue
                        
                        # Parse numeric fields with defaults
                        def parse_int(value: str, default: int = 0) -> int:
                            try:
                                return int(value) if value else default
                            except ValueError:
                                return default
                        
                        metrics = ATXAssetMetrics(
                            name=name,
                            path=row.get('Path', ''),
                            file_type=row.get('File type', ''),
                            cyclomatic_complexity=parse_int(row.get('Cyclomatic Complexity', '0')),
                            total_lines=parse_int(row.get('Total lines', '0')),
                            empty_lines=parse_int(row.get('Empty Lines', '0')),
                            effective_lines=parse_int(row.get('Effective Lines', '0')),
                            comment_lines=parse_int(row.get('Comment Lines', '0'))
                        )
                        
                        self._metrics[name] = metrics
                        
                    except (ValueError, KeyError) as e:
                        print(f"Warning: Skipping invalid row {row_num} in {file_path}: {e}")
                        skipped_count += 1
                        continue
                
                if skipped_count > 0:
                    print(f"Warning: Skipped {skipped_count} invalid rows in {file_path}")
                
        except PermissionError:
            raise PermissionError(
                f"Permission denied reading assets file: {file_path}. "
                f"Check file permissions and try again."
            )
        except csv.Error as e:
            raise ValueError(
                f"Invalid CSV format in {file_path}: {e}. "
                f"Please verify the file is a valid CSV with proper formatting."
            )
        
        self._loaded = True
        return self._metrics
    
    def get_metrics(self, program_name: str) -> Optional[ATXAssetMetrics]:
        """
        Get metrics for a specific program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            ATXAssetMetrics if found, None otherwise
        """
        return self._metrics.get(program_name)
    
    def get_cyclomatic_complexity(self, program_name: str) -> int:
        """
        Get cyclomatic complexity for a program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            Cyclomatic complexity value, or 0 if not found
        """
        metrics = self._metrics.get(program_name)
        return metrics.cyclomatic_complexity if metrics else 0
    
    def get_total_lines(self, program_name: str) -> int:
        """
        Get total lines of code for a program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            Total lines value, or 0 if not found
        """
        metrics = self._metrics.get(program_name)
        return metrics.total_lines if metrics else 0
    
    def get_all_metrics(self) -> Dict[str, ATXAssetMetrics]:
        """
        Get all loaded metrics.
        
        Returns:
            Dictionary mapping program names to metrics
        """
        return self._metrics
    
    def is_loaded(self) -> bool:
        """
        Check if assets have been loaded.
        
        Returns:
            True if load() has been called successfully
        """
        return self._loaded

