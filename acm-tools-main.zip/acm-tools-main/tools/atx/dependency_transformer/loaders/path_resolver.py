"""
Path resolver for mapping ATX file paths to local filesystem paths.

This module implements efficient path resolution with caching and prefix detection.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class PathResolver:
    """
    Resolves ATX file paths to local filesystem paths.
    
    The resolver implements an efficient algorithm:
    1. Detects the root path prefix from the first matching file
    2. Caches the prefix mapping for subsequent resolutions
    3. Caches individual resolved paths to avoid redundant filesystem searches
    
    Example:
        Input:  aws-mainframe-modernization-carddemo-main/app/cbl/COMEN01C.cbl
        Search: ./examples/code/cobol/carddemoV2/app/cbl/COMEN01C.cbl (found!)
        Mapping: aws-mainframe-modernization-carddemo-main → ./examples/code/cobol/carddemoV2
        Output: ./examples/code/cobol/carddemoV2/app/cbl/COMEN01C.cbl
    """
    
    def __init__(self, search_paths: Optional[List[str]] = None):
        """
        Initialize PathResolver with optional search paths.
        
        Args:
            search_paths: List of directories to search for files.
                         Defaults to ['.', './examples/code']
        """
        self.search_paths = search_paths or ['.', './examples/code']
        self._prefix_mappings: Dict[str, str] = {}
        self._resolved_cache: Dict[str, Optional[str]] = {}
        self._missing_files: Set[str] = set()
        
        logger.info(f"PathResolver initialized with search paths: {self.search_paths}")
    
    def resolve_path(self, atx_path: str) -> Optional[str]:
        """
        Resolve an ATX path to a local filesystem path.
        
        Args:
            atx_path: Path from ATX input (e.g., 'aws-mainframe-modernization-carddemo-main/app/cbl/COMEN01C.cbl')
            
        Returns:
            Resolved local path (e.g., './examples/code/cobol/carddemoV2/app/cbl/COMEN01C.cbl')
            or None if file not found
        """
        # Check cache first
        if atx_path in self._resolved_cache:
            return self._resolved_cache[atx_path]
        
        # Check if we've already determined this file is missing
        if atx_path in self._missing_files:
            return None
        
        # Try to resolve using existing prefix mappings
        for atx_prefix, local_prefix in self._prefix_mappings.items():
            if atx_path.startswith(atx_prefix):
                # Replace prefix and check if file exists
                relative_path = atx_path[len(atx_prefix):].lstrip('/')
                resolved_path = str(Path(local_prefix) / relative_path)
                
                if Path(resolved_path).exists():
                    self._resolved_cache[atx_path] = resolved_path
                    logger.debug(f"Resolved (cached prefix): {atx_path} -> {resolved_path}")
                    return resolved_path
        
        # No cached prefix worked, perform filesystem search
        resolved_path = self._search_filesystem(atx_path)
        
        if resolved_path:
            self._resolved_cache[atx_path] = resolved_path
            logger.debug(f"Resolved (filesystem search): {atx_path} -> {resolved_path}")
        else:
            self._missing_files.add(atx_path)
            self._resolved_cache[atx_path] = None
            logger.warning(f"Could not resolve path: {atx_path}")
        
        return resolved_path
    
    def _search_filesystem(self, atx_path: str) -> Optional[str]:
        """
        Search the filesystem for a file matching the ATX path structure.
        
        This method:
        1. Parses the ATX path into components
        2. Searches each search path for a matching file
        3. When found, extracts and caches the prefix mapping
        
        Args:
            atx_path: ATX file path to search for
            
        Returns:
            Resolved local path or None if not found
        """
        # Parse ATX path into components
        path_parts = Path(atx_path).parts
        
        if not path_parts:
            return None
        
        # Try different prefix lengths (start with full path, then remove first component)
        for prefix_length in range(len(path_parts), 0, -1):
            atx_prefix = str(Path(*path_parts[:prefix_length]))
            relative_suffix = str(Path(*path_parts[prefix_length:])) if prefix_length < len(path_parts) else ""
            
            # Search each configured search path
            for search_path in self.search_paths:
                search_base = Path(search_path)
                
                if not search_base.exists():
                    continue
                
                # Try to find the file by walking the directory tree
                try:
                    for candidate_path in search_base.rglob('*'):
                        if not candidate_path.is_file():
                            continue
                        
                        # Check if this file matches the relative structure
                        candidate_str = str(candidate_path)
                        
                        # Build the expected suffix path
                        if relative_suffix:
                            expected_suffix = str(Path(relative_suffix))
                            if candidate_str.endswith(expected_suffix):
                                # Found a match! Extract the prefix mapping
                                local_prefix = candidate_str[:-len(expected_suffix)].rstrip('/')
                                
                                # Cache the prefix mapping
                                if atx_prefix not in self._prefix_mappings:
                                    self._prefix_mappings[atx_prefix] = local_prefix
                                    logger.info(f"Detected prefix mapping: {atx_prefix} -> {local_prefix}")
                                
                                return candidate_str
                        else:
                            # No suffix, check if filename matches
                            if candidate_path.name == Path(atx_path).name:
                                # Found a match! Extract the prefix mapping
                                local_prefix = str(candidate_path.parent)
                                
                                # Cache the prefix mapping
                                if atx_prefix not in self._prefix_mappings:
                                    self._prefix_mappings[atx_prefix] = local_prefix
                                    logger.info(f"Detected prefix mapping: {atx_prefix} -> {local_prefix}")
                                
                                return str(candidate_path)
                
                except (PermissionError, OSError) as e:
                    logger.debug(f"Error searching {search_path}: {e}")
                    continue
        
        return None
    
    def resolve_batch(self, atx_paths: List[str]) -> Dict[str, Optional[str]]:
        """
        Resolve multiple ATX paths efficiently.
        
        Uses caching and path prefix detection to minimize filesystem searches.
        
        Args:
            atx_paths: List of ATX paths to resolve
            
        Returns:
            Dictionary mapping ATX paths to resolved local paths (or None if not found)
        """
        results = {}
        
        for atx_path in atx_paths:
            results[atx_path] = self.resolve_path(atx_path)
        
        return results
    
    def get_path_mapping(self) -> Dict[str, str]:
        """
        Get the detected path prefix mappings.
        
        Returns:
            Dictionary mapping ATX prefix to local prefix
            (e.g., {'aws-mainframe-modernization-carddemo-main': './examples/code/cobol/carddemoV2'})
        """
        return self._prefix_mappings.copy()
    
    def clear_cache(self):
        """Clear the resolved path cache and prefix mappings."""
        self._resolved_cache.clear()
        self._prefix_mappings.clear()
        self._missing_files.clear()
        logger.info("PathResolver cache cleared")
    
    def get_statistics(self) -> Dict[str, int]:
        """
        Get statistics about path resolution.
        
        Returns:
            Dictionary with cache hits, misses, and missing files count
        """
        return {
            'cached_paths': len(self._resolved_cache),
            'prefix_mappings': len(self._prefix_mappings),
            'missing_files': len(self._missing_files),
        }
