"""
ATX Dependency Loader.

Loads and parses ATX dependencies.json file, providing indexed access
to programs, transactions, JCL, calls, copybooks, and datasets.
"""

import json
from pathlib import Path
from typing import List, Dict, Set, Optional
from ..models.atx_models import ATXDependency


class ATXDependencyLoader:
    """
    Loads and parses ATX dependencies.json file.
    
    Provides indexed access to:
    - Programs (COB type)
    - Transactions (TRANSACTION type)
    - JCL jobs (JCL type)
    - Program calls
    - Copybooks
    - Datasets
    """
    
    def __init__(self):
        """Initialize the loader."""
        self._dependencies: List[ATXDependency] = []
        self._by_name: Dict[str, ATXDependency] = {}
        self._by_type: Dict[str, List[ATXDependency]] = {}
        self._loaded = False
    
    def load(self, file_path: str) -> List[ATXDependency]:
        """
        Load dependencies from JSON file.
        
        Args:
            file_path: Path to dependencies.json file
            
        Returns:
            List of ATXDependency objects
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If JSON is malformed or invalid
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Dependencies file not found: {file_path}")
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except PermissionError:
            raise PermissionError(
                f"Permission denied reading dependencies file: {file_path}. "
                f"Check file permissions and try again."
            )
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Invalid JSON in {file_path} at line {e.lineno}, column {e.colno}: {e.msg}. "
                f"Please verify the file is valid JSON format."
            )
        
        if not isinstance(data, list):
            raise ValueError(
                f"Schema mismatch in {file_path}: Expected a JSON array (list) at root level, "
                f"but got {type(data).__name__}. The dependencies.json file should contain "
                f"an array of dependency objects."
            )
        
        # Parse dependencies
        self._dependencies = []
        skipped_count = 0
        for idx, item in enumerate(data):
            try:
                # Validate required fields
                if not isinstance(item, dict):
                    print(f"Warning: Skipping entry {idx}: Expected object, got {type(item).__name__}")
                    skipped_count += 1
                    continue
                
                name = item.get('name', '')
                if not name:
                    print(f"Warning: Skipping entry {idx}: Missing required field 'name'")
                    skipped_count += 1
                    continue
                
                dep = ATXDependency(
                    name=name,
                    path=item.get('path', ''),
                    type=item.get('type', ''),
                    dependencies=item.get('dependencies', [])
                )
                self._dependencies.append(dep)
            except (ValueError, KeyError) as e:
                # Log warning but continue processing
                print(f"Warning: Skipping invalid dependency entry at index {idx} (name: {item.get('name', 'unknown')}): {e}")
                skipped_count += 1
                continue
        
        if skipped_count > 0:
            print(f"Warning: Skipped {skipped_count} invalid entries out of {len(data)} total entries")
        
        # Build indexes
        self._build_indexes()
        self._loaded = True
        
        return self._dependencies
    
    def _build_indexes(self):
        """Build internal indexes for fast lookups."""
        self._by_name = {}
        self._by_type = {}
        
        for dep in self._dependencies:
            # Index by name
            self._by_name[dep.name] = dep
            
            # Index by type
            if dep.type not in self._by_type:
                self._by_type[dep.type] = []
            self._by_type[dep.type].append(dep)
    
    def get_programs(self) -> List[ATXDependency]:
        """
        Extract all program entries (COB type).
        
        Returns:
            List of program dependencies
        """
        return self._by_type.get('COB', [])
    
    def get_transactions(self) -> List[ATXDependency]:
        """
        Extract all CICS transaction entries (TRANSACTION type).
        
        Returns:
            List of transaction dependencies
        """
        return self._by_type.get('TRANSACTION', [])
    
    def get_jcl_jobs(self) -> List[ATXDependency]:
        """
        Extract all JCL entries (JCL type).
        
        Returns:
            List of JCL dependencies
        """
        return self._by_type.get('JCL', [])
    
    def get_by_name(self, name: str) -> Optional[ATXDependency]:
        """
        Get dependency by name.
        
        Args:
            name: Dependency name
            
        Returns:
            ATXDependency if found, None otherwise
        """
        return self._by_name.get(name)
    
    def get_by_type(self, dep_type: str) -> List[ATXDependency]:
        """
        Get all dependencies of a specific type.
        
        Args:
            dep_type: Dependency type (e.g., 'COB', 'JCL', 'TRANSACTION')
            
        Returns:
            List of dependencies of the specified type
        """
        return self._by_type.get(dep_type, [])
    
    def get_program_calls(self, program_name: str) -> List[str]:
        """
        Get all programs called by the given program.
        
        Args:
            program_name: Name of the calling program
            
        Returns:
            List of called program names
        """
        dep = self._by_name.get(program_name)
        if not dep:
            return []
        
        calls = []
        for dependency in dep.dependencies:
            dep_type = dependency.get('dependencyType', '')
            # Check for various call patterns
            if ('Call' in dep_type or 'call' in dep_type.lower() or
                'Start program' in dep_type or 'Exec program' in dep_type):
                called_name = dependency.get('name', '')
                if called_name:
                    calls.append(called_name)
        
        return calls
    
    def get_copybooks(self, program_name: str) -> List[str]:
        """
        Get all copybooks used by the given program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            List of copybook names
        """
        dep = self._by_name.get(program_name)
        if not dep:
            return []
        
        copybooks = []
        for dependency in dep.dependencies:
            dep_type = dependency.get('dependencyType', '')
            dep_obj_type = dependency.get('type', '')
            # Check for copybook patterns
            if ('Copy' in dep_type or 'copybook' in dep_type.lower() or
                dep_obj_type == 'CPY'):
                copybook_name = dependency.get('name', '')
                if copybook_name:
                    copybooks.append(copybook_name)
        
        return copybooks
    
    def get_datasets(self, program_name: str) -> List[str]:
        """
        Get all datasets referenced by the given program.
        
        Args:
            program_name: Name of the program
            
        Returns:
            List of dataset names
        """
        dep = self._by_name.get(program_name)
        if not dep:
            return []
        
        datasets = []
        for dependency in dep.dependencies:
            dep_type = dependency.get('dependencyType', '')
            name = dependency.get('name', '')
            dep_obj_type = dependency.get('type', '')
            
            # Check if it's a dataset reference
            if ('Dataset' in dep_type or 'dataset' in dep_type.lower() or
                'DATASET' in dep_obj_type or 'VSAM' in dep_obj_type or
                'PS' in dep_obj_type):
                if name:
                    datasets.append(name)
        
        return datasets
    
    def get_all_dependencies(self) -> List[ATXDependency]:
        """
        Get all loaded dependencies.
        
        Returns:
            List of all dependencies
        """
        return self._dependencies
    
    def is_loaded(self) -> bool:
        """
        Check if dependencies have been loaded.
        
        Returns:
            True if load() has been called successfully
        """
        return self._loaded
