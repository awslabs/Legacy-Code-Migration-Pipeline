# ATX Dependency Transformer - Improvement Plan

## Executive Summary

The ATX Dependency Transformer achieves a **50% overall match** with legacy_analyzer outputs, but this is misleading. When analyzed by component:

- **Flows**: 78.8% match (26/33 common flows)
- **Jobs**: 70.5% match (31/44 common jobs) 
- **Entry Points**: 41.0% match (25/61 common programs)

The low overall percentage is primarily due to **different design philosophies** rather than bugs or missing functionality.

## Root Cause Analysis

### 1. Flow Differences (78.8% match - GOOD)

**Issue**: ATX generates 50 flows vs Legacy's 33 flows

**Root Causes**:
- **Different entry point detection**: ATX creates flows for JCL files (BUILDBAT.jcl, BUILDBMS.jcl) while legacy_analyzer only creates flows for program entry points
- **ATX includes 7 JCL-based flows** that legacy doesn't recognize as flows
- **Legacy includes 7 different JCL-based flows** (COBSWAIT, DFHECP1$, FTP, IEWL, IGYCRCTL)

**Why This Happens**:
- ATX dependencies.json includes JCL files as dependencies with type="JCL"
- The transformer treats these as entry points and creates flows
- Legacy analyzer parses actual JCL source files and extracts different programs

**Impact**: Minimal - both approaches are valid, just different philosophies

### 2. Job Differences (70.5% match - EXCELLENT)

**Issue**: ATX generates 32 jobs vs Legacy's 44 jobs

**Root Causes**:
- **Missing JCL files in ATX data**: Legacy found 13 more JCL files
  - CICDBCMP, DEFGDGD, ESDSRRDS, FTPJCL, IMSMQCMP, etc.
- **Job type classification differences**: 11 jobs have type mismatches
  - Example: CBADMCDJ is APPLICATION in ATX but INFRASTRUCTURE in legacy
  - This is due to different utility program lists

**Why This Happens**:
- ATX dependencies.json may not include all JCL files that exist in the codebase
- Different utility program classification logic

**Impact**: Moderate - missing JCL files means incomplete job coverage

### 3. Entry Point Differences (41.0% match - NEEDS IMPROVEMENT)

**Issue**: ATX generates 61 entry points vs Legacy's 37 entry points

**Root Causes**:
- **ATX over-generates inferred entry points**: 36 ATX-only entry points are JCL files marked as INFERRED
  - These should probably be BATCH entry points, not INFERRED
- **Legacy has better inference logic**: Legacy found 4 inferred entry points (ASMWAIT, CBTRN01C, COCDATFT, CSUTLDPY) that ATX missed
- **Missing CICS transaction**: Legacy found COCRDSEC as ONLINE entry point, ATX didn't

**Why This Happens**:
- ATX transformer incorrectly classifies JCL files as INFERRED instead of BATCH
- ATX call graph analysis doesn't detect all programs with no callers
- ATX dependencies.json may be missing some CICS transaction definitions

**Impact**: High - incorrect entry point classification affects migration planning

## Improvement Recommendations

### Priority 1: Fix Entry Point Classification (HIGH IMPACT)

**Problem**: JCL files are being classified as INFERRED entry points instead of BATCH

**Solution**:
```python
# In EntryPointTransformer._extract_jcl_entry_points()
# Change logic to properly identify JCL-based entry points

def _extract_jcl_entry_points(self) -> List[EntryPoint]:
    """Extract BATCH entry points from JCL types."""
    entry_points = []
    
    for jcl in self.dependency_loader.get_jcl_jobs():
        # Get programs executed by this JCL
        programs = self.dependency_loader.get_program_calls(jcl.name)
        
        for program in programs:
            entry_points.append(EntryPoint(
                programName=program,
                entryType="BATCH",  # Not INFERRED!
                confidence="EXPLICIT",  # Not INFERRED!
                source="JCL",
                description=f"Executed by JCL {jcl.name}",
                jclName=jcl.name,
                status="ENABLED"
            ))
    
    return entry_points
```

**Expected Impact**: Entry point match would improve from 41% to ~70%

### Priority 2: Add Configuration for Flow Filtering (MEDIUM IMPACT)

**Problem**: Different use cases need different flow definitions

**Solution**: Add configuration option to control what gets generated as a flow

```yaml
# config/atx_transformer.yaml
transformation:
  flow_generation:
    include_jcl_flows: true          # Generate flows for JCL files
    include_procedure_flows: false   # Don't generate flows for procedures
    include_utility_flows: false     # Don't generate flows for utility programs
    
  entry_point_detection:
    include_inferred: true           # Include inferred entry points
    inferred_confidence_threshold: 0.8  # Confidence threshold for inference
```

**Expected Impact**: Users can match legacy_analyzer behavior or customize for their needs

### Priority 3: Improve Utility Program Classification (MEDIUM IMPACT)

**Problem**: 11 jobs have type mismatches due to different utility program lists

**Solution**: Enhance the default utility program list in config

```yaml
# config/atx_transformer.yaml
utility_programs:
  # IBM utilities
  - IDCAMS
  - IEFBR14
  - IEBGENER
  - IEBCOPY
  - SORT
  - DFSORT
  - ICETOOL
  
  # Compilers and linkers
  - IGYCRCTL  # COBOL compiler
  - HEWL      # Linkage editor
  - IEWL      # Linkage editor
  - ASMA90    # Assembler
  
  # CICS utilities
  - DFHCSDUP
  - DFHECP1$
  
  # Custom utilities (user-configurable)
  - CSUTLDPY
  - COBSWAIT
```

**Expected Impact**: Job type classification would match legacy_analyzer more closely

### Priority 4: Enhance Inferred Entry Point Detection (LOW IMPACT)

**Problem**: ATX misses 4 inferred entry points that legacy found

**Solution**: Improve call graph analysis to detect programs with no callers

```python
# In CallGraphAnalyzer.find_entry_points()
def find_entry_points(self) -> List[str]:
    """Find programs with no inbound calls (inferred entry points)."""
    all_programs = set(self.call_graph.nodes())
    called_programs = set()
    
    for caller in self.call_graph.nodes():
        for callee in self.call_graph.successors(caller):
            called_programs.add(callee)
    
    # Programs with no callers
    entry_points = all_programs - called_programs
    
    # Filter out utility programs
    entry_points = [
        p for p in entry_points 
        if p not in self.config.utility_programs
    ]
    
    return sorted(entry_points)
```

**Expected Impact**: Would find the 4 missing inferred entry points

### Priority 5: Investigate Missing JCL Files (LOW IMPACT)

**Problem**: ATX dependencies.json is missing 13 JCL files that legacy found

**Solution**: This is a data quality issue with the ATX tool output, not the transformer

**Recommendation**: 
- Document that ATX transformer quality depends on ATX tool completeness
- Add validation warnings when JCL files are referenced but not found
- Provide guidance on ensuring complete ATX analysis

**Expected Impact**: Would improve job coverage if ATX data is more complete

## Implementation Priority

1. **Week 1**: Fix entry point classification (Priority 1)
   - Modify EntryPointTransformer
   - Add tests
   - Expected improvement: 41% → 70% entry point match

2. **Week 2**: Add flow filtering configuration (Priority 2)
   - Add config options
   - Update FlowTransformer
   - Add tests
   - Expected improvement: Customizable behavior

3. **Week 3**: Improve utility program classification (Priority 3)
   - Enhance default utility list
   - Add config validation
   - Expected improvement: 70.5% → 85% job match

4. **Week 4**: Enhance inferred entry point detection (Priority 4)
   - Improve CallGraphAnalyzer
   - Add tests
   - Expected improvement: Find 4 additional entry points

## Expected Final Results

After implementing all improvements:

| Component | Current Match | Expected Match | Improvement |
|-----------|--------------|----------------|-------------|
| Flows | 78.8% | 85-90% | +6-11% |
| Jobs | 70.5% | 85-90% | +15-20% |
| Entry Points | 41.0% | 70-75% | +29-34% |
| **Overall** | **50.0%** | **80-85%** | **+30-35%** |

## Alternative Approach: Alignment Mode

Add a special "legacy_analyzer_compatibility_mode" that:
- Filters out JCL flows
- Uses legacy's utility program list
- Matches legacy's entry point classification logic
- Produces outputs that are 90%+ compatible

```yaml
# config/atx_transformer.yaml
compatibility:
  mode: "legacy_analyzer"  # or "atx_native" or "custom"
  
  legacy_analyzer:
    exclude_jcl_flows: true
    exclude_procedure_flows: true
    use_legacy_utility_list: true
    match_entry_point_logic: true
```

This would allow users to choose between:
1. **ATX Native Mode**: Use ATX's philosophy (current behavior)
2. **Legacy Compatibility Mode**: Match legacy_analyzer as closely as possible
3. **Custom Mode**: User-defined configuration

## Conclusion

The 50% match rate is **not a bug** - it reflects different design philosophies:
- ATX is more inclusive (generates more flows and entry points)
- Legacy analyzer is more selective (only programs, not JCL files)

Both approaches are valid for different use cases. The improvements above will:
1. Fix actual bugs (entry point classification)
2. Add flexibility (configuration options)
3. Improve compatibility (better utility lists)
4. Provide user choice (compatibility modes)

**Recommendation**: Implement Priority 1 immediately (fixes a bug), then add Priority 2 (gives users control), then tackle the rest based on user feedback.
