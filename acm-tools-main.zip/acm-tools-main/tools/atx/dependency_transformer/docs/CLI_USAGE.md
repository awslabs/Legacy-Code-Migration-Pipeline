# ATX Dependency Transformer - CLI Usage Guide

## Overview

The ATX Dependency Transformer provides a command-line interface for transforming ATX tool outputs into legacy_analyzer-compatible format.

## Installation

The tool is part of the SMF Migration Toolkit and can be executed directly:

```bash
python -m tools.atx.dependency_transformer
```

## Commands

### Transform All

Transform all outputs (flows, jobs, and entry points):

```bash
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed
```

### Transform Flows Only

Transform only migration flows:

```bash
python -m tools.atx.dependency_transformer transform flows \
    --input-dir examples/atx \
    --output-dir results/flows
```

### Transform Jobs Only

Transform only batch jobs:

```bash
python -m tools.atx.dependency_transformer transform jobs \
    --input-dir examples/atx \
    --output-dir results/jobs
```

### Transform Entry Points Only

Transform only entry points:

```bash
python -m tools.atx.dependency_transformer transform entry-points \
    --input-dir examples/atx \
    --output-dir results/entry_points
```

## Options

### Required Options

- `--input-dir`: Directory containing ATX input files
  - Must contain: `dependencies.json`, `assets.csv`, `program_to_dsn.json`
  
- `--output-dir`: Directory for output files
  - Will be created if it doesn't exist

### Optional Options

- `--config`: Path to configuration YAML file
  - Uses default configuration if not specified
  - See `config/atx_transformer.yaml` for example

- `--dry-run`: Validate inputs without writing files
  - Useful for testing and validation
  - Shows what would be generated

- `--verbose`: Enable detailed output
  - Shows progress and warnings
  - Useful for debugging

## Examples

### Basic Usage

```bash
# Transform all with default settings
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed
```

### Dry Run

```bash
# Preview transformation without writing files
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed \
    --dry-run \
    --verbose
```

### Custom Configuration

```bash
# Use custom configuration file
python -m tools.atx.dependency_transformer transform all \
    --input-dir examples/atx \
    --output-dir results/atx_transformed \
    --config config/atx_transformer.yaml \
    --verbose
```

### Individual Transformations

```bash
# Transform only flows
python -m tools.atx.dependency_transformer transform flows \
    --input-dir examples/atx \
    --output-dir results/flows

# Transform only jobs
python -m tools.atx.dependency_transformer transform jobs \
    --input-dir examples/atx \
    --output-dir results/jobs

# Transform only entry points
python -m tools.atx.dependency_transformer transform entry-points \
    --input-dir examples/atx \
    --output-dir results/entry_points
```

## Input Requirements

The input directory must contain the following ATX output files:

1. **dependencies.json** (required)
   - Program dependencies and call relationships
   - CICS transactions
   - JCL jobs
   - Copybook usage
   - Dataset references

2. **assets.csv** (required)
   - Code metrics (cyclomatic complexity, lines of code)
   - Program metadata

3. **program_to_dsn.json** (required)
   - Data operations (READ, WRITE, UPDATE)
   - Dataset access patterns

## Output Structure

### Transform All

```
output_dir/
├── flows/
│   ├── Business_Flows.json
│   ├── flows_by_name.json
│   ├── flows_by_complexity_asc.json
│   ├── flows_by_complexity_desc.json
│   └── flows_by_independence.json
├── jobs/
│   ├── jobs.json
│   ├── jobs_by_name.json
│   ├── jobs_by_type.json
│   └── jobs_by_complexity.json
├── entry_points.json
└── exports/
    └── entry_points.csv
```

### Transform Flows

```
output_dir/
└── flows/
    ├── Business_Flows.json
    ├── flows_by_name.json
    ├── flows_by_complexity_asc.json
    ├── flows_by_complexity_desc.json
    └── flows_by_independence.json
```

### Transform Jobs

```
output_dir/
└── jobs/
    ├── jobs.json
    ├── jobs_by_name.json
    ├── jobs_by_type.json
    └── jobs_by_complexity.json
```

### Transform Entry Points

```
output_dir/
├── entry_points.json
└── exports/
    └── entry_points.csv
```

## Transformation Report

After each transformation, a report is displayed showing:

- **Status**: SUCCESS or FAILED
- **Statistics**:
  - Flows generated
  - Jobs generated
  - Entry points generated
  - Programs processed
  - Execution time
- **Warnings**: Non-fatal issues (missing data, etc.)
- **Errors**: Fatal issues that prevented transformation

### Example Report

```
======================================================================
TRANSFORMATION REPORT
======================================================================

Status: ✓ SUCCESS

Statistics:
  Flows generated:        50
  Jobs generated:         32
  Entry points generated: 61
  Programs processed:     28
  Execution time:         0.02s

======================================================================
```

## Exit Codes

- `0`: Success
- `1`: Failure (validation errors, transformation errors, etc.)

## Troubleshooting

### Missing Input Files

**Error**: Required ATX input file not found

**Solution**: Ensure all required files exist in the input directory:
- `dependencies.json`
- `assets.csv`
- `program_to_dsn.json`

### Invalid JSON/CSV Format

**Error**: Malformed JSON or CSV file

**Solution**: Validate your ATX output files are properly formatted

### Missing Metrics

**Warning**: Program in dependencies.json not found in assets.csv

**Impact**: Default metrics (CC=0, LOC=0) will be used

**Solution**: Ensure assets.csv contains all programs from dependencies.json

### Permission Denied

**Error**: Cannot write to output directory

**Solution**: Check write permissions on the output directory

## Configuration

Create a custom configuration file to customize:

- Complexity formula weights
- Complexity tier thresholds
- Utility program lists
- Output options

Example configuration:

```yaml
complexity:
  weight_cc: 0.3
  weight_loc: 0.7
  tier_thresholds:
    low: 10.0
    medium: 20.0

transformation:
  utility_programs:
    - SORT
    - IEFBR14
    - IDCAMS
  warn_on_missing_metrics: true

output:
  generate_sorted_variants: true
  generate_csv_exports: true
  indent_json: 2
```

## Help

Get help for any command:

```bash
# General help
python -m tools.atx.dependency_transformer --help

# Transform command help
python -m tools.atx.dependency_transformer transform --help

# Specific command help
python -m tools.atx.dependency_transformer transform all --help
python -m tools.atx.dependency_transformer transform flows --help
python -m tools.atx.dependency_transformer transform jobs --help
python -m tools.atx.dependency_transformer transform entry-points --help
```
