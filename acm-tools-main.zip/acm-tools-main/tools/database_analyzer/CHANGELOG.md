# Changelog

All notable changes to the Database Analyzer tool will be documented in this file.

## [2.0.0] - 2024

### Added
- **Configurable Legacy Root**: New `--legacy-root` parameter to specify where legacy code lives
- **Recursive File Discovery**: Automatically finds files in any subdirectory structure
- **Custom File Extensions**: Support for configurable file extensions via CLI and config
  - `--jcl-extensions`: Customize JCL file extensions
  - `--cbl-extensions`: Customize COBOL file extensions
  - `--cpy-extensions`: Customize copybook file extensions
- **Enhanced Statistics**: Track files scanned by type (JCL, COBOL, copybooks)
- **Configuration File Support**: Example configuration file (`config.example.json`)
- **Comprehensive Documentation**:
  - Migration Guide for upgrading from v1.x
  - Path Analysis document detailing all path changes
  - Documentation Index for easy navigation
  - Updated Getting Started guide

### Changed
- **Path Handling**: Removed hardcoded paths (`input/legacy/legacy_code/carddemoV2/app/`)
- **File Discovery**: Changed from direct `glob()` to recursive `rglob()` search
- **Statistics Output**: Enhanced to show file scan counts by type
- **CLI Help**: Updated with new parameters and examples

### Improved
- **Flexibility**: Works with any folder organization
- **Usability**: No need to reorganize existing codebases
- **Maintainability**: No hardcoded paths to update

### Backward Compatibility
- ✅ Fully backward compatible with v1.x
- ✅ Existing usage patterns work without changes
- ✅ Defaults to `base_path` if `legacy_root` not specified

### Migration
See [Migration Guide](docs/MIGRATION_GUIDE.md) for detailed upgrade instructions.

---

## [1.0.0] - Initial Release

### Features
- **JCL Analysis**: Parse JCL files for DD statements
- **Multi-line JCL Parsing**: Handle JCL continuation lines
- **COBOL Analysis**: Parse COBOL programs for SELECT statements
- **Copybook Parsing**: Extract record structures from copybooks
- **VSAM Support**: Discover VSAM KSDS, ESDS, RRDS files
- **Sequential Files**: Identify PS (Physical Sequential) files
- **Smart Filtering**:
  - Exclude system files (LOADLIB, SDFHLOAD, etc.)
  - Exclude backup files (*.BKUP, GDG generations)
  - Exclude duplicate formats (prefer VSAM over PS)
- **DDL Generation**:
  - PostgreSQL DDL with proper data types
  - SQLite DDL with proper data types
- **Type Mapping**: Map COBOL PIC clauses to SQL types
- **Primary Key Detection**: Identify natural keys for VSAM KSDS
- **Migration Scripts**: Generate data migration procedures
- **Statistics**: Detailed analysis statistics
- **Verbose Mode**: Optional detailed logging

### Supported File Types
- JCL files (`.jcl`)
- COBOL programs (`.cbl`)
- COBOL copybooks (`.cpy`)

### Output Files
- `postgresql_ddl.sql` - PostgreSQL table definitions
- `sqlite_ddl.sql` - SQLite table definitions
- `postgresql_migration.sql` - PostgreSQL migration scripts
- `sqlite_migration.sql` - SQLite migration scripts

### Core Tables Discovered
1. ACCTDATA - Account data
2. CARDDATA - Card data
3. CARDXREF - Card cross-reference
4. CUSTDATA - Customer data
5. DALYTRAN - Daily transactions
6. DATEPARM - Date parameters
7. DISCGRP - Discount groups
8. TCATBALF - Transaction category balance
9. TRANCATG - Transaction categories
10. TRANSACT - Transactions
11. TRANTYPE - Transaction types
12. TRXFL - Transaction file
13. USRSEC - User security

---

## Version Comparison

| Feature | v1.0 | v2.0 |
|---------|------|------|
| Hardcoded paths | ❌ Yes | ✅ No |
| Configurable root | ❌ No | ✅ Yes |
| Recursive search | ❌ No | ✅ Yes |
| Custom extensions | ❌ No | ✅ Yes |
| File scan stats | ❌ No | ✅ Yes |
| Backward compatible | N/A | ✅ Yes |
| JCL parsing | ✅ Yes | ✅ Yes |
| COBOL parsing | ✅ Yes | ✅ Yes |
| Copybook parsing | ✅ Yes | ✅ Yes |
| Smart filtering | ✅ Yes | ✅ Yes |
| DDL generation | ✅ Yes | ✅ Yes |

---

## Upgrade Path

### From v1.0 to v2.0

**No changes required** if using default structure:
```bash
# This still works exactly as before
database-analyzer analyze --base-path . --output-dir output/database
```

**For custom structures**, add `--legacy-root`:
```bash
# New capability in v2.0
database-analyzer analyze \
  --base-path . \
  --legacy-root your/custom/path \
  --output-dir output/database
```

---

## Future Roadmap

### Planned Features
- [ ] Support for additional target databases (MySQL, Oracle)
- [ ] Configuration file loading (JSON/YAML)
- [ ] Exclude patterns for directories
- [ ] Include patterns for more specific searches
- [ ] Parallel file processing for large codebases
- [ ] Caching for repeated runs
- [ ] HTML report generation
- [ ] Relationship detection between tables
- [ ] Foreign key inference

### Under Consideration
- [ ] IMS database support
- [ ] DB2 DDL parsing
- [ ] Data profiling capabilities
- [ ] Sample data generation
- [ ] Test data creation

---

## Breaking Changes

### v2.0
- None - fully backward compatible

### v1.0
- Initial release

---

## Contributors

See the main ACM Tools documentation for contributor information.

---

## License

Part of the ACM Tools suite.
