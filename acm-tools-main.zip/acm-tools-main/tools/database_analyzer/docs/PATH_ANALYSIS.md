# Database Analyzer - Path Usage Analysis

## Summary of Path-Related Changes

This document details all hardcoded paths found in the codebase and how they were addressed.

## Files Modified

### 1. `tools/acm-tools/tools/database_analyzer/core/analyzer.py`

#### Hardcoded Paths Removed
```python
# OLD - Hardcoded paths
self.jcl_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/jcl"
self.cbl_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/cbl"
self.cpy_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/cpy"
```

#### New Implementation
```python
# NEW - Configurable root with recursive search
self.legacy_root = Path(self.config.get('legacy_root', self.base_path))
self.jcl_extensions = self.config.get('jcl_extensions', ['.jcl', '.JCL'])
self.cbl_extensions = self.config.get('cbl_extensions', ['.cbl', '.CBL', '.cob', '.COB'])
self.cpy_extensions = self.config.get('cpy_extensions', ['.cpy', '.CPY'])
```

#### Methods Modified

1. **`__init__`**: Added configuration for legacy_root and file extensions
2. **`_find_files_by_extension`**: New helper method for recursive file discovery
3. **`analyze_jcl_files`**: Changed from `glob("*.jcl")` to recursive search
4. **`analyze_cobol_files`**: Changed from `glob("*.cbl")` to recursive search
5. **`analyze_copybooks`**: Changed from `glob("*.cpy")` to recursive search
6. **`print_statistics`**: Added file scan counts

### 2. `tools/acm-tools/tools/database_analyzer/cli.py`

#### New CLI Arguments
- `--legacy-root`: Specify root directory for legacy code
- `--jcl-extensions`: Comma-separated list of JCL file extensions
- `--cbl-extensions`: Comma-separated list of COBOL file extensions
- `--cpy-extensions`: Comma-separated list of copybook file extensions

#### Configuration Handling
```python
# Parse and pass extensions to analyzer
if args.jcl_extensions:
    config['jcl_extensions'] = [ext.strip() if ext.startswith('.') else f'.{ext.strip()}' 
                                 for ext in args.jcl_extensions.split(',')]
```

## Other Files with Hardcoded Paths (Not Modified)

### 3. `database_analyzer_improved.py` (Root Level)
**Status**: Appears to be a duplicate/test file
**Hardcoded Paths**: Same as original analyzer
**Recommendation**: Consider removing or updating to match the refactored version

### 4. `web-dashboard/models/data_loader.py`
**Hardcoded Paths Found**:
```python
source_dir = self.project_root / "input" / "legacy" / "legacy_code"
```
**Usage**: Web dashboard data loading
**Impact**: Low - This is for UI display purposes
**Recommendation**: Update if dashboard needs to support custom paths

### 5. `output/analysis/database_atx/tools/database_analyzer.py`
**Hardcoded Paths Found**:
```python
cpy_path = self.base_path / "input/legacy/atx/data-analysis/data_dictionary_cpy.csv"
lineage_path = self.base_path / "input/legacy/atx/data-analysis/program_to_dsn.json"
ddl_dir = self.base_path / f"output/analysis/database/gen_src_db_atx/{target}/ddl"
```
**Usage**: ATX-specific analyzer (different tool)
**Impact**: None - This is a separate tool for ATX data
**Recommendation**: Keep as-is (different use case)

## Path Usage Patterns

### Input Paths
- **Legacy Code**: `input/legacy/legacy_code/` - Now configurable via `legacy_root`
- **ATX Data**: `input/legacy/atx/` - Separate tool, not modified
- **Guidance**: `input/guidance/` - Not used by analyzer

### Output Paths
- **Database DDL**: `output/analysis/database/` - Controlled by `--output-dir` parameter
- **Reports**: Generated in specified output directory

## Recursive Search Implementation

The new `_find_files_by_extension` method:
```python
def _find_files_by_extension(self, root_path: Path, extensions: List[str]) -> List[Path]:
    """Recursively find all files with given extensions under root_path"""
    files = []
    if not root_path.exists():
        if self.verbose:
            print(f"Warning: Path does not exist: {root_path}")
        return files
    
    for ext in extensions:
        files.extend(root_path.rglob(f"*{ext}"))
    
    return sorted(files)
```

**Benefits**:
- Uses `rglob` for recursive search
- Handles multiple extensions
- Graceful handling of missing paths
- Returns sorted list for consistent processing

## Testing Recommendations

### Test Cases to Verify

1. **Backward Compatibility**
   ```bash
   # Should work without any new parameters
   database-analyzer analyze --base-path . --output-dir output/test
   ```

2. **Custom Root Path**
   ```bash
   # Should find files in custom location
   database-analyzer analyze --base-path . \
     --legacy-root input/legacy/legacy_code \
     --output-dir output/test
   ```

3. **Nested Files**
   - Place JCL files in deeply nested directories
   - Verify they are discovered and processed

4. **Mixed Extensions**
   ```bash
   # Should handle multiple extensions
   database-analyzer analyze --base-path . \
     --jcl-extensions .jcl,.JCL,.job \
     --output-dir output/test
   ```

5. **Non-existent Path**
   - Verify graceful handling when legacy_root doesn't exist

## Performance Considerations

### Before (Direct Path Access)
- Fast: Direct glob on known directories
- Limited: Only works with specific structure

### After (Recursive Search)
- Slightly slower: Recursive directory traversal
- Flexible: Works with any structure
- Optimized: Uses `rglob` which is efficient

**Recommendation**: For very large codebases (10,000+ files), consider:
- Using more specific `legacy_root` paths
- Limiting file extensions to only what's needed
- Adding path exclusion patterns if needed

## Future Enhancements

Potential improvements for path handling:

1. **Exclude Patterns**: Add `--exclude-dirs` to skip certain directories
2. **Include Patterns**: Add `--include-pattern` for more specific searches
3. **Path Mapping**: Support mapping DSNs to specific directories
4. **Cache**: Cache file discovery results for repeated runs
5. **Parallel Processing**: Process files in parallel for large codebases

## Configuration File Support

Consider adding support for a config file:
```json
{
  "legacy_root": "input/legacy/legacy_code",
  "jcl_extensions": [".jcl", ".JCL", ".job"],
  "cbl_extensions": [".cbl", ".CBL", ".cob"],
  "cpy_extensions": [".cpy", ".CPY"],
  "exclude_dirs": ["backup", "archive"],
  "verbose": true
}
```

This would make it easier to manage complex configurations.
