# Getting Started with Database Analyzer

## Quick Start

### 1. Installation

```bash
cd tools/acm-tools
pip install -e .
```

### 2. Run Analysis

```bash
# Basic usage (searches from base-path)
database-analyzer analyze \
    --base-path /path/to/your/project \
    --output-dir output/database

# Specify custom legacy code location
database-analyzer analyze \
    --base-path . \
    --legacy-root input/legacy/legacy_code \
    --output-dir output/database

# With custom file extensions
database-analyzer analyze \
    --base-path . \
    --legacy-root src/mainframe \
    --jcl-extensions .jcl,.JCL,.job \
    --cbl-extensions .cbl,.cob \
    --output-dir output/database
```

### 3. Review Results

Check the generated files in `output/database/`:
- `postgresql_ddl.sql` - PostgreSQL table definitions
- `sqlite_ddl.sql` - SQLite table definitions
- `postgresql_migration.sql` - PostgreSQL migration scripts
- `sqlite_migration.sql` - SQLite migration scripts

## What Gets Analyzed

The tool scans your legacy mainframe code for:

1. **JCL Files** (`*.jcl`) - DD statements defining datasets
2. **COBOL Programs** (`*.cbl`) - SELECT statements and file definitions
3. **Copybooks** (`*.cpy`) - Record structures and field definitions

## Project Structure

**Flexible Structure**: The analyzer now recursively searches for files, so your legacy code can be organized in any structure. Simply point `--legacy-root` to the directory containing your legacy files.

**Example structures supported**:

```
# Option 1: Organized by type
your-project/
├── jcl/          # All JCL files
├── cobol/        # All COBOL programs
└── copybooks/    # All copybooks

# Option 2: Organized by application
your-project/
├── app1/
│   ├── jcl/
│   ├── cbl/
│   └── cpy/
└── app2/
    ├── jcl/
    ├── cbl/
    └── cpy/

# Option 3: Mixed/nested structure
your-project/
├── src/
│   ├── batch/
│   │   ├── jobs/      # JCL files anywhere
│   │   └── programs/  # COBOL files anywhere
│   └── online/
│       └── copybooks/ # Copybooks anywhere
```

**Default structure** (backward compatible):
```
your-project/
├── input/
│   └── legacy/
│       └── legacy_code/
│           └── carddemoV2/
│               └── app/
│                   ├── jcl/    # JCL files
│                   ├── cbl/    # COBOL programs
│                   └── cpy/    # Copybooks
```

## Understanding the Output

### Statistics

```
============================================================
Analysis Summary:
============================================================
  JCL files scanned:           45
  COBOL files scanned:         38
  Copybook files scanned:      29
  Total DSNs found:            94
  System files excluded:       15
  Backup files excluded:       13
  Duplicate formats excluded:  39
  Files included:              28
============================================================
```

- **JCL files scanned**: Number of JCL files found and processed
- **COBOL files scanned**: Number of COBOL programs analyzed
- **Copybook files scanned**: Number of copybooks parsed
- **Total DSNs found**: All DD statements discovered in JCL
- **System files excluded**: LOADLIB, SDFHLOAD, DFHCSD, etc.
- **Backup files excluded**: *.BKUP, GDG generations
- **Duplicate formats excluded**: PS versions when VSAM exists
- **Files included**: Actual business data files

### Generated Tables

The tool discovers and generates DDL for:
- **VSAM KSDS files** → Tables with natural primary keys
- **VSAM ESDS files** → Tables with surrogate keys + sequence
- **VSAM RRDS files** → Tables with relative record number keys
- **Sequential files (PS)** → Tables with surrogate keys + sequence

## Common Use Cases

### Use Case 1: Database Migration Planning

```bash
# Analyze database structures
database-analyzer analyze \
    --base-path . \
    --output-dir output/db_analysis

# Review the generated DDL
cat output/db_analysis/postgresql_ddl.sql

# Count tables discovered
grep "CREATE TABLE" output/db_analysis/postgresql_ddl.sql | wc -l
```

### Use Case 2: Understanding Legacy Data Structures

```bash
# Run with verbose output to see all files
database-analyzer analyze \
    --base-path . \
    --output-dir output/db \
    --verbose

# Review what was included/excluded
# Check the console output for [INCLUDE] and [SKIP] messages
```

### Use Case 3: Including All Files (No Filtering)

```bash
# Disable all filters to see everything
database-analyzer analyze \
    --base-path . \
    --output-dir output/db_all \
    --no-system-filter \
    --no-backup-filter \
    --no-duplicate-filter
```

### Use Case 4: Custom Legacy Code Location

```bash
# Point to a different directory structure
database-analyzer analyze \
    --base-path . \
    --legacy-root /path/to/mainframe/source \
    --output-dir output/db

# Or use relative path
database-analyzer analyze \
    --base-path . \
    --legacy-root src/legacy \
    --output-dir output/db
```

### Use Case 5: Custom File Extensions

```bash
# Support additional file extensions
database-analyzer analyze \
    --base-path . \
    --legacy-root src/mainframe \
    --jcl-extensions .jcl,.JCL,.job,.JOB \
    --cbl-extensions .cbl,.CBL,.cob,.COB,.cobol \
    --cpy-extensions .cpy,.CPY,.copy,.COPY \
    --output-dir output/db
```

## Next Steps

1. **Review Generated DDL**: Check if all expected tables are present
2. **Validate Type Mappings**: Ensure COBOL types mapped correctly to SQL
3. **Check Primary Keys**: Verify key fields are correctly identified
4. **Review Migration Scripts**: Understand the data migration approach
5. **Create Analysis Report**: Document findings for stakeholders

## Troubleshooting

### Problem: Missing Tables

**Check**:
1. Is `--legacy-root` pointing to the correct directory?
2. Are JCL files being found? (check "JCL files scanned" in output)
3. Are copybooks available? (check "Copybook files scanned" in output)
4. Do file extensions match? (use `--jcl-extensions`, `--cbl-extensions`, `--cpy-extensions` if needed)
5. Run with `--verbose` to see what's being skipped

### Problem: Too Many Tables

**Solution**: Use default filtering (enabled by default)
- System files are excluded
- Backup files are excluded
- Duplicate formats are excluded

### Problem: Incorrect Table Structure

**Check**:
1. Copybook parsing - are PIC clauses correct?
2. Type mappings - review COBOL to SQL conversions
3. Field names - should match copybook exactly

## Configuration Options

### Command-Line Options

```bash
--base-path PATH          # Base path to project directory (required)
--legacy-root PATH        # Root path for legacy code (defaults to base-path)
--output-dir PATH         # Output directory for generated files (required)
--verbose                 # Enable verbose output
--no-system-filter        # Include system files
--no-backup-filter        # Include backup files
--no-duplicate-filter     # Include duplicate formats
--jcl-extensions EXTS     # Comma-separated JCL extensions (default: .jcl,.JCL)
--cbl-extensions EXTS     # Comma-separated COBOL extensions (default: .cbl,.CBL,.cob,.COB)
--cpy-extensions EXTS     # Comma-separated copybook extensions (default: .cpy,.CPY)
```

### Programmatic Configuration

```python
from tools.database_analyzer import DatabaseAnalyzer

config = {
    'legacy_root': 'input/legacy/legacy_code',
    'jcl_extensions': ['.jcl', '.JCL', '.job'],
    'cbl_extensions': ['.cbl', '.CBL', '.cob'],
    'cpy_extensions': ['.cpy', '.CPY'],
    'verbose': True,
    'exclude_system_files': True,
    'exclude_backups': True,
    'exclude_duplicates': True,
}

analyzer = DatabaseAnalyzer(base_path='.', config=config)
results = analyzer.run_analysis()
```

## Getting Help

- See [README.md](../README.md) for full documentation
- Check [MIGRATION_GUIDE.md](../MIGRATION_GUIDE.md) for upgrade guide
- Review [PATH_ANALYSIS.md](../PATH_ANALYSIS.md) for path handling details
