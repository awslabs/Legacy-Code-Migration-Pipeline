# Design Philosophy: Keep It Simple

## Current Structure

```
database_analyzer/
├── README.md                      # Main documentation
├── INTEGRATION_SUMMARY.md         # Integration details
├── __init__.py                    # Package initialization
├── __main__.py                    # CLI entry point
├── cli.py                         # Command-line interface
├── requirements.txt               # Dependencies (none)
│
├── core/
│   ├── __init__.py
│   └── analyzer.py                # All functionality in one file
│
└── docs/                          # Documentation
    ├── GETTING_STARTED.md
    ├── ANALYZER_IMPROVEMENTS.md
    ├── IMPROVED_ANALYZER_TEST_RESULTS.md
    └── TABLE_COMPARISON.md
```

## Why So Simple?

### YAGNI Principle: "You Aren't Gonna Need It"

We deliberately kept the structure minimal because:

1. **All functionality fits in one file** (`core/analyzer.py`)
   - ~600 lines of code
   - Easy to understand and maintain
   - No need to jump between files

2. **No premature abstraction**
   - Don't create folders until you need them
   - Don't split code until it's too complex
   - Don't add layers until there's a clear benefit

3. **Easy to refactor later**
   - When `analyzer.py` grows too large, split it
   - When adding MySQL support, create `generators/`
   - When filters get complex, create `filters/`

## When to Add Folders?

### Create `generators/` when:
- Adding 3+ target databases (MySQL, Oracle, SQL Server)
- DDL generation logic becomes complex (>200 lines per database)
- Need to share common DDL generation code

**Example**:
```
generators/
├── __init__.py
├── base_generator.py          # Common DDL logic
├── postgresql_generator.py    # PostgreSQL-specific
├── sqlite_generator.py        # SQLite-specific
└── mysql_generator.py         # MySQL-specific
```

### Create `filters/` when:
- Filter logic becomes complex (>100 lines per filter)
- Need to add custom filter rules
- Want to make filters configurable

**Example**:
```
filters/
├── __init__.py
├── system_filter.py           # System file patterns
├── backup_filter.py           # Backup file patterns
└── duplicate_filter.py        # Duplicate detection logic
```

### Create `mappers/` when:
- Type mapping becomes complex (>150 lines)
- Adding support for more source types (IMS, DB2)
- Need database-specific type mappings

**Example**:
```
mappers/
├── __init__.py
├── type_mapper.py             # COBOL to SQL type mapping
├── vsam_mapper.py             # VSAM to relational mapping
└── key_mapper.py              # Primary key identification
```

### Create `reports/` when:
- Need multiple report formats (Markdown, HTML, PDF)
- Report generation logic is complex
- Want templated reports

**Example**:
```
reports/
├── __init__.py
├── report_generator.py        # Report generation logic
└── templates/
    ├── analysis_report.md     # Markdown template
    └── analysis_report.html   # HTML template
```

### Create `tests/` when:
- Ready to add automated testing
- Have test fixtures (sample JCL, copybooks)
- Want CI/CD integration

**Example**:
```
tests/
├── __init__.py
├── test_analyzer.py           # Main analyzer tests
├── test_jcl_parser.py         # JCL parsing tests
└── fixtures/
    ├── sample.jcl
    └── sample.cpy
```

## Current Approach: Monolithic is Fine

**Why `core/analyzer.py` contains everything**:

1. **It's not that big** (~800 lines including new path handling)
2. **It's cohesive** (all related to database analysis)
3. **It's easy to understand** (one file to read)
4. **It works well** (no performance issues)
5. **It's easy to test** (one module to test)
6. **Flexible** (supports any folder structure via configuration)

## Recent Improvements

### Path Handling Refactoring (v2.0)

The analyzer was refactored to remove hardcoded paths:

**Before**:
```python
self.jcl_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/jcl"
self.cbl_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/cbl"
self.cpy_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/cpy"
```

**After**:
```python
self.legacy_root = Path(self.config.get('legacy_root', self.base_path))
self.jcl_extensions = self.config.get('jcl_extensions', ['.jcl', '.JCL'])
# Recursive file discovery using rglob
```

**Benefits**:
- Works with any folder structure
- Configurable file extensions
- Recursive file discovery
- Backward compatible
- Still fits in one file (~800 lines)

## Refactoring Triggers

Consider splitting when:

- [ ] File exceeds 1000 lines
- [ ] Adding 3+ target databases
- [ ] Filter logic exceeds 200 lines
- [ ] Type mapping exceeds 200 lines
- [ ] Multiple developers working on different parts
- [ ] Need to reuse components in other tools

**Current Status**: ~800 lines, still manageable in one file

## Comparison with legacy_analyzer

**legacy_analyzer** has many folders because:
- Supports 7+ languages (COBOL, JCL, ASM, PL/I, REXX, RPG, Natural)
- Complex dependency analysis
- Flow analysis, complexity metrics
- Multiple report types
- Large codebase (thousands of lines)

**database_analyzer** is simpler because:
- Focuses on one thing: database schema analysis
- Smaller codebase (~800 lines)
- Fewer features (by design)
- Flexible path handling (v2.0)
- Can grow when needed

## Summary

**Current**: Simple structure, all code in `core/analyzer.py`

**Future**: Add folders only when there's a clear need

**Philosophy**: Start simple, refactor when necessary, not before

This follows the principle: "Make it work, make it right, make it fast" - in that order.
