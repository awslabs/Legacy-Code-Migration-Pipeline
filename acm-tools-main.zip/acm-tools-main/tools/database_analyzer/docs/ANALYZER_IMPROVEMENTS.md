# Database Analyzer Improvements

## Issues Found

### 1. Missing DALYTRAN and DATEPARM

**Root Cause**: Multi-line DD statement parsing failure

**Problem**:
```jcl
//DALYTRAN DD DISP=SHR,
//         DSN=AWS.M2.CARDDEMO.DALYTRAN.PS
```

**Current Regex**: `r'//(\w+)\s+DD\s+.*?DSN=([^,\s\n]+)'`
- Expects DD and DSN on same line
- `\s+.*?` doesn't cross newlines by default
- Misses continuation lines (lines starting with `//` followed by spaces)

**Solution**: Handle JCL continuation lines

```python
def analyze_jcl_files(self):
    """Analyze JCL files for DD statements and Sequential/VSAM files"""
    for jcl_file in self.jcl_path.glob("*.jcl") if self.jcl_path.exists() else []:
        try:
            with open(jcl_file, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                
            # Merge continuation lines
            merged_lines = []
            current_line = ""
            for line in lines:
                # JCL continuation: line starts with // followed by spaces
                if line.startswith('//') and not line[2:3].strip():
                    # Continuation line - append to current
                    current_line += " " + line.strip()
                else:
                    if current_line:
                        merged_lines.append(current_line)
                    current_line = line.strip()
            if current_line:
                merged_lines.append(current_line)
            
            content = "\n".join(merged_lines)
            
            # Find DD statements with DSN parameters
            dd_pattern = r'//(\w+)\s+DD\s+.*?DSN=([^,\s\n]+)'
            matches = re.findall(dd_pattern, content, re.IGNORECASE)
            
            # ... rest of the code
```

---

### 2. Extra Tables (System Files, Backups, Duplicates)

**Problem**: Analyzer includes non-business files:
- System libraries (LOADLIB, SDFHLOAD, DFHCSD)
- Backup files (*.BKUP, *.BACKUP)
- Alternate formats (same data, different organization)
- Test files (ESDSRRDS.PS)

**Solution**: Add filtering logic

#### A. Exclude System Files

```python
def is_system_file(self, dsn: str) -> bool:
    """Identify system/infrastructure files to exclude"""
    system_patterns = [
        r'\.LOADLIB$',           # Load libraries
        r'SDFHLOAD',             # CICS system library
        r'DFHCSD',               # CICS system definition
        r'\.STEPLIB',            # Step libraries
        r'^OEM\.',               # OEM/vendor files
        r'\.PROCLIB',            # Procedure libraries
        r'\.PARMLIB',            # Parameter libraries
        r'ESDSRRDS\.PS$',        # Test/demo files
    ]
    
    dsn_upper = dsn.upper()
    for pattern in system_patterns:
        if re.search(pattern, dsn_upper):
            return True
    return False
```

#### B. Exclude Backup Files

```python
def is_backup_file(self, dsn: str) -> bool:
    """Identify backup files to exclude"""
    backup_patterns = [
        r'\.BKUP',               # Backup files
        r'\.BACKUP',             # Backup files
        r'\.BAK',                # Backup files
        r'\([\+\-]\d+\)',        # GDG generations (backup versions)
    ]
    
    dsn_upper = dsn.upper()
    for pattern in backup_patterns:
        if re.search(pattern, dsn_upper):
            return True
    return False
```

#### C. Identify Alternate Formats

```python
def get_primary_dsn(self, dsn: str) -> str:
    """Get primary DSN by removing format suffixes"""
    # Remove alternate format indicators
    dsn_clean = re.sub(r'\.(PSCOMP|ARRYPS|VBPS|SEQ)$', '', dsn, flags=re.IGNORECASE)
    
    # Prefer VSAM KSDS over other organizations
    # If we see both USRSEC.VSAM.KSDS and USRSEC.VSAM.ESDS, keep only KSDS
    dsn_clean = re.sub(r'\.VSAM\.(ESDS|RRDS)$', '.VSAM.KSDS', dsn_clean, flags=re.IGNORECASE)
    
    # Remove .PS if VSAM version exists
    dsn_clean = re.sub(r'\.PS$', '', dsn_clean, flags=re.IGNORECASE)
    
    return dsn_clean

def is_duplicate_format(self, dsn: str, existing_dsns: set) -> bool:
    """Check if this is an alternate format of an existing file"""
    primary = self.get_primary_dsn(dsn)
    
    # Check if primary version already exists
    for existing in existing_dsns:
        if self.get_primary_dsn(existing) == primary:
            # Prefer VSAM KSDS over other formats
            if '.VSAM.KSDS' in existing.upper():
                return True  # Skip this alternate format
            elif '.VSAM.KSDS' in dsn.upper():
                return False  # Keep this KSDS, will replace alternate
    
    return False
```

#### D. Integrated Filtering

```python
def analyze_jcl_files(self):
    """Analyze JCL files for DD statements and Sequential/VSAM files"""
    processed_primaries = set()  # Track primary DSNs to avoid duplicates
    
    for jcl_file in self.jcl_path.glob("*.jcl") if self.jcl_path.exists() else []:
        try:
            # ... (merge continuation lines as shown above)
            
            for dd_name, dsn in matches:
                # Apply filters
                if self.is_system_file(dsn):
                    print(f"Skipping system file: {dsn}")
                    continue
                
                if self.is_backup_file(dsn):
                    print(f"Skipping backup file: {dsn}")
                    continue
                
                primary_dsn = self.get_primary_dsn(dsn)
                if primary_dsn in processed_primaries:
                    print(f"Skipping duplicate format: {dsn} (primary: {primary_dsn})")
                    continue
                
                # Process the file
                file_type = self.determine_file_type(dsn, content)
                
                if file_type == 'PS':
                    self.sequential_files[dsn] = {
                        'dd_name': dd_name,
                        'source_jcl': jcl_file.name,
                        'organization': 'PS',
                        'dsn': dsn,
                        'primary_dsn': primary_dsn
                    }
                    processed_primaries.add(primary_dsn)
                    
                elif file_type in ['VSAM_KSDS', 'VSAM_ESDS', 'VSAM_RRDS']:
                    # Prefer KSDS over ESDS/RRDS
                    if file_type == 'VSAM_KSDS' or primary_dsn not in processed_primaries:
                        self.vsam_files[dsn] = {
                            'dd_name': dd_name,
                            'source_jcl': jcl_file.name,
                            'organization': file_type,
                            'dsn': dsn,
                            'primary_dsn': primary_dsn
                        }
                        processed_primaries.add(primary_dsn)
                        
        except Exception as e:
            print(f"Error processing JCL file {jcl_file}: {e}")
```

---

## Expected Results After Improvements

### Before (28 tables)
```
aws_m2_carddemo_acctdata_arryps          ❌ Duplicate format
aws_m2_carddemo_acctdata_pscomp          ❌ Duplicate format
aws_m2_carddemo_acctdata_vbps            ❌ Duplicate format
aws_m2_carddemo_acctdata_vsam_ksds       ✅ Keep
aws_m2_carddemo_carddata_vsam_ksds       ✅ Keep
aws_m2_carddemo_cardxref_vsam_ksds       ✅ Keep
aws_m2_carddemo_custdata_vsam_ksds       ✅ Keep
aws_m2_carddemo_discgrp_bkup__1_         ❌ Backup
aws_m2_carddemo_discgrp_ps               ❌ Duplicate format
aws_m2_carddemo_discgrp_vsam_ksds        ✅ Keep
aws_m2_carddemo_esdsrrds_ps              ❌ Test file
aws_m2_carddemo_loadlib                  ❌ System file
aws_m2_carddemo_tcatbalf_vsam_ksds       ✅ Keep
aws_m2_carddemo_trancatg_ps              ❌ Duplicate format
aws_m2_carddemo_trancatg_ps_bkup__1_     ❌ Backup
aws_m2_carddemo_trancatg_vsam_ksds       ✅ Keep
aws_m2_carddemo_transact_vsam_ksds       ✅ Keep
aws_m2_carddemo_trantype_bkup__1_        ❌ Backup
aws_m2_carddemo_trantype_ps              ❌ Duplicate format
aws_m2_carddemo_trantype_vsam_ksds       ✅ Keep
aws_m2_carddemo_trxfl_seq                ❌ Duplicate format
aws_m2_carddemo_trxfl_vsam_ksds          ✅ Keep
aws_m2_carddemo_usrsec_ps                ❌ Duplicate format
aws_m2_carddemo_usrsec_vsam_esds         ❌ Alternate org
aws_m2_carddemo_usrsec_vsam_ksds         ✅ Keep
aws_m2_carddemo_usrsec_vsam_rrds         ❌ Alternate org
oem_cicsts_dfhcsd                        ❌ System file
oem_cicsts_v05r06m0_cics_sdfhload        ❌ System file
```

### After (13 tables) + 2 missing
```
✅ ACCTDATA (aws_m2_carddemo_acctdata_vsam_ksds)
✅ CARDDATA (aws_m2_carddemo_carddata_vsam_ksds)
✅ CARDXREF (aws_m2_carddemo_cardxref_vsam_ksds)
✅ CUSTDATA (aws_m2_carddemo_custdata_vsam_ksds)
✅ DALYTRAN (aws_m2_carddemo_dalytran_ps) ⚠️ WILL BE FOUND with fix
✅ DATEPARM (aws_m2_carddemo_dateparm) ⚠️ WILL BE FOUND with fix
✅ DISCGRP (aws_m2_carddemo_discgrp_vsam_ksds)
✅ TCATBALF (aws_m2_carddemo_tcatbalf_vsam_ksds)
✅ TRANCATG (aws_m2_carddemo_trancatg_vsam_ksds)
✅ TRANSACT (aws_m2_carddemo_transact_vsam_ksds)
✅ TRANTYPE (aws_m2_carddemo_trantype_vsam_ksds)
✅ TRXFL (aws_m2_carddemo_trxfl_vsam_ksds)
✅ USRSEC (aws_m2_carddemo_usrsec_vsam_ksds)
```

---

## Additional Improvements

### 3. Add Configuration for Filtering

```python
class DatabaseAnalyzer:
    def __init__(self, base_path: str, config: dict = None):
        self.base_path = Path(base_path)
        self.config = config or {}
        
        # Filtering configuration
        self.exclude_system_files = self.config.get('exclude_system_files', True)
        self.exclude_backups = self.config.get('exclude_backups', True)
        self.exclude_duplicates = self.config.get('exclude_duplicates', True)
        self.prefer_vsam_ksds = self.config.get('prefer_vsam_ksds', True)
        
        # Custom exclusion patterns
        self.custom_exclude_patterns = self.config.get('exclude_patterns', [])
```

### 4. Add Verbose Logging

```python
def analyze_jcl_files(self):
    """Analyze JCL files for DD statements and Sequential/VSAM files"""
    stats = {
        'total_found': 0,
        'system_files': 0,
        'backups': 0,
        'duplicates': 0,
        'included': 0
    }
    
    # ... processing logic
    
    for dd_name, dsn in matches:
        stats['total_found'] += 1
        
        if self.is_system_file(dsn):
            stats['system_files'] += 1
            if self.config.get('verbose'):
                print(f"  [SKIP] System file: {dsn}")
            continue
        
        # ... more filtering
        
        stats['included'] += 1
    
    # Print summary
    print(f"\nJCL Analysis Summary:")
    print(f"  Total files found: {stats['total_found']}")
    print(f"  System files excluded: {stats['system_files']}")
    print(f"  Backup files excluded: {stats['backups']}")
    print(f"  Duplicate formats excluded: {stats['duplicates']}")
    print(f"  Files included: {stats['included']}")
```

### 5. Add Validation Report

```python
def generate_validation_report(self) -> str:
    """Generate a report showing what was included/excluded"""
    report = []
    report.append("# Database Analysis Validation Report\n")
    
    report.append("## Included Files\n")
    report.append("### VSAM Files\n")
    for dsn, info in self.vsam_files.items():
        report.append(f"- {dsn} ({info['organization']})")
    
    report.append("\n### Sequential Files\n")
    for dsn, info in self.sequential_files.items():
        report.append(f"- {dsn}")
    
    report.append("\n## Excluded Files\n")
    # Track excluded files during analysis
    for dsn, reason in self.excluded_files.items():
        report.append(f"- {dsn}: {reason}")
    
    return "\n".join(report)
```

---

## Implementation Priority

1. **HIGH**: Fix multi-line DD statement parsing (finds DALYTRAN, DATEPARM)
2. **HIGH**: Exclude system files (removes LOADLIB, SDFHLOAD, DFHCSD)
3. **HIGH**: Exclude backup files (removes *.BKUP)
4. **MEDIUM**: Exclude duplicate formats (removes PS versions when VSAM exists)
5. **MEDIUM**: Add verbose logging
6. **LOW**: Add configuration options
7. **LOW**: Generate validation report

---

## Testing

```python
# Test cases
test_cases = [
    # Multi-line DD statements
    ("DALYTRAN", "AWS.M2.CARDDEMO.DALYTRAN.PS", True),
    ("DATEPARM", "AWS.M2.CARDDEMO.DATEPARM", True),
    
    # System files (should be excluded)
    ("STEPLIB", "AWS.M2.CARDDEMO.LOADLIB", False),
    ("STEPLIB", "OEM.CICSTS.V05R06M0.CICS.SDFHLOAD", False),
    ("DFHCSD", "OEM.CICSTS.DFHCSD", False),
    
    # Backup files (should be excluded)
    ("SYSUT2", "AWS.M2.CARDDEMO.TRANTYPE.BKUP(+1)", False),
    ("SYSUT2", "AWS.M2.CARDDEMO.DISCGRP.BKUP(+1)", False),
    
    # Duplicate formats (should keep VSAM KSDS only)
    ("OUTFILE", "AWS.M2.CARDDEMO.ACCTDATA.PSCOMP", False),
    ("ARRYFILE", "AWS.M2.CARDDEMO.ACCTDATA.ARRYPS", False),
    ("ACCTFILE", "AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS", True),
]
```

---

## Summary

**Root Causes**:
1. Multi-line JCL parsing failure → missed DALYTRAN, DATEPARM
2. No filtering logic → included system files, backups, duplicates

**Solutions**:
1. Merge JCL continuation lines before parsing
2. Add filtering for system files, backups, and duplicate formats
3. Prefer VSAM KSDS over alternate organizations
4. Add logging and validation reporting

**Expected Outcome**: 13 business tables (matching ATX approach)
