# Table Comparison: ATX vs Non-ATX Approaches

## Summary

- **ATX Approach**: 13 business tables
- **Non-ATX Approach**: 28 tables (includes duplicates, backups, system files)

---

## Core Business Tables Comparison

| Business Entity | ATX Table | Non-ATX Table(s) | Status |
|-----------------|-----------|------------------|--------|
| **Account Data** | ACCTDATA | aws_m2_carddemo_acctdata_vsam_ksds | ✅ Both |
| | | aws_m2_carddemo_acctdata_pscomp | Non-ATX only |
| | | aws_m2_carddemo_acctdata_arryps | Non-ATX only |
| | | aws_m2_carddemo_acctdata_vbps | Non-ATX only |
| **Card Data** | CARDDATA | aws_m2_carddemo_carddata_vsam_ksds | ✅ Both |
| **Card Cross-Reference** | CARDXREF | aws_m2_carddemo_cardxref_vsam_ksds | ✅ Both |
| **Customer Data** | CUSTDATA | aws_m2_carddemo_custdata_vsam_ksds | ✅ Both |
| **Daily Transaction** | DALYTRAN | ❌ Missing | ATX only |
| **Date Parameters** | DATEPARM | ❌ Missing | ATX only |
| **Discount Group** | DISCGRP | aws_m2_carddemo_discgrp_vsam_ksds | ✅ Both |
| | | aws_m2_carddemo_discgrp_ps | Non-ATX only |
| | | aws_m2_carddemo_discgrp_bkup__1_ | Non-ATX only |
| **Transaction Category Balance** | TCATBALF | aws_m2_carddemo_tcatbalf_vsam_ksds | ✅ Both |
| **Transaction Category** | TRANCATG | aws_m2_carddemo_trancatg_vsam_ksds | ✅ Both |
| | | aws_m2_carddemo_trancatg_ps | Non-ATX only |
| | | aws_m2_carddemo_trancatg_ps_bkup__1_ | Non-ATX only |
| **Transaction** | TRANSACT | aws_m2_carddemo_transact_vsam_ksds | ✅ Both |
| **Transaction Type** | TRANTYPE | aws_m2_carddemo_trantype_vsam_ksds | ✅ Both |
| | | aws_m2_carddemo_trantype_ps | Non-ATX only |
| | | aws_m2_carddemo_trantype_bkup__1_ | Non-ATX only |
| **Transaction File** | TRXFL | aws_m2_carddemo_trxfl_vsam_ksds | ✅ Both |
| | | aws_m2_carddemo_trxfl_seq | Non-ATX only |
| **User Security** | USRSEC | aws_m2_carddemo_usrsec_vsam_ksds | ✅ Both |
| | | aws_m2_carddemo_usrsec_ps | Non-ATX only |
| | | aws_m2_carddemo_usrsec_vsam_esds | Non-ATX only |
| | | aws_m2_carddemo_usrsec_vsam_rrds | Non-ATX only |

---

## Tables ONLY in Non-ATX (Not in ATX)

### System/Infrastructure Files
| Table | Type | Reason for Exclusion |
|-------|------|---------------------|
| oem_cicsts_v05r06m0_cics_sdfhload | CICS System Library | System file, not business data |
| oem_cicsts_dfhcsd | CICS System Definition | System file, not business data |
| aws_m2_carddemo_loadlib | Load Library | System file, not business data |
| aws_m2_carddemo_esdsrrds_ps | Test/Demo File | Test file, not production data |

### Backup Files
| Table | Type | Reason for Exclusion |
|-------|------|---------------------|
| aws_m2_carddemo_discgrp_bkup__1_ | Backup | Backup copy, not primary data |
| aws_m2_carddemo_trancatg_ps_bkup__1_ | Backup | Backup copy, not primary data |
| aws_m2_carddemo_trantype_bkup__1_ | Backup | Backup copy, not primary data |

### Alternate File Formats (Same Data, Different Format)
| Table | Type | Reason for Exclusion |
|-------|------|---------------------|
| aws_m2_carddemo_acctdata_pscomp | Sequential (Compressed) | Alternate format of ACCTDATA |
| aws_m2_carddemo_acctdata_arryps | Sequential (Array) | Alternate format of ACCTDATA |
| aws_m2_carddemo_acctdata_vbps | Sequential (Variable Block) | Alternate format of ACCTDATA |
| aws_m2_carddemo_discgrp_ps | Sequential | Alternate format of DISCGRP VSAM |
| aws_m2_carddemo_trancatg_ps | Sequential | Alternate format of TRANCATG VSAM |
| aws_m2_carddemo_trantype_ps | Sequential | Alternate format of TRANTYPE VSAM |
| aws_m2_carddemo_trxfl_seq | Sequential | Alternate format of TRXFL VSAM |
| aws_m2_carddemo_usrsec_ps | Sequential | Alternate format of USRSEC VSAM |
| aws_m2_carddemo_usrsec_vsam_esds | VSAM ESDS | Alternate organization of USRSEC |
| aws_m2_carddemo_usrsec_vsam_rrds | VSAM RRDS | Alternate organization of USRSEC |

---

## Tables ONLY in ATX (Not in Non-ATX)

| Table | Type | Reason for Missing in Non-ATX |
|-------|------|-------------------------------|
| **DALYTRAN** | Sequential File | ❌ Not discovered in JCL analysis |
| **DATEPARM** | Sequential File | ❌ Not discovered in JCL analysis |

---

## Analysis of Missing Tables

### Why Non-ATX Missed DALYTRAN and DATEPARM

#### DALYTRAN (Daily Transaction)
**ATX Source**: `AWS.M2.CARDDEMO.DALYTRAN.PS`
**Copybook**: `DALYTRAN-RECORD`

**Possible Reasons for Missing**:
1. **Not referenced in analyzed JCL files**: The Non-ATX approach scans JCL files for DD statements. If DALYTRAN is only referenced in JCL files that weren't analyzed, it would be missed.
2. **Dynamic allocation**: File might be allocated dynamically in COBOL programs rather than in JCL.
3. **Embedded in program logic**: File might be opened directly in COBOL code without JCL DD statement.
4. **Newer addition**: File might have been added after the JCL analysis was performed.

**Business Impact**: HIGH - Daily transaction processing is critical for the application.

#### DATEPARM (Date Parameters)
**ATX Source**: `AWS.M2.CARDDEMO.DATEPARM`
**Copybook**: `WS-DATEPARM-RECORD`

**Possible Reasons for Missing**:
1. **Parameter file**: Small configuration file that might not have explicit JCL DD statement.
2. **Inline definition**: Might be defined inline in COBOL working storage rather than as external file.
3. **Hardcoded in programs**: Date parameters might be hardcoded or calculated rather than read from file.
4. **Not in analyzed JCL scope**: JCL files analyzed might not include batch jobs that use this file.

**Business Impact**: MEDIUM - Date parameters are important but might be replaceable with configuration.

---

## Why ATX Excluded Non-ATX Tables

### 1. System Files (Correctly Excluded)
ATX focuses on business data and correctly excludes:
- CICS system libraries (SDFHLOAD, DFHCSD)
- Load libraries (LOADLIB)
- Test/demo files (ESDSRRDS.PS)

**Reason**: These are infrastructure files, not business data requiring migration.

### 2. Backup Files (Correctly Excluded)
ATX excludes backup copies:
- DISCGRP.BKUP(+1)
- TRANCATG.PS.BKUP(+1)
- TRANTYPE.BKUP(+1)

**Reason**: Backup files contain duplicate data. Only primary source needs migration.

### 3. Alternate File Formats (Design Decision)
ATX includes only the primary VSAM KSDS version and excludes:
- Sequential file versions (PS)
- Alternate VSAM organizations (ESDS, RRDS)
- Different compression formats (PSCOMP, ARRYPS, VBPS)

**Reason**: Same logical data in different physical formats. Migrate once from primary source.

**Trade-off**: 
- ✅ Cleaner schema (no duplicates)
- ⚠️ Assumes VSAM KSDS is the authoritative source
- ⚠️ Might miss data if different formats contain different subsets

---

## Recommendations

### 1. Add Missing Tables to Non-ATX
The Non-ATX approach should add:
- **DALYTRAN** - Critical for daily transaction processing
- **DATEPARM** - Important for date range parameters

**Action**: 
```bash
# Search for DALYTRAN references in COBOL programs
grep -r "DALYTRAN" input/legacy/legacy_code/carddemoV2/app/

# Search for DATEPARM references
grep -r "DATEPARM" input/legacy/legacy_code/carddemoV2/app/
```

### 2. Validate ATX Exclusions
Verify that alternate file formats don't contain unique data:
- Compare record counts between VSAM and PS versions
- Check if different formats are used by different programs
- Validate that VSAM KSDS is the authoritative source

**Action**:
```sql
-- After migration, compare counts
SELECT 'VSAM' as source, COUNT(*) FROM aws_m2_carddemo_discgrp_vsam_ksds
UNION ALL
SELECT 'PS' as source, COUNT(*) FROM aws_m2_carddemo_discgrp_ps;
```

### 3. Document File Relationships
Create a mapping document showing:
- Primary source for each business entity
- Alternate formats and their purposes
- Backup files and retention policies
- System files and their roles

### 4. Hybrid Approach
**Recommended Strategy**:
1. Use ATX's 13 core business tables as the foundation
2. Add DALYTRAN and DATEPARM from ATX analysis
3. Validate against Non-ATX's comprehensive file discovery
4. Document which alternate formats to migrate (if any)
5. Explicitly exclude system files and backups

---

## Final Table Count Recommendation

### Core Business Tables (Must Migrate)
1. ACCTDATA - Account data
2. CARDDATA - Card data
3. CARDXREF - Card cross-reference
4. CUSTDATA - Customer data
5. DALYTRAN - Daily transactions ⚠️ Add to Non-ATX
6. DATEPARM - Date parameters ⚠️ Add to Non-ATX
7. DISCGRP - Discount groups
8. TCATBALF - Transaction category balance
9. TRANCATG - Transaction categories
10. TRANSACT - Transactions
11. TRANTYPE - Transaction types
12. TRXFL - Transaction file
13. USRSEC - User security

**Total: 13 tables** (ATX approach is correct)

### Optional (Validate Need)
- Alternate file formats (PS versions) - Only if they contain unique data
- VSAM ESDS/RRDS versions - Only if used by specific programs

### Exclude (Confirmed)
- System files (CICS libraries, load libraries)
- Backup files (*.BKUP)
- Test files (ESDSRRDS.PS)

---

## Conclusion

**Missing Tables Analysis**:
- **ATX is missing**: 0 business tables (DALYTRAN and DATEPARM are included)
- **Non-ATX is missing**: 2 business tables (DALYTRAN, DATEPARM)

**Reason for Non-ATX Missing Tables**:
- JCL analysis didn't capture all file references
- Files might be dynamically allocated or referenced in COBOL code
- ATX data dictionary provides more complete inventory

**Recommendation**: 
- Use ATX's 13-table list as the authoritative business data inventory
- Enhance Non-ATX analysis to discover DALYTRAN and DATEPARM
- Validate that alternate file formats don't contain unique data
- Keep Non-ATX's superior SQL implementation (foreign keys, indexes, naming)
