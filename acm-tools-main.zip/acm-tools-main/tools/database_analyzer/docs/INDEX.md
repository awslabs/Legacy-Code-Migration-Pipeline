# Database Analyzer Documentation Index

## Quick Links

### Getting Started
- [README](../README.md) - Main documentation and overview
- [Getting Started Guide](GETTING_STARTED.md) - Quick start tutorial
- [Configuration Example](../config.example.json) - Sample configuration file

### Recent Changes (v2.0)
- [Migration Guide](MIGRATION_GUIDE.md) - Upgrading from hardcoded paths
- [Path Analysis](PATH_ANALYSIS.md) - Detailed path refactoring documentation

### Technical Documentation
- [Integration Summary](../INTEGRATION_SUMMARY.md) - ACM Tools integration details
- [Design Philosophy](../DESIGN_PHILOSOPHY.md) - Architecture and design decisions
- [Analyzer Improvements](ANALYZER_IMPROVEMENTS.md) - Technical improvements
- [Test Results](IMPROVED_ANALYZER_TEST_RESULTS.md) - Testing and validation
- [Table Comparison](TABLE_COMPARISON.md) - ATX vs Non-ATX analysis

## Documentation by Topic

### Installation & Setup
1. [Installation](GETTING_STARTED.md#1-installation)
2. [Project Structure](GETTING_STARTED.md#project-structure)
3. [Configuration Options](GETTING_STARTED.md#configuration-options)

### Usage
1. [Basic Usage](../README.md#quick-start)
2. [Command-Line Options](../README.md#analyze-command)
3. [Programmatic API](../README.md#api-usage)
4. [Use Cases](GETTING_STARTED.md#common-use-cases)

### Path Configuration (New in v2.0)
1. [Overview](MIGRATION_GUIDE.md#overview-of-changes)
2. [Configuration Parameters](MIGRATION_GUIDE.md#configuration-options)
3. [Usage Examples](MIGRATION_GUIDE.md#usage-examples)
4. [Migration Steps](MIGRATION_GUIDE.md#migration-steps)
5. [Detailed Path Analysis](PATH_ANALYSIS.md)

### Features
1. [VSAM File Analysis](../README.md#features)
2. [Sequential File Discovery](../README.md#features)
3. [Multi-line JCL Parsing](../README.md#how-it-works)
4. [Smart Filtering](../README.md#how-it-works)
5. [Copybook Parsing](../README.md#how-it-works)
6. [Type Mapping](../README.md#type-mapping)

### Output & Results
1. [Understanding Output](GETTING_STARTED.md#understanding-the-output)
2. [Generated Files](GETTING_STARTED.md#3-review-results)
3. [Statistics](GETTING_STARTED.md#statistics)
4. [Core Business Tables](../README.md#core-business-tables-discovered)

### Troubleshooting
1. [Common Issues](GETTING_STARTED.md#troubleshooting)
2. [Missing Tables](../README.md#missing-tables)
3. [Incorrect Structure](../README.md#incorrect-table-structure)
4. [Too Many Tables](../README.md#too-many-tables)

### Integration
1. [ACM Tools Integration](../INTEGRATION_SUMMARY.md)
2. [Python API](../INTEGRATION_SUMMARY.md#from-python-code)
3. [CLI Usage](../INTEGRATION_SUMMARY.md#from-command-line)
4. [Future Enhancements](../INTEGRATION_SUMMARY.md#future-enhancements-when-needed)

### Architecture & Design
1. [Design Philosophy](../DESIGN_PHILOSOPHY.md)
2. [Structure](../DESIGN_PHILOSOPHY.md#current-structure)
3. [Why Simple?](../DESIGN_PHILOSOPHY.md#why-so-simple)
4. [When to Refactor](../DESIGN_PHILOSOPHY.md#when-to-add-folders)
5. [Refactoring Triggers](../DESIGN_PHILOSOPHY.md#refactoring-triggers)

## Version History

### Version 2.0 (Current)
- ✅ Removed hardcoded paths
- ✅ Added configurable `legacy_root` parameter
- ✅ Implemented recursive file discovery
- ✅ Added custom file extension support
- ✅ Enhanced statistics tracking
- ✅ Maintained backward compatibility

### Version 1.0
- Initial release
- JCL, COBOL, and copybook analysis
- DDL generation for PostgreSQL and SQLite
- Smart filtering (system, backup, duplicates)
- Multi-line JCL parsing

## Quick Reference

### Command-Line Options
```bash
--base-path PATH          # Base path to project (required)
--legacy-root PATH        # Root for legacy code (optional)
--output-dir PATH         # Output directory (required)
--verbose                 # Enable verbose output
--no-system-filter        # Include system files
--no-backup-filter        # Include backup files
--no-duplicate-filter     # Include duplicate formats
--jcl-extensions EXTS     # JCL file extensions
--cbl-extensions EXTS     # COBOL file extensions
--cpy-extensions EXTS     # Copybook file extensions
```

### Configuration Parameters
```python
config = {
    'legacy_root': 'path/to/legacy',
    'jcl_extensions': ['.jcl', '.JCL'],
    'cbl_extensions': ['.cbl', '.CBL', '.cob'],
    'cpy_extensions': ['.cpy', '.CPY'],
    'verbose': True,
    'exclude_system_files': True,
    'exclude_backups': True,
    'exclude_duplicates': True,
}
```

### File Extensions Supported
- **JCL**: `.jcl`, `.JCL` (customizable)
- **COBOL**: `.cbl`, `.CBL`, `.cob`, `.COB` (customizable)
- **Copybooks**: `.cpy`, `.CPY` (customizable)

## Contributing

See the main ACM Tools documentation for contribution guidelines.

## Support

For questions or issues:
1. Check the [Troubleshooting](GETTING_STARTED.md#troubleshooting) section
2. Review the [Migration Guide](MIGRATION_GUIDE.md) for path-related issues
3. Consult the [README](../README.md) for general usage
4. Open an issue in the project repository

## License

Part of the ACM Tools suite.
