# Database Analyzer - Migration Guide

## Overview of Changes

The Database Analyzer has been refactored to remove hardcoded paths and support generic folder structures. This allows the tool to work with any legacy codebase organization, not just the specific `carddemoV2` structure.

## What Changed

### Before (Hardcoded Paths)
```python
self.jcl_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/jcl"
self.cbl_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/cbl"
self.cpy_path = self.base_path / "input/legacy/legacy_code/carddemoV2/app/cpy"
```

### After (Configurable Root with Recursive Search)
```python
self.legacy_root = Path(self.config.get('legacy_root', self.base_path))
# Recursively searches for files with specified extensions
```

## Key Improvements

1. **Configurable Root Path**: Specify where your legacy code lives via `--legacy-root` parameter
2. **Recursive File Discovery**: Automatically finds JCL, COBOL, and copybook files in any subdirectory
3. **Flexible File Extensions**: Configure which file extensions to search for
4. **No Folder Structure Assumptions**: Works regardless of how files are organized

## Configuration Options

### New Config Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `legacy_root` | string | `base_path` | Root directory to search for legacy files |
| `jcl_extensions` | list | `['.jcl', '.JCL']` | File extensions for JCL files |
| `cbl_extensions` | list | `['.cbl', '.CBL', '.cob', '.COB']` | File extensions for COBOL files |
| `cpy_extensions` | list | `['.cpy', '.CPY']` | File extensions for copybook files |

## Usage Examples

### Basic Usage (Backward Compatible)
```bash
# If your legacy code is at base_path, this still works
database-analyzer analyze --base-path . --output-dir output/database
```

### Custom Legacy Root
```bash
# Specify a different root for legacy code
database-analyzer analyze \
  --base-path . \
  --legacy-root input/legacy/legacy_code \
  --output-dir output/database
```

### Custom File Extensions
```bash
# Support additional file extensions
database-analyzer analyze \
  --base-path . \
  --legacy-root src/mainframe \
  --jcl-extensions .jcl,.JCL,.job \
  --cbl-extensions .cbl,.cob,.cobol \
  --cpy-extensions .cpy,.copy \
  --output-dir output/database
```

### Programmatic Usage
```python
from tools.database_analyzer.core.analyzer import DatabaseAnalyzer

config = {
    'legacy_root': '/path/to/legacy/code',
    'jcl_extensions': ['.jcl', '.JCL', '.job'],
    'cbl_extensions': ['.cbl', '.CBL', '.cob'],
    'cpy_extensions': ['.cpy', '.CPY'],
    'verbose': True
}

analyzer = DatabaseAnalyzer(base_path='.', config=config)
results = analyzer.run_analysis()
```

## Migration Steps

### For Existing Users

1. **No changes required** if your structure matches the default:
   - Legacy code at `{base_path}/input/legacy/legacy_code/carddemoV2/app/`
   - Just continue using the tool as before

2. **For custom structures**, add the `--legacy-root` parameter:
   ```bash
   database-analyzer analyze \
     --base-path . \
     --legacy-root your/custom/path \
     --output-dir output/database
   ```

### For New Projects

1. Point `--legacy-root` to wherever your legacy code lives
2. The tool will recursively find all relevant files
3. No need to organize files in a specific folder structure

## Benefits

- **Flexibility**: Works with any folder organization
- **Simplicity**: No need to reorganize existing codebases
- **Scalability**: Handles projects with files scattered across multiple directories
- **Maintainability**: No hardcoded paths to update when structure changes

## Backward Compatibility

The tool remains fully backward compatible. If you don't specify `--legacy-root`, it defaults to `base_path`, maintaining the original behavior for existing users.

## Statistics Enhancement

The tool now tracks additional statistics:
- JCL files scanned
- COBOL files scanned  
- Copybook files scanned

This helps you understand what the tool is processing during analysis.

## Path Resolution Summary

| Scenario | Configuration | Result |
|----------|---------------|--------|
| Default | No `legacy_root` specified | Searches from `base_path` |
| Custom Root | `--legacy-root /custom/path` | Searches from `/custom/path` |
| Relative Path | `--legacy-root input/legacy` | Resolves relative to current directory |
| Absolute Path | `--legacy-root /absolute/path` | Uses absolute path directly |

## Questions?

For issues or questions, please refer to the main README or open an issue in the project repository.
