#!/usr/bin/env python3
"""
Database Analyzer Tool for Legacy File System Analysis
Analyzes JCL, COBOL, and copybook files to discover Sequential and VSAM files
"""

import os
import re
import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set

class DatabaseAnalyzer:
    def __init__(self, base_path: str, config: dict = None):
        self.base_path = Path(base_path)
        
        self.config = config or {}
        self.verbose = self.config.get('verbose', True)
        
        # Configurable root path for legacy code (defaults to base_path for backward compatibility)
        self.legacy_root = Path(self.config.get('legacy_root', self.base_path))
        
        # File extensions to search for (configurable)
        self.jcl_extensions = self.config.get('jcl_extensions', ['.jcl', '.JCL'])
        self.cbl_extensions = self.config.get('cbl_extensions', ['.cbl', '.CBL', '.cob', '.COB'])
        self.cpy_extensions = self.config.get('cpy_extensions', ['.cpy', '.CPY'])

        # Filtering configuration
        self.exclude_system_files = self.config.get('exclude_system_files', True)
        self.exclude_backups = self.config.get('exclude_backups', True)
        self.exclude_duplicates = self.config.get('exclude_duplicates', True)

        self.sequential_files = {}
        self.vsam_files = {}
        self.cobol_files = {}
        self.copybooks = {}
        self.file_to_table = {}
        self.excluded_files = {}
        self.processed_primaries = set()

        # Statistics
        self.stats = {
            'total_found': 0,
            'system_files': 0,
            'backups': 0,
            'duplicates': 0,
            'included': 0,
            'jcl_files_scanned': 0,
            'cbl_files_scanned': 0,
            'cpy_files_scanned': 0
        }

    def is_system_file(self, dsn: str) -> bool:
        """Identify system/infrastructure files to exclude"""
        system_patterns = [
            r'\.LOADLIB$', r'SDFHLOAD', r'DFHCSD', r'\.STEPLIB',
            r'^OEM\.', r'\.PROCLIB', r'\.PARMLIB', r'ESDSRRDS\.PS$',
        ]
        dsn_upper = dsn.upper()
        return any(re.search(pattern, dsn_upper) for pattern in system_patterns)

    def is_backup_file(self, dsn: str) -> bool:
        """Identify backup files to exclude"""
        backup_patterns = [r'\.BKUP', r'\.BACKUP', r'\.BAK', r'\([\+\-]\d+\)']
        dsn_upper = dsn.upper()
        return any(re.search(pattern, dsn_upper) for pattern in backup_patterns)

    def get_primary_dsn(self, dsn: str) -> str:
        """Get primary DSN by removing format suffixes"""
        dsn_clean = re.sub(r'\.(PSCOMP|ARRYPS|VBPS|SEQ)$', '', dsn, flags=re.IGNORECASE)
        dsn_clean = re.sub(r'\.VSAM\.(ESDS|RRDS)$', '.VSAM.KSDS', dsn_clean, flags=re.IGNORECASE)
        dsn_clean = re.sub(r'\.PS$', '', dsn_clean, flags=re.IGNORECASE)
        return dsn_clean

    def should_prefer_over_existing(self, dsn: str, existing_dsn: str) -> bool:
        """Determine if new DSN should replace existing one"""
        if '.VSAM.KSDS' in dsn.upper() and '.VSAM.KSDS' not in existing_dsn.upper():
            return True
        if '.VSAM.' in dsn.upper() and '.PS' in existing_dsn.upper():
            return True
        return False


        
    def _find_files_by_extension(self, root_path: Path, extensions: List[str]) -> List[Path]:
        """Recursively find all files with given extensions under root_path"""
        files = []
        if not root_path.exists():
            if self.verbose:
                print(f"Warning: Path does not exist: {root_path}")
            return files
        
        for ext in extensions:
            # Use rglob for recursive search with pattern
            files.extend(root_path.rglob(f"*{ext}"))
        
        return sorted(files)
    
    def analyze_jcl_files(self):
        """Analyze JCL files for DD statements with improved multi-line handling and filtering"""
        jcl_files = self._find_files_by_extension(self.legacy_root, self.jcl_extensions)
        
        if self.verbose:
            print(f"Found {len(jcl_files)} JCL files to analyze")
        
        for jcl_file in jcl_files:
            self.stats['jcl_files_scanned'] += 1
            try:
                with open(jcl_file, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()

                # Merge JCL continuation lines
                merged_lines = []
                current_line = ""
                for line in lines:
                    # JCL continuation: line starts with // followed by spaces
                    if line.startswith('//') and len(line) > 2 and line[2] == ' ':
                        current_line += " " + line[2:].strip()
                    else:
                        if current_line:
                            merged_lines.append(current_line)
                        current_line = line.strip()
                if current_line:
                    merged_lines.append(current_line)

                content = "\n".join(merged_lines)

                # Find DD statements with DSN parameters
                dd_pattern = r'//(\w+)\s+DD\s+.*?DSN=([^,\s\n]+)'
                matches = re.findall(dd_pattern, content, re.IGNORECASE)

                # Also look for VSAM definitions in IDCAMS
                vsam_pattern = r'DEFINE\s+CLUSTER\s*\(\s*NAME\(([^)]+)\)'
                vsam_matches = re.findall(vsam_pattern, content, re.IGNORECASE | re.MULTILINE)

                for dd_name, dsn in matches:
                    self.stats['total_found'] += 1

                    # Apply filters
                    if self.exclude_system_files and self.is_system_file(dsn):
                        self.stats['system_files'] += 1
                        self.excluded_files[dsn] = "System file"
                        if self.verbose:
                            print(f"  [SKIP] System file: {dsn}")
                        continue

                    if self.exclude_backups and self.is_backup_file(dsn):
                        self.stats['backups'] += 1
                        self.excluded_files[dsn] = "Backup file"
                        if self.verbose:
                            print(f"  [SKIP] Backup file: {dsn}")
                        continue

                    primary_dsn = self.get_primary_dsn(dsn)

                    # Check for duplicates
                    if self.exclude_duplicates and primary_dsn in self.processed_primaries:
                        existing_dsn = None
                        for existing in list(self.sequential_files.keys()) + list(self.vsam_files.keys()):
                            if self.get_primary_dsn(existing) == primary_dsn:
                                existing_dsn = existing
                                break

                        if existing_dsn and self.should_prefer_over_existing(dsn, existing_dsn):
                            if existing_dsn in self.sequential_files:
                                del self.sequential_files[existing_dsn]
                            if existing_dsn in self.vsam_files:
                                del self.vsam_files[existing_dsn]
                            if self.verbose:
                                print(f"  [REPLACE] {existing_dsn} with {dsn}")
                        else:
                            self.stats['duplicates'] += 1
                            self.excluded_files[dsn] = f"Duplicate format (primary: {primary_dsn})"
                            if self.verbose:
                                print(f"  [SKIP] Duplicate format: {dsn}")
                            continue

                    # Process the file
                    file_type = self.determine_file_type(dsn, content)

                    if file_type == 'PS':
                        self.sequential_files[dsn] = {
                            'dd_name': dd_name,
                            'source_jcl': jcl_file.name,
                            'organization': 'PS',
                            'dsn': dsn,
                            'primary_dsn': primary_dsn
                        }
                        self.processed_primaries.add(primary_dsn)
                        self.stats['included'] += 1
                        if self.verbose:
                            print(f"  [INCLUDE] Sequential: {dsn}")

                    elif file_type in ['VSAM_KSDS', 'VSAM_ESDS', 'VSAM_RRDS']:
                        self.vsam_files[dsn] = {
                            'dd_name': dd_name,
                            'source_jcl': jcl_file.name,
                            'organization': file_type,
                            'dsn': dsn,
                            'primary_dsn': primary_dsn
                        }
                        self.processed_primaries.add(primary_dsn)
                        self.stats['included'] += 1
                        if self.verbose:
                            print(f"  [INCLUDE] VSAM {file_type}: {dsn}")

                # Process VSAM definitions
                for vsam_name in vsam_matches:
                    if not self.is_system_file(vsam_name) and not self.is_backup_file(vsam_name):
                        file_type = self.determine_file_type(vsam_name, content)
                        primary_dsn = self.get_primary_dsn(vsam_name)
                        if primary_dsn not in self.processed_primaries:
                            self.vsam_files[vsam_name] = {
                                'dd_name': 'VSAM_CLUSTER',
                                'source_jcl': jcl_file.name,
                                'organization': file_type,
                                'dsn': vsam_name,
                                'primary_dsn': primary_dsn
                            }
                            self.processed_primaries.add(primary_dsn)
                            self.stats['included'] += 1

            except Exception as e:
                print(f"Error processing JCL file {jcl_file}: {e}")

    
    def determine_file_type(self, dsn: str, content: str) -> str:
        """Determine file type based on DSN and JCL content"""
        dsn_upper = dsn.upper()
        
        if '.PS' in dsn_upper:
            return 'PS'
        elif '.VSAM.KSDS' in dsn_upper or dsn_upper.endswith('.KSDS'):
            return 'VSAM_KSDS'
        elif '.VSAM.ESDS' in dsn_upper or dsn_upper.endswith('.ESDS'):
            return 'VSAM_ESDS'
        elif '.VSAM.RRDS' in dsn_upper or dsn_upper.endswith('.RRDS'):
            return 'VSAM_RRDS'
        elif '.VSAM.' in dsn_upper:
            return 'VSAM_KSDS'  # Default VSAM type
        else:
            return 'PS'  # Default to sequential
    
    def analyze_cobol_files(self):
        """Analyze COBOL files for SELECT statements and file definitions"""
        cbl_files = self._find_files_by_extension(self.legacy_root, self.cbl_extensions)
        
        if self.verbose:
            print(f"Found {len(cbl_files)} COBOL files to analyze")
        
        for cbl_file in cbl_files:
            self.stats['cbl_files_scanned'] += 1
            try:
                with open(cbl_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    
                # Find SELECT statements with better pattern matching
                select_pattern = r'SELECT\s+(\w+(?:-\w+)*)\s+ASSIGN\s+TO\s+(\w+)(?:.*?ORGANIZATION\s+IS\s+(\w+))?'
                matches = re.findall(select_pattern, content, re.IGNORECASE | re.MULTILINE | re.DOTALL)
                
                for file_name, assign_to, org in matches:
                    org = org or 'SEQUENTIAL'
                    self.cobol_files[file_name] = {
                        'assign_to': assign_to,
                        'organization': org,
                        'source_cobol': cbl_file.name
                    }
                    
                    # Match with JCL files
                    if org.upper() in ['SEQUENTIAL', '']:
                        for dsn, jcl_info in self.sequential_files.items():
                            if jcl_info['dd_name'].upper() == assign_to.upper():
                                jcl_info['cobol_file'] = file_name
                                jcl_info['cobol_source'] = cbl_file.name
                    elif org.upper() == 'INDEXED':
                        for dsn, vsam_info in self.vsam_files.items():
                            if vsam_info['dd_name'].upper() == assign_to.upper():
                                vsam_info['cobol_file'] = file_name
                                vsam_info['cobol_source'] = cbl_file.name
                                
            except Exception as e:
                print(f"Error processing COBOL file {cbl_file}: {e}")
    
    def analyze_copybooks(self):
        """Analyze copybooks for record structures"""
        cpy_files = self._find_files_by_extension(self.legacy_root, self.cpy_extensions)
        
        if self.verbose:
            print(f"Found {len(cpy_files)} copybook files to analyze")
        
        for cpy_file in cpy_files:
            self.stats['cpy_files_scanned'] += 1
            try:
                with open(cpy_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    
                fields = self.parse_cobol_record(content)
                self.copybooks[cpy_file.stem] = {
                    'fields': fields,
                    'source_file': cpy_file.name
                }
                
            except Exception as e:
                print(f"Error processing copybook {cpy_file}: {e}")
    
    def parse_cobol_record(self, content: str) -> List[Dict]:
        """Parse COBOL record structure from copybook content"""
        fields = []
        lines = content.split('\n')
        
        for line in lines:
            # Remove line numbers and clean up
            line = re.sub(r'^\d{6}', '', line)
            line = line.strip()
            
            if not line or line.startswith('*') or line.startswith('/'):
                continue
                
            # Match field definitions (01, 05, 10, etc. levels)
            field_pattern = r'(\d{2})\s+(\w+(?:-\w+)*)\s+(?:REDEFINES\s+\w+\s+)?PIC\s+([X9SAVCZ\(\)\d\-\+\.V]+)(?:\s+VALUE\s+[^.]+)?'
            match = re.search(field_pattern, line, re.IGNORECASE)
            
            if match:
                level, name, pic = match.groups()
                sql_type, length, precision, scale = self.parse_pic_clause(pic)
                
                fields.append({
                    'level': int(level),
                    'name': name.replace('-', '_').lower(),
                    'pic': pic,
                    'sql_type': sql_type,
                    'length': length,
                    'precision': precision,
                    'scale': scale
                })
        
        return fields
    
    def parse_pic_clause(self, pic: str) -> Tuple[str, int, int, int]:
        """Parse PIC clause to determine SQL type, length, precision, scale"""
        pic = pic.upper().strip()
        length = 0
        precision = 0
        scale = 0
        
        # Handle signed fields
        is_signed = 'S' in pic
        
        # Handle decimal fields
        has_decimal = 'V' in pic
        
        if 'X' in pic:
            # Character field - PIC X(n) or PIC XXX
            length_match = re.search(r'X\((\d+)\)', pic)
            if length_match:
                length = int(length_match.group(1))
            else:
                length = pic.count('X')
            
            if length <= 255:
                return f'VARCHAR({length})', length, 0, 0
            else:
                return 'TEXT', length, 0, 0
                
        elif '9' in pic:
            # Numeric field - PIC 9(n) or PIC 999
            if has_decimal:
                # Handle decimal: S9(7)V99 or 9(5)V9(2)
                parts = pic.split('V')
                integer_part = parts[0]
                decimal_part = parts[1] if len(parts) > 1 else ''
                
                # Extract integer digits
                int_match = re.search(r'9\((\d+)\)', integer_part)
                if int_match:
                    precision = int(int_match.group(1))
                else:
                    precision = integer_part.count('9')
                
                # Extract decimal digits
                dec_match = re.search(r'9\((\d+)\)', decimal_part)
                if dec_match:
                    scale = int(dec_match.group(1))
                else:
                    scale = decimal_part.count('9')
                
                total_precision = precision + scale
                return f'DECIMAL({total_precision}, {scale})', total_precision, precision, scale
            else:
                # Integer field
                length_match = re.search(r'9\((\d+)\)', pic)
                if length_match:
                    length = int(length_match.group(1))
                else:
                    length = pic.count('9')
                
                if length <= 4:
                    return 'INTEGER', length, length, 0
                elif length <= 9:
                    return 'BIGINT', length, length, 0
                else:
                    return f'DECIMAL({length}, 0)', length, length, 0
        
        elif 'A' in pic:
            # Alphabetic field - PIC A(n) or PIC AAA
            length_match = re.search(r'A\((\d+)\)', pic)
            if length_match:
                length = int(length_match.group(1))
            else:
                length = pic.count('A')
            return f'VARCHAR({length})', length, 0, 0
        
        # Handle COMP fields
        if 'COMP-3' in pic or 'COMP3' in pic:
            # Packed decimal
            return f'DECIMAL({precision or 15}, {scale or 2})', precision or 15, precision or 15, scale or 2
        elif 'COMP' in pic:
            # Binary
            return 'INTEGER', 4, 4, 0
            
        return 'TEXT', 0, 0, 0
    
    def find_matching_copybook(self, dsn: str) -> Optional[Dict]:
        """Find matching copybook for a given DSN with improved matching"""
        dsn_upper = dsn.upper()
        
        # Enhanced direct matching patterns - map file names to copybooks
        patterns = {
            'CUSTDATA': 'CUSTREC',
            'ACCTDATA': 'CVACT01Y', 
            'CARDDATA': 'CVACT02Y',  # Fixed to use correct copybook
            'CARDXREF': 'CVACT03Y',  # Fixed to use correct copybook
            'TRANSACT': 'CVTRA01Y',
            'TRANCATG': 'CVTRA01Y',
            'DISCGRP': 'CVTRA01Y',
            'USRSEC': 'CSUSR01Y',
            'TCATBALF': 'CVTRA01Y',  # Added missing mapping
            'TRANTYPE': 'CVTRA01Y'   # Added missing mapping
        }
        
        for pattern, copybook in patterns.items():
            if pattern in dsn_upper and copybook in self.copybooks:
                return self.copybooks[copybook]
        
        # Enhanced partial name matching with more flexibility
        dsn_parts = dsn_upper.replace('.', ' ').replace('-', ' ').split()
        for dsn_part in dsn_parts:
            for cpy_name, cpy_info in self.copybooks.items():
                cpy_upper = cpy_name.upper()
                # Check if any part of DSN matches copybook name
                if (dsn_part in cpy_upper or cpy_upper in dsn_part or
                    any(part in cpy_upper for part in dsn_part.split('_')) or
                    any(part in dsn_part for part in cpy_upper.split('_'))):
                    return cpy_info
        
        return None
    
    def find_natural_key_field(self, copybook_info: Dict) -> Optional[str]:
        """Find the natural key field for VSAM KSDS from copybook"""
        if not copybook_info or not copybook_info.get('fields'):
            return None
            
        # Look for fields that are likely to be keys
        for field in copybook_info['fields']:
            if field['level'] == 5:  # Only 05 level fields
                field_name = field['name'].lower()
                # Check for common key patterns
                if (field_name.endswith('_id') or 
                    field_name.endswith('_num') or
                    field_name.endswith('_key') or
                    'id' in field_name or
                    'key' in field_name or
                    'num' in field_name):
                    return field['name']
        
        # If no obvious key found, return the first field as natural key
        for field in copybook_info['fields']:
            if field['level'] == 5:
                return field['name']
                
        return None
    
    def generate_sqlite_ddl(self) -> str:
        """Generate SQLite DDL for all discovered files"""
        ddl = "-- SQLite DDL for Legacy File System\n"
        ddl += "-- Generated by Database Analyzer Tool\n\n"
        
        self.file_to_table.clear()  # Reset for fresh generation
        
        # Generate tables for Sequential files
        for dsn, info in self.sequential_files.items():
            table_name = self.sanitize_table_name(dsn)
            if dsn in self.file_to_table:
                continue  # Skip duplicates
            
            self.file_to_table[dsn] = table_name
            
            ddl += f"-- Source: JCL file {info['source_jcl']}, DD name {info['dd_name']}\n"
            ddl += f"-- Sequential File: {dsn}\n"
            ddl += f"CREATE TABLE {table_name} (\n"
            ddl += "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
            ddl += "    sequence_number INTEGER NOT NULL,\n"
            
            # Try to find matching copybook and use actual fields
            copybook_info = self.find_matching_copybook(dsn)
            if copybook_info and copybook_info['fields']:
                for field in copybook_info['fields']:
                    if field['level'] == 5:  # Only include 05 level fields
                        ddl += f"    {field['name']} {field['sql_type']},\n"
            else:
                ddl += "    record_data TEXT,\n"
            
            ddl = ddl.rstrip(',\n') + "\n);\n\n"
            ddl += f"CREATE INDEX idx_{table_name}_seq ON {table_name}(sequence_number);\n\n"
        
        # Generate tables for VSAM files
        for dsn, info in self.vsam_files.items():
            table_name = self.sanitize_table_name(dsn)
            if dsn in self.file_to_table:
                continue  # Skip duplicates
            
            self.file_to_table[dsn] = table_name
            
            ddl += f"-- Source: JCL file {info['source_jcl']}, DD name {info['dd_name']}\n"
            ddl += f"-- VSAM File ({info['organization']}): {dsn}\n"
            ddl += f"CREATE TABLE {table_name} (\n"
            
            # Try to find matching copybook
            copybook_info = self.find_matching_copybook(dsn)
            if copybook_info and copybook_info['fields']:
                # For VSAM KSDS, use natural key as PRIMARY KEY (NO surrogate id, NO sequence_number)
                if info['organization'] == 'VSAM_KSDS':
                    natural_key = self.find_natural_key_field(copybook_info)
                    primary_key_set = False
                    
                    # Add all fields, making natural key the PRIMARY KEY
                    for field in copybook_info['fields']:
                        if field['level'] == 5:
                            if field['name'] == natural_key and not primary_key_set:
                                ddl += f"    {field['name']} {field['sql_type']} PRIMARY KEY,\n"
                                primary_key_set = True
                            else:
                                ddl += f"    {field['name']} {field['sql_type']},\n"
                    
                    # If no natural key was found, use first field as primary key
                    if not primary_key_set:
                        first_field = next((f for f in copybook_info['fields'] if f['level'] == 5), None)
                        if first_field:
                            # Replace the first field definition with PRIMARY KEY version
                            ddl_lines = ddl.split('\n')
                            for i, line in enumerate(ddl_lines):
                                if first_field['name'] in line and 'PRIMARY KEY' not in line:
                                    ddl_lines[i] = line.replace(f"{first_field['sql_type']},", f"{first_field['sql_type']} PRIMARY KEY,")
                                    break
                            ddl = '\n'.join(ddl_lines)
                
                # For ESDS, add surrogate key and sequence number
                elif info['organization'] == 'VSAM_ESDS':
                    ddl += "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                    ddl += "    sequence_number INTEGER NOT NULL,\n"
                    
                    # Add all other fields
                    for field in copybook_info['fields']:
                        if field['level'] == 5:
                            ddl += f"    {field['name']} {field['sql_type']},\n"
                
                # For RRDS, add relative record number
                elif info['organization'] == 'VSAM_RRDS':
                    ddl += "    relative_record_number INTEGER PRIMARY KEY,\n"
                    
                    # Add all other fields
                    for field in copybook_info['fields']:
                        if field['level'] == 5:
                            ddl += f"    {field['name']} {field['sql_type']},\n"
            else:
                # No copybook found - use default structure
                if info['organization'] == 'VSAM_KSDS':
                    ddl += "    record_key VARCHAR(50) PRIMARY KEY,\n"  # Generic natural key
                elif info['organization'] == 'VSAM_ESDS':
                    ddl += "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                    ddl += "    sequence_number INTEGER NOT NULL,\n"
                else:  # RRDS
                    ddl += "    relative_record_number INTEGER PRIMARY KEY,\n"
                ddl += "    record_data TEXT,\n"
            
            ddl = ddl.rstrip(',\n') + "\n);\n\n"
        
        return ddl
    
    def generate_postgresql_ddl(self) -> str:
        """Generate PostgreSQL DDL for all discovered files"""
        ddl = "-- PostgreSQL DDL for Legacy File System\n"
        ddl += "-- Generated by Database Analyzer Tool\n\n"
        
        self.file_to_table.clear()  # Reset for fresh generation
        
        # Generate tables for Sequential files
        for dsn, info in self.sequential_files.items():
            table_name = self.sanitize_table_name(dsn)
            if dsn in self.file_to_table:
                continue  # Skip duplicates
            
            self.file_to_table[dsn] = table_name
            
            ddl += f"-- Source: JCL file {info['source_jcl']}, DD name {info['dd_name']}\n"
            ddl += f"-- Sequential File: {dsn}\n"
            ddl += f"CREATE TABLE {table_name} (\n"
            ddl += "    id SERIAL PRIMARY KEY,\n"
            ddl += "    sequence_number INTEGER NOT NULL,\n"
            
            # Try to find matching copybook and use actual fields
            copybook_info = self.find_matching_copybook(dsn)
            if copybook_info and copybook_info['fields']:
                for field in copybook_info['fields']:
                    if field['level'] == 5:  # Only include 05 level fields
                        ddl += f"    {field['name']} {field['sql_type']},\n"
            else:
                ddl += "    record_data TEXT,\n"
            
            ddl = ddl.rstrip(',\n') + "\n);\n\n"
            ddl += f"CREATE INDEX idx_{table_name}_seq ON {table_name}(sequence_number);\n\n"
        
        # Generate tables for VSAM files
        for dsn, info in self.vsam_files.items():
            table_name = self.sanitize_table_name(dsn)
            if dsn in self.file_to_table:
                continue  # Skip duplicates
            
            self.file_to_table[dsn] = table_name
            
            ddl += f"-- Source: JCL file {info['source_jcl']}, DD name {info['dd_name']}\n"
            ddl += f"-- VSAM File ({info['organization']}): {dsn}\n"
            ddl += f"CREATE TABLE {table_name} (\n"
            
            # Try to find matching copybook
            copybook_info = self.find_matching_copybook(dsn)
            if copybook_info and copybook_info['fields']:
                # For VSAM KSDS, use natural key as PRIMARY KEY (NO surrogate id, NO sequence_number)
                if info['organization'] == 'VSAM_KSDS':
                    natural_key = self.find_natural_key_field(copybook_info)
                    primary_key_set = False
                    
                    # Add all fields, making natural key the PRIMARY KEY
                    for field in copybook_info['fields']:
                        if field['level'] == 5:
                            if field['name'] == natural_key and not primary_key_set:
                                ddl += f"    {field['name']} {field['sql_type']} PRIMARY KEY,\n"
                                primary_key_set = True
                            else:
                                ddl += f"    {field['name']} {field['sql_type']},\n"
                    
                    # If no natural key was found, use first field as primary key
                    if not primary_key_set:
                        first_field = next((f for f in copybook_info['fields'] if f['level'] == 5), None)
                        if first_field:
                            # Replace the first field definition with PRIMARY KEY version
                            ddl_lines = ddl.split('\n')
                            for i, line in enumerate(ddl_lines):
                                if first_field['name'] in line and 'PRIMARY KEY' not in line:
                                    ddl_lines[i] = line.replace(f"{first_field['sql_type']},", f"{first_field['sql_type']} PRIMARY KEY,")
                                    break
                            ddl = '\n'.join(ddl_lines)
                
                # For ESDS, add surrogate key and sequence number
                elif info['organization'] == 'VSAM_ESDS':
                    ddl += "    id SERIAL PRIMARY KEY,\n"
                    ddl += "    sequence_number INTEGER NOT NULL,\n"
                    
                    # Add all other fields
                    for field in copybook_info['fields']:
                        if field['level'] == 5:
                            ddl += f"    {field['name']} {field['sql_type']},\n"
                
                # For RRDS, add relative record number
                elif info['organization'] == 'VSAM_RRDS':
                    ddl += "    relative_record_number INTEGER PRIMARY KEY,\n"
                    
                    # Add all other fields
                    for field in copybook_info['fields']:
                        if field['level'] == 5:
                            ddl += f"    {field['name']} {field['sql_type']},\n"
            else:
                # No copybook found - use default structure
                if info['organization'] == 'VSAM_KSDS':
                    ddl += "    record_key VARCHAR(50) PRIMARY KEY,\n"  # Generic natural key
                elif info['organization'] == 'VSAM_ESDS':
                    ddl += "    id SERIAL PRIMARY KEY,\n"
                    ddl += "    sequence_number INTEGER NOT NULL,\n"
                else:  # RRDS
                    ddl += "    relative_record_number INTEGER PRIMARY KEY,\n"
                ddl += "    record_data TEXT,\n"
            
            ddl = ddl.rstrip(',\n') + "\n);\n\n"
        
        return ddl
    
    def sanitize_table_name(self, name: str) -> str:
        """Convert DSN or file name to valid SQL table name"""
        # Remove dots and special characters, convert to lowercase
        clean_name = re.sub(r'[^a-zA-Z0-9_]', '_', name.lower())
        # Ensure it starts with a letter
        if clean_name and clean_name[0].isdigit():
            clean_name = 'tbl_' + clean_name
        return clean_name
    
    def generate_migration_scripts(self, target: str) -> str:
        """Generate data migration scripts"""
        script = f"-- {target.upper()} Data Migration Scripts\n"
        script += "-- Generated by Database Analyzer Tool\n\n"
        
        for dsn, info in self.sequential_files.items():
            table_name = self.sanitize_table_name(dsn)
            script += f"-- Migration for {table_name}\n"
            script += f"-- Source: {dsn}\n"
            script += f"INSERT INTO {table_name} (sequence_number, record_data) VALUES\n"
            script += "-- Data to be loaded from source files\n"
            script += "-- Use appropriate ETL process for data conversion\n\n"
        
        return script

    def print_statistics(self):
        """Print analysis statistics"""
        print(f"\n{'='*60}")
        print("Analysis Summary:")
        print(f"{'='*60}")
        print(f"  JCL files scanned:           {self.stats['jcl_files_scanned']}")
        print(f"  COBOL files scanned:         {self.stats['cbl_files_scanned']}")
        print(f"  Copybook files scanned:      {self.stats['cpy_files_scanned']}")
        print(f"  Total DSNs found:            {self.stats['total_found']}")
        print(f"  System files excluded:       {self.stats['system_files']}")
        print(f"  Backup files excluded:       {self.stats['backups']}")
        print(f"  Duplicate formats excluded:  {self.stats['duplicates']}")
        print(f"  Files included:              {self.stats['included']}")
        print(f"{'='*60}\n")

    
    def run_analysis(self):
        """Run complete analysis"""
        print("Starting database analysis...")

        print("\nAnalyzing JCL files...")
        self.analyze_jcl_files()

        print("\nAnalyzing COBOL files...")
        self.analyze_cobol_files()

        print("\nAnalyzing copybooks...")
        self.analyze_copybooks()

        self.print_statistics()

        print(f"Found {len(self.sequential_files)} Sequential files")
        print(f"Found {len(self.vsam_files)} VSAM files")
        print(f"Found {len(self.cobol_files)} COBOL file definitions")
        print(f"Found {len(self.copybooks)} copybooks")

        return {
            'sequential_files': self.sequential_files,
            'vsam_files': self.vsam_files,
            'cobol_files': self.cobol_files,
            'copybooks': self.copybooks,
            'excluded_files': self.excluded_files,
            'stats': self.stats
        }


def main():
    parser = argparse.ArgumentParser(description='Database Analyzer for Legacy File Systems')
    parser.add_argument('--base-path', required=True, help='Base path to project directory')
    parser.add_argument('--output-dir', required=True, help='Output directory for generated files')
    
    args = parser.parse_args()
    
    analyzer = DatabaseAnalyzer(args.base_path)
    results = analyzer.run_analysis()
    
    # Generate DDL files
    sqlite_ddl = analyzer.generate_sqlite_ddl()
    postgresql_ddl = analyzer.generate_postgresql_ddl()
    
    # Generate migration scripts
    sqlite_migration = analyzer.generate_migration_scripts('sqlite')
    postgresql_migration = analyzer.generate_migration_scripts('postgresql')
    
    # Write output files
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    with open(output_dir / 'sqlite_ddl.sql', 'w') as f:
        f.write(sqlite_ddl)
    
    with open(output_dir / 'postgresql_ddl.sql', 'w') as f:
        f.write(postgresql_ddl)
    
    with open(output_dir / 'sqlite_migration.sql', 'w') as f:
        f.write(sqlite_migration)
    
    with open(output_dir / 'postgresql_migration.sql', 'w') as f:
        f.write(postgresql_migration)
    
    print(f"Analysis complete. Files generated in {output_dir}")

if __name__ == '__main__':
    main()