# SMF Test Data Generator Configuration Guide

This directory contains example configuration files for the SMF Test Data Generator. These configurations demonstrate how to generate synthetic SMF records for testing and demonstration purposes.

## Configuration Files

### carddemo_smf_generation_inventory.yaml
Example configuration using **inventory mode** with an existing inventory database. This mode is ideal when you have a catalog of mainframe artifacts but no actual SMF data.

**Key characteristics:**
- Uses inventory database with artifact catalog
- Infrastructure: 1000 MIPS, 500GB storage, 50000 IOPS
- Generates all 10 record types (30, 110, 14, 15, 17, 62, 64, 100, 101, 102)
- 12 months of data (2023-01-01 to 2023-12-31)

### carddemo_smf_generation_sourcecode.yaml
Example configuration using **source-code mode** with an analyzed source code database. This mode leverages dependency information from static code analysis.

**Key characteristics:**
- Uses analysis database with dependency information
- Infrastructure: 500 MIPS, 250GB storage, 25000 IOPS (smaller system)
- Generates all 10 record types with dependency-aware references
- 12 months of data (2023-01-01 to 2023-12-31)

## Configuration File Format

### Top-Level Structure

```yaml
generation_mode: inventory | source-code
database_path: <path_to_database>
output_directory: <output_path>
application_name: <app_name>
time_range:
  start_date: YYYY-MM-DD
  end_date: YYYY-MM-DD
record_types: [30, 110, 14, 15, 17, 62, 64, 100, 101, 102]
infrastructure: { ... }
active_artifacts: { ... }
unreferenced_artifacts: { ... }
missing_artifacts: { ... }
```

## Configuration Sections

### 1. Generation Mode

```yaml
generation_mode: inventory  # or 'source-code'
```

**Options:**
- `inventory`: Uses existing inventory database with artifact catalog
- `source-code`: Uses analyzed source code database with dependency information

**When to use inventory mode:**
- You have an inventory database from a discovery tool
- You want to generate SMF data for cataloged artifacts
- You don't have dependency information

**When to use source-code mode:**
- You have analyzed source code with the legacy_analyzer
- You want to leverage dependency information for realistic cross-references
- You want to demonstrate analysis-driven data generation

### 2. Database Path

```yaml
database_path: ./databases/carddemo_inventory.db
```

**Expected database tables:**

For **inventory mode**:
- `inventory_programs` - COBOL/PL/I programs
- `inventory_jcl` - JCL jobs
- `inventory_datasets` - Datasets (VSAM, sequential, etc.)
- `inventory_cics` - CICS transactions and programs

For **source-code mode** (includes all inventory tables plus):
- `artifact_dependencies` - Cross-artifact dependencies from analysis

### 3. Output Configuration

```yaml
output_directory: ./examples/data/carddemo_smf
application_name: carddemo
```

**Output files created:**
- `smf30_carddemo.json` - Batch job accounting records
- `smf110_carddemo.json` - CICS transaction performance records
- `smf14_carddemo.json` - INPUT dataset activity records
- `smf15_carddemo.json` - OUTPUT dataset activity records
- `smf17_carddemo.json` - Dataset deletion records
- `smf62_carddemo.json` - VSAM open records
- `smf64_carddemo.json` - VSAM close records
- `smf100_carddemo.json` - DB2 statistics records
- `smf101_carddemo.json` - DB2 accounting records
- `smf102_carddemo.json` - DB2 performance records

### 4. Time Range

```yaml
time_range:
  start_date: 2023-01-01  # YYYY-MM-DD format
  end_date: 2023-12-31    # YYYY-MM-DD format
```

**Date format:** YYYY-MM-DD (ISO 8601)

**Recommendations:**
- Use at least 30 days for meaningful patterns
- Use 12 months for annual analysis
- Longer ranges show seasonal patterns

**Generated timestamps:**
- Batch jobs: Business hours (8am-6pm weekdays)
- CICS transactions: 24/7 distribution
- Dataset operations: Business hours

### 5. Record Types

```yaml
record_types:
  - 30   # Batch job accounting
  - 110  # CICS transaction performance
  - 14   # INPUT dataset activity
  - 15   # OUTPUT dataset activity
  - 17   # Dataset deletion/scratch
  - 62   # VSAM open operations
  - 64   # VSAM close operations
  - 100  # DB2 statistics
  - 101  # DB2 accounting
  - 102  # DB2 performance
```

**Supported record types:**
- **Type 30**: Batch job and step accounting (CPU, I/O, storage)
- **Type 110**: CICS transaction performance (response time, CPU)
- **Type 14**: INPUT dataset activity (opens, reads, EXCP counts)
- **Type 15**: OUTPUT dataset activity (opens, writes, EXCP counts)
- **Type 17**: Dataset scratch/deletion events
- **Type 62**: VSAM open operations (access mode, status)
- **Type 64**: VSAM close operations (performance metrics)
- **Type 100**: DB2 statistics (SQL stats, buffer pool, latch stats, DDF)
- **Type 101**: DB2 accounting (CPU times, I/O metrics, wait times, commits/aborts)
- **Type 102**: DB2 performance (detailed DB2 metrics, correlation, trace, CPU headers)

**Default:** If not specified, generates Types 30 and 110 only.

### 6. Infrastructure Parameters

```yaml
infrastructure:
  mips: 1000              # CPU capacity in MIPS
  storage_gb: 500         # Storage capacity in GB
  iops: 50000             # I/O operations per second
  network_mbps: 10000     # Network throughput in Mbps
```

**All parameters are optional.** If not specified, defaults are used.

#### MIPS (CPU Capacity)

**Effect on generated data:**
- Higher MIPS → Lower CPU times for same workload
- Lower MIPS → Higher CPU times for same workload

**Examples:**
- `mips: 2000` - High-performance system (faster CPU times)
- `mips: 1000` - Standard system (default)
- `mips: 500` - Lower-performance system (slower CPU times)

**Scaling formula:** CPU time scales inversely with MIPS
- 2000 MIPS system: 50% of baseline CPU time
- 500 MIPS system: 200% of baseline CPU time

#### Storage (Capacity)

**Effect on generated data:**
- Influences storage usage values in Type 30 records
- Affects region size and memory allocation

**Examples:**
- `storage_gb: 1000` - Large system
- `storage_gb: 500` - Standard system (default)
- `storage_gb: 250` - Smaller system

#### IOPS (I/O Performance)

**Effect on generated data:**
- Higher IOPS → More I/O operations, faster I/O times
- Lower IOPS → Fewer I/O operations, slower I/O times

**Examples:**
- `iops: 100000` - High-performance storage
- `iops: 50000` - Standard storage (default)
- `iops: 25000` - Lower-performance storage

**Affects:**
- EXCP counts in Type 30, 14, 15, 64 records
- I/O timing in Type 30 records

#### Network (Throughput)

**Effect on generated data:**
- Influences network transfer times
- Affects distributed transaction timing

**Examples:**
- `network_mbps: 20000` - High-speed network
- `network_mbps: 10000` - Standard network (default)
- `network_mbps: 5000` - Lower-speed network

### 7. Active Artifacts

```yaml
active_artifacts:
  programs:
    - name: CBACT01C
      frequency: high    # daily, ~365 times/year
    - name: CBACT02C
      frequency: medium  # weekly, ~52 times/year
    - name: CBACT03C
      frequency: low     # monthly, ~12 times/year
  
  jcl:
    - name: DALYREJS
      frequency: high
  
  cics_transactions:
    - name: CAUP
      frequency: high
  
  datasets:
    - name: AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS
      frequency: high
```

**Frequency levels:**

| Frequency | Execution Pattern | Times per Year | Use Case |
|-----------|------------------|----------------|----------|
| `high` | Daily | ~365 | Critical daily jobs, frequently used transactions |
| `medium` | Weekly | ~52 | Weekly reports, periodic maintenance |
| `low` | Monthly | ~12 | Monthly reports, infrequent operations |

**Artifact types:**
- **programs**: COBOL, PL/I, or other programs
- **jcl**: JCL job names
- **cics_transactions**: CICS transaction IDs
- **datasets**: Dataset names (VSAM, sequential, etc.)

**Distribution patterns:**
- High frequency: Distributed daily across time range
- Medium frequency: Distributed weekly (typically same day of week)
- Low frequency: Distributed monthly (typically same day of month)

### 8. Unreferenced Artifacts

```yaml
unreferenced_artifacts:
  programs:
    - COBDATFT      # Old utility (unused)
    - CSUTLDTC      # Legacy code (replaced)
  jcl:
    - FTPJCL        # Old job (no longer used)
  datasets:
    - AWS.M2.CARDDEMO.USRSEC.VSAM.KSDS
```

**Purpose:** Demonstrate "dead code" detection

**Behavior:**
- These artifacts exist in the inventory/analysis database
- They will **NEVER** appear in generated SMF records
- Dashboard can identify them as unreferenced

**Use cases:**
- Testing unreferenced artifact detection
- Demonstrating cleanup opportunities
- Validating artifact lifecycle analysis

### 9. Missing Artifacts

```yaml
missing_artifacts:
  programs:
    - MISSING01     # Not in inventory
    - EXTPROG1      # External program
  datasets:
    - AWS.M2.MISSING.DATA.KSDS
```

**Purpose:** Demonstrate "missing artifact" detection

**Behavior:**
- These artifacts do **NOT** exist in the inventory/analysis database
- They **WILL** appear in generated SMF records
- Dashboard can identify them as missing from inventory

**Use cases:**
- Testing missing artifact detection
- Demonstrating inventory gaps
- Validating cross-reference analysis

## Usage Examples

### Generate with Inventory Mode

```bash
python -m tools.smf_test_data_generator \
    --config examples/config/carddemo_smf_generation_inventory.yaml
```

### Generate with Source Code Mode

```bash
python -m tools.smf_test_data_generator \
    --config examples/config/carddemo_smf_generation_sourcecode.yaml
```

### Validate Configuration Only

```bash
python -m tools.smf_test_data_generator \
    --config examples/config/carddemo_smf_generation_inventory.yaml \
    --validate-only
```

### Generate with Verbose Output

```bash
python -m tools.smf_test_data_generator \
    --config examples/config/carddemo_smf_generation_inventory.yaml \
    --verbose
```

## Expected File Paths

### Inventory Mode Database
```
./databases/carddemo_inventory.db
```

**Required tables:**
- `inventory_programs` (name, language, lines_of_code, etc.)
- `inventory_jcl` (name, job_type, steps, etc.)
- `inventory_datasets` (name, dataset_type, record_format, etc.)
- `inventory_cics` (transaction_id, program_name, etc.)

### Source Code Mode Database
```
./results/carddemo_analysis/carddemo.db
```

**Required tables:** All inventory tables plus:
- `artifact_dependencies` (source_artifact, target_artifact, dependency_type, etc.)

### Output Directory
```
./examples/data/carddemo_smf_inventory/
./examples/data/carddemo_smf_sourcecode/
```

**Generated files:**
- `smf30_carddemo.json`
- `smf110_carddemo.json`
- `smf14_carddemo.json`
- `smf15_carddemo.json`
- `smf17_carddemo.json`
- `smf62_carddemo.json`
- `smf64_carddemo.json`
- `smf100_carddemo.json`
- `smf101_carddemo.json`
- `smf102_carddemo.json`

## Infrastructure Parameter Effects

### Comparing Different Configurations

**High-Performance System:**
```yaml
infrastructure:
  mips: 2000
  storage_gb: 1000
  iops: 100000
  network_mbps: 20000
```
- Lower CPU times (faster processing)
- Higher I/O counts (more throughput)
- Larger memory allocations
- Faster network transfers

**Standard System:**
```yaml
infrastructure:
  mips: 1000
  storage_gb: 500
  iops: 50000
  network_mbps: 10000
```
- Baseline CPU times
- Standard I/O counts
- Standard memory allocations
- Standard network performance

**Lower-Performance System:**
```yaml
infrastructure:
  mips: 500
  storage_gb: 250
  iops: 25000
  network_mbps: 5000
```
- Higher CPU times (slower processing)
- Lower I/O counts (less throughput)
- Smaller memory allocations
- Slower network transfers

### Metric Scaling Examples

**Type 30 CPU Time (for same workload):**
- 2000 MIPS: 100 centiseconds (1 second)
- 1000 MIPS: 200 centiseconds (2 seconds)
- 500 MIPS: 400 centiseconds (4 seconds)

**Type 30 EXCP Count (for same dataset):**
- 100000 IOPS: 10000 EXCPs
- 50000 IOPS: 5000 EXCPs
- 25000 IOPS: 2500 EXCPs

**Type 110 Response Time (for same transaction):**
- 2000 MIPS: 150ms
- 1000 MIPS: 300ms
- 500 MIPS: 600ms

### DB2 Record Types

The generator supports three DB2 record types for database performance analysis:

**Type 100 - DB2 Statistics:**
- System-level DB2 performance metrics
- SQL operation counts (SELECT, INSERT, UPDATE, DELETE)
- Buffer pool statistics (getpage requests, I/O counts)
- Latch statistics (requests, suspensions)
- DDF (Distributed Data Facility) statistics
- Scales with infrastructure parameters (MIPS affects CPU metrics)

**Type 101 - DB2 Accounting:**
- Application-level DB2 resource consumption
- CPU times, elapsed times, wait times
- Correlation information (authorization_id, plan_name, connection_name)
- SQL statistics per application
- Buffer manager statistics
- Commit/abort counts
- Supports rollup flag for aggregated records
- Scales with infrastructure parameters (MIPS affects CPU, IOPS affects I/O)

**Type 102 - DB2 Performance:**
- Detailed DB2 performance monitoring
- Correlation header information
- Trace header for performance monitoring
- CPU header with detailed CPU usage
- Optional distributed header for distributed operations
- Optional data sharing header for data sharing environments
- Scales with infrastructure parameters

**DB2 Subsystem Configuration:**
All DB2 records reference a DB2 subsystem ID (default: "DB2P"). Records are coordinated with batch job execution to show realistic database access patterns during job processing.

## Troubleshooting

### Configuration Validation Errors

**Error: "Database not found"**
- Check that `database_path` points to an existing file
- Verify the path is relative to where you run the command

**Error: "Missing required tables"**
- Verify database has required tables for the mode
- Check table names match expected format (inventory_programs, etc.)

**Error: "Invalid date format"**
- Use YYYY-MM-DD format for dates
- Ensure end_date is after start_date

**Error: "Invalid frequency level"**
- Use only: high, medium, or low
- Check spelling and case (lowercase)

**Error: "Unreferenced artifact not in database"**
- Unreferenced artifacts must exist in the database
- Check artifact names match database exactly

**Error: "Missing artifact found in database"**
- Missing artifacts must NOT exist in the database
- These should be external references only

### Generation Issues

**No records generated:**
- Check that active_artifacts are defined
- Verify artifacts exist in database
- Check time range is valid

**Too few records:**
- Increase frequency levels (low → medium → high)
- Add more active artifacts
- Extend time range

**Too many records:**
- Decrease frequency levels (high → medium → low)
- Remove some active artifacts
- Shorten time range

## Best Practices

1. **Start with inventory mode** if you have an inventory database
2. **Use source-code mode** when you have dependency information
3. **Define realistic frequency levels** based on actual usage patterns
4. **Include unreferenced artifacts** to test detection capabilities
5. **Include missing artifacts** to test gap analysis
6. **Use 12-month time ranges** for comprehensive analysis
7. **Vary infrastructure parameters** to demonstrate different scenarios
8. **Generate all record types** for complete lifecycle analysis
9. **Validate configuration** before generating large datasets
10. **Use descriptive application names** for output file organization

## Next Steps

After generating SMF data:

1. **Load into database:**
   ```bash
   python -m tools.smf_analyzer.smf_loader load \
       --type 30 --db test.db --file smf30_carddemo.json --create-schema
   ```

2. **Run queries:**
   ```bash
   python -m tools.smf_analyzer.smf_queries run \
       --db test.db --query unreferenced_artifacts
   ```

3. **Launch dashboard:**
   ```bash
   smf-dashboard
   ```

4. **Analyze results:**
   - View unreferenced artifacts
   - Identify missing artifacts
   - Analyze usage patterns
   - Review infrastructure metrics
