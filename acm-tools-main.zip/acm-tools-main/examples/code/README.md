```markdown
# Legacy Source Code Directory Setup

This repository requires additional source code that is not included due to size constraints. Please follow the instructions below to set up the required directory structure and populate it with the necessary source code.

## Directory Structure

Create the following directory structure:
```
examples/
├── cobol/
│   └── carddemoV2/
├── pli/
│   └── carddemo/
├── rexx/
│   ├── cbtapes_file_647/
│   └── cbtapes_file_617/
└── rpg/
    └── cbt667/
```

## Setup Instructions

1. Create the directory structure shown above
2. Download and extract the source code for each component as detailed below

### COBOL Source
#### carddemoV2
- Download from: https://github.com/aws-samples/aws-mainframe-modernization-carddemo
- Clone or download the repository
- Extract contents into `cobol/carddemoV2/`

### PLI Source
#### carddemo
- *Download link to be provided*
- Extract contents into `pli/carddemo/`

### REXX Source
#### cbtapes_file_647
- Download from: https://www.cbttape.org/ftp/cbt/CBT647.zip
- Extract contents into `rexx/cbtapes_file_647/`

#### cbtapes_file_617
- Download from: https://www.cbttape.org/ftp/cbt/CBT617.zip
- Extract contents into `rexx/cbtapes_file_617/`

### RPG Source
#### cbt667
- Download from: https://www.cbttape.org/ftp/cbt/CBT667.zip
- Extract contents into `rpg/cbt667/`

## Verification

To verify your setup:
1. Ensure all directories are created with the correct structure
2. Verify that each directory contains the extracted source code
3. Check that no files are missing or corrupted

## Note

These directories are included in `.gitignore` to keep the repository size manageable. Do not commit these directories to the repository.

If you encounter any issues with the CBT tape files, you can also access them through the main CBT tape website: [www.cbttape.org](http://www.cbttape.org)
```