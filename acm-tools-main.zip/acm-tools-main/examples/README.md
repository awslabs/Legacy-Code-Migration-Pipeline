# SMF Toolkit Examples

This directory contains example scripts and data files demonstrating the SMF Toolkit capabilities.

## Quick Start: Complete SMF Analysis Pipeline

The **recommended starting point** is the complete analysis pipeline:

```bash
# Run from project root directory
python examples/smf_analysis_pipeline.py
```

### What It Does

1. **Parses SMF Files**: Automatically detects file format and extracts all record types
2. **Creates Database**: Loads data into unified SQLite database for cross-analysis
3. **Runs Queries**: Executes 36+ pre-built analysis queries
4. **Generates Reports**: Creates comprehensive summary with multiple output formats

### Example Results

Using the included `SMF.APR4.TRS.DECOMPRESS` file (391MB):

- **85,961 total records** processed across 6 SMF types
- **Type 30**: 20,180 job/step accounting records  
- **Type 110**: 11,015 CICS performance records
- **Type 14/15**: 54,764 dataset activity records
- **36 successful queries** with results in JSON, CSV, and Markdown
- **Complete analysis** in under 2 minutes

### Generated Output

```
results/
├── SMF.APR4.TRS_ALL.json          # All records combined (374MB)
├── SMF.APR4.TRS_030.json          # Type 30 records only (214MB)
├── SMF.APR4.TRS_110.json          # Type 110 records only (20MB)
├── SMF.APR4.TRS_014.json          # Type 14 records only (107MB)
├── SMF.APR4.TRS_015.json          # Type 15 records only (31MB)
├── SMF.APR4.TRS_002.json          # Type 2 records (dump header)
├── SMF.APR4.TRS_003.json          # Type 3 records (dump trailer)
├── SMF.APR4.TRS_REPORT.md         # Parsing report with statistics
├── smf_analysis.db                # SQLite database (61MB)
├── SMF_ANALYSIS_SUMMARY.md        # Complete analysis summary
├── QUERY_EXECUTION_REPORT.md      # Query performance metrics
└── queries/                       # Individual query results
    ├── smf_type_30_job_step_accounting/
    │   ├── top_cpu_consumers.json
    │   ├── top_cpu_consumers.csv
    │   ├── top_cpu_consumers.md
    │   ├── cpu_statistics.json
    │   └── ... (9 total queries)
    ├── smf_type_110_cics_performance/
    │   └── ... (10 total queries)
    ├── cross-type_analysis/
    │   └── ... (7 total queries)
    └── artifact_lifecycle_analysis/
        └── ... (10 total queries)
```

## Usage Options

### Default (Recommended)
```bash
python examples/smf_analysis_pipeline.py
```
- Auto-selects largest SMF file from `examples/data/jse/`
- Outputs to `./results/`

### Custom Input File
```bash
python examples/smf_analysis_pipeline.py --input examples/data/jse/SMF.JUL18.rdw
```

### Custom Output Directory
```bash
python examples/smf_analysis_pipeline.py --output ./my_analysis
```

### Help
```bash
python examples/smf_analysis_pipeline.py --help
```

## Available SMF Files

The `examples/data/jse/` directory contains sample SMF files:

- **SMF.JUL18.rdw** (0.69MB): 339 Type 30 records - Simple format
- **SMF.APR4.TRS.DECOMPRESS** (391MB): 85,961 records across 6 types - Multi-type format

## Pipeline Performance

Real performance metrics from the working pipeline:

### SMF.APR4.TRS.DECOMPRESS (391MB input file)
- **Parsing**: ~30 seconds (auto-detected simple format)
- **Database Loading**: ~45 seconds (85,961 records)
- **Query Execution**: ~22 seconds (36 queries)
- **Total Time**: ~2 minutes
- **Output Size**: 
  - JSON files: 574MB total
  - SQLite database: 61MB
  - Query results: ~5MB

### Query Performance Highlights
- **Fast queries** (< 0.01s): CPU statistics, record counts
- **Medium queries** (0.1-0.3s): Dataset activity, I/O analysis
- **Complex queries** (20+ seconds): Batch-CICS correlation (18,182 results)

## Next Steps

After running the pipeline:

1. **Review Results**: Check `SMF_ANALYSIS_SUMMARY.md` for overview
2. **Explore Database**: Use SQLite browser or queries to explore data
3. **Custom Analysis**: Run additional queries or create custom ones
4. **Integration**: Use the Python API to integrate with your applications

## Individual Component Examples

For learning individual components, see:

- **Parser**: `python -m smf_record_parser parse --help`
- **Loader**: `python -m smf_loader load --help`  
- **Queries**: `python -m smf_queries run --help`

## Data Files

### SMF Test Data

Located in `examples/data/jse/`:
- Real SMF records from z/OS systems
- Multiple record types (2, 3, 14, 15, 30, 110)
- Different file formats for testing format detection

### Inventory Data

Located in `examples/data/inventory/`:
- Sample JCL, program, and dataset inventories
- Used for artifact lifecycle analysis
- CSV format for easy import

## Troubleshooting

### Common Issues

1. **"No records found"**: Check file format detection in parsing report
2. **"Database locked"**: Close any SQLite browser connections
3. **"Permission denied"**: Run from project root directory
4. **"Type 0 records detected"**: File format detection issue - check parsing report

### Format Detection Issues

The pipeline includes robust format detection that handles:
- **Simple format** (2-byte RDW): Most common
- **VB format** (4-byte BDW + RDW): Variable blocked
- **RDW4 format** (4-byte RDW): Alternative format
- **Segment prefix**: Vendor-specific formats

If format detection fails, check the parsing report for diagnostic information.

### Getting Help

1. Check the main [README.md](../README.md) for detailed documentation
2. Review component-specific README files
3. Examine the generated reports for diagnostic information
4. Use `--help` flag with any command for usage information

## Performance Notes

- **Small files** (< 1MB): Complete analysis in seconds
- **Medium files** (1-50MB): Complete analysis in 1-2 minutes  
- **Large files** (50MB+): May take several minutes depending on record count
- **Database size**: Typically 15-20% of input JSON size due to normalization
- **Memory usage**: Processes files in batches to handle large datasets

The pipeline is optimized for typical SMF file sizes and provides progress indicators for long-running operations.

## Sample Query Results

Here are examples of the insights you can get from the analysis:

### Top CPU Consumers
```
| job_name | program_name | total_cpu_seconds | executions |
|----------|--------------|-------------------|------------|
| BBPDLY29 |              | 14.5              | 1          |
| DEV87DNB |              | 12.52             | 8          |
| DEV87DNB | DBUTLTY      | 10.02             | 12         |
```

### CICS System Summary
```
| applid   | product_name | total_transactions | avg_response_time |
|----------|--------------|-------------------|-------------------|
| CICS1    | DFHSIP       | 5,234             | 0.045             |
| CICS2    | DFHSIP       | 3,891             | 0.052             |
```

### Cross-Type Analysis
- **Batch-CICS Correlation**: 18,182 correlated events
- **System CPU Utilization**: 20 time periods analyzed
- **Resource Contention**: Peak usage periods identified

The pipeline provides actionable insights for mainframe modernization and performance optimization projects.