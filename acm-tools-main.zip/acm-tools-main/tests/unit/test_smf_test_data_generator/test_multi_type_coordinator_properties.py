"""
Property-based tests for multi-type record coordinator.

Tests correctness properties for coordinating multiple SMF record types
including cross-type artifact consistency and timestamp ordering.
"""

import pytest
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, assume, settings

from tools.smf_test_data_generator.multi_type_coordinator import MultiTypeRecordCoordinator
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters
from tools.smf_test_data_generator.config_loader import GeneratorConfig


# Helper function to create a test catalog
def create_test_catalog(
    programs=None,
    jcl_jobs=None,
    datasets=None,
    vsam_datasets=None,
    cics_transactions=None,
    missing_programs=None,
    missing_datasets=None
):
    """Create a test artifact catalog with specified artifacts."""
    if programs is None:
        programs = ['PROG01', 'PROG02', 'PROG03']
    if jcl_jobs is None:
        jcl_jobs = ['JOB01', 'JOB02']
    if datasets is None:
        datasets = ['DATA.SET.ONE', 'DATA.SET.TWO', 'DATA.SET.THREE']
    if vsam_datasets is None:
        vsam_datasets = ['VSAM.DATA.ONE', 'VSAM.DATA.TWO']
    if cics_transactions is None:
        cics_transactions = [
            {'transaction_id': 'TXN1', 'program_name': 'PROG01'},
            {'transaction_id': 'TXN2', 'program_name': 'PROG02'}
        ]
    if missing_programs is None:
        missing_programs = []
    if missing_datasets is None:
        missing_datasets = []
    
    # Create catalog directly with mock data
    catalog = ArtifactCatalog.__new__(ArtifactCatalog)
    
    # Initialize storage structures
    catalog._active_programs = {'high': [], 'medium': [], 'low': []}
    catalog._active_jcl = {'high': [], 'medium': [], 'low': []}
    catalog._active_cics_transactions = {'high': [], 'medium': [], 'low': []}
    catalog._active_datasets = {'high': [], 'medium': [], 'low': []}
    
    catalog._unreferenced_programs = set()
    catalog._unreferenced_jcl = set()
    catalog._unreferenced_datasets = set()
    catalog._unreferenced_cics_transactions = set()
    
    catalog._missing_programs = set(missing_programs)
    catalog._missing_datasets = set(missing_datasets)
    catalog._missing_cics_transactions = set()
    
    catalog._cics_program_mapping = {}
    catalog._program_datasets = {}
    
    # Add programs to high frequency
    catalog._active_programs['high'] = list(programs)
    
    # Add JCL jobs to high frequency
    catalog._active_jcl['high'] = list(jcl_jobs)
    
    # Add CICS transactions to high frequency
    catalog._active_cics_transactions['high'] = list(cics_transactions)
    
    # Build CICS program mapping
    for txn in cics_transactions:
        catalog._cics_program_mapping[txn['transaction_id']] = txn['program_name']
    
    # Add datasets to high frequency (including VSAM)
    all_datasets = list(datasets) + list(vsam_datasets)
    catalog._active_datasets['high'] = all_datasets
    
    # Add missing programs to high frequency
    catalog._active_programs['high'].extend(missing_programs)
    
    # Add missing datasets to high frequency
    catalog._active_datasets['high'].extend(missing_datasets)
    
    return catalog


# Helper function to create a test config
def create_test_config(record_types=None):
    """Create a test generator configuration."""
    if record_types is None:
        record_types = [30, 110, 14, 15, 17, 62, 64]
    
    # Create config directly with mock data
    config = GeneratorConfig.__new__(GeneratorConfig)
    
    # Initialize the internal _config dictionary that the properties access
    config._config = {
        'record_types': record_types,
        'active_artifacts': {
            'programs': [],
            'jcl': [],
            'cics_transactions': [],
            'datasets': []
        },
        'unreferenced_artifacts': {
            'programs': [],
            'jcl': [],
            'cics_transactions': [],
            'datasets': []
        },
        'missing_artifacts': {
            'programs': [],
            'cics_transactions': [],
            'datasets': []
        }
    }
    
    return config


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=90),
    record_types=st.lists(
        st.sampled_from([14, 30, 15, 62, 64]),
        min_size=2,
        max_size=5,
        unique=True
    )
)
def test_property_45_cross_type_artifact_consistency(
    start_year,
    duration_days,
    record_types
):
    """
    Feature: smf-test-data-generator, Property 45: Cross-Type Artifact Consistency
    
    For any set of generated records across multiple types for the same job
    execution, all records should reference the same program name and job name.
    
    Validates: Requirements 20.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    config = create_test_config(record_types=record_types)
    
    # Create coordinator
    coordinator = MultiTypeRecordCoordinator(
        config, catalog, distribution, infrastructure
    )
    
    # Generate coordinated records for a single job execution
    job_name = "TESTJOB"
    program_name = "TESTPROG"
    timestamp = start_date + timedelta(days=duration_days // 2)
    
    job_records = coordinator.coordinate_job_execution(
        job_name=job_name,
        program_name=program_name,
        timestamp=timestamp
    )
    
    # Verify artifact consistency across all record types
    for record_type, records in job_records.items():
        if record_type not in record_types:
            continue
        
        for record in records:
            # All records should reference the same job name
            if record_type == 30:
                assert record['identification']['job_name'] == job_name
                assert record['identification']['program_name'] == program_name
            elif record_type in [14, 15]:
                assert record['identification']['job_name'] == job_name
                assert record['identification']['program_name'] == program_name
            elif record_type in [62, 64]:
                assert record['identification']['job_name'] == job_name


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=90)
)
def test_property_46_cross_type_timestamp_ordering(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 46: Cross-Type Timestamp Ordering
    
    For any set of related records (e.g., Type 14 input, Type 30 execution,
    Type 15 output), the timestamps should be in logical order
    (Type 14 open_time ≤ Type 30 timestamp ≤ Type 15 close_time).
    
    Validates: Requirements 20.5
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    config = create_test_config(record_types=[14, 30, 15, 62, 64])
    
    # Create coordinator
    coordinator = MultiTypeRecordCoordinator(
        config, catalog, distribution, infrastructure
    )
    
    # Generate coordinated records for a single job execution
    job_name = "TESTJOB"
    program_name = "TESTPROG"
    timestamp = start_date + timedelta(days=duration_days // 2)
    
    job_records = coordinator.coordinate_job_execution(
        job_name=job_name,
        program_name=program_name,
        timestamp=timestamp
    )
    
    # Extract timestamps from each record type
    type14_times = []
    type30_times = []
    type15_times = []
    type62_times = []
    type64_times = []
    
    # Type 14 records (input datasets)
    for record in job_records.get(14, []):
        open_time_str = record['identification']['open_time']
        close_time_str = record['identification']['close_time']
        open_time = datetime.strptime(open_time_str, '%Y-%m-%d %H:%M:%S')
        close_time = datetime.strptime(close_time_str, '%Y-%m-%d %H:%M:%S')
        type14_times.append((open_time, close_time))
    
    # Type 30 records (job execution)
    for record in job_records.get(30, []):
        timestamp_str = f"{record['date']} {record['timestamp']}"
        exec_time = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        type30_times.append(exec_time)
    
    # Type 15 records (output datasets)
    for record in job_records.get(15, []):
        open_time_str = record['identification']['open_time']
        close_time_str = record['identification']['close_time']
        open_time = datetime.strptime(open_time_str, '%Y-%m-%d %H:%M:%S')
        close_time = datetime.strptime(close_time_str, '%Y-%m-%d %H:%M:%S')
        type15_times.append((open_time, close_time))
    
    # Type 62 records (VSAM open)
    for record in job_records.get(62, []):
        open_time_str = record['identification']['open_time']
        open_time = datetime.strptime(open_time_str, '%Y-%m-%d %H:%M:%S')
        type62_times.append(open_time)
    
    # Type 64 records (VSAM close)
    for record in job_records.get(64, []):
        open_time_str = record['identification']['open_time']
        close_time_str = record['identification']['close_time']
        open_time = datetime.strptime(open_time_str, '%Y-%m-%d %H:%M:%S')
        close_time = datetime.strptime(close_time_str, '%Y-%m-%d %H:%M:%S')
        type64_times.append((open_time, close_time))
    
    # Verify timestamp ordering
    
    # Type 14 input datasets should open before Type 30 execution
    if type14_times and type30_times:
        for open_time, close_time in type14_times:
            for exec_time in type30_times:
                # Input should open before or at job execution time
                assert open_time <= exec_time, \
                    f"Type 14 open time {open_time} should be <= Type 30 time {exec_time}"
                # Input should close before or at job execution time
                assert close_time <= exec_time, \
                    f"Type 14 close time {close_time} should be <= Type 30 time {exec_time}"
    
    # Type 30 execution should be before Type 15 output close
    if type30_times and type15_times:
        for exec_time in type30_times:
            for open_time, close_time in type15_times:
                # Job execution should be before or at output close time
                assert exec_time <= close_time, \
                    f"Type 30 time {exec_time} should be <= Type 15 close time {close_time}"
    
    # Type 62 VSAM open should be before Type 64 VSAM close
    if type62_times and type64_times:
        # Match up open/close pairs (same number of Type 62 and Type 64 records)
        assert len(type62_times) == len(type64_times), \
            "Should have same number of Type 62 and Type 64 records"
        
        for i in range(len(type62_times)):
            open_time = type62_times[i]
            vsam_open_time, vsam_close_time = type64_times[i]
            
            # Type 62 open time should match Type 64 open time
            assert open_time == vsam_open_time, \
                f"Type 62 open time {open_time} should match Type 64 open time {vsam_open_time}"
            
            # VSAM open should be before VSAM close
            assert vsam_open_time < vsam_close_time, \
                f"VSAM open time {vsam_open_time} should be < close time {vsam_close_time}"
    
    # Type 14 open/close should be properly ordered
    for open_time, close_time in type14_times:
        assert open_time <= close_time, \
            f"Type 14 open time {open_time} should be <= close time {close_time}"
    
    # Type 15 open/close should be properly ordered
    for open_time, close_time in type15_times:
        assert open_time <= close_time, \
            f"Type 15 open time {open_time} should be <= close time {close_time}"


@pytest.mark.property
@settings(max_examples=30, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=30, max_value=180)
)
def test_multi_type_generation_completeness(start_year, duration_days):
    """
    Test that generate_all_records produces records for all configured types.
    
    This is a supplementary test to ensure the coordinator generates records
    for all configured types, not just coordinated batch types.
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    
    # Test with all record types
    config = create_test_config(record_types=[30, 110, 14, 15, 17, 62, 64])
    
    # Create coordinator
    coordinator = MultiTypeRecordCoordinator(
        config, catalog, distribution, infrastructure
    )
    
    # Generate all records
    records_by_type = coordinator.generate_all_records()
    
    # Verify all configured types have records
    for record_type in config.record_types:
        assert record_type in records_by_type, \
            f"Record type {record_type} should be in results"
        
        # Most types should have at least some records
        # (Type 17 might be empty if no deletions are generated)
        if record_type != 17:
            assert len(records_by_type[record_type]) > 0, \
                f"Record type {record_type} should have at least one record"


@pytest.mark.property
@settings(max_examples=30, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=30, max_value=180),
    subset_size=st.integers(min_value=1, max_value=3)
)
def test_partial_record_type_generation(start_year, duration_days, subset_size):
    """
    Test that coordinator works correctly with partial record type configurations.
    
    Verifies that the coordinator can generate records when only a subset of
    record types is configured.
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    
    # Select a random subset of record types
    all_types = [30, 110, 14, 15, 17, 62, 64]
    import random
    random.seed(start_year + duration_days)  # Deterministic for testing
    selected_types = random.sample(all_types, min(subset_size, len(all_types)))
    
    config = create_test_config(record_types=selected_types)
    
    # Create coordinator
    coordinator = MultiTypeRecordCoordinator(
        config, catalog, distribution, infrastructure
    )
    
    # Generate all records
    records_by_type = coordinator.generate_all_records()
    
    # Verify only configured types have records
    for record_type in selected_types:
        assert record_type in records_by_type, \
            f"Configured record type {record_type} should be in results"
    
    # Verify no unconfigured types have records
    for record_type in all_types:
        if record_type not in selected_types:
            # Unconfigured types should either not be in results or have empty lists
            if record_type in records_by_type:
                assert len(records_by_type[record_type]) == 0, \
                    f"Unconfigured record type {record_type} should have no records"
