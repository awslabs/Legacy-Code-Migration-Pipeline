"""
Unit tests for SMF Test Data Generator.
"""
