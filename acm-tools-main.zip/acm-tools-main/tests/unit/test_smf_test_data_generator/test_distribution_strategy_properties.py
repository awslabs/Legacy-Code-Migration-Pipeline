"""
Property-based tests for distribution strategy.

Tests correctness properties for timestamp distribution and frequency calculations.
"""

import pytest
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, assume, settings
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730),  # Up to 2 years
    frequency=st.sampled_from(['high', 'medium', 'low'])
)
def test_property_5_timestamp_range_compliance(
    start_year, start_month, start_day, duration_days, frequency
):
    """
    Feature: smf-test-data-generator, Property 5: Timestamp Range Compliance
    
    For any set of generated SMF records (Type 30 or Type 110) with a specified
    time range, all record timestamps should fall within the start date and end
    date boundaries (inclusive).
    
    Validates: Requirements 2.6, 3.6, 7.2
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate timestamps
    timestamps = strategy.generate_timestamps(frequency)
    
    # All timestamps should be within range (inclusive)
    for timestamp in timestamps:
        assert start_date <= timestamp <= end_date, (
            f"Timestamp {timestamp} is outside range [{start_date}, {end_date}]"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=7, max_value=730)  # At least a week
)
def test_property_15_batch_timestamp_realism(start_year, start_month, start_day, duration_days):
    """
    Feature: smf-test-data-generator, Property 15: Batch Timestamp Realism
    
    For any Type 30 record timestamp, the time component should fall within
    business hours (08:00:00 to 18:00:00) on weekdays.
    
    Validates: Requirements 7.3
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate base timestamps
    base_timestamps = strategy.generate_timestamps('high')
    
    # Generate batch timestamps from base timestamps
    batch_timestamps = [
        strategy.generate_batch_timestamp(base_ts)
        for base_ts in base_timestamps[:min(50, len(base_timestamps))]  # Test up to 50
    ]
    
    # All batch timestamps should be on weekdays
    for timestamp in batch_timestamps:
        weekday = timestamp.weekday()
        assert weekday < 5, (
            f"Batch timestamp {timestamp} is on weekend (weekday={weekday})"
        )
    
    # All batch timestamps should be in business hours (8am-6pm)
    for timestamp in batch_timestamps:
        hour = timestamp.hour
        assert 8 <= hour <= 17, (
            f"Batch timestamp {timestamp} is outside business hours (hour={hour})"
        )
        
        # If hour is 18, minutes and seconds should be 0 (exactly 6pm)
        if hour == 18:
            assert timestamp.minute == 0 and timestamp.second == 0, (
                f"Batch timestamp {timestamp} is after 6pm"
            )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730),
    frequency=st.sampled_from(['high', 'medium', 'low'])
)
def test_property_16_date_and_time_format_compliance(
    start_year, start_month, start_day, duration_days, frequency
):
    """
    Feature: smf-test-data-generator, Property 16: Date and Time Format Compliance
    
    For any generated SMF record, the date field should match the format YYYY-MM-DD
    and the time field should match the format HH:MM:SS.
    
    Validates: Requirements 7.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate timestamps
    timestamps = strategy.generate_timestamps(frequency)
    
    # Test both batch and CICS timestamps
    for base_ts in timestamps[:min(20, len(timestamps))]:  # Test up to 20
        # Test batch timestamp
        batch_ts = strategy.generate_batch_timestamp(base_ts)
        
        # Format date and time
        date_str = batch_ts.strftime('%Y-%m-%d')
        time_str = batch_ts.strftime('%H:%M:%S')
        
        # Verify date format (YYYY-MM-DD)
        assert len(date_str) == 10, f"Date string '{date_str}' has wrong length"
        assert date_str[4] == '-' and date_str[7] == '-', (
            f"Date string '{date_str}' has wrong format"
        )
        
        # Parse back to verify format is correct
        parsed_date = datetime.strptime(date_str, '%Y-%m-%d')
        assert parsed_date.year == batch_ts.year
        assert parsed_date.month == batch_ts.month
        assert parsed_date.day == batch_ts.day
        
        # Verify time format (HH:MM:SS)
        assert len(time_str) == 8, f"Time string '{time_str}' has wrong length"
        assert time_str[2] == ':' and time_str[5] == ':', (
            f"Time string '{time_str}' has wrong format"
        )
        
        # Parse back to verify format is correct
        parsed_time = datetime.strptime(time_str, '%H:%M:%S')
        assert parsed_time.hour == batch_ts.hour
        assert parsed_time.minute == batch_ts.minute
        assert parsed_time.second == batch_ts.second
        
        # Test CICS timestamp
        cics_ts = strategy.generate_cics_timestamp(base_ts)
        
        # Format date and time
        date_str = cics_ts.strftime('%Y-%m-%d')
        time_str = cics_ts.strftime('%H:%M:%S')
        
        # Verify formats
        assert len(date_str) == 10
        assert date_str[4] == '-' and date_str[7] == '-'
        assert len(time_str) == 8
        assert time_str[2] == ':' and time_str[5] == ':'


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=7, max_value=730)  # At least 7 days to avoid weekend edge cases
)
def test_property_5_batch_timestamps_in_range(start_year, start_month, start_day, duration_days):
    """
    Feature: smf-test-data-generator, Property 5: Timestamp Range Compliance
    
    Verify that batch timestamps (after adjustment) still fall within the time range.
    
    Validates: Requirements 2.6, 7.2
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate base timestamps
    base_timestamps = strategy.generate_timestamps('high')
    
    # Generate batch timestamps
    for base_ts in base_timestamps[:min(50, len(base_timestamps))]:
        batch_ts = strategy.generate_batch_timestamp(base_ts)
        
        # Batch timestamp should still be within overall range
        # (may be adjusted forward to next weekday, so allow some tolerance)
        assert batch_ts >= start_date, (
            f"Batch timestamp {batch_ts} is before start date {start_date}"
        )
        # Allow up to 3 days past end date for weekend adjustment
        # (worst case: Friday end date adjusted to Monday)
        assert batch_ts <= end_date + timedelta(days=3), (
            f"Batch timestamp {batch_ts} is too far past end date {end_date}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730)
)
def test_property_5_cics_timestamps_in_range(start_year, start_month, start_day, duration_days):
    """
    Feature: smf-test-data-generator, Property 5: Timestamp Range Compliance
    
    Verify that CICS timestamps fall within the time range.
    
    Validates: Requirements 3.6, 7.2
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate base timestamps
    base_timestamps = strategy.generate_timestamps('medium')
    
    # Generate CICS timestamps
    for base_ts in base_timestamps[:min(50, len(base_timestamps))]:
        cics_ts = strategy.generate_cics_timestamp(base_ts)
        
        # CICS timestamp should be within range (same day as base)
        assert cics_ts.date() == base_ts.date(), (
            f"CICS timestamp {cics_ts} is on different day than base {base_ts}"
        )
        
        # Should be within overall range
        assert start_date <= cics_ts <= end_date, (
            f"CICS timestamp {cics_ts} is outside range [{start_date}, {end_date}]"
        )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730)
)
def test_property_15_batch_timestamps_sorted(start_year, start_month, start_day, duration_days):
    """
    Feature: smf-test-data-generator, Property 15: Batch Timestamp Realism
    
    Verify that generated timestamps are in chronological order.
    
    Validates: Requirements 7.3
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate timestamps
    timestamps = strategy.generate_timestamps('high')
    
    # Timestamps should be sorted
    for i in range(len(timestamps) - 1):
        assert timestamps[i] <= timestamps[i + 1], (
            f"Timestamps not sorted: {timestamps[i]} > {timestamps[i + 1]}"
        )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=30, max_value=730)  # At least 30 days for meaningful hour variety
)
def test_property_16_cics_timestamp_24_7_distribution(
    start_year, start_month, start_day, duration_days
):
    """
    Feature: smf-test-data-generator, Property 16: Date and Time Format Compliance
    
    Verify that CICS timestamps can occur at any hour (24/7 distribution).
    
    Validates: Requirements 7.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate many CICS timestamps to test distribution
    base_timestamps = strategy.generate_timestamps('high')
    cics_timestamps = [
        strategy.generate_cics_timestamp(base_ts)
        for base_ts in base_timestamps[:min(100, len(base_timestamps))]
    ]
    
    # CICS timestamps should be able to occur at any hour (0-23)
    # With 100 samples, we should see some variety
    hours = set(ts.hour for ts in cics_timestamps)
    
    # We should see at least a few different hours
    # (not testing for all 24 hours as that would require many more samples)
    # With 30+ days and 100 samples, we should see at least 5 different hours
    assert len(hours) >= 5, (
        f"CICS timestamps only used {len(hours)} different hours, expected more variety"
    )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730)
)
def test_property_15_batch_timestamp_weekday_only(
    start_year, start_month, start_day, duration_days
):
    """
    Feature: smf-test-data-generator, Property 15: Batch Timestamp Realism
    
    Verify that batch timestamps never fall on weekends.
    
    Validates: Requirements 7.3
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate many batch timestamps
    base_timestamps = strategy.generate_timestamps('high')
    batch_timestamps = [
        strategy.generate_batch_timestamp(base_ts)
        for base_ts in base_timestamps[:min(100, len(base_timestamps))]
    ]
    
    # None should be on weekends
    weekend_count = sum(1 for ts in batch_timestamps if ts.weekday() >= 5)
    assert weekend_count == 0, (
        f"Found {weekend_count} batch timestamps on weekends"
    )



@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=30, max_value=730),  # At least 30 days for meaningful frequency
    frequency=st.sampled_from(['high', 'medium', 'low'])
)
def test_property_10_frequency_distribution_correctness(
    start_year, start_month, start_day, duration_days, frequency
):
    """
    Feature: smf-test-data-generator, Property 10: Frequency Distribution Correctness
    
    For any active artifact with a specified frequency level over a time range,
    the number of generated records containing that artifact should be approximately:
    - high frequency = days in range
    - medium frequency = weeks in range
    - low frequency = months in range
    (±10% tolerance)
    
    Validates: Requirements 4.4, 4.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Calculate expected count based on frequency
    total_days = duration_days + 1  # Inclusive
    
    if frequency == 'high':
        # Daily execution - one per day
        expected_count = total_days
    elif frequency == 'medium':
        # Weekly execution - approximately once per week
        expected_count = max(1, int(total_days / 7))
    elif frequency == 'low':
        # Monthly execution - approximately once per month
        expected_count = max(1, int(total_days / 30))
    
    # Generate timestamps
    timestamps = strategy.generate_timestamps(frequency)
    actual_count = len(timestamps)
    
    # Calculate tolerance (±10%)
    tolerance = max(1, int(expected_count * 0.1))
    lower_bound = expected_count - tolerance
    upper_bound = expected_count + tolerance
    
    # Verify count is within tolerance
    assert lower_bound <= actual_count <= upper_bound, (
        f"Frequency '{frequency}' over {total_days} days: "
        f"expected {expected_count} (±{tolerance}), got {actual_count}"
    )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=365, max_value=730)  # At least 1 year
)
def test_property_10_high_frequency_daily_execution(
    start_year, start_month, start_day, duration_days
):
    """
    Feature: smf-test-data-generator, Property 10: Frequency Distribution Correctness
    
    Verify that high-frequency artifacts appear approximately daily.
    
    Validates: Requirements 4.4, 4.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate high-frequency timestamps
    timestamps = strategy.generate_timestamps('high')
    
    # Should have approximately one per day
    total_days = duration_days + 1
    expected_count = total_days
    actual_count = len(timestamps)
    
    # Allow ±10% tolerance
    tolerance = max(1, int(expected_count * 0.1))
    assert abs(actual_count - expected_count) <= tolerance, (
        f"High frequency over {total_days} days: "
        f"expected ~{expected_count}, got {actual_count}"
    )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=365, max_value=730)  # At least 1 year
)
def test_property_10_medium_frequency_weekly_execution(
    start_year, start_month, start_day, duration_days
):
    """
    Feature: smf-test-data-generator, Property 10: Frequency Distribution Correctness
    
    Verify that medium-frequency artifacts appear approximately weekly.
    
    Validates: Requirements 4.4, 4.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate medium-frequency timestamps
    timestamps = strategy.generate_timestamps('medium')
    
    # Should have approximately one per week
    total_days = duration_days + 1
    expected_count = max(1, int(total_days / 7))
    actual_count = len(timestamps)
    
    # Allow ±10% tolerance
    tolerance = max(1, int(expected_count * 0.1))
    assert abs(actual_count - expected_count) <= tolerance, (
        f"Medium frequency over {total_days} days ({total_days/7:.1f} weeks): "
        f"expected ~{expected_count}, got {actual_count}"
    )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=365, max_value=730)  # At least 1 year
)
def test_property_10_low_frequency_monthly_execution(
    start_year, start_month, start_day, duration_days
):
    """
    Feature: smf-test-data-generator, Property 10: Frequency Distribution Correctness
    
    Verify that low-frequency artifacts appear approximately monthly.
    
    Validates: Requirements 4.4, 4.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate low-frequency timestamps
    timestamps = strategy.generate_timestamps('low')
    
    # Should have approximately one per month
    total_days = duration_days + 1
    expected_count = max(1, int(total_days / 30))
    actual_count = len(timestamps)
    
    # Allow ±10% tolerance
    tolerance = max(1, int(expected_count * 0.1))
    assert abs(actual_count - expected_count) <= tolerance, (
        f"Low frequency over {total_days} days ({total_days/30:.1f} months): "
        f"expected ~{expected_count}, got {actual_count}"
    )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=30, max_value=730)
)
def test_property_10_calculate_execution_count(
    start_year, start_month, start_day, duration_days
):
    """
    Feature: smf-test-data-generator, Property 10: Frequency Distribution Correctness
    
    Verify that calculate_execution_count returns correct values for each frequency.
    
    Validates: Requirements 4.4, 4.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    total_days = duration_days + 1
    
    # Test high frequency
    high_count = strategy.calculate_execution_count('high')
    assert high_count == total_days, (
        f"High frequency should return {total_days} days, got {high_count}"
    )
    
    # Test medium frequency
    medium_count = strategy.calculate_execution_count('medium')
    expected_medium = max(1, int(total_days / 7))
    assert medium_count == expected_medium, (
        f"Medium frequency should return {expected_medium} weeks, got {medium_count}"
    )
    
    # Test low frequency
    low_count = strategy.calculate_execution_count('low')
    expected_low = max(1, int(total_days / 30))
    assert low_count == expected_low, (
        f"Low frequency should return {expected_low} months, got {low_count}"
    )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=30, max_value=730),
    frequency=st.sampled_from(['high', 'medium', 'low'])
)
def test_property_10_timestamps_match_calculated_count(
    start_year, start_month, start_day, duration_days, frequency
):
    """
    Feature: smf-test-data-generator, Property 10: Frequency Distribution Correctness
    
    Verify that generate_timestamps returns the same count as calculate_execution_count.
    
    Validates: Requirements 4.4, 4.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Calculate expected count
    expected_count = strategy.calculate_execution_count(frequency)
    
    # Generate timestamps
    timestamps = strategy.generate_timestamps(frequency)
    actual_count = len(timestamps)
    
    # Should match exactly (when count is not specified)
    assert actual_count == expected_count, (
        f"Frequency '{frequency}': calculate_execution_count returned {expected_count}, "
        f"but generate_timestamps returned {actual_count} timestamps"
    )



@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730),
    count=st.integers(min_value=0, max_value=10),
    window_minutes=st.integers(min_value=1, max_value=120)
)
def test_property_46_cross_type_timestamp_ordering(
    start_year, start_month, start_day, duration_days, count, window_minutes
):
    """
    Feature: smf-test-data-generator, Property 46: Cross-Type Timestamp Ordering
    
    For any set of related records (e.g., Type 14 input, Type 30 execution, Type 15 output),
    the timestamps should be in logical order and within a reasonable time window.
    
    Validates: Requirements 20.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day, 12, 0, 0)  # Noon to avoid edge cases
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate a base timestamp in the middle of the range
    mid_point = start_date + (end_date - start_date) / 2
    
    # Generate related timestamps
    related_timestamps = strategy.generate_related_timestamps(
        base_timestamp=mid_point,
        count=count,
        window_minutes=window_minutes
    )
    
    # Verify count
    assert len(related_timestamps) == count, (
        f"Expected {count} related timestamps, got {len(related_timestamps)}"
    )
    
    if count == 0:
        return
    
    # All timestamps should be sorted chronologically
    for i in range(len(related_timestamps) - 1):
        assert related_timestamps[i] <= related_timestamps[i + 1], (
            f"Related timestamps not sorted: {related_timestamps[i]} > {related_timestamps[i + 1]}"
        )
    
    # All timestamps should be within the window of the base timestamp
    for ts in related_timestamps:
        time_diff_minutes = abs((ts - mid_point).total_seconds() / 60)
        assert time_diff_minutes <= window_minutes, (
            f"Timestamp {ts} is {time_diff_minutes:.1f} minutes from base {mid_point}, "
            f"exceeds window of {window_minutes} minutes"
        )
    
    # All timestamps should be within overall time range
    for ts in related_timestamps:
        assert start_date <= ts <= end_date, (
            f"Related timestamp {ts} is outside range [{start_date}, {end_date}]"
        )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=7, max_value=730)
)
def test_property_46_dataset_access_timestamp_business_hours(
    start_year, start_month, start_day, duration_days
):
    """
    Feature: smf-test-data-generator, Property 46: Cross-Type Timestamp Ordering
    
    Verify that dataset access timestamps follow business hours pattern.
    
    Validates: Requirements 20.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate base timestamps
    base_timestamps = strategy.generate_timestamps('high')
    
    # Generate dataset access timestamps
    dataset_timestamps = [
        strategy.generate_dataset_access_timestamp(base_ts)
        for base_ts in base_timestamps[:min(50, len(base_timestamps))]
    ]
    
    # All dataset access timestamps should be on weekdays
    for timestamp in dataset_timestamps:
        weekday = timestamp.weekday()
        assert weekday < 5, (
            f"Dataset access timestamp {timestamp} is on weekend (weekday={weekday})"
        )
    
    # All dataset access timestamps should be in business hours (8am-6pm)
    for timestamp in dataset_timestamps:
        hour = timestamp.hour
        assert 8 <= hour <= 17, (
            f"Dataset access timestamp {timestamp} is outside business hours (hour={hour})"
        )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730),
    window_minutes=st.integers(min_value=5, max_value=60)
)
def test_property_46_related_timestamps_single_count(
    start_year, start_month, start_day, duration_days, window_minutes
):
    """
    Feature: smf-test-data-generator, Property 46: Cross-Type Timestamp Ordering
    
    Verify that requesting a single related timestamp returns the base timestamp.
    
    Validates: Requirements 20.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day, 12, 0, 0)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate a base timestamp
    mid_point = start_date + (end_date - start_date) / 2
    
    # Generate single related timestamp
    related_timestamps = strategy.generate_related_timestamps(
        base_timestamp=mid_point,
        count=1,
        window_minutes=window_minutes
    )
    
    # Should return exactly one timestamp
    assert len(related_timestamps) == 1
    
    # Should be the base timestamp
    assert related_timestamps[0] == mid_point


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    duration_days=st.integers(min_value=1, max_value=730),
    count=st.integers(min_value=2, max_value=10),
    window_minutes=st.integers(min_value=5, max_value=60)
)
def test_property_46_related_timestamps_spread(
    start_year, start_month, start_day, duration_days, count, window_minutes
):
    """
    Feature: smf-test-data-generator, Property 46: Cross-Type Timestamp Ordering
    
    Verify that related timestamps are spread across the time window.
    
    Validates: Requirements 20.5
    """
    # Create time range
    start_date = datetime(start_year, start_month, start_day, 12, 0, 0)
    end_date = start_date + timedelta(days=duration_days)
    
    # Create distribution strategy
    strategy = DistributionStrategy(start_date, end_date)
    
    # Generate a base timestamp
    mid_point = start_date + (end_date - start_date) / 2
    
    # Generate multiple related timestamps
    related_timestamps = strategy.generate_related_timestamps(
        base_timestamp=mid_point,
        count=count,
        window_minutes=window_minutes
    )
    
    # Should return requested count
    assert len(related_timestamps) == count
    
    # With multiple timestamps, they should not all be identical
    # (unless window is very small, but we're using at least 5 minutes)
    unique_timestamps = set(related_timestamps)
    
    # With random generation, we expect some variety
    # (not all timestamps should be exactly the same)
    # Allow for small chance of duplicates with small counts
    if count >= 5:
        assert len(unique_timestamps) >= 2, (
            f"Expected some variety in {count} related timestamps, "
            f"but got only {len(unique_timestamps)} unique values"
        )
