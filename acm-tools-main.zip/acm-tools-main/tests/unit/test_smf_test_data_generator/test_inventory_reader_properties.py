"""
Property-based tests for inventory reader.

Tests correctness properties for database validation and artifact extraction.
"""

import pytest
import sqlite3
import tempfile
import os
from pathlib import Path
from hypothesis import given, strategies as st, assume, settings
from tools.smf_test_data_generator.inventory_reader import InventoryReader


# Strategy for generating database table names
@st.composite
def database_with_tables(draw, include_all_required=True):
    """Generate a temporary database with specified tables.
    
    Args:
        include_all_required: If True, includes all required tables.
                            If False, randomly includes/excludes tables.
    
    Returns:
        Tuple of (db_path, existing_tables, missing_tables)
    """
    required_tables = [
        'inventory_programs',
        'inventory_jcl',
        'inventory_datasets',
        'inventory_cics'
    ]
    
    # Create temporary database
    db_fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(db_fd)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    if include_all_required:
        tables_to_create = required_tables
        missing_tables = []
    else:
        # Randomly decide which tables to create
        tables_to_create = []
        missing_tables = []
        for table in required_tables:
            if draw(st.booleans()):
                tables_to_create.append(table)
            else:
                missing_tables.append(table)
    
    # Create tables with minimal schema
    for table in tables_to_create:
        if table == 'inventory_programs':
            cursor.execute("""
                CREATE TABLE inventory_programs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    program_name VARCHAR(8) NOT NULL,
                    library_name VARCHAR(44) NOT NULL,
                    link_date DATE,
                    size_bytes INTEGER,
                    entry_point VARCHAR(16)
                )
            """)
        elif table == 'inventory_jcl':
            cursor.execute("""
                CREATE TABLE inventory_jcl (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    member_name VARCHAR(8) NOT NULL,
                    library_name VARCHAR(44) NOT NULL,
                    last_modified DATE,
                    size_lines INTEGER
                )
            """)
        elif table == 'inventory_datasets':
            cursor.execute("""
                CREATE TABLE inventory_datasets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    dataset_name VARCHAR(44) NOT NULL,
                    creation_date DATE,
                    last_referenced DATE,
                    size_mb DECIMAL(12,2),
                    volume VARCHAR(6),
                    dataset_type VARCHAR(10)
                )
            """)
        elif table == 'inventory_cics':
            cursor.execute("""
                CREATE TABLE inventory_cics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    resource_name VARCHAR(8) NOT NULL,
                    resource_type VARCHAR(20) NOT NULL,
                    group_name VARCHAR(8),
                    status VARCHAR(20),
                    program_name VARCHAR(8),
                    dataset_name VARCHAR(44),
                    description TEXT,
                    language VARCHAR(20)
                )
            """)
    
    conn.commit()
    conn.close()
    
    return db_path, tables_to_create, missing_tables


@st.composite
def populated_database(draw):
    """Generate a database with all required tables and some data."""
    db_fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(db_fd)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create all required tables
    cursor.execute("""
        CREATE TABLE inventory_programs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            program_name VARCHAR(8) NOT NULL,
            library_name VARCHAR(44) NOT NULL,
            link_date DATE,
            size_bytes INTEGER,
            entry_point VARCHAR(16)
        )
    """)
    
    cursor.execute("""
        CREATE TABLE inventory_jcl (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_name VARCHAR(8) NOT NULL,
            library_name VARCHAR(44) NOT NULL,
            last_modified DATE,
            size_lines INTEGER
        )
    """)
    
    cursor.execute("""
        CREATE TABLE inventory_datasets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dataset_name VARCHAR(44) NOT NULL,
            creation_date DATE,
            last_referenced DATE,
            size_mb DECIMAL(12,2),
            volume VARCHAR(6),
            dataset_type VARCHAR(10)
        )
    """)
    
    cursor.execute("""
        CREATE TABLE inventory_cics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            resource_name VARCHAR(8) NOT NULL,
            resource_type VARCHAR(20) NOT NULL,
            group_name VARCHAR(8),
            status VARCHAR(20),
            program_name VARCHAR(8),
            dataset_name VARCHAR(44),
            description TEXT,
            language VARCHAR(20)
        )
    """)
    
    # Insert some random data (using unique names to avoid duplicates)
    num_programs = draw(st.integers(min_value=0, max_value=10))
    program_names_used = set()
    for i in range(num_programs):
        # Generate unique program name
        program_name = f"PROG{i:04d}"
        program_names_used.add(program_name)
        
        library_name = draw(st.text(min_size=1, max_size=44))
        size_bytes = draw(st.integers(min_value=1000, max_value=1000000))
        
        cursor.execute("""
            INSERT INTO inventory_programs (program_name, library_name, size_bytes)
            VALUES (?, ?, ?)
        """, (program_name, library_name, size_bytes))
    
    num_jcl = draw(st.integers(min_value=0, max_value=10))
    jcl_names_used = set()
    for i in range(num_jcl):
        # Generate unique JCL name
        member_name = f"JCL{i:05d}"
        jcl_names_used.add(member_name)
        
        library_name = draw(st.text(min_size=1, max_size=44))
        size_lines = draw(st.integers(min_value=10, max_value=10000))
        
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, (member_name, library_name, size_lines))
    
    num_datasets = draw(st.integers(min_value=0, max_value=10))
    dataset_names_used = set()
    for i in range(num_datasets):
        # Generate unique dataset name
        dataset_name = f"AWS.M2.DATASET{i:04d}.KSDS"
        dataset_names_used.add(dataset_name)
        
        size_mb = draw(st.floats(min_value=0.1, max_value=1000.0))
        dataset_type = draw(st.sampled_from(['VSAM', 'PS', 'PDS', 'PDSE']))
        
        cursor.execute("""
            INSERT INTO inventory_datasets (dataset_name, size_mb, dataset_type)
            VALUES (?, ?, ?)
        """, (dataset_name, size_mb, dataset_type))
    
    num_cics = draw(st.integers(min_value=0, max_value=10))
    cics_names_used = set()
    for i in range(num_cics):
        # Generate unique CICS transaction name (4 chars)
        resource_name = f"T{i:03d}"
        cics_names_used.add(resource_name)
        
        program_name = f"PROG{i:04d}"
        
        cursor.execute("""
            INSERT INTO inventory_cics (resource_name, resource_type, program_name)
            VALUES (?, 'TRANSACTION', ?)
        """, (resource_name, program_name))
    
    conn.commit()
    
    # Get counts for verification
    cursor.execute("SELECT COUNT(*) FROM inventory_programs")
    program_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM inventory_jcl")
    jcl_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM inventory_datasets")
    dataset_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_type = 'TRANSACTION'")
    cics_count = cursor.fetchone()[0]
    
    conn.close()
    
    return db_path, program_count, jcl_count, dataset_count, cics_count


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(db_info=database_with_tables(include_all_required=True))
def test_property_1_database_validation_success(db_info):
    """
    Feature: smf-test-data-generator, Property 1: Database Validation
    
    For any database path provided to the generator, if the database exists and
    contains all required tables (inventory_programs, inventory_jcl, inventory_datasets,
    inventory_cics), then validation should succeed.
    
    Validates: Requirements 1.1, 1.3
    """
    db_path, existing_tables, missing_tables = db_info
    
    try:
        reader = InventoryReader(db_path)
        valid, errors = reader.validate_database()
        
        # Should be valid since all required tables exist
        assert valid is True
        assert len(errors) == 0
        
        reader.close()
        
    finally:
        # Clean up
        if os.path.exists(db_path):
            os.unlink(db_path)


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(db_info=database_with_tables(include_all_required=False))
def test_property_1_database_validation_missing_tables(db_info):
    """
    Feature: smf-test-data-generator, Property 1: Database Validation
    
    For any database path provided to the generator, if the database is missing
    required tables, validation should fail with a descriptive error message.
    
    Validates: Requirements 1.1, 1.3
    """
    db_path, existing_tables, missing_tables = db_info
    
    # Only test if there are actually missing tables
    assume(len(missing_tables) > 0)
    
    try:
        reader = InventoryReader(db_path)
        valid, errors = reader.validate_database()
        
        # Should be invalid if any tables are missing
        assert valid is False
        assert len(errors) > 0
        
        # Error message should mention missing tables
        error_msg = errors[0]
        assert 'Database missing required tables' in error_msg
        
        # All missing tables should be mentioned in the error
        for table in missing_tables:
            assert table in error_msg
        
        reader.close()
        
    finally:
        # Clean up
        if os.path.exists(db_path):
            os.unlink(db_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    db_path=st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'P')),
        min_size=1,
        max_size=100
    ).filter(lambda x: not os.path.exists(x))
)
def test_property_1_database_validation_nonexistent_file(db_path):
    """
    Feature: smf-test-data-generator, Property 1: Database Validation
    
    For any database path that doesn't exist, the reader should raise
    FileNotFoundError with a descriptive error message.
    
    Validates: Requirements 1.1, 1.3
    """
    # Ensure the path doesn't exist
    assume(not os.path.exists(db_path))
    
    with pytest.raises(FileNotFoundError) as exc_info:
        InventoryReader(db_path)
    
    # Error message should mention the file not being found
    error_msg = str(exc_info.value)
    assert 'Database file not found' in error_msg
    assert db_path in error_msg


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(db_info=populated_database())
def test_property_2_artifact_extraction_completeness(db_info):
    """
    Feature: smf-test-data-generator, Property 2: Artifact Extraction Completeness
    
    For any valid inventory database, the generator should extract all program names,
    JCL job names, dataset names, and CICS transaction IDs that exist in their
    respective tables.
    
    Validates: Requirements 1.2, 1.4
    """
    db_path, expected_programs, expected_jcl, expected_datasets, expected_cics = db_info
    
    try:
        reader = InventoryReader(db_path)
        
        # Validate database first
        valid, errors = reader.validate_database()
        assert valid is True
        
        # Extract all artifacts
        programs = reader.get_programs()
        jcl_jobs = reader.get_jcl_jobs()
        datasets = reader.get_datasets()
        cics_transactions = reader.get_cics_transactions()
        
        # Verify counts match expected
        assert len(programs) == expected_programs
        assert len(jcl_jobs) == expected_jcl
        assert len(datasets) == expected_datasets
        assert len(cics_transactions) == expected_cics
        
        # Verify structure of returned data
        for program in programs:
            assert 'program_name' in program
            assert 'library_name' in program
            assert isinstance(program['program_name'], str)
            assert isinstance(program['library_name'], str)
        
        for jcl in jcl_jobs:
            assert 'member_name' in jcl
            assert 'library_name' in jcl
            assert isinstance(jcl['member_name'], str)
            assert isinstance(jcl['library_name'], str)
        
        for dataset in datasets:
            assert 'dataset_name' in dataset
            assert isinstance(dataset['dataset_name'], str)
        
        for cics in cics_transactions:
            assert 'resource_name' in cics
            assert 'resource_type' in cics
            assert cics['resource_type'] == 'TRANSACTION'
            assert isinstance(cics['resource_name'], str)
        
        reader.close()
        
    finally:
        # Clean up
        if os.path.exists(db_path):
            os.unlink(db_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(db_info=populated_database())
def test_property_2_cics_program_mapping_completeness(db_info):
    """
    Feature: smf-test-data-generator, Property 2: Artifact Extraction Completeness
    
    For any valid inventory database, the get_cics_programs() method should return
    a complete mapping of CICS transaction IDs to program names for all transactions
    that have an associated program.
    
    Validates: Requirements 1.2, 1.4
    """
    db_path, _, _, _, expected_cics = db_info
    
    try:
        reader = InventoryReader(db_path)
        
        # Get CICS transactions and program mapping
        cics_transactions = reader.get_cics_transactions()
        cics_programs = reader.get_cics_programs()
        
        # Verify mapping structure
        assert isinstance(cics_programs, dict)
        
        # Count transactions with program names
        transactions_with_programs = sum(
            1 for t in cics_transactions
            if t.get('program_name') and t['program_name'].strip()
        )
        
        # Mapping should have entries for all transactions with programs
        assert len(cics_programs) == transactions_with_programs
        
        # Verify each mapping entry
        for trans_id, program_name in cics_programs.items():
            assert isinstance(trans_id, str)
            assert isinstance(program_name, str)
            assert len(trans_id) > 0
            assert len(program_name) > 0
            
            # Verify this mapping exists in the transactions list
            matching_trans = [
                t for t in cics_transactions
                if t['resource_name'] == trans_id
            ]
            assert len(matching_trans) == 1
            assert matching_trans[0]['program_name'] == program_name
        
        reader.close()
        
    finally:
        # Clean up
        if os.path.exists(db_path):
            os.unlink(db_path)


@pytest.mark.property
@settings(max_examples=30, deadline=None)
@given(db_info=populated_database())
def test_property_2_artifact_extraction_no_duplicates(db_info):
    """
    Feature: smf-test-data-generator, Property 2: Artifact Extraction Completeness
    
    For any valid inventory database, extracted artifacts should not contain
    duplicates (each artifact should appear exactly once in the results).
    
    Validates: Requirements 1.2, 1.4
    """
    db_path, _, _, _, _ = db_info
    
    try:
        reader = InventoryReader(db_path)
        
        # Extract all artifacts
        programs = reader.get_programs()
        jcl_jobs = reader.get_jcl_jobs()
        datasets = reader.get_datasets()
        cics_transactions = reader.get_cics_transactions()
        
        # Check for duplicates by comparing list length to set length
        program_names = [p['program_name'] for p in programs]
        assert len(program_names) == len(set(program_names)) or len(program_names) == 0
        
        jcl_names = [j['member_name'] for j in jcl_jobs]
        assert len(jcl_names) == len(set(jcl_names)) or len(jcl_names) == 0
        
        dataset_names = [d['dataset_name'] for d in datasets]
        assert len(dataset_names) == len(set(dataset_names)) or len(dataset_names) == 0
        
        cics_names = [c['resource_name'] for c in cics_transactions]
        assert len(cics_names) == len(set(cics_names)) or len(cics_names) == 0
        
        reader.close()
        
    finally:
        # Clean up
        if os.path.exists(db_path):
            os.unlink(db_path)
