"""
Property-based tests for SMF Type 64 record generator.

Tests correctness properties for Type 64 record generation including schema
compliance and unified schema compliance.
"""

import pytest
import re
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, settings
from tools.smf_test_data_generator.smf64_generator import SMF64RecordGenerator
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters


# Helper function to create a test catalog
def create_test_catalog(
    programs=None,
    jcl_jobs=None,
    datasets=None,
    missing_datasets=None
):
    """Create a test artifact catalog with specified artifacts."""
    if programs is None:
        programs = ['PROG01', 'PROG02', 'PROG03']
    if jcl_jobs is None:
        jcl_jobs = ['JOB01', 'JOB02']
    if datasets is None:
        # Include VSAM datasets
        datasets = [
            'DATA.VSAM.KSDS.ONE',
            'DATA.VSAM.ESDS.TWO',
            'DATA.VSAM.RRDS.THREE'
        ]
    if missing_datasets is None:
        missing_datasets = []
    
    # Create catalog directly with mock data
    catalog = ArtifactCatalog.__new__(ArtifactCatalog)
    
    # Initialize storage structures
    catalog._active_programs = {'high': [], 'medium': [], 'low': []}
    catalog._active_jcl = {'high': [], 'medium': [], 'low': []}
    catalog._active_cics_transactions = {'high': [], 'medium': [], 'low': []}
    catalog._active_datasets = {'high': [], 'medium': [], 'low': []}
    
    catalog._unreferenced_programs = set()
    catalog._unreferenced_jcl = set()
    catalog._unreferenced_datasets = set()
    catalog._unreferenced_cics_transactions = set()
    
    catalog._missing_programs = set()
    catalog._missing_datasets = set(missing_datasets)
    catalog._missing_cics_transactions = set()
    
    catalog._cics_program_mapping = {}
    catalog._program_datasets = {}
    
    # Add programs to high frequency
    catalog._active_programs['high'] = list(programs)
    
    # Add JCL jobs to high frequency
    catalog._active_jcl['high'] = list(jcl_jobs)
    
    # Add datasets to high frequency
    catalog._active_datasets['high'] = list(datasets)
    
    # Add missing datasets to high frequency
    catalog._active_datasets['high'].extend(missing_datasets)
    
    return catalog


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365),
    access_mode=st.sampled_from(['INPUT', 'OUTPUT', 'UPDATE']),
    mips=st.integers(min_value=500, max_value=5000)
)
def test_property_36_type64_schema_compliance(start_year, duration_days, access_mode, mips):
    """
    Feature: smf-test-data-generator, Property 36: Type 64 Schema Compliance
    
    For any generated Type 64 record, the record structure should match the
    unified schema definition with identification and performance sections
    containing component_name, job_name, user_id, and performance metrics.
    
    Validates: Requirements 16.1, 16.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    open_timestamp = start_date
    close_timestamp = start_date + timedelta(minutes=5)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({'mips': mips})
    generator = SMF64RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate a single record
    record = generator.generate_vsam_close_record(
        component_name='TEST.VSAM.KSDS',
        job_name='TESTJOB',
        open_timestamp=open_timestamp,
        close_timestamp=close_timestamp,
        access_mode=access_mode
    )
    
    # Check top-level required fields
    assert 'record_type' in record
    assert record['record_type'] == 64
    assert 'subtype' in record
    assert 'system_id' in record
    assert 'date' in record
    assert 'timestamp' in record
    assert 'record_length' in record
    
    # Check identification section is present
    assert 'identification' in record, "Missing required section: identification"
    assert record['identification'] is not None, "Section identification is None"
    
    # Check identification section fields
    ident = record['identification']
    assert 'component_name' in ident, "Missing component_name in identification"
    assert 'job_name' in ident, "Missing job_name in identification"
    assert 'user_id' in ident, "Missing user_id in identification"
    assert 'dd_name' in ident, "Missing dd_name in identification"
    assert 'situation' in ident, "Missing situation in identification"
    assert 'component_type' in ident, "Missing component_type in identification"
    assert 'open_time' in ident, "Missing open_time in identification"
    assert 'close_time' in ident, "Missing close_time in identification"
    assert 'catalog_name' in ident, "Missing catalog_name in identification"
    assert 'job_id' in ident, "Missing job_id in identification"
    
    # Verify component_name, job_name, user_id are not empty
    assert ident['component_name'], "component_name should not be empty"
    assert ident['job_name'], "job_name should not be empty"
    assert ident['user_id'], "user_id should not be empty"
    
    # Check performance section is present
    assert 'performance' in record, "Missing required section: performance"
    assert record['performance'] is not None, "Section performance is None"
    
    # Check performance section fields
    perf = record['performance']
    assert 'records_retrieved' in perf, "Missing records_retrieved in performance"
    assert 'records_inserted' in perf, "Missing records_inserted in performance"
    assert 'records_updated' in perf, "Missing records_updated in performance"
    assert 'records_deleted' in perf, "Missing records_deleted in performance"
    assert 'ci_splits' in perf, "Missing ci_splits in performance"
    assert 'ca_splits' in perf, "Missing ca_splits in performance"
    assert 'excps' in perf, "Missing excps in performance"
    assert 'ci_size' in perf, "Missing ci_size in performance"
    assert 'max_record_size' in perf, "Missing max_record_size in performance"
    
    # Verify performance metrics are non-negative
    assert perf['records_retrieved'] >= 0, "records_retrieved should be non-negative"
    assert perf['records_inserted'] >= 0, "records_inserted should be non-negative"
    assert perf['records_updated'] >= 0, "records_updated should be non-negative"
    assert perf['records_deleted'] >= 0, "records_deleted should be non-negative"
    assert perf['ci_splits'] >= 0, "ci_splits should be non-negative"
    assert perf['ca_splits'] >= 0, "ca_splits should be non-negative"
    assert perf['excps'] >= 0, "excps should be non-negative"
    assert perf['ci_size'] > 0, "ci_size should be positive"
    assert perf['max_record_size'] > 0, "max_record_size should be positive"
    
    # Verify performance metrics match access mode expectations
    if access_mode == 'INPUT':
        # Read-only should have no inserts, updates, or deletes
        assert perf['records_inserted'] == 0, "INPUT mode should have no inserts"
        assert perf['records_updated'] == 0, "INPUT mode should have no updates"
        assert perf['records_deleted'] == 0, "INPUT mode should have no deletes"
        assert perf['ci_splits'] == 0, "INPUT mode should have no CI splits"
        assert perf['ca_splits'] == 0, "INPUT mode should have no CA splits"
        assert perf['records_retrieved'] > 0, "INPUT mode should have retrievals"
    elif access_mode == 'OUTPUT':
        # Write-only should have no retrievals, updates, or deletes
        assert perf['records_retrieved'] == 0, "OUTPUT mode should have no retrievals"
        assert perf['records_updated'] == 0, "OUTPUT mode should have no updates"
        assert perf['records_deleted'] == 0, "OUTPUT mode should have no deletes"
        assert perf['records_inserted'] > 0, "OUTPUT mode should have inserts"


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_30_unified_schema_compliance_type64(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 30: Unified Schema Compliance
    
    For any generated SMF record of any type, the record should include all
    fields required by the smf_records common table (record_type, subtype,
    system_id, record_date, record_time, record_timestamp).
    
    Validates: Requirements 11.2, 11.3
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF64RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check unified schema compliance for each record
    for record in records:
        # Check required common fields
        assert 'record_type' in record, "Missing required field: record_type"
        assert 'subtype' in record, "Missing required field: subtype"
        assert 'system_id' in record, "Missing required field: system_id"
        assert 'date' in record, "Missing required field: date (record_date)"
        assert 'timestamp' in record, "Missing required field: timestamp (record_time)"
        
        # Verify record_type is 64 for Type 64 records
        assert record['record_type'] == 64, (
            f"Expected record_type 64, got {record['record_type']}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_31_record_timestamp_format_type64(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 31: Record Timestamp Format
    
    For any generated SMF record, the record_timestamp field should match
    the format "YYYY-MM-DD HH:MM:SS".
    
    Validates: Requirements 11.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF64RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Pattern for "YYYY-MM-DD HH:MM:SS" format
    timestamp_pattern = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
    
    # Check timestamp format for each record
    for record in records:
        date = record.get('date')
        time = record.get('timestamp')
        
        # Check date format (YYYY-MM-DD)
        assert date is not None, "date field should not be None"
        date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        assert date_pattern.match(date), (
            f"date '{date}' does not match format YYYY-MM-DD"
        )
        
        # Check time format (HH:MM:SS)
        assert time is not None, "timestamp field should not be None"
        time_pattern = re.compile(r'^\d{2}:\d{2}:\d{2}$')
        assert time_pattern.match(time), (
            f"timestamp '{time}' does not match format HH:MM:SS"
        )
        
        # Construct full timestamp and verify format
        full_timestamp = f"{date} {time}"
        assert timestamp_pattern.match(full_timestamp), (
            f"Full timestamp '{full_timestamp}' does not match format YYYY-MM-DD HH:MM:SS"
        )
        
        # Also check open_time and close_time in identification section
        ident = record.get('identification', {})
        open_time = ident.get('open_time')
        close_time = ident.get('close_time')
        
        if open_time:
            assert timestamp_pattern.match(open_time), (
                f"open_time '{open_time}' does not match format YYYY-MM-DD HH:MM:SS"
            )
        
        if close_time:
            assert timestamp_pattern.match(close_time), (
                f"close_time '{close_time}' does not match format YYYY-MM-DD HH:MM:SS"
            )
