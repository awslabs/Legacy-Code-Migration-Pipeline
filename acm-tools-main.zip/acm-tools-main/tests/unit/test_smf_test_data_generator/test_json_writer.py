"""
Unit tests for JSON writer.

Tests specific file naming conventions and edge cases for JSON file writing.
"""

import pytest
import json
import tempfile
import os
from pathlib import Path
from tools.smf_test_data_generator.json_writer import JSONWriter


class TestFileNaming:
    """Test file naming conventions for different record types."""
    
    def test_type30_file_naming(self):
        """Test Type 30 file naming convention: smf30_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "carddemo")
            test_records = [{'record_type': 30, 'test': 'data'}]
            
            output_file = writer.write_type30_records(test_records)
            
            assert os.path.basename(output_file) == "smf30_carddemo.json"
            assert os.path.exists(output_file)
    
    def test_type110_file_naming(self):
        """Test Type 110 file naming convention: smf110_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "carddemo")
            test_records = [{'record_type': 110, 'test': 'data'}]
            
            output_file = writer.write_type110_records(test_records)
            
            assert os.path.basename(output_file) == "smf110_carddemo.json"
            assert os.path.exists(output_file)
    
    def test_type14_file_naming(self):
        """Test Type 14 file naming convention: smf14_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [{'record_type': 14, 'test': 'data'}]
            
            output_file = writer.write_records(14, test_records)
            
            assert os.path.basename(output_file) == "smf14_testapp.json"
            assert os.path.exists(output_file)
    
    def test_type15_file_naming(self):
        """Test Type 15 file naming convention: smf15_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [{'record_type': 15, 'test': 'data'}]
            
            output_file = writer.write_records(15, test_records)
            
            assert os.path.basename(output_file) == "smf15_testapp.json"
            assert os.path.exists(output_file)
    
    def test_type17_file_naming(self):
        """Test Type 17 file naming convention: smf17_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [{'record_type': 17, 'test': 'data'}]
            
            output_file = writer.write_records(17, test_records)
            
            assert os.path.basename(output_file) == "smf17_testapp.json"
            assert os.path.exists(output_file)
    
    def test_type62_file_naming(self):
        """Test Type 62 file naming convention: smf62_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [{'record_type': 62, 'test': 'data'}]
            
            output_file = writer.write_records(62, test_records)
            
            assert os.path.basename(output_file) == "smf62_testapp.json"
            assert os.path.exists(output_file)
    
    def test_type64_file_naming(self):
        """Test Type 64 file naming convention: smf64_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [{'record_type': 64, 'test': 'data'}]
            
            output_file = writer.write_records(64, test_records)
            
            assert os.path.basename(output_file) == "smf64_testapp.json"
            assert os.path.exists(output_file)
    
    def test_type100_file_naming(self):
        """Test Type 100 file naming convention: smf100_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "db2app")
            test_records = [{'record_type': 100, 'test': 'data'}]
            
            output_file = writer.write_records(100, test_records)
            
            assert os.path.basename(output_file) == "smf100_db2app.json"
            assert os.path.exists(output_file)
    
    def test_type101_file_naming(self):
        """Test Type 101 file naming convention: smf101_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "db2app")
            test_records = [{'record_type': 101, 'test': 'data'}]
            
            output_file = writer.write_records(101, test_records)
            
            assert os.path.basename(output_file) == "smf101_db2app.json"
            assert os.path.exists(output_file)
    
    def test_type102_file_naming(self):
        """Test Type 102 file naming convention: smf102_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "db2app")
            test_records = [{'record_type': 102, 'test': 'data'}]
            
            output_file = writer.write_records(102, test_records)
            
            assert os.path.basename(output_file) == "smf102_db2app.json"
            assert os.path.exists(output_file)
    
    def test_application_name_with_underscores(self):
        """Test file naming with application name containing underscores"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "my_test_app")
            test_records = [{'record_type': 30, 'test': 'data'}]
            
            output_file = writer.write_type30_records(test_records)
            
            assert os.path.basename(output_file) == "smf30_my_test_app.json"
    
    def test_application_name_with_hyphens(self):
        """Test file naming with application name containing hyphens"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "my-test-app")
            test_records = [{'record_type': 110, 'test': 'data'}]
            
            output_file = writer.write_type110_records(test_records)
            
            assert os.path.basename(output_file) == "smf110_my-test-app.json"
    
    def test_merged_file_naming(self):
        """Test merged file naming convention: smf_all_{app}.json"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "carddemo")
            records_by_type = {
                30: [{'record_type': 30, 'test': 'data'}],
                110: [{'record_type': 110, 'test': 'data'}]
            }
            
            output_file = writer.write_merged_records(records_by_type)
            
            assert os.path.basename(output_file) == "smf_all_carddemo.json"
            assert os.path.exists(output_file)


class TestJSONContent:
    """Test JSON content structure and formatting."""
    
    def test_empty_records_list(self):
        """Test writing empty records list produces valid JSON array"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            
            output_file = writer.write_type30_records([])
            
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert content == []
                assert isinstance(content, list)
    
    def test_single_record(self):
        """Test writing single record"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_record = {
                'record_type': 30,
                'system_id': 'SYS1',
                'date': '2023-06-15'
            }
            
            output_file = writer.write_type30_records([test_record])
            
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert len(content) == 1
                assert content[0] == test_record
    
    def test_multiple_records(self):
        """Test writing multiple records"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [
                {'record_type': 30, 'id': 1},
                {'record_type': 30, 'id': 2},
                {'record_type': 30, 'id': 3}
            ]
            
            output_file = writer.write_type30_records(test_records)
            
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert len(content) == 3
                assert content == test_records
    
    def test_json_indentation(self):
        """Test JSON is formatted with proper indentation (indent=2)"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [
                {
                    'record_type': 30,
                    'nested': {
                        'field1': 'value1',
                        'field2': 'value2'
                    }
                }
            ]
            
            output_file = writer.write_type30_records(test_records)
            
            with open(output_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
                # Should have newlines (formatted)
                assert '\n' in content
                
                # Should match indent=2 formatting
                expected = json.dumps(test_records, indent=2)
                assert content == expected
    
    def test_utf8_encoding(self):
        """Test UTF-8 encoding is used"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            test_records = [
                {
                    'record_type': 30,
                    'description': 'Test with special chars: é, ñ, ü'
                }
            ]
            
            output_file = writer.write_type30_records(test_records)
            
            # Read with UTF-8 encoding
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert content[0]['description'] == 'Test with special chars: é, ñ, ü'


class TestMultiTypeWriting:
    """Test writing multiple record types."""
    
    def test_write_all_records_creates_separate_files(self):
        """Test write_all_records creates separate file for each type"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            records_by_type = {
                30: [{'record_type': 30, 'test': 'data30'}],
                110: [{'record_type': 110, 'test': 'data110'}],
                14: [{'record_type': 14, 'test': 'data14'}]
            }
            
            written_files = writer.write_all_records(records_by_type)
            
            # Should have 3 type-specific files + 1 merged file
            assert len(written_files) == 4
            assert 30 in written_files
            assert 110 in written_files
            assert 14 in written_files
            assert 'merged' in written_files
            
            # Verify each file exists
            for file_path in written_files.values():
                assert os.path.exists(file_path)
    
    def test_write_all_records_correct_content(self):
        """Test each file contains only its record type"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            records_by_type = {
                30: [{'record_type': 30, 'id': 1}, {'record_type': 30, 'id': 2}],
                110: [{'record_type': 110, 'id': 3}]
            }
            
            written_files = writer.write_all_records(records_by_type)
            
            # Check Type 30 file
            with open(written_files[30], 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert len(content) == 2
                assert all(r['record_type'] == 30 for r in content)
            
            # Check Type 110 file
            with open(written_files[110], 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert len(content) == 1
                assert content[0]['record_type'] == 110
    
    def test_merged_file_contains_all_records(self):
        """Test merged file contains records from all types"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            records_by_type = {
                30: [{'record_type': 30, 'id': 1}],
                110: [{'record_type': 110, 'id': 2}],
                14: [{'record_type': 14, 'id': 3}]
            }
            
            written_files = writer.write_all_records(records_by_type)
            
            # Check merged file
            with open(written_files['merged'], 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert len(content) == 3
                
                # Should contain all record types
                record_types = {r['record_type'] for r in content}
                assert record_types == {30, 110, 14}
    
    def test_merged_file_sorted_by_type(self):
        """Test merged file has records sorted by type"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            # Provide types in non-sorted order
            records_by_type = {
                110: [{'record_type': 110, 'id': 2}],
                14: [{'record_type': 14, 'id': 3}],
                30: [{'record_type': 30, 'id': 1}]
            }
            
            written_files = writer.write_all_records(records_by_type)
            
            # Check merged file has sorted order
            with open(written_files['merged'], 'r', encoding='utf-8') as f:
                content = json.load(f)
                
                # Records should be in order: 14, 30, 110
                assert content[0]['record_type'] == 14
                assert content[1]['record_type'] == 30
                assert content[2]['record_type'] == 110


class TestDirectoryHandling:
    """Test output directory creation and handling."""
    
    def test_creates_directory_if_not_exists(self):
        """Test directory is created if it doesn't exist"""
        with tempfile.TemporaryDirectory() as temp_base:
            output_dir = os.path.join(temp_base, 'new_directory')
            
            assert not os.path.exists(output_dir)
            
            writer = JSONWriter(output_dir, "testapp")
            writer.write_type30_records([{'test': 'data'}])
            
            assert os.path.exists(output_dir)
            assert os.path.isdir(output_dir)
    
    def test_creates_nested_directories(self):
        """Test nested directories are created"""
        with tempfile.TemporaryDirectory() as temp_base:
            output_dir = os.path.join(temp_base, 'level1', 'level2', 'level3')
            
            assert not os.path.exists(output_dir)
            
            writer = JSONWriter(output_dir, "testapp")
            writer.write_type30_records([{'test': 'data'}])
            
            assert os.path.exists(output_dir)
            assert os.path.isdir(output_dir)
    
    def test_uses_existing_directory(self):
        """Test existing directory is used without error"""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Directory already exists
            assert os.path.exists(temp_dir)
            
            writer = JSONWriter(temp_dir, "testapp")
            output_file = writer.write_type30_records([{'test': 'data'}])
            
            assert os.path.exists(output_file)
    
    def test_pathlib_path_support(self):
        """Test Path objects are supported"""
        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = Path(temp_dir) / 'subdir'
            
            writer = JSONWriter(str(output_path), "testapp")
            output_file = writer.write_type30_records([{'test': 'data'}])
            
            assert os.path.exists(output_file)


class TestEdgeCases:
    """Test edge cases and error conditions."""
    
    def test_overwrite_existing_file(self):
        """Test existing file is overwritten"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            
            # First write
            writer.write_type30_records([{'id': 1}])
            
            # Second write should overwrite
            output_file = writer.write_type30_records([{'id': 2}])
            
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert len(content) == 1
                assert content[0]['id'] == 2
    
    def test_large_record_count(self):
        """Test writing large number of records"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            
            # Create 1000 records
            test_records = [{'record_type': 30, 'id': i} for i in range(1000)]
            
            output_file = writer.write_type30_records(test_records)
            
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert len(content) == 1000
    
    def test_complex_nested_structure(self):
        """Test writing records with complex nested structures"""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, "testapp")
            
            test_record = {
                'record_type': 30,
                'identification': {
                    'job_name': 'TEST',
                    'nested': {
                        'level2': {
                            'level3': {
                                'value': 'deep'
                            }
                        }
                    }
                },
                'arrays': [1, 2, 3],
                'mixed': [
                    {'a': 1},
                    {'b': 2}
                ]
            }
            
            output_file = writer.write_type30_records([test_record])
            
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert content[0] == test_record
