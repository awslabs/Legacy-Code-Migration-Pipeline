"""
Property-based tests for SMF Type 14 record generator.

Tests correctness properties for Type 14 record generation including schema
compliance and unified schema compliance.
"""

import pytest
import re
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, settings
from tools.smf_test_data_generator.smf14_generator import SMF14RecordGenerator
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters


# Helper function to create a test catalog
def create_test_catalog(
    programs=None,
    jcl_jobs=None,
    datasets=None,
    missing_datasets=None
):
    """Create a test artifact catalog with specified artifacts."""
    if programs is None:
        programs = ['PROG01', 'PROG02', 'PROG03']
    if jcl_jobs is None:
        jcl_jobs = ['JOB01', 'JOB02']
    if datasets is None:
        datasets = ['DATA.SET.ONE', 'DATA.SET.TWO', 'DATA.SET.THREE']
    if missing_datasets is None:
        missing_datasets = []
    
    # Create catalog directly with mock data
    catalog = ArtifactCatalog.__new__(ArtifactCatalog)
    
    # Initialize storage structures
    catalog._active_programs = {'high': [], 'medium': [], 'low': []}
    catalog._active_jcl = {'high': [], 'medium': [], 'low': []}
    catalog._active_cics_transactions = {'high': [], 'medium': [], 'low': []}
    catalog._active_datasets = {'high': [], 'medium': [], 'low': []}
    
    catalog._unreferenced_programs = set()
    catalog._unreferenced_jcl = set()
    catalog._unreferenced_datasets = set()
    catalog._unreferenced_cics_transactions = set()
    
    catalog._missing_programs = set()
    catalog._missing_datasets = set(missing_datasets)
    catalog._missing_cics_transactions = set()
    
    catalog._cics_program_mapping = {}
    catalog._program_datasets = {}
    
    # Add programs to high frequency
    catalog._active_programs['high'] = list(programs)
    
    # Add JCL jobs to high frequency
    catalog._active_jcl['high'] = list(jcl_jobs)
    
    # Add datasets to high frequency
    catalog._active_datasets['high'] = list(datasets)
    
    # Add missing datasets to high frequency
    catalog._active_datasets['high'].extend(missing_datasets)
    
    return catalog


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_32_type14_schema_compliance(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 32: Type 14 Schema Compliance
    
    For any generated Type 14 record, the record structure should match the
    unified schema definition with identification section containing dataset_name,
    job_name, program_name, and user_id.
    
    Validates: Requirements 12.1, 12.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF14RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate a single record
    record = generator.generate_dataset_input_record(
        dataset_name='TEST.DATA.SET',
        job_name='TESTJOB',
        program_name='TESTPROG',
        timestamp=start_date
    )
    
    # Check top-level required fields
    assert 'record_type' in record
    assert record['record_type'] == 14
    assert 'subtype' in record
    assert 'system_id' in record
    assert 'date' in record
    assert 'timestamp' in record
    assert 'record_length' in record
    
    # Check identification section is present
    assert 'identification' in record, "Missing required section: identification"
    assert record['identification'] is not None, "Section identification is None"
    
    # Check identification section fields
    ident = record['identification']
    assert 'dataset_name' in ident, "Missing dataset_name in identification"
    assert 'job_name' in ident, "Missing job_name in identification"
    assert 'program_name' in ident, "Missing program_name in identification"
    assert 'user_id' in ident, "Missing user_id in identification"
    assert 'job_id' in ident, "Missing job_id in identification"
    assert 'step_name' in ident, "Missing step_name in identification"
    assert 'dd_name' in ident, "Missing dd_name in identification"
    assert 'open_time' in ident, "Missing open_time in identification"
    assert 'close_time' in ident, "Missing close_time in identification"
    assert 'dataset_org' in ident, "Missing dataset_org in identification"
    assert 'record_format' in ident, "Missing record_format in identification"
    assert 'excp_count' in ident, "Missing excp_count in identification"
    assert 'num_volumes' in ident, "Missing num_volumes in identification"
    assert 'volume_serials' in ident, "Missing volume_serials in identification"
    
    # Verify dataset_name, job_name, program_name, user_id are not empty
    assert ident['dataset_name'], "dataset_name should not be empty"
    assert ident['job_name'], "job_name should not be empty"
    assert ident['program_name'], "program_name should not be empty"
    assert ident['user_id'], "user_id should not be empty"


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_30_unified_schema_compliance_type14(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 30: Unified Schema Compliance
    
    For any generated SMF record of any type, the record should include all
    fields required by the smf_records common table (record_type, subtype,
    system_id, record_date, record_time, record_timestamp).
    
    Validates: Requirements 11.2, 11.3
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF14RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check unified schema compliance for each record
    for record in records:
        # Check required common fields
        assert 'record_type' in record, "Missing required field: record_type"
        assert 'subtype' in record, "Missing required field: subtype"
        assert 'system_id' in record, "Missing required field: system_id"
        assert 'date' in record, "Missing required field: date (record_date)"
        assert 'timestamp' in record, "Missing required field: timestamp (record_time)"
        
        # Verify record_type is 14 for Type 14 records
        assert record['record_type'] == 14, (
            f"Expected record_type 14, got {record['record_type']}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_31_record_timestamp_format_type14(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 31: Record Timestamp Format
    
    For any generated SMF record, the record_timestamp field should match
    the format "YYYY-MM-DD HH:MM:SS".
    
    Validates: Requirements 11.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF14RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Pattern for "YYYY-MM-DD HH:MM:SS" format
    timestamp_pattern = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
    
    # Check timestamp format for each record
    for record in records:
        date = record.get('date')
        time = record.get('timestamp')
        
        # Check date format (YYYY-MM-DD)
        assert date is not None, "date field should not be None"
        date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        assert date_pattern.match(date), (
            f"date '{date}' does not match format YYYY-MM-DD"
        )
        
        # Check time format (HH:MM:SS)
        assert time is not None, "timestamp field should not be None"
        time_pattern = re.compile(r'^\d{2}:\d{2}:\d{2}$')
        assert time_pattern.match(time), (
            f"timestamp '{time}' does not match format HH:MM:SS"
        )
        
        # Construct full timestamp and verify format
        full_timestamp = f"{date} {time}"
        assert timestamp_pattern.match(full_timestamp), (
            f"Full timestamp '{full_timestamp}' does not match format YYYY-MM-DD HH:MM:SS"
        )
        
        # Also check open_time and close_time in identification section
        ident = record.get('identification', {})
        open_time = ident.get('open_time')
        close_time = ident.get('close_time')
        
        if open_time:
            assert timestamp_pattern.match(open_time), (
                f"open_time '{open_time}' does not match format YYYY-MM-DD HH:MM:SS"
            )
        
        if close_time:
            assert timestamp_pattern.match(close_time), (
                f"close_time '{close_time}' does not match format YYYY-MM-DD HH:MM:SS"
            )
