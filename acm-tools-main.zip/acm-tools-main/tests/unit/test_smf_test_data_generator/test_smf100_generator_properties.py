"""
Property-based tests for SMF Type 100 record generator.

Tests correctness properties for Type 100 record generation including schema
compliance, DB2 CPU time scaling, DB2 subsystem ID consistency, and unified
schema compliance.
"""

import pytest
import re
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, settings
from tools.smf_test_data_generator.smf100_generator import SMF100RecordGenerator
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters


# Helper function to create a test catalog
def create_test_catalog(
    programs=None,
    jcl_jobs=None,
    datasets=None
):
    """Create a test artifact catalog with specified artifacts."""
    if programs is None:
        programs = ['PROG01', 'PROG02', 'PROG03']
    if jcl_jobs is None:
        jcl_jobs = ['JOB01', 'JOB02']
    if datasets is None:
        datasets = ['DATA.SET.ONE', 'DATA.SET.TWO']
    
    # Create catalog directly with mock data
    catalog = ArtifactCatalog.__new__(ArtifactCatalog)
    
    # Initialize storage structures
    catalog._active_programs = {'high': [], 'medium': [], 'low': []}
    catalog._active_jcl = {'high': [], 'medium': [], 'low': []}
    catalog._active_cics_transactions = {'high': [], 'medium': [], 'low': []}
    catalog._active_datasets = {'high': [], 'medium': [], 'low': []}
    
    catalog._unreferenced_programs = set()
    catalog._unreferenced_jcl = set()
    catalog._unreferenced_datasets = set()
    catalog._unreferenced_cics_transactions = set()
    
    catalog._missing_programs = set()
    catalog._missing_datasets = set()
    catalog._missing_cics_transactions = set()
    
    catalog._cics_program_mapping = {}
    catalog._program_datasets = {}
    
    # Add programs to high frequency
    catalog._active_programs['high'] = list(programs)
    
    # Add JCL jobs to high frequency
    catalog._active_jcl['high'] = list(jcl_jobs)
    
    # Add datasets to high frequency
    catalog._active_datasets['high'] = list(datasets)
    
    return catalog


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365),
    mips=st.integers(min_value=500, max_value=5000)
)
def test_property_47_type100_schema_compliance(start_year, duration_days, mips):
    """
    Feature: smf-test-data-generator, Property 47: Type 100 Schema Compliance
    
    For any generated Type 100 record, the record structure should match the
    unified schema definition with statistics section, SQL statistics, buffer
    pool statistics, latch statistics, and DDF statistics.
    
    Validates: Requirements 17.1, 17.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    timestamp = start_date
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({'mips': mips})
    generator = SMF100RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate a single record
    record = generator.generate_statistics_record(
        subsystem_id='DB2P',
        timestamp=timestamp
    )
    
    # Check top-level required fields
    assert 'record_type' in record
    assert record['record_type'] == 100
    assert 'subtype' in record
    assert 'system_id' in record
    assert 'date' in record
    assert 'timestamp' in record
    assert 'record_length' in record
    assert 'subsystem_id' in record
    
    # Verify subsystem_id is not empty
    assert record['subsystem_id'], "subsystem_id should not be empty"
    
    # Check statistics section is present
    assert 'statistics' in record, "Missing required section: statistics"
    assert record['statistics'] is not None, "Section statistics is None"
    
    # Check statistics section fields
    stats = record['statistics']
    assert 'product_section_offset' in stats
    assert 'product_section_length' in stats
    assert 'product_section_count' in stats
    assert 'has_correlation_header' in stats
    assert 'has_trace_header' in stats
    assert 'has_cpu_header' in stats
    assert 'has_distributed_header' in stats
    assert 'has_data_sharing_header' in stats
    assert 'self_defining_section_offset' in stats
    
    # Check SQL statistics section is present
    assert 'sql_statistics' in record, "Missing required section: sql_statistics"
    assert record['sql_statistics'] is not None, "Section sql_statistics is None"
    
    # Check SQL statistics fields
    sql_stats = record['sql_statistics']
    assert 'select_count' in sql_stats
    assert 'insert_count' in sql_stats
    assert 'update_count' in sql_stats
    assert 'delete_count' in sql_stats
    assert 'describe_count' in sql_stats
    assert 'prepare_count' in sql_stats
    
    # Verify SQL statistics are non-negative
    assert sql_stats['select_count'] >= 0
    assert sql_stats['insert_count'] >= 0
    assert sql_stats['update_count'] >= 0
    assert sql_stats['delete_count'] >= 0
    assert sql_stats['describe_count'] >= 0
    assert sql_stats['prepare_count'] >= 0
    
    # Check buffer pool statistics section is present
    assert 'buffer_pool' in record, "Missing required section: buffer_pool"
    assert record['buffer_pool'] is not None, "Section buffer_pool is None"
    assert isinstance(record['buffer_pool'], list), "buffer_pool should be a list"
    assert len(record['buffer_pool']) > 0, "buffer_pool should have at least one entry"
    
    # Check buffer pool statistics fields
    for bp in record['buffer_pool']:
        assert 'buffer_pool_id' in bp
        assert 'getpage_requests' in bp
        assert 'sync_read_io' in bp
        assert 'sync_write_io' in bp
        assert 'sequential_prefetch' in bp
        assert 'list_prefetch' in bp
        
        # Verify buffer pool statistics are non-negative
        assert bp['buffer_pool_id'] >= 0
        assert bp['getpage_requests'] >= 0
        assert bp['sync_read_io'] >= 0
        assert bp['sync_write_io'] >= 0
        assert bp['sequential_prefetch'] >= 0
        assert bp['list_prefetch'] >= 0
    
    # Check latch statistics section is present
    assert 'latch_statistics' in record, "Missing required section: latch_statistics"
    assert record['latch_statistics'] is not None, "Section latch_statistics is None"
    assert isinstance(record['latch_statistics'], list), "latch_statistics should be a list"
    assert len(record['latch_statistics']) > 0, "latch_statistics should have at least one entry"
    
    # Check latch statistics fields
    for latch in record['latch_statistics']:
        assert 'latch_type' in latch
        assert 'latch_requests' in latch
        assert 'latch_suspensions' in latch
        
        # Verify latch statistics are non-negative
        assert latch['latch_requests'] >= 0
        assert latch['latch_suspensions'] >= 0
        assert latch['latch_type'], "latch_type should not be empty"
    
    # Check DDF statistics section is present
    assert 'ddf_statistics' in record, "Missing required section: ddf_statistics"
    assert record['ddf_statistics'] is not None, "Section ddf_statistics is None"
    
    # Check DDF statistics fields
    ddf = record['ddf_statistics']
    assert 'distributed_requests' in ddf
    assert 'remote_requests' in ddf
    
    # Verify DDF statistics are non-negative
    assert ddf['distributed_requests'] >= 0
    assert ddf['remote_requests'] >= 0


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365),
    mips1=st.integers(min_value=500, max_value=2000),
    mips2=st.integers(min_value=2001, max_value=5000)
)
def test_property_50_db2_cpu_time_scaling(start_year, duration_days, mips1, mips2):
    """
    Feature: smf-test-data-generator, Property 50: DB2 CPU Time Scaling
    
    For any two configurations with different MIPS values, generated DB2 CPU
    times (in Types 100, 101, 102) should scale inversely proportional to MIPS.
    
    Validates: Requirements 17.8, 18.8, 19.9
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    timestamp = start_date
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    
    # Generate records with two different MIPS configurations
    infrastructure1 = InfrastructureParameters({'mips': mips1})
    generator1 = SMF100RecordGenerator(catalog, distribution, infrastructure1)
    record1 = generator1.generate_statistics_record('DB2P', timestamp)
    
    infrastructure2 = InfrastructureParameters({'mips': mips2})
    generator2 = SMF100RecordGenerator(catalog, distribution, infrastructure2)
    record2 = generator2.generate_statistics_record('DB2P', timestamp)
    
    # For Type 100, we check SQL operation counts which scale with MIPS
    # Higher MIPS = more throughput = more operations
    sql_stats1 = record1['sql_statistics']
    sql_stats2 = record2['sql_statistics']
    
    # Calculate total operations for each configuration
    total_ops1 = (sql_stats1['select_count'] + sql_stats1['insert_count'] + 
                  sql_stats1['update_count'] + sql_stats1['delete_count'])
    total_ops2 = (sql_stats2['select_count'] + sql_stats2['insert_count'] + 
                  sql_stats2['update_count'] + sql_stats2['delete_count'])
    
    # Calculate expected scaling ratio
    expected_ratio = mips2 / mips1
    
    # Calculate actual ratio (with tolerance for randomness)
    if total_ops1 > 0:
        actual_ratio = total_ops2 / total_ops1
        
        # Allow 50% tolerance due to randomness in generation
        # The key is that higher MIPS should generally produce more operations
        assert actual_ratio > 0.5 * expected_ratio, (
            f"SQL operations should scale with MIPS. "
            f"Expected ratio ~{expected_ratio:.2f}, got {actual_ratio:.2f}"
        )
        assert actual_ratio < 2.0 * expected_ratio, (
            f"SQL operations should scale with MIPS. "
            f"Expected ratio ~{expected_ratio:.2f}, got {actual_ratio:.2f}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=30, max_value=365)
)
def test_property_51_db2_subsystem_id_consistency(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 51: DB2 Subsystem ID Consistency
    
    For any set of generated DB2 records (Types 100, 101, 102) within the same
    time window, all records should reference the same DB2 subsystem_id.
    
    Validates: Requirements 17.2, 18.2, 19.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF100RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate multiple records
    records = generator.generate_records()
    
    # Skip test if no records generated
    if len(records) == 0:
        pytest.skip("No records generated")
    
    # Extract all subsystem IDs
    subsystem_ids = [record['subsystem_id'] for record in records]
    
    # All subsystem IDs should be the same within a generation run
    unique_subsystem_ids = set(subsystem_ids)
    assert len(unique_subsystem_ids) == 1, (
        f"All Type 100 records should have the same subsystem_id. "
        f"Found: {unique_subsystem_ids}"
    )
    
    # Verify subsystem ID format (should be 3-4 characters, alphanumeric)
    subsystem_id = subsystem_ids[0]
    assert len(subsystem_id) >= 3 and len(subsystem_id) <= 4, (
        f"Subsystem ID should be 3-4 characters, got '{subsystem_id}'"
    )
    assert subsystem_id.isalnum(), (
        f"Subsystem ID should be alphanumeric, got '{subsystem_id}'"
    )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_30_unified_schema_compliance_type100(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 30: Unified Schema Compliance
    
    For any generated SMF record of any type, the record should include all
    fields required by the smf_records common table (record_type, subtype,
    system_id, record_date, record_time, record_timestamp).
    
    Validates: Requirements 11.2, 11.3
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF100RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check unified schema compliance for each record
    for record in records:
        # Check required common fields
        assert 'record_type' in record, "Missing required field: record_type"
        assert 'subtype' in record, "Missing required field: subtype"
        assert 'system_id' in record, "Missing required field: system_id"
        assert 'date' in record, "Missing required field: date (record_date)"
        assert 'timestamp' in record, "Missing required field: timestamp (record_time)"
        
        # Verify record_type is 100 for Type 100 records
        assert record['record_type'] == 100, (
            f"Expected record_type 100, got {record['record_type']}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_31_record_timestamp_format_type100(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 31: Record Timestamp Format
    
    For any generated SMF record, the record_timestamp field should match
    the format "YYYY-MM-DD HH:MM:SS".
    
    Validates: Requirements 11.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF100RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Pattern for "YYYY-MM-DD HH:MM:SS" format
    timestamp_pattern = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
    
    # Check timestamp format for each record
    for record in records:
        date = record.get('date')
        time = record.get('timestamp')
        
        # Check date format (YYYY-MM-DD)
        assert date is not None, "date field should not be None"
        date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        assert date_pattern.match(date), (
            f"date '{date}' does not match format YYYY-MM-DD"
        )
        
        # Check time format (HH:MM:SS)
        assert time is not None, "timestamp field should not be None"
        time_pattern = re.compile(r'^\d{2}:\d{2}:\d{2}$')
        assert time_pattern.match(time), (
            f"timestamp '{time}' does not match format HH:MM:SS"
        )
        
        # Construct full timestamp and verify format
        full_timestamp = f"{date} {time}"
        assert timestamp_pattern.match(full_timestamp), (
            f"Full timestamp '{full_timestamp}' does not match format YYYY-MM-DD HH:MM:SS"
        )
