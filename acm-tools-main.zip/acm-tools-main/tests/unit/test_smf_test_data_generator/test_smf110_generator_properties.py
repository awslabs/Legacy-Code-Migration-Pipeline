"""
Property-based tests for SMF Type 110 record generator.

Tests correctness properties for Type 110 record generation including schema
compliance, referential integrity, transaction-program mapping, and realistic
value bounds.
"""

import pytest
import re
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, assume, settings
from tools.smf_test_data_generator.smf110_generator import SMF110RecordGenerator
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters


# Helper function to create a test catalog
def create_test_catalog(
    cics_transactions=None,
    missing_cics_transactions=None
):
    """Create a test artifact catalog with specified CICS transactions."""
    if cics_transactions is None:
        cics_transactions = [
            {'transaction_id': 'CAUP', 'program_name': 'COACTUPC'},
            {'transaction_id': 'CMEN', 'program_name': 'COMENUC'},
            {'transaction_id': 'CBIL', 'program_name': 'COBILLC'}
        ]
    if missing_cics_transactions is None:
        missing_cics_transactions = []
    
    # Create catalog directly with mock data
    catalog = ArtifactCatalog.__new__(ArtifactCatalog)
    
    # Initialize storage structures
    catalog._active_programs = {'high': [], 'medium': [], 'low': []}
    catalog._active_jcl = {'high': [], 'medium': [], 'low': []}
    catalog._active_cics_transactions = {'high': [], 'medium': [], 'low': []}
    catalog._active_datasets = {'high': [], 'medium': [], 'low': []}
    
    catalog._unreferenced_programs = set()
    catalog._unreferenced_jcl = set()
    catalog._unreferenced_datasets = set()
    catalog._unreferenced_cics_transactions = set()
    
    catalog._missing_programs = set()
    catalog._missing_datasets = set()
    catalog._missing_cics_transactions = set(missing_cics_transactions)
    
    catalog._program_datasets = {}
    
    # Build CICS program mapping
    catalog._cics_program_mapping = {}
    for trans in cics_transactions:
        catalog._cics_program_mapping[trans['transaction_id']] = trans['program_name']
    
    # Add CICS transactions to high frequency
    catalog._active_cics_transactions['high'] = list(cics_transactions)
    
    # Add missing CICS transactions to high frequency
    for trans_id in missing_cics_transactions:
        catalog._active_cics_transactions['high'].append({
            'transaction_id': trans_id,
            'program_name': ''  # Missing transactions may not have program mapping
        })
    
    return catalog


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_4_type110_schema_compliance(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 4: Type 110 Schema Compliance
    
    For any generated Type 110 record, the record structure should match the
    smf110_schema definition with all required sections (subsystem, identification
    with performance data) present.
    
    Validates: Requirements 3.1, 3.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF110RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate a single record
    record = generator.generate_transaction_record(
        transaction_id='CAUP',
        program_name='COACTUPC',
        timestamp=start_date
    )
    
    # Check top-level required fields
    assert 'record_type' in record
    assert record['record_type'] == 110
    assert 'subtype' in record
    assert 'system_id' in record
    assert 'date' in record
    assert 'timestamp' in record
    assert 'record_length' in record
    
    # Check header section
    assert 'header' in record
    assert 'subsystem_id' in record['header']
    assert record['header']['subsystem_id'] == 'CICS'
    
    # Check all required sections are present
    required_sections = ['subsystem', 'identification']
    
    for section in required_sections:
        assert section in record, f"Missing required section: {section}"
        assert record[section] is not None, f"Section {section} is None"
    
    # Check subsystem section fields
    subsystem = record['subsystem']
    assert 'record_version' in subsystem
    assert 'product_name_generic' in subsystem
    assert 'product_name_specific' in subsystem
    assert 'data_class' in subsystem
    assert 'jobname' in subsystem
    assert 'job_date' in subsystem
    assert 'job_time' in subsystem
    assert 'user_id' in subsystem
    assert 'os_product_level' in subsystem
    assert 'data_record_count' in subsystem
    
    # Check identification section fields (performance data)
    ident = record['identification']
    assert 'type' in ident
    assert ident['type'] == 'performance'
    assert 'tran_name' in ident
    assert 'program_name' in ident
    assert 'user_id' in ident
    assert 'terminal_id' in ident
    assert 'start_time' in ident
    assert 'stop_time' in ident
    assert 'cpu_time' in ident
    assert 'response_time' in ident
    assert 'suspend_time' in ident
    assert 'external_wait_time' in ident


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_7_cics_transaction_referential_integrity(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 7: CICS Transaction Referential Integrity
    
    For any generated Type 110 record, the transaction ID should either exist
    in the inventory_cics table or be in the configured missing artifacts list.
    
    Validates: Requirements 3.3
    """
    # Create test setup with known transactions
    known_transactions = [
        {'transaction_id': 'CAUP', 'program_name': 'COACTUPC'},
        {'transaction_id': 'CMEN', 'program_name': 'COMENUC'},
        {'transaction_id': 'CBIL', 'program_name': 'COBILLC'}
    ]
    missing_transactions = ['MISS01', 'MISS02']
    
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog(
        cics_transactions=known_transactions,
        missing_cics_transactions=missing_transactions
    )
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF110RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Build set of all valid transaction IDs
    all_valid_transactions = set()
    for trans in known_transactions:
        all_valid_transactions.add(trans['transaction_id'])
    all_valid_transactions.update(missing_transactions)
    
    # Check each record's transaction ID
    for record in records:
        identification = record.get('identification', {})
        tran_name = identification.get('tran_name')
        
        assert tran_name is not None, "tran_name should not be None"
        assert tran_name in all_valid_transactions, (
            f"Transaction '{tran_name}' is not in known or missing transactions"
        )


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_8_cics_transaction_program_mapping(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 8: CICS Transaction-Program Mapping
    
    For any Type 110 record where the transaction ID exists in inventory_cics,
    the program name in the record should match the program_name associated
    with that transaction in the inventory.
    
    Validates: Requirements 3.5
    """
    # Create test setup with known transaction-program mappings
    known_transactions = [
        {'transaction_id': 'CAUP', 'program_name': 'COACTUPC'},
        {'transaction_id': 'CMEN', 'program_name': 'COMENUC'},
        {'transaction_id': 'CBIL', 'program_name': 'COBILLC'}
    ]
    
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog(cics_transactions=known_transactions)
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF110RecordGenerator(catalog, distribution, infrastructure)
    
    # Build mapping for validation
    transaction_program_map = {}
    for trans in known_transactions:
        transaction_program_map[trans['transaction_id']] = trans['program_name']
    
    # Generate records
    records = generator.generate_records()
    
    # Check each record's transaction-program mapping
    for record in records:
        identification = record.get('identification', {})
        tran_name = identification.get('tran_name')
        program_name = identification.get('program_name')
        
        # If transaction is in our known list, verify program mapping
        if tran_name in transaction_program_map:
            expected_program = transaction_program_map[tran_name]
            assert program_name == expected_program, (
                f"Transaction '{tran_name}' should map to program '{expected_program}', "
                f"but got '{program_name}'"
            )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_23_cics_cpu_time_bounds(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 23: CICS CPU Time Bounds
    
    For any Type 110 record, the cpu_time value (in microseconds) should be
    between 1000 (1ms) and 5000000 (5 seconds).
    
    Validates: Requirements 10.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF110RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check CPU time bounds for each record
    for record in records:
        identification = record.get('identification', {})
        cpu_time = identification.get('cpu_time')
        
        assert cpu_time is not None, "cpu_time should not be None"
        assert 1000 <= cpu_time <= 5000000, (
            f"cpu_time {cpu_time} is outside bounds [1000, 5000000] microseconds"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_25_cics_response_time_bounds(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 25: CICS Response Time Bounds
    
    For any Type 110 record, the response_time value (in microseconds) should
    be between 10000 (10ms) and 2000000 (2 seconds).
    
    Validates: Requirements 10.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF110RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check response time bounds for each record
    for record in records:
        identification = record.get('identification', {})
        response_time = identification.get('response_time')
        
        assert response_time is not None, "response_time should not be None"
        assert 10000 <= response_time <= 2000000, (
            f"response_time {response_time} is outside bounds [10000, 2000000] microseconds"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_30_unified_schema_compliance_type110(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 30: Unified Schema Compliance
    
    For any generated SMF record of any type, the record should include all
    fields required by the smf_records common table (record_type, subtype,
    system_id, record_date, record_time, record_timestamp).
    
    Validates: Requirements 11.2, 11.3
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF110RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check unified schema compliance for each record
    for record in records:
        # Check required common fields
        assert 'record_type' in record, "Missing required field: record_type"
        assert 'subtype' in record, "Missing required field: subtype"
        assert 'system_id' in record, "Missing required field: system_id"
        assert 'date' in record, "Missing required field: date (record_date)"
        assert 'timestamp' in record, "Missing required field: timestamp (record_time)"
        
        # Verify record_type is 110 for Type 110 records
        assert record['record_type'] == 110, (
            f"Expected record_type 110, got {record['record_type']}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_31_record_timestamp_format_type110(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 31: Record Timestamp Format
    
    For any generated SMF record, the record_timestamp field should match
    the format "YYYY-MM-DD HH:MM:SS".
    
    Validates: Requirements 11.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})  # Use defaults
    generator = SMF110RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Pattern for "YYYY-MM-DD HH:MM:SS" format
    timestamp_pattern = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
    
    # Check timestamp format for each record
    for record in records:
        date = record.get('date')
        time = record.get('timestamp')
        
        # Check date format (YYYY-MM-DD)
        assert date is not None, "date field should not be None"
        date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        assert date_pattern.match(date), (
            f"date '{date}' does not match format YYYY-MM-DD"
        )
        
        # Check time format (HH:MM:SS)
        assert time is not None, "timestamp field should not be None"
        time_pattern = re.compile(r'^\d{2}:\d{2}:\d{2}$')
        assert time_pattern.match(time), (
            f"timestamp '{time}' does not match format HH:MM:SS"
        )
        
        # Construct full timestamp and verify format
        full_timestamp = f"{date} {time}"
        assert timestamp_pattern.match(full_timestamp), (
            f"Full timestamp '{full_timestamp}' does not match format YYYY-MM-DD HH:MM:SS"
        )
