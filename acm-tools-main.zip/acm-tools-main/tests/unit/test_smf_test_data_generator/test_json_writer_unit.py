"""
Unit tests for JSON writer.

Tests specific file naming conventions and edge cases.
"""

import pytest
import json
import tempfile
import os
from pathlib import Path
from tools.smf_test_data_generator.json_writer import JSONWriter


class TestJSONWriterFileNaming:
    """Test file naming conventions for JSON writer."""
    
    def test_type30_file_naming_convention(self):
        """
        Test Type 30 file naming convention: smf30_{application_name}.json
        
        Validates: Requirements 8.1
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'carddemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 30, 'test': 'data'}]
            output_file = writer.write_type30_records(test_records)
            
            # Verify file name follows convention
            expected_filename = f'smf30_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            
            # Verify file is in correct directory
            assert os.path.dirname(output_file) == temp_dir
            
            # Verify file exists
            assert os.path.exists(output_file)
    
    def test_type110_file_naming_convention(self):
        """
        Test Type 110 file naming convention: smf110_{application_name}.json
        
        Validates: Requirements 8.2
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'carddemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 110, 'test': 'data'}]
            output_file = writer.write_type110_records(test_records)
            
            # Verify file name follows convention
            expected_filename = f'smf110_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            
            # Verify file is in correct directory
            assert os.path.dirname(output_file) == temp_dir
            
            # Verify file exists
            assert os.path.exists(output_file)
    
    def test_type14_file_naming_convention(self):
        """
        Test Type 14 file naming convention: smf14_{application_name}.json
        
        Validates: Requirements 8.1, 20.3
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'carddemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 14, 'test': 'data'}]
            output_file = writer.write_records(14, test_records)
            
            # Verify file name follows convention
            expected_filename = f'smf14_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            
            # Verify file is in correct directory
            assert os.path.dirname(output_file) == temp_dir
            
            # Verify file exists
            assert os.path.exists(output_file)
    
    def test_type15_file_naming_convention(self):
        """
        Test Type 15 file naming convention: smf15_{application_name}.json
        
        Validates: Requirements 8.2, 20.3
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'carddemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 15, 'test': 'data'}]
            output_file = writer.write_records(15, test_records)
            
            # Verify file name follows convention
            expected_filename = f'smf15_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            
            # Verify file is in correct directory
            assert os.path.dirname(output_file) == temp_dir
            
            # Verify file exists
            assert os.path.exists(output_file)
    
    def test_type17_file_naming_convention(self):
        """
        Test Type 17 file naming convention: smf17_{application_name}.json
        
        Validates: Requirements 8.1, 20.3
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'carddemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 17, 'test': 'data'}]
            output_file = writer.write_records(17, test_records)
            
            # Verify file name follows convention
            expected_filename = f'smf17_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            
            # Verify file is in correct directory
            assert os.path.dirname(output_file) == temp_dir
            
            # Verify file exists
            assert os.path.exists(output_file)
    
    def test_type62_file_naming_convention(self):
        """
        Test Type 62 file naming convention: smf62_{application_name}.json
        
        Validates: Requirements 8.2, 20.3
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'carddemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 62, 'test': 'data'}]
            output_file = writer.write_records(62, test_records)
            
            # Verify file name follows convention
            expected_filename = f'smf62_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            
            # Verify file is in correct directory
            assert os.path.dirname(output_file) == temp_dir
            
            # Verify file exists
            assert os.path.exists(output_file)
    
    def test_type64_file_naming_convention(self):
        """
        Test Type 64 file naming convention: smf64_{application_name}.json
        
        Validates: Requirements 8.1, 20.3
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'carddemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 64, 'test': 'data'}]
            output_file = writer.write_records(64, test_records)
            
            # Verify file name follows convention
            expected_filename = f'smf64_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            
            # Verify file is in correct directory
            assert os.path.dirname(output_file) == temp_dir
            
            # Verify file exists
            assert os.path.exists(output_file)
    
    def test_file_naming_with_special_characters(self):
        """Test file naming with application names containing special characters."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Test with underscores and hyphens
            app_name = 'card-demo_v2'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 30}]
            output_file = writer.write_type30_records(test_records)
            
            expected_filename = f'smf30_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
            assert os.path.exists(output_file)
    
    def test_file_naming_with_uppercase(self):
        """Test file naming preserves application name case."""
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'CardDemo'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 110}]
            output_file = writer.write_type110_records(test_records)
            
            # Case should be preserved
            expected_filename = f'smf110_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename
    
    def test_file_naming_with_numbers(self):
        """Test file naming with numeric application names."""
        with tempfile.TemporaryDirectory() as temp_dir:
            app_name = 'app123'
            writer = JSONWriter(temp_dir, app_name)
            
            test_records = [{'record_type': 30}]
            output_file = writer.write_type30_records(test_records)
            
            expected_filename = f'smf30_{app_name}.json'
            assert os.path.basename(output_file) == expected_filename


class TestJSONWriterEdgeCases:
    """Test edge cases for JSON writer."""
    
    def test_write_empty_record_list(self):
        """Test writing an empty list of records."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            output_file = writer.write_type30_records([])
            
            # File should exist
            assert os.path.exists(output_file)
            
            # Content should be empty array
            with open(output_file, 'r') as f:
                content = json.load(f)
                assert content == []
    
    def test_write_single_record(self):
        """Test writing a single record."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            test_record = {
                'record_type': 30,
                'system_id': 'SYS1',
                'date': '2023-06-15'
            }
            
            output_file = writer.write_type30_records([test_record])
            
            # Verify content
            with open(output_file, 'r') as f:
                content = json.load(f)
                assert len(content) == 1
                assert content[0] == test_record
    
    def test_write_multiple_records(self):
        """Test writing multiple records."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            test_records = [
                {'record_type': 110, 'id': 1},
                {'record_type': 110, 'id': 2},
                {'record_type': 110, 'id': 3}
            ]
            
            output_file = writer.write_type110_records(test_records)
            
            # Verify content
            with open(output_file, 'r') as f:
                content = json.load(f)
                assert len(content) == 3
                assert content == test_records
    
    def test_overwrite_existing_file(self):
        """Test that writing overwrites existing file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            # First write
            first_records = [{'id': 1}]
            writer.write_type30_records(first_records)
            
            # Second write
            second_records = [{'id': 2}, {'id': 3}]
            output_file = writer.write_type30_records(second_records)
            
            # Verify only second write is present
            with open(output_file, 'r') as f:
                content = json.load(f)
                assert len(content) == 2
                assert content == second_records
    
    def test_json_formatting(self):
        """Test that JSON is properly formatted with indentation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            test_records = [
                {
                    'record_type': 30,
                    'nested': {
                        'field1': 'value1',
                        'field2': 'value2'
                    }
                }
            ]
            
            output_file = writer.write_type30_records(test_records)
            
            # Read raw content
            with open(output_file, 'r') as f:
                content = f.read()
                
                # Should have newlines (formatted)
                assert '\n' in content
                
                # Should match indent=2 formatting
                expected = json.dumps(test_records, indent=2)
                assert content == expected
    
    def test_unicode_handling(self):
        """Test that Unicode characters are handled correctly."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            test_records = [
                {
                    'record_type': 30,
                    'description': 'Test with unicode: café, naïve, 日本語'
                }
            ]
            
            output_file = writer.write_type30_records(test_records)
            
            # Read and verify
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
                assert content[0]['description'] == 'Test with unicode: café, naïve, 日本語'


class TestJSONWriterDirectoryHandling:
    """Test directory creation and handling."""
    
    def test_create_simple_directory(self):
        """Test creating a simple output directory."""
        with tempfile.TemporaryDirectory() as temp_base:
            output_dir = os.path.join(temp_base, 'output')
            writer = JSONWriter(output_dir, 'testapp')
            
            writer.write_type30_records([{'test': 'data'}])
            
            assert os.path.exists(output_dir)
            assert os.path.isdir(output_dir)
    
    def test_create_nested_directories(self):
        """Test creating nested output directories."""
        with tempfile.TemporaryDirectory() as temp_base:
            output_dir = os.path.join(temp_base, 'level1', 'level2', 'level3')
            writer = JSONWriter(output_dir, 'testapp')
            
            writer.write_type110_records([{'test': 'data'}])
            
            assert os.path.exists(output_dir)
            assert os.path.isdir(output_dir)
    
    def test_use_existing_directory(self):
        """Test using an existing output directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Directory already exists
            writer = JSONWriter(temp_dir, 'testapp')
            
            # Should not raise error
            writer.write_type30_records([{'test': 'data'}])
            
            assert os.path.exists(temp_dir)
    
    def test_pathlib_path_support(self):
        """Test that Path objects are supported."""
        with tempfile.TemporaryDirectory() as temp_base:
            output_dir = Path(temp_base) / 'output'
            writer = JSONWriter(str(output_dir), 'testapp')
            
            writer.write_type30_records([{'test': 'data'}])
            
            assert output_dir.exists()
            assert output_dir.is_dir()


class TestJSONWriterReturnValues:
    """Test return values from write methods."""
    
    def test_write_type30_returns_filepath(self):
        """Test that write_type30_records returns the output file path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            output_file = writer.write_type30_records([{'test': 'data'}])
            
            # Should return a string path
            assert isinstance(output_file, str)
            
            # Path should exist
            assert os.path.exists(output_file)
            
            # Path should be absolute or relative to temp_dir
            assert 'smf30_testapp.json' in output_file
    
    def test_write_type110_returns_filepath(self):
        """Test that write_type110_records returns the output file path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            writer = JSONWriter(temp_dir, 'testapp')
            
            output_file = writer.write_type110_records([{'test': 'data'}])
            
            # Should return a string path
            assert isinstance(output_file, str)
            
            # Path should exist
            assert os.path.exists(output_file)
            
            # Path should be absolute or relative to temp_dir
            assert 'smf110_testapp.json' in output_file
