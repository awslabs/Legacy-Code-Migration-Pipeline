"""
Property-based tests for infrastructure parameters.

Tests correctness properties for infrastructure parameter scaling and metric generation.
"""

import pytest
from hypothesis import given, strategies as st, assume, settings
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters


# Strategies for generating infrastructure configurations
@st.composite
def infrastructure_config(draw):
    """Generate a valid infrastructure configuration dictionary."""
    return {
        'mips': draw(st.integers(min_value=100, max_value=10000)),
        'storage_gb': draw(st.integers(min_value=100, max_value=10000)),
        'iops': draw(st.integers(min_value=1000, max_value=500000)),
        'network_mbps': draw(st.integers(min_value=100, max_value=100000))
    }


@st.composite
def partial_infrastructure_config(draw):
    """Generate a partial infrastructure configuration (some keys missing)."""
    config = {}
    
    # Randomly include each parameter
    if draw(st.booleans()):
        config['mips'] = draw(st.integers(min_value=100, max_value=10000))
    if draw(st.booleans()):
        config['storage_gb'] = draw(st.integers(min_value=100, max_value=10000))
    if draw(st.booleans()):
        config['iops'] = draw(st.integers(min_value=1000, max_value=500000))
    if draw(st.booleans()):
        config['network_mbps'] = draw(st.integers(min_value=100, max_value=100000))
    
    return config


# Property 40: Infrastructure Parameters Defaults
@given(config=partial_infrastructure_config())
@settings(max_examples=100)
def test_property_40_infrastructure_defaults(config):
    """
    Feature: smf-test-data-generator, Property 40: Infrastructure Parameters Defaults
    
    For any configuration without infrastructure parameters specified,
    the generator should use default values (MIPS=1000, storage_gb=500,
    iops=50000, network_mbps=10000).
    
    Validates: Requirements 18.6
    """
    params = InfrastructureParameters(config)
    
    # Check that missing parameters use defaults
    if 'mips' not in config:
        assert params.mips == 1000, "Default MIPS should be 1000"
    else:
        assert params.mips == config['mips'], "Configured MIPS should be used"
    
    if 'storage_gb' not in config:
        assert params.storage_gb == 500, "Default storage_gb should be 500"
    else:
        assert params.storage_gb == config['storage_gb'], "Configured storage_gb should be used"
    
    if 'iops' not in config:
        assert params.iops == 50000, "Default IOPS should be 50000"
    else:
        assert params.iops == config['iops'], "Configured IOPS should be used"
    
    if 'network_mbps' not in config:
        assert params.network_mbps == 10000, "Default network_mbps should be 10000"
    else:
        assert params.network_mbps == config['network_mbps'], "Configured network_mbps should be used"


# Property 41: CPU Time Scaling
@given(
    mips1=st.integers(min_value=100, max_value=5000),
    mips2=st.integers(min_value=100, max_value=5000),
    base_time_ms=st.floats(min_value=1.0, max_value=10000.0)
)
@settings(max_examples=100)
def test_property_41_cpu_time_scaling(mips1, mips2, base_time_ms):
    """
    Feature: smf-test-data-generator, Property 41: CPU Time Scaling
    
    For any two configurations with different MIPS values, generated CPU times
    should scale inversely proportional to MIPS (higher MIPS = lower CPU times
    for same workload).
    
    Validates: Requirements 19.1
    """
    # Skip if MIPS values are the same
    assume(mips1 != mips2)
    
    # Create two infrastructure configurations with different MIPS
    config1 = {'mips': mips1}
    config2 = {'mips': mips2}
    
    params1 = InfrastructureParameters(config1)
    params2 = InfrastructureParameters(config2)
    
    # Scale the same base time with both configurations
    scaled_time1 = params1.scale_cpu_time(base_time_ms)
    scaled_time2 = params2.scale_cpu_time(base_time_ms)
    
    # Verify inverse proportionality: higher MIPS should give lower CPU time
    if mips1 > mips2:
        # params1 has higher MIPS, so should have lower (or equal) CPU time
        assert scaled_time1 <= scaled_time2, \
            f"Higher MIPS ({mips1}) should result in lower CPU time than lower MIPS ({mips2})"
    else:
        # params2 has higher MIPS, so should have lower (or equal) CPU time
        assert scaled_time2 <= scaled_time1, \
            f"Higher MIPS ({mips2}) should result in lower CPU time than lower MIPS ({mips1})"
    
    # Verify the scaling ratio is approximately inverse to MIPS ratio
    # Allow for rounding errors in integer conversion
    mips_ratio = mips1 / mips2
    time_ratio = scaled_time1 / scaled_time2 if scaled_time2 > 0 else float('inf')
    
    # The time ratio should be approximately the inverse of the MIPS ratio
    # Allow 10% tolerance for rounding errors
    expected_time_ratio = 1.0 / mips_ratio
    if scaled_time2 > 0 and scaled_time1 > 0:
        tolerance = 0.1
        assert abs(time_ratio - expected_time_ratio) / expected_time_ratio <= tolerance, \
            f"Time scaling ratio ({time_ratio:.3f}) should be approximately inverse of MIPS ratio ({mips_ratio:.3f})"


# Property 42: I/O Count Scaling
@given(
    iops1=st.integers(min_value=1000, max_value=500000),
    iops2=st.integers(min_value=1000, max_value=500000),
    base_count=st.integers(min_value=100, max_value=100000)
)
@settings(max_examples=100)
def test_property_42_io_count_scaling(iops1, iops2, base_count):
    """
    Feature: smf-test-data-generator, Property 42: I/O Count Scaling
    
    For any two configurations with different IOPS values, generated I/O counts
    should scale proportionally to IOPS capacity.
    
    Validates: Requirements 19.3
    """
    # Skip if IOPS values are the same
    assume(iops1 != iops2)
    
    # Create two infrastructure configurations with different IOPS
    config1 = {'iops': iops1}
    config2 = {'iops': iops2}
    
    params1 = InfrastructureParameters(config1)
    params2 = InfrastructureParameters(config2)
    
    # Scale the same base count with both configurations
    scaled_count1 = params1.scale_io_count(base_count)
    scaled_count2 = params2.scale_io_count(base_count)
    
    # Verify proportionality: higher IOPS should give higher I/O count
    if iops1 > iops2:
        # params1 has higher IOPS, so should have higher (or equal) I/O count
        assert scaled_count1 >= scaled_count2, \
            f"Higher IOPS ({iops1}) should result in higher I/O count than lower IOPS ({iops2})"
    else:
        # params2 has higher IOPS, so should have higher (or equal) I/O count
        assert scaled_count2 >= scaled_count1, \
            f"Higher IOPS ({iops2}) should result in higher I/O count than lower IOPS ({iops1})"
    
    # Verify the scaling ratio is approximately proportional to IOPS ratio
    # Allow for rounding errors in integer conversion
    iops_ratio = iops1 / iops2
    count_ratio = scaled_count1 / scaled_count2 if scaled_count2 > 0 else float('inf')
    
    # The count ratio should be approximately equal to the IOPS ratio
    # Allow 10% tolerance for rounding errors
    if scaled_count2 > 0 and scaled_count1 > 0:
        tolerance = 0.1
        assert abs(count_ratio - iops_ratio) / iops_ratio <= tolerance, \
            f"I/O count scaling ratio ({count_ratio:.3f}) should be approximately equal to IOPS ratio ({iops_ratio:.3f})"


# Property 43: Storage Usage Bounds
@given(
    config=infrastructure_config(),
    artifact_type=st.sampled_from(['program', 'dataset', 'vsam', 'temp', 'default'])
)
@settings(max_examples=100)
def test_property_43_storage_usage_bounds(config, artifact_type):
    """
    Feature: smf-test-data-generator, Property 43: Storage Usage Bounds
    
    For any generated record with storage metrics, the storage usage values
    should not exceed the configured storage_gb capacity.
    
    Validates: Requirements 19.2
    """
    params = InfrastructureParameters(config)
    
    # Get storage usage for the artifact type
    storage_bytes = params.get_storage_usage(artifact_type)
    
    # Convert storage_gb to bytes
    max_storage_bytes = config['storage_gb'] * 1024 * 1024 * 1024
    
    # Verify storage usage is within bounds
    assert storage_bytes > 0, "Storage usage should be positive"
    assert storage_bytes <= max_storage_bytes, \
        f"Storage usage ({storage_bytes} bytes) should not exceed capacity ({max_storage_bytes} bytes)"
    
    # Verify storage usage is reasonable (not more than 10% of total capacity)
    max_single_artifact = max_storage_bytes * 0.1
    assert storage_bytes <= max_single_artifact, \
        f"Single artifact storage ({storage_bytes} bytes) should not exceed 10% of capacity ({max_single_artifact} bytes)"


# Additional test: Verify network transfer time calculation
@given(
    config=infrastructure_config(),
    data_size_mb=st.floats(min_value=0.1, max_value=1000.0)
)
@settings(max_examples=100)
def test_network_transfer_time_calculation(config, data_size_mb):
    """
    Test that network transfer time is calculated correctly based on throughput.
    
    This is not a numbered property but validates the network_mbps parameter usage.
    """
    params = InfrastructureParameters(config)
    
    # Get network transfer time
    transfer_time_ms = params.get_network_transfer_time(data_size_mb)
    
    # Verify transfer time is positive
    assert transfer_time_ms > 0, "Transfer time should be positive"
    
    # Calculate expected minimum time (without overhead)
    data_size_mb_bits = data_size_mb * 8
    min_transfer_time_ms = (data_size_mb_bits / config['network_mbps']) * 1000
    
    # Verify actual time is at least the minimum (accounting for overhead)
    assert transfer_time_ms >= min_transfer_time_ms, \
        f"Transfer time ({transfer_time_ms} ms) should be at least minimum time ({min_transfer_time_ms} ms)"
    
    # Verify overhead is reasonable (should be between 10-20% as per implementation)
    max_transfer_time_ms = min_transfer_time_ms * 1.3  # Allow 30% for tolerance
    assert transfer_time_ms <= max_transfer_time_ms, \
        f"Transfer time ({transfer_time_ms} ms) should not exceed reasonable overhead ({max_transfer_time_ms} ms)"
