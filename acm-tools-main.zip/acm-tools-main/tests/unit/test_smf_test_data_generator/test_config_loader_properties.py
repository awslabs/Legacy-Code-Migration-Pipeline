"""
Property-based tests for configuration loader.

Tests correctness properties for YAML configuration parsing and validation.
"""

import pytest
import yaml
import tempfile
import os
from pathlib import Path
from datetime import datetime
from hypothesis import given, strategies as st, assume, settings
from tools.smf_test_data_generator.config_loader import GeneratorConfig


# Strategy for generating valid YAML configuration
@st.composite
def valid_config_dict(draw):
    """Generate a valid configuration dictionary."""
    # Generate dates
    start_year = draw(st.integers(min_value=2020, max_value=2024))
    start_month = draw(st.integers(min_value=1, max_value=12))
    start_day = draw(st.integers(min_value=1, max_value=28))  # Safe for all months
    
    end_year = draw(st.integers(min_value=start_year, max_value=2025))
    end_month = draw(st.integers(min_value=1, max_value=12))
    end_day = draw(st.integers(min_value=1, max_value=28))
    
    start_date = f"{start_year:04d}-{start_month:02d}-{start_day:02d}"
    end_date = f"{end_year:04d}-{end_month:02d}-{end_day:02d}"
    
    # Ensure end date is after start date
    if datetime.strptime(end_date, '%Y-%m-%d') <= datetime.strptime(start_date, '%Y-%m-%d'):
        end_year = start_year + 1
        end_date = f"{end_year:04d}-{end_month:02d}-{end_day:02d}"
    
    # Generate artifact names
    num_programs = draw(st.integers(min_value=0, max_value=5))
    num_jcl = draw(st.integers(min_value=0, max_value=5))
    num_cics = draw(st.integers(min_value=0, max_value=5))
    
    programs = []
    for _ in range(num_programs):
        name = draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=8))
        frequency = draw(st.sampled_from(['high', 'medium', 'low']))
        programs.append({'name': name, 'frequency': frequency})
    
    jcl = []
    for _ in range(num_jcl):
        name = draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=8))
        frequency = draw(st.sampled_from(['high', 'medium', 'low']))
        jcl.append({'name': name, 'frequency': frequency})
    
    cics = []
    for _ in range(num_cics):
        name = draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=4))
        frequency = draw(st.sampled_from(['high', 'medium', 'low']))
        cics.append({'name': name, 'frequency': frequency})
    
    # Generate generation_mode
    generation_mode = draw(st.sampled_from(['inventory', 'source-code']))
    
    # Generate record_types (optional)
    include_record_types = draw(st.booleans())
    record_types = None
    if include_record_types:
        # Select a subset of valid record types
        num_types = draw(st.integers(min_value=1, max_value=7))
        record_types = draw(st.lists(
            st.sampled_from([30, 110, 14, 15, 17, 62, 64]),
            min_size=num_types,
            max_size=num_types,
            unique=True
        ))
    
    # Generate infrastructure (optional)
    include_infrastructure = draw(st.booleans())
    infrastructure = None
    if include_infrastructure:
        infrastructure = {
            'mips': draw(st.integers(min_value=100, max_value=10000)),
            'storage_gb': draw(st.integers(min_value=100, max_value=5000)),
            'iops': draw(st.integers(min_value=1000, max_value=100000)),
            'network_mbps': draw(st.integers(min_value=100, max_value=100000))
        }
    
    config = {
        'generation_mode': generation_mode,
        'database_path': draw(st.text(min_size=1, max_size=100)),
        'inventory_db': draw(st.text(min_size=1, max_size=100)),
        'output_directory': draw(st.text(min_size=1, max_size=100)),
        'application_name': draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd')), min_size=1, max_size=20)),
        'time_range': {
            'start_date': start_date,
            'end_date': end_date
        },
        'active_artifacts': {}
    }
    
    if record_types is not None:
        config['record_types'] = record_types
    
    if infrastructure is not None:
        config['infrastructure'] = infrastructure
    
    if programs:
        config['active_artifacts']['programs'] = programs
    if jcl:
        config['active_artifacts']['jcl'] = jcl
    if cics:
        config['active_artifacts']['cics_transactions'] = cics
    
    return config


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(config_dict=valid_config_dict())
def test_property_19_configuration_parsing_completeness(config_dict):
    """
    Feature: smf-test-data-generator, Property 19: Configuration Parsing Completeness
    
    For any valid YAML configuration file, the generator should successfully extract
    all required parameters: generation_mode, database_path, output_directory, 
    application_name, time_range, record_types, infrastructure, active_artifacts, 
    unreferenced_artifacts, and missing_artifacts.
    
    Validates: Requirements 9.2, 9.4
    """
    # Create temporary YAML file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        # Load configuration
        config = GeneratorConfig(temp_path)
        
        # Verify all required fields are accessible
        assert config.generation_mode == config_dict['generation_mode']
        assert config.database_path == config_dict['database_path']
        assert config.inventory_db_path == config_dict['inventory_db']
        assert config.output_directory == config_dict['output_directory']
        assert config.application_name == config_dict['application_name']
        
        # Verify time range parsing
        expected_start = datetime.strptime(config_dict['time_range']['start_date'], '%Y-%m-%d')
        expected_end = datetime.strptime(config_dict['time_range']['end_date'], '%Y-%m-%d')
        assert config.start_date == expected_start
        assert config.end_date == expected_end
        
        # Verify record_types (should default to [30, 110] if not specified)
        record_types = config.record_types
        if 'record_types' in config_dict:
            assert record_types == config_dict['record_types']
        else:
            assert record_types == [30, 110]
        
        # Verify infrastructure (should return empty dict if not specified)
        infrastructure = config.infrastructure
        if 'infrastructure' in config_dict:
            assert infrastructure == config_dict['infrastructure']
        else:
            assert infrastructure == {}
        
        # Verify active artifacts
        active_artifacts = config.active_artifacts
        assert isinstance(active_artifacts, dict)
        
        # Check that all artifact types from config are present
        if 'programs' in config_dict.get('active_artifacts', {}):
            assert 'programs' in active_artifacts
            assert len(active_artifacts['programs']) == len(config_dict['active_artifacts']['programs'])
            for i, artifact in enumerate(active_artifacts['programs']):
                assert artifact['name'] == config_dict['active_artifacts']['programs'][i]['name']
                assert artifact['frequency'] == config_dict['active_artifacts']['programs'][i]['frequency']
        
        if 'jcl' in config_dict.get('active_artifacts', {}):
            assert 'jcl' in active_artifacts
            assert len(active_artifacts['jcl']) == len(config_dict['active_artifacts']['jcl'])
        
        if 'cics_transactions' in config_dict.get('active_artifacts', {}):
            assert 'cics_transactions' in active_artifacts
            assert len(active_artifacts['cics_transactions']) == len(config_dict['active_artifacts']['cics_transactions'])
        
        # Verify unreferenced and missing artifacts (should be empty or present)
        unreferenced = config.unreferenced_artifacts
        assert isinstance(unreferenced, dict)
        
        missing = config.missing_artifacts
        assert isinstance(missing, dict)
        
    finally:
        # Clean up temporary file
        os.unlink(temp_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    inventory_db=st.text(min_size=1, max_size=100),
    output_dir=st.text(min_size=1, max_size=100),
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd')), min_size=1, max_size=20),
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    days_duration=st.integers(min_value=1, max_value=365)
)
def test_property_19_all_required_fields_extracted(
    inventory_db, output_dir, app_name, start_year, start_month, start_day, days_duration
):
    """
    Feature: smf-test-data-generator, Property 19: Configuration Parsing Completeness
    
    Verify that all required configuration fields can be extracted from any valid YAML.
    
    Validates: Requirements 9.2, 9.4
    """
    from datetime import timedelta
    
    # Create valid dates
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=days_duration)
    
    config_dict = {
        'inventory_db': inventory_db,
        'output_directory': output_dir,
        'application_name': app_name,
        'time_range': {
            'start_date': start_date.strftime('%Y-%m-%d'),
            'end_date': end_date.strftime('%Y-%m-%d')
        }
    }
    
    # Create temporary YAML file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        
        # All required fields should be extractable
        assert config.inventory_db_path == inventory_db
        assert config.output_directory == output_dir
        assert config.application_name == app_name
        assert config.start_date == start_date
        assert config.end_date == end_date
        
        # Optional fields should return empty dicts if not present
        assert isinstance(config.active_artifacts, dict)
        assert isinstance(config.unreferenced_artifacts, dict)
        assert isinstance(config.missing_artifacts, dict)
        
    finally:
        os.unlink(temp_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    missing_field=st.sampled_from(['inventory_db', 'output_directory', 'application_name', 'time_range'])
)
def test_property_19_missing_required_field_raises_error(missing_field):
    """
    Feature: smf-test-data-generator, Property 19: Configuration Parsing Completeness
    
    When a required field is missing, accessing it should raise an appropriate error.
    
    Validates: Requirements 9.2, 9.4
    """
    config_dict = {
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        }
    }
    
    # Remove the specified field
    if missing_field == 'time_range':
        del config_dict['time_range']
    else:
        del config_dict[missing_field]
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        
        # Accessing the missing field should raise KeyError
        with pytest.raises(KeyError):
            if missing_field == 'inventory_db':
                _ = config.inventory_db_path
            elif missing_field == 'output_directory':
                _ = config.output_directory
            elif missing_field == 'application_name':
                _ = config.application_name
            elif missing_field == 'time_range':
                _ = config.start_date
        
    finally:
        os.unlink(temp_path)



@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    invalid_yaml=st.sampled_from([
        'invalid: yaml: syntax: [',
        '{invalid yaml',
        'key: [unclosed list',
        'key: {unclosed dict',
        '  : no key before colon',
        'key: value\n  : another no key',
    ])
)
def test_property_21_invalid_yaml_error_handling(invalid_yaml):
    """
    Feature: smf-test-data-generator, Property 21: Invalid YAML Error Handling
    
    For any invalid YAML configuration file, the generator should return a
    descriptive error message indicating the YAML parsing failure.
    
    Validates: Requirements 9.3
    """
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write(invalid_yaml)
        temp_path = f.name
    
    try:
        # Loading invalid YAML should raise YAMLError
        with pytest.raises(yaml.YAMLError) as exc_info:
            GeneratorConfig(temp_path)
        
        # Error message should be descriptive
        error_msg = str(exc_info.value)
        assert 'Invalid YAML configuration' in error_msg or 'YAML' in error_msg
        
    finally:
        os.unlink(temp_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    start_month=st.integers(min_value=1, max_value=12),
    start_day=st.integers(min_value=1, max_value=28),
    end_offset_days=st.integers(min_value=-365, max_value=-1)  # Negative offset = end before start
)
def test_property_21_date_range_validation(start_year, start_month, start_day, end_offset_days):
    """
    Feature: smf-test-data-generator, Property 21: Invalid YAML Error Handling
    
    When end date is before or equal to start date, validation should fail with
    a descriptive error message.
    
    Validates: Requirements 9.3
    """
    from datetime import timedelta
    
    start_date = datetime(start_year, start_month, start_day)
    end_date = start_date + timedelta(days=end_offset_days)
    
    config_dict = {
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': start_date.strftime('%Y-%m-%d'),
            'end_date': end_date.strftime('%Y-%m-%d')
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        
        # Should have at least one error about date range
        assert len(errors) > 0
        assert any('End date must be after start date' in error for error in errors)
        
    finally:
        os.unlink(temp_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    invalid_frequency=st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd')),
        min_size=1,
        max_size=20
    ).filter(lambda x: x not in ['high', 'medium', 'low'])
)
def test_property_21_frequency_validation(invalid_frequency):
    """
    Feature: smf-test-data-generator, Property 21: Invalid YAML Error Handling
    
    When an invalid frequency level is specified, validation should fail with
    a descriptive error message.
    
    Validates: Requirements 9.3
    """
    config_dict = {
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        },
        'active_artifacts': {
            'programs': [
                {'name': 'PROG1', 'frequency': invalid_frequency}
            ]
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        
        # Should have at least one error about invalid frequency
        assert len(errors) > 0
        assert any('Invalid frequency level' in error for error in errors)
        assert any('must be \'high\', \'medium\', or \'low\'' in error for error in errors)
        
    finally:
        os.unlink(temp_path)


@pytest.mark.property
@settings(max_examples=30, deadline=None)
@given(
    date_format=st.sampled_from([
        '01/01/2023',      # MM/DD/YYYY
        '2023.01.01',      # YYYY.MM.DD
        '01-01-2023',      # MM-DD-YYYY
        '2023/01/01',      # YYYY/MM/DD
        '20230101',        # YYYYMMDD
        'Jan 1, 2023',     # Month name
        '1st January 2023' # Written format
    ])
)
def test_property_21_date_format_validation(date_format):
    """
    Feature: smf-test-data-generator, Property 21: Invalid YAML Error Handling
    
    When an invalid date format is used, validation should fail with a
    descriptive error message indicating the expected format.
    
    Validates: Requirements 9.3
    """
    config_dict = {
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': date_format,
            'end_date': '2023-12-31'
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        
        # Should have at least one error about invalid date format
        assert len(errors) > 0
        assert any('Invalid date format' in error for error in errors)
        assert any('expected YYYY-MM-DD' in error for error in errors)
        
    finally:
        os.unlink(temp_path)



@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    generation_mode=st.sampled_from(['inventory', 'source-code']),
    database_path=st.text(min_size=1, max_size=100),
    output_dir=st.text(min_size=1, max_size=100),
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd')), min_size=1, max_size=20)
)
def test_property_40_infrastructure_parameters_defaults(generation_mode, database_path, output_dir, app_name):
    """
    Feature: smf-test-data-generator, Property 40: Infrastructure Parameters Defaults
    
    For any configuration without infrastructure parameters specified, the generator
    should use default values (MIPS=1000, storage_gb=500, iops=50000, network_mbps=10000).
    
    Validates: Requirements 18.6
    """
    config_dict = {
        'generation_mode': generation_mode,
        'database_path': database_path,
        'output_directory': output_dir,
        'application_name': app_name,
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        }
        # Note: infrastructure is intentionally omitted
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        
        # Infrastructure should return empty dict when not specified
        infrastructure = config.infrastructure
        assert isinstance(infrastructure, dict)
        assert infrastructure == {}
        
        # The InfrastructureConfig class should apply defaults when created
        # This is tested in the infrastructure_parameters module
        
    finally:
        os.unlink(temp_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    invalid_mode=st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'Pd')),
        min_size=1,
        max_size=20
    ).filter(lambda x: x not in ['inventory', 'source-code'])
)
def test_property_21_generation_mode_validation(invalid_mode):
    """
    Feature: smf-test-data-generator, Property 21: Invalid YAML Error Handling
    
    When an invalid generation_mode is specified, validation should fail with
    a descriptive error message.
    
    Validates: Requirements 9.3, 17.1
    """
    config_dict = {
        'generation_mode': invalid_mode,
        'database_path': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        
        # Should have at least one error about invalid generation_mode
        assert len(errors) > 0
        assert any('Invalid generation_mode' in error for error in errors)
        assert any('must be \'inventory\' or \'source-code\'' in error for error in errors)
        
    finally:
        os.unlink(temp_path)


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    invalid_record_type=st.integers(min_value=1, max_value=200).filter(
        lambda x: x not in [30, 110, 14, 15, 17, 62, 64]
    )
)
def test_property_21_record_types_validation(invalid_record_type):
    """
    Feature: smf-test-data-generator, Property 21: Invalid YAML Error Handling
    
    When an invalid record type is specified, validation should fail with
    a descriptive error message.
    
    Validates: Requirements 9.3, 20.2
    """
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        },
        'record_types': [30, invalid_record_type]
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        
        # Should have at least one error about invalid record type
        assert len(errors) > 0
        assert any(f'Invalid record type {invalid_record_type}' in error for error in errors)
        
    finally:
        os.unlink(temp_path)
