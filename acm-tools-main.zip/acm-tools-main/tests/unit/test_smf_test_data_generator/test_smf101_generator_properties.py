"""
Property-based tests for SMF Type 101 record generator.

Tests correctness properties for Type 101 record generation including schema
compliance, DB2 CPU time scaling, DB2 subsystem ID consistency, and unified
schema compliance.
"""

import pytest
import re
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, settings
from tools.smf_test_data_generator.smf101_generator import SMF101RecordGenerator
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters


# Helper function to create a test catalog
def create_test_catalog(
    programs=None,
    jcl_jobs=None,
    datasets=None
):
    """Create a test artifact catalog with specified artifacts."""
    if programs is None:
        programs = ['PROG01', 'PROG02', 'PROG03']
    if jcl_jobs is None:
        jcl_jobs = ['JOB01', 'JOB02']
    if datasets is None:
        datasets = ['DATA.SET.ONE', 'DATA.SET.TWO']
    
    # Create catalog directly with mock data
    catalog = ArtifactCatalog.__new__(ArtifactCatalog)
    
    # Initialize storage structures
    catalog._active_programs = {'high': [], 'medium': [], 'low': []}
    catalog._active_jcl = {'high': [], 'medium': [], 'low': []}
    catalog._active_cics_transactions = {'high': [], 'medium': [], 'low': []}
    catalog._active_datasets = {'high': [], 'medium': [], 'low': []}
    
    catalog._unreferenced_programs = set()
    catalog._unreferenced_jcl = set()
    catalog._unreferenced_datasets = set()
    catalog._unreferenced_cics_transactions = set()
    
    catalog._missing_programs = set()
    catalog._missing_datasets = set()
    catalog._missing_cics_transactions = set()
    
    catalog._cics_program_mapping = {}
    catalog._program_datasets = {}
    
    # Add programs to high frequency
    catalog._active_programs['high'] = list(programs)
    
    # Add JCL jobs to high frequency
    catalog._active_jcl['high'] = list(jcl_jobs)
    
    # Add datasets to high frequency
    catalog._active_datasets['high'] = list(datasets)
    
    return catalog


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365),
    mips=st.integers(min_value=500, max_value=5000)
)
def test_property_48_type101_schema_compliance(start_year, duration_days, mips):
    """
    Feature: smf-test-data-generator, Property 48: Type 101 Schema Compliance
    
    For any generated Type 101 record, the record structure should match the
    unified schema definition with accounting section, correlation information,
    SQL statistics, and buffer manager statistics.
    
    Validates: Requirements 18.1, 18.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    begin_timestamp = start_date
    end_timestamp = begin_timestamp + timedelta(seconds=60)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({'mips': mips})
    generator = SMF101RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate a single record
    record = generator.generate_accounting_record(
        authorization_id='USER01',
        plan_name='TESTPLAN',
        connection_name='CONN01',
        begin_timestamp=begin_timestamp,
        end_timestamp=end_timestamp,
        is_rollup=False
    )
    
    # Check top-level required fields
    assert 'record_type' in record
    assert record['record_type'] == 101
    assert 'subtype' in record
    assert 'system_id' in record
    assert 'date' in record
    assert 'timestamp' in record
    assert 'record_length' in record
    
    # Check accounting section is present
    assert 'accounting' in record, "Missing required section: accounting"
    assert record['accounting'] is not None, "Section accounting is None"
    
    # Check accounting section fields
    acct = record['accounting']
    assert 'begin_store_clock' in acct
    assert 'end_store_clock' in acct
    assert 'begin_cpu_time' in acct
    assert 'end_cpu_time' in acct
    assert 'accumulated_cpu_in_db2' in acct
    assert 'accumulated_elapsed_in_db2' in acct
    assert 'accumulated_wait_io' in acct
    assert 'accumulated_wait_lock' in acct
    assert 'commit_count' in acct
    assert 'abort_count' in acct
    assert 'db2_entry_exit_count' in acct
    assert 'is_rollup' in acct
    assert 'class2_active' in acct
    assert 'class3_active' in acct
    assert 'package_count' in acct
    assert 'reason_invoked' in acct
    assert 'flags' in acct
    
    # Verify accounting section values are non-negative
    assert acct['accumulated_cpu_in_db2'] >= 0
    assert acct['accumulated_elapsed_in_db2'] >= 0
    assert acct['accumulated_wait_io'] >= 0
    assert acct['accumulated_wait_lock'] >= 0
    assert acct['commit_count'] >= 0
    assert acct['abort_count'] >= 0
    assert acct['db2_entry_exit_count'] >= 0
    assert acct['package_count'] >= 0
    
    # Verify is_rollup is 0 or 1
    assert acct['is_rollup'] in [0, 1]
    
    # Check correlation section is present
    assert 'correlation' in record, "Missing required section: correlation"
    assert record['correlation'] is not None, "Section correlation is None"
    
    # Check correlation section fields
    corr = record['correlation']
    assert 'authorization_id' in corr
    assert 'correlation_id' in corr
    assert 'connection_name' in corr
    assert 'plan_name' in corr
    assert 'connection_type' in corr
    
    # Verify correlation section values are not empty
    assert corr['authorization_id'], "authorization_id should not be empty"
    assert corr['correlation_id'], "correlation_id should not be empty"
    assert corr['connection_name'], "connection_name should not be empty"
    assert corr['plan_name'], "plan_name should not be empty"
    assert corr['connection_type'] >= 1 and corr['connection_type'] <= 4
    
    # Check SQL statistics section is present
    assert 'sql_statistics' in record, "Missing required section: sql_statistics"
    assert record['sql_statistics'] is not None, "Section sql_statistics is None"
    
    # Check SQL statistics fields
    sql_stats = record['sql_statistics']
    assert 'select_count' in sql_stats
    assert 'insert_count' in sql_stats
    assert 'update_count' in sql_stats
    assert 'delete_count' in sql_stats
    assert 'describe_count' in sql_stats
    assert 'prepare_count' in sql_stats
    assert 'open_count' in sql_stats
    assert 'close_count' in sql_stats
    assert 'fetch_count' in sql_stats
    
    # Verify SQL statistics are non-negative
    assert sql_stats['select_count'] >= 0
    assert sql_stats['insert_count'] >= 0
    assert sql_stats['update_count'] >= 0
    assert sql_stats['delete_count'] >= 0
    assert sql_stats['describe_count'] >= 0
    assert sql_stats['prepare_count'] >= 0
    assert sql_stats['open_count'] >= 0
    assert sql_stats['close_count'] >= 0
    assert sql_stats['fetch_count'] >= 0
    
    # Check buffer manager statistics section is present
    assert 'buffer_manager' in record, "Missing required section: buffer_manager"
    assert record['buffer_manager'] is not None, "Section buffer_manager is None"
    assert isinstance(record['buffer_manager'], list), "buffer_manager should be a list"
    assert len(record['buffer_manager']) > 0, "buffer_manager should have at least one entry"
    
    # Check buffer manager statistics fields
    for bm in record['buffer_manager']:
        assert 'buffer_pool_id' in bm
        assert 'getpage_requests' in bm
        assert 'sync_read_io' in bm
        assert 'seq_prefetch_requests' in bm
        assert 'list_prefetch_requests' in bm
        assert 'dynamic_prefetch_requests' in bm
        
        # Verify buffer manager statistics are non-negative
        assert bm['buffer_pool_id'] >= 0
        assert bm['getpage_requests'] >= 0
        assert bm['sync_read_io'] >= 0
        assert bm['seq_prefetch_requests'] >= 0
        assert bm['list_prefetch_requests'] >= 0
        assert bm['dynamic_prefetch_requests'] >= 0


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365),
    mips1=st.integers(min_value=500, max_value=2000),
    mips2=st.integers(min_value=2001, max_value=5000),
    seed=st.integers(min_value=0, max_value=1000000)
)
def test_property_50_db2_cpu_time_scaling_type101(start_year, duration_days, mips1, mips2, seed):
    """
    Feature: smf-test-data-generator, Property 50: DB2 CPU Time Scaling
    
    For any two configurations with different MIPS values, generated DB2 CPU
    times (in Types 100, 101, 102) should scale inversely proportional to MIPS.
    
    Validates: Requirements 17.8, 18.8, 19.9
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    begin_timestamp = start_date
    end_timestamp = begin_timestamp + timedelta(seconds=60)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    
    # Set random seed for reproducibility
    import random
    random.seed(seed)
    
    # Generate records with two different MIPS configurations
    infrastructure1 = InfrastructureParameters({'mips': mips1})
    generator1 = SMF101RecordGenerator(catalog, distribution, infrastructure1)
    record1 = generator1.generate_accounting_record(
        'USER01', 'TESTPLAN', 'CONN01', begin_timestamp, end_timestamp, False
    )
    
    # Reset seed to get same base values
    random.seed(seed)
    
    infrastructure2 = InfrastructureParameters({'mips': mips2})
    generator2 = SMF101RecordGenerator(catalog, distribution, infrastructure2)
    record2 = generator2.generate_accounting_record(
        'USER01', 'TESTPLAN', 'CONN01', begin_timestamp, end_timestamp, False
    )
    
    # For Type 101, we check accumulated_cpu_in_db2 which should scale inversely with MIPS
    # Higher MIPS = lower CPU time for same workload
    cpu_time1 = record1['accounting']['accumulated_cpu_in_db2']
    cpu_time2 = record2['accounting']['accumulated_cpu_in_db2']
    
    # Calculate expected scaling ratio (inverse relationship)
    # If mips2 > mips1, then cpu_time2 < cpu_time1
    # So cpu_time1/cpu_time2 should equal mips2/mips1
    expected_ratio = mips2 / mips1
    
    # Calculate actual ratio
    if cpu_time2 > 0:
        actual_ratio = cpu_time1 / cpu_time2
        
        # With controlled randomness (same seed), the ratio should be very close to expected
        # Allow 10% tolerance for floating point precision
        assert actual_ratio > 0.9 * expected_ratio, (
            f"CPU time should scale inversely with MIPS. "
            f"Expected ratio ~{expected_ratio:.2f}, got {actual_ratio:.2f}"
        )
        assert actual_ratio < 1.1 * expected_ratio, (
            f"CPU time should scale inversely with MIPS. "
            f"Expected ratio ~{expected_ratio:.2f}, got {actual_ratio:.2f}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=30, max_value=365)
)
def test_property_51_db2_subsystem_id_consistency_type101(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 51: DB2 Subsystem ID Consistency
    
    For any set of generated DB2 records (Types 100, 101, 102) within the same
    time window, all records should reference the same DB2 subsystem_id.
    
    Validates: Requirements 17.2, 18.2, 19.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF101RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate multiple records
    records = generator.generate_records()
    
    # Skip test if no records generated
    if len(records) == 0:
        pytest.skip("No records generated")
    
    # Extract all subsystem IDs
    subsystem_ids = [record['subsystem_id'] for record in records]
    
    # All subsystem IDs should be the same within a generation run
    unique_subsystem_ids = set(subsystem_ids)
    assert len(unique_subsystem_ids) == 1, (
        f"All Type 101 records should have the same subsystem_id. "
        f"Found: {unique_subsystem_ids}"
    )
    
    # Verify subsystem ID format (should be 3-4 characters, alphanumeric)
    subsystem_id = subsystem_ids[0]
    assert len(subsystem_id) >= 3 and len(subsystem_id) <= 4, (
        f"Subsystem ID should be 3-4 characters, got '{subsystem_id}'"
    )
    assert subsystem_id.isalnum(), (
        f"Subsystem ID should be alphanumeric, got '{subsystem_id}'"
    )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_30_unified_schema_compliance_type101(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 30: Unified Schema Compliance
    
    For any generated SMF record of any type, the record should include all
    fields required by the smf_records common table (record_type, subtype,
    system_id, record_date, record_time, record_timestamp).
    
    Validates: Requirements 11.2, 11.3
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF101RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check unified schema compliance for each record
    for record in records:
        # Check required common fields
        assert 'record_type' in record, "Missing required field: record_type"
        assert 'subtype' in record, "Missing required field: subtype"
        assert 'system_id' in record, "Missing required field: system_id"
        assert 'date' in record, "Missing required field: date (record_date)"
        assert 'timestamp' in record, "Missing required field: timestamp (record_time)"
        
        # Verify record_type is 101 for Type 101 records
        assert record['record_type'] == 101, (
            f"Expected record_type 101, got {record['record_type']}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_31_record_timestamp_format_type101(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 31: Record Timestamp Format
    
    For any generated SMF record, the record_timestamp field should match
    the format "YYYY-MM-DD HH:MM:SS".
    
    Validates: Requirements 11.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF101RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Pattern for "YYYY-MM-DD HH:MM:SS" format
    timestamp_pattern = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
    
    # Check timestamp format for each record
    for record in records:
        date = record.get('date')
        time = record.get('timestamp')
        
        # Check date format (YYYY-MM-DD)
        assert date is not None, "date field should not be None"
        date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        assert date_pattern.match(date), (
            f"date '{date}' does not match format YYYY-MM-DD"
        )
        
        # Check time format (HH:MM:SS)
        assert time is not None, "timestamp field should not be None"
        time_pattern = re.compile(r'^\d{2}:\d{2}:\d{2}$')
        assert time_pattern.match(time), (
            f"timestamp '{time}' does not match format HH:MM:SS"
        )
        
        # Construct full timestamp and verify format
        full_timestamp = f"{date} {time}"
        assert timestamp_pattern.match(full_timestamp), (
            f"Full timestamp '{full_timestamp}' does not match format YYYY-MM-DD HH:MM:SS"
        )
