"""
Unit tests for configuration loader.

Tests specific examples and edge cases for configuration validation.
"""

import pytest
import yaml
import tempfile
import os
from tools.smf_test_data_generator.config_loader import GeneratorConfig


def test_valid_configuration():
    """Test loading a valid configuration file."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': './test.db',
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        },
        'active_artifacts': {
            'programs': [
                {'name': 'PROG1', 'frequency': 'high'},
                {'name': 'PROG2', 'frequency': 'medium'}
            ]
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        assert len(errors) == 0, f"Expected no errors, got: {errors}"
    finally:
        os.unlink(temp_path)


def test_end_date_before_start_date():
    """Test validation fails when end date is before start date."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': './test.db',
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-12-31',
            'end_date': '2023-01-01'
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        assert len(errors) > 0
        assert any('End date must be after start date' in error for error in errors)
    finally:
        os.unlink(temp_path)


def test_invalid_frequency_level():
    """Test validation fails with invalid frequency level."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': './test.db',
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        },
        'active_artifacts': {
            'programs': [
                {'name': 'PROG1', 'frequency': 'invalid'}
            ]
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        assert len(errors) > 0
        assert any('Invalid frequency level' in error for error in errors)
        assert any('must be \'high\', \'medium\', or \'low\'' in error for error in errors)
    finally:
        os.unlink(temp_path)


def test_missing_required_field():
    """Test validation fails when required field is missing."""
    config_dict = {
        'generation_mode': 'inventory',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        assert len(errors) > 0
        assert any('database_path' in error for error in errors)
    finally:
        os.unlink(temp_path)


def test_invalid_date_format():
    """Test validation fails with invalid date format."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': './test.db',
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '01/01/2023',  # Wrong format
            'end_date': '2023-12-31'
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        assert len(errors) > 0
        assert any('Invalid date format' in error for error in errors)
    finally:
        os.unlink(temp_path)


def test_artifact_missing_name():
    """Test validation fails when artifact is missing name field."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': './test.db',
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        },
        'active_artifacts': {
            'programs': [
                {'frequency': 'high'}  # Missing name
            ]
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        assert len(errors) > 0
        assert any('missing \'name\' field' in error for error in errors)
    finally:
        os.unlink(temp_path)


def test_artifact_missing_frequency():
    """Test validation fails when artifact is missing frequency field."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': './test.db',
        'inventory_db': './test.db',
        'output_directory': './output',
        'application_name': 'testapp',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-12-31'
        },
        'active_artifacts': {
            'programs': [
                {'name': 'PROG1'}  # Missing frequency
            ]
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = f.name
    
    try:
        config = GeneratorConfig(temp_path)
        errors = config.validate()
        assert len(errors) > 0
        assert any('missing \'frequency\' field' in error for error in errors)
    finally:
        os.unlink(temp_path)


def test_file_not_found():
    """Test that FileNotFoundError is raised for non-existent config file."""
    with pytest.raises(FileNotFoundError):
        GeneratorConfig('/nonexistent/path/config.yaml')


def test_empty_config_file():
    """Test that ValueError is raised for empty config file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write('')  # Empty file
        temp_path = f.name
    
    try:
        with pytest.raises(ValueError, match="Configuration file is empty"):
            GeneratorConfig(temp_path)
    finally:
        os.unlink(temp_path)


def test_invalid_yaml_syntax():
    """Test that YAMLError is raised for invalid YAML syntax."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write('invalid: yaml: syntax: [')
        temp_path = f.name
    
    try:
        with pytest.raises(yaml.YAMLError):
            GeneratorConfig(temp_path)
    finally:
        os.unlink(temp_path)
