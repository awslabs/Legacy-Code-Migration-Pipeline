"""
Property-based tests for SMF Type 102 record generator.

Tests correctness properties for Type 102 record generation including schema
compliance, DB2 CPU time scaling, DB2 subsystem ID consistency, and unified
schema compliance.
"""

import pytest
import re
import json
from datetime import datetime, timedelta
from hypothesis import given, strategies as st, settings
from tools.smf_test_data_generator.smf102_generator import SMF102RecordGenerator
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters


# Helper function to create a test catalog
def create_test_catalog(
    programs=None,
    jcl_jobs=None,
    datasets=None
):
    """Create a test artifact catalog with specified artifacts."""
    if programs is None:
        programs = ['PROG01', 'PROG02', 'PROG03']
    if jcl_jobs is None:
        jcl_jobs = ['JOB01', 'JOB02']
    if datasets is None:
        datasets = ['DATA.SET.ONE', 'DATA.SET.TWO']
    
    # Create catalog directly with mock data
    catalog = ArtifactCatalog.__new__(ArtifactCatalog)
    
    # Initialize storage structures
    catalog._active_programs = {'high': [], 'medium': [], 'low': []}
    catalog._active_jcl = {'high': [], 'medium': [], 'low': []}
    catalog._active_cics_transactions = {'high': [], 'medium': [], 'low': []}
    catalog._active_datasets = {'high': [], 'medium': [], 'low': []}
    
    catalog._unreferenced_programs = set()
    catalog._unreferenced_jcl = set()
    catalog._unreferenced_datasets = set()
    catalog._unreferenced_cics_transactions = set()
    
    catalog._missing_programs = set()
    catalog._missing_datasets = set()
    catalog._missing_cics_transactions = set()
    
    catalog._cics_program_mapping = {}
    catalog._program_datasets = {}
    
    # Add programs to high frequency
    catalog._active_programs['high'] = list(programs)
    
    # Add JCL jobs to high frequency
    catalog._active_jcl['high'] = list(jcl_jobs)
    
    # Add datasets to high frequency
    catalog._active_datasets['high'] = list(datasets)
    
    return catalog


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365),
    mips=st.integers(min_value=500, max_value=5000)
)
def test_property_49_type102_schema_compliance(start_year, duration_days, mips):
    """
    Feature: smf-test-data-generator, Property 49: Type 102 Schema Compliance
    
    For any generated Type 102 record, the record structure should match the
    unified schema definition with performance section containing detailed DB2
    metrics and optional headers.
    
    Validates: Requirements 19.1, 19.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    timestamp = start_date
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({'mips': mips})
    generator = SMF102RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate a single record
    record = generator.generate_performance_record(
        subsystem_id='DB2P',
        timestamp=timestamp
    )
    
    # Check top-level required fields
    assert 'record_type' in record
    assert record['record_type'] == 102
    assert 'subtype' in record
    assert 'system_id' in record
    assert 'date' in record
    assert 'timestamp' in record
    assert 'record_length' in record
    assert 'subsystem_id' in record
    
    # Verify subsystem_id is not empty
    assert record['subsystem_id'], "subsystem_id should not be empty"
    
    # Check performance section is present
    assert 'performance' in record, "Missing required section: performance"
    assert record['performance'] is not None, "Section performance is None"
    
    # Check performance section fields
    perf = record['performance']
    assert 'product_section_offset' in perf
    assert 'product_section_length' in perf
    assert 'product_section_count' in perf
    assert 'has_correlation_header' in perf
    assert 'has_trace_header' in perf
    assert 'has_cpu_header' in perf
    assert 'has_distributed_header' in perf
    assert 'has_data_sharing_header' in perf
    assert 'self_defining_section_offset' in perf
    assert 'data_sections_json' in perf
    
    # Verify header flags are 0 or 1
    assert perf['has_correlation_header'] in [0, 1]
    assert perf['has_trace_header'] in [0, 1]
    assert perf['has_cpu_header'] in [0, 1]
    assert perf['has_distributed_header'] in [0, 1]
    assert perf['has_data_sharing_header'] in [0, 1]
    
    # Verify data_sections_json is valid JSON
    assert perf['data_sections_json'], "data_sections_json should not be empty"
    try:
        detailed_metrics = json.loads(perf['data_sections_json'])
    except json.JSONDecodeError as e:
        pytest.fail(f"data_sections_json is not valid JSON: {e}")
    
    # Check detailed metrics structure
    assert 'ifcid' in detailed_metrics
    assert 'cpu_time_us' in detailed_metrics
    assert 'elapsed_time_us' in detailed_metrics
    assert 'getpage_count' in detailed_metrics
    assert 'sync_io_count' in detailed_metrics
    assert 'lock_requests' in detailed_metrics
    assert 'lock_suspensions' in detailed_metrics
    assert 'sql_statements' in detailed_metrics
    
    # Verify metrics are non-negative
    assert detailed_metrics['cpu_time_us'] >= 0
    assert detailed_metrics['elapsed_time_us'] >= 0
    assert detailed_metrics['getpage_count'] >= 0
    assert detailed_metrics['sync_io_count'] >= 0
    assert detailed_metrics['lock_requests'] >= 0
    assert detailed_metrics['lock_suspensions'] >= 0
    assert detailed_metrics['sql_statements'] >= 0
    
    # Check correlation header
    assert 'correlation' in detailed_metrics
    corr = detailed_metrics['correlation']
    assert 'authorization_id' in corr
    assert 'plan_name' in corr
    assert 'connection_name' in corr
    assert corr['authorization_id'], "authorization_id should not be empty"
    assert corr['plan_name'], "plan_name should not be empty"
    assert corr['connection_name'], "connection_name should not be empty"
    
    # Check trace header
    assert 'trace' in detailed_metrics
    trace = detailed_metrics['trace']
    assert 'trace_number' in trace
    assert 'trace_type' in trace
    assert trace['trace_number'] > 0
    assert trace['trace_type'], "trace_type should not be empty"
    
    # Check CPU header
    assert 'cpu' in detailed_metrics
    cpu = detailed_metrics['cpu']
    assert 'cpu_number' in cpu
    assert 'cpu_model' in cpu
    assert 'cpu_serial' in cpu
    assert cpu['cpu_number'] >= 0
    assert cpu['cpu_model'], "cpu_model should not be empty"
    assert cpu['cpu_serial'], "cpu_serial should not be empty"


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365),
    mips1=st.integers(min_value=500, max_value=2000),
    mips2=st.integers(min_value=2001, max_value=5000),
    seed=st.integers(min_value=0, max_value=1000000)
)
def test_property_50_db2_cpu_time_scaling_type102(start_year, duration_days, mips1, mips2, seed):
    """
    Feature: smf-test-data-generator, Property 50: DB2 CPU Time Scaling
    
    For any two configurations with different MIPS values, generated DB2 CPU
    times (in Types 100, 101, 102) should scale inversely proportional to MIPS.
    
    Validates: Requirements 17.8, 18.8, 19.9
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    timestamp = start_date
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    
    # Set random seed for reproducibility
    import random
    random.seed(seed)
    
    # Generate records with two different MIPS configurations
    infrastructure1 = InfrastructureParameters({'mips': mips1})
    generator1 = SMF102RecordGenerator(catalog, distribution, infrastructure1)
    record1 = generator1.generate_performance_record('DB2P', timestamp)
    
    # Reset seed to get same base values
    random.seed(seed)
    
    infrastructure2 = InfrastructureParameters({'mips': mips2})
    generator2 = SMF102RecordGenerator(catalog, distribution, infrastructure2)
    record2 = generator2.generate_performance_record('DB2P', timestamp)
    
    # Extract CPU times from detailed metrics
    metrics1 = json.loads(record1['performance']['data_sections_json'])
    metrics2 = json.loads(record2['performance']['data_sections_json'])
    
    cpu_time1 = metrics1['cpu_time_us']
    cpu_time2 = metrics2['cpu_time_us']
    
    # Calculate expected scaling ratio (inverse proportional)
    # Higher MIPS = lower CPU time for same workload
    # If mips2 > mips1, then cpu_time2 < cpu_time1
    # So cpu_time1/cpu_time2 should equal mips2/mips1
    expected_ratio = mips2 / mips1
    
    # Calculate actual ratio (with tolerance for randomness)
    if cpu_time2 > 0:
        actual_ratio = cpu_time1 / cpu_time2
        
        # Allow 20% tolerance due to rounding in integer conversion
        # The key is that higher MIPS should produce lower CPU times
        assert actual_ratio > 0.8 * expected_ratio, (
            f"CPU time should scale inversely with MIPS. "
            f"Expected ratio ~{expected_ratio:.2f}, got {actual_ratio:.2f}"
        )
        assert actual_ratio < 1.2 * expected_ratio, (
            f"CPU time should scale inversely with MIPS. "
            f"Expected ratio ~{expected_ratio:.2f}, got {actual_ratio:.2f}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=30, max_value=365)
)
def test_property_51_db2_subsystem_id_consistency_type102(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 51: DB2 Subsystem ID Consistency
    
    For any set of generated DB2 records (Types 100, 101, 102) within the same
    time window, all records should reference the same DB2 subsystem_id.
    
    Validates: Requirements 17.2, 18.2, 19.2
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF102RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate multiple records
    records = generator.generate_records()
    
    # Skip test if no records generated
    if len(records) == 0:
        pytest.skip("No records generated")
    
    # Extract all subsystem IDs
    subsystem_ids = [record['subsystem_id'] for record in records]
    
    # All subsystem IDs should be the same within a generation run
    unique_subsystem_ids = set(subsystem_ids)
    assert len(unique_subsystem_ids) == 1, (
        f"All Type 102 records should have the same subsystem_id. "
        f"Found: {unique_subsystem_ids}"
    )
    
    # Verify subsystem ID format (should be 3-4 characters, alphanumeric)
    subsystem_id = subsystem_ids[0]
    assert len(subsystem_id) >= 3 and len(subsystem_id) <= 4, (
        f"Subsystem ID should be 3-4 characters, got '{subsystem_id}'"
    )
    assert subsystem_id.isalnum(), (
        f"Subsystem ID should be alphanumeric, got '{subsystem_id}'"
    )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_30_unified_schema_compliance_type102(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 30: Unified Schema Compliance
    
    For any generated SMF record of any type, the record should include all
    fields required by the smf_records common table (record_type, subtype,
    system_id, record_date, record_time, record_timestamp).
    
    Validates: Requirements 11.2, 11.3
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF102RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Check unified schema compliance for each record
    for record in records:
        # Check required common fields
        assert 'record_type' in record, "Missing required field: record_type"
        assert 'subtype' in record, "Missing required field: subtype"
        assert 'system_id' in record, "Missing required field: system_id"
        assert 'date' in record, "Missing required field: date (record_date)"
        assert 'timestamp' in record, "Missing required field: timestamp (record_time)"
        
        # Verify record_type is 102 for Type 102 records
        assert record['record_type'] == 102, (
            f"Expected record_type 102, got {record['record_type']}"
        )


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    start_year=st.integers(min_value=2020, max_value=2024),
    duration_days=st.integers(min_value=7, max_value=365)
)
def test_property_31_record_timestamp_format_type102(start_year, duration_days):
    """
    Feature: smf-test-data-generator, Property 31: Record Timestamp Format
    
    For any generated SMF record, the record_timestamp field should match
    the format "YYYY-MM-DD HH:MM:SS".
    
    Validates: Requirements 11.4
    """
    # Create test setup
    start_date = datetime(start_year, 1, 1)
    end_date = start_date + timedelta(days=duration_days)
    
    catalog = create_test_catalog()
    distribution = DistributionStrategy(start_date, end_date)
    infrastructure = InfrastructureParameters({})
    generator = SMF102RecordGenerator(catalog, distribution, infrastructure)
    
    # Generate records
    records = generator.generate_records()
    
    # Pattern for "YYYY-MM-DD HH:MM:SS" format
    timestamp_pattern = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
    
    # Check timestamp format for each record
    for record in records:
        date = record.get('date')
        time = record.get('timestamp')
        
        # Check date format (YYYY-MM-DD)
        assert date is not None, "date field should not be None"
        date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        assert date_pattern.match(date), (
            f"date '{date}' does not match format YYYY-MM-DD"
        )
        
        # Check time format (HH:MM:SS)
        assert time is not None, "timestamp field should not be None"
        time_pattern = re.compile(r'^\d{2}:\d{2}:\d{2}$')
        assert time_pattern.match(time), (
            f"timestamp '{time}' does not match format HH:MM:SS"
        )
        
        # Construct full timestamp and verify format
        full_timestamp = f"{date} {time}"
        assert timestamp_pattern.match(full_timestamp), (
            f"Full timestamp '{full_timestamp}' does not match format YYYY-MM-DD HH:MM:SS"
        )
