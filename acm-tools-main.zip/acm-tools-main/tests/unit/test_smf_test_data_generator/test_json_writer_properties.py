"""
Property-based tests for JSON writer.

Tests correctness properties for JSON file writing and output directory creation.
"""

import pytest
import json
import tempfile
import os
import shutil
from pathlib import Path
from hypothesis import given, strategies as st, settings
from tools.smf_test_data_generator.json_writer import JSONWriter


# Strategy for generating SMF record-like dictionaries
@st.composite
def smf_record(draw, record_type):
    """Generate a minimal SMF record dictionary."""
    record = {
        'record_type': record_type,
        'system_id': draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=8)),
        'date': draw(st.dates(min_value=datetime.date(2020, 1, 1), max_value=datetime.date(2025, 12, 31))).strftime('%Y-%m-%d'),
        'timestamp': f"{draw(st.integers(0, 23)):02d}:{draw(st.integers(0, 59)):02d}:{draw(st.integers(0, 59)):02d}",
    }
    
    if record_type == 30:
        record['identification'] = {
            'job_name': draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=8)),
            'program_name': draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=8)),
        }
    elif record_type == 110:
        record['identification'] = {
            'tran_name': draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=4)),
            'program_name': draw(st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), min_size=1, max_size=8)),
        }
    
    return record


import datetime


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    output_dir=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-/'), min_size=1, max_size=50),
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20)
)
def test_property_17_output_directory_creation(output_dir, app_name):
    """
    Feature: smf-test-data-generator, Property 17: Output Directory Creation
    
    For any specified output directory path, if the directory does not exist
    when the generator runs, the directory should be created before writing
    output files.
    
    Validates: Requirements 8.4
    """
    # Create a temporary base directory
    with tempfile.TemporaryDirectory() as temp_base:
        # Create a path that doesn't exist yet
        full_output_dir = os.path.join(temp_base, output_dir.lstrip('/'))
        
        # Ensure the directory doesn't exist
        if os.path.exists(full_output_dir):
            shutil.rmtree(full_output_dir)
        
        assert not os.path.exists(full_output_dir), "Directory should not exist before test"
        
        # Create writer and write some records
        writer = JSONWriter(full_output_dir, app_name)
        test_records = [{'record_type': 30, 'test': 'data'}]
        
        # Write records - this should create the directory
        writer.write_type30_records(test_records)
        
        # Verify directory was created
        assert os.path.exists(full_output_dir), "Directory should be created"
        assert os.path.isdir(full_output_dir), "Path should be a directory"
        
        # Verify file was written
        expected_file = os.path.join(full_output_dir, f"smf30_{app_name}.json")
        assert os.path.exists(expected_file), "Output file should exist"


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20),
    num_records=st.integers(min_value=0, max_value=10)
)
def test_property_17_nested_directory_creation(app_name, num_records):
    """
    Feature: smf-test-data-generator, Property 17: Output Directory Creation
    
    Verify that nested directories are created properly (parents=True behavior).
    
    Validates: Requirements 8.4
    """
    with tempfile.TemporaryDirectory() as temp_base:
        # Create a nested path that doesn't exist
        nested_path = os.path.join(temp_base, 'level1', 'level2', 'level3')
        
        assert not os.path.exists(nested_path), "Nested path should not exist"
        
        writer = JSONWriter(nested_path, app_name)
        test_records = [{'record_type': 110, 'test': f'data{i}'} for i in range(num_records)]
        
        # Write records - should create all parent directories
        writer.write_type110_records(test_records)
        
        # Verify all directories were created
        assert os.path.exists(nested_path), "Nested directory should be created"
        assert os.path.isdir(nested_path), "Path should be a directory"
        
        # Verify file was written
        expected_file = os.path.join(nested_path, f"smf110_{app_name}.json")
        assert os.path.exists(expected_file), "Output file should exist"


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20),
    num_records=st.integers(min_value=0, max_value=20)
)
def test_property_18_json_array_structure_type30(app_name, num_records):
    """
    Feature: smf-test-data-generator, Property 18: JSON Array Structure
    
    For any generated output file (Type 30 or Type 110), the file content
    should be a valid JSON array containing zero or more SMF record objects.
    
    Validates: Requirements 8.6
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # Generate test records
        test_records = []
        for i in range(num_records):
            record = {
                'record_type': 30,
                'system_id': f'SYS{i}',
                'date': '2023-06-15',
                'timestamp': '14:23:45',
                'identification': {
                    'job_name': f'JOB{i:04d}',
                    'program_name': f'PROG{i:04d}'
                }
            }
            test_records.append(record)
        
        # Write records
        output_file = writer.write_type30_records(test_records)
        
        # Read and validate JSON structure
        with open(output_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
            # Should be valid JSON
            parsed = json.loads(content)
            
            # Should be an array
            assert isinstance(parsed, list), "Output should be a JSON array"
            
            # Should have correct number of records
            assert len(parsed) == num_records, f"Array should contain {num_records} records"
            
            # Each element should be a dictionary (object)
            for i, record in enumerate(parsed):
                assert isinstance(record, dict), f"Record {i} should be a JSON object"
                assert 'record_type' in record, f"Record {i} should have record_type field"
                assert record['record_type'] == 30, f"Record {i} should be Type 30"


@pytest.mark.property
@settings(max_examples=100, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20),
    num_records=st.integers(min_value=0, max_value=20)
)
def test_property_18_json_array_structure_type110(app_name, num_records):
    """
    Feature: smf-test-data-generator, Property 18: JSON Array Structure
    
    For any generated Type 110 output file, the file content should be a
    valid JSON array containing zero or more SMF record objects.
    
    Validates: Requirements 8.6
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # Generate test records
        test_records = []
        for i in range(num_records):
            record = {
                'record_type': 110,
                'system_id': f'SYS{i}',
                'date': '2023-06-15',
                'timestamp': '14:23:45',
                'identification': {
                    'tran_name': f'T{i:03d}',
                    'program_name': f'PROG{i:04d}'
                }
            }
            test_records.append(record)
        
        # Write records
        output_file = writer.write_type110_records(test_records)
        
        # Read and validate JSON structure
        with open(output_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
            # Should be valid JSON
            parsed = json.loads(content)
            
            # Should be an array
            assert isinstance(parsed, list), "Output should be a JSON array"
            
            # Should have correct number of records
            assert len(parsed) == num_records, f"Array should contain {num_records} records"
            
            # Each element should be a dictionary (object)
            for i, record in enumerate(parsed):
                assert isinstance(record, dict), f"Record {i} should be a JSON object"
                assert 'record_type' in record, f"Record {i} should have record_type field"
                assert record['record_type'] == 110, f"Record {i} should be Type 110"


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20)
)
def test_property_18_empty_array_valid_json(app_name):
    """
    Feature: smf-test-data-generator, Property 18: JSON Array Structure
    
    Even with zero records, the output should be a valid JSON array (empty array).
    
    Validates: Requirements 8.6
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # Write empty record list
        output_file = writer.write_type30_records([])
        
        # Read and validate
        with open(output_file, 'r', encoding='utf-8') as f:
            content = f.read()
            parsed = json.loads(content)
            
            assert isinstance(parsed, list), "Output should be a JSON array"
            assert len(parsed) == 0, "Array should be empty"
            assert content.strip() == '[]', "Empty array should be formatted as []"


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20),
    num_records=st.integers(min_value=1, max_value=10)
)
def test_property_18_json_formatting_indentation(app_name, num_records):
    """
    Feature: smf-test-data-generator, Property 18: JSON Array Structure
    
    JSON output should be properly formatted with indentation for readability.
    
    Validates: Requirements 8.5, 8.6
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # Create test records
        test_records = [
            {
                'record_type': 30,
                'system_id': f'SYS{i}',
                'nested': {'field': 'value'}
            }
            for i in range(num_records)
        ]
        
        # Write records
        output_file = writer.write_type30_records(test_records)
        
        # Read content
        with open(output_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
            # Should be valid JSON
            parsed = json.loads(content)
            assert isinstance(parsed, list)
            
            # Check for indentation (indent=2 means 2 spaces)
            # The content should have newlines and indentation
            assert '\n' in content, "JSON should be formatted with newlines"
            
            # Re-format with same settings and compare
            expected = json.dumps(test_records, indent=2)
            assert content == expected, "JSON should be formatted with indent=2"


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20)
)
def test_property_18_multiple_writes_overwrite(app_name):
    """
    Feature: smf-test-data-generator, Property 18: JSON Array Structure
    
    Multiple writes to the same file should overwrite (not append).
    
    Validates: Requirements 8.6
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # First write
        first_records = [{'record_type': 30, 'id': 1}]
        writer.write_type30_records(first_records)
        
        # Second write with different data
        second_records = [{'record_type': 30, 'id': 2}, {'record_type': 30, 'id': 3}]
        output_file = writer.write_type30_records(second_records)
        
        # Read and verify only second write is present
        with open(output_file, 'r', encoding='utf-8') as f:
            parsed = json.loads(f.read())
            
            assert len(parsed) == 2, "Should only have records from second write"
            assert parsed[0]['id'] == 2
            assert parsed[1]['id'] == 3


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20),
    record_types=st.lists(st.sampled_from([14, 15, 17, 30, 62, 64, 110]), min_size=1, max_size=7, unique=True)
)
def test_property_44_multi_type_file_naming(app_name, record_types):
    """
    Feature: smf-test-data-generator, Property 44: Multi-Type File Naming
    
    For any set of generated record types, each type should be written to a
    separate file named smf{type}_{application_name}.json.
    
    Validates: Requirements 20.3
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # Create records for each type
        records_by_type = {}
        for record_type in record_types:
            records_by_type[record_type] = [
                {
                    'record_type': record_type,
                    'system_id': 'SYS1',
                    'date': '2023-06-15',
                    'timestamp': '14:23:45'
                }
            ]
        
        # Write all records
        written_files = writer.write_all_records(records_by_type)
        
        # Verify correct number of files written (one per type + merged file)
        assert len(written_files) == len(record_types) + 1, \
            f"Should write {len(record_types)} type-specific files + 1 merged file"
        
        # Verify each record type has its own file
        for record_type in record_types:
            assert record_type in written_files, \
                f"Record type {record_type} should be in written files"
            
            # Verify file naming convention
            expected_filename = f"smf{record_type}_{app_name}.json"
            filepath = written_files[record_type]
            
            assert os.path.basename(filepath) == expected_filename, \
                f"File should be named {expected_filename}"
            
            # Verify file exists
            assert os.path.exists(filepath), \
                f"File {filepath} should exist"
            
            # Verify file contains correct record type
            with open(filepath, 'r', encoding='utf-8') as f:
                parsed = json.loads(f.read())
                assert isinstance(parsed, list), "File should contain JSON array"
                assert len(parsed) > 0, "File should contain at least one record"
                assert parsed[0]['record_type'] == record_type, \
                    f"Record should have type {record_type}"


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20),
    record_type=st.sampled_from([14, 15, 17, 30, 62, 64, 110])
)
def test_property_44_write_records_generic_method(app_name, record_type):
    """
    Feature: smf-test-data-generator, Property 44: Multi-Type File Naming
    
    The generic write_records() method should work for any record type
    and follow the same naming convention.
    
    Validates: Requirements 20.3
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # Create test record
        test_records = [
            {
                'record_type': record_type,
                'system_id': 'SYS1',
                'date': '2023-06-15',
                'timestamp': '14:23:45'
            }
        ]
        
        # Write using generic method
        output_file = writer.write_records(record_type, test_records)
        
        # Verify file naming convention
        expected_filename = f"smf{record_type}_{app_name}.json"
        assert os.path.basename(output_file) == expected_filename, \
            f"File should be named {expected_filename}"
        
        # Verify file exists and contains correct data
        assert os.path.exists(output_file), "File should exist"
        
        with open(output_file, 'r', encoding='utf-8') as f:
            parsed = json.loads(f.read())
            assert isinstance(parsed, list), "File should contain JSON array"
            assert len(parsed) == 1, "File should contain one record"
            assert parsed[0]['record_type'] == record_type, \
                f"Record should have type {record_type}"


@pytest.mark.property
@settings(max_examples=50, deadline=None)
@given(
    app_name=st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'), min_size=1, max_size=20)
)
def test_property_44_all_record_types_separate_files(app_name):
    """
    Feature: smf-test-data-generator, Property 44: Multi-Type File Naming
    
    When writing all supported record types, each should get its own file.
    
    Validates: Requirements 20.3
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        writer = JSONWriter(temp_dir, app_name)
        
        # Create records for all supported types
        all_types = [14, 15, 17, 30, 62, 64, 110]
        records_by_type = {
            record_type: [{'record_type': record_type, 'test': 'data'}]
            for record_type in all_types
        }
        
        # Write all records
        written_files = writer.write_all_records(records_by_type)
        
        # Verify all types written (including merged file)
        assert len(written_files) == len(all_types) + 1, \
            "Should write file for each record type + merged file"
        
        # Verify no files are shared between types
        file_paths = list(written_files.values())
        assert len(file_paths) == len(set(file_paths)), \
            "Each record type should have unique file"
        
        # Verify all files exist
        for record_type, filepath in written_files.items():
            assert os.path.exists(filepath), \
                f"File for type {record_type} should exist"
            
            # Verify correct naming
            if record_type == 'merged':
                expected_name = f"smf_all_{app_name}.json"
            else:
                expected_name = f"smf{record_type}_{app_name}.json"
            assert os.path.basename(filepath) == expected_name, \
                f"File should be named {expected_name}"
