"""
Unit tests for external program and caller configuration loading.

Tests the ExternalConfigLoader class and related functions for loading
and managing external program and caller configuration from YAML files.
"""

import pytest
import sqlite3
import tempfile
import os
from pathlib import Path

from tools.legacy_analyzer.migration.schema import MigrationFlowSchema
from tools.legacy_analyzer.migration.external_config import (
    ExternalConfigLoader,
    ExternalConfigError,
    load_external_config,
    is_external_program,
    get_external_callers
)


@pytest.fixture
def db_connection():
    """Create an in-memory database with migration schema."""
    conn = sqlite3.connect(':memory:')
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    yield conn
    conn.close()


@pytest.fixture
def sample_config_file():
    """Create a temporary YAML configuration file."""
    config_content = """
external_programs:
  - pattern: "UTIL*"
    type: "UTILITY"
    scope: "EXTERNAL"
  
  - pattern: "COMMON*"
    type: "UTILITY"
    scope: "EXTERNAL"
  
  - name: "DBUTIL"
    type: "DATABASE_UTILITY"
    scope: "EXTERNAL"
  
  - name: "LOGGER"
    type: "LOGGING"
    scope: "EXTERNAL"

external_callers:
  - caller: "EXTERNAL_SYSTEM_A"
    calls:
      - target: "PAYCALC"
        type: "PROGRAM_CALL"
        system: "EXTERNAL_SYSTEM_A"
        description: "Legacy batch system"
  
  - caller: "LEGACY_BILLING"
    calls:
      - target: "BILLING1"
        type: "CICS_LINK"
        system: "LEGACY_BILLING"
      - target: "BILLING2"
        type: "PROGRAM_CALL"
"""
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write(config_content)
        temp_path = f.name
    
    yield temp_path
    
    # Cleanup
    if os.path.exists(temp_path):
        os.unlink(temp_path)


@pytest.fixture
def invalid_config_file():
    """Create a temporary invalid YAML configuration file."""
    config_content = """
external_programs:
  - invalid_field: "UTIL*"
"""
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write(config_content)
        temp_path = f.name
    
    yield temp_path
    
    # Cleanup
    if os.path.exists(temp_path):
        os.unlink(temp_path)


class TestExternalConfigLoader:
    """Test ExternalConfigLoader class."""
    
    def test_load_external_config_success(self, db_connection, sample_config_file):
        """Test successful loading of external configuration."""
        loader = ExternalConfigLoader(db_connection)
        result = loader.load_external_config(sample_config_file, verbose=False)
        
        assert result['programs_loaded'] == 4
        assert result['callers_loaded'] == 3
        assert result['config_path'] == sample_config_file
    
    def test_load_external_config_file_not_found(self, db_connection):
        """Test loading with non-existent file."""
        loader = ExternalConfigLoader(db_connection)
        
        with pytest.raises(ExternalConfigError) as exc_info:
            loader.load_external_config('/nonexistent/file.yaml', verbose=False)
        
        assert 'not found' in str(exc_info.value).lower()
    
    def test_load_external_config_invalid_schema(self, db_connection, invalid_config_file):
        """Test loading with invalid configuration schema."""
        loader = ExternalConfigLoader(db_connection)
        
        with pytest.raises(ExternalConfigError) as exc_info:
            loader.load_external_config(invalid_config_file, verbose=False)
        
        assert 'pattern' in str(exc_info.value).lower() or 'name' in str(exc_info.value).lower()
    
    def test_is_external_program_exact_match(self, db_connection, sample_config_file):
        """Test checking if program is external (exact match)."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        assert loader.is_external_program('DBUTIL') is True
        assert loader.is_external_program('LOGGER') is True
        assert loader.is_external_program('NOTEXTERNAL') is False
    
    def test_is_external_program_pattern_match(self, db_connection, sample_config_file):
        """Test checking if program is external (pattern match)."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        assert loader.is_external_program('UTIL001') is True
        assert loader.is_external_program('UTILPROG') is True
        assert loader.is_external_program('COMMON01') is True
        assert loader.is_external_program('COMMONLIB') is True
        assert loader.is_external_program('NOTUTIL') is False
    
    def test_get_external_programs(self, db_connection, sample_config_file):
        """Test getting set of external programs (exact matches only)."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        programs = loader.get_external_programs()
        
        assert 'DBUTIL' in programs
        assert 'LOGGER' in programs
        assert len(programs) == 2  # Only exact matches, not patterns
    
    def test_get_external_patterns(self, db_connection, sample_config_file):
        """Test getting list of external program patterns."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        patterns = loader.get_external_patterns()
        
        assert 'UTIL*' in patterns
        assert 'COMMON*' in patterns
        assert len(patterns) == 2
    
    def test_get_external_callers_all(self, db_connection, sample_config_file):
        """Test getting all external callers."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        callers = loader.get_external_callers()
        
        assert 'EXTERNAL_SYSTEM_A' in callers
        assert 'LEGACY_BILLING' in callers
        assert len(callers['EXTERNAL_SYSTEM_A']) == 1
        assert len(callers['LEGACY_BILLING']) == 2
    
    def test_get_external_callers_filtered(self, db_connection, sample_config_file):
        """Test getting external callers filtered by target program."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        callers = loader.get_external_callers(target_program='BILLING1')
        
        assert 'LEGACY_BILLING' in callers
        assert 'EXTERNAL_SYSTEM_A' not in callers
        assert len(callers['LEGACY_BILLING']) == 1
        assert callers['LEGACY_BILLING'][0]['target'] == 'BILLING1'
    
    def test_matches_external_pattern(self, db_connection, sample_config_file):
        """Test pattern matching for external programs."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        matches, pattern = loader.matches_external_pattern('UTIL123')
        assert matches is True
        assert pattern == 'UTIL*'
        
        matches, pattern = loader.matches_external_pattern('NOTUTIL')
        assert matches is False
        assert pattern is None
    
    def test_clear_external_config(self, db_connection, sample_config_file):
        """Test clearing external configuration."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        # Verify data is loaded
        summary = loader.get_config_summary()
        assert summary['total_external_programs'] > 0
        assert summary['unique_external_callers'] > 0
        
        # Clear configuration
        loader.clear_external_config(verbose=False)
        
        # Verify data is cleared
        summary = loader.get_config_summary()
        assert summary['total_external_programs'] == 0
        assert summary['unique_external_callers'] == 0
    
    def test_get_config_summary(self, db_connection, sample_config_file):
        """Test getting configuration summary."""
        loader = ExternalConfigLoader(db_connection)
        loader.load_external_config(sample_config_file, verbose=False)
        
        summary = loader.get_config_summary()
        
        assert summary['total_external_programs'] == 4
        assert summary['pattern_programs'] == 2
        assert summary['exact_programs'] == 2
        assert summary['unique_external_callers'] == 2
        assert summary['total_external_calls'] == 3


class TestConvenienceFunctions:
    """Test convenience functions."""
    
    def test_load_external_config_function(self, db_connection, sample_config_file):
        """Test load_external_config convenience function."""
        result = load_external_config(db_connection, sample_config_file, verbose=False)
        
        assert result['programs_loaded'] == 4
        assert result['callers_loaded'] == 3
    
    def test_is_external_program_function(self, db_connection, sample_config_file):
        """Test is_external_program convenience function."""
        load_external_config(db_connection, sample_config_file, verbose=False)
        
        assert is_external_program(db_connection, 'DBUTIL') is True
        assert is_external_program(db_connection, 'UTIL123') is True
        assert is_external_program(db_connection, 'NOTEXTERNAL') is False
    
    def test_get_external_callers_function(self, db_connection, sample_config_file):
        """Test get_external_callers convenience function."""
        load_external_config(db_connection, sample_config_file, verbose=False)
        
        callers = get_external_callers(db_connection)
        
        assert 'EXTERNAL_SYSTEM_A' in callers
        assert 'LEGACY_BILLING' in callers


class TestPatternMatching:
    """Test pattern matching functionality."""
    
    def test_wildcard_detection(self, db_connection):
        """Test wildcard pattern detection."""
        loader = ExternalConfigLoader(db_connection)
        
        assert loader._is_wildcard_pattern('UTIL*') is True
        assert loader._is_wildcard_pattern('COMMON?') is True
        assert loader._is_wildcard_pattern('*PROG') is True
        assert loader._is_wildcard_pattern('EXACT') is False
    
    def test_asterisk_wildcard(self, db_connection):
        """Test asterisk wildcard matching."""
        config_content = """
external_programs:
  - pattern: "UTIL*"
    type: "UTILITY"
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            loader.load_external_config(temp_path, verbose=False)
            
            assert loader.is_external_program('UTIL') is True
            assert loader.is_external_program('UTIL1') is True
            assert loader.is_external_program('UTIL123') is True
            assert loader.is_external_program('UTILPROG') is True
            assert loader.is_external_program('XUTIL') is False
        finally:
            os.unlink(temp_path)
    
    def test_question_mark_wildcard(self, db_connection):
        """Test question mark wildcard matching."""
        config_content = """
external_programs:
  - pattern: "PROG?"
    type: "UTILITY"
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            loader.load_external_config(temp_path, verbose=False)
            
            assert loader.is_external_program('PROG1') is True
            assert loader.is_external_program('PROGA') is True
            assert loader.is_external_program('PROG') is False
            assert loader.is_external_program('PROG12') is False
        finally:
            os.unlink(temp_path)


class TestConfigValidation:
    """Test configuration validation."""
    
    def test_empty_config(self, db_connection):
        """Test loading empty configuration."""
        config_content = ""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            result = loader.load_external_config(temp_path, verbose=False)
            
            assert result['programs_loaded'] == 0
            assert result['callers_loaded'] == 0
        finally:
            os.unlink(temp_path)
    
    def test_missing_caller_field(self, db_connection):
        """Test validation of missing caller field."""
        config_content = """
external_callers:
  - calls:
      - target: "PROG1"
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            
            with pytest.raises(ExternalConfigError) as exc_info:
                loader.load_external_config(temp_path, verbose=False)
            
            assert 'caller' in str(exc_info.value).lower()
        finally:
            os.unlink(temp_path)
    
    def test_missing_calls_field(self, db_connection):
        """Test validation of missing calls field."""
        config_content = """
external_callers:
  - caller: "EXTERNAL_SYS"
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            
            with pytest.raises(ExternalConfigError) as exc_info:
                loader.load_external_config(temp_path, verbose=False)
            
            assert 'calls' in str(exc_info.value).lower()
        finally:
            os.unlink(temp_path)
    
    def test_missing_target_field(self, db_connection):
        """Test validation of missing target field in call."""
        config_content = """
external_callers:
  - caller: "EXTERNAL_SYS"
    calls:
      - type: "PROGRAM_CALL"
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            
            with pytest.raises(ExternalConfigError) as exc_info:
                loader.load_external_config(temp_path, verbose=False)
            
            assert 'target' in str(exc_info.value).lower()
        finally:
            os.unlink(temp_path)


class TestMetadataHandling:
    """Test metadata handling in external callers."""
    
    def test_caller_metadata_storage(self, db_connection):
        """Test that caller metadata is stored correctly."""
        config_content = """
external_callers:
  - caller: "EXTERNAL_SYS"
    calls:
      - target: "PROG1"
        type: "PROGRAM_CALL"
        system: "EXTERNAL_SYS"
        description: "Test call"
        custom_field: "custom_value"
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            loader.load_external_config(temp_path, verbose=False)
            
            callers = loader.get_external_callers(target_program='PROG1')
            
            assert 'EXTERNAL_SYS' in callers
            call = callers['EXTERNAL_SYS'][0]
            assert call['target'] == 'PROG1'
            assert call['type'] == 'PROGRAM_CALL'
            assert 'metadata' in call
            assert call['metadata']['system'] == 'EXTERNAL_SYS'
            assert call['metadata']['description'] == 'Test call'
            assert call['metadata']['custom_field'] == 'custom_value'
        finally:
            os.unlink(temp_path)
    
    def test_caller_no_metadata(self, db_connection):
        """Test caller with no additional metadata."""
        config_content = """
external_callers:
  - caller: "EXTERNAL_SYS"
    calls:
      - target: "PROG1"
        type: "PROGRAM_CALL"
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            temp_path = f.name
        
        try:
            loader = ExternalConfigLoader(db_connection)
            loader.load_external_config(temp_path, verbose=False)
            
            callers = loader.get_external_callers(target_program='PROG1')
            
            assert 'EXTERNAL_SYS' in callers
            call = callers['EXTERNAL_SYS'][0]
            assert call['target'] == 'PROG1'
            assert call['type'] == 'PROGRAM_CALL'
            # metadata key should not be present if there's no metadata
            assert 'metadata' not in call
        finally:
            os.unlink(temp_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
