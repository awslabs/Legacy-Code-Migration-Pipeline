"""
Unit tests for JSON schema validation.

Tests that the exported JSON format matches the specification exactly,
including all required fields, optional fields, and data structures.
"""

import pytest
import sqlite3
import json
from tools.legacy_analyzer.migration import (
    MigrationFlowExporter,
    MigrationFlowSchema
)


@pytest.fixture
def test_db_with_complete_flow():
    """Create a database with a complete flow for schema validation."""
    conn = sqlite3.connect(':memory:')
    
    # Create schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    cursor = conn.cursor()
    
    # Insert complete flow with all fields
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            priority, business_domain,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_COMPLETE', 'Complete Test Flow', 'TESTPROG', 'JCL',
        3, 2, 2,
        2500, 45, 67.5, 'MEDIUM',
        1, 'TestDomain',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert multiple entry types
    cursor.executemany("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, [
        ('FLOW_COMPLETE', 'JCL', 'JOB1', json.dumps({'jclName': 'JOB1', 'jobName': 'TESTJOB'})),
        ('FLOW_COMPLETE', 'JCL', 'JOB2', json.dumps({'jclName': 'JOB2'})),
        ('FLOW_COMPLETE', 'CICS_TRANSACTION', 'TST1', json.dumps({'transactionId': 'TST1', 'csdGroup': 'TESTGRP'})),
        ('FLOW_COMPLETE', 'CICS_PROGRAM', 'TESTPROG', json.dumps({'programName': 'TESTPROG'}))
    ])
    
    # Insert scope
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, [
        ('FLOW_COMPLETE', 'PROGRAM', 'TESTPROG'),
        ('FLOW_COMPLETE', 'PROGRAM', 'SUBPROG1'),
        ('FLOW_COMPLETE', 'PROGRAM', 'SUBPROG2'),
        ('FLOW_COMPLETE', 'COPYBOOK', 'COPY1'),
        ('FLOW_COMPLETE', 'COPYBOOK', 'COPY2'),
        ('FLOW_COMPLETE', 'DATASET', 'TEST.DATA1'),
        ('FLOW_COMPLETE', 'DATASET', 'TEST.DATA2')
    ])
    
    # Insert interfaces
    cursor.executemany("""
        INSERT INTO flow_interfaces (
            flow_id, direction, interface_type, source, target, external, metadata_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    """, [
        ('FLOW_COMPLETE', 'INBOUND', 'PROGRAM_CALL', 'EXTPROG', 'SUBPROG1', 0,
         json.dumps({'callingProgram': 'EXTPROG'})),
        ('FLOW_COMPLETE', 'OUTBOUND', 'PROGRAM_CALL', 'SUBPROG2', 'UTIL1', 1,
         json.dumps({'callingProgram': 'SUBPROG2'})),
        ('FLOW_COMPLETE', 'OUTBOUND', 'CICS_LINK', 'TESTPROG', 'EXTCICS', 1,
         json.dumps({'program': 'EXTCICS'}))
    ])
    
    # Insert data operations
    cursor.executemany("""
        INSERT INTO flow_data_operations (
            flow_id, operation_category, operation_type, db_type, target, program, mode
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    """, [
        ('FLOW_COMPLETE', 'DATABASE', 'SELECT', 'DB2', 'TEST_TABLE', 'TESTPROG', None),
        ('FLOW_COMPLETE', 'DATABASE', 'INSERT', 'DB2', 'TEST_TABLE', 'SUBPROG1', None),
        ('FLOW_COMPLETE', 'DATABASE', 'UPDATE', 'DB2', 'TEST_TABLE', 'SUBPROG2', None),
        ('FLOW_COMPLETE', 'DATASET', 'ACCESS', None, 'TEST.DATA1', 'TESTPROG', 'INPUT'),
        ('FLOW_COMPLETE', 'DATASET', 'ACCESS', None, 'TEST.DATA2', 'SUBPROG1', 'OUTPUT')
    ])
    
    # Insert dependencies
    cursor.execute("""
        INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
        VALUES (?, ?, ?)
    """, ('FLOW_COMPLETE', 'FLOW_OTHER', 'REQUIRED'))
    
    conn.commit()
    
    yield conn
    
    conn.close()


class TestJSONSchemaValidation:
    """Test JSON schema validation."""
    
    def test_top_level_structure(self, test_db_with_complete_flow):
        """Test that top-level JSON structure is correct."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_all_flows()
        
        # Must have 'flows' key
        assert 'flows' in result
        assert isinstance(result['flows'], list)
    
    def test_flow_object_required_fields(self, test_db_with_complete_flow):
        """Test that flow object has all required fields."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        flow = result['flows'][0]
        
        # Required fields
        required_fields = [
            'flowId', 'name', 'entryPoint', 'scope', 'interfaces',
            'dataOperations', 'complexity', 'dependencies'
        ]
        
        for field in required_fields:
            assert field in flow, f"Missing required field: {field}"
    
    def test_entry_point_structure(self, test_db_with_complete_flow):
        """Test entryPoint object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        entry_point = result['flows'][0]['entryPoint']
        
        # Required fields
        assert 'program' in entry_point
        assert 'types' in entry_point
        
        # program must be a string
        assert isinstance(entry_point['program'], str)
        assert entry_point['program'] == 'TESTPROG'
        
        # types must be an array
        assert isinstance(entry_point['types'], list)
        assert len(entry_point['types']) > 0
        
        # Optional field
        assert 'primaryType' in entry_point
        assert entry_point['primaryType'] == 'JCL'
    
    def test_entry_point_types_structure(self, test_db_with_complete_flow):
        """Test entryPoint.types array structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        types = result['flows'][0]['entryPoint']['types']
        
        # Each type must have 'type' and 'callers'
        for entry_type in types:
            assert 'type' in entry_type
            assert 'callers' in entry_type
            
            # type must be a string
            assert isinstance(entry_type['type'], str)
            
            # callers must be an array
            assert isinstance(entry_type['callers'], list)
            assert len(entry_type['callers']) > 0
    
    def test_entry_point_caller_structure(self, test_db_with_complete_flow):
        """Test caller object structure within entry point types."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        types = result['flows'][0]['entryPoint']['types']
        
        # Find JCL type
        jcl_type = next(t for t in types if t['type'] == 'JCL')
        
        # Check callers
        for caller in jcl_type['callers']:
            assert 'source' in caller
            assert isinstance(caller['source'], str)
            
            # metadata is optional but if present must be a dict
            if 'metadata' in caller:
                assert isinstance(caller['metadata'], dict)
    
    def test_scope_structure(self, test_db_with_complete_flow):
        """Test scope object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        scope = result['flows'][0]['scope']
        
        # Required fields
        assert 'programs' in scope
        assert 'copybooks' in scope
        assert 'datasets' in scope
        
        # All must be arrays
        assert isinstance(scope['programs'], list)
        assert isinstance(scope['copybooks'], list)
        assert isinstance(scope['datasets'], list)
        
        # Check content
        assert len(scope['programs']) == 3
        assert len(scope['copybooks']) == 2
        assert len(scope['datasets']) == 2
        
        # All items must be strings
        for program in scope['programs']:
            assert isinstance(program, str)
        for copybook in scope['copybooks']:
            assert isinstance(copybook, str)
        for dataset in scope['datasets']:
            assert isinstance(dataset, str)
    
    def test_interfaces_structure(self, test_db_with_complete_flow):
        """Test interfaces object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        interfaces = result['flows'][0]['interfaces']
        
        # Required fields
        assert 'inbound' in interfaces
        assert 'outbound' in interfaces
        
        # Both must be arrays
        assert isinstance(interfaces['inbound'], list)
        assert isinstance(interfaces['outbound'], list)
    
    def test_interface_object_structure(self, test_db_with_complete_flow):
        """Test individual interface object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        interfaces = result['flows'][0]['interfaces']
        
        # Check inbound interface
        if interfaces['inbound']:
            inbound = interfaces['inbound'][0]
            assert 'type' in inbound
            assert 'source' in inbound
            assert 'target' in inbound
            
            # external is optional
            # metadata is optional
        
        # Check outbound interface
        if interfaces['outbound']:
            outbound = interfaces['outbound'][0]
            assert 'type' in outbound
            assert 'source' in outbound
            assert 'target' in outbound
            assert 'external' in outbound
            assert outbound['external'] is True
    
    def test_data_operations_structure(self, test_db_with_complete_flow):
        """Test dataOperations object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        data_ops = result['flows'][0]['dataOperations']
        
        # Required fields
        assert 'databases' in data_ops
        assert 'datasets' in data_ops
        
        # Both must be arrays
        assert isinstance(data_ops['databases'], list)
        assert isinstance(data_ops['datasets'], list)
    
    def test_database_operation_structure(self, test_db_with_complete_flow):
        """Test database operation object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        databases = result['flows'][0]['dataOperations']['databases']
        
        assert len(databases) > 0
        
        for db_op in databases:
            assert 'type' in db_op
            assert 'operation' in db_op
            assert 'target' in db_op
            assert 'program' in db_op
            
            # All must be strings
            assert isinstance(db_op['type'], str)
            assert isinstance(db_op['operation'], str)
            assert isinstance(db_op['target'], str)
            assert isinstance(db_op['program'], str)
    
    def test_dataset_operation_structure(self, test_db_with_complete_flow):
        """Test dataset operation object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        datasets = result['flows'][0]['dataOperations']['datasets']
        
        assert len(datasets) > 0
        
        for ds_op in datasets:
            assert 'name' in ds_op
            assert 'mode' in ds_op
            assert 'programs' in ds_op
            
            # name and mode must be strings
            assert isinstance(ds_op['name'], str)
            assert isinstance(ds_op['mode'], str)
            
            # programs must be an array of strings
            assert isinstance(ds_op['programs'], list)
            for program in ds_op['programs']:
                assert isinstance(program, str)
    
    def test_complexity_structure(self, test_db_with_complete_flow):
        """Test complexity object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        complexity = result['flows'][0]['complexity']
        
        # Required fields
        assert 'totalPrograms' in complexity
        assert 'totalLines' in complexity
        assert 'cyclomaticComplexity' in complexity
        assert 'compositeScore' in complexity
        assert 'tier' in complexity
        
        # Check types
        assert isinstance(complexity['totalPrograms'], int)
        assert isinstance(complexity['totalLines'], int)
        assert isinstance(complexity['cyclomaticComplexity'], int)
        assert isinstance(complexity['compositeScore'], (int, float))
        assert isinstance(complexity['tier'], str)
        
        # Check values
        assert complexity['totalPrograms'] == 3
        assert complexity['totalLines'] == 2500
        assert complexity['cyclomaticComplexity'] == 45
        assert complexity['compositeScore'] == 67.5
        assert complexity['tier'] == 'MEDIUM'
    
    def test_dependencies_structure(self, test_db_with_complete_flow):
        """Test dependencies object structure."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        dependencies = result['flows'][0]['dependencies']
        
        # Required fields
        assert 'requiredFlows' in dependencies
        assert 'dependentFlows' in dependencies
        
        # Both must be arrays
        assert isinstance(dependencies['requiredFlows'], list)
        assert isinstance(dependencies['dependentFlows'], list)
        
        # All items must be strings
        for flow_id in dependencies['requiredFlows']:
            assert isinstance(flow_id, str)
        for flow_id in dependencies['dependentFlows']:
            assert isinstance(flow_id, str)
    
    def test_optional_fields_present(self, test_db_with_complete_flow):
        """Test that optional fields are included when available."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        flow = result['flows'][0]
        
        # Optional fields that should be present
        assert 'priority' in flow
        assert flow['priority'] == 1
        
        assert 'businessDomain' in flow
        assert flow['businessDomain'] == 'TestDomain'
        
        assert 'primaryType' in flow['entryPoint']
        assert flow['entryPoint']['primaryType'] == 'JCL'
    
    def test_optional_fields_absent(self):
        """Test that optional fields are omitted when not available."""
        conn = sqlite3.connect(':memory:')
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        cursor = conn.cursor()
        
        # Insert flow without optional fields
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_MINIMAL', 'Minimal Flow', 'MINPROG', None,
            1, 0, 0,
            100, 5, 10.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert minimal entry type
        cursor.execute("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, ('FLOW_MINIMAL', 'JCL', 'JOB1', None))
        
        # Insert minimal scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_MINIMAL', 'PROGRAM', 'MINPROG'))
        
        conn.commit()
        
        exporter = MigrationFlowExporter(conn)
        result = exporter.export_flows(['FLOW_MINIMAL'])
        flow = result['flows'][0]
        
        # Optional fields should not be present
        assert 'priority' not in flow
        assert 'businessDomain' not in flow
        assert 'primaryType' not in flow['entryPoint']
        
        conn.close()
    
    def test_json_serializable(self, test_db_with_complete_flow):
        """Test that exported data is JSON serializable."""
        exporter = MigrationFlowExporter(test_db_with_complete_flow)
        
        result = exporter.export_flows(['FLOW_COMPLETE'])
        
        # Should be able to serialize to JSON
        json_str = json.dumps(result, indent=2)
        
        # Should be able to deserialize
        parsed = json.loads(json_str)
        
        assert parsed == result
    
    def test_empty_arrays_for_missing_data(self):
        """Test that empty arrays are used when no data exists."""
        conn = sqlite3.connect(':memory:')
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        cursor = conn.cursor()
        
        # Insert flow with minimal data
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_EMPTY', 'Empty Flow', 'EMPTYPROG', 'JCL',
            1, 0, 0,
            100, 5, 10.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert minimal entry type
        cursor.execute("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, ('FLOW_EMPTY', 'JCL', 'JOB1', None))
        
        # Insert minimal scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_EMPTY', 'PROGRAM', 'EMPTYPROG'))
        
        # No interfaces, data operations, or dependencies
        
        conn.commit()
        
        exporter = MigrationFlowExporter(conn)
        result = exporter.export_flows(['FLOW_EMPTY'])
        flow = result['flows'][0]
        
        # Should have empty arrays
        assert flow['scope']['copybooks'] == []
        assert flow['scope']['datasets'] == []
        assert flow['interfaces']['inbound'] == []
        assert flow['interfaces']['outbound'] == []
        assert flow['dataOperations']['databases'] == []
        assert flow['dataOperations']['datasets'] == []
        assert flow['dependencies']['requiredFlows'] == []
        assert flow['dependencies']['dependentFlows'] == []
        
        conn.close()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
