"""
Unit tests for complexity calculation in migration flow builder.

Tests the calculate_flow_complexity() method which aggregates complexity
metrics across all programs in a flow.
"""

import pytest
import sqlite3
import tempfile
import os
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.connect(path)
    
    # Use MigrationFlowSchema to create required tables
    from tools.legacy_analyzer.migration.schema import MigrationFlowSchema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create complexity_metrics table (part of main schema, not migration schema)
    conn.execute("""
        CREATE TABLE complexity_metrics (
            program_name VARCHAR(44) PRIMARY KEY,
            lines_of_code INTEGER,
            total_lines INTEGER,
            cyclomatic_complexity INTEGER,
            dependency_count_in INTEGER,
            dependency_count_out INTEGER,
            composite_score REAL,
            complexity_tier VARCHAR(10),
            language_factor REAL,
            is_god_program INTEGER,
            analyzed_date TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.commit()
    
    yield conn
    
    conn.close()
    os.unlink(path)


@pytest.fixture
def builder(temp_db):
    """Create a MigrationFlowBuilder instance with temp database."""
    return MigrationFlowBuilder(temp_db)


def test_calculate_flow_complexity_single_program(builder, temp_db):
    """Test complexity calculation for a flow with a single program."""
    # Insert test data
    temp_db.execute("""
        INSERT INTO complexity_metrics 
        (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
        VALUES ('PROG1', 500, 25, 35.5, 'MEDIUM')
    """)
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1'])
    
    # Verify results
    assert result['totalPrograms'] == 1
    assert result['totalLines'] == 500
    assert result['cyclomaticComplexity'] == 25
    assert result['compositeScore'] > 0
    assert result['tier'] in ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH']


def test_calculate_flow_complexity_multiple_programs(builder, temp_db):
    """Test complexity calculation for a flow with multiple programs."""
    # Insert test data for multiple programs
    programs = [
        ('PROG1', 500, 25, 35.5, 'MEDIUM'),
        ('PROG2', 300, 15, 22.0, 'LOW'),
        ('PROG3', 800, 40, 55.0, 'HIGH')
    ]
    
    for prog_name, loc, cyclomatic, composite, tier in programs:
        temp_db.execute("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
            VALUES (?, ?, ?, ?, ?)
        """, (prog_name, loc, cyclomatic, composite, tier))
    
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1', 'PROG2', 'PROG3'])
    
    # Verify results
    assert result['totalPrograms'] == 3
    assert result['totalLines'] == 1600  # 500 + 300 + 800
    assert result['cyclomaticComplexity'] == 80  # 25 + 15 + 40
    assert result['compositeScore'] > 0
    assert result['tier'] in ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH']


def test_calculate_flow_complexity_missing_data(builder, temp_db):
    """Test complexity calculation when no complexity data exists."""
    # Don't insert any data
    
    # Calculate complexity for programs with no data
    result = builder.calculate_flow_complexity(['PROG1', 'PROG2'])
    
    # Verify results - should return defaults
    assert result['totalPrograms'] == 2
    assert result['totalLines'] == 0
    assert result['cyclomaticComplexity'] == 0
    # Composite score will include program count contribution
    assert result['compositeScore'] >= 0.0
    assert result['tier'] == 'UNKNOWN'


def test_calculate_flow_complexity_partial_data(builder, temp_db):
    """Test complexity calculation when only some programs have data."""
    # Insert data for only one program
    temp_db.execute("""
        INSERT INTO complexity_metrics 
        (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
        VALUES ('PROG1', 500, 25, 35.5, 'MEDIUM')
    """)
    temp_db.commit()
    
    # Calculate complexity for two programs (only one has data)
    result = builder.calculate_flow_complexity(['PROG1', 'PROG2'])
    
    # Verify results - should include data from PROG1 only
    assert result['totalPrograms'] == 2
    assert result['totalLines'] == 500  # Only PROG1's data
    assert result['cyclomaticComplexity'] == 25  # Only PROG1's data
    assert result['compositeScore'] > 0
    assert result['tier'] != 'UNKNOWN'  # Has some data


def test_calculate_flow_complexity_empty_program_list(builder, temp_db):
    """Test complexity calculation with empty program list."""
    # Calculate complexity for empty list
    result = builder.calculate_flow_complexity([])
    
    # Verify results
    assert result['totalPrograms'] == 0
    assert result['totalLines'] == 0
    assert result['cyclomaticComplexity'] == 0
    assert result['compositeScore'] == 0.0
    assert result['tier'] == 'UNKNOWN'


def test_calculate_flow_complexity_low_tier(builder, temp_db):
    """Test that low complexity programs result in LOW tier."""
    # Insert low complexity program
    temp_db.execute("""
        INSERT INTO complexity_metrics 
        (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
        VALUES ('PROG1', 100, 5, 8.0, 'LOW')
    """)
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1'])
    
    # Verify tier is LOW
    assert result['tier'] == 'LOW'
    assert result['compositeScore'] < 25


def test_calculate_flow_complexity_medium_tier(builder, temp_db):
    """Test that medium complexity programs result in MEDIUM tier."""
    # Insert medium complexity programs
    # Need higher values to reach MEDIUM tier (25-50)
    programs = [
        ('PROG1', 1000, 50, 35.5, 'MEDIUM'),
        ('PROG2', 1200, 60, 40.0, 'MEDIUM'),
        ('PROG3', 800, 40, 30.0, 'MEDIUM')
    ]
    
    for prog_name, loc, cyclomatic, composite, tier in programs:
        temp_db.execute("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
            VALUES (?, ?, ?, ?, ?)
        """, (prog_name, loc, cyclomatic, composite, tier))
    
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1', 'PROG2', 'PROG3'])
    
    # Verify tier is MEDIUM
    assert result['tier'] == 'MEDIUM'
    assert 25 <= result['compositeScore'] < 50


def test_calculate_flow_complexity_high_tier(builder, temp_db):
    """Test that high complexity programs result in HIGH tier."""
    # Insert high complexity programs
    # Need values to reach HIGH tier (50-75)
    programs = [
        ('PROG1', 1500, 75, 65.0, 'HIGH'),
        ('PROG2', 1800, 90, 70.0, 'HIGH'),
        ('PROG3', 1400, 70, 60.0, 'HIGH')
    ]
    
    for prog_name, loc, cyclomatic, composite, tier in programs:
        temp_db.execute("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
            VALUES (?, ?, ?, ?, ?)
        """, (prog_name, loc, cyclomatic, composite, tier))
    
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1', 'PROG2', 'PROG3'])
    
    # Verify tier is HIGH
    assert result['tier'] == 'HIGH'
    assert 50 <= result['compositeScore'] < 75


def test_calculate_flow_complexity_very_high_tier(builder, temp_db):
    """Test that very high complexity programs result in VERY_HIGH tier."""
    # Insert very high complexity programs
    programs = [
        ('PROG1', 3000, 150, 85.0, 'VERY_HIGH'),
        ('PROG2', 3500, 180, 90.0, 'VERY_HIGH'),
        ('PROG3', 2800, 140, 80.0, 'VERY_HIGH')
    ]
    
    for prog_name, loc, cyclomatic, composite, tier in programs:
        temp_db.execute("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
            VALUES (?, ?, ?, ?, ?)
        """, (prog_name, loc, cyclomatic, composite, tier))
    
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1', 'PROG2', 'PROG3'])
    
    # Verify tier is VERY_HIGH
    assert result['tier'] == 'VERY_HIGH'
    assert result['compositeScore'] >= 75


def test_calculate_flow_complexity_null_values(builder, temp_db):
    """Test complexity calculation with NULL values in database."""
    # Insert data with NULL values
    temp_db.execute("""
        INSERT INTO complexity_metrics 
        (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
        VALUES ('PROG1', NULL, NULL, NULL, 'UNKNOWN')
    """)
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1'])
    
    # Verify results - should handle NULLs gracefully
    assert result['totalPrograms'] == 1
    assert result['totalLines'] == 0  # NULL treated as 0
    assert result['cyclomaticComplexity'] == 0  # NULL treated as 0


def test_calculate_flow_complexity_large_flow(builder, temp_db):
    """Test complexity calculation for a large flow with many programs."""
    # Insert data for 20 programs
    programs = []
    for i in range(1, 21):
        prog_name = f'PROG{i:02d}'
        loc = 200 + (i * 50)
        cyclomatic = 10 + (i * 2)
        composite = 20.0 + (i * 1.5)
        tier = 'MEDIUM'
        programs.append((prog_name, loc, cyclomatic, composite, tier))
    
    for prog_name, loc, cyclomatic, composite, tier in programs:
        temp_db.execute("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
            VALUES (?, ?, ?, ?, ?)
        """, (prog_name, loc, cyclomatic, composite, tier))
    
    temp_db.commit()
    
    # Calculate complexity
    program_names = [f'PROG{i:02d}' for i in range(1, 21)]
    result = builder.calculate_flow_complexity(program_names)
    
    # Verify results
    assert result['totalPrograms'] == 20
    assert result['totalLines'] > 0
    assert result['cyclomaticComplexity'] > 0
    assert result['compositeScore'] > 0
    assert result['tier'] in ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH']


def test_calculate_flow_complexity_no_table(builder):
    """Test complexity calculation when complexity_metrics table doesn't exist."""
    # Create a new database without the complexity_metrics table
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.connect(path)
    
    # Use MigrationFlowSchema to create required tables (but not complexity_metrics)
    from tools.legacy_analyzer.migration.schema import MigrationFlowSchema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    conn.commit()
    
    builder_no_table = MigrationFlowBuilder(conn)
    
    try:
        # Calculate complexity
        result = builder_no_table.calculate_flow_complexity(['PROG1', 'PROG2'])
        
        # Verify results - should return defaults
        assert result['totalPrograms'] == 2
        assert result['totalLines'] == 0
        assert result['cyclomaticComplexity'] == 0
        assert result['compositeScore'] == 0.0
        assert result['tier'] == 'UNKNOWN'
    
    finally:
        conn.close()
        os.unlink(path)


def test_composite_score_calculation(builder, temp_db):
    """Test that composite score is calculated correctly."""
    # Insert test data with known values
    temp_db.execute("""
        INSERT INTO complexity_metrics 
        (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
        VALUES ('PROG1', 1000, 50, 45.0, 'MEDIUM')
    """)
    temp_db.commit()
    
    # Calculate complexity
    result = builder.calculate_flow_complexity(['PROG1'])
    
    # Verify composite score is calculated
    assert result['compositeScore'] > 0
    assert isinstance(result['compositeScore'], float)
    
    # Verify it's rounded to 2 decimal places
    assert result['compositeScore'] == round(result['compositeScore'], 2)


def test_complexity_tier_boundaries(builder, temp_db):
    """Test complexity tier boundary conditions."""
    # Test LOW/MEDIUM boundary (score = 25)
    temp_db.execute("""
        INSERT INTO complexity_metrics 
        (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
        VALUES ('PROG1', 2500, 250, 25.0, 'MEDIUM')
    """)
    temp_db.commit()
    
    result = builder.calculate_flow_complexity(['PROG1'])
    
    # At boundary, should be MEDIUM (>= 25)
    assert result['tier'] in ['MEDIUM', 'HIGH', 'VERY_HIGH']


def test_calculate_flow_complexity_deterministic(builder, temp_db):
    """Test that complexity calculation is deterministic."""
    # Insert test data
    programs = [
        ('PROG1', 500, 25, 35.5, 'MEDIUM'),
        ('PROG2', 300, 15, 22.0, 'LOW')
    ]
    
    for prog_name, loc, cyclomatic, composite, tier in programs:
        temp_db.execute("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, cyclomatic_complexity, composite_score, complexity_tier)
            VALUES (?, ?, ?, ?, ?)
        """, (prog_name, loc, cyclomatic, composite, tier))
    
    temp_db.commit()
    
    # Calculate complexity multiple times
    result1 = builder.calculate_flow_complexity(['PROG1', 'PROG2'])
    result2 = builder.calculate_flow_complexity(['PROG1', 'PROG2'])
    result3 = builder.calculate_flow_complexity(['PROG1', 'PROG2'])
    
    # Verify results are identical
    assert result1 == result2 == result3


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
