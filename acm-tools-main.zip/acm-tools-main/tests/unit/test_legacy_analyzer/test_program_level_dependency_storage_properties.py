"""Property-based tests for program-level dependency storage.

Feature: program-level-dependency-tracking, Property 2: Program-level dependency storage
"""

import pytest
import tempfile
import os
import json
from hypothesis import given, strategies as st, settings, HealthCheck
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.legacy_analyzer.program_level_dependency_loader import ProgramLevelDependencyLoader
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType
from tools.legacy_analyzer.models.dependency import Dependency, DependencyType


# Strategy for generating valid program names
@st.composite
def program_name_strategy(draw):
    """Generate valid program names (1-44 chars, alphanumeric)."""
    # Use a prefix to make names unique and avoid conflicts
    prefix = draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ', min_size=3, max_size=8))
    suffix = draw(st.text(alphabet='0123456789', min_size=2, max_size=6))
    return f"PROG_{prefix}_{suffix}"


# Strategy for generating program boundaries
@st.composite
def program_boundary_strategy(draw):
    """Generate valid ProgramBoundary objects."""
    program_name = draw(program_name_strategy())
    start_line = draw(st.integers(min_value=1, max_value=1000))
    end_line = draw(st.integers(min_value=start_line, max_value=start_line + 500))
    program_type = draw(st.sampled_from(list(ProgramType)))
    language = draw(st.sampled_from(['COBOL', 'PL/I', 'NATURAL', 'REXX', 'RPG', 'ASM']))
    entry_points = draw(st.lists(program_name_strategy(), max_size=3))
    
    return ProgramBoundary(
        program_name=program_name,
        start_line=start_line,
        end_line=end_line,
        program_type=program_type,
        language=language,
        entry_points=entry_points
    )


# Strategy for generating dependencies
@st.composite
def dependency_strategy(draw):
    """Generate valid Dependency objects."""
    source_name = draw(program_name_strategy())
    target_name = draw(program_name_strategy())
    dependency_types = [DependencyType.CALL, DependencyType.COPY, DependencyType.EXEC_PGM]
    target_types = ['PROGRAM', 'COPYBOOK', 'PROC']
    
    return Dependency(
        source_artifact=source_name,
        source_type='PROGRAM',
        target_artifact=target_name,
        target_type=draw(st.sampled_from(target_types)),
        dependency_type=draw(st.sampled_from(dependency_types)),
        line_number=draw(st.one_of(st.none(), st.integers(min_value=1, max_value=1000)))
    )


# Strategy for generating program dependency records for bulk insert
@st.composite
def program_dependency_record_strategy(draw):
    """Generate valid program dependency records for bulk insert."""
    source_program = draw(program_name_strategy())
    target_program = draw(program_name_strategy())
    file_path = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd', 'P'), max_codepoint=127),
        min_size=1,
        max_size=255
    ))
    
    dependency_types = ['CALL', 'COPY', 'EXEC', 'FETCH', 'INCLUDE', 'LINK']
    target_types = ['PROGRAM', 'COPYBOOK', 'PROC', 'MODULE', 'SUBROUTINE']
    
    return {
        'source_program_name': source_program,
        'source_file_path': file_path,
        'target_program_name': target_program,
        'target_artifact_type': draw(st.sampled_from(target_types)),
        'dependency_type': draw(st.sampled_from(dependency_types)),
        'line_number': draw(st.one_of(st.none(), st.integers(min_value=1, max_value=1000)))
    }


class TestProgramLevelDependencyStorageProperties:
    """Property-based tests for program-level dependency storage."""
    
    @pytest.fixture
    def temp_db(self):
        """Create a temporary database for testing."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = SQLiteAdapter(db_path)
        db.connect()
        
        # Create dependencies schema
        loader = ProgramLevelDependencyLoader(db)
        loader.create_dependencies_schema()
        
        # Create program_file_mapping table with all required columns
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_file_mapping (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER NOT NULL,
                program_name VARCHAR(44) NOT NULL,
                program_index INTEGER NOT NULL,
                start_line INTEGER NOT NULL,
                end_line INTEGER NOT NULL,
                program_type VARCHAR(20) NOT NULL,
                language VARCHAR(20) NOT NULL,
                entry_points TEXT,
                lines_of_code INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(file_id, program_name),
                FOREIGN KEY (file_id) REFERENCES inventory(id)
            )
        """)
        db.commit()
        
        yield db
        
        # Cleanup
        db.close()
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=1, max_size=10, unique_by=lambda x: x.program_name),
        file_path=st.text(
            alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/',
            min_size=10,
            max_size=50
        ).map(lambda x: f"/test/source/{x}.cbl")
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_program_level_dependency_storage(self, temp_db, programs, file_path):
        """
        Feature: program-level-dependency-tracking, Property 2: Program-level dependency storage
        
        Validates: Requirements 1.5
        
        For any analyzed program, dependencies should be stored using individual 
        program names as source and target artifacts rather than file names.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        cursor.execute("DELETE FROM inventory")
        temp_db.commit()
        
        # Add file to inventory (required for program_file_mapping foreign key)
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path, language)
            VALUES (?, 'FILE', ?, 'COBOL')
        """, (os.path.basename(file_path), file_path))
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Generate dependencies for each program
        dependencies = {}
        for program in programs:
            # Generate 1-3 dependencies per program
            program_deps = []
            for i in range(min(3, len(programs))):
                if i < len(programs) - 1:
                    target_program = programs[i + 1]
                    dep = Dependency(
                        source_artifact=program.program_name,
                        source_type='PROGRAM',
                        target_artifact=target_program.program_name,
                        target_type='PROGRAM',
                        dependency_type=DependencyType.CALL,
                        line_number=program.start_line + 10
                    )
                    program_deps.append(dep)
            dependencies[program.program_name] = program_deps
        
        # Store program dependencies
        stats = loader.store_program_dependencies(file_path, programs, dependencies)
        
        # Verify storage succeeded
        assert stats['errors'] == 0
        assert stats['programs_processed'] == len(programs)
        assert stats['programs_stored'] == len(programs)
        
        # Get file_id for querying
        cursor.execute("SELECT id FROM inventory WHERE file_path = ?", (file_path,))
        file_id = cursor.fetchone()[0]
        
        # Verify programs are stored in program_file_mapping
        cursor.execute("SELECT COUNT(*) FROM program_file_mapping WHERE file_id = ?", (file_id,))
        program_count = cursor.fetchone()[0]
        assert program_count == len(programs)
        
        # Verify dependencies use program names, not file names
        cursor.execute("""
            SELECT source_artifact_name, source_artifact_type, target_artifact_name 
            FROM artifact_dependencies 
            WHERE source_file_path = ?
        """, (file_path,))
        
        stored_deps = cursor.fetchall()
        
        # All source artifacts should be program names and type should be 'PROGRAM'
        program_names = {prog.program_name for prog in programs}
        for source_name, source_type, target_name in stored_deps:
            assert source_type == 'PROGRAM'
            assert source_name in program_names  # Source should be a program name, not file name
            assert source_name != file_path  # Should not be the file path
    
    @given(
        dependency_records=st.lists(program_dependency_record_strategy(), min_size=1, max_size=50)
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_bulk_insert_program_dependencies(self, temp_db, dependency_records):
        """
        Feature: program-level-dependency-tracking, Property 2: Program-level dependency storage
        
        Validates: Requirements 1.5
        
        For any bulk insert of program dependencies, all dependencies should be 
        stored using individual program names as source artifacts.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Bulk insert program dependencies
        stats = loader.bulk_insert_program_dependencies(dependency_records, skip_duplicates=True)
        
        # Verify insertion succeeded
        assert stats['processed'] == len(dependency_records)
        assert stats['errors'] == 0
        
        # Verify all stored dependencies use program names as source artifacts
        cursor = temp_db.cursor()
        cursor.execute("""
            SELECT source_artifact_name, source_artifact_type, target_artifact_name 
            FROM artifact_dependencies
        """)
        
        stored_deps = cursor.fetchall()
        
        # Extract expected program names from input records
        expected_program_names = {rec['source_program_name'] for rec in dependency_records 
                                if rec.get('source_program_name', '').strip()}
        
        # All source artifacts should be program names and type should be 'PROGRAM'
        for source_name, source_type, target_name in stored_deps:
            assert source_type == 'PROGRAM'
            assert source_name in expected_program_names
            # Verify it's not a file path (shouldn't contain common file path characters)
            assert '/' not in source_name and '\\' not in source_name
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=2, max_size=5, unique_by=lambda x: x.program_name),
        file_path=st.text(
            alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/',
            min_size=10,
            max_size=50
        ).map(lambda x: f"/test/source/{x}.cbl")
    )
    @settings(
        max_examples=50,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_program_file_mapping_consistency(self, temp_db, programs, file_path):
        """
        Feature: program-level-dependency-tracking, Property 2: Program-level dependency storage
        
        Validates: Requirements 1.5
        
        For any program stored with dependencies, the program-file mapping should 
        maintain consistent program names across both tables.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        cursor.execute("DELETE FROM inventory")
        temp_db.commit()
        
        # Add file to inventory (required for program_file_mapping foreign key)
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path, language)
            VALUES (?, 'FILE', ?, 'COBOL')
        """, (os.path.basename(file_path), file_path))
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Create cross-program dependencies
        dependencies = {}
        for i, program in enumerate(programs):
            program_deps = []
            # Each program calls the next one (circular for last)
            next_idx = (i + 1) % len(programs)
            target_program = programs[next_idx]
            
            dep = Dependency(
                source_artifact=program.program_name,
                source_type='PROGRAM',
                target_artifact=target_program.program_name,
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL,
                line_number=program.start_line + 5
            )
            program_deps.append(dep)
            dependencies[program.program_name] = program_deps
        
        # Store program dependencies
        stats = loader.store_program_dependencies(file_path, programs, dependencies)
        assert stats['errors'] == 0
        
        # Get file_id for querying
        cursor.execute("SELECT id FROM inventory WHERE file_path = ?", (file_path,))
        file_id = cursor.fetchone()[0]
        
        # Verify consistency between program_file_mapping and artifact_dependencies
        cursor = temp_db.cursor()
        
        # Get program names from program_file_mapping
        cursor.execute("SELECT program_name FROM program_file_mapping WHERE file_id = ?", (file_id,))
        mapping_programs = {row[0] for row in cursor.fetchall()}
        
        # Get source program names from artifact_dependencies
        cursor.execute("""
            SELECT DISTINCT source_artifact_name 
            FROM artifact_dependencies 
            WHERE source_file_path = ? AND source_artifact_type = 'PROGRAM'
        """, (file_path,))
        dependency_programs = {row[0] for row in cursor.fetchall()}
        
        # All programs with dependencies should exist in program_file_mapping
        assert dependency_programs.issubset(mapping_programs)
        
        # All programs should be represented consistently
        expected_programs = {prog.program_name for prog in programs}
        assert mapping_programs == expected_programs


if __name__ == '__main__':
    pytest.main([__file__, '-v'])