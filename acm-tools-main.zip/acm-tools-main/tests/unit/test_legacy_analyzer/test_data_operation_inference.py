"""
Unit tests for DataOperationInferencer.

Tests data operation inference from artifact_dependencies table.
"""

import pytest
import sqlite3
from tools.legacy_analyzer.migration.data_operation_inferencer import DataOperationInferencer


class TestDataOperationInferencer:
    """Test suite for DataOperationInferencer class."""
    
    def setup_method(self):
        """Set up test database before each test."""
        self.conn = sqlite3.connect(':memory:')
        self.cursor = self.conn.cursor()
        
        # Create artifact_dependencies table
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_artifact_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_artifact_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(20) NOT NULL,
                source_file_path VARCHAR(255),
                target_file_path VARCHAR(255),
                line_number INTEGER
            )
        """)
        
        self.conn.commit()
        self.inferencer = DataOperationInferencer(self.conn)
    
    def teardown_method(self):
        """Clean up after each test."""
        self.conn.close()
    
    def _insert_dependency(self, source_name, source_type, target_name, 
                          target_type, dep_type):
        """Helper to insert a dependency."""
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, (source_name, source_type, target_name, target_type, dep_type))
        self.conn.commit()
    
    # Test SQL Operation Parsing
    
    def test_parse_sql_select(self):
        """Test parsing SELECT statement."""
        result = self.inferencer._parse_sql_operation("SELECT * FROM CUSTOMER")
        assert result == "SELECT"
    
    def test_parse_sql_insert(self):
        """Test parsing INSERT statement."""
        result = self.inferencer._parse_sql_operation("INSERT INTO CUSTOMER VALUES (...)")
        assert result == "INSERT"
    
    def test_parse_sql_update(self):
        """Test parsing UPDATE statement."""
        result = self.inferencer._parse_sql_operation("UPDATE CUSTOMER SET NAME = 'TEST'")
        assert result == "UPDATE"
    
    def test_parse_sql_delete(self):
        """Test parsing DELETE statement."""
        result = self.inferencer._parse_sql_operation("DELETE FROM CUSTOMER WHERE ID = 1")
        assert result == "DELETE"
    
    def test_parse_sql_merge(self):
        """Test parsing MERGE statement."""
        result = self.inferencer._parse_sql_operation("MERGE INTO CUSTOMER USING ...")
        assert result == "MERGE"
    
    def test_parse_sql_unknown(self):
        """Test parsing unknown SQL or table name defaults to SELECT."""
        result = self.inferencer._parse_sql_operation("CUSTOMER_TABLE")
        assert result == "SELECT"
    
    def test_parse_sql_empty(self):
        """Test parsing empty SQL statement."""
        result = self.inferencer._parse_sql_operation("")
        assert result == "UNKNOWN"
    
    # Test Table Name Extraction
    
    def test_extract_table_from_select(self):
        """Test extracting table name from SELECT statement."""
        result = self.inferencer._extract_table_from_sql("SELECT * FROM CUSTOMER WHERE ID = 1")
        assert result == "CUSTOMER"
    
    def test_extract_table_from_insert(self):
        """Test extracting table name from INSERT statement."""
        result = self.inferencer._extract_table_from_sql("INSERT INTO EMPLOYEE VALUES (1, 'JOHN')")
        assert result == "EMPLOYEE"
    
    def test_extract_table_from_update(self):
        """Test extracting table name from UPDATE statement."""
        result = self.inferencer._extract_table_from_sql("UPDATE PAYROLL SET AMOUNT = 1000")
        assert result == "PAYROLL"
    
    def test_extract_table_from_delete(self):
        """Test extracting table name from DELETE statement."""
        result = self.inferencer._extract_table_from_sql("DELETE FROM ORDERS WHERE ID = 5")
        assert result == "ORDERS"
    
    def test_extract_table_plain_name(self):
        """Test extracting plain table name."""
        result = self.inferencer._extract_table_from_sql("CUSTOMER_TABLE")
        assert result == "CUSTOMER_TABLE"
    
    def test_extract_table_none(self):
        """Test extracting from None."""
        result = self.inferencer._extract_table_from_sql(None)
        assert result is None
    
    # Test CICS Operation Mapping
    
    def test_infer_cics_read(self):
        """Test inferring CICS READ operation."""
        result = self.inferencer._infer_operation_type("CICS_READ", "CUSTFILE")
        assert result == "READ"
    
    def test_infer_cics_write(self):
        """Test inferring CICS WRITE operation."""
        result = self.inferencer._infer_operation_type("CICS_WRITE", "CUSTFILE")
        assert result == "WRITE"
    
    def test_infer_cics_rewrite(self):
        """Test inferring CICS REWRITE operation."""
        result = self.inferencer._infer_operation_type("CICS_REWRITE", "CUSTFILE")
        assert result == "UPDATE"
    
    def test_infer_cics_delete(self):
        """Test inferring CICS DELETE operation."""
        result = self.inferencer._infer_operation_type("CICS_DELETE", "CUSTFILE")
        assert result == "DELETE"
    
    def test_infer_cics_startbr(self):
        """Test inferring CICS STARTBR operation."""
        result = self.inferencer._infer_operation_type("CICS_STARTBR", "CUSTFILE")
        assert result == "READ"
    
    def test_infer_cics_readnext(self):
        """Test inferring CICS READNEXT operation."""
        result = self.inferencer._infer_operation_type("CICS_READNEXT", "CUSTFILE")
        assert result == "READ"
    
    # Test Database Type Inference
    
    def test_infer_db_type_db2(self):
        """Test inferring DB2 database type."""
        result = self.inferencer._infer_db_type("EXEC_SQL_DB2", "TABLE")
        assert result == "DB2"
    
    def test_infer_db_type_ims(self):
        """Test inferring IMS database type."""
        result = self.inferencer._infer_db_type("IMS_DLI", "SEGMENT")
        assert result == "IMS"
    
    def test_infer_db_type_vsam(self):
        """Test inferring VSAM database type from CICS."""
        result = self.inferencer._infer_db_type("CICS_READ", "FILE")
        assert result == "VSAM"
    
    def test_infer_db_type_default(self):
        """Test default database type inference."""
        result = self.inferencer._infer_db_type("EXEC_SQL", "TABLE")
        assert result == "SQL"
    
    # Test Dataset Mode Inference
    
    def test_infer_dataset_mode_read(self):
        """Test inferring INPUT mode from READ dependency."""
        result = self.inferencer._infer_dataset_mode("FILE_READ", "EMPLOYEE.MASTER")
        assert result == "INPUT"
    
    def test_infer_dataset_mode_write(self):
        """Test inferring OUTPUT mode from WRITE dependency."""
        result = self.inferencer._infer_dataset_mode("FILE_WRITE", "PAYROLL.REPORT")
        assert result == "OUTPUT"
    
    def test_infer_dataset_mode_disp_shr(self):
        """Test inferring INPUT mode from DISP=SHR."""
        result = self.inferencer._infer_dataset_mode("JCL_DD", "EMPLOYEE.MASTER DISP=SHR")
        assert result == "INPUT"
    
    def test_infer_dataset_mode_disp_old(self):
        """Test inferring INOUT mode from DISP=OLD."""
        result = self.inferencer._infer_dataset_mode("JCL_DD", "EMPLOYEE.MASTER DISP=OLD")
        assert result == "INOUT"
    
    def test_infer_dataset_mode_disp_new(self):
        """Test inferring OUTPUT mode from DISP=NEW."""
        result = self.inferencer._infer_dataset_mode("JCL_DD", "PAYROLL.REPORT DISP=NEW")
        assert result == "OUTPUT"
    
    def test_infer_dataset_mode_disp_mod(self):
        """Test inferring OUTPUT mode from DISP=MOD."""
        result = self.inferencer._infer_dataset_mode("JCL_DD", "PAYROLL.REPORT DISP=MOD")
        assert result == "OUTPUT"
    
    def test_infer_dataset_mode_default(self):
        """Test default dataset mode inference."""
        result = self.inferencer._infer_dataset_mode("DATASET", "EMPLOYEE.MASTER")
        assert result == "INOUT"
    
    # Test Dataset Name Extraction
    
    def test_extract_dataset_name_simple(self):
        """Test extracting simple dataset name."""
        result = self.inferencer._extract_dataset_name("EMPLOYEE.MASTER")
        assert result == "EMPLOYEE.MASTER"
    
    def test_extract_dataset_name_with_dd_prefix(self):
        """Test extracting dataset name with DD: prefix."""
        result = self.inferencer._extract_dataset_name("DD:EMPFILE")
        assert result == "EMPFILE"
    
    def test_extract_dataset_name_with_ddname_prefix(self):
        """Test extracting dataset name with DDNAME: prefix."""
        result = self.inferencer._extract_dataset_name("DDNAME:PAYFILE")
        assert result == "PAYFILE"
    
    def test_extract_dataset_name_none(self):
        """Test extracting from None."""
        result = self.inferencer._extract_dataset_name(None)
        assert result is None
    
    def test_extract_dataset_name_empty(self):
        """Test extracting from empty string."""
        result = self.inferencer._extract_dataset_name("")
        assert result is None
    
    # Test Database Operations Inference
    
    def test_infer_database_operations_sql_select(self):
        """Test inferring SQL SELECT operation."""
        self._insert_dependency(
            "PAYROLL1", "PROGRAM",
            "SELECT * FROM EMPLOYEE", "TABLE",
            "EXEC_SQL"
        )
        
        operations = self.inferencer.infer_database_operations(["PAYROLL1"])
        
        assert len(operations) == 1
        assert operations[0]['type'] == "SQL"
        assert operations[0]['operation'] == "SELECT"
        assert operations[0]['target'] == "EMPLOYEE"
        assert operations[0]['program'] == "PAYROLL1"
    
    def test_infer_database_operations_cics_read(self):
        """Test inferring CICS READ operation."""
        self._insert_dependency(
            "BILLING1", "PROGRAM",
            "CUSTFILE", "FILE",
            "CICS_READ"
        )
        
        operations = self.inferencer.infer_database_operations(["BILLING1"])
        
        assert len(operations) == 1
        assert operations[0]['type'] == "VSAM"
        assert operations[0]['operation'] == "READ"
        assert operations[0]['target'] == "CUSTFILE"
        assert operations[0]['program'] == "BILLING1"
    
    def test_infer_database_operations_cics_write(self):
        """Test inferring CICS WRITE operation."""
        self._insert_dependency(
            "ACCTPROG", "PROGRAM",
            "ACCTFILE", "FILE",
            "CICS_WRITE"
        )
        
        operations = self.inferencer.infer_database_operations(["ACCTPROG"])
        
        assert len(operations) == 1
        assert operations[0]['type'] == "VSAM"
        assert operations[0]['operation'] == "WRITE"
        assert operations[0]['target'] == "ACCTFILE"
    
    def test_infer_database_operations_multiple_programs(self):
        """Test inferring operations for multiple programs."""
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "SELECT * FROM TABLE1", "TABLE",
            "EXEC_SQL"
        )
        self._insert_dependency(
            "PROG2", "PROGRAM",
            "INSERT INTO TABLE2 VALUES (...)", "TABLE",
            "EXEC_SQL"
        )
        
        operations = self.inferencer.infer_database_operations(["PROG1", "PROG2"])
        
        assert len(operations) == 2
        assert any(op['program'] == "PROG1" and op['operation'] == "SELECT" for op in operations)
        assert any(op['program'] == "PROG2" and op['operation'] == "INSERT" for op in operations)
    
    def test_infer_database_operations_empty_programs(self):
        """Test inferring operations with empty program list."""
        operations = self.inferencer.infer_database_operations([])
        assert operations == []
    
    def test_infer_database_operations_no_matches(self):
        """Test inferring operations with no matching dependencies."""
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "COPY1", "COPYBOOK",
            "COPY"
        )
        
        operations = self.inferencer.infer_database_operations(["PROG1"])
        assert operations == []
    
    # Test Dataset Operations Inference
    
    def test_infer_dataset_operations_single_program(self):
        """Test inferring dataset operations for single program."""
        self._insert_dependency(
            "PAYROLL1", "PROGRAM",
            "EMPLOYEE.MASTER", "DATASET",
            "FILE_READ"
        )
        
        operations = self.inferencer.infer_dataset_operations(["PAYROLL1"])
        
        assert len(operations) == 1
        assert operations[0]['name'] == "EMPLOYEE.MASTER"
        assert operations[0]['mode'] == "INPUT"
        assert "PAYROLL1" in operations[0]['programs']
    
    def test_infer_dataset_operations_multiple_programs_same_dataset(self):
        """Test inferring dataset operations with multiple programs accessing same dataset."""
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "SHARED.DATA", "DATASET",
            "FILE_READ"
        )
        self._insert_dependency(
            "PROG2", "PROGRAM",
            "SHARED.DATA", "DATASET",
            "FILE_WRITE"
        )
        
        operations = self.inferencer.infer_dataset_operations(["PROG1", "PROG2"])
        
        assert len(operations) == 1
        assert operations[0]['name'] == "SHARED.DATA"
        assert operations[0]['mode'] == "INOUT"  # Both INPUT and OUTPUT
        assert "PROG1" in operations[0]['programs']
        assert "PROG2" in operations[0]['programs']
    
    def test_infer_dataset_operations_input_only(self):
        """Test inferring INPUT-only dataset."""
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "INPUT.DATA", "DATASET",
            "FILE_READ"
        )
        
        operations = self.inferencer.infer_dataset_operations(["PROG1"])
        
        assert len(operations) == 1
        assert operations[0]['mode'] == "INPUT"
    
    def test_infer_dataset_operations_output_only(self):
        """Test inferring OUTPUT-only dataset."""
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "OUTPUT.DATA", "DATASET",
            "FILE_WRITE"
        )
        
        operations = self.inferencer.infer_dataset_operations(["PROG1"])
        
        assert len(operations) == 1
        assert operations[0]['mode'] == "OUTPUT"
    
    def test_infer_dataset_operations_sorted_by_name(self):
        """Test that dataset operations are sorted by name."""
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "ZEBRA.DATA", "DATASET",
            "FILE_READ"
        )
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "ALPHA.DATA", "DATASET",
            "FILE_READ"
        )
        
        operations = self.inferencer.infer_dataset_operations(["PROG1"])
        
        assert len(operations) == 2
        assert operations[0]['name'] == "ALPHA.DATA"
        assert operations[1]['name'] == "ZEBRA.DATA"
    
    def test_infer_dataset_operations_empty_programs(self):
        """Test inferring dataset operations with empty program list."""
        operations = self.inferencer.infer_dataset_operations([])
        assert operations == []
    
    # Test All Operations Inference
    
    def test_infer_all_operations(self):
        """Test inferring all operations (databases and datasets)."""
        # Add database operation
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "SELECT * FROM CUSTOMER", "TABLE",
            "EXEC_SQL"
        )
        
        # Add dataset operation
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "EMPLOYEE.MASTER", "DATASET",
            "FILE_READ"
        )
        
        operations = self.inferencer.infer_all_operations(["PROG1"])
        
        assert 'databases' in operations
        assert 'datasets' in operations
        assert len(operations['databases']) == 1
        assert len(operations['datasets']) == 1
    
    # Test Operation Summary
    
    def test_get_operation_summary(self):
        """Test getting operation summary statistics."""
        # Add database operations
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "SELECT * FROM TABLE1", "TABLE",
            "EXEC_SQL"
        )
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "INSERT INTO TABLE2 VALUES (...)", "TABLE",
            "EXEC_SQL"
        )
        
        # Add dataset operations
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "DATASET1", "DATASET",
            "FILE_READ"
        )
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "DATASET2", "DATASET",
            "FILE_WRITE"
        )
        
        summary = self.inferencer.get_operation_summary(["PROG1"])
        
        assert summary['total_database_operations'] == 2
        assert summary['total_datasets'] == 2
        assert summary['unique_tables'] == 2
        assert summary['unique_datasets'] == 2
    
    def test_get_operation_summary_duplicates(self):
        """Test operation summary with duplicate tables/datasets."""
        # Same table accessed twice
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "SELECT * FROM CUSTOMER", "TABLE",
            "EXEC_SQL"
        )
        self._insert_dependency(
            "PROG1", "PROGRAM",
            "UPDATE CUSTOMER SET ...", "TABLE",
            "EXEC_SQL"
        )
        
        summary = self.inferencer.get_operation_summary(["PROG1"])
        
        assert summary['total_database_operations'] == 2
        assert summary['unique_tables'] == 1  # Only one unique table
    
    # Test VSAM File Operations
    
    def test_handle_vsam_operations(self):
        """Test handling VSAM file operations via CICS."""
        self._insert_dependency(
            "VSAMTEST", "PROGRAM",
            "VSAMFILE", "FILE",
            "CICS_READ"
        )
        self._insert_dependency(
            "VSAMTEST", "PROGRAM",
            "VSAMFILE", "FILE",
            "CICS_WRITE"
        )
        
        operations = self.inferencer.infer_database_operations(["VSAMTEST"])
        
        assert len(operations) == 2
        assert all(op['type'] == "VSAM" for op in operations)
        assert any(op['operation'] == "READ" for op in operations)
        assert any(op['operation'] == "WRITE" for op in operations)
    
    def test_handle_vsam_browse_operations(self):
        """Test handling VSAM browse operations."""
        self._insert_dependency(
            "BROWSE", "PROGRAM",
            "VSAMFILE", "FILE",
            "CICS_STARTBR"
        )
        self._insert_dependency(
            "BROWSE", "PROGRAM",
            "VSAMFILE", "FILE",
            "CICS_READNEXT"
        )
        
        operations = self.inferencer.infer_database_operations(["BROWSE"])
        
        assert len(operations) == 2
        assert all(op['operation'] == "READ" for op in operations)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
