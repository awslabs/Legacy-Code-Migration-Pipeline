"""
Property-based tests for auto-detection of external programs

Tests cover:
- Property 11: Auto-Detection Inserts External Programs
  For any program called by the flow that has no source code, the system SHALL
  insert it into the outbound_interfaces table with reason="missing_source_code".
"""

import sqlite3
import tempfile
import os
from hypothesis import given, strategies as st, settings, assume

from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder


def create_test_database():
    """Helper function to create a test database with all required tables."""
    fd, temp_db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(temp_db_path)
    cursor = conn.cursor()
    
    # Create schema
    schema_manager = InterfaceSchemaManager(conn)
    schema_manager.create_tables()
    
    # Create external_program_config table (required by ExternalConfigLoader)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS external_program_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern VARCHAR(100) NOT NULL,
            program_type VARCHAR(50),
            scope VARCHAR(20),
            is_pattern BOOLEAN DEFAULT FALSE,
            created_date DATE
        )
    """)
    
    # Create external_caller_config table (required by ExternalConfigLoader)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS external_caller_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            caller_name VARCHAR(100) NOT NULL,
            target_program VARCHAR(44) NOT NULL,
            call_type VARCHAR(20),
            metadata_json TEXT,
            created_date DATE
        )
    """)
    
    # Create artifact_dependencies table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS artifact_dependencies (
            source_artifact_name TEXT,
            source_artifact_type TEXT,
            target_artifact_name TEXT,
            target_artifact_type TEXT,
            dependency_type TEXT,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            language TEXT
        )
    """)
    
    conn.commit()
    return conn, temp_db_path


@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        min_size=1,
        max_size=10,
        unique=True
    ),
    called_programs_with_source=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        min_size=0,
        max_size=5,
        unique=True
    ),
    called_programs_without_source=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        min_size=1,
        max_size=5,
        unique=True
    )
)
@settings(max_examples=100)
def test_property_auto_detection_inserts_external_programs(
    flow_programs,
    called_programs_with_source,
    called_programs_without_source
):
    """
    Property: For any program called by the flow that has no source code,
    the system SHALL insert it into the outbound_interfaces table with
    reason="missing_source_code".
    
    **Feature: fix-inbound-interface-logic, Property 11: Auto-Detection Inserts External Programs**
    **Validates: Requirements 9.1**
    """
    # Ensure no overlap between the three sets
    assume(len(set(flow_programs) & set(called_programs_with_source)) == 0)
    assume(len(set(flow_programs) & set(called_programs_without_source)) == 0)
    assume(len(set(called_programs_with_source) & set(called_programs_without_source)) == 0)
    
    conn, temp_db_path = create_test_database()
    cursor = conn.cursor()
    
    try:
        # Insert flow programs as sources (they have source code)
        for prog in flow_programs:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'PROGRAM', 'DUMMY', 'COPYBOOK', 'COPY')
            """, (prog,))
            
            cursor.execute("""
                INSERT INTO program_file_mapping (program_name, file_path, language)
                VALUES (?, ?, 'COBOL')
            """, (prog, f'/path/to/{prog}.cbl'))
        
        # Insert calls from flow programs to programs WITH source code
        for called_prog in called_programs_with_source:
            # Add to program_file_mapping (has source code)
            cursor.execute("""
                INSERT INTO program_file_mapping (program_name, file_path, language)
                VALUES (?, ?, 'COBOL')
            """, (called_prog, f'/path/to/{called_prog}.cbl'))
            
            # Add dependency from a flow program
            if flow_programs:
                cursor.execute("""
                    INSERT INTO artifact_dependencies 
                    (source_artifact_name, source_artifact_type, target_artifact_name, 
                     target_artifact_type, dependency_type)
                    VALUES (?, 'PROGRAM', ?, 'PROGRAM', 'PROGRAM_CALL')
                """, (flow_programs[0], called_prog))
        
        # Insert calls from flow programs to programs WITHOUT source code
        for called_prog in called_programs_without_source:
            # Do NOT add to program_file_mapping (no source code)
            # Add dependency from a flow program
            if flow_programs:
                cursor.execute("""
                    INSERT INTO artifact_dependencies 
                    (source_artifact_name, source_artifact_type, target_artifact_name, 
                     target_artifact_type, dependency_type)
                    VALUES (?, 'PROGRAM', ?, 'PROGRAM', 'PROGRAM_CALL')
                """, (flow_programs[0], called_prog))
        
        conn.commit()
        
        # Create flow builder and call auto-detection
        flow_builder = MigrationFlowBuilder(conn)
        detected_count = flow_builder._auto_detect_external_programs(set(flow_programs))
        
        # Verify: detected_count should equal number of programs without source code
        assert detected_count == len(called_programs_without_source), \
            f"Expected {len(called_programs_without_source)} programs detected, got {detected_count}"
        
        # Verify: All programs without source code should be in outbound_interfaces
        cursor.execute("""
            SELECT program_name, reason 
            FROM outbound_interfaces
        """)
        
        outbound_programs = cursor.fetchall()
        outbound_program_names = {row[0] for row in outbound_programs}
        outbound_reasons = {row[0]: row[1] for row in outbound_programs}
        
        for prog in called_programs_without_source:
            assert prog in outbound_program_names, \
                f"Program {prog} without source code should be in outbound_interfaces"
            assert outbound_reasons[prog] == 'missing_source_code', \
                f"Program {prog} should have reason='missing_source_code'"
        
        # Verify: Programs WITH source code should NOT be in outbound_interfaces
        for prog in called_programs_with_source:
            assert prog not in outbound_program_names, \
                f"Program {prog} with source code should NOT be in outbound_interfaces"
        
        # Verify: Flow programs should NOT be in outbound_interfaces
        for prog in flow_programs:
            assert prog not in outbound_program_names, \
                f"Flow program {prog} should NOT be in outbound_interfaces"
    
    finally:
        conn.close()
        try:
            os.unlink(temp_db_path)
        except:
            pass


@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        min_size=1,
        max_size=10,
        unique=True
    ),
    external_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        min_size=1,
        max_size=5,
        unique=True
    ),
    num_runs=st.integers(min_value=2, max_value=5)
)
@settings(max_examples=100)
def test_property_auto_detection_prevents_duplicates(
    flow_programs,
    external_programs,
    num_runs
):
    """
    Property: For any external program auto-detected multiple times,
    it should be inserted exactly once into the database.
    
    **Feature: fix-inbound-interface-logic, Property 11: Auto-Detection Inserts External Programs**
    **Validates: Requirements 9.2**
    """
    # Ensure no overlap
    assume(len(set(flow_programs) & set(external_programs)) == 0)
    
    conn, temp_db_path = create_test_database()
    cursor = conn.cursor()
    
    try:
        # Insert flow programs
        for prog in flow_programs:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'PROGRAM', 'DUMMY', 'COPYBOOK', 'COPY')
            """, (prog,))
            
            cursor.execute("""
                INSERT INTO program_file_mapping (program_name, file_path, language)
                VALUES (?, ?, 'COBOL')
            """, (prog, f'/path/to/{prog}.cbl'))
        
        # Insert calls to external programs (no source code)
        for ext_prog in external_programs:
            if flow_programs:
                cursor.execute("""
                    INSERT INTO artifact_dependencies 
                    (source_artifact_name, source_artifact_type, target_artifact_name, 
                     target_artifact_type, dependency_type)
                    VALUES (?, 'PROGRAM', ?, 'PROGRAM', 'PROGRAM_CALL')
                """, (flow_programs[0], ext_prog))
        
        conn.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(conn)
        
        # Run auto-detection multiple times
        total_detected = 0
        for _ in range(num_runs):
            detected = flow_builder._auto_detect_external_programs(set(flow_programs))
            total_detected += detected
        
        # Verify: First run should detect all external programs
        # Subsequent runs should detect 0 (duplicates prevented)
        # Total detected should equal number of external programs
        assert total_detected == len(external_programs), \
            f"Expected total {len(external_programs)} detected across {num_runs} runs, got {total_detected}"
        
        # Verify: Each external program appears exactly once in database
        cursor.execute("""
            SELECT program_name, COUNT(*) as count
            FROM outbound_interfaces
            GROUP BY program_name
        """)
        
        program_counts = cursor.fetchall()
        
        for prog_name, count in program_counts:
            assert count == 1, \
                f"Program {prog_name} should appear exactly once, found {count} times"
        
        # Verify: All external programs are in database
        cursor.execute("SELECT program_name FROM outbound_interfaces")
        db_programs = {row[0] for row in cursor.fetchall()}
        
        for ext_prog in external_programs:
            assert ext_prog in db_programs, \
                f"External program {ext_prog} should be in outbound_interfaces"
    
    finally:
        conn.close()
        try:
            os.unlink(temp_db_path)
        except:
            pass
