#!/usr/bin/env python3
"""
Test script for language detection functionality.

Tests the new content-based language detection on various files.
"""

import os
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.legacy_analyzer.language_detector import LanguageDetector


def test_language_detection():
    """Test language detection on example files."""
    
    detector = LanguageDetector()
    
    # Test cases: (file_path, expected_language)
    test_cases = [
        # COBOL files with .txt extension
        ('examples/code/cobol/carddemoV2/app/cbl', '.txt', 'COBOL'),
        
        # REXX files with .txt extension
        ('examples/code/rexx/cbtapes_file_617', '.txt', 'REXX'),
        
        # Regular COBOL files
        ('examples/code/cobol/carddemoV2/app/cbl', '.cbl', 'COBOL'),
        
        # COBOL copybooks
        ('examples/code/cobol/carddemoV2/app/cpy', '.cpy', 'COBOL'),
    ]
    
    print("=" * 80)
    print("Language Detection Test Results")
    print("=" * 80)
    
    for directory, extension, expected_lang in test_cases:
        if not os.path.exists(directory):
            print(f"\n⚠ Directory not found: {directory}")
            continue
        
        print(f"\n\nTesting {extension} files in {directory}")
        print(f"Expected language: {expected_lang}")
        print("-" * 80)
        
        # Find files with this extension
        files = list(Path(directory).glob(f"*{extension}"))
        
        if not files:
            print(f"  No {extension} files found")
            continue
        
        # Test first few files
        for file_path in files[:5]:  # Limit to 5 files per directory
            language, confidence, details = detector.detect_with_confidence(str(file_path))
            
            # Check if detection matches expected
            match_symbol = "✓" if language == expected_lang else "✗"
            
            print(f"\n  {match_symbol} File: {file_path.name}")
            print(f"    Detected: {language} (confidence: {confidence})")
            print(f"    Extension guess: {details['extension_guess']}")
            print(f"    Content scores: {details['content_scores']}")
            print(f"    Detection method: {details['method']}")
    
    print("\n" + "=" * 80)
    print("Testing specific problematic files")
    print("=" * 80)
    
    # Test specific files mentioned in the issue
    specific_tests = []
    
    # Find .txt files in COBOL directory
    cobol_dir = 'examples/code/cobol/carddemoV2/app/cbl'
    if os.path.exists(cobol_dir):
        txt_files = list(Path(cobol_dir).glob("*.txt"))
        if txt_files:
            specific_tests.append((txt_files[0], 'COBOL'))
    
    # Find .txt files in REXX directory
    rexx_dir = 'examples/code/rexx/cbtapes_file_617'
    if os.path.exists(rexx_dir):
        txt_files = list(Path(rexx_dir).glob("*.txt"))
        if txt_files:
            specific_tests.extend([(f, 'REXX') for f in txt_files[:3]])
    
    for file_path, expected_lang in specific_tests:
        language, confidence, details = detector.detect_with_confidence(str(file_path))
        
        match_symbol = "✓" if language == expected_lang else "✗"
        
        print(f"\n{match_symbol} File: {file_path}")
        print(f"  Expected: {expected_lang}")
        print(f"  Detected: {language} (confidence: {confidence})")
        print(f"  Content scores: {details['content_scores']}")
        
        # Show first few lines of file for context
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = [line.rstrip() for line in f.readlines()[:10]]
            print(f"  First lines:")
            for i, line in enumerate(lines[:5], 1):
                if line.strip():
                    print(f"    {i}: {line[:70]}")
        except:
            pass
    
    print("\n" + "=" * 80)


if __name__ == '__main__':
    test_language_detection()
