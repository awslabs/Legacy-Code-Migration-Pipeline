"""Property-based tests for dependency referential integrity.

Feature: program-level-dependency-tracking, Property 14: Dependency referential integrity
"""

import pytest
import tempfile
import os
from hypothesis import given, strategies as st, settings, HealthCheck
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.legacy_analyzer.program_level_dependency_loader import ProgramLevelDependencyLoader
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType
from tools.legacy_analyzer.models.dependency import Dependency, DependencyType


# Strategy for generating valid program names
@st.composite
def program_name_strategy(draw):
    """Generate valid program names (1-44 chars, alphanumeric)."""
    # Use a prefix to make names unique and avoid conflicts
    prefix = draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ', min_size=3, max_size=8))
    suffix = draw(st.text(alphabet='0123456789', min_size=2, max_size=6))
    return f"PROG_{prefix}_{suffix}"


# Strategy for generating program boundaries
@st.composite
def program_boundary_strategy(draw):
    """Generate valid ProgramBoundary objects."""
    program_name = draw(program_name_strategy())
    start_line = draw(st.integers(min_value=1, max_value=1000))
    end_line = draw(st.integers(min_value=start_line, max_value=start_line + 500))
    program_type = draw(st.sampled_from(list(ProgramType)))
    language = draw(st.sampled_from(['COBOL', 'PL/I', 'NATURAL', 'REXX', 'RPG', 'ASM']))
    entry_points = draw(st.lists(program_name_strategy(), max_size=3))
    
    return ProgramBoundary(
        program_name=program_name,
        start_line=start_line,
        end_line=end_line,
        program_type=program_type,
        language=language,
        entry_points=entry_points
    )





class TestDependencyReferentialIntegrityProperties:
    """Property-based tests for dependency referential integrity."""
    
    @pytest.fixture
    def temp_db(self):
        """Create a temporary database for testing."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = SQLiteAdapter(db_path)
        db.connect()
        
        # Create dependencies schema
        loader = ProgramLevelDependencyLoader(db)
        loader.create_dependencies_schema()
        
        yield db
        
        # Cleanup
        db.close()
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=2, max_size=10, unique_by=lambda x: x.program_name)
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_valid_dependencies_pass_integrity_check(self, temp_db, programs):
        """
        Feature: program-level-dependency-tracking, Property 14: Dependency referential integrity
        
        Validates: Requirements 8.2
        
        For any program-level dependency where both source and target programs exist 
        in the inventory, referential integrity validation should pass.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Store programs first
        file_path = '/test/source/multi_program.cbl'
        empty_dependencies = {prog.program_name: [] for prog in programs}
        stats = loader.store_program_dependencies(file_path, programs, empty_dependencies)
        assert stats['errors'] == 0
        
        # Generate valid dependencies between existing programs
        program_names = [prog.program_name for prog in programs]
        valid_deps = []
        
        # Create simple valid dependencies between consecutive programs
        for i in range(min(len(programs) - 1, 3)):  # Limit to avoid too many dependencies
            valid_deps.append({
                'source_program_name': program_names[i],
                'source_file_path': file_path,
                'target_program_name': program_names[i + 1],
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'line_number': 100 + i
            })
        
        if valid_deps:
            # Insert valid dependencies
            dep_stats = loader.bulk_insert_program_dependencies(valid_deps, skip_duplicates=True)
            assert dep_stats['errors'] == 0
            
            # Validate referential integrity
            validation_results = loader.validate_program_referential_integrity()
            
            # Should pass validation since all programs exist
            assert validation_results['valid'] == True
            assert len(validation_results['missing_source_programs']) == 0
            assert validation_results['statistics']['integrity_score'] == 1.0
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=2, max_size=8, unique_by=lambda x: x.program_name)
    )
    @settings(
        max_examples=50,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_invalid_dependencies_fail_integrity_check(self, temp_db, programs):
        """
        Feature: program-level-dependency-tracking, Property 14: Dependency referential integrity
        
        Validates: Requirements 8.2
        
        For any program-level dependency where source or target programs do not exist 
        in the inventory, referential integrity validation should fail.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Store programs first
        file_path = '/test/source/multi_program.cbl'
        empty_dependencies = {prog.program_name: [] for prog in programs}
        stats = loader.store_program_dependencies(file_path, programs, empty_dependencies)
        assert stats['errors'] == 0
        
        # Generate invalid dependencies with non-existing programs
        program_names = [prog.program_name for prog in programs]
        invalid_deps = []
        
        # Create dependencies with non-existing program names
        for i in range(min(2, len(programs))):
            invalid_deps.append({
                'source_program_name': f'NONEXISTENT_PROG_{i}',
                'source_file_path': file_path,
                'target_program_name': f'MISSING_TARGET_{i}',
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'line_number': 200 + i
            })
        
        if invalid_deps:
            # Insert invalid dependencies (this should succeed at insert level)
            dep_stats = loader.bulk_insert_program_dependencies(invalid_deps, skip_duplicates=True)
            
            # Validate referential integrity
            validation_results = loader.validate_program_referential_integrity()
            
            # Should fail validation due to missing programs
            assert validation_results['valid'] == False
            assert len(validation_results['missing_source_programs']) > 0
            assert validation_results['statistics']['integrity_score'] < 1.0
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=3, max_size=8, unique_by=lambda x: x.program_name)
    )
    @settings(
        max_examples=50,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_mixed_dependencies_partial_integrity(self, temp_db, programs):
        """
        Feature: program-level-dependency-tracking, Property 14: Dependency referential integrity
        
        Validates: Requirements 8.2
        
        For any mix of valid and invalid program dependencies, referential integrity 
        validation should accurately report the proportion of valid dependencies.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Store programs first
        file_path = '/test/source/multi_program.cbl'
        empty_dependencies = {prog.program_name: [] for prog in programs}
        stats = loader.store_program_dependencies(file_path, programs, empty_dependencies)
        assert stats['errors'] == 0
        
        program_names = [prog.program_name for prog in programs]
        
        # Generate mix of valid and invalid dependencies
        all_deps = []
        
        # Add some valid dependencies
        for i in range(min(2, len(programs) - 1)):
            all_deps.append({
                'source_program_name': program_names[i],
                'source_file_path': file_path,
                'target_program_name': program_names[i + 1],
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'line_number': 100 + i
            })
        
        # Add some invalid dependencies
        for i in range(min(2, len(programs) - 1)):
            all_deps.append({
                'source_program_name': f'INVALID_PROG_{i}',
                'source_file_path': file_path,
                'target_program_name': f'MISSING_TARGET_{i}',
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'line_number': 200 + i
            })
        
        if all_deps:
            # Insert mixed dependencies
            dep_stats = loader.bulk_insert_program_dependencies(all_deps, skip_duplicates=True)
            
            # Validate referential integrity
            validation_results = loader.validate_program_referential_integrity()
            
            # Should have partial integrity
            total_deps = validation_results['total_dependencies']
            if total_deps > 0:
                integrity_score = validation_results['statistics']['integrity_score']
                assert 0.0 <= integrity_score <= 1.0
                
                # If there are missing programs, integrity should be less than perfect
                if (len(validation_results['missing_source_programs']) > 0 or 
                    len(validation_results['missing_target_programs']) > 0):
                    assert integrity_score < 1.0
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=1, max_size=5, unique_by=lambda x: x.program_name)
    )
    @settings(
        max_examples=50,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_orphaned_programs_detection(self, temp_db, programs):
        """
        Feature: program-level-dependency-tracking, Property 14: Dependency referential integrity
        
        Validates: Requirements 8.2
        
        For any programs that exist in the inventory but have no dependencies, 
        they should be correctly identified as orphaned programs.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Store programs without any dependencies
        file_path = '/test/source/orphaned_programs.cbl'
        empty_dependencies = {prog.program_name: [] for prog in programs}
        stats = loader.store_program_dependencies(file_path, programs, empty_dependencies)
        assert stats['errors'] == 0
        
        # Validate referential integrity
        validation_results = loader.validate_program_referential_integrity()
        
        # All programs should be orphaned since they have no dependencies
        expected_orphaned = {prog.program_name for prog in programs}
        actual_orphaned = set(validation_results['orphaned_programs'])
        
        assert actual_orphaned == expected_orphaned
        assert validation_results['statistics']['orphaned_programs_count'] == len(programs)
        assert validation_results['statistics']['programs_with_dependencies'] == 0
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=2, max_size=6, unique_by=lambda x: x.program_name)
    )
    @settings(
        max_examples=50,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_integrity_statistics_accuracy(self, temp_db, programs):
        """
        Feature: program-level-dependency-tracking, Property 14: Dependency referential integrity
        
        Validates: Requirements 8.2
        
        For any set of programs and dependencies, the integrity validation statistics 
        should accurately reflect the actual state of referential integrity.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        cursor.execute("DELETE FROM artifact_dependencies")
        temp_db.commit()
        
        loader = ProgramLevelDependencyLoader(temp_db)
        
        # Store programs first
        file_path = '/test/source/stats_test.cbl'
        empty_dependencies = {prog.program_name: [] for prog in programs}
        stats = loader.store_program_dependencies(file_path, programs, empty_dependencies)
        assert stats['errors'] == 0
        
        program_names = [prog.program_name for prog in programs]
        
        # Create some valid dependencies (program-to-program calls)
        valid_deps = []
        for i in range(len(programs) - 1):
            valid_deps.append({
                'source_program_name': program_names[i],
                'source_file_path': file_path,
                'target_program_name': program_names[i + 1],
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'line_number': 100 + i
            })
        
        if valid_deps:
            # Insert valid dependencies
            dep_stats = loader.bulk_insert_program_dependencies(valid_deps, skip_duplicates=True)
            assert dep_stats['errors'] == 0
            
            # Validate referential integrity
            validation_results = loader.validate_program_referential_integrity()
            
            # Verify statistics accuracy
            stats = validation_results['statistics']
            
            # Total programs should match what we stored
            assert stats['total_programs'] == len(programs)
            
            # Total dependencies should match what we inserted
            assert validation_results['total_dependencies'] == len(valid_deps)
            
            # Since all dependencies are valid, integrity score should be 1.0
            assert stats['integrity_score'] == 1.0
            
            # Missing counts should be zero for valid dependencies
            assert stats['missing_source_count'] == 0
            assert stats['missing_target_count'] == 0
            
            # Programs with dependencies should be at least the number of source programs
            source_programs = {dep['source_program_name'] for dep in valid_deps}
            assert stats['programs_with_dependencies'] >= len(source_programs)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])