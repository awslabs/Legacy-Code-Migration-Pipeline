"""
Unit tests for Entry Point Type Detection

Tests the detection of all invocation types and callers for entry point programs.
"""

import unittest
import sqlite3
import tempfile
import os
from tools.legacy_analyzer.migration.entry_point_type_detector import EntryPointTypeDetector


class TestEntryPointTypeDetection(unittest.TestCase):
    """Test cases for entry point type detection."""
    
    def setUp(self):
        """Set up test database."""
        # Create temporary database
        self.db_fd, self.db_path = tempfile.mkstemp()
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create test tables
        self._create_test_tables()
        
        # Create detector
        self.detector = EntryPointTypeDetector(self.conn)
    
    def tearDown(self):
        """Clean up test database."""
        self.conn.close()
        os.close(self.db_fd)
        os.unlink(self.db_path)
    
    def _create_test_tables(self):
        """Create test database tables."""
        # Create inventory_cics table
        self.cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                language VARCHAR(20),
                description TEXT
            )
        """)
        
        # Create artifact_dependencies table
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_artifact_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_artifact_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(30) NOT NULL,
                source_file_path VARCHAR(255),
                line_number INTEGER
            )
        """)
        
        # Create inventory_bms table (optional)
        self.cursor.execute("""
            CREATE TABLE inventory_bms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                map_name VARCHAR(8) NOT NULL,
                mapset_name VARCHAR(8),
                program_name VARCHAR(8),
                description TEXT
            )
        """)
        
        self.conn.commit()
    
    def test_detect_jcl_invocations_single_caller(self):
        """Test detecting JCL invocations with single caller."""
        # Add JCL dependency
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type, source_file_path, line_number)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM', 
                    '/jcl/PAYROLL01.jcl', 42)
        """)
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have one type (JCL)
        self.assertEqual(len(entry_types), 1)
        self.assertEqual(entry_types[0]['type'], 'JCL')
        
        # Should have one caller
        callers = entry_types[0]['callers']
        self.assertEqual(len(callers), 1)
        self.assertEqual(callers[0]['source'], 'PAYROLL01')
        
        # Check metadata
        metadata = callers[0]['metadata']
        self.assertEqual(metadata['jclName'], 'PAYROLL01')
        self.assertEqual(metadata['jobName'], 'PAYROLL01')
        self.assertEqual(metadata['filePath'], '/jcl/PAYROLL01.jcl')
        self.assertEqual(metadata['lineNumber'], 42)
    
    def test_detect_jcl_invocations_multiple_callers(self):
        """Test detecting JCL invocations with multiple callers."""
        # Add multiple JCL dependencies
        jcl_jobs = [
            ('PAYROLL01', '/jcl/PAYROLL01.jcl', 42),
            ('PAYWEEK', '/jcl/PAYWEEK.jcl', 15),
            ('PAYMONTH', '/jcl/PAYMONTH.jcl', 28)
        ]
        
        for jcl_name, file_path, line_num in jcl_jobs:
            self.cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type, source_file_path, line_number)
                VALUES (?, 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM', ?, ?)
            """, (jcl_name, file_path, line_num))
        
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have one type (JCL)
        self.assertEqual(len(entry_types), 1)
        jcl_type = entry_types[0]
        self.assertEqual(jcl_type['type'], 'JCL')
        
        # Should have three callers
        callers = jcl_type['callers']
        self.assertEqual(len(callers), 3)
        
        # Check all callers are present
        caller_names = [c['source'] for c in callers]
        self.assertIn('PAYROLL01', caller_names)
        self.assertIn('PAYWEEK', caller_names)
        self.assertIn('PAYMONTH', caller_names)
    
    def test_detect_cics_transaction_invocations(self):
        """Test detecting CICS transaction invocations."""
        # Add CICS transaction
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES ('PAY1', 'TRANSACTION', 'PAYGRP', 'ENABLED', 'PAYROLL1', 
                    'Payroll Transaction')
        """)
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have one type (CICS_TRANSACTION)
        self.assertEqual(len(entry_types), 1)
        self.assertEqual(entry_types[0]['type'], 'CICS_TRANSACTION')
        
        # Should have one caller
        callers = entry_types[0]['callers']
        self.assertEqual(len(callers), 1)
        self.assertEqual(callers[0]['source'], 'PAY1')
        
        # Check metadata
        metadata = callers[0]['metadata']
        self.assertEqual(metadata['transactionId'], 'PAY1')
        self.assertEqual(metadata['csdGroup'], 'PAYGRP')
        self.assertEqual(metadata['status'], 'ENABLED')
        self.assertEqual(metadata['description'], 'Payroll Transaction')
    
    def test_detect_cics_program_invocations(self):
        """Test detecting CICS program definitions."""
        # Add CICS program definition
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, language, description)
            VALUES ('PAYROLL1', 'PROGRAM', 'PAYGRP', 'ENABLED', 'COBOL', 
                    'Payroll Program')
        """)
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have one type (CICS_PROGRAM)
        self.assertEqual(len(entry_types), 1)
        self.assertEqual(entry_types[0]['type'], 'CICS_PROGRAM')
        
        # Should have one caller
        callers = entry_types[0]['callers']
        self.assertEqual(len(callers), 1)
        self.assertEqual(callers[0]['source'], 'PAYROLL1')
        
        # Check metadata
        metadata = callers[0]['metadata']
        self.assertEqual(metadata['programName'], 'PAYROLL1')
        self.assertEqual(metadata['csdGroup'], 'PAYGRP')
        self.assertEqual(metadata['status'], 'ENABLED')
        self.assertEqual(metadata['language'], 'COBOL')
    
    def test_detect_screen_invocations(self):
        """Test detecting screen invocations from BMS maps."""
        # Add BMS map
        self.cursor.execute("""
            INSERT INTO inventory_bms 
            (map_name, mapset_name, program_name, description)
            VALUES ('PAYSCREEN', 'PAYMAPS', 'PAYROLL1', 'Payroll Screen')
        """)
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have one type (SCREEN)
        self.assertEqual(len(entry_types), 1)
        self.assertEqual(entry_types[0]['type'], 'SCREEN')
        
        # Should have one caller
        callers = entry_types[0]['callers']
        self.assertEqual(len(callers), 1)
        self.assertEqual(callers[0]['source'], 'PAYSCREEN')
        
        # Check metadata
        metadata = callers[0]['metadata']
        self.assertEqual(metadata['screenName'], 'PAYSCREEN')
        self.assertEqual(metadata['mapset'], 'PAYMAPS')
        self.assertEqual(metadata['description'], 'Payroll Screen')
    
    def test_detect_external_call_invocations(self):
        """Test detecting external call invocations."""
        # Add external call dependency
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type, source_file_path, line_number)
            VALUES ('MAINPROG', 'PROGRAM', 'PAYROLL1', 'PROGRAM', 'PROGRAM_CALL', 
                    '/src/MAINPROG.cbl', 150)
        """)
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have one type (EXTERNAL_CALL)
        self.assertEqual(len(entry_types), 1)
        self.assertEqual(entry_types[0]['type'], 'EXTERNAL_CALL')
        
        # Should have one caller
        callers = entry_types[0]['callers']
        self.assertEqual(len(callers), 1)
        self.assertEqual(callers[0]['source'], 'MAINPROG')
        
        # Check metadata
        metadata = callers[0]['metadata']
        self.assertEqual(metadata['callingProgram'], 'MAINPROG')
        self.assertEqual(metadata['callType'], 'PROGRAM_CALL')
        self.assertEqual(metadata['filePath'], '/src/MAINPROG.cbl')
        self.assertEqual(metadata['lineNumber'], 150)
    
    def test_detect_multiple_entry_types(self):
        """Test program invoked by JCL and CICS has both types."""
        # Add JCL dependency
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        # Add CICS transaction
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('PAY1', 'TRANSACTION', 'PAYROLL1')
        """)
        
        # Add CICS program definition
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type)
            VALUES ('PAYROLL1', 'PROGRAM')
        """)
        
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have three types
        self.assertEqual(len(entry_types), 3)
        
        # Check all types are present
        type_names = [t['type'] for t in entry_types]
        self.assertIn('JCL', type_names)
        self.assertIn('CICS_TRANSACTION', type_names)
        self.assertIn('CICS_PROGRAM', type_names)
    
    def test_detect_multiple_jcl_callers(self):
        """Test program invoked by multiple JCL jobs lists all callers."""
        # Add multiple JCL dependencies
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYWEEK', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Should have one type (JCL)
        self.assertEqual(len(entry_types), 1)
        jcl_type = entry_types[0]
        self.assertEqual(jcl_type['type'], 'JCL')
        
        # Should have two callers
        callers = jcl_type['callers']
        self.assertEqual(len(callers), 2)
        
        # Check both callers are present
        caller_sources = [c['source'] for c in callers]
        self.assertIn('PAYROLL01', caller_sources)
        self.assertIn('PAYWEEK', caller_sources)
    
    def test_determine_primary_type_most_callers(self):
        """Test primary type is determined by most callers."""
        # Add 2 JCL callers
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYWEEK', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        # Add 1 CICS transaction caller
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('PAY1', 'TRANSACTION', 'PAYROLL1')
        """)
        
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Determine primary type
        primary_type = self.detector.determine_primary_type(entry_types)
        
        # JCL should be primary (2 callers vs 1)
        self.assertEqual(primary_type, 'JCL')
    
    def test_determine_primary_type_priority_on_tie(self):
        """Test primary type uses priority when caller counts are equal."""
        # Add 1 JCL caller
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        # Add 1 CICS transaction caller
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('PAY1', 'TRANSACTION', 'PAYROLL1')
        """)
        
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Determine primary type
        primary_type = self.detector.determine_primary_type(entry_types)
        
        # JCL should be primary (higher priority when tied)
        self.assertEqual(primary_type, 'JCL')
    
    def test_get_all_callers(self):
        """Test getting all callers across all types."""
        # Add JCL caller
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        # Add CICS transaction caller
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('PAY1', 'TRANSACTION', 'PAYROLL1')
        """)
        
        # Add external call caller
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('MAINPROG', 'PROGRAM', 'PAYROLL1', 'PROGRAM', 'PROGRAM_CALL')
        """)
        
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Get all callers
        all_callers = self.detector.get_all_callers(entry_types)
        
        # Should have 3 callers
        self.assertEqual(len(all_callers), 3)
        self.assertIn('PAYROLL01', all_callers)
        self.assertIn('PAY1', all_callers)
        self.assertIn('MAINPROG', all_callers)
    
    def test_get_entry_type_statistics(self):
        """Test getting statistics about entry point types."""
        # Add multiple callers of different types
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYWEEK', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('PAY1', 'TRANSACTION', 'PAYROLL1')
        """)
        
        self.conn.commit()
        
        # Detect entry point types
        entry_types = self.detector.detect_entry_point_types('PAYROLL1')
        
        # Get statistics
        stats = self.detector.get_entry_type_statistics(entry_types)
        
        # Check statistics
        self.assertEqual(stats['total_types'], 2)
        self.assertEqual(stats['total_callers'], 3)
        self.assertEqual(stats['types']['JCL'], 2)
        self.assertEqual(stats['types']['CICS_TRANSACTION'], 1)
        self.assertEqual(stats['primary_type'], 'JCL')
    
    def test_has_any_invocation_type(self):
        """Test checking if program has any invocation type."""
        # Add JCL dependency
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        self.conn.commit()
        
        # Check program with invocation type
        self.assertTrue(self.detector.has_any_invocation_type('PAYROLL1'))
        
        # Check program without invocation type
        self.assertFalse(self.detector.has_any_invocation_type('UNKNOWN'))
    
    def test_get_programs_by_invocation_type_jcl(self):
        """Test getting programs by JCL invocation type."""
        # Add JCL dependencies
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('BILLING01', 'JCL', 'BILLING1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.conn.commit()
        
        # Get programs by JCL type
        programs = self.detector.get_programs_by_invocation_type('JCL')
        
        # Should have 2 programs
        self.assertEqual(len(programs), 2)
        self.assertIn('PAYROLL1', programs)
        self.assertIn('BILLING1', programs)
    
    def test_get_programs_by_invocation_type_cics_transaction(self):
        """Test getting programs by CICS transaction invocation type."""
        # Add CICS transactions
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('PAY1', 'TRANSACTION', 'PAYROLL1')
        """)
        
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('BILL1', 'TRANSACTION', 'BILLING1')
        """)
        
        self.conn.commit()
        
        # Get programs by CICS_TRANSACTION type
        programs = self.detector.get_programs_by_invocation_type('CICS_TRANSACTION')
        
        # Should have 2 programs
        self.assertEqual(len(programs), 2)
        self.assertIn('PAYROLL1', programs)
        self.assertIn('BILLING1', programs)
    
    def test_no_entry_types_for_unknown_program(self):
        """Test that unknown program has no entry types."""
        # Detect entry point types for non-existent program
        entry_types = self.detector.detect_entry_point_types('UNKNOWN')
        
        # Should have no types
        self.assertEqual(len(entry_types), 0)
    
    def test_graceful_handling_missing_tables(self):
        """Test graceful handling when tables don't exist."""
        # Create new database without tables
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        
        try:
            detector = EntryPointTypeDetector(conn)
            
            # Should not have tables
            self.assertFalse(detector._has_cics_table)
            self.assertFalse(detector._has_dependencies_table)
            self.assertFalse(detector._has_bms_table)
            
            # Should return empty list, not error
            entry_types = detector.detect_entry_point_types('PAYROLL1')
            self.assertEqual(len(entry_types), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)
    
    def test_detect_multiple_programs_batch(self):
        """Test detecting entry types for multiple programs efficiently."""
        # Add dependencies for multiple programs
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, 
             target_artifact_type, dependency_type)
            VALUES ('BILLING01', 'JCL', 'BILLING1', 'PROGRAM', 'EXEC_PGM')
        """)
        
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, program_name)
            VALUES ('ACCT1', 'TRANSACTION', 'ACCOUNT1')
        """)
        
        self.conn.commit()
        
        # Detect for multiple programs
        programs = ['PAYROLL1', 'BILLING1', 'ACCOUNT1']
        results = self.detector.detect_multiple_programs(programs)
        
        # Should have results for all programs
        self.assertEqual(len(results), 3)
        self.assertIn('PAYROLL1', results)
        self.assertIn('BILLING1', results)
        self.assertIn('ACCOUNT1', results)
        
        # Check each has correct types
        self.assertEqual(results['PAYROLL1'][0]['type'], 'JCL')
        self.assertEqual(results['BILLING1'][0]['type'], 'JCL')
        self.assertEqual(results['ACCOUNT1'][0]['type'], 'CICS_TRANSACTION')


if __name__ == '__main__':
    unittest.main()
