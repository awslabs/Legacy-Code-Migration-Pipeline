"""Tests for CICS transaction report generator."""

import unittest
import sqlite3
import tempfile
import os
import json
from pathlib import Path

from tools.legacy_analyzer.reports.cics_report import (
    CICSReportGenerator,
    CICSTransactionReport,
    TransactionCallTree,
    TransactionDataDependencies,
    TransactionComplexity,
    ModernizationSuggestion,
    generate_cics_transactions_report
)


class TestCICSReportGenerator(unittest.TestCase):
    """Test CICS report generator."""
    
    def setUp(self):
        """Set up test database."""
        self.db_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.db_file.name
        self.db_file.close()
        
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create test tables
        self._create_test_tables()
        self._insert_test_data()
        
        self.generator = CICSReportGenerator(self.conn)
    
    def tearDown(self):
        """Clean up test database."""
        self.conn.close()
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    def _create_test_tables(self):
        """Create test database tables."""
        # inventory_cics table
        self.cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY,
                resource_name VARCHAR(8),
                resource_type VARCHAR(20),
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20)
            )
        """)
        
        # artifact_dependencies table
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY,
                source_artifact_name VARCHAR(44),
                source_type VARCHAR(20),
                target_artifact_name VARCHAR(44),
                target_type VARCHAR(20),
                dependency_type VARCHAR(20)
            )
        """)
        
        # complexity_metrics table
        self.cursor.execute("""
            CREATE TABLE complexity_metrics (
                id INTEGER PRIMARY KEY,
                program_name VARCHAR(44),
                lines_of_code INTEGER,
                cyclomatic_complexity INTEGER,
                composite_score REAL
            )
        """)
        
        self.conn.commit()
    
    def _insert_test_data(self):
        """Insert test data."""
        # Insert CICS transactions
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('CAUP', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTUPC', 'Account Update'),
            ('CALI', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTLST', 'Account List'),
            ('CDIS', 'TRANSACTION', 'CARDDEMO', 'DISABLED', 'CODISABL', 'Disabled Transaction')
        """)
        
        # Insert CICS programs
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, language)
            VALUES 
            ('COACTUPC', 'PROGRAM', 'CARDDEMO', 'ENABLED', 'COBOL'),
            ('COACTLST', 'PROGRAM', 'CARDDEMO', 'ENABLED', 'COBOL')
        """)
        
        # Insert CICS files
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, dataset_name)
            VALUES 
            ('ACCTDAT', 'FILE', 'CARDDEMO', 'ENABLED', 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS'),
            ('CUSTDAT', 'FILE', 'CARDDEMO', 'ENABLED', 'AWS.M2.CARDDEMO.CUSTDATA.VSAM.KSDS')
        """)
        
        # Insert CICS mapsets
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, description)
            VALUES 
            ('COACTUP', 'MAPSET', 'CARDDEMO', 'ENABLED', 'Account Update Map')
        """)
        
        # Insert dependencies (call tree)
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_type, target_artifact_name, target_type, dependency_type)
            VALUES 
            ('COACTUPC', 'PROGRAM', 'CBACT01C', 'PROGRAM', 'CALL'),
            ('COACTUPC', 'PROGRAM', 'ACCTDAT', 'FILE', 'READ'),
            ('CBACT01C', 'PROGRAM', 'CBACT02C', 'PROGRAM', 'CALL'),
            ('CBACT01C', 'PROGRAM', 'CUSTDAT', 'FILE', 'READ')
        """)
        
        # Insert complexity metrics
        self.cursor.execute("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, cyclomatic_complexity, composite_score)
            VALUES 
            ('COACTUPC', 500, 25, 75.5),
            ('CBACT01C', 300, 15, 45.0),
            ('CBACT02C', 200, 10, 30.0)
        """)
        
        self.conn.commit()
    
    def test_get_call_tree(self):
        """Test call tree generation."""
        call_tree = self.generator._get_call_tree('COACTUPC')
        
        self.assertIsInstance(call_tree, TransactionCallTree)
        self.assertGreater(call_tree.depth, 0)
        self.assertIn('COACTUPC', call_tree.programs)
        self.assertIn('CBACT01C', call_tree.programs)
        self.assertEqual(call_tree.total_programs, len(call_tree.programs))
    
    def test_get_data_dependencies(self):
        """Test data dependencies extraction."""
        programs = ['COACTUPC', 'CBACT01C']
        data_deps = self.generator._get_data_dependencies(programs)
        
        self.assertIsInstance(data_deps, TransactionDataDependencies)
        self.assertIn('ACCTDAT', data_deps.files)
        self.assertIn('CUSTDAT', data_deps.files)
    
    def test_get_complexity_metrics(self):
        """Test complexity metrics aggregation."""
        programs = ['COACTUPC', 'CBACT01C', 'CBACT02C']
        complexity = self.generator._get_complexity_metrics(programs)
        
        self.assertIsInstance(complexity, TransactionComplexity)
        self.assertEqual(complexity.total_loc, 1000)  # 500 + 300 + 200
        self.assertEqual(complexity.total_cyclomatic, 50)  # 25 + 15 + 10
        self.assertAlmostEqual(complexity.composite_score, 150.5)  # 75.5 + 45.0 + 30.0
        self.assertEqual(complexity.tier, 'HIGH')  # Score > 100
    
    def test_generate_modernization_suggestion(self):
        """Test modernization suggestion generation."""
        suggestion = self.generator._generate_modernization_suggestion(
            'CAUP',
            'Account Update',
            'CARDDEMO'
        )
        
        self.assertIsInstance(suggestion, ModernizationSuggestion)
        self.assertEqual(suggestion.http_method, 'PUT')  # 'update' in description
        self.assertIn('account', suggestion.suggested_api_endpoint.lower())
        self.assertEqual(suggestion.suggested_service, 'Carddemo Service')
    
    def test_generate_transaction_report(self):
        """Test single transaction report generation."""
        report = self.generator.generate_transaction_report('CAUP')
        
        self.assertIsNotNone(report)
        self.assertIsInstance(report, CICSTransactionReport)
        self.assertEqual(report.transaction_id, 'CAUP')
        self.assertEqual(report.program, 'COACTUPC')
        self.assertEqual(report.group, 'CARDDEMO')
        self.assertEqual(report.status, 'ENABLED')
        self.assertEqual(report.description, 'Account Update')
        
        # Check call tree
        self.assertIsNotNone(report.call_tree)
        self.assertGreater(report.call_tree.total_programs, 0)
        
        # Check data dependencies
        self.assertIsNotNone(report.data_dependencies)
        self.assertGreater(len(report.data_dependencies.files), 0)
        
        # Check complexity
        self.assertIsNotNone(report.complexity)
        self.assertGreater(report.complexity.composite_score, 0)
        
        # Check modernization
        self.assertIsNotNone(report.modernization)
        self.assertIsNotNone(report.modernization.suggested_api_endpoint)
    
    def test_generate_transaction_report_not_found(self):
        """Test transaction report for non-existent transaction."""
        report = self.generator.generate_transaction_report('XXXX')
        
        self.assertIsNone(report)
    
    def test_generate_all_transactions_report(self):
        """Test all transactions report generation."""
        report_data = self.generator.generate_all_transactions_report(
            include_disabled=False
        )
        
        self.assertIn('metadata', report_data)
        self.assertIn('transactions', report_data)
        self.assertIn('summary', report_data)
        
        # Should have 2 enabled transactions
        self.assertEqual(len(report_data['transactions']), 2)
        
        # Check summary
        summary = report_data['summary']
        self.assertEqual(summary['total_transactions'], 2)
        self.assertEqual(summary['enabled'], 2)
        self.assertEqual(summary['disabled'], 0)
        self.assertIn('CARDDEMO', summary['by_group'])
    
    def test_generate_all_transactions_report_include_disabled(self):
        """Test all transactions report with disabled transactions."""
        report_data = self.generator.generate_all_transactions_report(
            include_disabled=True
        )
        
        # Should have 3 transactions (including disabled)
        self.assertEqual(len(report_data['transactions']), 3)
        
        # Check summary
        summary = report_data['summary']
        self.assertEqual(summary['total_transactions'], 3)
        self.assertEqual(summary['enabled'], 2)
        self.assertEqual(summary['disabled'], 1)
    
    def test_transaction_report_to_dict(self):
        """Test transaction report serialization."""
        report = self.generator.generate_transaction_report('CAUP')
        
        report_dict = report.to_dict()
        
        self.assertIsInstance(report_dict, dict)
        self.assertEqual(report_dict['transaction_id'], 'CAUP')
        self.assertEqual(report_dict['program'], 'COACTUPC')
        self.assertIn('call_tree', report_dict)
        self.assertIn('data_dependencies', report_dict)
        self.assertIn('complexity', report_dict)
        self.assertIn('modernization', report_dict)


class TestGenerateCICSTransactionsReport(unittest.TestCase):
    """Test convenience function for generating CICS reports."""
    
    def setUp(self):
        """Set up test database."""
        self.db_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.db_file.name
        self.db_file.close()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create minimal test tables
        cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY,
                resource_name VARCHAR(8),
                resource_type VARCHAR(20),
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                description TEXT
            )
        """)
        
        cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('TEST', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'TESTPROG', 'Test Transaction')
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY,
                source_artifact_name VARCHAR(44),
                target_artifact_name VARCHAR(44),
                target_type VARCHAR(20),
                dependency_type VARCHAR(20)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE complexity_metrics (
                id INTEGER PRIMARY KEY,
                program_name VARCHAR(44),
                lines_of_code INTEGER,
                cyclomatic_complexity INTEGER,
                composite_score REAL
            )
        """)
        
        conn.commit()
        conn.close()
    
    def tearDown(self):
        """Clean up test database."""
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    def test_generate_json_report(self):
        """Test JSON report generation."""
        report = generate_cics_transactions_report(
            db_path=self.db_path,
            output_format='json',
            include_disabled=False
        )
        
        self.assertIsInstance(report, str)
        
        # Parse JSON to verify it's valid
        report_data = json.loads(report)
        self.assertIn('metadata', report_data)
        self.assertIn('transactions', report_data)
        self.assertIn('summary', report_data)
    
    def test_generate_html_report(self):
        """Test HTML report generation."""
        report = generate_cics_transactions_report(
            db_path=self.db_path,
            output_format='html',
            include_disabled=False
        )
        
        self.assertIsInstance(report, str)
        self.assertIn('<!DOCTYPE html>', report)
        self.assertIn('CICS Transactions Report', report)
        self.assertIn('TEST', report)  # Transaction ID should be in HTML


class TestModernizationSuggestion(unittest.TestCase):
    """Test modernization suggestion logic."""
    
    def setUp(self):
        """Set up test database."""
        self.db_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.db_file.name
        self.db_file.close()
        
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create minimal tables
        self.cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY,
                resource_name VARCHAR(8),
                resource_type VARCHAR(20),
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                description TEXT
            )
        """)
        
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY,
                source_artifact_name VARCHAR(44),
                target_artifact_name VARCHAR(44),
                target_type VARCHAR(20),
                dependency_type VARCHAR(20)
            )
        """)
        
        self.cursor.execute("""
            CREATE TABLE complexity_metrics (
                id INTEGER PRIMARY KEY,
                program_name VARCHAR(44),
                lines_of_code INTEGER,
                cyclomatic_complexity INTEGER,
                composite_score REAL
            )
        """)
        
        self.conn.commit()
        self.generator = CICSReportGenerator(self.conn)
    
    def tearDown(self):
        """Clean up test database."""
        self.conn.close()
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    def test_create_operation(self):
        """Test CREATE operation detection."""
        suggestion = self.generator._generate_modernization_suggestion(
            'CADD',
            'Create Account',
            'CARDDEMO'
        )
        
        self.assertEqual(suggestion.http_method, 'POST')
        self.assertIn('create', suggestion.suggested_api_endpoint.lower())
    
    def test_update_operation(self):
        """Test UPDATE operation detection."""
        suggestion = self.generator._generate_modernization_suggestion(
            'CUPD',
            'Update Customer',
            'CARDDEMO'
        )
        
        self.assertEqual(suggestion.http_method, 'PUT')
        self.assertIn('update', suggestion.suggested_api_endpoint.lower())
    
    def test_delete_operation(self):
        """Test DELETE operation detection."""
        suggestion = self.generator._generate_modernization_suggestion(
            'CDEL',
            'Delete Record',
            'CARDDEMO'
        )
        
        self.assertEqual(suggestion.http_method, 'DELETE')
        self.assertIn('delete', suggestion.suggested_api_endpoint.lower())
    
    def test_list_operation(self):
        """Test LIST operation detection."""
        suggestion = self.generator._generate_modernization_suggestion(
            'CLIS',
            'List Accounts',
            'CARDDEMO'
        )
        
        self.assertEqual(suggestion.http_method, 'GET')
        self.assertIn('list', suggestion.suggested_api_endpoint.lower())


if __name__ == '__main__':
    unittest.main()
