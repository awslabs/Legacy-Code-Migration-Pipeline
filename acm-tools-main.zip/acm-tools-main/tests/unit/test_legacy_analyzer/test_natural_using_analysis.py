"""Tests for Natural USING analysis functionality."""

import os
import tempfile
import pytest
from pathlib import Path
from tools.legacy_analyzer.parsers.natural_parser import NaturalDependencyParser
from tools.legacy_analyzer.models.dependency import DependencyType


class TestNaturalUsingAnalysis:
    """Test Natural USING analysis functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = NaturalDependencyParser()
    
    def test_parse_with_using_analysis_basic(self):
        """Test basic USING analysis functionality."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            gda_dir = temp_path / "gda"
            gda_dir.mkdir()
            
            # Create main program
            main_program = """
            DEFINE DATA
            GLOBAL USING UTILS-GDA
            END-DEFINE
            
            CALLNAT 'MAIN-PROCESS'
            
            END
            """
            
            # Create global data area with executable code
            utils_gda = """
            DEFINE DATA GLOBAL
            1 SHARED-VAR (A10)
            END-DEFINE
            
            DEFINE SUBROUTINE HELPER-FUNC
            CALLNAT 'ANOTHER-FUNC'
            END-SUBROUTINE
            """
            
            main_file = temp_path / "MAINPROG.NSP"
            main_file.write_text(main_program)
            (gda_dir / "UTILS-GDA.NSG").write_text(utils_gda)
            
            # Test enhanced parsing
            result = self.parser.parse_with_using_analysis(main_program, str(main_file))
            
            # Should find calls from both main program and USING reference
            assert 'callnat' in result
            assert 'MAIN-PROCESS' in result['callnat']
            assert 'ANOTHER-FUNC' in result['callnat']
    
    def test_nested_using_references(self):
        """Test nested USING reference analysis."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            gda_dir = temp_path / "gda"
            gda_dir.mkdir()
            
            # Create main program
            main_program = """
            DEFINE DATA
            GLOBAL USING LEVEL1-GDA
            END-DEFINE
            
            CALLNAT 'MAIN-FUNC'
            
            END
            """
            
            # Create level 1 global data area
            level1_gda = """
            DEFINE DATA GLOBAL
            GLOBAL USING LEVEL2-GDA
            1 LEVEL1-VAR (A20)
            END-DEFINE
            
            DEFINE SUBROUTINE LEVEL1-PROC
            CALLNAT 'LEVEL1-FUNC'
            END-SUBROUTINE
            """
            
            # Create level 2 global data area
            level2_gda = """
            DEFINE DATA GLOBAL
            1 LEVEL2-VAR (A30)
            END-DEFINE
            
            DEFINE SUBROUTINE LEVEL2-PROC
            CALLNAT 'LEVEL2-FUNC'
            END-SUBROUTINE
            """
            
            main_file = temp_path / "MAINPROG.NSP"
            main_file.write_text(main_program)
            (gda_dir / "LEVEL1-GDA.NSG").write_text(level1_gda)
            (gda_dir / "LEVEL2-GDA.NSG").write_text(level2_gda)
            
            # Test enhanced parsing
            result = self.parser.parse_with_using_analysis(main_program, str(main_file))
            
            # Should find nested USING references
            assert 'using' in result
            assert 'LEVEL1-GDA' in result['using']
            assert 'LEVEL2-GDA' in result['using']
            
            # Should find calls from all levels
            assert 'callnat' in result
            assert 'MAIN-FUNC' in result['callnat']
            assert 'LEVEL1-FUNC' in result['callnat']
            assert 'LEVEL2-FUNC' in result['callnat']
    
    def test_circular_reference_detection(self):
        """Test circular reference detection in USING statements."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            gda_dir = temp_path / "gda"
            gda_dir.mkdir()
            
            # Create main program
            main_program = """
            DEFINE DATA
            GLOBAL USING CIRCULAR-A
            END-DEFINE
            
            CALLNAT 'MAIN-FUNC'
            
            END
            """
            
            # Create circular USING references
            circular_a = """
            DEFINE DATA GLOBAL
            GLOBAL USING CIRCULAR-B
            1 VAR-A (A10)
            END-DEFINE
            
            DEFINE SUBROUTINE PROC-A
            CALLNAT 'FUNC-A'
            END-SUBROUTINE
            """
            
            circular_b = """
            DEFINE DATA GLOBAL
            GLOBAL USING CIRCULAR-A
            1 VAR-B (A10)
            END-DEFINE
            
            DEFINE SUBROUTINE PROC-B
            CALLNAT 'FUNC-B'
            END-SUBROUTINE
            """
            
            main_file = temp_path / "MAINPROG.NSP"
            main_file.write_text(main_program)
            (gda_dir / "CIRCULAR-A.NSG").write_text(circular_a)
            (gda_dir / "CIRCULAR-B.NSG").write_text(circular_b)
            
            # Should not hang or crash
            result = self.parser.parse_with_using_analysis(main_program, str(main_file))
            
            # Should find USING references (but not get stuck in infinite loop)
            assert 'using' in result
            assert 'CIRCULAR-A' in result['using']
            
            # Should find some calls (but not duplicate due to circular refs)
            assert 'callnat' in result
            assert 'MAIN-FUNC' in result['callnat']
    
    def test_get_using_dependencies(self):
        """Test detailed dependency extraction."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            gda_dir = temp_path / "gda"
            gda_dir.mkdir()
            
            # Create main program
            main_program = """
            DEFINE DATA
            GLOBAL USING UTILS-GDA
            END-DEFINE
            
            CALLNAT 'MAIN-PROCESS'
            
            END
            """
            
            # Create global data area with executable code
            utils_gda = """
            DEFINE DATA GLOBAL
            1 SHARED-VAR (A10)
            END-DEFINE
            
            DEFINE SUBROUTINE HELPER-FUNC
            CALLNAT 'HELPER-PROG'
            FETCH 'UTILITY-PROG'
            END-SUBROUTINE
            """
            
            main_file = temp_path / "MAINPROG.NSP"
            main_file.write_text(main_program)
            (gda_dir / "UTILS-GDA.NSG").write_text(utils_gda)
            
            # Test dependency extraction
            dependencies = self.parser.get_using_dependencies(main_program, str(main_file))
            
            # Should have USING dependency
            using_deps = [d for d in dependencies if d.dependency_type == DependencyType.COPY]
            assert len(using_deps) >= 1
            assert any(d.target_artifact == 'UTILS-GDA' for d in using_deps)
            
            # Should have call dependencies via USING
            call_deps = [d for d in dependencies if d.dependency_type == DependencyType.CALL]
            assert len(call_deps) >= 1
            
            # Should have fetch dependencies via USING
            fetch_deps = [d for d in dependencies if d.dependency_type == DependencyType.FETCH]
            assert len(fetch_deps) >= 1
            
            # Check that via_using information is captured in notes
            via_using_deps = [d for d in dependencies if d.notes and 'via using' in d.notes]
            assert len(via_using_deps) >= 1
    
    def test_data_only_using_ignored(self):
        """Test that data-only USING references don't contribute calls."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            gda_dir = temp_path / "gda"
            gda_dir.mkdir()
            
            # Create main program
            main_program = """
            DEFINE DATA
            GLOBAL USING CONSTANTS-GDA
            END-DEFINE
            
            CALLNAT 'MAIN-PROCESS'
            
            END
            """
            
            # Create data-only global data area
            constants_gda = """
            DEFINE DATA GLOBAL
            1 MAX-SIZE (N5) INIT <1000>
            1 ERROR-CODES (A4/5) INIT <'OK', 'WARN', 'ERR1', 'ERR2', 'FAIL'>
            1 CONFIG-VALUES
              2 TIMEOUT (N3) INIT <30>
              2 RETRY-COUNT (N2) INIT <3>
            END-DEFINE
            """
            
            main_file = temp_path / "MAINPROG.NSP"
            main_file.write_text(main_program)
            (gda_dir / "CONSTANTS-GDA.NSG").write_text(constants_gda)
            
            # Test enhanced parsing
            basic_result = self.parser.parse(main_program)
            enhanced_result = self.parser.parse_with_using_analysis(main_program, str(main_file))
            
            # Should have same calls (data-only USING shouldn't add calls)
            assert enhanced_result['callnat'] == basic_result['callnat']
            assert 'MAIN-PROCESS' in enhanced_result['callnat']
    
    def test_using_path_resolution(self):
        """Test USING path resolution with different directory structures."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create different directory structures
            (temp_path / "gda").mkdir()
            (temp_path / "lda").mkdir()
            (temp_path / "copycode").mkdir()
            (temp_path / "natural").mkdir()
            
            # Test different file extensions and locations
            test_cases = [
                ("gda/GLOBAL1.NSG", "GLOBAL1"),
                ("lda/LOCAL1.NSL", "LOCAL1"),
                ("copycode/COPY1.NSC", "COPY1"),
                ("natural/DATA1.NSD", "DATA1"),
            ]
            
            for file_path, using_ref in test_cases:
                full_path = temp_path / file_path
                full_path.write_text("* Test USING reference")
                
                resolved_path = self.parser._resolve_using_path(using_ref, str(temp_path))
                assert resolved_path is not None
                assert os.path.exists(resolved_path)
    
    def test_mixed_using_types(self):
        """Test mixed GLOBAL and LOCAL USING statements."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            gda_dir = temp_path / "gda"
            lda_dir = temp_path / "lda"
            gda_dir.mkdir()
            lda_dir.mkdir()
            
            # Create main program with mixed USING types
            main_program = """
            DEFINE DATA
            GLOBAL USING GLOBAL-DATA
            LOCAL USING LOCAL-DATA
            END-DEFINE
            
            CALLNAT 'MAIN-PROCESS'
            
            END
            """
            
            # Create global data area
            global_data = """
            DEFINE DATA GLOBAL
            1 GLOBAL-VAR (A10)
            END-DEFINE
            
            DEFINE SUBROUTINE GLOBAL-PROC
            CALLNAT 'GLOBAL-HELPER'
            END-SUBROUTINE
            """
            
            # Create local data area
            local_data = """
            DEFINE DATA LOCAL
            1 LOCAL-VAR (A20)
            END-DEFINE
            
            DEFINE SUBROUTINE LOCAL-PROC
            CALLNAT 'LOCAL-HELPER'
            END-SUBROUTINE
            """
            
            main_file = temp_path / "MAINPROG.NSP"
            main_file.write_text(main_program)
            (gda_dir / "GLOBAL-DATA.NSG").write_text(global_data)
            (lda_dir / "LOCAL-DATA.NSL").write_text(local_data)
            
            # Test enhanced parsing
            result = self.parser.parse_with_using_analysis(main_program, str(main_file))
            
            # Should find both USING references
            assert 'using' in result
            assert 'GLOBAL-DATA' in result['using']
            assert 'LOCAL-DATA' in result['using']
            
            # Should find calls from both references
            assert 'callnat' in result
            assert 'MAIN-PROCESS' in result['callnat']
            assert 'GLOBAL-HELPER' in result['callnat']
            assert 'LOCAL-HELPER' in result['callnat']


if __name__ == '__main__':
    pytest.main([__file__, '-v'])