"""Unit tests for flow analysis components."""

import pytest
from tools.legacy_analyzer.models.dependency import Dependency, CircularDependency, DependencyType
from tools.legacy_analyzer.models.flow import ProgramFlow, CallGraph
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from tools.legacy_analyzer.analysis.call_graph import CallGraphBuilder
from tools.legacy_analyzer.analysis.circular_detector import CircularDependencyDetector
from tools.legacy_analyzer.analysis.flow_visualizer import FlowVisualizer, CallGraphVisualizer


@pytest.fixture
def simple_dependencies():
    """Create a simple set of dependencies for testing."""
    return [
        Dependency(
            source_artifact='PROG1',
            source_type='PROGRAM',
            target_artifact='PROG2',
            target_type='PROGRAM',
            dependency_type=DependencyType.CALL
        ),
        Dependency(
            source_artifact='PROG2',
            source_type='PROGRAM',
            target_artifact='PROG3',
            target_type='PROGRAM',
            dependency_type=DependencyType.CALL
        ),
        Dependency(
            source_artifact='PROG1',
            source_type='PROGRAM',
            target_artifact='COPY1',
            target_type='COPYBOOK',
            dependency_type=DependencyType.COPY
        ),
        Dependency(
            source_artifact='PROG2',
            source_type='PROGRAM',
            target_artifact='DS1',
            target_type='DATASET',
            dependency_type=DependencyType.DATASET_REF
        ),
    ]


@pytest.fixture
def circular_dependencies():
    """Create dependencies with circular references."""
    return [
        Dependency(
            source_artifact='PROGA',
            source_type='PROGRAM',
            target_artifact='PROGB',
            target_type='PROGRAM',
            dependency_type=DependencyType.CALL
        ),
        Dependency(
            source_artifact='PROGB',
            source_type='PROGRAM',
            target_artifact='PROGC',
            target_type='PROGRAM',
            dependency_type=DependencyType.CALL
        ),
        Dependency(
            source_artifact='PROGC',
            source_type='PROGRAM',
            target_artifact='PROGA',
            target_type='PROGRAM',
            dependency_type=DependencyType.CALL
        ),
    ]


@pytest.fixture
def complex_dependencies():
    """Create a complex dependency graph."""
    return [
        # Entry point
        Dependency('MAIN', 'PROGRAM', 'SUB1', 'PROGRAM', DependencyType.CALL),
        Dependency('MAIN', 'PROGRAM', 'SUB2', 'PROGRAM', DependencyType.CALL),
        # Second level
        Dependency('SUB1', 'PROGRAM', 'UTIL1', 'PROGRAM', DependencyType.CALL),
        Dependency('SUB1', 'PROGRAM', 'UTIL2', 'PROGRAM', DependencyType.CALL),
        Dependency('SUB2', 'PROGRAM', 'UTIL2', 'PROGRAM', DependencyType.CALL),
        # Third level
        Dependency('UTIL1', 'PROGRAM', 'LEAF1', 'PROGRAM', DependencyType.CALL),
        Dependency('UTIL2', 'PROGRAM', 'LEAF2', 'PROGRAM', DependencyType.CALL),
        # Copybooks
        Dependency('MAIN', 'PROGRAM', 'COPY1', 'COPYBOOK', DependencyType.COPY),
        Dependency('SUB1', 'PROGRAM', 'COPY2', 'COPYBOOK', DependencyType.COPY),
        # Datasets
        Dependency('LEAF1', 'PROGRAM', 'DATA1', 'DATASET', DependencyType.DATASET_REF),
    ]


class TestFlowAnalyzer:
    """Test suite for FlowAnalyzer class."""
    
    def test_analyze_simple_flow(self, simple_dependencies):
        """Test analyzing a simple linear flow."""
        analyzer = FlowAnalyzer(simple_dependencies)
        flow = analyzer.analyze_flow('PROG1')
        
        assert flow.start_program == 'PROG1'
        assert 'PROG1' in flow.programs
        assert 'PROG2' in flow.programs
        assert 'PROG3' in flow.programs
        assert flow.depth == 2
        assert flow.total_programs == 3
    
    def test_analyze_flow_max_depth(self, complex_dependencies):
        """Test that max_depth parameter limits traversal."""
        analyzer = FlowAnalyzer(complex_dependencies)
        flow = analyzer.analyze_flow('MAIN', max_depth=2)
        
        assert flow.depth <= 2
        # Should include MAIN, SUB1, SUB2, UTIL1, UTIL2 but not LEAF1, LEAF2
        assert 'MAIN' in flow.programs
        assert 'SUB1' in flow.programs
    
    def test_get_entry_points(self, complex_dependencies):
        """Test identifying entry point programs."""
        analyzer = FlowAnalyzer(complex_dependencies)
        entry_points = analyzer.get_entry_points()
        
        assert 'MAIN' in entry_points
        assert 'SUB1' not in entry_points
        assert 'LEAF1' not in entry_points
    
    def test_calculate_flow_depth(self, complex_dependencies):
        """Test calculating depth of a program."""
        analyzer = FlowAnalyzer(complex_dependencies)
        
        # MAIN is entry point (depth 0)
        assert analyzer.calculate_flow_depth('MAIN') == 0
        
        # SUB1 is called by MAIN (depth 1)
        # Note: This test may need adjustment based on implementation
    
    def test_get_program_statistics(self, complex_dependencies):
        """Test getting program statistics."""
        analyzer = FlowAnalyzer(complex_dependencies)
        stats = analyzer.get_program_statistics()
        
        assert stats['total_programs'] > 0
        assert stats['entry_points'] >= 1
        assert stats['total_calls'] > 0
    
    def test_analyze_multiple_flows(self, complex_dependencies):
        """Test analyzing multiple flows at once."""
        analyzer = FlowAnalyzer(complex_dependencies)
        flows = analyzer.analyze_multiple_flows(['MAIN', 'SUB1'])
        
        assert 'MAIN' in flows
        assert 'SUB1' in flows
        assert isinstance(flows['MAIN'], ProgramFlow)
        assert isinstance(flows['SUB1'], ProgramFlow)


class TestCallGraphBuilder:
    """Test suite for CallGraphBuilder class."""
    
    def test_build_call_graph_single_program(self, simple_dependencies):
        """Test building call graph for a single program."""
        builder = CallGraphBuilder(simple_dependencies)
        graph = builder.build_call_graph(['PROG1'])
        
        assert 'PROG1' in graph.nodes
        assert 'PROG2' in graph.nodes
        assert 'PROG3' in graph.nodes
        assert ('PROG1', 'PROG2') in graph.edges
        assert ('PROG2', 'PROG3') in graph.edges
    
    def test_build_full_call_graph(self, complex_dependencies):
        """Test building complete call graph."""
        builder = CallGraphBuilder(complex_dependencies)
        graph = builder.build_full_call_graph()
        
        assert len(graph.nodes) > 0
        assert len(graph.edges) > 0
        assert 'MAIN' in graph.nodes
    
    def test_get_callers(self, simple_dependencies):
        """Test getting programs that call a specific program."""
        builder = CallGraphBuilder(simple_dependencies)
        callers = builder.get_callers('PROG2')
        
        assert 'PROG1' in callers
    
    def test_get_callees(self, simple_dependencies):
        """Test getting programs called by a specific program."""
        builder = CallGraphBuilder(simple_dependencies)
        callees = builder.get_callees('PROG1')
        
        assert 'PROG2' in callees
    
    def test_get_entry_points(self, complex_dependencies):
        """Test identifying entry points."""
        builder = CallGraphBuilder(complex_dependencies)
        entry_points = builder.get_entry_points()
        
        assert 'MAIN' in entry_points
    
    def test_get_leaf_programs(self, complex_dependencies):
        """Test identifying leaf programs."""
        builder = CallGraphBuilder(complex_dependencies)
        leaf_programs = builder.get_leaf_programs()
        
        assert 'LEAF1' in leaf_programs
        assert 'LEAF2' in leaf_programs
        assert 'MAIN' not in leaf_programs
    
    def test_add_metadata_to_graph(self, simple_dependencies):
        """Test adding metadata to graph nodes."""
        builder = CallGraphBuilder(simple_dependencies)
        graph = builder.build_call_graph(['PROG1'])
        
        def metadata_provider(program):
            return {'complexity': 10, 'loc': 100}
        
        builder.add_metadata_to_graph(graph, metadata_provider)
        
        assert 'PROG1' in graph.metadata
        assert graph.metadata['PROG1']['complexity'] == 10


class TestCircularDependencyDetector:
    """Test suite for CircularDependencyDetector class."""
    
    def test_detect_simple_cycle(self, circular_dependencies):
        """Test detecting a simple circular dependency."""
        detector = CircularDependencyDetector(circular_dependencies)
        cycles = detector.detect_all_cycles()
        
        assert len(cycles) > 0
        cycle = cycles[0]
        assert 'PROGA' in cycle.artifacts
        assert 'PROGB' in cycle.artifacts
        assert 'PROGC' in cycle.artifacts
    
    def test_no_cycles_in_linear_flow(self, simple_dependencies):
        """Test that no cycles are detected in linear flow."""
        detector = CircularDependencyDetector(simple_dependencies)
        cycles = detector.detect_all_cycles()
        
        assert len(cycles) == 0
    
    def test_has_cycle_involving(self, circular_dependencies):
        """Test checking if a program is in a cycle."""
        detector = CircularDependencyDetector(circular_dependencies)
        
        assert detector.has_cycle_involving('PROGA') is True
        assert detector.has_cycle_involving('PROGB') is True
        assert detector.has_cycle_involving('PROGC') is True
    
    def test_get_cycles_involving(self, circular_dependencies):
        """Test getting all cycles involving a program."""
        detector = CircularDependencyDetector(circular_dependencies)
        cycles = detector.get_cycles_involving('PROGA')
        
        assert len(cycles) > 0
        assert 'PROGA' in cycles[0].artifacts
    
    def test_detect_cycle_from_program(self, circular_dependencies):
        """Test detecting cycle starting from specific program."""
        detector = CircularDependencyDetector(circular_dependencies)
        cycle = detector.detect_cycle_from_program('PROGA')
        
        assert cycle is not None
        assert 'PROGA' in cycle.artifacts


class TestFlowVisualizer:
    """Test suite for FlowVisualizer class."""
    
    def test_to_dot_format(self, simple_dependencies):
        """Test exporting flow to DOT format."""
        analyzer = FlowAnalyzer(simple_dependencies)
        flow = analyzer.analyze_flow('PROG1')
        visualizer = FlowVisualizer(flow, simple_dependencies)
        
        dot = visualizer.to_dot()
        
        assert 'digraph ProgramFlow' in dot
        assert 'PROG1' in dot
        assert 'PROG2' in dot
        assert '->' in dot
    
    def test_to_dot_with_copybooks(self, simple_dependencies):
        """Test DOT format includes copybooks."""
        analyzer = FlowAnalyzer(simple_dependencies)
        flow = analyzer.analyze_flow('PROG1')
        visualizer = FlowVisualizer(flow, simple_dependencies)
        
        dot = visualizer.to_dot(include_copybooks=True)
        
        assert 'COPY1' in dot
        assert 'shape=note' in dot
    
    def test_to_dot_without_copybooks(self, simple_dependencies):
        """Test DOT format excludes copybooks when requested."""
        analyzer = FlowAnalyzer(simple_dependencies)
        flow = analyzer.analyze_flow('PROG1')
        visualizer = FlowVisualizer(flow, simple_dependencies)
        
        dot = visualizer.to_dot(include_copybooks=False)
        
        assert 'COPY1' not in dot
    
    def test_to_mermaid_format(self, simple_dependencies):
        """Test exporting flow to Mermaid format."""
        analyzer = FlowAnalyzer(simple_dependencies)
        flow = analyzer.analyze_flow('PROG1')
        visualizer = FlowVisualizer(flow, simple_dependencies)
        
        mermaid = visualizer.to_mermaid()
        
        assert 'graph TD' in mermaid
        assert 'PROG1' in mermaid
        assert '-->' in mermaid
    
    def test_to_json_format(self, simple_dependencies):
        """Test exporting flow to JSON format."""
        analyzer = FlowAnalyzer(simple_dependencies)
        flow = analyzer.analyze_flow('PROG1')
        visualizer = FlowVisualizer(flow, simple_dependencies)
        
        json_str = visualizer.to_json()
        
        assert 'start_program' in json_str
        assert 'PROG1' in json_str
        assert 'dependencies' in json_str
    
    def test_circular_dependency_in_visualization(self, circular_dependencies):
        """Test that circular dependencies are shown in visualization."""
        analyzer = FlowAnalyzer(circular_dependencies)
        flow = analyzer.analyze_flow('PROGA')
        visualizer = FlowVisualizer(flow, circular_dependencies)
        
        dot = visualizer.to_dot()
        
        # Should have comment about circular dependencies
        assert 'Circular' in dot or 'Cycle' in dot


class TestCallGraphVisualizer:
    """Test suite for CallGraphVisualizer class."""
    
    def test_call_graph_to_dot(self, simple_dependencies):
        """Test exporting call graph to DOT format."""
        builder = CallGraphBuilder(simple_dependencies)
        graph = builder.build_call_graph(['PROG1'])
        visualizer = CallGraphVisualizer(graph)
        
        dot = visualizer.to_dot()
        
        assert 'digraph CallGraph' in dot
        assert 'PROG1' in dot
    
    def test_call_graph_to_mermaid(self, simple_dependencies):
        """Test exporting call graph to Mermaid format."""
        builder = CallGraphBuilder(simple_dependencies)
        graph = builder.build_call_graph(['PROG1'])
        visualizer = CallGraphVisualizer(graph)
        
        mermaid = visualizer.to_mermaid()
        
        assert 'graph LR' in mermaid
        assert 'PROG1' in mermaid
    
    def test_call_graph_to_json(self, simple_dependencies):
        """Test exporting call graph to JSON format."""
        builder = CallGraphBuilder(simple_dependencies)
        graph = builder.build_call_graph(['PROG1'])
        visualizer = CallGraphVisualizer(graph)
        
        json_str = visualizer.to_json()
        
        assert 'nodes' in json_str
        assert 'edges' in json_str


class TestProgramFlow:
    """Test suite for ProgramFlow data model."""
    
    def test_program_flow_creation(self):
        """Test creating a ProgramFlow object."""
        flow = ProgramFlow(
            start_program='TEST',
            depth=2,
            programs=['TEST', 'SUB1', 'SUB2'],
            dependencies=[]
        )
        
        assert flow.start_program == 'TEST'
        assert flow.depth == 2
        assert len(flow.programs) == 3
        assert flow.total_programs == 3
    
    def test_has_circular_dependencies(self):
        """Test checking for circular dependencies."""
        cycle = CircularDependency(
            artifacts=['A', 'B', 'C'],
            dependency_types=['CALL', 'CALL', 'CALL']
        )
        
        flow = ProgramFlow(
            start_program='A',
            depth=2,
            programs=['A', 'B', 'C'],
            dependencies=[],
            circular_dependencies=[cycle]
        )
        
        assert flow.has_circular_dependencies() is True
    
    def test_no_circular_dependencies(self):
        """Test flow without circular dependencies."""
        flow = ProgramFlow(
            start_program='TEST',
            depth=2,
            programs=['TEST', 'SUB1'],
            dependencies=[]
        )
        
        assert flow.has_circular_dependencies() is False


class TestFlowAnalyzerWithMetadata:
    """Test suite for FlowAnalyzer with metadata integration."""
    
    @pytest.fixture
    def mock_db_with_cics(self, tmp_path):
        """Create a mock database with CICS metadata."""
        import sqlite3
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Create inventory_cics table
        cursor.execute("""
            CREATE TABLE inventory_cics (
                resource_name VARCHAR(8),
                resource_type VARCHAR(20),
                program_name VARCHAR(44),
                group_name VARCHAR(20),
                status VARCHAR(10),
                description TEXT
            )
        """)
        
        # Insert test data
        cursor.execute("""
            INSERT INTO inventory_cics VALUES
            ('TRAN1', 'TRANSACTION', 'PROG1', 'GROUP1', 'ENABLED', 'Test transaction 1'),
            ('TRAN2', 'TRANSACTION', 'PROG2', 'GROUP1', 'ENABLED', 'Test transaction 2'),
            ('TRAN3', 'TRANSACTION', 'PROG3', 'GROUP1', 'DISABLED', 'Disabled transaction')
        """)
        
        # Create artifact_dependencies table
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name VARCHAR(44),
                source_artifact_type VARCHAR(20),
                target_artifact_name VARCHAR(44),
                target_artifact_type VARCHAR(20),
                dependency_type VARCHAR(20)
            )
        """)
        
        # Insert JCL dependencies
        cursor.execute("""
            INSERT INTO artifact_dependencies VALUES
            ('JOB1', 'JCL', 'BATCH1', 'PROGRAM', 'EXEC_PGM'),
            ('JOB2', 'JCL', 'BATCH2', 'PROGRAM', 'EXEC_PGM')
        """)
        
        conn.commit()
        return conn
    
    @pytest.fixture
    def mock_db_without_cics(self, tmp_path):
        """Create a mock database without CICS metadata."""
        import sqlite3
        db_path = tmp_path / "test_no_cics.db"
        conn = sqlite3.connect(str(db_path))
        return conn
    
    def test_get_entry_points_with_metadata(self, simple_dependencies, mock_db_with_cics):
        """Test getting entry points with metadata enabled."""
        analyzer = FlowAnalyzer(simple_dependencies, db_connection=mock_db_with_cics)
        
        # Get entry points with metadata
        entry_points = analyzer.get_entry_points(use_metadata=True)
        
        # Should include CICS transactions
        assert 'PROG1' in entry_points
        assert 'PROG2' in entry_points
        # PROG3 is disabled, should not be included by default
        assert 'PROG3' not in entry_points
    
    def test_get_entry_points_with_metadata_include_disabled(self, simple_dependencies, mock_db_with_cics):
        """Test getting entry points including disabled transactions."""
        analyzer = FlowAnalyzer(simple_dependencies, db_connection=mock_db_with_cics)
        
        # Get entry points with disabled included
        entry_points = analyzer.get_entry_points(
            use_metadata=True,
            include_disabled=True
        )
        
        # Should include disabled transaction
        assert 'PROG3' in entry_points
    
    def test_get_entry_points_backward_compatibility(self, simple_dependencies):
        """Test that get_entry_points maintains backward compatibility."""
        # Without database connection
        analyzer = FlowAnalyzer(simple_dependencies)
        
        # Should work without metadata
        entry_points = analyzer.get_entry_points()
        
        # Should return list of strings
        assert isinstance(entry_points, list)
        assert all(isinstance(ep, str) for ep in entry_points)
    
    def test_get_entry_points_with_metadata_returns_strings(self, simple_dependencies, mock_db_with_cics):
        """Test that get_entry_points returns strings even with metadata."""
        analyzer = FlowAnalyzer(simple_dependencies, db_connection=mock_db_with_cics)
        
        # Get entry points with metadata
        entry_points = analyzer.get_entry_points(use_metadata=True)
        
        # Should still return list of strings for backward compatibility
        assert isinstance(entry_points, list)
        assert all(isinstance(ep, str) for ep in entry_points)
    
    def test_get_entry_points_with_metadata_fallback(self, simple_dependencies, mock_db_without_cics):
        """Test fallback to code analysis when metadata unavailable."""
        analyzer = FlowAnalyzer(simple_dependencies, db_connection=mock_db_without_cics)
        
        # Request metadata but it's not available
        entry_points = analyzer.get_entry_points(use_metadata=True)
        
        # Should fall back to code analysis
        assert isinstance(entry_points, list)
        # PROG1 is not called by anyone, so it's an entry point
        assert 'PROG1' in entry_points
    
    def test_get_entry_points_with_metadata_objects(self, simple_dependencies, mock_db_with_cics):
        """Test getting entry points with full metadata objects."""
        analyzer = FlowAnalyzer(simple_dependencies, db_connection=mock_db_with_cics)
        
        # Get entry points with metadata objects
        entry_points = analyzer.get_entry_points_with_metadata()
        
        # Should return EntryPoint objects
        from tools.legacy_analyzer.models.flow import EntryPoint
        assert all(isinstance(ep, EntryPoint) for ep in entry_points)
        
        # Check that ONLINE entry points have transaction IDs
        online_entries = [ep for ep in entry_points if ep.entry_type == 'ONLINE']
        assert len(online_entries) > 0
        for ep in online_entries:
            assert ep.transaction_id is not None
            assert ep.confidence == 'EXPLICIT'
            assert ep.source == 'CSD'
    
    def test_get_entry_points_with_metadata_objects_fallback(self, simple_dependencies):
        """Test getting entry points with metadata objects when no DB available."""
        analyzer = FlowAnalyzer(simple_dependencies)
        
        # Get entry points with metadata objects (no DB)
        entry_points = analyzer.get_entry_points_with_metadata()
        
        # Should return EntryPoint objects with INFERRED confidence
        from tools.legacy_analyzer.models.flow import EntryPoint
        assert all(isinstance(ep, EntryPoint) for ep in entry_points)
        
        # All should be INFERRED
        assert all(ep.confidence == 'INFERRED' for ep in entry_points)
        assert all(ep.entry_type == 'INFERRED' for ep in entry_points)
        assert all(ep.source == 'CODE_ANALYSIS' for ep in entry_points)
    
    def test_get_entry_points_with_metadata_priority(self, mock_db_with_cics):
        """Test that metadata sources are prioritized correctly."""
        # Create dependencies where PROG1 is both a CICS transaction and called by PROG2
        deps = [
            Dependency(
                source_artifact='PROG2',
                source_type='PROGRAM',
                target_artifact='PROG1',
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL
            )
        ]
        
        analyzer = FlowAnalyzer(deps, db_connection=mock_db_with_cics)
        
        # Get entry points with metadata
        entry_points = analyzer.get_entry_points_with_metadata()
        
        # PROG1 should still be included as ONLINE entry point
        # even though it's called by PROG2
        prog1_entries = [ep for ep in entry_points if ep.program_name == 'PROG1']
        assert len(prog1_entries) == 1
        assert prog1_entries[0].entry_type == 'ONLINE'
        assert prog1_entries[0].confidence == 'EXPLICIT'
    
    def test_get_entry_points_with_metadata_batch(self, mock_db_with_cics):
        """Test detection of BATCH entry points from JCL."""
        # Create dependencies without CICS transactions
        deps = [
            Dependency(
                source_artifact='BATCH1',
                source_type='PROGRAM',
                target_artifact='SUB1',
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL
            )
        ]
        
        analyzer = FlowAnalyzer(deps, db_connection=mock_db_with_cics)
        
        # Get entry points with metadata
        entry_points = analyzer.get_entry_points_with_metadata()
        
        # Should include BATCH entry points
        batch_entries = [ep for ep in entry_points if ep.entry_type == 'BATCH']
        assert len(batch_entries) > 0
        
        # Check BATCH1 is included
        batch1_entries = [ep for ep in batch_entries if ep.program_name == 'BATCH1']
        assert len(batch1_entries) == 1
        assert batch1_entries[0].jcl_name is not None
        assert batch1_entries[0].confidence == 'EXPLICIT'
        assert batch1_entries[0].source == 'JCL'


class TestCallGraph:
    """Test suite for CallGraph data model."""
    
    def test_call_graph_creation(self):
        """Test creating a CallGraph object."""
        graph = CallGraph(
            nodes=['A', 'B', 'C'],
            edges=[('A', 'B'), ('B', 'C')]
        )
        
        assert len(graph.nodes) == 3
        assert len(graph.edges) == 2
    
    def test_add_node(self):
        """Test adding nodes to graph."""
        graph = CallGraph(nodes=[], edges=[])
        graph.add_node('A')
        graph.add_node('B', complexity=10)
        
        assert 'A' in graph.nodes
        assert 'B' in graph.nodes
        assert graph.metadata['B']['complexity'] == 10
    
    def test_add_edge(self):
        """Test adding edges to graph."""
        graph = CallGraph(nodes=['A', 'B'], edges=[])
        graph.add_edge('A', 'B')
        
        assert ('A', 'B') in graph.edges
    
    def test_get_callers(self):
        """Test getting callers of a node."""
        graph = CallGraph(
            nodes=['A', 'B', 'C'],
            edges=[('A', 'B'), ('C', 'B')]
        )
        
        callers = graph.get_callers('B')
        
        assert 'A' in callers
        assert 'C' in callers
    
    def test_get_callees(self):
        """Test getting callees of a node."""
        graph = CallGraph(
            nodes=['A', 'B', 'C'],
            edges=[('A', 'B'), ('A', 'C')]
        )
        
        callees = graph.get_callees('A')
        
        assert 'B' in callees
        assert 'C' in callees
    
    def test_to_dict(self):
        """Test converting graph to dictionary."""
        graph = CallGraph(
            nodes=['A', 'B'],
            edges=[('A', 'B')],
            metadata={'A': {'complexity': 5}}
        )
        
        result = graph.to_dict()
        
        assert 'nodes' in result
        assert 'edges' in result
        assert 'metadata' in result
        assert result['nodes'] == ['A', 'B']
