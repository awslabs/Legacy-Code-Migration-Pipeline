"""
Property-based tests for codebase membership checking

Tests cover:
- Property 2: Codebase Programs Excluded from Inbound Interfaces
  For any program in the codebase calling a flow program,
  no inbound interface should be created.
"""

import sqlite3
import tempfile
import os
from hypothesis import given, strategies as st, settings, HealthCheck

from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder
from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager


def create_minimal_database_schema(conn):
    """Create minimal database schema required for MigrationFlowBuilder."""
    cursor = conn.cursor()
    
    # Create artifact_dependencies table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS artifact_dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_artifact_name TEXT NOT NULL,
            source_artifact_type TEXT NOT NULL,
            target_artifact_name TEXT NOT NULL,
            target_artifact_type TEXT NOT NULL,
            dependency_type TEXT NOT NULL,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    # Create external_program_config table (required by ExternalConfigLoader)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS external_program_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern TEXT NOT NULL UNIQUE,
            is_pattern INTEGER DEFAULT 0,
            reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create external_caller_config table (required by ExternalConfigLoader)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS external_caller_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            caller_name TEXT NOT NULL,
            target_program TEXT NOT NULL,
            call_type TEXT NOT NULL,
            metadata_json TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(caller_name, target_program, call_type)
        )
    """)
    
    # Create program_file_mapping table (required by ExternalConfigLoader)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT NOT NULL,
            language TEXT
        )
    """)
    
    # Create inventory table (required by ExternalConfigLoader for program_file_mapping fallback)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            artifact_name TEXT NOT NULL,
            artifact_type TEXT NOT NULL,
            file_path TEXT,
            language TEXT
        )
    """)
    
    conn.commit()


@given(
    codebase_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd', 'Pc'))),
        min_size=2,
        max_size=20,
        unique=True
    )
)
@settings(max_examples=100, suppress_health_check=[HealthCheck.filter_too_much])
def test_property_codebase_programs_excluded(codebase_programs):
    """
    Property: For any program in the codebase calling a flow program,
    the program should be recognized as in the codebase.
    
    **Feature: fix-inbound-interface-logic, Property 2: Codebase Programs Excluded from Inbound Interfaces**
    **Validates: Requirements 1.2, 3.1, 5.1**
    """
    # Create temporary database
    fd, temp_db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(temp_db_path)
    
    try:
        # Create minimal schema
        create_minimal_database_schema(conn)
        cursor = conn.cursor()
        
        # Insert codebase programs into artifact_dependencies
        for program in codebase_programs:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'PROGRAM', 'DUMMY_TARGET', 'PROGRAM', 'PROGRAM_CALL')
            """, (program,))
        
        conn.commit()
        
        # Create schema for external interfaces
        schema_manager = InterfaceSchemaManager(conn)
        schema_manager.create_tables()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(conn)
        
        # Test: Check that all codebase programs are recognized
        for program in codebase_programs:
            is_in_codebase = flow_builder._is_program_in_codebase(program)
            assert is_in_codebase, \
                f"Program {program} should be recognized as in codebase"
        
        # Test: Check that a non-existent program is not in codebase
        is_external = flow_builder._is_program_in_codebase('NONEXISTENT_PROGRAM_XYZ')
        assert not is_external, \
            "Non-existent program should not be in codebase"
        
        # Test: Verify caching works (second call should use cache)
        for program in codebase_programs[:3]:  # Test first 3 programs
            is_in_codebase_cached = flow_builder._is_program_in_codebase(program)
            assert is_in_codebase_cached, \
                f"Cached result for {program} should be True"
        
    finally:
        conn.close()
        os.unlink(temp_db_path)


@given(
    programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd', 'Pc'))),
        min_size=1,
        max_size=50,
        unique=True
    )
)
@settings(max_examples=100)
def test_property_codebase_check_consistency(programs):
    """
    Property: For any set of programs, codebase membership check should be consistent
    across multiple calls.
    
    **Feature: fix-inbound-interface-logic, Property 2: Codebase Programs Excluded**
    """
    # Create temporary database
    fd, temp_db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(temp_db_path)
    
    try:
        # Create minimal schema
        create_minimal_database_schema(conn)
        cursor = conn.cursor()
        
        # Split programs into codebase and external
        split_point = len(programs) // 2
        codebase_programs = programs[:split_point]
        external_programs = programs[split_point:]
        
        # Insert codebase programs
        for program in codebase_programs:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'PROGRAM', 'DUMMY_TARGET', 'PROGRAM', 'PROGRAM_CALL')
            """, (program,))
        
        conn.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(conn)
        
        # Test: Check all codebase programs are recognized
        for program in codebase_programs:
            is_in_codebase = flow_builder._is_program_in_codebase(program)
            assert is_in_codebase, \
                f"Program {program} should be in codebase"
            
            # Check again (should use cache)
            is_in_codebase_cached = flow_builder._is_program_in_codebase(program)
            assert is_in_codebase_cached, \
                f"Cached result for {program} should be True"
        
        # Test: Check all external programs are not recognized
        for program in external_programs:
            is_in_codebase = flow_builder._is_program_in_codebase(program)
            assert not is_in_codebase, \
                f"Program {program} should not be in codebase"
            
            # Check again (should use cache)
            is_in_codebase_cached = flow_builder._is_program_in_codebase(program)
            assert not is_in_codebase_cached, \
                f"Cached result for {program} should be False"
        
    finally:
        conn.close()
        os.unlink(temp_db_path)


@given(
    program_name=st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd', 'Pc'))),
    num_dependencies=st.integers(min_value=0, max_value=100)
)
@settings(max_examples=100)
def test_property_codebase_membership_threshold(program_name, num_dependencies):
    """
    Property: A program is in the codebase if and only if it has at least one dependency
    as a source_artifact_name.
    
    **Feature: fix-inbound-interface-logic, Property 2: Codebase Programs Excluded**
    """
    # Create temporary database
    fd, temp_db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(temp_db_path)
    
    try:
        # Create minimal schema
        create_minimal_database_schema(conn)
        cursor = conn.cursor()
        
        # Insert num_dependencies dependencies for the program
        for i in range(num_dependencies):
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'PROGRAM', ?, 'PROGRAM', 'PROGRAM_CALL')
            """, (program_name, f'TARGET_{i}'))
        
        conn.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(conn)
        
        # Test: Check codebase membership
        is_in_codebase = flow_builder._is_program_in_codebase(program_name)
        
        # Property: Program is in codebase if and only if it has dependencies
        expected_in_codebase = num_dependencies > 0
        assert is_in_codebase == expected_in_codebase, \
            f"Program with {num_dependencies} dependencies should {'be' if expected_in_codebase else 'not be'} in codebase"
        
    finally:
        conn.close()
        os.unlink(temp_db_path)
