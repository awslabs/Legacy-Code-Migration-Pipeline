"""
Property-based tests for InterfaceSchemaManager

Tests cover:
- Property 8: Database Schema Creation Idempotence
  For any number of schema creation calls, tables should be created exactly once.
"""

import sqlite3
import tempfile
import os
from hypothesis import given, strategies as st, settings

from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager


@given(num_calls=st.integers(min_value=1, max_value=10))
@settings(max_examples=100)
def test_property_schema_creation_idempotent(num_calls):
    """
    Property: For any number of schema creation calls,
    tables should be created exactly once.
    
    **Feature: fix-inbound-interface-logic, Property 8: Database Schema Creation Idempotence**
    **Validates: Requirements 7.3**
    """
    # Create temporary database
    fd, temp_db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(temp_db_path)
    schema_manager = InterfaceSchemaManager(conn)
    
    try:
        # Call create_tables() num_calls times
        for _ in range(num_calls):
            schema_manager.create_tables()
        
        # Verify tables exist
        assert schema_manager.table_exists('inbound_interfaces'), \
            "inbound_interfaces table should exist"
        assert schema_manager.table_exists('outbound_interfaces'), \
            "outbound_interfaces table should exist"
        
        # Verify table schema is correct
        cursor = conn.cursor()
        
        # Check inbound_interfaces schema
        cursor.execute("PRAGMA table_info(inbound_interfaces)")
        inbound_columns = cursor.fetchall()
        inbound_column_names = [col[1] for col in inbound_columns]
        
        assert 'id' in inbound_column_names
        assert 'source_name' in inbound_column_names
        assert 'target_program' in inbound_column_names
        assert 'dependency_type' in inbound_column_names
        assert 'is_configured' in inbound_column_names
        assert 'metadata' in inbound_column_names
        assert 'created_at' in inbound_column_names
        
        # Check outbound_interfaces schema
        cursor.execute("PRAGMA table_info(outbound_interfaces)")
        outbound_columns = cursor.fetchall()
        outbound_column_names = [col[1] for col in outbound_columns]
        
        assert 'id' in outbound_column_names
        assert 'program_name' in outbound_column_names
        assert 'reason' in outbound_column_names
        assert 'metadata' in outbound_column_names
        assert 'created_at' in outbound_column_names
        
        # Verify indexes exist
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND tbl_name='inbound_interfaces'
        """)
        inbound_indexes = cursor.fetchall()
        inbound_index_names = [idx[0] for idx in inbound_indexes]
        
        assert 'idx_inbound_target' in inbound_index_names
        assert 'idx_inbound_source' in inbound_index_names
        
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND tbl_name='outbound_interfaces'
        """)
        outbound_indexes = cursor.fetchall()
        outbound_index_names = [idx[0] for idx in outbound_indexes]
        
        assert 'idx_outbound_program' in outbound_index_names
        
        # Verify no duplicate tables were created
        cursor.execute("""
            SELECT COUNT(*) FROM sqlite_master 
            WHERE type='table' AND name='inbound_interfaces'
        """)
        inbound_count = cursor.fetchone()[0]
        assert inbound_count == 1, "Should have exactly one inbound_interfaces table"
        
        cursor.execute("""
            SELECT COUNT(*) FROM sqlite_master 
            WHERE type='table' AND name='outbound_interfaces'
        """)
        outbound_count = cursor.fetchone()[0]
        assert outbound_count == 1, "Should have exactly one outbound_interfaces table"
        
    finally:
        conn.close()
        os.unlink(temp_db_path)


@given(
    num_create_calls=st.integers(min_value=1, max_value=5),
    num_check_calls=st.integers(min_value=1, max_value=5)
)
@settings(max_examples=100)
def test_property_table_exists_consistent(num_create_calls, num_check_calls):
    """
    Property: For any number of create_tables and table_exists calls,
    table_exists should consistently return True after creation.
    
    **Feature: fix-inbound-interface-logic, Property 8: Database Schema Creation Idempotence**
    """
    # Create temporary database
    fd, temp_db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(temp_db_path)
    schema_manager = InterfaceSchemaManager(conn)
    
    try:
        # Call create_tables() multiple times
        for _ in range(num_create_calls):
            schema_manager.create_tables()
        
        # Call table_exists() multiple times and verify consistency
        for _ in range(num_check_calls):
            assert schema_manager.table_exists('inbound_interfaces'), \
                "inbound_interfaces should exist after creation"
            assert schema_manager.table_exists('outbound_interfaces'), \
                "outbound_interfaces should exist after creation"
            assert not schema_manager.table_exists('nonexistent_table'), \
                "nonexistent_table should not exist"
        
    finally:
        conn.close()
        os.unlink(temp_db_path)


@given(
    interfaces=st.lists(
        st.tuples(
            st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd', 'Pc'))),
            st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd', 'Pc'))),
            st.sampled_from(['PROGRAM_CALL', 'CICS_LINK', 'CICS_XCTL', 'EXTERNAL_CALL'])
        ),
        min_size=1,
        max_size=20,
        unique=True
    )
)
@settings(max_examples=100)
def test_property_unique_constraint_prevents_duplicates(interfaces):
    """
    Property: For any set of interfaces, the UNIQUE constraint should prevent duplicates.
    
    **Feature: fix-inbound-interface-logic, Property 8: Database Schema Creation Idempotence**
    """
    # Create temporary database
    fd, temp_db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(temp_db_path)
    schema_manager = InterfaceSchemaManager(conn)
    
    try:
        schema_manager.create_tables()
        cursor = conn.cursor()
        
        # Insert all interfaces
        for source, target, dep_type in interfaces:
            cursor.execute("""
                INSERT OR IGNORE INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured)
                VALUES (?, ?, ?, ?)
            """, (source, target, dep_type, 1))
        conn.commit()
        
        # Try to insert duplicates (should be ignored)
        for source, target, dep_type in interfaces:
            cursor.execute("""
                INSERT OR IGNORE INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured)
                VALUES (?, ?, ?, ?)
            """, (source, target, dep_type, 1))
        conn.commit()
        
        # Verify count matches original list (no duplicates)
        cursor.execute("SELECT COUNT(*) FROM inbound_interfaces")
        count = cursor.fetchone()[0]
        assert count == len(interfaces), \
            f"Should have {len(interfaces)} interfaces, but found {count}"
        
    finally:
        conn.close()
        os.unlink(temp_db_path)
