"""Unit tests for complexity analyzer."""

import pytest
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer
from tools.legacy_analyzer.models.complexity import ComplexityMetrics, ComplexityThresholds


class TestComplexityAnalyzer:
    """Test suite for ComplexityAnalyzer."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.analyzer = ComplexityAnalyzer()
    
    def test_calculate_loc_simple(self):
        """Test LOC calculation with simple code."""
        source_code = """
        PROGRAM-ID. TEST.
        PROCEDURE DIVISION.
            DISPLAY 'HELLO'.
            STOP RUN.
        """
        
        result = self.analyzer.calculate_loc(source_code, 'COBOL')
        
        assert result['loc'] > 0
        assert result['total_lines'] == len(source_code.split('\n'))
        assert result['blank_lines'] >= 0
        assert result['comment_lines'] >= 0
    
    def test_calculate_loc_with_comments(self):
        """Test LOC calculation with comments."""
        source_code = """
      * This is a comment
        PROGRAM-ID. TEST.
      * Another comment
        PROCEDURE DIVISION.
            DISPLAY 'HELLO'.
            STOP RUN.
        """
        
        result = self.analyzer.calculate_loc(source_code, 'COBOL')
        
        # Should have at least 2 comment lines
        assert result['comment_lines'] >= 2
        # LOC should exclude comments
        assert result['loc'] < result['total_lines']
    
    def test_calculate_loc_with_blank_lines(self):
        """Test LOC calculation with blank lines."""
        source_code = """
        PROGRAM-ID. TEST.
        
        PROCEDURE DIVISION.
        
            DISPLAY 'HELLO'.
            
            STOP RUN.
        """
        
        result = self.analyzer.calculate_loc(source_code, 'COBOL')
        
        # Should have blank lines
        assert result['blank_lines'] > 0
        # LOC should exclude blank lines
        assert result['loc'] < result['total_lines']
    
    def test_calculate_cyclomatic_complexity_cobol_simple(self):
        """Test cyclomatic complexity for simple COBOL."""
        source_code = """
        PROGRAM-ID. TEST.
        PROCEDURE DIVISION.
            DISPLAY 'HELLO'.
            STOP RUN.
        """
        
        complexity = self.analyzer.calculate_cyclomatic_complexity(source_code, 'COBOL')
        
        # Simple program should have complexity of 1
        assert complexity == 1
    
    def test_calculate_cyclomatic_complexity_cobol_with_if(self):
        """Test cyclomatic complexity for COBOL with IF statements."""
        source_code = """
        PROGRAM-ID. TEST.
        PROCEDURE DIVISION.
            IF A > B
                DISPLAY 'A IS GREATER'
            END-IF.
            IF C = D
                DISPLAY 'C EQUALS D'
            END-IF.
            STOP RUN.
        """
        
        complexity = self.analyzer.calculate_cyclomatic_complexity(source_code, 'COBOL')
        
        # Base (1) + 2 IF statements = 3
        assert complexity == 3
    
    def test_calculate_cyclomatic_complexity_cobol_with_evaluate(self):
        """Test cyclomatic complexity for COBOL with EVALUATE."""
        source_code = """
        PROGRAM-ID. TEST.
        PROCEDURE DIVISION.
            EVALUATE TRUE
                WHEN A > B
                    DISPLAY 'CASE 1'
                WHEN C = D
                    DISPLAY 'CASE 2'
                WHEN OTHER
                    DISPLAY 'DEFAULT'
            END-EVALUATE.
            STOP RUN.
        """
        
        complexity = self.analyzer.calculate_cyclomatic_complexity(source_code, 'COBOL')
        
        # Base (1) + 3 WHEN clauses = 4
        assert complexity == 4
    
    def test_calculate_cyclomatic_complexity_cobol_with_perform(self):
        """Test cyclomatic complexity for COBOL with PERFORM UNTIL."""
        source_code = """
        PROGRAM-ID. TEST.
        PROCEDURE DIVISION.
            PERFORM UNTIL A > 10
                ADD 1 TO A
            END-PERFORM.
            STOP RUN.
        """
        
        complexity = self.analyzer.calculate_cyclomatic_complexity(source_code, 'COBOL')
        
        # Base (1) + 1 PERFORM UNTIL = 2
        assert complexity == 2
    
    def test_calculate_cyclomatic_complexity_cobol_with_logical_operators(self):
        """Test cyclomatic complexity for COBOL with AND/OR."""
        source_code = """
        PROGRAM-ID. TEST.
        PROCEDURE DIVISION.
            IF A > B AND C < D OR E = F
                DISPLAY 'COMPLEX CONDITION'
            END-IF.
            STOP RUN.
        """
        
        complexity = self.analyzer.calculate_cyclomatic_complexity(source_code, 'COBOL')
        
        # Base (1) + 1 IF + 1 AND + 1 OR = 4
        assert complexity == 4
    
    def test_calculate_cyclomatic_complexity_pli(self):
        """Test cyclomatic complexity for PL/I."""
        source_code = """
        TEST: PROC OPTIONS(MAIN);
            IF A > B THEN
                PUT SKIP LIST('A IS GREATER');
            DO WHILE (I < 10);
                I = I + 1;
            END;
        END TEST;
        """
        
        complexity = self.analyzer.calculate_cyclomatic_complexity(source_code, 'PLI')
        
        # Base (1) + 1 IF + 1 DO WHILE = 3
        assert complexity == 3
    
    def test_calculate_cyclomatic_complexity_jcl(self):
        """Test cyclomatic complexity for JCL."""
        source_code = """
        //TESTJOB JOB
        //STEP1 EXEC PGM=PROG1,COND=(4,LT)
        //STEP2 EXEC PGM=PROG2
        //IF (STEP1.RC = 0) THEN
        //  STEP3 EXEC PGM=PROG3
        //ENDIF
        """
        
        complexity = self.analyzer.calculate_cyclomatic_complexity(source_code, 'JCL')
        
        # Base (1) + 1 COND + 1 IF = 3
        assert complexity == 3
    
    def test_analyze_program_simple(self):
        """Test analyzing a simple program."""
        source_code = """
        PROGRAM-ID. TEST.
        PROCEDURE DIVISION.
            DISPLAY 'HELLO'.
            STOP RUN.
        """
        
        metrics = self.analyzer.analyze_program(
            program_name='TEST',
            source_code=source_code,
            language='COBOL',
            dependency_count_in=2,
            dependency_count_out=3
        )
        
        assert metrics.program_name == 'TEST'
        assert metrics.language == 'COBOL'
        assert metrics.lines_of_code > 0
        assert metrics.cyclomatic_complexity >= 1
        assert metrics.dependency_count_in == 2
        assert metrics.dependency_count_out == 3
        assert metrics.composite_score > 0
        assert metrics.complexity_tier in ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH']
    
    def test_analyze_program_complex(self):
        """Test analyzing a complex program."""
        # Create a program with high complexity
        source_code = """
        PROGRAM-ID. COMPLEX.
        PROCEDURE DIVISION.
        """ + "\n".join([f"    IF A{i} > B{i}\n        DISPLAY 'TEST{i}'\n    END-IF." 
                         for i in range(20)]) + """
            STOP RUN.
        """
        
        metrics = self.analyzer.analyze_program(
            program_name='COMPLEX',
            source_code=source_code,
            language='COBOL',
            dependency_count_in=10,
            dependency_count_out=15
        )
        
        assert metrics.cyclomatic_complexity > 10
        assert metrics.complexity_tier in ['MEDIUM', 'HIGH', 'VERY_HIGH']
    
    def test_composite_score_calculation(self):
        """Test composite score calculation."""
        score = ComplexityMetrics.calculate_composite_score(
            loc=1000,
            cyclomatic=20,
            deps_in=5,
            deps_out=10,
            loc_weight=0.3,
            cyclomatic_weight=0.4,
            deps_weight=0.3,
            language_factor=1.0
        )
        
        # Score should be positive
        assert score > 0
        
        # Score should be influenced by all factors
        # With these values: (1000/100 * 0.3) + (20 * 0.4) + (15 * 0.3) = 3 + 8 + 4.5 = 15.5
        assert abs(score - 15.5) < 0.1
    
    def test_tier_classification(self):
        """Test complexity tier classification."""
        # Test LOW tier
        assert ComplexityMetrics.determine_tier(5.0) == 'LOW'
        
        # Test MEDIUM tier
        assert ComplexityMetrics.determine_tier(15.0) == 'MEDIUM'
        
        # Test HIGH tier
        assert ComplexityMetrics.determine_tier(35.0) == 'HIGH'
        
        # Test VERY_HIGH tier
        assert ComplexityMetrics.determine_tier(75.0) == 'VERY_HIGH'
    
    def test_god_program_detection_by_loc(self):
        """Test god program detection based on LOC."""
        is_god = ComplexityMetrics.is_god_program_check(
            loc=6000,  # Exceeds default threshold of 5000
            cyclomatic=50,
            deps_total=30
        )
        
        assert is_god is True
    
    def test_god_program_detection_by_cyclomatic(self):
        """Test god program detection based on cyclomatic complexity."""
        is_god = ComplexityMetrics.is_god_program_check(
            loc=2000,
            cyclomatic=150,  # Exceeds default threshold of 100
            deps_total=30
        )
        
        assert is_god is True
    
    def test_god_program_detection_by_dependencies(self):
        """Test god program detection based on dependencies."""
        is_god = ComplexityMetrics.is_god_program_check(
            loc=2000,
            cyclomatic=50,
            deps_total=60  # Exceeds default threshold of 50
        )
        
        assert is_god is True
    
    def test_not_god_program(self):
        """Test that normal programs are not flagged as god programs."""
        is_god = ComplexityMetrics.is_god_program_check(
            loc=1000,
            cyclomatic=20,
            deps_total=15
        )
        
        assert is_god is False
    
    def test_language_specific_factors(self):
        """Test language-specific complexity factors."""
        thresholds = ComplexityThresholds()
        
        # COBOL should have factor 1.0
        assert thresholds.get_language_factor('COBOL') == 1.0
        
        # JCL should have lower factor (0.8)
        assert thresholds.get_language_factor('JCL') == 0.8
        
        # Assembler should have higher factor (1.5)
        assert thresholds.get_language_factor('ASSEMBLER') == 1.5
    
    def test_analyze_all_programs(self):
        """Test batch analysis of multiple programs."""
        programs = {
            'PROG1': {
                'source_code': 'PROGRAM-ID. PROG1.\nPROCEDURE DIVISION.\n    DISPLAY "TEST".\n    STOP RUN.',
                'language': 'COBOL',
                'dependency_count_in': 1,
                'dependency_count_out': 2
            },
            'PROG2': {
                'source_code': 'PROGRAM-ID. PROG2.\nPROCEDURE DIVISION.\n    IF A > B\n        DISPLAY "A".\n    STOP RUN.',
                'language': 'COBOL',
                'dependency_count_in': 3,
                'dependency_count_out': 1
            }
        }
        
        results = self.analyzer.analyze_all_programs(programs)
        
        assert len(results) == 2
        assert 'PROG1' in results
        assert 'PROG2' in results
        assert results['PROG1'].program_name == 'PROG1'
        assert results['PROG2'].program_name == 'PROG2'
        # PROG2 should have higher complexity due to IF statement
        assert results['PROG2'].cyclomatic_complexity > results['PROG1'].cyclomatic_complexity
    
    def test_pli_comment_detection(self):
        """Test comment detection in PL/I code."""
        source_code = """
        /* This is a comment */
        TEST: PROC OPTIONS(MAIN);
            /* Another comment */
            PUT SKIP LIST('HELLO');
        END TEST;
        """
        
        result = self.analyzer.calculate_loc(source_code, 'PLI')
        
        # Should detect comments
        assert result['comment_lines'] >= 2
    
    def test_jcl_comment_detection(self):
        """Test comment detection in JCL."""
        source_code = """
        //* This is a comment
        //TESTJOB JOB
        //* Another comment
        //STEP1 EXEC PGM=PROG1
        """
        
        result = self.analyzer.calculate_loc(source_code, 'JCL')
        
        # Should detect comments
        assert result['comment_lines'] >= 2
    
    def test_maintainability_index(self):
        """Test maintainability index calculation."""
        metrics = ComplexityMetrics(
            program_name='TEST',
            language='COBOL',
            lines_of_code=100,
            cyclomatic_complexity=10,
            dependency_count_in=5,
            dependency_count_out=5,
            composite_score=10.0,
            complexity_tier='MEDIUM'
        )
        
        mi = metrics.get_maintainability_index()
        
        # Maintainability index should be between 0 and 100
        assert 0 <= mi <= 100
    
    def test_custom_thresholds(self):
        """Test analyzer with custom thresholds."""
        custom_thresholds = ComplexityThresholds(
            low_threshold=5.0,
            medium_threshold=15.0,
            high_threshold=30.0,
            loc_weight=0.4,
            cyclomatic_weight=0.3,
            deps_weight=0.3
        )
        
        analyzer = ComplexityAnalyzer(thresholds=custom_thresholds)
        
        source_code = "PROGRAM-ID. TEST.\nPROCEDURE DIVISION.\n    DISPLAY 'TEST'.\n    STOP RUN."
        
        metrics = analyzer.analyze_program(
            program_name='TEST',
            source_code=source_code,
            language='COBOL',
            dependency_count_in=0,
            dependency_count_out=0
        )
        
        # Should use custom thresholds
        assert metrics.composite_score >= 0
    
    def test_cobol_fixed_format_comment_column_7(self):
        """Test COBOL fixed format comment detection in column 7."""
        # In fixed format COBOL, column 7 (index 6) can have * or / for comments
        source_code = """      * This is a comment in column 7
        PROGRAM-ID. TEST.
      / Another comment type
        PROCEDURE DIVISION.
            DISPLAY 'HELLO'.
        """
        
        result = self.analyzer.calculate_loc(source_code, 'COBOL')
        
        # Should detect comments in column 7
        assert result['comment_lines'] >= 2
    
    def test_empty_source_code(self):
        """Test handling of empty source code."""
        result = self.analyzer.calculate_loc('', 'COBOL')
        
        assert result['loc'] == 0
        assert result['total_lines'] == 1  # Empty string splits to one empty line
        assert result['blank_lines'] == 1
    
    def test_metrics_string_representation(self):
        """Test string representation of ComplexityMetrics."""
        metrics = ComplexityMetrics(
            program_name='TEST',
            language='COBOL',
            lines_of_code=100,
            cyclomatic_complexity=10,
            dependency_count_in=5,
            dependency_count_out=5,
            composite_score=10.5,
            complexity_tier='MEDIUM'
        )
        
        str_repr = str(metrics)
        
        assert 'TEST' in str_repr
        assert 'COBOL' in str_repr
        assert '100' in str_repr
        assert '10' in str_repr
        assert 'MEDIUM' in str_repr


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
