"""Unit tests for metadata reconciliation."""

import unittest
import sqlite3
import tempfile
import os
from tools.legacy_analyzer.metadata.reconciliation import (
    MetadataReconciler,
    ReconciliationReport,
    ReconciliationIssue
)


class TestReconciliationIssue(unittest.TestCase):
    """Test cases for ReconciliationIssue class."""
    
    def test_to_dict_basic(self):
        """Test converting issue to dictionary with basic fields."""
        issue = ReconciliationIssue(
            issue_type='missing_in_code',
            program_name='TESTPROG',
            severity='ERROR',
            issue='Test issue',
            recommendation='Test recommendation'
        )
        
        result = issue.to_dict()
        
        self.assertEqual(result['issue_type'], 'missing_in_code')
        self.assertEqual(result['program'], 'TESTPROG')
        self.assertEqual(result['severity'], 'ERROR')
        self.assertEqual(result['issue'], 'Test issue')
        self.assertEqual(result['recommendation'], 'Test recommendation')
        self.assertNotIn('transaction_id', result)
        self.assertNotIn('cics_group', result)
    
    def test_to_dict_with_optional_fields(self):
        """Test converting issue to dictionary with optional fields."""
        issue = ReconciliationIssue(
            issue_type='status_mismatch',
            program_name='TESTPROG',
            severity='WARNING',
            issue='Test issue',
            recommendation='Test recommendation',
            transaction_id='TEST',
            cics_group='TESTGRP',
            csd_status='DISABLED',
            code_status='ACTIVE'
        )
        
        result = issue.to_dict()
        
        self.assertEqual(result['transaction_id'], 'TEST')
        self.assertEqual(result['cics_group'], 'TESTGRP')
        self.assertEqual(result['csd_status'], 'DISABLED')
        self.assertEqual(result['code_status'], 'ACTIVE')


class TestReconciliationReport(unittest.TestCase):
    """Test cases for ReconciliationReport class."""
    
    def test_empty_report(self):
        """Test empty reconciliation report."""
        report = ReconciliationReport()
        
        self.assertEqual(len(report.get_all_issues()), 0)
        
        summary = report.get_summary()
        self.assertEqual(summary['total_issues'], 0)
        self.assertEqual(summary['missing_in_code'], 0)
        self.assertEqual(summary['missing_in_csd'], 0)
        self.assertEqual(summary['status_mismatches'], 0)
    
    def test_report_with_issues(self):
        """Test report with various issues."""
        issue1 = ReconciliationIssue(
            issue_type='missing_in_code',
            program_name='PROG1',
            severity='ERROR',
            issue='Issue 1',
            recommendation='Rec 1'
        )
        
        issue2 = ReconciliationIssue(
            issue_type='missing_in_csd',
            program_name='PROG2',
            severity='INFO',
            issue='Issue 2',
            recommendation='Rec 2'
        )
        
        issue3 = ReconciliationIssue(
            issue_type='status_mismatch',
            program_name='PROG3',
            severity='WARNING',
            issue='Issue 3',
            recommendation='Rec 3'
        )
        
        report = ReconciliationReport(
            programs_in_csd_not_in_code=[issue1],
            programs_in_code_not_in_csd=[issue2],
            status_mismatches=[issue3]
        )
        
        # Test get_all_issues
        all_issues = report.get_all_issues()
        self.assertEqual(len(all_issues), 3)
        
        # Test summary
        summary = report.get_summary()
        self.assertEqual(summary['total_issues'], 3)
        self.assertEqual(summary['missing_in_code'], 1)
        self.assertEqual(summary['missing_in_csd'], 1)
        self.assertEqual(summary['status_mismatches'], 1)
        self.assertEqual(summary['by_severity']['ERROR'], 1)
        self.assertEqual(summary['by_severity']['WARNING'], 1)
        self.assertEqual(summary['by_severity']['INFO'], 1)
    
    def test_to_dict(self):
        """Test converting report to dictionary."""
        issue = ReconciliationIssue(
            issue_type='missing_in_code',
            program_name='PROG1',
            severity='ERROR',
            issue='Issue 1',
            recommendation='Rec 1'
        )
        
        report = ReconciliationReport(
            programs_in_csd_not_in_code=[issue]
        )
        
        result = report.to_dict()
        
        self.assertIn('reconciliation', result)
        self.assertIn('summary', result)
        self.assertIn('programs_in_csd_not_in_code', result['reconciliation'])
        self.assertEqual(len(result['reconciliation']['programs_in_csd_not_in_code']), 1)


class TestMetadataReconciler(unittest.TestCase):
    """Test cases for MetadataReconciler class."""
    
    def setUp(self):
        """Set up test database."""
        # Create temporary database
        self.db_fd, self.db_path = tempfile.mkstemp()
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create test tables
        self._create_test_tables()
        
        # Create reconciler
        self.reconciler = MetadataReconciler(self.conn)
    
    def tearDown(self):
        """Clean up test database."""
        self.conn.close()
        os.close(self.db_fd)
        os.unlink(self.db_path)
    
    def _create_test_tables(self):
        """Create test database tables."""
        # Create inventory_cics table
        self.cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20)
            )
        """)
        
        # Create inventory table
        self.cursor.execute("""
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                artifact_name VARCHAR(44) NOT NULL,
                artifact_type VARCHAR(20) NOT NULL,
                file_path VARCHAR(255)
            )
        """)
        
        self.conn.commit()
    
    def test_check_tables_exist(self):
        """Test that reconciler correctly identifies existing tables."""
        self.assertTrue(self.reconciler._has_cics_table)
        self.assertTrue(self.reconciler._has_inventory_table)
    
    def test_get_cics_programs_from_transactions(self):
        """Test getting programs from CICS transactions."""
        # Add test data
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('CAUP', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTUPC', 'Account Update'),
            ('CMEN', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COMENUC', 'Main Menu'),
            ('COLD', 'TRANSACTION', 'CARDDEMO', 'DISABLED', 'COLDPROG', 'Old Transaction')
        """)
        self.conn.commit()
        
        programs = self.reconciler.get_cics_programs()
        
        # Should find 3 programs
        self.assertEqual(len(programs), 3)
        self.assertIn('COACTUPC', programs)
        self.assertIn('COMENUC', programs)
        self.assertIn('COLDPROG', programs)
        
        # Check metadata
        self.assertEqual(programs['COACTUPC']['transaction_id'], 'CAUP')
        self.assertEqual(programs['COACTUPC']['cics_group'], 'CARDDEMO')
        self.assertEqual(programs['COACTUPC']['status'], 'ENABLED')
        self.assertEqual(programs['COLDPROG']['status'], 'DISABLED')
    
    def test_get_cics_programs_from_program_resources(self):
        """Test getting programs from PROGRAM resources."""
        # Add test data
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, description)
            VALUES 
            ('TESTPROG', 'PROGRAM', 'TESTGRP', 'ENABLED', 'Test Program')
        """)
        self.conn.commit()
        
        programs = self.reconciler.get_cics_programs()
        
        # Should find 1 program
        self.assertEqual(len(programs), 1)
        self.assertIn('TESTPROG', programs)
        
        # Check metadata (no transaction_id for PROGRAM resources)
        self.assertIsNone(programs['TESTPROG']['transaction_id'])
        self.assertEqual(programs['TESTPROG']['cics_group'], 'TESTGRP')
    
    def test_get_cics_programs_mixed_sources(self):
        """Test getting programs from both TRANSACTION and PROGRAM resources."""
        # Add test data
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('CAUP', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTUPC', 'Account Update')
        """)
        
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, description)
            VALUES 
            ('TESTPROG', 'PROGRAM', 'TESTGRP', 'ENABLED', 'Test Program')
        """)
        self.conn.commit()
        
        programs = self.reconciler.get_cics_programs()
        
        # Should find 2 programs
        self.assertEqual(len(programs), 2)
        self.assertIn('COACTUPC', programs)
        self.assertIn('TESTPROG', programs)
    
    def test_get_code_programs(self):
        """Test getting programs from source code inventory."""
        # Add test data
        self.cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path)
            VALUES 
            ('COACTUPC', 'PROGRAM', '/path/to/COACTUPC.cbl'),
            ('COMENUC', 'PROGRAM', '/path/to/COMENUC.cbl'),
            ('UTILPROG', 'PROGRAM', '/path/to/UTILPROG.cbl')
        """)
        self.conn.commit()
        
        programs = self.reconciler.get_code_programs()
        
        # Should find 3 programs
        self.assertEqual(len(programs), 3)
        self.assertIn('COACTUPC', programs)
        self.assertIn('COMENUC', programs)
        self.assertIn('UTILPROG', programs)
    
    def test_detect_programs_in_csd_not_in_code(self):
        """Test detecting programs in CSD but not in code."""
        cics_programs = {
            'COACTUPC': {
                'transaction_id': 'CAUP',
                'cics_group': 'CARDDEMO',
                'status': 'ENABLED',
                'description': 'Account Update'
            },
            'OLDPROG': {
                'transaction_id': 'OLD1',
                'cics_group': 'CARDDEMO',
                'status': 'DISABLED',
                'description': 'Old Program'
            }
        }
        
        code_programs = {'COACTUPC', 'UTILPROG'}
        
        issues = self.reconciler.detect_programs_in_csd_not_in_code(
            cics_programs,
            code_programs
        )
        
        # Should find 1 issue (OLDPROG)
        self.assertEqual(len(issues), 1)
        
        issue = issues[0]
        self.assertEqual(issue.issue_type, 'missing_in_code')
        self.assertEqual(issue.program_name, 'OLDPROG')
        self.assertEqual(issue.severity, 'WARNING')  # DISABLED programs are WARNING
        self.assertEqual(issue.transaction_id, 'OLD1')
        self.assertEqual(issue.csd_status, 'DISABLED')
    
    def test_detect_programs_in_csd_not_in_code_enabled(self):
        """Test detecting ENABLED programs in CSD but not in code (ERROR severity)."""
        cics_programs = {
            'MISSING': {
                'transaction_id': 'MISS',
                'cics_group': 'TESTGRP',
                'status': 'ENABLED',
                'description': 'Missing Program'
            }
        }
        
        code_programs = set()
        
        issues = self.reconciler.detect_programs_in_csd_not_in_code(
            cics_programs,
            code_programs
        )
        
        # Should find 1 issue with ERROR severity
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0].severity, 'ERROR')
    
    def test_detect_programs_in_code_not_in_csd(self):
        """Test detecting programs in code but not in CSD."""
        cics_programs = {
            'COACTUPC': {
                'transaction_id': 'CAUP',
                'cics_group': 'CARDDEMO',
                'status': 'ENABLED',
                'description': 'Account Update'
            }
        }
        
        code_programs = {'COACTUPC', 'UTILPROG', 'SUBPROG'}
        
        issues = self.reconciler.detect_programs_in_code_not_in_csd(
            cics_programs,
            code_programs
        )
        
        # Should find 2 issues (UTILPROG, SUBPROG)
        self.assertEqual(len(issues), 2)
        
        program_names = {issue.program_name for issue in issues}
        self.assertEqual(program_names, {'UTILPROG', 'SUBPROG'})
        
        # All should be INFO severity
        for issue in issues:
            self.assertEqual(issue.issue_type, 'missing_in_csd')
            self.assertEqual(issue.severity, 'INFO')
            self.assertEqual(issue.code_status, 'ACTIVE')
    
    def test_detect_status_mismatches(self):
        """Test detecting status mismatches between CSD and code."""
        cics_programs = {
            'COACTUPC': {
                'transaction_id': 'CAUP',
                'cics_group': 'CARDDEMO',
                'status': 'ENABLED',
                'description': 'Account Update'
            },
            'OLDPROG': {
                'transaction_id': 'OLD1',
                'cics_group': 'CARDDEMO',
                'status': 'DISABLED',
                'description': 'Old Program'
            },
            'MISSING': {
                'transaction_id': 'MISS',
                'cics_group': 'TESTGRP',
                'status': 'DISABLED',
                'description': 'Missing Program'
            }
        }
        
        code_programs = {'COACTUPC', 'OLDPROG'}  # MISSING is not in code
        
        issues = self.reconciler.detect_status_mismatches(
            cics_programs,
            code_programs
        )
        
        # Should find 1 issue (OLDPROG is DISABLED but in code)
        self.assertEqual(len(issues), 1)
        
        issue = issues[0]
        self.assertEqual(issue.issue_type, 'status_mismatch')
        self.assertEqual(issue.program_name, 'OLDPROG')
        self.assertEqual(issue.severity, 'WARNING')
        self.assertEqual(issue.csd_status, 'DISABLED')
        self.assertEqual(issue.code_status, 'ACTIVE')
    
    def test_reconcile_complete(self):
        """Test complete reconciliation process."""
        # Add CICS metadata
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('CAUP', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTUPC', 'Account Update'),
            ('COLD', 'TRANSACTION', 'CARDDEMO', 'DISABLED', 'OLDPROG', 'Old Transaction'),
            ('MISS', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'MISSING', 'Missing Program')
        """)
        
        # Add code inventory
        self.cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path)
            VALUES 
            ('COACTUPC', 'PROGRAM', '/path/to/COACTUPC.cbl'),
            ('OLDPROG', 'PROGRAM', '/path/to/OLDPROG.cbl'),
            ('UTILPROG', 'PROGRAM', '/path/to/UTILPROG.cbl')
        """)
        self.conn.commit()
        
        # Run reconciliation
        report = self.reconciler.reconcile()
        
        # Check results
        # 1. MISSING is in CSD but not in code (ERROR)
        self.assertEqual(len(report.programs_in_csd_not_in_code), 1)
        self.assertEqual(report.programs_in_csd_not_in_code[0].program_name, 'MISSING')
        
        # 2. UTILPROG is in code but not in CSD (INFO)
        self.assertEqual(len(report.programs_in_code_not_in_csd), 1)
        self.assertEqual(report.programs_in_code_not_in_csd[0].program_name, 'UTILPROG')
        
        # 3. OLDPROG is DISABLED in CSD but in code (WARNING)
        self.assertEqual(len(report.status_mismatches), 1)
        self.assertEqual(report.status_mismatches[0].program_name, 'OLDPROG')
        
        # Check summary
        summary = report.get_summary()
        self.assertEqual(summary['total_issues'], 3)
        self.assertEqual(summary['missing_in_code'], 1)
        self.assertEqual(summary['missing_in_csd'], 1)
        self.assertEqual(summary['status_mismatches'], 1)
    
    def test_reconcile_no_issues(self):
        """Test reconciliation with no issues."""
        # Add matching data
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('CAUP', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTUPC', 'Account Update')
        """)
        
        self.cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path)
            VALUES 
            ('COACTUPC', 'PROGRAM', '/path/to/COACTUPC.cbl')
        """)
        self.conn.commit()
        
        # Run reconciliation
        report = self.reconciler.reconcile()
        
        # Should have no issues
        self.assertEqual(len(report.get_all_issues()), 0)
        
        summary = report.get_summary()
        self.assertEqual(summary['total_issues'], 0)
    
    def test_reconcile_missing_cics_table(self):
        """Test reconciliation when CICS table doesn't exist."""
        # Create new database without CICS table
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        
        try:
            reconciler = MetadataReconciler(conn)
            
            # Should not have CICS table
            self.assertFalse(reconciler._has_cics_table)
            
            # Should return empty report
            report = reconciler.reconcile()
            self.assertEqual(len(report.get_all_issues()), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)
    
    def test_reconcile_missing_inventory_table(self):
        """Test reconciliation when inventory table doesn't exist."""
        # Create new database without inventory table
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create only CICS table
        cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8)
            )
        """)
        conn.commit()
        
        try:
            reconciler = MetadataReconciler(conn)
            
            # Should have CICS table but not inventory table
            self.assertTrue(reconciler._has_cics_table)
            self.assertFalse(reconciler._has_inventory_table)
            
            # Should return empty report
            report = reconciler.reconcile()
            self.assertEqual(len(report.get_all_issues()), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)
    
    def test_get_cics_programs_empty_program_name(self):
        """Test that empty program names are skipped."""
        # Add transaction with empty program_name
        self.cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name)
            VALUES 
            ('TEST', 'TRANSACTION', 'TESTGRP', 'ENABLED', ''),
            ('TEST2', 'TRANSACTION', 'TESTGRP', 'ENABLED', NULL)
        """)
        self.conn.commit()
        
        programs = self.reconciler.get_cics_programs()
        
        # Should find 0 programs (empty/null program names are skipped)
        self.assertEqual(len(programs), 0)


if __name__ == '__main__':
    unittest.main()
