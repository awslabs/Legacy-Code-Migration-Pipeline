"""
Unit tests for interface identification in migration flow builder.

Tests cover:
- Inbound interface identification (external programs calling into flow)
- Outbound interface identification (flow programs calling external)
- External program configuration support
- External caller configuration support
- Entry point invocation exclusion from inbound interfaces
- JCL outbound interface identification
- Interface metadata extraction
"""

import pytest
import sqlite3
from unittest.mock import Mock, MagicMock
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder


class MockDependency:
    """Mock dependency object for testing."""
    
    def __init__(self, source, target, dep_type, source_type='PROGRAM', 
                 target_type='PROGRAM', file_path=None, line_number=None):
        self.source_artifact = source
        self.target_artifact = target
        self.dependency_type = dep_type
        self.source_type = source_type
        self.target_type = target_type
        self.source_file_path = file_path
        self.line_number = line_number


class MockFlow:
    """Mock ProgramFlow object for testing."""
    
    def __init__(self, programs, dependencies=None):
        self.programs = programs
        self.dependencies = dependencies or []


@pytest.fixture
def test_db():
    """Create an in-memory test database."""
    conn = sqlite3.connect(':memory:')
    
    # Use MigrationFlowSchema to create required tables
    from tools.legacy_analyzer.migration.schema import MigrationFlowSchema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create artifact_dependencies table (part of main schema, not migration schema)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            id INTEGER PRIMARY KEY,
            source_artifact_name TEXT,
            target_artifact_name TEXT,
            dependency_type TEXT,
            source_artifact_type TEXT,
            target_artifact_type TEXT,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    conn.commit()
    return conn


@pytest.fixture
def flow_builder(test_db):
    """Create a MigrationFlowBuilder instance."""
    return MigrationFlowBuilder(test_db)


def insert_dependency(conn, source, target, dep_type, 
                     source_type='PROGRAM', target_type='PROGRAM',
                     file_path=None, line_number=None):
    """Helper to insert a dependency into the test database."""
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO artifact_dependencies 
        (source_artifact_name, target_artifact_name, dependency_type,
         source_artifact_type, target_artifact_type, source_file_path, line_number)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (source, target, dep_type, source_type, target_type, file_path, line_number))
    conn.commit()


# Test 1: No inbound interfaces for entry point invocations
def test_no_inbound_interface_for_entry_point(flow_builder, test_db):
    """Entry point invocations are NOT inbound interfaces."""
    # Setup: External program calling the entry point
    insert_dependency(test_db, 'EXTERNAL_PROG', 'PAYROLL1', 'PROGRAM_CALL')
    
    # Create flow with PAYROLL1 as entry point
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Entry point invocations should NOT be in inbound interfaces
    assert len(interfaces['inbound']) == 0, \
        "Entry point invocations should not create inbound interfaces"


# Test 2: Inbound interface for non-entry program call
def test_inbound_interface_for_non_entry_call(flow_builder, test_db):
    """External program calling non-entry program IS an inbound interface."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Load EXTERNAL_PROG into inbound_interfaces table
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYCALC', 'PROGRAM_CALL', True))
    test_db.commit()
    
    # Ensure EXTERNAL_PROG is NOT in artifact_dependencies (not in codebase)
    # (No need to insert - it's already not there)
    
    # Create flow with PAYROLL1 as entry point
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one inbound interface
    assert len(interfaces['inbound']) == 1
    assert interfaces['inbound'][0]['source'] == 'EXTERNAL_PROG'
    assert interfaces['inbound'][0]['target'] == 'PAYCALC'
    assert interfaces['inbound'][0]['type'] == 'PROGRAM_CALL'


# Test 3: No inbound interface for internal calls
def test_no_inbound_interface_for_internal_call(flow_builder, test_db):
    """Internal calls within the flow are NOT inbound interfaces."""
    # Setup: Program in flow calling another program in flow
    insert_dependency(test_db, 'PAYROLL1', 'PAYCALC', 'PROGRAM_CALL')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have no inbound interfaces (internal call)
    assert len(interfaces['inbound']) == 0


# Test 4: Outbound interface for external program call
def test_outbound_interface_for_external_call(flow_builder, test_db):
    """Flow program calling external program IS an outbound interface."""
    # Setup: Program in flow calling external program
    insert_dependency(test_db, 'PAYCALC', 'DBUTIL', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    
    # Create flow (DBUTIL is not in the flow)
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one outbound interface
    assert len(interfaces['outbound']) == 1
    assert interfaces['outbound'][0]['source'] == 'PAYCALC'
    assert interfaces['outbound'][0]['target'] == 'DBUTIL'
    assert interfaces['outbound'][0]['type'] == 'PROGRAM_CALL'
    assert interfaces['outbound'][0]['external'] is True


# Test 5: Outbound interface with external program configuration
def test_outbound_interface_with_external_config(flow_builder, test_db):
    """Program in external config is marked as outbound interface."""
    # Setup: Create outbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Mark UTIL_COMMON as external in database
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO outbound_interfaces (program_name, reason)
        VALUES (?, ?)
    """, ('UTIL_COMMON', 'configured'))
    test_db.commit()
    
    # Setup: Program in flow calling a program that's in external config
    insert_dependency(test_db, 'PAYCALC', 'UTIL_COMMON', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    
    # Create flow (UTIL_COMMON is in the flow but marked as external)
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC', 'UTIL_COMMON'])
    
    # Identify interfaces (no external_programs parameter needed)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one outbound interface (UTIL_COMMON is external)
    assert len(interfaces['outbound']) == 1
    assert interfaces['outbound'][0]['target'] == 'UTIL_COMMON'
    assert interfaces['outbound'][0]['external'] is True


# Test 6: Inbound interface from configured external caller
def test_inbound_interface_from_external_caller_config(flow_builder, test_db):
    """Configured external caller creates inbound interface."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Load external caller into database
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured, metadata)
        VALUES (?, ?, ?, ?, ?)
    """, ('EXTERNAL_SYSTEM_A', 'PAYCALC', 'PROGRAM_CALL', True, 
          '{"system": "Legacy Batch System", "description": "Legacy batch system"}'))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces (no external_callers parameter needed)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one inbound interface from external caller
    assert len(interfaces['inbound']) == 1
    assert interfaces['inbound'][0]['source'] == 'EXTERNAL_SYSTEM_A'
    assert interfaces['inbound'][0]['target'] == 'PAYCALC'
    assert interfaces['inbound'][0]['external'] is True
    assert 'system' in interfaces['inbound'][0]['metadata']


# Test 7: External caller to entry point DOES create inbound interface (NEW BEHAVIOR)
def test_external_caller_to_entry_point_creates_inbound(flow_builder, test_db):
    """External caller to entry point DOES create inbound interface (new behavior)."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure external caller to entry point in database
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_SYSTEM_A', 'PAYROLL1', 'PROGRAM_CALL', True))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces (no external_callers parameter needed)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # NEW BEHAVIOR: Should have one inbound interface (configured external callers
    # create inbound interfaces regardless of whether target is entry point)
    assert len(interfaces['inbound']) == 1
    assert interfaces['inbound'][0]['source'] == 'EXTERNAL_SYSTEM_A'
    assert interfaces['inbound'][0]['target'] == 'PAYROLL1'


# Test 8: JCL outbound interface
def test_jcl_outbound_interface(flow_builder, test_db):
    """Flow program submitting external JCL creates outbound interface."""
    # Setup: Program in flow submitting JCL
    insert_dependency(test_db, 'PAYCALC', 'EXTERNAL_JOB', 'JCL_SUBMIT',
                     target_type='JCL')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one JCL outbound interface
    assert len(interfaces['outbound']) == 1
    assert interfaces['outbound'][0]['type'] == 'JCL'
    assert interfaces['outbound'][0]['source'] == 'PAYCALC'
    assert interfaces['outbound'][0]['target'] == 'EXTERNAL_JOB'
    assert interfaces['outbound'][0]['external'] is True
    assert 'jclName' in interfaces['outbound'][0]['metadata']


# Test 9: Multiple interface types
def test_multiple_interface_types(flow_builder, test_db):
    """Flow can have multiple inbound and outbound interfaces."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure external callers in database
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL1', 'PAYCALC', 'PROGRAM_CALL', True))
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL2', 'PAYDB', 'CICS_LINK', True))
    test_db.commit()
    
    # Setup multiple outbound dependencies
    insert_dependency(test_db, 'PAYCALC', 'DBUTIL', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    insert_dependency(test_db, 'PAYDB', 'EXTERNAL_JOB', 'JCL_SUBMIT',
                     target_type='JCL')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC', 'PAYDB'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have 2 inbound and 2 outbound interfaces
    assert len(interfaces['inbound']) == 2
    assert len(interfaces['outbound']) == 2


# Test 10: Interface metadata extraction
def test_interface_metadata_extraction(flow_builder, test_db):
    """Interface metadata is correctly extracted."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure external caller with metadata in database
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured, metadata)
        VALUES (?, ?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYCALC', 'PROGRAM_CALL', True, 
          '{"filePath": "/path/to/external.cbl", "lineNumber": 42}'))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Check metadata
    assert len(interfaces['inbound']) == 1
    metadata = interfaces['inbound'][0]['metadata']
    assert metadata['callingProgram'] == 'EXTERNAL_PROG'
    assert metadata['filePath'] == '/path/to/external.cbl'
    assert metadata['lineNumber'] == 42


# Test 11: CICS interface types
def test_cics_interface_types(flow_builder, test_db):
    """CICS LINK, XCTL, START are recognized as interface types."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure external caller with CICS_LINK
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL1', 'PAYCALC', 'CICS_LINK', True))
    test_db.commit()
    
    # Setup: Various CICS call types for outbound
    insert_dependency(test_db, 'PAYCALC', 'EXTERNAL2', 'CICS_XCTL',
                     target_type='PROGRAM')
    insert_dependency(test_db, 'PAYCALC', 'EXTERNAL3', 'CICS_START',
                     target_type='PROGRAM')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Check interface types
    assert len(interfaces['inbound']) == 1
    assert interfaces['inbound'][0]['type'] == 'CICS_LINK'
    
    assert len(interfaces['outbound']) == 2
    outbound_types = {i['type'] for i in interfaces['outbound']}
    assert 'CICS_XCTL' in outbound_types
    assert 'CICS_START' in outbound_types


# Test 12: Empty flow has no interfaces
def test_empty_flow_no_interfaces(flow_builder, test_db):
    """Flow with no external interactions has no interfaces."""
    # Create flow with no external dependencies
    flow = MockFlow(programs=['PAYROLL1'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have no interfaces
    assert len(interfaces['inbound']) == 0
    assert len(interfaces['outbound']) == 0


# Test 13: External caller with multiple targets
def test_external_caller_multiple_targets(flow_builder, test_db):
    """External caller can call multiple programs in the flow."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure external caller with multiple targets in database
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_SYSTEM_A', 'PAYCALC', 'PROGRAM_CALL', True))
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_SYSTEM_A', 'PAYDB', 'CICS_LINK', True))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC', 'PAYDB'])
    
    # Identify interfaces (no external_callers parameter needed)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have two inbound interfaces from same caller
    assert len(interfaces['inbound']) == 2
    assert all(i['source'] == 'EXTERNAL_SYSTEM_A' for i in interfaces['inbound'])
    targets = {i['target'] for i in interfaces['inbound']}
    assert targets == {'PAYCALC', 'PAYDB'}


# Test 14: Combined database and configured interfaces
def test_combined_database_and_configured_interfaces(flow_builder, test_db):
    """Interfaces from both database queries are included."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure two external callers in database
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('DB_EXTERNAL', 'PAYCALC', 'PROGRAM_CALL', True))
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('CONFIG_EXTERNAL', 'PAYCALC', 'EXTERNAL_CALL', True))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces (no external_callers parameter needed)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have two inbound interfaces (both from database)
    assert len(interfaces['inbound']) == 2
    sources = {i['source'] for i in interfaces['inbound']}
    assert sources == {'DB_EXTERNAL', 'CONFIG_EXTERNAL'}


# Test 15: Interface deduplication
def test_interface_deduplication(flow_builder, test_db):
    """Multiple interfaces from same source are handled correctly."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure external caller calling TWO DIFFERENT targets
    # (Can't have duplicates due to UNIQUE constraint on source_name, target_program, dependency_type)
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured, metadata)
        VALUES (?, ?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYCALC', 'PROGRAM_CALL', True, '{"lineNumber": 10}'))
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured, metadata)
        VALUES (?, ?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYDB', 'PROGRAM_CALL', True, '{"lineNumber": 20}'))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC', 'PAYDB'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have two interfaces (different targets)
    assert len(interfaces['inbound']) == 2
    assert all(i['source'] == 'EXTERNAL_PROG' for i in interfaces['inbound'])
    targets = {i['target'] for i in interfaces['inbound']}
    assert targets == {'PAYCALC', 'PAYDB'}


if __name__ == '__main__':
    pytest.main([__file__, '-v'])


# ============================================================================
# Tests for Enhanced Outbound Interface Identification (Task 8.2)
# ============================================================================

# Test 16: Outbound interface from database query
def test_outbound_interface_from_database(flow_builder, test_db):
    """Programs from outbound_interfaces table create outbound interfaces."""
    # Setup: Create outbound_interfaces table and insert data
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO outbound_interfaces (program_name, reason, metadata)
        VALUES (?, ?, ?)
    """, ('EXTERNAL_UTIL', 'configured', '{"description": "External utility"}'))
    test_db.commit()
    
    # Setup: Program in flow calling external program
    insert_dependency(test_db, 'PAYCALC', 'EXTERNAL_UTIL', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces (no external_programs parameter)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one outbound interface from database
    assert len(interfaces['outbound']) == 1
    assert interfaces['outbound'][0]['source'] == 'PAYCALC'
    assert interfaces['outbound'][0]['target'] == 'EXTERNAL_UTIL'
    assert interfaces['outbound'][0]['external'] is True


# Test 17: Outbound interface includes reason metadata
def test_outbound_interface_includes_reason_metadata(flow_builder, test_db):
    """Reason metadata from database is included in outbound interface."""
    # Setup: Create outbound_interfaces table and insert data with reason
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO outbound_interfaces (program_name, reason, metadata)
        VALUES (?, ?, ?)
    """, ('EXTERNAL_UTIL', 'configured', '{"description": "External utility"}'))
    test_db.commit()
    
    # Setup: Program in flow calling external program
    insert_dependency(test_db, 'PAYCALC', 'EXTERNAL_UTIL', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Check reason metadata is included
    assert len(interfaces['outbound']) == 1
    metadata = interfaces['outbound'][0]['metadata']
    assert 'reason' in metadata
    assert metadata['reason'] == 'configured'
    assert 'description' in metadata
    assert metadata['description'] == 'External utility'


# Test 18: Auto-detected programs are included in outbound interfaces
def test_auto_detected_programs_in_outbound_interfaces(flow_builder, test_db):
    """Auto-detected programs (missing source code) are included in outbound interfaces."""
    # Setup: Create outbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Create program_file_mapping table (for source code check)
    cursor = test_db.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            language TEXT
        )
    """)
    
    # Insert mapping for programs IN the flow (have source code)
    cursor.execute("""
        INSERT INTO program_file_mapping (program_name, file_path, language)
        VALUES (?, ?, ?)
    """, ('PAYCALC', '/path/to/paycalc.cbl', 'COBOL'))
    test_db.commit()
    
    # Setup: Program in flow calling program WITHOUT source code
    insert_dependency(test_db, 'PAYCALC', 'MISSING_SOURCE', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces (this should auto-detect MISSING_SOURCE)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one outbound interface
    assert len(interfaces['outbound']) == 1
    assert interfaces['outbound'][0]['target'] == 'MISSING_SOURCE'
    
    # Verify MISSING_SOURCE was inserted into outbound_interfaces table
    cursor.execute("""
        SELECT program_name, reason
        FROM outbound_interfaces
        WHERE program_name = ?
    """, ('MISSING_SOURCE',))
    row = cursor.fetchone()
    assert row is not None
    assert row[0] == 'MISSING_SOURCE'
    assert row[1] == 'missing_source_code'


# Test 19: Multiple outbound interfaces with mixed sources
def test_multiple_outbound_interfaces_mixed_sources(flow_builder, test_db):
    """Outbound interfaces from both database and auto-detection work together."""
    # Setup: Create tables
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    cursor = test_db.cursor()
    
    # Insert configured external program
    cursor.execute("""
        INSERT INTO outbound_interfaces (program_name, reason, metadata)
        VALUES (?, ?, ?)
    """, ('CONFIGURED_UTIL', 'configured', '{"description": "Configured utility"}'))
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            language TEXT
        )
    """)
    
    # Insert mapping for programs IN the flow
    cursor.execute("""
        INSERT INTO program_file_mapping (program_name, file_path, language)
        VALUES (?, ?, ?)
    """, ('PAYCALC', '/path/to/paycalc.cbl', 'COBOL'))
    test_db.commit()
    
    # Setup: Program in flow calling both configured and missing source programs
    insert_dependency(test_db, 'PAYCALC', 'CONFIGURED_UTIL', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    insert_dependency(test_db, 'PAYCALC', 'MISSING_SOURCE', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have two outbound interfaces
    assert len(interfaces['outbound']) == 2
    targets = {i['target'] for i in interfaces['outbound']}
    assert targets == {'CONFIGURED_UTIL', 'MISSING_SOURCE'}
    
    # Check metadata for configured program
    configured_interface = next(i for i in interfaces['outbound'] 
                               if i['target'] == 'CONFIGURED_UTIL')
    assert 'reason' in configured_interface['metadata']
    assert configured_interface['metadata']['reason'] == 'configured'


# Test 20: Outbound interface without external_programs parameter
def test_outbound_interface_without_external_programs_param(flow_builder, test_db):
    """Outbound interfaces work without external_programs parameter (database-only)."""
    # Setup: Create outbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO outbound_interfaces (program_name, reason)
        VALUES (?, ?)
    """, ('EXTERNAL_PROG', 'configured'))
    test_db.commit()
    
    # Setup: Program in flow calling external program
    insert_dependency(test_db, 'PAYCALC', 'EXTERNAL_PROG', 'PROGRAM_CALL',
                     target_type='PROGRAM')
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces WITHOUT external_programs parameter
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
        # Note: No external_programs parameter
    )
    
    # Should have one outbound interface from database
    assert len(interfaces['outbound']) == 1
    assert interfaces['outbound'][0]['target'] == 'EXTERNAL_PROG'
    assert interfaces['outbound'][0]['external'] is True


# ============================================================================
# Tests for Cross-Flow Call Filtering (Task 10.2)
# ============================================================================

# Test 21: No inbound interface for codebase program call
def test_no_inbound_for_codebase_program_call(flow_builder, test_db):
    """Program in codebase calling flow program does NOT create inbound interface."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Insert CALLER_PROG into artifact_dependencies (in codebase)
    insert_dependency(test_db, 'CALLER_PROG', 'SOME_OTHER_PROG', 'PROGRAM_CALL')
    
    # Setup: Configure CALLER_PROG in inbound_interfaces (but it's in codebase)
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('CALLER_PROG', 'PAYCALC', 'PROGRAM_CALL', True))
    test_db.commit()
    
    # Create flow (CALLER_PROG is NOT in this flow, but IS in codebase)
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have zero inbound interfaces (cross-flow call, not inbound)
    assert len(interfaces['inbound']) == 0, \
        "Cross-flow calls from codebase programs should not create inbound interfaces"


# Test 22: Inbound interface for non-codebase program call
def test_inbound_for_non_codebase_program_call(flow_builder, test_db):
    """Program NOT in codebase calling flow program DOES create inbound interface."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: EXTERNAL_PROG is NOT in artifact_dependencies (not in codebase)
    # (No need to insert - it's already not there)
    
    # Setup: Configure EXTERNAL_PROG in inbound_interfaces
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYCALC', 'PROGRAM_CALL', True))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have one inbound interface (from true external program)
    assert len(interfaces['inbound']) == 1
    assert interfaces['inbound'][0]['source'] == 'EXTERNAL_PROG'
    assert interfaces['inbound'][0]['target'] == 'PAYCALC'


# Test 23: Mixed codebase and external callers
def test_mixed_codebase_and_external_callers(flow_builder, test_db):
    """Mix of codebase and external callers - only external creates inbound interface."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Insert CODEBASE_PROG into artifact_dependencies (in codebase)
    insert_dependency(test_db, 'CODEBASE_PROG', 'SOME_OTHER_PROG', 'PROGRAM_CALL')
    
    # Setup: EXTERNAL_PROG is NOT in artifact_dependencies (not in codebase)
    
    # Setup: Configure both in inbound_interfaces
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('CODEBASE_PROG', 'PAYCALC', 'PROGRAM_CALL', True))
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYCALC', 'PROGRAM_CALL', True))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have only one inbound interface (from EXTERNAL_PROG)
    assert len(interfaces['inbound']) == 1
    assert interfaces['inbound'][0]['source'] == 'EXTERNAL_PROG'
    assert interfaces['inbound'][0]['target'] == 'PAYCALC'


# Test 24: Codebase check caching
def test_codebase_check_caching(flow_builder, test_db):
    """Codebase membership check is cached for performance."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure same external caller multiple times
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYCALC', 'PROGRAM_CALL', True))
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYDB', 'CICS_LINK', True))
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC', 'PAYDB'])
    
    # Identify interfaces (this should cache the codebase check for EXTERNAL_PROG)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should have two inbound interfaces
    assert len(interfaces['inbound']) == 2
    assert all(i['source'] == 'EXTERNAL_PROG' for i in interfaces['inbound'])
    
    # Verify cache exists (check internal cache)
    assert hasattr(flow_builder, '_codebase_membership_cache')
    assert 'EXTERNAL_PROG' in flow_builder._codebase_membership_cache
    assert flow_builder._codebase_membership_cache['EXTERNAL_PROG'] is False


# Test 25: Database error handling for codebase check
def test_database_error_handling_codebase_check(flow_builder, test_db):
    """Database errors during codebase check are handled gracefully."""
    # Setup: Create inbound_interfaces table
    from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
    schema_manager = InterfaceSchemaManager(test_db)
    schema_manager.create_tables()
    
    # Setup: Configure external caller
    cursor = test_db.cursor()
    cursor.execute("""
        INSERT INTO inbound_interfaces (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_PROG', 'PAYCALC', 'PROGRAM_CALL', True))
    test_db.commit()
    
    # Drop artifact_dependencies table to simulate database error
    cursor.execute("DROP TABLE artifact_dependencies")
    test_db.commit()
    
    # Create flow
    flow = MockFlow(programs=['PAYROLL1', 'PAYCALC'])
    
    # Identify interfaces (should handle error gracefully)
    interfaces = flow_builder.identify_interfaces(
        flow=flow,
        entry_program='PAYROLL1'
    )
    
    # Should still create inbound interface (conservative approach: treat as external on error)
    assert len(interfaces['inbound']) == 1
    assert interfaces['inbound'][0]['source'] == 'EXTERNAL_PROG'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
