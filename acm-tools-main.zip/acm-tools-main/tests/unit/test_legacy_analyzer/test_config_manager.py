"""Unit tests for configuration manager."""

import pytest
import tempfile
import yaml
from pathlib import Path
from tools.legacy_analyzer.utils.config import (
    ConfigManager, ConfigValidationError,
    AnalysisConfig, ComplexityConfig, PackageConfig
)


class TestConfigManager:
    """Test suite for ConfigManager."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.config_path = Path(self.temp_dir) / 'test_config.yaml'
    
    def teardown_method(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def create_test_config(self, config_dict: dict) -> str:
        """Create a test configuration file.
        
        Args:
            config_dict: Configuration dictionary.
            
        Returns:
            Path to created config file.
        """
        with open(self.config_path, 'w') as f:
            yaml.dump(config_dict, f)
        return str(self.config_path)
    
    def test_load_valid_config(self):
        """Test loading a valid configuration file."""
        config_dict = {
            'analysis': {
                'max_flow_depth': 15,
                'enable_circular_detection': True
            },
            'complexity': {
                'thresholds': {'low': 10, 'medium': 25, 'high': 50},
                'weights': {'loc': 0.3, 'cyclomatic': 0.4, 'dependencies': 0.3}
            }
        }
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        assert manager.get('analysis.max_flow_depth') == 15
        assert manager.get('analysis.enable_circular_detection') is True
    
    def test_load_nonexistent_config(self):
        """Test loading a non-existent configuration file."""
        with pytest.raises(FileNotFoundError):
            ConfigManager('/nonexistent/config.yaml')
    
    def test_load_invalid_yaml(self):
        """Test loading invalid YAML."""
        with open(self.config_path, 'w') as f:
            f.write("invalid: yaml: content: [")
        
        with pytest.raises(ConfigValidationError):
            ConfigManager(str(self.config_path))
    
    def test_get_analysis_config(self):
        """Test getting analysis configuration."""
        config_dict = {
            'analysis': {
                'max_flow_depth': 20,
                'enable_circular_detection': False,
                'max_workers': 8
            }
        }
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        analysis_config = manager.get_analysis_config()
        
        assert isinstance(analysis_config, AnalysisConfig)
        assert analysis_config.max_flow_depth == 20
        assert analysis_config.enable_circular_detection is False
        assert analysis_config.max_workers == 8
    
    def test_get_complexity_config(self):
        """Test getting complexity configuration."""
        config_dict = {
            'complexity': {
                'thresholds': {'low': 5, 'medium': 15, 'high': 30},
                'weights': {'loc': 0.4, 'cyclomatic': 0.3, 'dependencies': 0.3},
                'god_program_threshold': 150
            }
        }
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        complexity_config = manager.get_complexity_config()
        
        assert isinstance(complexity_config, ComplexityConfig)
        assert complexity_config.thresholds['low'] == 5
        assert complexity_config.weights['loc'] == 0.4
        assert complexity_config.god_program_threshold == 150
    
    def test_get_package_config(self):
        """Test getting package configuration."""
        config_dict = {
            'packages': {
                'max_artifacts': 200,
                'max_loc': 100000,
                'allow_external_deps': True
            }
        }
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        package_config = manager.get_package_config()
        
        assert isinstance(package_config, PackageConfig)
        assert package_config.max_artifacts == 200
        assert package_config.max_loc == 100000
        assert package_config.allow_external_deps is True
    
    def test_environment_overrides(self):
        """Test environment-specific configuration overrides."""
        config_dict = {
            'analysis': {
                'max_workers': 4
            },
            'environments': {
                'dev': {
                    'analysis': {
                        'max_workers': 2
                    }
                }
            }
        }
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path, environment='dev')
        
        assert manager.get('analysis.max_workers') == 2
    
    def test_validation_invalid_weights(self):
        """Test validation fails for invalid complexity weights."""
        config_dict = {
            'complexity': {
                'weights': {'loc': 0.5, 'cyclomatic': 0.3, 'dependencies': 0.3}
            },
            'validation': {
                'validate_config': True
            }
        }
        
        config_path = self.create_test_config(config_dict)
        
        with pytest.raises(ConfigValidationError) as exc_info:
            ConfigManager(config_path)
        
        assert 'weights must sum to 1.0' in str(exc_info.value)
    
    def test_validation_invalid_thresholds(self):
        """Test validation fails for invalid complexity thresholds."""
        config_dict = {
            'complexity': {
                'thresholds': {'low': 50, 'medium': 25, 'high': 10}
            },
            'validation': {
                'validate_config': True
            }
        }
        
        config_path = self.create_test_config(config_dict)
        
        with pytest.raises(ConfigValidationError) as exc_info:
            ConfigManager(config_path)
        
        assert 'ascending order' in str(exc_info.value)
    
    def test_validation_invalid_max_workers(self):
        """Test validation fails for negative max_workers."""
        config_dict = {
            'analysis': {
                'max_workers': -1
            },
            'validation': {
                'validate_config': True
            }
        }
        
        config_path = self.create_test_config(config_dict)
        
        with pytest.raises(ConfigValidationError) as exc_info:
            ConfigManager(config_path)
        
        assert 'max_workers must be >= 0' in str(exc_info.value)
    
    def test_get_with_default(self):
        """Test getting configuration value with default."""
        config_dict = {'analysis': {'max_flow_depth': 10}}
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        # Existing key
        assert manager.get('analysis.max_flow_depth', 5) == 10
        
        # Non-existing key
        assert manager.get('nonexistent.key', 'default') == 'default'
    
    def test_set_config_value(self):
        """Test setting configuration values."""
        config_dict = {'analysis': {'max_flow_depth': 10}}
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        manager.set('analysis.max_flow_depth', 20)
        assert manager.get('analysis.max_flow_depth') == 20
        
        # Set nested value
        manager.set('new.nested.value', 42)
        assert manager.get('new.nested.value') == 42
    
    def test_save_config(self):
        """Test saving configuration to file."""
        config_dict = {'analysis': {'max_flow_depth': 10}}
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        manager.set('analysis.max_flow_depth', 20)
        
        output_path = Path(self.temp_dir) / 'saved_config.yaml'
        manager.save_config(str(output_path))
        
        # Load saved config and verify
        with open(output_path, 'r') as f:
            saved_config = yaml.safe_load(f)
        
        assert saved_config['analysis']['max_flow_depth'] == 20
    
    def test_get_all(self):
        """Test getting complete configuration."""
        config_dict = {
            'analysis': {'max_flow_depth': 10},
            'complexity': {'thresholds': {'low': 10, 'medium': 20, 'high': 30}},
            'validation': {'validate_config': False}
        }
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        all_config = manager.get_all()
        
        assert 'analysis' in all_config
        assert 'complexity' in all_config
        assert all_config['analysis']['max_flow_depth'] == 10
    
    def test_get_parser_config(self):
        """Test getting parser configuration."""
        config_dict = {
            'parsers': {
                'cobol': {
                    'extensions': ['.cbl', '.cob'],
                    'encoding': 'cp037',
                    'case_sensitive': False
                }
            }
        }
        
        config_path = self.create_test_config(config_dict)
        manager = ConfigManager(config_path)
        
        parser_config = manager.get_parser_config('cobol')
        
        assert parser_config.extensions == ['.cbl', '.cob']
        assert parser_config.encoding == 'cp037'
        assert parser_config.case_sensitive is False
    
    def test_validation_disabled(self):
        """Test that validation can be disabled."""
        config_dict = {
            'complexity': {
                'weights': {'loc': 0.5, 'cyclomatic': 0.3, 'dependencies': 0.3}
            },
            'validation': {
                'validate_config': False
            }
        }
        
        config_path = self.create_test_config(config_dict)
        
        # Should not raise exception even with invalid weights
        manager = ConfigManager(config_path)
        assert manager.get('complexity.weights.loc') == 0.5
