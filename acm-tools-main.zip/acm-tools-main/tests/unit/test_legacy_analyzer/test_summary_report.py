"""Tests for summary report generator."""

import unittest
import sqlite3
import tempfile
import os
from pathlib import Path

from tools.legacy_analyzer.reports.summary_report import (
    SummaryReportGenerator,
    generate_summary_report
)


class TestSummaryReportGenerator(unittest.TestCase):
    """Test SummaryReportGenerator class."""
    
    def setUp(self):
        """Set up test database."""
        self.db_file = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.db_file.name
        self.db_file.close()
        
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create test tables
        self._create_test_tables()
        self._insert_test_data()
        
        self.conn.commit()
        self.conn.close()
    
    def tearDown(self):
        """Clean up test database."""
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    def _create_test_tables(self):
        """Create test database tables."""
        # inventory table
        self.cursor.execute("""
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY,
                artifact_name VARCHAR(44),
                language VARCHAR(20),
                artifact_type VARCHAR(20)
            )
        """)
        
        # artifact_dependencies table
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY,
                source_artifact_name VARCHAR(44),
                target_artifact_name VARCHAR(44),
                dependency_type VARCHAR(20)
            )
        """)
        
        # inventory_cics table
        self.cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY,
                resource_name VARCHAR(8),
                resource_type VARCHAR(20)
            )
        """)
        
        # inventory_programs table
        self.cursor.execute("""
            CREATE TABLE inventory_programs (
                id INTEGER PRIMARY KEY,
                program_name VARCHAR(44)
            )
        """)
        
        # migration_flows table
        self.cursor.execute("""
            CREATE TABLE migration_flows (
                id INTEGER PRIMARY KEY,
                flow_id VARCHAR(50),
                complexity_tier VARCHAR(20)
            )
        """)
    
    def _insert_test_data(self):
        """Insert test data."""
        # Insert inventory data
        self.cursor.execute("""
            INSERT INTO inventory (artifact_name, language, artifact_type)
            VALUES 
            ('PROG1', 'COBOL', 'PROGRAM'),
            ('PROG2', 'COBOL', 'PROGRAM'),
            ('PROG3', 'PL/I', 'PROGRAM'),
            ('JOB1', 'JCL', 'JOB'),
            ('COPY1', 'COBOL', 'COPYBOOK')
        """)
        
        # Insert dependency data
        self.cursor.execute("""
            INSERT INTO artifact_dependencies (source_artifact_name, target_artifact_name, dependency_type)
            VALUES 
            ('PROG1', 'COPY1', 'COPY'),
            ('PROG1', 'PROG2', 'CALL'),
            ('PROG2', 'FILE1', 'CICS_FILE'),
            ('JOB1', 'PROG1', 'EXEC_PGM')
        """)
        
        # Insert CICS data
        self.cursor.execute("""
            INSERT INTO inventory_cics (resource_name, resource_type)
            VALUES 
            ('TRAN1', 'TRANSACTION'),
            ('PROG1', 'PROGRAM'),
            ('FILE1', 'FILE')
        """)
        
        # Insert program data
        self.cursor.execute("""
            INSERT INTO inventory_programs (program_name)
            VALUES 
            ('PROG1'),
            ('PROG2')
        """)
        
        # Insert migration flow data
        self.cursor.execute("""
            INSERT INTO migration_flows (flow_id, complexity_tier)
            VALUES 
            ('FLOW1', 'LOW'),
            ('FLOW2', 'MEDIUM'),
            ('FLOW3', 'HIGH')
        """)


class TestGetInventoryStats(TestSummaryReportGenerator):
    """Test _get_inventory_stats method."""
    
    def test_get_inventory_stats_with_data(self):
        """Test inventory stats with populated database."""
        generator = SummaryReportGenerator(self.db_path)
        generator.conn = sqlite3.connect(self.db_path)
        
        stats = generator._get_inventory_stats()
        
        self.assertEqual(stats['total'], 5)
        self.assertEqual(stats['by_language']['COBOL'], 3)
        self.assertEqual(stats['by_language']['PL/I'], 1)
        self.assertEqual(stats['by_language']['JCL'], 1)
        
        generator.conn.close()
    
    def test_get_inventory_stats_empty_table(self):
        """Test inventory stats with empty table."""
        # Create empty database
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY,
                artifact_name VARCHAR(44),
                language VARCHAR(20)
            )
        """)
        conn.commit()
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_inventory_stats()
            
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_language'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)
    
    def test_get_inventory_stats_missing_table(self):
        """Test inventory stats with missing table."""
        # Create database without inventory table
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_inventory_stats()
            
            # Should return empty stats without error
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_language'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)


class TestGetDependencyStats(TestSummaryReportGenerator):
    """Test _get_dependency_stats method."""
    
    def test_get_dependency_stats_with_data(self):
        """Test dependency stats with populated database."""
        generator = SummaryReportGenerator(self.db_path)
        generator.conn = sqlite3.connect(self.db_path)
        
        stats = generator._get_dependency_stats()
        
        self.assertEqual(stats['total'], 4)
        self.assertEqual(stats['by_type']['COPY'], 1)
        self.assertEqual(stats['by_type']['CALL'], 1)
        self.assertEqual(stats['by_type']['CICS_FILE'], 1)
        self.assertEqual(stats['by_type']['EXEC_PGM'], 1)
        
        generator.conn.close()
    
    def test_get_dependency_stats_empty_table(self):
        """Test dependency stats with empty table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY,
                source_artifact_name VARCHAR(44),
                target_artifact_name VARCHAR(44),
                dependency_type VARCHAR(20)
            )
        """)
        conn.commit()
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_dependency_stats()
            
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_type'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)
    
    def test_get_dependency_stats_missing_table(self):
        """Test dependency stats with missing table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_dependency_stats()
            
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_type'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)


class TestGetCicsStats(TestSummaryReportGenerator):
    """Test _get_cics_stats method."""
    
    def test_get_cics_stats_with_data(self):
        """Test CICS stats with populated database."""
        generator = SummaryReportGenerator(self.db_path)
        generator.conn = sqlite3.connect(self.db_path)
        
        stats = generator._get_cics_stats()
        
        self.assertEqual(stats['total'], 3)
        self.assertEqual(stats['by_type']['TRANSACTION'], 1)
        self.assertEqual(stats['by_type']['PROGRAM'], 1)
        self.assertEqual(stats['by_type']['FILE'], 1)
        
        generator.conn.close()
    
    def test_get_cics_stats_empty_table(self):
        """Test CICS stats with empty table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY,
                resource_name VARCHAR(8),
                resource_type VARCHAR(20)
            )
        """)
        conn.commit()
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_cics_stats()
            
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_type'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)
    
    def test_get_cics_stats_missing_table(self):
        """Test CICS stats with missing table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_cics_stats()
            
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_type'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)


class TestGetProgramStats(TestSummaryReportGenerator):
    """Test _get_program_stats method."""
    
    def test_get_program_stats_with_data(self):
        """Test program stats with populated database."""
        generator = SummaryReportGenerator(self.db_path)
        generator.conn = sqlite3.connect(self.db_path)
        
        stats = generator._get_program_stats()
        
        self.assertEqual(stats['total'], 2)
        
        generator.conn.close()
    
    def test_get_program_stats_empty_table(self):
        """Test program stats with empty table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE inventory_programs (
                id INTEGER PRIMARY KEY,
                program_name VARCHAR(44)
            )
        """)
        conn.commit()
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_program_stats()
            
            self.assertEqual(stats['total'], 0)
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)
    
    def test_get_program_stats_missing_table(self):
        """Test program stats with missing table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_program_stats()
            
            self.assertEqual(stats['total'], 0)
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)


class TestGetMigrationFlowStats(TestSummaryReportGenerator):
    """Test _get_migration_flow_stats method."""
    
    def test_get_migration_flow_stats_with_data(self):
        """Test migration flow stats with populated database."""
        generator = SummaryReportGenerator(self.db_path)
        generator.conn = sqlite3.connect(self.db_path)
        
        stats = generator._get_migration_flow_stats()
        
        self.assertEqual(stats['total'], 3)
        self.assertEqual(stats['by_complexity']['LOW'], 1)
        self.assertEqual(stats['by_complexity']['MEDIUM'], 1)
        self.assertEqual(stats['by_complexity']['HIGH'], 1)
        
        generator.conn.close()
    
    def test_get_migration_flow_stats_empty_table(self):
        """Test migration flow stats with empty table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE migration_flows (
                id INTEGER PRIMARY KEY,
                flow_id VARCHAR(50),
                complexity_tier VARCHAR(20)
            )
        """)
        conn.commit()
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_migration_flow_stats()
            
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_complexity'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)
    
    def test_get_migration_flow_stats_missing_table(self):
        """Test migration flow stats with missing table."""
        empty_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        empty_db_path = empty_db.name
        empty_db.close()
        
        conn = sqlite3.connect(empty_db_path)
        conn.close()
        
        try:
            generator = SummaryReportGenerator(empty_db_path)
            generator.conn = sqlite3.connect(empty_db_path)
            
            stats = generator._get_migration_flow_stats()
            
            self.assertEqual(stats['total'], 0)
            self.assertEqual(stats['by_complexity'], {})
            
            generator.conn.close()
        finally:
            os.unlink(empty_db_path)


class TestFormatMarkdown(unittest.TestCase):
    """Test _format_markdown method."""
    
    def test_format_markdown_with_all_data(self):
        """Test Markdown formatting with all sections populated."""
        generator = SummaryReportGenerator(':memory:')
        
        inventory_stats = {
            'total': 5,
            'by_language': {'COBOL': 3, 'JCL': 2}
        }
        dependency_stats = {
            'total': 10,
            'by_type': {'COPY': 5, 'CALL': 5}
        }
        cics_stats = {
            'total': 3,
            'by_type': {'TRANSACTION': 1, 'PROGRAM': 2}
        }
        program_stats = {
            'total': 2
        }
        migration_flow_stats = {
            'total': 4,
            'by_complexity': {'LOW': 2, 'HIGH': 2}
        }
        
        markdown = generator._format_markdown(
            inventory_stats,
            dependency_stats,
            cics_stats,
            program_stats,
            migration_flow_stats
        )
        
        # Check header
        self.assertIn('# Analysis Summary Report', markdown)
        
        # Check inventory section
        self.assertIn('## Inventory Statistics', markdown)
        self.assertIn('**Total Artifacts:** 5', markdown)
        self.assertIn('### By Language', markdown)
        self.assertIn('| COBOL | 3 |', markdown)
        self.assertIn('| JCL | 2 |', markdown)
        
        # Check dependency section
        self.assertIn('## Dependency Statistics', markdown)
        self.assertIn('**Total Dependencies:** 10', markdown)
        self.assertIn('### By Type', markdown)
        self.assertIn('| COPY | 5 |', markdown)
        self.assertIn('| CALL | 5 |', markdown)
        
        # Check CICS section
        self.assertIn('## CICS Resources', markdown)
        self.assertIn('**Total CICS Resources:** 3', markdown)
        self.assertIn('### By Resource Type', markdown)
        self.assertIn('| TRANSACTION | 1 |', markdown)
        self.assertIn('| PROGRAM | 2 |', markdown)
        
        # Check programs section
        self.assertIn('## Programs', markdown)
        self.assertIn('**Total Programs:** 2', markdown)
        
        # Check migration flows section
        self.assertIn('## Migration Flows', markdown)
        self.assertIn('**Total Migration Flows:** 4', markdown)
        self.assertIn('### By Complexity', markdown)
        self.assertIn('| LOW | 2 |', markdown)
        self.assertIn('| HIGH | 2 |', markdown)
    
    def test_format_markdown_without_cics(self):
        """Test Markdown formatting without CICS data."""
        generator = SummaryReportGenerator(':memory:')
        
        inventory_stats = {'total': 5, 'by_language': {'COBOL': 5}}
        dependency_stats = {'total': 10, 'by_type': {'COPY': 10}}
        cics_stats = {'total': 0, 'by_type': {}}
        program_stats = {'total': 2}
        migration_flow_stats = {'total': 0, 'by_complexity': {}}
        
        markdown = generator._format_markdown(
            inventory_stats,
            dependency_stats,
            cics_stats,
            program_stats,
            migration_flow_stats
        )
        
        # CICS section should not be present
        self.assertNotIn('## CICS Resources', markdown)
        
        # Migration flows section should not be present
        self.assertNotIn('## Migration Flows', markdown)
        
        # Other sections should be present
        self.assertIn('## Inventory Statistics', markdown)
        self.assertIn('## Dependency Statistics', markdown)
        self.assertIn('## Programs', markdown)
    
    def test_format_markdown_empty_data(self):
        """Test Markdown formatting with empty data."""
        generator = SummaryReportGenerator(':memory:')
        
        inventory_stats = {'total': 0, 'by_language': {}}
        dependency_stats = {'total': 0, 'by_type': {}}
        cics_stats = {'total': 0, 'by_type': {}}
        program_stats = {'total': 0}
        migration_flow_stats = {'total': 0, 'by_complexity': {}}
        
        markdown = generator._format_markdown(
            inventory_stats,
            dependency_stats,
            cics_stats,
            program_stats,
            migration_flow_stats
        )
        
        # Should have basic structure
        self.assertIn('# Analysis Summary Report', markdown)
        self.assertIn('## Inventory Statistics', markdown)
        self.assertIn('**Total Artifacts:** 0', markdown)
        self.assertIn('## Dependency Statistics', markdown)
        self.assertIn('**Total Dependencies:** 0', markdown)
        self.assertIn('## Programs', markdown)
        self.assertIn('**Total Programs:** 0', markdown)
        
        # Should not have tables for empty data
        self.assertNotIn('### By Language', markdown)
        self.assertNotIn('### By Type', markdown)


class TestGenerateMethod(TestSummaryReportGenerator):
    """Test generate method."""
    
    def test_generate_success(self):
        """Test successful report generation."""
        output_file = tempfile.NamedTemporaryFile(delete=False, suffix='.md')
        output_path = output_file.name
        output_file.close()
        os.unlink(output_path)
        
        try:
            generator = SummaryReportGenerator(self.db_path)
            generator.generate(output_path)
            
            # Check file was created
            self.assertTrue(os.path.exists(output_path))
            
            # Check content
            content = Path(output_path).read_text()
            self.assertIn('# Analysis Summary Report', content)
            self.assertIn('## Inventory Statistics', content)
            self.assertIn('**Total Artifacts:** 5', content)
            
        finally:
            if os.path.exists(output_path):
                os.unlink(output_path)
    
    def test_generate_creates_directory(self):
        """Test that generate creates output directory."""
        temp_dir = tempfile.mkdtemp()
        output_path = os.path.join(temp_dir, 'subdir', 'report.md')
        
        try:
            generator = SummaryReportGenerator(self.db_path)
            generator.generate(output_path)
            
            # Check file was created
            self.assertTrue(os.path.exists(output_path))
            
        finally:
            if os.path.exists(output_path):
                os.unlink(output_path)
            if os.path.exists(os.path.dirname(output_path)):
                os.rmdir(os.path.dirname(output_path))
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
    
    def test_generate_missing_database(self):
        """Test error handling for missing database."""
        generator = SummaryReportGenerator('/nonexistent/database.db')
        
        with self.assertRaises(FileNotFoundError) as context:
            generator.generate('output.md')
        
        self.assertIn('Database file not found', str(context.exception))
    
    def test_generate_invalid_database_path(self):
        """Test error handling for invalid database path."""
        # Create a directory instead of a file
        temp_dir = tempfile.mkdtemp()
        
        try:
            generator = SummaryReportGenerator(temp_dir)
            
            with self.assertRaises(ValueError) as context:
                generator.generate('output.md')
            
            self.assertIn('not a file', str(context.exception))
            
        finally:
            os.rmdir(temp_dir)
    
    def test_generate_closes_connection(self):
        """Test that connection is closed after generation."""
        output_file = tempfile.NamedTemporaryFile(delete=False, suffix='.md')
        output_path = output_file.name
        output_file.close()
        os.unlink(output_path)
        
        try:
            generator = SummaryReportGenerator(self.db_path)
            generator.generate(output_path)
            
            # Connection should be None after generation
            self.assertIsNone(generator.conn)
            
        finally:
            if os.path.exists(output_path):
                os.unlink(output_path)


class TestGenerateSummaryReportFunction(TestSummaryReportGenerator):
    """Test generate_summary_report convenience function."""
    
    def test_generate_summary_report_success(self):
        """Test successful report generation via convenience function."""
        output_file = tempfile.NamedTemporaryFile(delete=False, suffix='.md')
        output_path = output_file.name
        output_file.close()
        os.unlink(output_path)
        
        try:
            generate_summary_report(self.db_path, output_path)
            
            # Check file was created
            self.assertTrue(os.path.exists(output_path))
            
            # Check content
            content = Path(output_path).read_text()
            self.assertIn('# Analysis Summary Report', content)
            self.assertIn('## Inventory Statistics', content)
            
        finally:
            if os.path.exists(output_path):
                os.unlink(output_path)
    
    def test_generate_summary_report_missing_database(self):
        """Test error handling for missing database."""
        with self.assertRaises(FileNotFoundError):
            generate_summary_report('/nonexistent/database.db', 'output.md')


if __name__ == '__main__':
    unittest.main()
