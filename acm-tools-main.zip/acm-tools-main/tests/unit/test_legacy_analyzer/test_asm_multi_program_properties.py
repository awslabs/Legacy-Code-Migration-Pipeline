#!/usr/bin/env python3
"""
Property-based tests for Assembler multi-program parsing.

**Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Assembler)**
**Validates: Requirements 1.2**

This module tests the enhanced Assembler parser's ability to detect CSECT boundaries
and extract ENTRY points as separate program entities within multi-program files.
"""

import pytest
from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.parsers.asm_parser import ASMDependencyParser
from tools.legacy_analyzer.analysis.program_boundary_detector import AssemblerProgramBoundaryDetector
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Strategy for generating Assembler source content with multiple CSECTs
@st.composite
def asm_multi_program_source(draw):
    """Generate Assembler source with multiple CSECT definitions."""
    
    # Generate 1-3 CSECT programs (keep it simple for testing)
    num_csects = draw(st.integers(min_value=1, max_value=3))
    
    lines = []
    
    # Add some initial comments
    lines.append("* Assembler multi-program source")
    lines.append("*")
    
    for i in range(num_csects):
        # Generate simple CSECT names (letters and numbers only)
        csect_name = draw(st.text(
            alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
            min_size=3, max_size=8
        ).filter(lambda x: x and x[0].isalpha()))
        
        # CSECT definition
        lines.append(f"{csect_name} CSECT")
        lines.append(f"         USING {csect_name},R15")
        
        # Add some typical Assembler instructions
        lines.append("         STM   R14,R12,12(R13)")
        lines.append("         BR    R14")
        
        # Add some space between CSECTs
        lines.append("")
    
    lines.append("         END")
    
    return "\n".join(lines)


@st.composite
def asm_csect_names(draw):
    """Generate valid Assembler CSECT names."""
    return draw(st.text(
        alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        min_size=3, max_size=8
    ).filter(lambda x: x and x[0].isalpha()))


@st.composite
def asm_source_with_csects(draw):
    """Generate Assembler source with specific CSECT names."""
    csect_names = draw(st.lists(asm_csect_names(), min_size=1, max_size=3, unique=True))
    
    lines = []
    lines.append("* Multi-CSECT Assembler program")
    
    for csect_name in csect_names:
        lines.append(f"{csect_name} CSECT")
        lines.append(f"         USING {csect_name},R15")
        lines.append("         STM   R14,R12,12(R13)")
        lines.append("         BR    R14")
        lines.append("")
    
    lines.append("         END")
    return "\n".join(lines), csect_names


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Assembler)**
# **Validates: Requirements 1.2**
@settings(max_examples=50)  # Reduced for faster testing
@given(
    asm_source=asm_multi_program_source()
)
def test_property_asm_multi_program_parsing_accuracy(asm_source):
    """
    Property 1: Multi-program file parsing accuracy (Assembler)
    
    For any Assembler source file containing multiple CSECT sections, parsing should 
    identify each individual CSECT as a separate program with correct boundaries and 
    track dependencies separately for each CSECT.
    """
    parser = ASMDependencyParser()
    detector = AssemblerProgramBoundaryDetector()
    
    # Ensure source has some content
    lines = asm_source.splitlines()
    assume(len(lines) >= 1)
    assume(any(line.strip() for line in lines))  # At least one non-empty line
    
    # Test program boundary detection
    programs = detector.detect_boundaries(asm_source)
    
    # Property: All detected programs should have valid Assembler characteristics
    for program in programs:
        assert program.language == "ASM", \
            f"Program '{program.program_name}' should have language 'ASM', got '{program.language}'"
        
        assert program.program_type in [ProgramType.CSECT, ProgramType.MAIN, ProgramType.ENTRY_POINT], \
            f"Program '{program.program_name}' should be CSECT, MAIN, or ENTRY_POINT type, got {program.program_type}"
        
        assert program.start_line >= 1, \
            f"Program '{program.program_name}' should have start_line >= 1, got {program.start_line}"
        
        assert program.end_line >= program.start_line, \
            f"Program '{program.program_name}' should have end_line >= start_line"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
    
    # Property: Programs should not overlap
    for i, prog1 in enumerate(programs):
        for prog2 in programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"Assembler programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: If CSECT lines exist, should detect corresponding programs
    csect_lines = []
    for line in lines:
        stripped = line.strip().upper()
        if ' CSECT' in stripped and not stripped.startswith('*'):
            csect_lines.append(line)
    
    if csect_lines:
        assert len(programs) > 0, \
            "Assembler source with CSECT should detect at least one program"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Assembler)**
# **Validates: Requirements 1.2**
@settings(max_examples=50)
@given(
    source_and_names=asm_source_with_csects()
)
def test_property_asm_csect_name_detection(source_and_names):
    """
    Property 1: Multi-program file parsing accuracy (Assembler) - CSECT name detection
    
    For any Assembler source file with CSECT definitions, the parser should correctly
    identify the CSECT names and use them as program names.
    """
    asm_source, expected_csect_names = source_and_names
    detector = AssemblerProgramBoundaryDetector()
    
    # Detect program boundaries
    programs = detector.detect_boundaries(asm_source)
    
    # Property: All expected CSECT names should be detected as programs
    detected_names = {program.program_name for program in programs}
    
    for expected_name in expected_csect_names:
        assert expected_name in detected_names, \
            f"CSECT '{expected_name}' should be detected as a program"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
