"""Unit tests for flow data models."""

import pytest
from tools.legacy_analyzer.models.flow import EntryPoint, ServiceCandidate


class TestEntryPoint:
    """Test suite for EntryPoint data model."""
    
    def test_online_entry_point_creation(self):
        """Test creating an ONLINE entry point from CICS transaction."""
        entry_point = EntryPoint(
            program_name='COACTUPC',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='CAUP',
            cics_group='CARDDEMO',
            mapset_name='COACTUP',
            status='ENABLED',
            description='Account Update'
        )
        
        assert entry_point.program_name == 'COACTUPC'
        assert entry_point.entry_type == 'ONLINE'
        assert entry_point.confidence == 'EXPLICIT'
        assert entry_point.source == 'CSD'
        assert entry_point.transaction_id == 'CAUP'
        assert entry_point.cics_group == 'CARDDEMO'
        assert entry_point.mapset_name == 'COACTUP'
        assert entry_point.status == 'ENABLED'
        assert entry_point.description == 'Account Update'
    
    def test_batch_entry_point_creation(self):
        """Test creating a BATCH entry point from JCL."""
        entry_point = EntryPoint(
            program_name='CBACT01C',
            entry_type='BATCH',
            confidence='EXPLICIT',
            source='JCL',
            jcl_name='DALYREJS',
            job_name='DAILYJOB',
            status='ENABLED'
        )
        
        assert entry_point.program_name == 'CBACT01C'
        assert entry_point.entry_type == 'BATCH'
        assert entry_point.confidence == 'EXPLICIT'
        assert entry_point.source == 'JCL'
        assert entry_point.jcl_name == 'DALYREJS'
        assert entry_point.job_name == 'DAILYJOB'
        assert entry_point.status == 'ENABLED'
    
    def test_inferred_entry_point_creation(self):
        """Test creating an INFERRED entry point from code analysis."""
        entry_point = EntryPoint(
            program_name='UTILPROG',
            entry_type='INFERRED',
            confidence='INFERRED',
            source='CODE_ANALYSIS',
            description='Not called by any program'
        )
        
        assert entry_point.program_name == 'UTILPROG'
        assert entry_point.entry_type == 'INFERRED'
        assert entry_point.confidence == 'INFERRED'
        assert entry_point.source == 'CODE_ANALYSIS'
        assert entry_point.description == 'Not called by any program'
    
    def test_minimal_entry_point_creation(self):
        """Test creating entry point with only required fields."""
        entry_point = EntryPoint(
            program_name='TESTPROG',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD'
        )
        
        assert entry_point.program_name == 'TESTPROG'
        assert entry_point.entry_type == 'ONLINE'
        assert entry_point.confidence == 'EXPLICIT'
        assert entry_point.source == 'CSD'
        assert entry_point.transaction_id is None
        assert entry_point.cics_group is None
        assert entry_point.mapset_name is None
        assert entry_point.jcl_name is None
        assert entry_point.job_name is None
        assert entry_point.status is None
        assert entry_point.description is None
    
    def test_to_dict_online_entry_point(self):
        """Test converting ONLINE entry point to dictionary."""
        entry_point = EntryPoint(
            program_name='COACTUPC',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='CAUP',
            cics_group='CARDDEMO',
            mapset_name='COACTUP',
            status='ENABLED',
            description='Account Update'
        )
        
        result = entry_point.to_dict()
        
        assert result['program_name'] == 'COACTUPC'
        assert result['entry_type'] == 'ONLINE'
        assert result['confidence'] == 'EXPLICIT'
        assert result['source'] == 'CSD'
        assert result['transaction_id'] == 'CAUP'
        assert result['cics_group'] == 'CARDDEMO'
        assert result['mapset_name'] == 'COACTUP'
        assert result['status'] == 'ENABLED'
        assert result['description'] == 'Account Update'
    
    def test_to_dict_batch_entry_point(self):
        """Test converting BATCH entry point to dictionary."""
        entry_point = EntryPoint(
            program_name='CBACT01C',
            entry_type='BATCH',
            confidence='EXPLICIT',
            source='JCL',
            jcl_name='DALYREJS',
            job_name='DAILYJOB',
            status='ENABLED'
        )
        
        result = entry_point.to_dict()
        
        assert result['program_name'] == 'CBACT01C'
        assert result['entry_type'] == 'BATCH'
        assert result['confidence'] == 'EXPLICIT'
        assert result['source'] == 'JCL'
        assert result['jcl_name'] == 'DALYREJS'
        assert result['job_name'] == 'DAILYJOB'
        assert result['status'] == 'ENABLED'
    
    def test_to_dict_minimal_entry_point(self):
        """Test converting minimal entry point to dictionary."""
        entry_point = EntryPoint(
            program_name='TESTPROG',
            entry_type='INFERRED',
            confidence='INFERRED',
            source='CODE_ANALYSIS'
        )
        
        result = entry_point.to_dict()
        
        assert result['program_name'] == 'TESTPROG'
        assert result['entry_type'] == 'INFERRED'
        assert result['confidence'] == 'INFERRED'
        assert result['source'] == 'CODE_ANALYSIS'
        # Optional fields should not be in dict
        assert 'transaction_id' not in result
        assert 'cics_group' not in result
        assert 'mapset_name' not in result
        assert 'jcl_name' not in result
        assert 'job_name' not in result
        assert 'status' not in result
        assert 'description' not in result
    
    def test_is_explicit_method(self):
        """Test is_explicit() method."""
        explicit_entry = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD'
        )
        
        inferred_entry = EntryPoint(
            program_name='PROG2',
            entry_type='INFERRED',
            confidence='INFERRED',
            source='CODE_ANALYSIS'
        )
        
        assert explicit_entry.is_explicit() is True
        assert inferred_entry.is_explicit() is False
    
    def test_is_inferred_method(self):
        """Test is_inferred() method."""
        explicit_entry = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD'
        )
        
        inferred_entry = EntryPoint(
            program_name='PROG2',
            entry_type='INFERRED',
            confidence='INFERRED',
            source='CODE_ANALYSIS'
        )
        
        assert explicit_entry.is_inferred() is False
        assert inferred_entry.is_inferred() is True
    
    def test_is_enabled_method_with_enabled_status(self):
        """Test is_enabled() method with ENABLED status."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            status='ENABLED'
        )
        
        assert entry_point.is_enabled() is True
    
    def test_is_enabled_method_with_disabled_status(self):
        """Test is_enabled() method with DISABLED status."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            status='DISABLED'
        )
        
        assert entry_point.is_enabled() is False
    
    def test_is_enabled_method_with_no_status(self):
        """Test is_enabled() method when status is None (defaults to True)."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='INFERRED',
            confidence='INFERRED',
            source='CODE_ANALYSIS'
        )
        
        assert entry_point.is_enabled() is True
    
    def test_str_representation_online(self):
        """Test string representation for ONLINE entry point."""
        entry_point = EntryPoint(
            program_name='COACTUPC',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='CAUP'
        )
        
        result = str(entry_point)
        
        assert 'COACTUPC' in result
        assert 'ONLINE' in result
        assert 'TRAN=CAUP' in result
    
    def test_str_representation_batch(self):
        """Test string representation for BATCH entry point."""
        entry_point = EntryPoint(
            program_name='CBACT01C',
            entry_type='BATCH',
            confidence='EXPLICIT',
            source='JCL',
            jcl_name='DALYREJS'
        )
        
        result = str(entry_point)
        
        assert 'CBACT01C' in result
        assert 'BATCH' in result
        assert 'JCL=DALYREJS' in result
    
    def test_str_representation_inferred(self):
        """Test string representation for INFERRED entry point."""
        entry_point = EntryPoint(
            program_name='UTILPROG',
            entry_type='INFERRED',
            confidence='INFERRED',
            source='CODE_ANALYSIS'
        )
        
        result = str(entry_point)
        
        assert 'UTILPROG' in result
        assert 'INFERRED' in result
    
    def test_str_representation_with_both_transaction_and_jcl(self):
        """Test string representation when both transaction_id and jcl_name are present."""
        entry_point = EntryPoint(
            program_name='TESTPROG',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='TEST',
            jcl_name='TESTJCL'
        )
        
        result = str(entry_point)
        
        assert 'TESTPROG' in result
        assert 'ONLINE' in result
        assert 'TRAN=TEST' in result
        assert 'JCL=TESTJCL' in result
    
    def test_entry_point_with_all_fields(self):
        """Test creating entry point with all possible fields."""
        entry_point = EntryPoint(
            program_name='FULLPROG',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='FULL',
            cics_group='TESTGRP',
            mapset_name='FULLMAP',
            jcl_name='FULLJCL',
            job_name='FULLJOB',
            status='ENABLED',
            description='Full test entry point'
        )
        
        assert entry_point.program_name == 'FULLPROG'
        assert entry_point.entry_type == 'ONLINE'
        assert entry_point.confidence == 'EXPLICIT'
        assert entry_point.source == 'CSD'
        assert entry_point.transaction_id == 'FULL'
        assert entry_point.cics_group == 'TESTGRP'
        assert entry_point.mapset_name == 'FULLMAP'
        assert entry_point.jcl_name == 'FULLJCL'
        assert entry_point.job_name == 'FULLJOB'
        assert entry_point.status == 'ENABLED'
        assert entry_point.description == 'Full test entry point'
        
        # Test all methods
        assert entry_point.is_explicit() is True
        assert entry_point.is_inferred() is False
        assert entry_point.is_enabled() is True
        
        # Test to_dict includes all fields
        result = entry_point.to_dict()
        assert len(result) == 11  # All fields should be present



class TestServiceCandidate:
    """Test suite for ServiceCandidate data model."""
    
    def test_service_candidate_creation_minimal(self):
        """Test creating a service candidate with minimal fields."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='TST1'
        )
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=[entry_point],
            grouping_reason='CICS_GROUP',
            confidence='HIGH'
        )
        
        assert service.name == 'Test Service'
        assert len(service.entry_points) == 1
        assert service.entry_points[0].program_name == 'PROG1'
        assert service.grouping_reason == 'CICS_GROUP'
        assert service.confidence == 'HIGH'
        assert service.shared_data == []
        assert service.shared_programs == []
        assert service.total_complexity == 0.0
        assert service.total_programs == 1  # Auto-calculated
        assert service.total_transactions == 1  # Auto-calculated
        assert service.cics_group is None
        assert service.recommendation is None
    
    def test_service_candidate_creation_full(self):
        """Test creating a service candidate with all fields."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST1',
                cics_group='TESTGRP'
            ),
            EntryPoint(
                program_name='PROG2',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST2',
                cics_group='TESTGRP'
            ),
            EntryPoint(
                program_name='PROG3',
                entry_type='BATCH',
                confidence='EXPLICIT',
                source='JCL',
                jcl_name='TESTJCL'
            )
        ]
        
        service = ServiceCandidate(
            name='Customer Management Service',
            entry_points=entry_points,
            grouping_reason='CICS_GROUP',
            confidence='HIGH',
            shared_data=['CUSTDAT', 'ACCTDAT'],
            shared_programs=['CUSTVAL', 'CUSTFMT'],
            total_complexity=245.8,
            cics_group='TESTGRP',
            recommendation='CONSIDER_MERGE'
        )
        
        assert service.name == 'Customer Management Service'
        assert len(service.entry_points) == 3
        assert service.grouping_reason == 'CICS_GROUP'
        assert service.confidence == 'HIGH'
        assert service.shared_data == ['CUSTDAT', 'ACCTDAT']
        assert service.shared_programs == ['CUSTVAL', 'CUSTFMT']
        assert service.total_complexity == 245.8
        assert service.total_programs == 3  # Auto-calculated
        assert service.total_transactions == 2  # Only ONLINE entry points
        assert service.cics_group == 'TESTGRP'
        assert service.recommendation == 'CONSIDER_MERGE'
    
    def test_service_candidate_auto_calculate_totals(self):
        """Test that totals are auto-calculated in __post_init__."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST1'
            ),
            EntryPoint(
                program_name='PROG2',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST2'
            ),
            EntryPoint(
                program_name='PROG3',
                entry_type='BATCH',
                confidence='EXPLICIT',
                source='JCL'
            ),
            EntryPoint(
                program_name='PROG4',
                entry_type='INFERRED',
                confidence='INFERRED',
                source='CODE_ANALYSIS'
            )
        ]
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=entry_points,
            grouping_reason='DATA_OWNERSHIP',
            confidence='MEDIUM'
        )
        
        # Should auto-calculate
        assert service.total_programs == 4
        assert service.total_transactions == 2  # Only ONLINE
    
    def test_service_candidate_manual_totals_not_overridden(self):
        """Test that manually set totals are not overridden."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST1'
            )
        ]
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=entry_points,
            grouping_reason='CICS_GROUP',
            confidence='HIGH',
            total_programs=10,  # Manually set
            total_transactions=5  # Manually set
        )
        
        # Should keep manual values
        assert service.total_programs == 10
        assert service.total_transactions == 5
    
    def test_service_candidate_to_dict_minimal(self):
        """Test converting minimal service candidate to dictionary."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='TST1'
        )
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=[entry_point],
            grouping_reason='CICS_GROUP',
            confidence='HIGH'
        )
        
        result = service.to_dict()
        
        assert result['name'] == 'Test Service'
        assert len(result['entry_points']) == 1
        assert result['entry_points'][0]['program_name'] == 'PROG1'
        assert result['grouping_reason'] == 'CICS_GROUP'
        assert result['confidence'] == 'HIGH'
        assert result['shared_data'] == []
        assert result['shared_programs'] == []
        assert result['total_complexity'] == 0.0
        assert result['total_programs'] == 1
        assert result['total_transactions'] == 1
        # Optional fields should not be in dict
        assert 'cics_group' not in result
        assert 'recommendation' not in result
    
    def test_service_candidate_to_dict_full(self):
        """Test converting full service candidate to dictionary."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST1'
            ),
            EntryPoint(
                program_name='PROG2',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST2'
            )
        ]
        
        service = ServiceCandidate(
            name='Customer Service',
            entry_points=entry_points,
            grouping_reason='CICS_GROUP',
            confidence='HIGH',
            shared_data=['CUSTDAT'],
            shared_programs=['CUSTVAL'],
            total_complexity=150.5,
            cics_group='CUSTGRP',
            recommendation='CONSIDER_MERGE'
        )
        
        result = service.to_dict()
        
        assert result['name'] == 'Customer Service'
        assert len(result['entry_points']) == 2
        assert result['grouping_reason'] == 'CICS_GROUP'
        assert result['confidence'] == 'HIGH'
        assert result['shared_data'] == ['CUSTDAT']
        assert result['shared_programs'] == ['CUSTVAL']
        assert result['total_complexity'] == 150.5
        assert result['total_programs'] == 2
        assert result['total_transactions'] == 2
        assert result['cics_group'] == 'CUSTGRP'
        assert result['recommendation'] == 'CONSIDER_MERGE'
    
    def test_get_program_names(self):
        """Test getting list of program names."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD'
            ),
            EntryPoint(
                program_name='PROG2',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD'
            ),
            EntryPoint(
                program_name='PROG3',
                entry_type='BATCH',
                confidence='EXPLICIT',
                source='JCL'
            )
        ]
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=entry_points,
            grouping_reason='SHARED_PROGRAMS',
            confidence='MEDIUM'
        )
        
        program_names = service.get_program_names()
        
        assert len(program_names) == 3
        assert 'PROG1' in program_names
        assert 'PROG2' in program_names
        assert 'PROG3' in program_names
    
    def test_get_transaction_ids(self):
        """Test getting list of transaction IDs."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST1'
            ),
            EntryPoint(
                program_name='PROG2',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST2'
            ),
            EntryPoint(
                program_name='PROG3',
                entry_type='BATCH',
                confidence='EXPLICIT',
                source='JCL'
                # No transaction_id for BATCH
            )
        ]
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=entry_points,
            grouping_reason='CICS_GROUP',
            confidence='HIGH'
        )
        
        transaction_ids = service.get_transaction_ids()
        
        assert len(transaction_ids) == 2
        assert 'TST1' in transaction_ids
        assert 'TST2' in transaction_ids
    
    def test_get_transaction_ids_empty(self):
        """Test getting transaction IDs when none exist."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='BATCH',
                confidence='EXPLICIT',
                source='JCL'
            ),
            EntryPoint(
                program_name='PROG2',
                entry_type='INFERRED',
                confidence='INFERRED',
                source='CODE_ANALYSIS'
            )
        ]
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=entry_points,
            grouping_reason='DATA_OWNERSHIP',
            confidence='LOW'
        )
        
        transaction_ids = service.get_transaction_ids()
        
        assert len(transaction_ids) == 0
    
    def test_has_high_confidence_true(self):
        """Test has_high_confidence() returns True for HIGH confidence."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD'
        )
        
        service = ServiceCandidate(
            name='Test Service',
            entry_points=[entry_point],
            grouping_reason='CICS_GROUP',
            confidence='HIGH'
        )
        
        assert service.has_high_confidence() is True
    
    def test_has_high_confidence_false(self):
        """Test has_high_confidence() returns False for non-HIGH confidence."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD'
        )
        
        medium_service = ServiceCandidate(
            name='Medium Service',
            entry_points=[entry_point],
            grouping_reason='DATA_OWNERSHIP',
            confidence='MEDIUM'
        )
        
        low_service = ServiceCandidate(
            name='Low Service',
            entry_points=[entry_point],
            grouping_reason='SHARED_PROGRAMS',
            confidence='LOW'
        )
        
        assert medium_service.has_high_confidence() is False
        assert low_service.has_high_confidence() is False
    
    def test_str_representation(self):
        """Test string representation of service candidate."""
        entry_points = [
            EntryPoint(
                program_name='PROG1',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST1'
            ),
            EntryPoint(
                program_name='PROG2',
                entry_type='ONLINE',
                confidence='EXPLICIT',
                source='CSD',
                transaction_id='TST2'
            ),
            EntryPoint(
                program_name='PROG3',
                entry_type='BATCH',
                confidence='EXPLICIT',
                source='JCL'
            )
        ]
        
        service = ServiceCandidate(
            name='Customer Management Service',
            entry_points=entry_points,
            grouping_reason='CICS_GROUP',
            confidence='HIGH'
        )
        
        result = str(service)
        
        assert 'Customer Management Service' in result
        assert '3 programs' in result
        assert '2 transactions' in result
    
    def test_service_candidate_with_empty_entry_points(self):
        """Test service candidate with empty entry points list."""
        service = ServiceCandidate(
            name='Empty Service',
            entry_points=[],
            grouping_reason='CICS_GROUP',
            confidence='LOW'
        )
        
        assert service.total_programs == 0
        assert service.total_transactions == 0
        assert service.get_program_names() == []
        assert service.get_transaction_ids() == []
    
    def test_service_candidate_grouping_reasons(self):
        """Test different grouping reasons."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD'
        )
        
        cics_group_service = ServiceCandidate(
            name='CICS Group Service',
            entry_points=[entry_point],
            grouping_reason='CICS_GROUP',
            confidence='HIGH'
        )
        
        data_service = ServiceCandidate(
            name='Data Service',
            entry_points=[entry_point],
            grouping_reason='DATA_OWNERSHIP',
            confidence='MEDIUM'
        )
        
        shared_service = ServiceCandidate(
            name='Shared Service',
            entry_points=[entry_point],
            grouping_reason='SHARED_PROGRAMS',
            confidence='LOW'
        )
        
        assert cics_group_service.grouping_reason == 'CICS_GROUP'
        assert data_service.grouping_reason == 'DATA_OWNERSHIP'
        assert shared_service.grouping_reason == 'SHARED_PROGRAMS'
    
    def test_service_candidate_confidence_levels(self):
        """Test different confidence levels."""
        entry_point = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD'
        )
        
        high_service = ServiceCandidate(
            name='High Confidence',
            entry_points=[entry_point],
            grouping_reason='CICS_GROUP',
            confidence='HIGH'
        )
        
        medium_service = ServiceCandidate(
            name='Medium Confidence',
            entry_points=[entry_point],
            grouping_reason='DATA_OWNERSHIP',
            confidence='MEDIUM'
        )
        
        low_service = ServiceCandidate(
            name='Low Confidence',
            entry_points=[entry_point],
            grouping_reason='SHARED_PROGRAMS',
            confidence='LOW'
        )
        
        assert high_service.confidence == 'HIGH'
        assert medium_service.confidence == 'MEDIUM'
        assert low_service.confidence == 'LOW'
        assert high_service.has_high_confidence() is True
        assert medium_service.has_high_confidence() is False
        assert low_service.has_high_confidence() is False
