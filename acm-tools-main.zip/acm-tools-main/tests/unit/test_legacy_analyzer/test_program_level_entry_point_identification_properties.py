"""Property-based tests for program-level entry point identification.

**Feature: program-level-dependency-tracking, Property 9: Program-level entry point identification**
**Validates: Requirements 4.4**

Tests that entry point detection identifies programs that are never called by other programs,
regardless of file structure, operating at program-level granularity.
"""

import pytest
from hypothesis import given, strategies as st, settings, HealthCheck
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from tools.legacy_analyzer.analysis.entry_point_detector import EntryPointDetector
from tools.legacy_analyzer.models.dependency import Dependency, DependencyType
from tools.legacy_analyzer.models.flow import EntryPoint
import sqlite3
import tempfile
import os


# Test data generators
@st.composite
def generate_program_name(draw):
    """Generate valid program names."""
    # Mainframe program names are typically 1-8 characters, alphanumeric
    length = draw(st.integers(min_value=1, max_value=8))
    name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
        min_size=length,
        max_size=length
    ))
    return name if name else "PROG1"  # Fallback for empty names


@st.composite
def generate_program_call_dependency(draw):
    """Generate a program call dependency."""
    source_program = draw(generate_program_name())
    target_program = draw(generate_program_name())
    
    # Ensure source and target are different
    if source_program == target_program:
        target_program = source_program + "X"
    
    dependency_type = draw(st.sampled_from([
        DependencyType.CALL,
        DependencyType.CICS_LINK,
        DependencyType.CICS_START,
        DependencyType.EXEC_PGM
    ]))
    
    return Dependency(
        source_artifact=source_program,
        source_type='PROGRAM',
        target_artifact=target_program,
        target_type='PROGRAM',
        dependency_type=dependency_type,
        line_number=draw(st.integers(min_value=1, max_value=1000))
    )


@st.composite
def generate_non_call_dependency(draw):
    """Generate a non-call dependency (copybook, dataset, etc.)."""
    source_program = draw(generate_program_name())
    
    target_type = draw(st.sampled_from(['COPYBOOK', 'DATASET', 'FILE']))
    target_name = draw(st.text(min_size=1, max_size=8, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))))
    
    # Ensure target name is different from source program name
    if target_name == source_program:
        target_name = target_name + "X"
    
    dependency_type = draw(st.sampled_from([
        DependencyType.COPY,
        DependencyType.DATASET_REF,
        DependencyType.FILE_REF
    ]))
    
    return Dependency(
        source_artifact=source_program,
        source_type='PROGRAM',
        target_artifact=target_name or "TARGET1",
        target_type=target_type,
        dependency_type=dependency_type,
        line_number=draw(st.integers(min_value=1, max_value=1000))
    )


@st.composite
def generate_mixed_dependencies(draw):
    """Generate a mix of call and non-call dependencies."""
    call_deps = draw(st.lists(generate_program_call_dependency(), min_size=0, max_size=10))
    non_call_deps = draw(st.lists(generate_non_call_dependency(), min_size=0, max_size=5))
    
    all_deps = call_deps + non_call_deps
    
    # Ensure we have at least one dependency
    if not all_deps:
        all_deps = [draw(generate_program_call_dependency())]
    
    return all_deps


@pytest.fixture
def temp_db_with_metadata():
    """Create a temporary database with CICS and JCL metadata."""
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create inventory_cics table
    cursor.execute("""
        CREATE TABLE inventory_cics (
            resource_name VARCHAR(8),
            resource_type VARCHAR(20),
            program_name VARCHAR(44),
            group_name VARCHAR(20),
            status VARCHAR(10),
            description TEXT
        )
    """)
    
    # Create artifact_dependencies table for JCL
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            source_artifact_name VARCHAR(44),
            source_artifact_type VARCHAR(20),
            target_artifact_name VARCHAR(44),
            target_artifact_type VARCHAR(20),
            dependency_type VARCHAR(20),
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE program_file_mapping (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT NOT NULL,
            program_name VARCHAR(44) NOT NULL,
            program_index INTEGER NOT NULL,
            start_line INTEGER NOT NULL,
            end_line INTEGER NOT NULL,
            program_type VARCHAR(20) NOT NULL,
            language VARCHAR(20) NOT NULL,
            entry_points TEXT,
            UNIQUE(file_path, program_name)
        )
    """)
    
    conn.commit()
    
    yield conn
    
    conn.close()
    try:
        os.unlink(db_path)
    except OSError:
        pass


class TestProgramLevelEntryPointIdentificationProperties:
    """Property-based tests for program-level entry point identification."""
    
    @given(dependencies=generate_mixed_dependencies())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_entry_points_never_called_by_others(self, dependencies, temp_db_with_metadata):
        """
        **Feature: program-level-dependency-tracking, Property 9: Program-level entry point identification**
        **Validates: Requirements 4.4**
        
        For any set of dependencies, entry points should be programs that are never called 
        by other programs, regardless of file structure.
        """
        # Clean database before each example
        cursor = temp_db_with_metadata.cursor()
        cursor.execute("DELETE FROM inventory_cics")
        cursor.execute("DELETE FROM artifact_dependencies")
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db_with_metadata.commit()
        
        # Create FlowAnalyzer
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db_with_metadata)
        
        # Extract all programs and called programs from dependencies
        all_programs = set()
        called_programs = set()
        
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
                
                # If this is a program call dependency, target is called
                if dep.dependency_type in {
                    DependencyType.CALL, DependencyType.CICS_LINK,
                    DependencyType.CICS_START, DependencyType.EXEC_PGM
                }:
                    called_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Get entry points using code analysis (no metadata)
        entry_points = analyzer.get_entry_points(
            all_programs_in_inventory=all_programs,
            use_metadata=False
        )
        
        # Calculate expected entry points (programs never called by others)
        expected_entry_points = all_programs - called_programs
        
        # Convert to sets for comparison
        entry_points_set = set(entry_points)
        
        # Property: All identified entry points should never be called by other programs
        for entry_point in entry_points_set:
            assert entry_point not in called_programs, \
                f"Entry point {entry_point} should not be called by other programs"
            assert entry_point in all_programs, \
                f"Entry point {entry_point} should be a valid program in the system"
        
        # Property: All programs that are never called should be identified as entry points
        for program in expected_entry_points:
            assert program in entry_points_set, \
                f"Program {program} is never called by others, so should be an entry point"
        
        # Property: Entry points set should exactly match expected entry points
        assert entry_points_set == expected_entry_points, \
            f"Entry points {entry_points_set} should match expected {expected_entry_points}"
    
    @given(dependencies=generate_mixed_dependencies())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_entry_points_with_metadata_integration(self, dependencies, temp_db_with_metadata):
        """
        **Feature: program-level-dependency-tracking, Property 9: Program-level entry point identification**
        **Validates: Requirements 4.4**
        
        For any set of dependencies, when metadata is available, entry point detection
        should integrate CICS transactions and JCL jobs with code analysis results.
        """
        # Clean database before each example
        cursor = temp_db_with_metadata.cursor()
        cursor.execute("DELETE FROM inventory_cics")
        cursor.execute("DELETE FROM artifact_dependencies")
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db_with_metadata.commit()
        
        # Extract programs from dependencies
        all_programs = set()
        called_programs = set()
        
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
                if dep.dependency_type in {
                    DependencyType.CALL, DependencyType.CICS_LINK,
                    DependencyType.CICS_START, DependencyType.EXEC_PGM
                }:
                    called_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Add some CICS transactions for a subset of programs
        program_list = list(all_programs)
        cics_programs = program_list[:min(3, len(program_list))]
        
        for i, program in enumerate(cics_programs):
            cursor.execute("""
                INSERT INTO inventory_cics 
                (resource_name, resource_type, program_name, group_name, status, description)
                VALUES (?, 'TRANSACTION', ?, 'GROUP1', 'ENABLED', 'Test transaction')
            """, (f"TXN{i}", program))
        
        # Add some JCL jobs for a subset of programs
        jcl_programs = program_list[min(3, len(program_list)):min(6, len(program_list))]
        
        for i, program in enumerate(jcl_programs):
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'JCL', ?, 'PROGRAM', 'EXEC_PGM')
            """, (f"JOB{i}", program))
        
        temp_db_with_metadata.commit()
        
        # Create FlowAnalyzer with metadata support
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db_with_metadata)
        
        # Get entry points with metadata
        entry_points_with_metadata = analyzer.get_entry_points_with_metadata(
            all_programs_in_inventory=all_programs
        )
        
        # Verify entry points are EntryPoint objects
        assert all(isinstance(ep, EntryPoint) for ep in entry_points_with_metadata)
        
        # Property: CICS transaction programs should be identified as ONLINE entry points
        cics_entry_points = [ep for ep in entry_points_with_metadata if ep.entry_type == 'ONLINE']
        cics_program_names = {ep.program_name for ep in cics_entry_points}
        
        for cics_program in cics_programs:
            assert cics_program in cics_program_names, \
                f"CICS program {cics_program} should be identified as ONLINE entry point"
        
        # Property: JCL job programs should be identified as BATCH entry points
        batch_entry_points = [ep for ep in entry_points_with_metadata if ep.entry_type == 'BATCH']
        batch_program_names = {ep.program_name for ep in batch_entry_points}
        
        for jcl_program in jcl_programs:
            assert jcl_program in batch_program_names, \
                f"JCL program {jcl_program} should be identified as BATCH entry point"
        
        # Property: Programs with explicit metadata should have EXPLICIT confidence
        explicit_entry_points = [ep for ep in entry_points_with_metadata if ep.confidence == 'EXPLICIT']
        explicit_program_names = {ep.program_name for ep in explicit_entry_points}
        
        for cics_program in cics_programs:
            assert cics_program in explicit_program_names, \
                f"CICS program {cics_program} should have EXPLICIT confidence"
        
        for jcl_program in jcl_programs:
            assert jcl_program in explicit_program_names, \
                f"JCL program {jcl_program} should have EXPLICIT confidence"
        
        # Property: Programs without metadata but never called should be INFERRED entry points
        metadata_programs = set(cics_programs + jcl_programs)
        inferred_candidates = (all_programs - called_programs) - metadata_programs
        
        inferred_entry_points = [ep for ep in entry_points_with_metadata if ep.confidence == 'INFERRED']
        inferred_program_names = {ep.program_name for ep in inferred_entry_points}
        
        for inferred_program in inferred_candidates:
            assert inferred_program in inferred_program_names, \
                f"Program {inferred_program} should be identified as INFERRED entry point"
    
    @given(dependencies=generate_mixed_dependencies())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_entry_points_ignore_non_call_dependencies(self, dependencies, temp_db_with_metadata):
        """
        **Feature: program-level-dependency-tracking, Property 9: Program-level entry point identification**
        **Validates: Requirements 4.4**
        
        For any set of dependencies, entry point identification should only consider
        program call dependencies and ignore copybook, dataset, and other non-call dependencies.
        """
        # Clean database before each example
        cursor = temp_db_with_metadata.cursor()
        cursor.execute("DELETE FROM inventory_cics")
        cursor.execute("DELETE FROM artifact_dependencies")
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db_with_metadata.commit()
        
        # Separate call and non-call dependencies
        call_dependencies = []
        non_call_dependencies = []
        
        for dep in dependencies:
            if dep.dependency_type in {
                DependencyType.CALL, DependencyType.CICS_LINK,
                DependencyType.CICS_START, DependencyType.EXEC_PGM
            }:
                call_dependencies.append(dep)
            else:
                non_call_dependencies.append(dep)
        
        # Extract programs from all dependencies
        all_programs = set()
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Extract called programs from ONLY call dependencies
        called_programs_from_calls = set()
        for dep in call_dependencies:
            if (dep.target_type == 'PROGRAM' and 
                dep.dependency_type in {
                    DependencyType.CALL, DependencyType.CICS_LINK,
                    DependencyType.CICS_START, DependencyType.EXEC_PGM
                }):
                called_programs_from_calls.add(dep.target_artifact)
        
        # Create FlowAnalyzer with all dependencies (including non-call)
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db_with_metadata)
        
        # Get entry points
        entry_points = analyzer.get_entry_points(
            all_programs_in_inventory=all_programs,
            use_metadata=False
        )
        
        entry_points_set = set(entry_points)
        
        # Property: Entry points should be based only on call dependencies
        expected_entry_points = all_programs - called_programs_from_calls
        
        assert entry_points_set == expected_entry_points, \
            f"Entry points should ignore non-call dependencies. " \
            f"Expected: {expected_entry_points}, Got: {entry_points_set}"
        
        # Property: Programs that are targets of non-call dependencies should still be entry points
        # if they are not called by program call dependencies
        for dep in non_call_dependencies:
            if (dep.target_type == 'PROGRAM' and 
                dep.target_artifact not in called_programs_from_calls):
                assert dep.target_artifact in entry_points_set, \
                    f"Program {dep.target_artifact} is target of non-call dependency " \
                    f"but not called by programs, so should be entry point"
    
    @given(dependencies=generate_mixed_dependencies())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_entry_points_consistent_across_methods(self, dependencies, temp_db_with_metadata):
        """
        **Feature: program-level-dependency-tracking, Property 9: Program-level entry point identification**
        **Validates: Requirements 4.4**
        
        For any set of dependencies, entry point identification should be consistent
        between get_entry_points() and get_entry_points_with_metadata() when no metadata exists.
        """
        # Clean database before each example
        cursor = temp_db_with_metadata.cursor()
        cursor.execute("DELETE FROM inventory_cics")
        cursor.execute("DELETE FROM artifact_dependencies")
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db_with_metadata.commit()
        
        # Extract all programs
        all_programs = set()
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Create FlowAnalyzer
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db_with_metadata)
        
        # Get entry points using both methods (no metadata in database)
        entry_points_simple = analyzer.get_entry_points(
            all_programs_in_inventory=all_programs,
            use_metadata=False
        )
        
        entry_points_with_metadata = analyzer.get_entry_points_with_metadata(
            all_programs_in_inventory=all_programs
        )
        
        # Extract program names from metadata objects
        entry_points_from_metadata = [ep.program_name for ep in entry_points_with_metadata]
        
        # Property: Both methods should identify the same entry points when no metadata exists
        entry_points_simple_set = set(entry_points_simple)
        entry_points_metadata_set = set(entry_points_from_metadata)
        
        assert entry_points_simple_set == entry_points_metadata_set, \
            f"Entry point methods should be consistent when no metadata exists. " \
            f"Simple: {entry_points_simple_set}, Metadata: {entry_points_metadata_set}"
        
        # Property: All entry points from metadata method should have INFERRED confidence
        # when no explicit metadata exists
        for ep in entry_points_with_metadata:
            assert ep.confidence == 'INFERRED', \
                f"Entry point {ep.program_name} should have INFERRED confidence when no metadata"
            assert ep.entry_type == 'INFERRED', \
                f"Entry point {ep.program_name} should have INFERRED type when no metadata"
            assert ep.source == 'CODE_ANALYSIS', \
                f"Entry point {ep.program_name} should have CODE_ANALYSIS source when no metadata"