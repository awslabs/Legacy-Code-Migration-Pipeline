"""
Property-Based Tests for JobExporter.

This module contains property-based tests using Hypothesis to verify
universal correctness properties of the JCL job export functionality.

Feature: jcl-job-export
"""

import pytest
import sqlite3
import tempfile
import os
from hypothesis import given, settings, strategies as st, HealthCheck
from tools.legacy_analyzer.migration.job_exporter import JobExporter
from tools.legacy_analyzer.migration.exceptions import ExportError


# Test data strategies
@st.composite
def job_name_strategy(draw):
    """Generate valid JCL job names (1-8 uppercase alphanumeric characters)."""
    length = draw(st.integers(min_value=1, max_value=8))
    return ''.join(draw(st.lists(
        st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'),
        min_size=length,
        max_size=length
    )))


@st.composite
def job_list_strategy(draw):
    """Generate a list of unique job names."""
    num_jobs = draw(st.integers(min_value=0, max_value=50))
    job_names = set()
    
    while len(job_names) < num_jobs:
        job_name = draw(job_name_strategy())
        job_names.add(job_name)
    
    return list(job_names)


@pytest.fixture
def temp_db():
    """Create a temporary database file."""
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    # Create basic schema
    conn = sqlite3.connect(path)
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE inventory_jcl (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_name VARCHAR(8) NOT NULL,
            library_name VARCHAR(44) NOT NULL,
            last_modified DATE,
            size_lines INTEGER,
            datasets TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            source_artifact_name TEXT,
            source_artifact_type TEXT,
            target_artifact_name TEXT,
            target_artifact_type TEXT,
            dependency_type TEXT
        )
    """)
    
    cursor.execute("""
        CREATE TABLE inventory (
            name TEXT PRIMARY KEY,
            type TEXT,
            is_entry_point BOOLEAN
        )
    """)
    
    conn.commit()
    conn.close()
    
    yield path
    
    # Cleanup
    if os.path.exists(path):
        os.unlink(path)


def populate_db_with_jobs(db_path: str, job_names: list):
    """Populate database with test jobs."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    for job_name in job_names:
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, (job_name, 'JCL', 100))
    
    conn.commit()
    conn.close()


# Property 1: Export Completeness
# Feature: jcl-job-export, Property 1: Export Completeness
# Validates: Requirements 1.1, 3.1
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large
    ]
)
@given(job_names=job_list_strategy())
def test_property_export_completeness(job_names):
    """
    Property 1: Export Completeness
    
    For any database containing N jobs, querying those jobs should return
    exactly N job entries.
    
    This property verifies that:
    - All jobs in the database are retrieved
    - No duplicate jobs are returned
    - The count matches exactly
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Populate database with jobs
        populate_db_with_jobs(db_path, job_names)
        
        # Create exporter and query jobs
        with JobExporter(db_path) as exporter:
            jobs = exporter._query_jobs()
        
        # Verify completeness
        assert len(jobs) == len(job_names), \
            f"Expected {len(job_names)} jobs, got {len(jobs)}"
        
        # Verify all job names are present
        returned_names = {job['jobName'] for job in jobs}
        expected_names = set(job_names)
        
        assert returned_names == expected_names, \
            f"Job names mismatch. Missing: {expected_names - returned_names}, " \
            f"Extra: {returned_names - expected_names}"
        
        # Verify no duplicates
        assert len(returned_names) == len(jobs), \
            "Duplicate jobs found in export"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Additional basic property tests for database connection
def test_database_connection_success(temp_db):
    """Test that JobExporter successfully connects to valid database."""
    with JobExporter(temp_db) as exporter:
        assert exporter.db is not None
        assert exporter.cursor is not None
        assert exporter.db_path == temp_db


def test_database_connection_failure():
    """Test that JobExporter raises ExportError for invalid database."""
    with pytest.raises(ExportError) as exc_info:
        JobExporter('/nonexistent/path/to/database.db')
    
    assert 'database' in str(exc_info.value).lower() or 'not found' in str(exc_info.value).lower(), \
        "Error message should mention database or not found"
    assert exc_info.value.operation == 'connect', \
        "Error should indicate connection operation"


def test_context_manager_closes_connection(temp_db):
    """Test that context manager properly closes database connection."""
    exporter = JobExporter(temp_db)
    
    with exporter:
        assert exporter.db is not None
    
    # After context exit, connection should be closed
    # Attempting to use cursor should raise an error
    with pytest.raises(sqlite3.ProgrammingError):
        exporter.cursor.execute("SELECT 1")


def test_query_jobs_empty_database(temp_db):
    """Test querying jobs from empty database returns empty list."""
    with JobExporter(temp_db) as exporter:
        jobs = exporter._query_jobs()
    
    assert jobs == []
    assert isinstance(jobs, list)


def test_query_jobs_returns_correct_structure(temp_db):
    """Test that queried jobs have correct structure."""
    # Add a single job
    populate_db_with_jobs(temp_db, ['TESTJOB1'])
    
    with JobExporter(temp_db) as exporter:
        jobs = exporter._query_jobs()
    
    assert len(jobs) == 1
    job = jobs[0]
    
    # Verify required fields
    assert 'jobName' in job
    assert 'library' in job
    assert 'lastModified' in job
    assert 'sizeLines' in job
    
    # Verify values
    assert job['jobName'] == 'TESTJOB1'
    assert job['library'] == 'JCL'
    assert job['sizeLines'] == 100


def test_query_job_steps_empty_dependencies(temp_db):
    """Test querying steps for job with no dependencies."""
    # Add a job with no dependencies
    populate_db_with_jobs(temp_db, ['TESTJOB1'])
    
    with JobExporter(temp_db) as exporter:
        steps = exporter._query_job_steps('TESTJOB1')
    
    assert steps == []
    assert isinstance(steps, list)


def test_query_job_steps_with_dependencies(temp_db):
    """Test querying steps for job with program dependencies."""
    # Add a job
    populate_db_with_jobs(temp_db, ['TESTJOB1'])
    
    # Add dependencies
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.executemany("""
        INSERT INTO artifact_dependencies 
        (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
        VALUES (?, ?, ?, ?, ?)
    """, [
        ('TESTJOB1', 'JCL', 'PROG1', 'COBOL', 'INVOKES'),
        ('TESTJOB1', 'JCL', 'PROG2', 'COBOL', 'INVOKES'),
    ])
    
    conn.commit()
    conn.close()
    
    with JobExporter(temp_db) as exporter:
        steps = exporter._query_job_steps('TESTJOB1')
    
    assert len(steps) == 2
    
    # Verify step structure
    for step in steps:
        assert 'stepName' in step
        assert 'program' in step
        assert 'type' in step
        assert 'purpose' in step
        assert 'flowEntry' in step
    
    # Verify programs
    programs = {step['program'] for step in steps}
    assert programs == {'PROG1', 'PROG2'}


def test_query_job_steps_nonexistent_job(temp_db):
    """Test querying steps for non-existent job returns empty list."""
    with JobExporter(temp_db) as exporter:
        steps = exporter._query_job_steps('NONEXISTENT')
    
    assert steps == []


# Property 2: Job Categorization Consistency
# Feature: jcl-job-export, Property 2: Job Categorization Consistency
# Validates: Requirements 2.1, 2.2, 2.3
@st.composite
def step_strategy(draw):
    """Generate a step with either a utility or custom program."""
    # Choose between utility and custom program
    is_utility = draw(st.booleans())
    
    if is_utility:
        # Pick a known utility program
        utilities = ['IEFBR14', 'IDCAMS', 'IEBGENER', 'SORT', 'DFSORT', 'IKJEFT01']
        program = draw(st.sampled_from(utilities))
    else:
        # Generate a custom program name (not in utility list)
        program = draw(st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
            min_size=1,
            max_size=8
        ).filter(lambda x: x.upper() not in [
            'IEFBR14', 'IDCAMS', 'IEBGENER', 'SORT', 'DFSORT', 'IKJEFT01',
            'IEBCOPY', 'IEBPTPCH', 'SYNCSORT', 'DSNTEP2', 'FTP', 'IKJEFT1A'
        ]))
    
    return {
        'stepName': f'STEP{draw(st.integers(min_value=1, max_value=99)):02d}',
        'program': program,
        'type': 'UNKNOWN',
        'purpose': f'Execute {program}',
        'flowEntry': False
    }


@st.composite
def steps_list_strategy(draw):
    """Generate a list of steps (can be empty)."""
    return draw(st.lists(step_strategy(), min_size=0, max_size=10))


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(steps=steps_list_strategy())
def test_property_job_categorization_consistency(steps):
    """
    Property 2: Job Categorization Consistency
    
    For any job, if it contains at least one step invoking a custom program,
    then jobType should be "APPLICATION" and hasCustomCode should be true;
    otherwise jobType should be "INFRASTRUCTURE" and hasCustomCode should be false.
    
    This property verifies that:
    - Jobs with custom programs are categorized as APPLICATION
    - Jobs with only utilities are categorized as INFRASTRUCTURE
    - Jobs with no steps are categorized as INFRASTRUCTURE
    - hasCustomCode flag matches the job type
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Create exporter
        with JobExporter(db_path) as exporter:
            # Categorize the job
            job_type, has_custom_code = exporter._categorize_job(steps)
            
            # Determine if any step has a custom program
            has_custom_program = False
            for step in steps:
                program = step.get('program', '')
                if not exporter._is_utility_program(program):
                    has_custom_program = True
                    break
            
            # Verify consistency
            if has_custom_program:
                # Job should be APPLICATION with hasCustomCode=True
                assert job_type == 'APPLICATION', \
                    f"Job with custom program should be APPLICATION, got {job_type}"
                assert has_custom_code is True, \
                    f"Job with custom program should have hasCustomCode=True, got {has_custom_code}"
            else:
                # Job should be INFRASTRUCTURE with hasCustomCode=False
                assert job_type == 'INFRASTRUCTURE', \
                    f"Job with only utilities should be INFRASTRUCTURE, got {job_type}"
                assert has_custom_code is False, \
                    f"Job with only utilities should have hasCustomCode=False, got {has_custom_code}"
            
            # Verify consistency between job_type and has_custom_code
            if job_type == 'APPLICATION':
                assert has_custom_code is True, \
                    "APPLICATION jobs must have hasCustomCode=True"
            elif job_type == 'INFRASTRUCTURE':
                assert has_custom_code is False, \
                    "INFRASTRUCTURE jobs must have hasCustomCode=False"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 3: Step Type Assignment
# Feature: jcl-job-export, Property 3: Step Type Assignment
# Validates: Requirements 3.3, 3.4
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(steps=steps_list_strategy())
def test_property_step_type_assignment(steps):
    """
    Property 3: Step Type Assignment
    
    For any step in a job, if the step invokes a custom program then type
    should be "CUSTOM", and if it invokes a utility program then type should
    be "UTILITY".
    
    This property verifies that:
    - Utility programs are marked with type="UTILITY"
    - Custom programs are marked with type="CUSTOM"
    - All steps have a valid type assignment
    - Type assignment is consistent with program classification
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        # Populate inventory with custom programs
        # (programs that are not utilities)
        custom_programs = set()
        for step in steps:
            program = step.get('program', '')
            if program:
                # Check if it's a utility
                is_utility = program.upper() in [
                    'IEFBR14', 'IDCAMS', 'IEBGENER', 'SORT', 'DFSORT', 'IKJEFT01',
                    'IEBCOPY', 'IEBPTPCH', 'SYNCSORT', 'DSNTEP2', 'FTP', 'IKJEFT1A'
                ]
                
                if not is_utility:
                    custom_programs.add(program)
        
        # Insert custom programs into inventory
        for program in custom_programs:
            cursor.execute("""
                INSERT INTO inventory (name, type, is_entry_point)
                VALUES (?, ?, ?)
            """, (program, 'COBOL', False))
        
        conn.commit()
        conn.close()
        
        # Create exporter and assign step types
        with JobExporter(db_path) as exporter:
            # Assign types to steps
            typed_steps = exporter._assign_step_types(steps.copy())
            
            # Verify type assignment for each step
            for step in typed_steps:
                program = step.get('program', '')
                step_type = step.get('type', '')
                
                # Verify type is either CUSTOM or UTILITY
                assert step_type in ['CUSTOM', 'UTILITY'], \
                    f"Step type must be CUSTOM or UTILITY, got {step_type}"
                
                # Verify consistency with program classification
                if exporter._is_utility_program(program):
                    assert step_type == 'UTILITY', \
                        f"Utility program {program} should have type=UTILITY, got {step_type}"
                else:
                    # Non-utility programs should be CUSTOM
                    # (either in inventory or not recognized as utility)
                    assert step_type == 'CUSTOM', \
                        f"Custom program {program} should have type=CUSTOM, got {step_type}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 4: Step Data Completeness
# Feature: jcl-job-export, Property 4: Step Data Completeness
# Validates: Requirements 3.2
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(steps=steps_list_strategy())
def test_property_step_data_completeness(steps):
    """
    Property 4: Step Data Completeness
    
    For any step in an exported job, the step object should contain
    stepName, program, type, purpose, and flowEntry fields.
    
    This property verifies that:
    - All required fields are present in each step
    - No required fields are missing or null
    - Field types are correct (strings for names, boolean for flowEntry)
    - All steps have complete data structure
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Create exporter and assign step types
        with JobExporter(db_path) as exporter:
            # Assign types to steps (this should ensure all fields are present)
            typed_steps = exporter._assign_step_types(steps.copy())
            
            # Verify completeness for each step
            for step in typed_steps:
                # Verify all required fields are present
                required_fields = ['stepName', 'program', 'type', 'purpose', 'flowEntry']
                
                for field in required_fields:
                    assert field in step, \
                        f"Step missing required field: {field}. Step: {step}"
                
                # Verify field values are not None
                assert step['stepName'] is not None, \
                    "stepName should not be None"
                assert step['program'] is not None, \
                    "program should not be None"
                assert step['type'] is not None, \
                    "type should not be None"
                assert step['purpose'] is not None, \
                    "purpose should not be None"
                assert step['flowEntry'] is not None, \
                    "flowEntry should not be None"
                
                # Verify field types
                assert isinstance(step['stepName'], str), \
                    f"stepName should be string, got {type(step['stepName'])}"
                assert isinstance(step['program'], str), \
                    f"program should be string, got {type(step['program'])}"
                assert isinstance(step['type'], str), \
                    f"type should be string, got {type(step['type'])}"
                assert isinstance(step['purpose'], str), \
                    f"purpose should be string, got {type(step['purpose'])}"
                assert isinstance(step['flowEntry'], bool), \
                    f"flowEntry should be boolean, got {type(step['flowEntry'])}"
                
                # Verify string fields are not empty
                assert len(step['stepName']) > 0, \
                    "stepName should not be empty"
                assert len(step['program']) > 0, \
                    "program should not be empty"
                assert len(step['type']) > 0, \
                    "type should not be empty"
                assert len(step['purpose']) > 0, \
                    "purpose should not be empty"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)



# Property 6: Job-to-Flow Linking
# Feature: jcl-job-export, Property 6: Job-to-Flow Linking
# Validates: Requirements 4.1, 4.2, 4.4
@st.composite
def step_with_entry_point_strategy(draw):
    """Generate a step that may or may not be a flow entry point."""
    is_entry_point = draw(st.booleans())
    
    # Generate program name using only ASCII uppercase letters and digits
    # This matches mainframe naming conventions
    program = draw(st.text(
        alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
        min_size=1,
        max_size=8
    ).filter(lambda x: x.upper() not in [
        'IEFBR14', 'IDCAMS', 'IEBGENER', 'SORT', 'DFSORT', 'IKJEFT01',
        'IEBCOPY', 'IEBPTPCH', 'SYNCSORT', 'DSNTEP2', 'FTP', 'IKJEFT1A'
    ]))
    
    return {
        'stepName': f'STEP{draw(st.integers(min_value=1, max_value=99)):02d}',
        'program': program,
        'type': 'CUSTOM',
        'purpose': f'Execute {program}',
        'flowEntry': is_entry_point
    }


@st.composite
def steps_with_entry_points_strategy(draw):
    """Generate a list of steps with potential entry points."""
    return draw(st.lists(step_with_entry_point_strategy(), min_size=0, max_size=10))


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(steps=steps_with_entry_points_strategy())
def test_property_job_to_flow_linking(steps):
    """
    Property 6: Job-to-Flow Linking
    
    For any job, if it contains at least one step that is a flow entry point,
    then linkedFlow should be set to "FLOW_{program_name}" where program_name
    is the entry point program; otherwise linkedFlow should be null.
    
    This property verifies that:
    - Jobs with entry point steps are linked to flows
    - Jobs without entry points have linkedFlow=None
    - Flow names follow the FLOW_{program} convention
    - Only the first entry point is used when multiple exist
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Populate inventory and flows for entry point programs
        entry_point_programs = []
        for step in steps:
            if step.get('flowEntry', False):
                program = step.get('program', '')
                if program and program not in entry_point_programs:
                    entry_point_programs.append(program)
                    
                    # Add to inventory as entry point
                    cursor.execute("""
                        INSERT OR IGNORE INTO inventory (name, type, is_entry_point)
                        VALUES (?, ?, ?)
                    """, (program, 'COBOL', True))
                    
                    # Add corresponding flow
                    flow_id = f'FLOW_{program}'
                    cursor.execute("""
                        INSERT OR IGNORE INTO migration_flows (flow_id, entry_point)
                        VALUES (?, ?)
                    """, (flow_id, program))
        
        conn.commit()
        conn.close()
        
        # Create exporter and link to flow
        with JobExporter(db_path) as exporter:
            linked_flow = exporter._link_to_flow(steps)
            
            # Find the first entry point in steps
            first_entry_point = None
            for step in steps:
                if step.get('flowEntry', False):
                    first_entry_point = step.get('program')
                    break
            
            # Verify linking behavior
            if first_entry_point:
                # Job should be linked to flow
                expected_flow = f'FLOW_{first_entry_point}'
                assert linked_flow == expected_flow, \
                    f"Job with entry point {first_entry_point} should link to {expected_flow}, got {linked_flow}"
                
                # Verify flow name convention
                assert linked_flow.startswith('FLOW_'), \
                    f"Flow name should start with 'FLOW_', got {linked_flow}"
            else:
                # Job should not be linked to any flow
                assert linked_flow is None, \
                    f"Job without entry points should have linkedFlow=None, got {linked_flow}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 7: Flow Naming Convention
# Feature: jcl-job-export, Property 7: Flow Naming Convention
# Validates: Requirements 4.4
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(steps=steps_with_entry_points_strategy())
def test_property_flow_naming_convention(steps):
    """
    Property 7: Flow Naming Convention
    
    For any job with a non-null linkedFlow value, the linkedFlow string
    should match the pattern "FLOW_" followed by a valid program name.
    
    This property verifies that:
    - All flow names start with "FLOW_" prefix
    - Flow names contain a valid program identifier after the prefix
    - Flow naming is consistent across all jobs
    - No invalid flow name formats are generated
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Populate inventory and flows for entry point programs
        entry_point_programs = []
        for step in steps:
            if step.get('flowEntry', False):
                program = step.get('program', '')
                if program and program not in entry_point_programs:
                    entry_point_programs.append(program)
                    
                    # Add to inventory as entry point
                    cursor.execute("""
                        INSERT OR IGNORE INTO inventory (name, type, is_entry_point)
                        VALUES (?, ?, ?)
                    """, (program, 'COBOL', True))
                    
                    # Add corresponding flow
                    flow_id = f'FLOW_{program}'
                    cursor.execute("""
                        INSERT OR IGNORE INTO migration_flows (flow_id, entry_point)
                        VALUES (?, ?)
                    """, (flow_id, program))
        
        conn.commit()
        conn.close()
        
        # Create exporter and link to flow
        with JobExporter(db_path) as exporter:
            linked_flow = exporter._link_to_flow(steps)
            
            # If flow is linked, verify naming convention
            if linked_flow is not None:
                # Verify flow name starts with "FLOW_"
                assert linked_flow.startswith('FLOW_'), \
                    f"Flow name must start with 'FLOW_', got {linked_flow}"
                
                # Verify there's a program name after the prefix
                program_part = linked_flow[5:]  # Remove "FLOW_" prefix
                assert len(program_part) > 0, \
                    f"Flow name must have program name after 'FLOW_', got {linked_flow}"
                
                # Verify the program part matches one of the entry point programs
                assert program_part in entry_point_programs, \
                    f"Flow program {program_part} should be one of the entry points: {entry_point_programs}"
                
                # Verify the flow name matches the expected format
                import re
                pattern = r'^FLOW_[A-Z0-9]+$'
                assert re.match(pattern, linked_flow), \
                    f"Flow name should match pattern FLOW_[A-Z0-9]+, got {linked_flow}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 10: Dependency Inference from Datasets
# Feature: jcl-job-export, Property 10: Dependency Inference from Datasets
# Validates: Requirements 5.1, 5.3
@st.composite
def dataset_access_strategy(draw):
    """Generate dataset access information (read or write)."""
    dataset_name = draw(st.text(
        alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.',
        min_size=5,
        max_size=44
    ))
    access_type = draw(st.sampled_from(['READ', 'WRITE']))
    
    return {
        'dataset': dataset_name,
        'access': access_type
    }


@st.composite
def job_with_datasets_strategy(draw):
    """Generate a job with dataset access information."""
    job_name = draw(job_name_strategy())
    datasets = draw(st.lists(dataset_access_strategy(), min_size=0, max_size=5))
    
    return {
        'jobName': job_name,
        'datasets': datasets
    }


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(jobs=st.lists(job_with_datasets_strategy(), min_size=2, max_size=10))
def test_property_dependency_inference_from_datasets(jobs):
    """
    Property 10: Dependency Inference from Datasets
    
    For any pair of jobs where job A writes a dataset and job B reads the same
    dataset, job A should appear in job B's mustRunAfter array, and job B should
    appear in job A's mustRunBefore array.
    
    This property verifies that:
    - Write-then-read patterns create correct dependencies
    - Dependencies are bidirectional (mustRunAfter and mustRunBefore)
    - Dataset names are matched correctly
    - Multiple dataset dependencies are handled correctly
    
    Note: The current database schema does not store dataset access information,
    so this test verifies the structure and logic of the dependency extraction
    method, even though it currently returns empty dependencies.
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        # Populate database with jobs
        job_names = [job['jobName'] for job in jobs]
        for job_name in job_names:
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, (job_name, 'JCL', 100))
        
        conn.commit()
        conn.close()
        
        # Create exporter and extract dependencies
        with JobExporter(db_path) as exporter:
            # Test dependency extraction for each job
            for job in jobs:
                job_name = job['jobName']
                
                # Extract dependencies
                dependencies = exporter._extract_dependencies(job_name, job_names)
                
                # Verify structure
                assert 'mustRunAfter' in dependencies, \
                    "Dependencies must contain mustRunAfter array"
                assert 'mustRunBefore' in dependencies, \
                    "Dependencies must contain mustRunBefore array"
                
                # Verify types
                assert isinstance(dependencies['mustRunAfter'], list), \
                    "mustRunAfter must be a list"
                assert isinstance(dependencies['mustRunBefore'], list), \
                    "mustRunBefore must be a list"
                
                # Verify no self-dependencies
                assert job_name not in dependencies['mustRunAfter'], \
                    f"Job {job_name} should not depend on itself (mustRunAfter)"
                assert job_name not in dependencies['mustRunBefore'], \
                    f"Job {job_name} should not depend on itself (mustRunBefore)"
                
                # Verify all dependencies are valid job names
                for dep in dependencies['mustRunAfter']:
                    assert dep in job_names, \
                        f"Dependency {dep} should be a valid job name"
                
                for dep in dependencies['mustRunBefore']:
                    assert dep in job_names, \
                        f"Dependency {dep} should be a valid job name"
                
                # Verify no duplicates
                assert len(dependencies['mustRunAfter']) == len(set(dependencies['mustRunAfter'])), \
                    "mustRunAfter should not contain duplicates"
                assert len(dependencies['mustRunBefore']) == len(set(dependencies['mustRunBefore'])), \
                    "mustRunBefore should not contain duplicates"
                
                # Verify sorted order (for consistency)
                assert dependencies['mustRunAfter'] == sorted(dependencies['mustRunAfter']), \
                    "mustRunAfter should be sorted alphabetically"
                assert dependencies['mustRunBefore'] == sorted(dependencies['mustRunBefore']), \
                    "mustRunBefore should be sorted alphabetically"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)



# Property 11: Dependency Object Presence
# Feature: jcl-job-export, Property 11: Dependency Object Presence
# Validates: Requirements 5.5
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large
    ]
)
@given(job_names=job_list_strategy())
def test_property_dependency_object_presence(job_names):
    """
    Property 11: Dependency Object Presence
    
    For any exported job, the dependencies object should contain both
    mustRunAfter and mustRunBefore arrays (even if empty).
    
    This property verifies that:
    - All jobs have a dependencies object
    - The dependencies object always contains mustRunAfter array
    - The dependencies object always contains mustRunBefore array
    - Arrays are never null or undefined (can be empty)
    - Arrays contain only strings (job names)
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        # Populate database with jobs
        for job_name in job_names:
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, (job_name, 'JCL', 100))
        
        conn.commit()
        conn.close()
        
        # Create exporter and extract dependencies for each job
        with JobExporter(db_path) as exporter:
            for job_name in job_names:
                # Extract dependencies
                dependencies = exporter._extract_dependencies(job_name, job_names)
                
                # Verify dependencies is a dictionary
                assert isinstance(dependencies, dict), \
                    f"Dependencies for job {job_name} should be a dictionary, got {type(dependencies)}"
                
                # Verify required keys are present
                assert 'mustRunAfter' in dependencies, \
                    f"Dependencies for job {job_name} must contain 'mustRunAfter' key"
                assert 'mustRunBefore' in dependencies, \
                    f"Dependencies for job {job_name} must contain 'mustRunBefore' key"
                
                # Verify values are lists (not None or other types)
                assert isinstance(dependencies['mustRunAfter'], list), \
                    f"mustRunAfter for job {job_name} must be a list, got {type(dependencies['mustRunAfter'])}"
                assert isinstance(dependencies['mustRunBefore'], list), \
                    f"mustRunBefore for job {job_name} must be a list, got {type(dependencies['mustRunBefore'])}"
                
                # Verify values are not None
                assert dependencies['mustRunAfter'] is not None, \
                    f"mustRunAfter for job {job_name} should not be None"
                assert dependencies['mustRunBefore'] is not None, \
                    f"mustRunBefore for job {job_name} should not be None"
                
                # Verify all elements in arrays are strings
                for dep in dependencies['mustRunAfter']:
                    assert isinstance(dep, str), \
                        f"All elements in mustRunAfter should be strings, got {type(dep)}"
                    assert len(dep) > 0, \
                        f"Job names in mustRunAfter should not be empty strings"
                
                for dep in dependencies['mustRunBefore']:
                    assert isinstance(dep, str), \
                        f"All elements in mustRunBefore should be strings, got {type(dep)}"
                    assert len(dep) > 0, \
                        f"Job names in mustRunBefore should not be empty strings"
                
                # Verify no None values in arrays
                assert None not in dependencies['mustRunAfter'], \
                    f"mustRunAfter should not contain None values"
                assert None not in dependencies['mustRunBefore'], \
                    f"mustRunBefore should not contain None values"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)



# Property 8: Dataset Deduplication
# Feature: jcl-job-export, Property 8: Dataset Deduplication
# Validates: Requirements 6.2, 6.4
@st.composite
def dataset_name_strategy(draw):
    """Generate valid mainframe dataset names."""
    # Mainframe dataset names: up to 44 characters, segments separated by dots
    # Each segment: 1-8 alphanumeric characters, starting with letter
    num_segments = draw(st.integers(min_value=1, max_value=5))
    segments = []
    
    for _ in range(num_segments):
        # First character must be a letter
        first_char = draw(st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ'))
        # Remaining characters can be alphanumeric
        remaining_length = draw(st.integers(min_value=0, max_value=7))
        remaining_chars = ''.join(draw(st.lists(
            st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'),
            min_size=remaining_length,
            max_size=remaining_length
        )))
        segments.append(first_char + remaining_chars)
    
    return '.'.join(segments)


@st.composite
def datasets_with_duplicates_strategy(draw):
    """Generate a list of datasets that may contain duplicates."""
    # Generate base dataset names
    num_unique = draw(st.integers(min_value=1, max_value=10))
    unique_datasets = [draw(dataset_name_strategy()) for _ in range(num_unique)]
    
    # Add some duplicates
    num_duplicates = draw(st.integers(min_value=0, max_value=5))
    datasets_with_dups = unique_datasets.copy()
    
    for _ in range(num_duplicates):
        if unique_datasets:
            duplicate = draw(st.sampled_from(unique_datasets))
            datasets_with_dups.append(duplicate)
    
    # Shuffle the list using Hypothesis's permutations
    shuffled = draw(st.permutations(datasets_with_dups))
    
    return list(shuffled)


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(datasets=datasets_with_duplicates_strategy())
def test_property_dataset_deduplication(datasets):
    """
    Property 8: Dataset Deduplication
    
    For any job, the datasets array should contain only unique dataset names
    (no duplicates), and all datasets should be in fully qualified form.
    
    This property verifies that:
    - Duplicate dataset references are removed
    - Each dataset appears only once in the output
    - Dataset names are preserved correctly
    - All datasets are in fully qualified form (no partial names)
    - Empty or invalid dataset names are filtered out
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                datasets TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        # Create a job with datasets (including duplicates)
        job_name = 'TESTJOB1'
        
        # Store datasets as JSON array
        import json
        datasets_json = json.dumps(datasets)
        
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
            VALUES (?, ?, ?, ?)
        """, (job_name, 'JCL', 100, datasets_json))
        
        conn.commit()
        conn.close()
        
        # Create exporter and extract datasets
        with JobExporter(db_path) as exporter:
            extracted_datasets = exporter._extract_datasets(job_name)
        
        # Verify deduplication
        # 1. No duplicates in output
        assert len(extracted_datasets) == len(set(extracted_datasets)), \
            f"Extracted datasets contain duplicates: {extracted_datasets}"
        
        # 2. All unique datasets from input are present in output
        unique_input_datasets = set(ds.strip() for ds in datasets if ds and ds.strip())
        extracted_set = set(extracted_datasets)
        
        assert unique_input_datasets == extracted_set, \
            f"Dataset mismatch. Expected: {unique_input_datasets}, Got: {extracted_set}"
        
        # 3. Output is sorted (for consistency)
        assert extracted_datasets == sorted(extracted_datasets), \
            f"Datasets should be sorted alphabetically, got: {extracted_datasets}"
        
        # 4. All datasets are non-empty strings
        for dataset in extracted_datasets:
            assert isinstance(dataset, str), \
                f"Dataset should be string, got {type(dataset)}"
            assert len(dataset) > 0, \
                f"Dataset name should not be empty"
            assert dataset.strip() == dataset, \
                f"Dataset name should not have leading/trailing whitespace: '{dataset}'"
        
        # 5. Verify fully qualified form (contains at least one segment)
        for dataset in extracted_datasets:
            # Mainframe dataset names should have at least one character
            assert len(dataset) > 0, \
                f"Dataset name should not be empty: '{dataset}'"
            # Should not be just whitespace
            assert dataset.strip(), \
                f"Dataset name should not be just whitespace: '{dataset}'"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)



# Property 9: Dataset Array Presence
# Feature: jcl-job-export, Property 9: Dataset Array Presence
# Validates: Requirements 6.5
@st.composite
def job_with_optional_datasets_strategy(draw):
    """Generate a job that may or may not have dataset information."""
    job_name = draw(job_name_strategy())
    
    # Randomly decide if job has datasets
    has_datasets = draw(st.booleans())
    
    if has_datasets:
        # Generate 0 to 10 datasets
        num_datasets = draw(st.integers(min_value=0, max_value=10))
        datasets = [draw(dataset_name_strategy()) for _ in range(num_datasets)]
    else:
        # No datasets (will be stored as NULL or empty in database)
        datasets = None
    
    return {
        'jobName': job_name,
        'datasets': datasets
    }


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much
    ]
)
@given(job_data=job_with_optional_datasets_strategy())
def test_property_dataset_array_presence(job_data):
    """
    Property 9: Dataset Array Presence
    
    For any exported job, the datasets field should be an array (possibly empty),
    never null or undefined.
    
    This property verifies that:
    - The _extract_datasets method always returns a list
    - The list is never None or other non-list type
    - Empty dataset information results in an empty list, not None
    - Missing dataset information results in an empty list, not None
    - The return type is consistent regardless of input
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                datasets TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        # Create a job with or without datasets
        job_name = job_data['jobName']
        datasets = job_data['datasets']
        
        # Store datasets as JSON array or NULL
        if datasets is not None:
            import json
            datasets_json = json.dumps(datasets)
        else:
            datasets_json = None
        
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
            VALUES (?, ?, ?, ?)
        """, (job_name, 'JCL', 100, datasets_json))
        
        conn.commit()
        conn.close()
        
        # Create exporter and extract datasets
        with JobExporter(db_path) as exporter:
            extracted_datasets = exporter._extract_datasets(job_name)
        
        # Verify array presence
        # 1. Result must be a list
        assert isinstance(extracted_datasets, list), \
            f"_extract_datasets must return a list, got {type(extracted_datasets)}"
        
        # 2. Result must not be None
        assert extracted_datasets is not None, \
            "_extract_datasets must not return None"
        
        # 3. If input had no datasets, result should be empty list
        if datasets is None or len(datasets) == 0:
            assert extracted_datasets == [], \
                f"Jobs with no datasets should return empty list, got {extracted_datasets}"
        
        # 4. All elements in the list must be strings
        for dataset in extracted_datasets:
            assert isinstance(dataset, str), \
                f"All dataset entries must be strings, got {type(dataset)}"
        
        # 5. List should not contain None values
        assert None not in extracted_datasets, \
            "Dataset list should not contain None values"
        
        # 6. List should not contain empty strings
        for dataset in extracted_datasets:
            assert len(dataset) > 0, \
                "Dataset list should not contain empty strings"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Additional edge case tests for dataset extraction
def test_extract_datasets_nonexistent_job(temp_db):
    """Test extracting datasets for non-existent job returns empty list."""
    with JobExporter(temp_db) as exporter:
        datasets = exporter._extract_datasets('NONEXISTENT')
    
    assert datasets == []
    assert isinstance(datasets, list)


def test_extract_datasets_null_datasets_column(temp_db):
    """Test extracting datasets when datasets column is NULL."""
    # Add a job with NULL datasets
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
        VALUES (?, ?, ?, ?)
    """, ('TESTJOB1', 'JCL', 100, None))
    
    conn.commit()
    conn.close()
    
    with JobExporter(temp_db) as exporter:
        datasets = exporter._extract_datasets('TESTJOB1')
    
    assert datasets == []
    assert isinstance(datasets, list)


def test_extract_datasets_empty_json_array(temp_db):
    """Test extracting datasets when datasets is empty JSON array."""
    import json
    
    # Add a job with empty datasets array
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
        VALUES (?, ?, ?, ?)
    """, ('TESTJOB1', 'JCL', 100, json.dumps([])))
    
    conn.commit()
    conn.close()
    
    with JobExporter(temp_db) as exporter:
        datasets = exporter._extract_datasets('TESTJOB1')
    
    assert datasets == []
    assert isinstance(datasets, list)


def test_extract_datasets_with_duplicates(temp_db):
    """Test that duplicate datasets are removed."""
    import json
    
    # Add a job with duplicate datasets
    datasets_with_dups = ['DATASET.ONE', 'DATASET.TWO', 'DATASET.ONE', 'DATASET.THREE', 'DATASET.TWO']
    
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
        VALUES (?, ?, ?, ?)
    """, ('TESTJOB1', 'JCL', 100, json.dumps(datasets_with_dups)))
    
    conn.commit()
    conn.close()
    
    with JobExporter(temp_db) as exporter:
        datasets = exporter._extract_datasets('TESTJOB1')
    
    # Should have only unique datasets
    assert len(datasets) == 3
    assert set(datasets) == {'DATASET.ONE', 'DATASET.TWO', 'DATASET.THREE'}
    
    # Should be sorted
    assert datasets == sorted(datasets)


def test_extract_datasets_dict_format(temp_db):
    """Test extracting datasets when stored as dictionary objects."""
    import json
    
    # Add a job with datasets in dictionary format
    datasets_dict = [
        {'name': 'DATASET.ONE'},
        {'dsn': 'DATASET.TWO'},
        {'dataset': 'DATASET.THREE'},
        {'datasetName': 'DATASET.FOUR'}
    ]
    
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
        VALUES (?, ?, ?, ?)
    """, ('TESTJOB1', 'JCL', 100, json.dumps(datasets_dict)))
    
    conn.commit()
    conn.close()
    
    with JobExporter(temp_db) as exporter:
        datasets = exporter._extract_datasets('TESTJOB1')
    
    # Should extract all datasets from different key formats
    assert len(datasets) == 4
    assert set(datasets) == {'DATASET.ONE', 'DATASET.TWO', 'DATASET.THREE', 'DATASET.FOUR'}


def test_extract_datasets_mixed_format(temp_db):
    """Test extracting datasets with mixed string and dict formats."""
    import json
    
    # Add a job with mixed format datasets
    datasets_mixed = [
        'DATASET.ONE',
        {'name': 'DATASET.TWO'},
        'DATASET.THREE',
        {'dsn': 'DATASET.FOUR'}
    ]
    
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
        VALUES (?, ?, ?, ?)
    """, ('TESTJOB1', 'JCL', 100, json.dumps(datasets_mixed)))
    
    conn.commit()
    conn.close()
    
    with JobExporter(temp_db) as exporter:
        datasets = exporter._extract_datasets('TESTJOB1')
    
    # Should extract all datasets regardless of format
    assert len(datasets) == 4
    assert set(datasets) == {'DATASET.ONE', 'DATASET.TWO', 'DATASET.THREE', 'DATASET.FOUR'}


def test_extract_datasets_invalid_json(temp_db):
    """Test extracting datasets when JSON is invalid."""
    # Add a job with invalid JSON
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
        VALUES (?, ?, ?, ?)
    """, ('TESTJOB1', 'JCL', 100, 'invalid json {'))
    
    conn.commit()
    conn.close()
    
    with JobExporter(temp_db) as exporter:
        datasets = exporter._extract_datasets('TESTJOB1')
    
    # Should return empty list on JSON parse error
    assert datasets == []
    assert isinstance(datasets, list)



# Property 12: Name Sorting Order
# Feature: jcl-job-export, Property 12: Name Sorting Order
# Validates: Requirements 7.1
@st.composite
def job_dict_strategy(draw):
    """Generate a job dictionary with required fields for sorting."""
    job_name = draw(job_name_strategy())
    job_type = draw(st.sampled_from(['APPLICATION', 'INFRASTRUCTURE']))
    num_steps = draw(st.integers(min_value=0, max_value=20))
    
    # Generate steps
    steps = []
    for i in range(num_steps):
        steps.append({
            'stepName': f'STEP{i+1:02d}',
            'program': f'PROG{i+1}',
            'type': 'CUSTOM',
            'purpose': f'Execute PROG{i+1}',
            'flowEntry': False
        })
    
    # Generate dependencies
    dependencies = {
        'mustRunAfter': [],
        'mustRunBefore': []
    }
    
    return {
        'jobName': job_name,
        'jobType': job_type,
        'hasCustomCode': job_type == 'APPLICATION',
        'linkedFlow': None,
        'steps': steps,
        'datasets': [],
        'dependencies': dependencies
    }


@st.composite
def job_list_for_sorting_strategy(draw):
    """Generate a list of unique jobs for sorting tests."""
    num_jobs = draw(st.integers(min_value=2, max_value=20))
    jobs = []
    job_names_seen = set()
    
    while len(jobs) < num_jobs:
        job = draw(job_dict_strategy())
        if job['jobName'] not in job_names_seen:
            jobs.append(job)
            job_names_seen.add(job['jobName'])
    
    return jobs


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much,
        HealthCheck.large_base_example
    ]
)
@given(jobs=job_list_for_sorting_strategy())
def test_property_name_sorting_order(jobs):
    """
    Property 12: Name Sorting Order
    
    For any list of jobs sorted by name, each job's name should be
    lexicographically less than or equal to the next job's name.
    
    This property verifies that:
    - Jobs are sorted in ascending alphabetical order
    - The sort is stable and consistent
    - All jobs are included in the sorted output
    - No jobs are duplicated or lost
    """
    from tools.legacy_analyzer.migration.sorting_strategies import NameSortingStrategy
    
    # Apply name sorting
    strategy = NameSortingStrategy()
    sorted_jobs = strategy.sort(jobs)
    
    # Verify all jobs are present
    assert len(sorted_jobs) == len(jobs), \
        f"Sorted list should have same length as input: {len(sorted_jobs)} != {len(jobs)}"
    
    # Verify no jobs were lost or duplicated
    input_names = sorted([job['jobName'] for job in jobs])
    output_names = sorted([job['jobName'] for job in sorted_jobs])
    assert input_names == output_names, \
        f"Job names mismatch after sorting"
    
    # Verify lexicographic ordering
    for i in range(len(sorted_jobs) - 1):
        current_name = sorted_jobs[i]['jobName']
        next_name = sorted_jobs[i + 1]['jobName']
        
        assert current_name <= next_name, \
            f"Jobs not in alphabetical order: {current_name} should come before or equal to {next_name}"
    
    # Verify the sorted list matches Python's sorted() function
    expected_order = sorted(jobs, key=lambda j: j['jobName'])
    expected_names = [j['jobName'] for j in expected_order]
    actual_names = [j['jobName'] for j in sorted_jobs]
    
    assert actual_names == expected_names, \
        f"Sorting order doesn't match expected alphabetical order"


# Property 13: Type Sorting Grouping
# Feature: jcl-job-export, Property 13: Type Sorting Grouping
# Validates: Requirements 7.2
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much,
        HealthCheck.large_base_example
    ]
)
@given(jobs=job_list_for_sorting_strategy())
def test_property_type_sorting_grouping(jobs):
    """
    Property 13: Type Sorting Grouping
    
    For any list of jobs sorted by type, all APPLICATION jobs should appear
    before all INFRASTRUCTURE jobs.
    
    This property verifies that:
    - APPLICATION jobs are grouped first
    - INFRASTRUCTURE jobs are grouped second
    - Within each group, jobs are sorted by name
    - No jobs are lost or duplicated
    - The grouping is consistent
    """
    from tools.legacy_analyzer.migration.sorting_strategies import TypeSortingStrategy
    
    # Apply type sorting
    strategy = TypeSortingStrategy()
    sorted_jobs = strategy.sort(jobs)
    
    # Verify all jobs are present
    assert len(sorted_jobs) == len(jobs), \
        f"Sorted list should have same length as input: {len(sorted_jobs)} != {len(jobs)}"
    
    # Verify no jobs were lost or duplicated
    input_names = sorted([job['jobName'] for job in jobs])
    output_names = sorted([job['jobName'] for job in sorted_jobs])
    assert input_names == output_names, \
        f"Job names mismatch after sorting"
    
    # Find the boundary between APPLICATION and INFRASTRUCTURE jobs
    app_jobs = [job for job in sorted_jobs if job['jobType'] == 'APPLICATION']
    infra_jobs = [job for job in sorted_jobs if job['jobType'] == 'INFRASTRUCTURE']
    
    # Verify all APPLICATION jobs come before all INFRASTRUCTURE jobs
    if app_jobs and infra_jobs:
        # Find the last APPLICATION job index
        last_app_index = -1
        first_infra_index = len(sorted_jobs)
        
        for i, job in enumerate(sorted_jobs):
            if job['jobType'] == 'APPLICATION':
                last_app_index = i
            elif job['jobType'] == 'INFRASTRUCTURE' and first_infra_index == len(sorted_jobs):
                first_infra_index = i
        
        assert last_app_index < first_infra_index, \
            f"All APPLICATION jobs should come before INFRASTRUCTURE jobs"
    
    # Verify APPLICATION jobs are sorted by name within their group
    app_names = [job['jobName'] for job in app_jobs]
    assert app_names == sorted(app_names), \
        f"APPLICATION jobs should be sorted by name within their group"
    
    # Verify INFRASTRUCTURE jobs are sorted by name within their group
    infra_names = [job['jobName'] for job in infra_jobs]
    assert infra_names == sorted(infra_names), \
        f"INFRASTRUCTURE jobs should be sorted by name within their group"
    
    # Verify counts match
    input_app_count = sum(1 for job in jobs if job['jobType'] == 'APPLICATION')
    input_infra_count = sum(1 for job in jobs if job['jobType'] == 'INFRASTRUCTURE')
    
    assert len(app_jobs) == input_app_count, \
        f"APPLICATION job count mismatch: {len(app_jobs)} != {input_app_count}"
    assert len(infra_jobs) == input_infra_count, \
        f"INFRASTRUCTURE job count mismatch: {len(infra_jobs)} != {input_infra_count}"


# Property 14: Dependency Sorting Topological Order
# Feature: jcl-job-export, Property 14: Dependency Sorting Topological Order
# Validates: Requirements 7.3
@st.composite
def jobs_with_dependencies_strategy(draw):
    """Generate a list of jobs with dependency relationships."""
    num_jobs = draw(st.integers(min_value=2, max_value=10))
    
    # Generate unique job names
    job_names = []
    for _ in range(num_jobs):
        job_name = draw(job_name_strategy())
        while job_name in job_names:
            job_name = draw(job_name_strategy())
        job_names.append(job_name)
    
    # Create jobs with dependencies
    jobs = []
    for i, job_name in enumerate(job_names):
        # Randomly select some predecessors (jobs that must run before this one)
        # Only select from jobs that come before this one in the list to avoid cycles
        possible_predecessors = job_names[:i]
        
        if possible_predecessors:
            num_predecessors = draw(st.integers(min_value=0, max_value=min(3, len(possible_predecessors))))
            predecessors = draw(st.lists(
                st.sampled_from(possible_predecessors),
                min_size=num_predecessors,
                max_size=num_predecessors,
                unique=True
            ))
        else:
            predecessors = []
        
        # Create job
        job = {
            'jobName': job_name,
            'jobType': draw(st.sampled_from(['APPLICATION', 'INFRASTRUCTURE'])),
            'hasCustomCode': True,
            'linkedFlow': None,
            'steps': [],
            'datasets': [],
            'dependencies': {
                'mustRunAfter': sorted(predecessors),
                'mustRunBefore': []  # Will be computed
            }
        }
        jobs.append(job)
    
    # Compute mustRunBefore relationships
    for job in jobs:
        for predecessor in job['dependencies']['mustRunAfter']:
            # Find the predecessor job and add this job to its mustRunBefore
            for pred_job in jobs:
                if pred_job['jobName'] == predecessor:
                    if job['jobName'] not in pred_job['dependencies']['mustRunBefore']:
                        pred_job['dependencies']['mustRunBefore'].append(job['jobName'])
                    break
    
    # Sort mustRunBefore arrays
    for job in jobs:
        job['dependencies']['mustRunBefore'] = sorted(job['dependencies']['mustRunBefore'])
    
    return jobs


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much,
        HealthCheck.large_base_example
    ]
)
@given(jobs=jobs_with_dependencies_strategy())
def test_property_dependency_sorting_topological_order(jobs):
    """
    Property 14: Dependency Sorting Topological Order
    
    For any list of jobs sorted by dependencies, if job A must run before
    job B (A is in B's mustRunAfter), then A should appear before B in the
    sorted list.
    
    This property verifies that:
    - Dependencies are respected in the sort order
    - Jobs with no dependencies come first
    - Jobs appear after all their dependencies
    - Circular dependencies are handled gracefully
    - The sort produces a valid topological ordering
    """
    from tools.legacy_analyzer.migration.sorting_strategies import DependencySortingStrategy
    
    # Apply dependency sorting
    strategy = DependencySortingStrategy()
    sorted_jobs = strategy.sort(jobs)
    
    # Verify all jobs are present
    assert len(sorted_jobs) == len(jobs), \
        f"Sorted list should have same length as input: {len(sorted_jobs)} != {len(jobs)}"
    
    # Verify no jobs were lost or duplicated
    input_names = sorted([job['jobName'] for job in jobs])
    output_names = sorted([job['jobName'] for job in sorted_jobs])
    assert input_names == output_names, \
        f"Job names mismatch after sorting"
    
    # Build a position map for quick lookup
    position = {job['jobName']: i for i, job in enumerate(sorted_jobs)}
    
    # Verify topological order: for each job, all its dependencies should come before it
    for job in sorted_jobs:
        job_name = job['jobName']
        job_position = position[job_name]
        
        # Check all mustRunAfter dependencies
        for dependency in job['dependencies']['mustRunAfter']:
            if dependency in position:
                dep_position = position[dependency]
                
                # Dependency should come before this job
                assert dep_position < job_position, \
                    f"Dependency violation: {dependency} (position {dep_position}) " \
                    f"should come before {job_name} (position {job_position})"
    
    # Verify that jobs with no dependencies come first (or early)
    # This is a weaker property but helps validate the algorithm
    jobs_with_no_deps = [job for job in jobs if not job['dependencies']['mustRunAfter']]
    
    if jobs_with_no_deps:
        # At least one job with no dependencies should be in the first half
        no_dep_positions = [position[job['jobName']] for job in jobs_with_no_deps]
        min_no_dep_position = min(no_dep_positions)
        
        # This is a soft check - at least one no-dependency job should be early
        # (not necessarily first due to name sorting within same dependency level)
        assert min_no_dep_position < len(sorted_jobs), \
            f"Jobs with no dependencies should appear in the sorted list"


# Property 15: Complexity Sorting Order
# Feature: jcl-job-export, Property 15: Complexity Sorting Order
# Validates: Requirements 7.4
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much,
        HealthCheck.large_base_example
    ]
)
@given(jobs=job_list_for_sorting_strategy())
def test_property_complexity_sorting_order(jobs):
    """
    Property 15: Complexity Sorting Order
    
    For any list of jobs sorted by complexity, each job should have greater
    than or equal number of steps compared to the next job.
    
    This property verifies that:
    - Jobs are sorted by step count in descending order
    - Jobs with more steps appear first
    - Jobs with same step count are sorted by name
    - All jobs are included in the sorted output
    - No jobs are duplicated or lost
    """
    from tools.legacy_analyzer.migration.sorting_strategies import ComplexitySortingStrategy
    
    # Apply complexity sorting
    strategy = ComplexitySortingStrategy()
    sorted_jobs = strategy.sort(jobs)
    
    # Verify all jobs are present
    assert len(sorted_jobs) == len(jobs), \
        f"Sorted list should have same length as input: {len(sorted_jobs)} != {len(jobs)}"
    
    # Verify no jobs were lost or duplicated
    input_names = sorted([job['jobName'] for job in jobs])
    output_names = sorted([job['jobName'] for job in sorted_jobs])
    assert input_names == output_names, \
        f"Job names mismatch after sorting"
    
    # Verify descending order by step count
    for i in range(len(sorted_jobs) - 1):
        current_steps = len(sorted_jobs[i]['steps'])
        next_steps = len(sorted_jobs[i + 1]['steps'])
        
        assert current_steps >= next_steps, \
            f"Jobs not in descending complexity order: " \
            f"{sorted_jobs[i]['jobName']} ({current_steps} steps) should have >= steps than " \
            f"{sorted_jobs[i + 1]['jobName']} ({next_steps} steps)"
    
    # Verify that jobs with same step count are sorted by name
    # Group jobs by step count
    from itertools import groupby
    
    for step_count, group in groupby(sorted_jobs, key=lambda j: len(j['steps'])):
        group_list = list(group)
        if len(group_list) > 1:
            # Jobs in this group should be sorted by name
            group_names = [job['jobName'] for job in group_list]
            assert group_names == sorted(group_names), \
                f"Jobs with {step_count} steps should be sorted by name: {group_names}"
    
    # Verify the most complex job is first (if jobs exist)
    if sorted_jobs:
        max_steps_in_input = max(len(job['steps']) for job in jobs)
        first_job_steps = len(sorted_jobs[0]['steps'])
        
        assert first_job_steps == max_steps_in_input, \
            f"First job should have maximum step count: {first_job_steps} != {max_steps_in_input}"
    
    # Verify the least complex job is last (if jobs exist)
    if sorted_jobs:
        min_steps_in_input = min(len(job['steps']) for job in jobs)
        last_job_steps = len(sorted_jobs[-1]['steps'])
        
        assert last_job_steps == min_steps_in_input, \
            f"Last job should have minimum step count: {last_job_steps} != {min_steps_in_input}"



# Property 16: Summary Count Accuracy
# Feature: jcl-job-export, Property 16: Summary Count Accuracy
# Validates: Requirements 8.2, 8.3, 8.4
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much,
        HealthCheck.large_base_example
    ]
)
@given(jobs=job_list_for_sorting_strategy())
def test_property_summary_count_accuracy(jobs):
    """
    Property 16: Summary Count Accuracy
    
    For any export, the summary.totalJobs should equal the length of the jobs
    array, summary.applicationJobs should equal the count of jobs with
    jobType="APPLICATION", and summary.infrastructureJobs should equal the
    count of jobs with jobType="INFRASTRUCTURE".
    
    This property verifies that:
    - Total job count matches the jobs array length
    - APPLICATION job count is accurate
    - INFRASTRUCTURE job count is accurate
    - Counts sum correctly (totalJobs = applicationJobs + infrastructureJobs)
    - Counts are non-negative integers
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Create exporter and generate summary
        with JobExporter(db_path) as exporter:
            summary = exporter._generate_summary(jobs, 'name')
        
        # Calculate expected counts
        expected_total = len(jobs)
        expected_app = sum(1 for job in jobs if job['jobType'] == 'APPLICATION')
        expected_infra = sum(1 for job in jobs if job['jobType'] == 'INFRASTRUCTURE')
        
        # Verify total jobs count
        assert summary['totalJobs'] == expected_total, \
            f"totalJobs should be {expected_total}, got {summary['totalJobs']}"
        
        # Verify application jobs count
        assert summary['applicationJobs'] == expected_app, \
            f"applicationJobs should be {expected_app}, got {summary['applicationJobs']}"
        
        # Verify infrastructure jobs count
        assert summary['infrastructureJobs'] == expected_infra, \
            f"infrastructureJobs should be {expected_infra}, got {summary['infrastructureJobs']}"
        
        # Verify counts sum correctly
        assert summary['totalJobs'] == summary['applicationJobs'] + summary['infrastructureJobs'], \
            f"totalJobs ({summary['totalJobs']}) should equal " \
            f"applicationJobs ({summary['applicationJobs']}) + " \
            f"infrastructureJobs ({summary['infrastructureJobs']})"
        
        # Verify counts are non-negative integers
        assert isinstance(summary['totalJobs'], int), \
            f"totalJobs should be an integer, got {type(summary['totalJobs'])}"
        assert isinstance(summary['applicationJobs'], int), \
            f"applicationJobs should be an integer, got {type(summary['applicationJobs'])}"
        assert isinstance(summary['infrastructureJobs'], int), \
            f"infrastructureJobs should be an integer, got {type(summary['infrastructureJobs'])}"
        
        assert summary['totalJobs'] >= 0, \
            f"totalJobs should be non-negative, got {summary['totalJobs']}"
        assert summary['applicationJobs'] >= 0, \
            f"applicationJobs should be non-negative, got {summary['applicationJobs']}"
        assert summary['infrastructureJobs'] >= 0, \
            f"infrastructureJobs should be non-negative, got {summary['infrastructureJobs']}"
        
        # Verify counts match the input
        assert summary['totalJobs'] == len(jobs), \
            f"totalJobs should match input length: {summary['totalJobs']} != {len(jobs)}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 17: Summary Completeness
# Feature: jcl-job-export, Property 17: Summary Completeness
# Validates: Requirements 8.1, 8.6
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much,
        HealthCheck.large_base_example
    ]
)
@given(
    jobs=job_list_for_sorting_strategy(),
    sort_by=st.sampled_from(['name', 'type', 'dependencies', 'complexity'])
)
def test_property_summary_completeness(jobs, sort_by):
    """
    Property 17: Summary Completeness
    
    For any export, the summary object should contain totalJobs,
    applicationJobs, infrastructureJobs, exportDate, database, and
    sortedBy fields.
    
    This property verifies that:
    - All required fields are present in the summary
    - No required fields are missing or null
    - Field types are correct
    - Field values are valid
    - Summary provides complete metadata about the export
    """
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Create exporter and generate summary
        with JobExporter(db_path) as exporter:
            summary = exporter._generate_summary(jobs, sort_by)
        
        # Verify all required fields are present
        required_fields = [
            'totalJobs',
            'applicationJobs',
            'infrastructureJobs',
            'exportDate',
            'database',
            'sortedBy'
        ]
        
        for field in required_fields:
            assert field in summary, \
                f"Summary missing required field: {field}"
        
        # Verify no fields are None
        for field in required_fields:
            assert summary[field] is not None, \
                f"Summary field {field} should not be None"
        
        # Verify field types
        assert isinstance(summary['totalJobs'], int), \
            f"totalJobs should be int, got {type(summary['totalJobs'])}"
        assert isinstance(summary['applicationJobs'], int), \
            f"applicationJobs should be int, got {type(summary['applicationJobs'])}"
        assert isinstance(summary['infrastructureJobs'], int), \
            f"infrastructureJobs should be int, got {type(summary['infrastructureJobs'])}"
        assert isinstance(summary['exportDate'], str), \
            f"exportDate should be str, got {type(summary['exportDate'])}"
        assert isinstance(summary['database'], str), \
            f"database should be str, got {type(summary['database'])}"
        assert isinstance(summary['sortedBy'], str), \
            f"sortedBy should be str, got {type(summary['sortedBy'])}"
        
        # Verify string fields are not empty
        assert len(summary['exportDate']) > 0, \
            "exportDate should not be empty"
        assert len(summary['database']) > 0, \
            "database should not be empty"
        assert len(summary['sortedBy']) > 0, \
            "sortedBy should not be empty"
        
        # Verify sortedBy matches input
        assert summary['sortedBy'] == sort_by, \
            f"sortedBy should be '{sort_by}', got '{summary['sortedBy']}'"
        
        # Verify database path matches
        assert summary['database'] == db_path, \
            f"database should be '{db_path}', got '{summary['database']}'"
        
        # Verify no extra unexpected fields (optional check)
        # This ensures the summary structure is well-defined
        for field in summary.keys():
            assert field in required_fields, \
                f"Unexpected field in summary: {field}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 18: ISO 8601 Timestamp Format
# Feature: jcl-job-export, Property 18: ISO 8601 Timestamp Format
# Validates: Requirements 8.5
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.filter_too_much,
        HealthCheck.large_base_example
    ]
)
@given(jobs=job_list_for_sorting_strategy())
def test_property_iso8601_timestamp_format(jobs):
    """
    Property 18: ISO 8601 Timestamp Format
    
    For any export, the summary.exportDate should be a valid ISO 8601
    formatted timestamp string.
    
    This property verifies that:
    - exportDate is a string
    - exportDate follows ISO 8601 format (YYYY-MM-DDTHH:MM:SS.sssZ)
    - Timestamp is in UTC timezone (ends with 'Z')
    - Timestamp can be parsed as a valid datetime
    - Timestamp represents a reasonable date (not far in past or future)
    """
    import re
    from datetime import datetime, timezone, timedelta
    
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Create exporter and generate summary
        with JobExporter(db_path) as exporter:
            summary = exporter._generate_summary(jobs, 'name')
        
        export_date = summary['exportDate']
        
        # Verify it's a string
        assert isinstance(export_date, str), \
            f"exportDate should be a string, got {type(export_date)}"
        
        # Verify ISO 8601 format: YYYY-MM-DDTHH:MM:SS.sssZ
        # Pattern: 4-digit year, 2-digit month, 2-digit day, T separator,
        # 2-digit hour, 2-digit minute, 2-digit second, 3-digit milliseconds, Z suffix
        iso8601_pattern = r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$'
        
        assert re.match(iso8601_pattern, export_date), \
            f"exportDate should match ISO 8601 format (YYYY-MM-DDTHH:MM:SS.sssZ), got: {export_date}"
        
        # Verify it ends with 'Z' (UTC timezone)
        assert export_date.endswith('Z'), \
            f"exportDate should end with 'Z' (UTC timezone), got: {export_date}"
        
        # Verify it can be parsed as a valid datetime
        try:
            # Parse the timestamp (remove 'Z' and parse as UTC)
            timestamp_str = export_date[:-1]  # Remove 'Z'
            parsed_date = datetime.fromisoformat(timestamp_str).replace(tzinfo=timezone.utc)
        except ValueError as e:
            pytest.fail(f"exportDate could not be parsed as valid datetime: {export_date}, error: {e}")
        
        # Verify the timestamp is reasonable (within 1 minute of now)
        # This ensures the timestamp represents the current export time
        now = datetime.now(timezone.utc)
        time_diff = abs((now - parsed_date).total_seconds())
        
        assert time_diff < 60, \
            f"exportDate should be close to current time (within 60 seconds), " \
            f"but difference is {time_diff} seconds. exportDate: {export_date}, now: {now.isoformat()}"
        
        # Verify the timestamp is not in the future (with small tolerance for clock skew)
        assert parsed_date <= now + timedelta(seconds=5), \
            f"exportDate should not be in the future: {export_date}"
        
        # Verify the timestamp is not too far in the past (within 1 hour)
        assert parsed_date >= now - timedelta(hours=1), \
            f"exportDate should not be more than 1 hour in the past: {export_date}"
        
        # Verify the date components are valid
        assert 1 <= parsed_date.month <= 12, \
            f"Month should be between 1 and 12, got {parsed_date.month}"
        assert 1 <= parsed_date.day <= 31, \
            f"Day should be between 1 and 31, got {parsed_date.day}"
        assert 0 <= parsed_date.hour <= 23, \
            f"Hour should be between 0 and 23, got {parsed_date.hour}"
        assert 0 <= parsed_date.minute <= 59, \
            f"Minute should be between 0 and 59, got {parsed_date.minute}"
        assert 0 <= parsed_date.second <= 59, \
            f"Second should be between 0 and 59, got {parsed_date.second}"
        assert 0 <= parsed_date.microsecond <= 999999, \
            f"Microsecond should be between 0 and 999999, got {parsed_date.microsecond}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Additional unit tests for summary generation
def test_generate_summary_empty_jobs(temp_db):
    """Test generating summary for empty jobs list."""
    with JobExporter(temp_db) as exporter:
        summary = exporter._generate_summary([], 'name')
    
    assert summary['totalJobs'] == 0
    assert summary['applicationJobs'] == 0
    assert summary['infrastructureJobs'] == 0
    assert summary['sortedBy'] == 'name'
    assert summary['database'] == temp_db
    assert 'exportDate' in summary


def test_generate_summary_all_application_jobs(temp_db):
    """Test generating summary when all jobs are APPLICATION type."""
    jobs = [
        {'jobName': 'JOB1', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
        {'jobName': 'JOB2', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
        {'jobName': 'JOB3', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
    ]
    
    with JobExporter(temp_db) as exporter:
        summary = exporter._generate_summary(jobs, 'type')
    
    assert summary['totalJobs'] == 3
    assert summary['applicationJobs'] == 3
    assert summary['infrastructureJobs'] == 0
    assert summary['sortedBy'] == 'type'


def test_generate_summary_all_infrastructure_jobs(temp_db):
    """Test generating summary when all jobs are INFRASTRUCTURE type."""
    jobs = [
        {'jobName': 'JOB1', 'jobType': 'INFRASTRUCTURE', 'hasCustomCode': False, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
        {'jobName': 'JOB2', 'jobType': 'INFRASTRUCTURE', 'hasCustomCode': False, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
    ]
    
    with JobExporter(temp_db) as exporter:
        summary = exporter._generate_summary(jobs, 'complexity')
    
    assert summary['totalJobs'] == 2
    assert summary['applicationJobs'] == 0
    assert summary['infrastructureJobs'] == 2
    assert summary['sortedBy'] == 'complexity'


def test_generate_summary_mixed_job_types(temp_db):
    """Test generating summary with mixed job types."""
    jobs = [
        {'jobName': 'JOB1', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
        {'jobName': 'JOB2', 'jobType': 'INFRASTRUCTURE', 'hasCustomCode': False, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
        {'jobName': 'JOB3', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
        {'jobName': 'JOB4', 'jobType': 'INFRASTRUCTURE', 'hasCustomCode': False, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
        {'jobName': 'JOB5', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
    ]
    
    with JobExporter(temp_db) as exporter:
        summary = exporter._generate_summary(jobs, 'dependencies')
    
    assert summary['totalJobs'] == 5
    assert summary['applicationJobs'] == 3
    assert summary['infrastructureJobs'] == 2
    assert summary['sortedBy'] == 'dependencies'


def test_generate_summary_timestamp_format(temp_db):
    """Test that summary timestamp is in correct ISO 8601 format."""
    import re
    
    jobs = [
        {'jobName': 'JOB1', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
    ]
    
    with JobExporter(temp_db) as exporter:
        summary = exporter._generate_summary(jobs, 'name')
    
    # Verify ISO 8601 format
    iso8601_pattern = r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$'
    assert re.match(iso8601_pattern, summary['exportDate']), \
        f"exportDate should match ISO 8601 format, got: {summary['exportDate']}"


def test_generate_summary_database_path(temp_db):
    """Test that summary includes correct database path."""
    jobs = [
        {'jobName': 'JOB1', 'jobType': 'APPLICATION', 'hasCustomCode': True, 'steps': [], 'datasets': [], 'dependencies': {}, 'linkedFlow': None},
    ]
    
    with JobExporter(temp_db) as exporter:
        summary = exporter._generate_summary(jobs, 'name')
    
    assert summary['database'] == temp_db
    assert len(summary['database']) > 0


# Property 21: Output File Naming Convention
# Feature: jcl-job-export, Property 21: Output File Naming Convention
# Validates: Requirements 11.1
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.function_scoped_fixture
    ]
)
@given(sort_strategy=st.sampled_from(['name', 'type', 'dependencies', 'complexity']))
def test_property_output_file_naming_convention(sort_strategy):
    """
    Property 21: Output File Naming Convention
    
    For any export with sort strategy S, the output filename should be
    "jobs_by_{S}.json".
    
    This property verifies that:
    - Output filenames follow the jobs_by_{strategy}.json pattern
    - Filename matches the sort strategy used
    - Filename is consistent and predictable
    - No invalid characters or formats in filename
    """
    import tempfile
    import os
    
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                datasets TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Populate database with a test job
            populate_db_with_jobs(db_path, ['TESTJOB1'])
            
            # Create exporter and export jobs
            with JobExporter(db_path) as exporter:
                result = exporter.export_jobs(output_dir, sort_by=sort_strategy)
            
            # Verify filename follows convention
            expected_filename = f"jobs_by_{sort_strategy}.json"
            expected_path = os.path.join(output_dir, expected_filename)
            
            # Check that file exists with correct name
            assert os.path.exists(expected_path), \
                f"Expected output file {expected_path} does not exist"
            
            # Verify filename pattern
            assert expected_filename.startswith('jobs_by_'), \
                f"Filename should start with 'jobs_by_', got {expected_filename}"
            assert expected_filename.endswith('.json'), \
                f"Filename should end with '.json', got {expected_filename}"
            
            # Verify strategy name is in filename
            assert sort_strategy in expected_filename, \
                f"Sort strategy '{sort_strategy}' should be in filename {expected_filename}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 22: JSON Indentation Format
# Feature: jcl-job-export, Property 22: JSON Indentation Format
# Validates: Requirements 11.4
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.function_scoped_fixture
    ]
)
@given(sort_strategy=st.sampled_from(['name', 'type', 'dependencies', 'complexity']))
def test_property_json_indentation_format(sort_strategy):
    """
    Property 22: JSON Indentation Format
    
    For any exported JSON file, the file should use 2-space indentation
    throughout.
    
    This property verifies that:
    - JSON output uses 2-space indentation
    - Indentation is consistent throughout the file
    - JSON is properly formatted and readable
    - No tabs or inconsistent spacing
    """
    import tempfile
    import os
    import json
    
    # Create temporary database for this test
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        # Create schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE inventory_jcl (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                member_name VARCHAR(8) NOT NULL,
                library_name VARCHAR(44) NOT NULL,
                last_modified DATE,
                size_lines INTEGER,
                datasets TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                name TEXT PRIMARY KEY,
                type TEXT,
                is_entry_point BOOLEAN
            )
        """)
        
        conn.commit()
        conn.close()
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Populate database with test jobs
            populate_db_with_jobs(db_path, ['TESTJOB1', 'TESTJOB2'])
            
            # Create exporter and export jobs
            with JobExporter(db_path) as exporter:
                result = exporter.export_jobs(output_dir, sort_by=sort_strategy)
            
            # Read the output file
            filename = f"jobs_by_{sort_strategy}.json"
            filepath = os.path.join(output_dir, filename)
            
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Verify JSON is valid
            parsed_data = json.loads(content)
            assert parsed_data is not None, "JSON should be valid"
            
            # Re-format with 2-space indentation and compare
            expected_content = json.dumps(parsed_data, indent=2, ensure_ascii=False)
            
            # Verify indentation matches
            assert content == expected_content, \
                "JSON file should use 2-space indentation"
            
            # Additional checks for indentation
            lines = content.split('\n')
            for line in lines:
                if line.strip():  # Skip empty lines
                    # Count leading spaces
                    leading_spaces = len(line) - len(line.lstrip(' '))
                    
                    # Verify indentation is a multiple of 2
                    assert leading_spaces % 2 == 0, \
                        f"Indentation should be multiple of 2 spaces, got {leading_spaces} in line: {line[:50]}"
                    
                    # Verify no tabs are used
                    assert '\t' not in line, \
                        f"Tabs should not be used for indentation, found in line: {line[:50]}"
    
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)
