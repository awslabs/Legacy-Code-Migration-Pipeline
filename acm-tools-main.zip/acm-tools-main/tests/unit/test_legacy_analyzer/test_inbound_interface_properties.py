"""
Property-Based Tests for Inbound Interface Identification

This module contains property-based tests that validate the correctness
of inbound interface identification logic in the migration flow builder.

Tests validate:
- Property 1: External Systems Create Inbound Interfaces
- Property 3: Configured External Callers Always Create Inbound Interfaces
- Property 4: Metadata Preservation for Configured Callers
"""

import pytest
import sqlite3
import json
import tempfile
import os
from hypothesis import given, strategies as st, settings, assume, HealthCheck
from typing import List, Dict, Set

from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder
from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
from tools.legacy_analyzer.migration.interface_loader import ExternalInterfaceLoader
from tools.legacy_analyzer.models.flow import ProgramFlow


# Strategy for generating valid program names
program_name_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), whitelist_characters='_-'),
    min_size=1,
    max_size=20
).filter(lambda x: x and x[0].isalpha())


# Strategy for generating dependency types
dependency_type_strategy = st.sampled_from([
    'PROGRAM_CALL',
    'CICS_LINK',
    'CICS_XCTL',
    'EXTERNAL_CALL'
])


# Strategy for generating metadata
metadata_strategy = st.fixed_dictionaries({
    'system': st.text(min_size=1, max_size=50),
    'description': st.text(min_size=0, max_size=100)
})


def create_test_database():
    """Create a temporary test database with required schema."""
    db_fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(db_fd)
    
    conn = sqlite3.connect(db_path)
    
    # Create artifact_dependencies table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS artifact_dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_artifact_name TEXT NOT NULL,
            source_artifact_type TEXT NOT NULL,
            target_artifact_name TEXT NOT NULL,
            target_artifact_type TEXT NOT NULL,
            dependency_type TEXT NOT NULL,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    # Create program_file_mapping table (needed by ExternalConfigLoader)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT NOT NULL,
            language TEXT
        )
    """)
    
    # Create inventory table (needed by ExternalConfigLoader)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            artifact_name TEXT NOT NULL,
            artifact_type TEXT NOT NULL,
            file_path TEXT
        )
    """)
    
    # Create external_program_config table (needed by ExternalConfigLoader)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS external_program_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern TEXT NOT NULL UNIQUE,
            is_pattern INTEGER NOT NULL DEFAULT 0,
            reason TEXT,
            metadata TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create external_caller_config table (needed by ExternalConfigLoader)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS external_caller_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            caller_name TEXT NOT NULL,
            target_program TEXT NOT NULL,
            call_type TEXT,
            metadata_json TEXT,
            created_date DATE,
            UNIQUE(caller_name, target_program)
        )
    """)
    
    # Create interface tables
    schema_manager = InterfaceSchemaManager(conn)
    schema_manager.create_tables()
    
    conn.commit()
    return conn, db_path


def cleanup_test_database(conn, db_path):
    """Clean up test database."""
    conn.close()
    if os.path.exists(db_path):
        os.unlink(db_path)


@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(program_name_strategy, min_size=1, max_size=10, unique=True),
    codebase_programs=st.lists(program_name_strategy, min_size=0, max_size=20, unique=True),
    external_caller=program_name_strategy,
    target_program_idx=st.integers(min_value=0, max_value=9),
    dependency_type=dependency_type_strategy
)
def test_property_external_systems_create_inbound_interfaces(
    flow_programs,
    codebase_programs,
    external_caller,
    target_program_idx,
    dependency_type
):
    """
    Property 1: External Systems Create Inbound Interfaces
    
    For any program NOT in the codebase calling a flow program,
    an inbound interface should be created if it's in the inbound_interfaces table.
    
    **Feature: fix-inbound-interface-logic, Property 1: External Systems Create Inbound Interfaces**
    **Validates: Requirements 1.1**
    """
    # Ensure target_program_idx is valid
    assume(target_program_idx < len(flow_programs))
    
    # Ensure external_caller is NOT in codebase and NOT in flow
    assume(external_caller not in codebase_programs)
    assume(external_caller not in flow_programs)
    
    # Setup database
    conn, db_path = create_test_database()
    
    try:
        cursor = conn.cursor()
        
        # Insert codebase programs into artifact_dependencies
        for prog in codebase_programs:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'PROGRAM', 'DUMMY', 'PROGRAM', 'PROGRAM_CALL')
            """, (prog,))
        
        # Insert external caller into inbound_interfaces table
        target_program = flow_programs[target_program_idx]
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured, metadata)
            VALUES (?, ?, ?, 1, '{}')
        """, (external_caller, target_program, dependency_type))
        
        conn.commit()
        
        # Create flow builder
        builder = MigrationFlowBuilder(conn)
        
        # Create mock flow
        flow = ProgramFlow(
            start_program=flow_programs[0],
            depth=1,
            programs=list(flow_programs),
            dependencies=[]
        )
        flow.programs = set(flow_programs)
        
        # Identify inbound interfaces
        inbound_interfaces = builder._identify_inbound_interfaces(
            flow,
            flow_programs[0],
            set(flow_programs)
        )
        
        # Assert: Should have exactly one inbound interface
        assert len(inbound_interfaces) == 1, \
            f"Expected 1 inbound interface, got {len(inbound_interfaces)}"
        
        # Assert: Interface source should be external_caller
        assert inbound_interfaces[0]['source'] == external_caller, \
            f"Expected source {external_caller}, got {inbound_interfaces[0]['source']}"
        
        # Assert: Interface target should be target_program
        assert inbound_interfaces[0]['target'] == target_program, \
            f"Expected target {target_program}, got {inbound_interfaces[0]['target']}"
        
        # Assert: Interface type should match
        assert inbound_interfaces[0]['type'] == dependency_type, \
            f"Expected type {dependency_type}, got {inbound_interfaces[0]['type']}"
    
    finally:
        cleanup_test_database(conn, db_path)


@settings(max_examples=100, deadline=None, suppress_health_check=[HealthCheck.filter_too_much])
@given(
    flow_programs=st.lists(program_name_strategy, min_size=1, max_size=10, unique=True),
    codebase_programs=st.lists(program_name_strategy, min_size=1, max_size=20, unique=True),
    codebase_caller_idx=st.integers(min_value=0, max_value=19),
    target_program_idx=st.integers(min_value=0, max_value=9),
    dependency_type=dependency_type_strategy
)
def test_property_codebase_programs_excluded_from_inbound(
    flow_programs,
    codebase_programs,
    codebase_caller_idx,
    target_program_idx,
    dependency_type
):
    """
    Property 2: Codebase Programs Excluded from Inbound Interfaces
    
    For any program in the codebase (but not in the current flow) calling a flow program,
    no inbound interface should be created even if it's in the inbound_interfaces table.
    
    **Feature: fix-inbound-interface-logic, Property 2: Codebase Programs Excluded**
    **Validates: Requirements 1.2, 3.1, 5.1**
    """
    # Ensure indices are valid
    assume(codebase_caller_idx < len(codebase_programs))
    assume(target_program_idx < len(flow_programs))
    
    codebase_caller = codebase_programs[codebase_caller_idx]
    target_program = flow_programs[target_program_idx]
    
    # Ensure codebase_caller is NOT in flow
    assume(codebase_caller not in flow_programs)
    
    # Setup database
    conn, db_path = create_test_database()
    
    try:
        cursor = conn.cursor()
        
        # Insert codebase programs into artifact_dependencies
        for prog in codebase_programs:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
                VALUES (?, 'PROGRAM', 'DUMMY', 'PROGRAM', 'PROGRAM_CALL')
            """, (prog,))
        
        # Insert codebase caller into inbound_interfaces table (configured)
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured, metadata)
            VALUES (?, ?, ?, 1, '{}')
        """, (codebase_caller, target_program, dependency_type))
        
        conn.commit()
        
        # Create flow builder
        builder = MigrationFlowBuilder(conn)
        
        # Create mock flow
        flow = ProgramFlow(
            start_program=flow_programs[0],
            depth=1,
            programs=list(flow_programs),
            dependencies=[]
        )
        flow.programs = set(flow_programs)
        
        # Identify inbound interfaces
        inbound_interfaces = builder._identify_inbound_interfaces(
            flow,
            flow_programs[0],
            set(flow_programs)
        )
        
        # Assert: Should have NO inbound interfaces (codebase program filtered out)
        assert len(inbound_interfaces) == 0, \
            f"Expected 0 inbound interfaces for codebase caller, got {len(inbound_interfaces)}"
    
    finally:
        cleanup_test_database(conn, db_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])



@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(program_name_strategy, min_size=2, max_size=10, unique=True),
    external_callers=st.lists(
        st.tuples(program_name_strategy, st.integers(min_value=0, max_value=9), dependency_type_strategy),
        min_size=1,
        max_size=5,
        unique_by=lambda x: (x[0], x[1])  # Unique by (caller, target_idx)
    )
)
def test_property_configured_external_callers_always_create_inbound(
    flow_programs,
    external_callers
):
    """
    Property 3: Configured External Callers Always Create Inbound Interfaces
    
    For any configured external caller, when it targets a program in a flow,
    an inbound interface should be created regardless of whether the target is
    an entry point or whether the caller is in the codebase.
    
    **Feature: fix-inbound-interface-logic, Property 3: Configured External Callers**
    **Validates: Requirements 2.1, 2.2**
    """
    # Ensure all target indices are valid
    for caller, target_idx, _ in external_callers:
        assume(target_idx < len(flow_programs))
    
    # Ensure all callers are unique and not in flow
    caller_names = [caller for caller, _, _ in external_callers]
    assume(len(set(caller_names)) == len(caller_names))  # All unique
    for caller in caller_names:
        assume(caller not in flow_programs)
    
    # Setup database
    conn, db_path = create_test_database()
    
    try:
        cursor = conn.cursor()
        
        # Insert configured external callers into inbound_interfaces table
        for caller_name, target_idx, dep_type in external_callers:
            target_program = flow_programs[target_idx]
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured, metadata)
                VALUES (?, ?, ?, 1, '{}')
            """, (caller_name, target_program, dep_type))
        
        conn.commit()
        
        # Create flow builder
        builder = MigrationFlowBuilder(conn)
        
        # Create mock flow
        flow = ProgramFlow(
            start_program=flow_programs[0],
            depth=1,
            programs=list(flow_programs),
            dependencies=[]
        )
        flow.programs = set(flow_programs)
        
        # Identify inbound interfaces
        inbound_interfaces = builder._identify_inbound_interfaces(
            flow,
            flow_programs[0],
            set(flow_programs)
        )
        
        # Assert: Should have exactly as many inbound interfaces as configured callers
        assert len(inbound_interfaces) == len(external_callers), \
            f"Expected {len(external_callers)} inbound interfaces, got {len(inbound_interfaces)}"
        
        # Assert: All configured callers should be present
        interface_sources = {iface['source'] for iface in inbound_interfaces}
        expected_sources = {caller for caller, _, _ in external_callers}
        assert interface_sources == expected_sources, \
            f"Expected sources {expected_sources}, got {interface_sources}"
    
    finally:
        cleanup_test_database(conn, db_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])



@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(program_name_strategy, min_size=1, max_size=10, unique=True),
    external_caller=program_name_strategy,
    target_program_idx=st.integers(min_value=0, max_value=9),
    dependency_type=dependency_type_strategy,
    metadata=metadata_strategy
)
def test_property_metadata_preservation_for_configured_callers(
    flow_programs,
    external_caller,
    target_program_idx,
    dependency_type,
    metadata
):
    """
    Property 4: Metadata Preservation for Configured Callers
    
    For any configured external caller with metadata, when an inbound interface
    is created, the system should preserve all metadata fields in the inbound
    interface record.
    
    **Feature: fix-inbound-interface-logic, Property 4: Metadata Preservation**
    **Validates: Requirements 2.3**
    """
    # Ensure target_program_idx is valid
    assume(target_program_idx < len(flow_programs))
    
    # Ensure external_caller is NOT in flow
    assume(external_caller not in flow_programs)
    
    # Setup database
    conn, db_path = create_test_database()
    
    try:
        cursor = conn.cursor()
        
        # Insert external caller into inbound_interfaces table with metadata
        target_program = flow_programs[target_program_idx]
        metadata_json = json.dumps(metadata)
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured, metadata)
            VALUES (?, ?, ?, 1, ?)
        """, (external_caller, target_program, dependency_type, metadata_json))
        
        conn.commit()
        
        # Create flow builder
        builder = MigrationFlowBuilder(conn)
        
        # Create mock flow
        flow = ProgramFlow(
            start_program=flow_programs[0],
            depth=1,
            programs=list(flow_programs),
            dependencies=[]
        )
        flow.programs = set(flow_programs)
        
        # Identify inbound interfaces
        inbound_interfaces = builder._identify_inbound_interfaces(
            flow,
            flow_programs[0],
            set(flow_programs)
        )
        
        # Assert: Should have exactly one inbound interface
        assert len(inbound_interfaces) == 1, \
            f"Expected 1 inbound interface, got {len(inbound_interfaces)}"
        
        # Assert: Metadata should be preserved
        interface_metadata = inbound_interfaces[0]['metadata']
        
        # Check that all metadata fields are preserved
        for key, value in metadata.items():
            assert key in interface_metadata, \
                f"Expected metadata key '{key}' not found in interface metadata"
            assert interface_metadata[key] == value, \
                f"Expected metadata['{key}'] = {value}, got {interface_metadata[key]}"
    
    finally:
        cleanup_test_database(conn, db_path)
