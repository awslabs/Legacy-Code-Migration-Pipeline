"""Unit tests for metadata file scanner."""

import pytest
import tempfile
import os
from pathlib import Path
from tools.legacy_analyzer.metadata.scanner import (
    MetadataFileScanner,
    MetadataFiles
)


class TestMetadataFiles:
    """Test MetadataFiles data class."""
    
    def test_create_empty_metadata_files(self):
        """Test creating empty MetadataFiles."""
        metadata = MetadataFiles()
        
        assert len(metadata.csd_files) == 0
        assert len(metadata.csv_files) == 0
        assert len(metadata.other_files) == 0
        assert metadata.get_file_count() == 0
    
    def test_metadata_files_with_data(self):
        """Test MetadataFiles with data."""
        metadata = MetadataFiles(
            csd_files=['file1.csd', 'file2.csd'],
            csv_files=['file1.csv'],
            other_files=['file1.txt']
        )
        
        assert len(metadata.csd_files) == 2
        assert len(metadata.csv_files) == 1
        assert len(metadata.other_files) == 1
        assert metadata.get_file_count() == 4
    
    def test_get_all_files(self):
        """Test get_all_files method."""
        metadata = MetadataFiles(
            csd_files=['file1.csd', 'file2.csd'],
            csv_files=['file1.csv'],
            other_files=['file1.txt']
        )
        
        all_files = metadata.get_all_files()
        assert len(all_files) == 4
        assert 'file1.csd' in all_files
        assert 'file2.csd' in all_files
        assert 'file1.csv' in all_files
        assert 'file1.txt' in all_files
    
    def test_metadata_files_str(self):
        """Test string representation."""
        metadata = MetadataFiles(
            csd_files=['file1.csd', 'file2.csd'],
            csv_files=['file1.csv']
        )
        
        str_repr = str(metadata)
        assert 'csd=2' in str_repr
        assert 'csv=1' in str_repr
        assert 'other=0' in str_repr


class TestMetadataFileScanner:
    """Test MetadataFileScanner class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.scanner = MetadataFileScanner()
        self.temp_dir = tempfile.mkdtemp()
    
    def teardown_method(self):
        """Clean up test fixtures."""
        # Clean up temp directory
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def create_test_file(self, filename, content=''):
        """Helper to create a test file."""
        filepath = os.path.join(self.temp_dir, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w') as f:
            f.write(content)
        return filepath
    
    def test_scanner_initialization(self):
        """Test scanner initialization."""
        scanner = MetadataFileScanner()
        
        assert scanner.csd_extensions == {'.csd'}
        assert scanner.csv_extensions == {'.csv'}
        assert len(scanner.cics_csv_patterns) > 0
        assert len(scanner.skip_dirs) > 0
    
    def test_scan_empty_directory(self):
        """Test scanning an empty directory."""
        metadata = self.scanner.scan_directory(self.temp_dir)
        
        assert metadata.get_file_count() == 0
    
    def test_scan_directory_not_found(self):
        """Test scanning a non-existent directory."""
        with pytest.raises(FileNotFoundError):
            self.scanner.scan_directory('/nonexistent/directory')
    
    def test_scan_directory_not_a_directory(self):
        """Test scanning a file instead of directory."""
        test_file = self.create_test_file('test.txt', 'content')
        
        with pytest.raises(NotADirectoryError):
            self.scanner.scan_directory(test_file)
    
    def test_scan_single_csd_file(self):
        """Test scanning directory with single CSD file."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
"""
        self.create_test_file('test.csd', csd_content)
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=False)
        
        assert len(metadata.csd_files) == 1
        assert metadata.csd_files[0].endswith('test.csd')
    
    def test_scan_single_csv_file(self):
        """Test scanning directory with single CSV file."""
        csv_content = "resource_name,resource_type,group_name,status\n"
        self.create_test_file('cics_inventory.csv', csv_content)
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=False)
        
        assert len(metadata.csv_files) == 1
        assert metadata.csv_files[0].endswith('cics_inventory.csv')
    
    def test_scan_multiple_files(self):
        """Test scanning directory with multiple files."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        csv_content = "resource_name,resource_type\n"
        
        self.create_test_file('file1.csd', csd_content)
        self.create_test_file('file2.csd', csd_content)
        self.create_test_file('inventory.csv', csv_content)
        self.create_test_file('readme.txt', 'text')
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=False)
        
        assert len(metadata.csd_files) == 2
        assert len(metadata.csv_files) == 1
    
    def test_scan_recursive(self):
        """Test recursive directory scanning."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        
        self.create_test_file('root.csd', csd_content)
        self.create_test_file('subdir/sub.csd', csd_content)
        self.create_test_file('subdir/nested/deep.csd', csd_content)
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=True)
        
        assert len(metadata.csd_files) == 3
    
    def test_scan_non_recursive(self):
        """Test non-recursive directory scanning."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        
        self.create_test_file('root.csd', csd_content)
        self.create_test_file('subdir/sub.csd', csd_content)
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=False)
        
        assert len(metadata.csd_files) == 1
        assert metadata.csd_files[0].endswith('root.csd')
    
    def test_scan_skip_hidden_files(self):
        """Test that hidden files are skipped."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        
        self.create_test_file('visible.csd', csd_content)
        self.create_test_file('.hidden.csd', csd_content)
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=False)
        
        assert len(metadata.csd_files) == 1
        assert metadata.csd_files[0].endswith('visible.csd')
    
    def test_scan_skip_pycache_directory(self):
        """Test that __pycache__ directories are skipped."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        
        self.create_test_file('root.csd', csd_content)
        self.create_test_file('__pycache__/cache.csd', csd_content)
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=True)
        
        assert len(metadata.csd_files) == 1
        assert '__pycache__' not in metadata.csd_files[0]
    
    def test_scan_skip_git_directory(self):
        """Test that .git directories are skipped."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        
        self.create_test_file('root.csd', csd_content)
        self.create_test_file('.git/config.csd', csd_content)
        
        metadata = self.scanner.scan_directory(self.temp_dir, recursive=True)
        
        assert len(metadata.csd_files) == 1
        assert '.git' not in metadata.csd_files[0]
    
    def test_scan_with_file_type_filter_csd(self):
        """Test scanning with CSD file type filter."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        csv_content = "resource_name,resource_type\n"
        
        self.create_test_file('test.csd', csd_content)
        self.create_test_file('test.csv', csv_content)
        
        metadata = self.scanner.scan_directory(
            self.temp_dir,
            recursive=False,
            file_types={'csd'}
        )
        
        assert len(metadata.csd_files) == 1
        assert len(metadata.csv_files) == 0
    
    def test_scan_with_file_type_filter_csv(self):
        """Test scanning with CSV file type filter."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        csv_content = "resource_name,resource_type\n"
        
        self.create_test_file('test.csd', csd_content)
        self.create_test_file('test.csv', csv_content)
        
        metadata = self.scanner.scan_directory(
            self.temp_dir,
            recursive=False,
            file_types={'csv'}
        )
        
        assert len(metadata.csd_files) == 0
        assert len(metadata.csv_files) == 1
    
    def test_scan_with_file_type_filter_all(self):
        """Test scanning with 'all' file type filter."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        csv_content = "resource_name,resource_type\n"
        
        self.create_test_file('test.csd', csd_content)
        self.create_test_file('test.csv', csv_content)
        
        metadata = self.scanner.scan_directory(
            self.temp_dir,
            recursive=False,
            file_types={'all'}
        )
        
        assert len(metadata.csd_files) == 1
        assert len(metadata.csv_files) == 1
    
    def test_scan_with_pattern_filter(self):
        """Test scanning with glob pattern filter."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        
        self.create_test_file('CARDDEMO.csd', csd_content)
        self.create_test_file('OTHER.csd', csd_content)
        
        metadata = self.scanner.scan_directory(
            self.temp_dir,
            recursive=False,
            patterns=['CARDDEMO.*']
        )
        
        assert len(metadata.csd_files) == 1
        assert 'CARDDEMO.csd' in metadata.csd_files[0]
    
    def test_scan_with_multiple_patterns(self):
        """Test scanning with multiple glob patterns."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        csv_content = "resource_name,resource_type\n"
        
        self.create_test_file('CARDDEMO.csd', csd_content)
        self.create_test_file('OTHER.csd', csd_content)
        self.create_test_file('cics_inventory.csv', csv_content)
        self.create_test_file('other.csv', csv_content)
        
        metadata = self.scanner.scan_directory(
            self.temp_dir,
            recursive=False,
            patterns=['CARDDEMO.*', '*cics*.csv']
        )
        
        assert len(metadata.csd_files) == 1
        assert len(metadata.csv_files) == 1
        assert 'CARDDEMO.csd' in metadata.csd_files[0]
        assert 'cics_inventory.csv' in metadata.csv_files[0]
    
    def test_scan_case_insensitive_patterns(self):
        """Test that pattern matching is case-insensitive."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        
        self.create_test_file('CARDDEMO.CSD', csd_content)
        
        metadata = self.scanner.scan_directory(
            self.temp_dir,
            recursive=False,
            patterns=['*.csd']
        )
        
        assert len(metadata.csd_files) == 1


class TestFileTypeIdentification:
    """Test file type identification."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.scanner = MetadataFileScanner()
        self.temp_dir = tempfile.mkdtemp()
    
    def teardown_method(self):
        """Clean up test fixtures."""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def create_test_file(self, filename, content=''):
        """Helper to create a test file."""
        filepath = os.path.join(self.temp_dir, filename)
        with open(filepath, 'w') as f:
            f.write(content)
        return filepath
    
    def test_identify_csd_by_extension(self):
        """Test identifying CSD file by extension."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        filepath = self.create_test_file('test.csd', csd_content)
        
        file_type = self.scanner.identify_file_type(filepath)
        assert file_type == 'csd'
    
    def test_identify_csv_by_extension(self):
        """Test identifying CSV file by extension."""
        csv_content = "resource_name,resource_type\n"
        filepath = self.create_test_file('test.csv', csv_content)
        
        file_type = self.scanner.identify_file_type(filepath)
        assert file_type == 'csv'
    
    def test_identify_cics_csv_by_filename(self):
        """Test identifying CICS CSV by filename pattern."""
        csv_content = "resource_name,resource_type\n"
        filepath = self.create_test_file('cics_inventory.csv', csv_content)
        
        file_type = self.scanner.identify_file_type(filepath)
        assert file_type == 'csv'
    
    def test_identify_csd_by_content(self):
        """Test identifying CSD file by content."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
"""
        filepath = self.create_test_file('noextension', csd_content)
        
        file_type = self.scanner.identify_file_type(filepath)
        assert file_type == 'csd'
    
    def test_identify_csv_by_content(self):
        """Test identifying CICS CSV by content."""
        csv_content = "resource_name,resource_type,transaction,program\n"
        filepath = self.create_test_file('noextension', csv_content)
        
        file_type = self.scanner.identify_file_type(filepath)
        assert file_type == 'csv'
    
    def test_identify_other_file_type(self):
        """Test identifying non-metadata file."""
        content = "This is just a text file"
        filepath = self.create_test_file('readme.txt', content)
        
        file_type = self.scanner.identify_file_type(filepath)
        assert file_type == 'other'
    
    def test_validate_csd_content_with_define_transaction(self):
        """Test CSD content validation with DEFINE TRANSACTION."""
        csd_content = " DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)"
        filepath = self.create_test_file('test.txt', csd_content)
        
        is_valid = self.scanner._validate_csd_content(filepath)
        assert is_valid is True
    
    def test_validate_csd_content_with_define_program(self):
        """Test CSD content validation with DEFINE PROGRAM."""
        csd_content = " DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)"
        filepath = self.create_test_file('test.txt', csd_content)
        
        is_valid = self.scanner._validate_csd_content(filepath)
        assert is_valid is True
    
    def test_validate_csd_content_with_define_file(self):
        """Test CSD content validation with DEFINE FILE."""
        csd_content = " DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)"
        filepath = self.create_test_file('test.txt', csd_content)
        
        is_valid = self.scanner._validate_csd_content(filepath)
        assert is_valid is True
    
    def test_validate_csd_content_with_define_mapset(self):
        """Test CSD content validation with DEFINE MAPSET."""
        csd_content = " DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)"
        filepath = self.create_test_file('test.txt', csd_content)
        
        is_valid = self.scanner._validate_csd_content(filepath)
        assert is_valid is True
    
    def test_validate_csd_content_case_insensitive(self):
        """Test CSD content validation is case-insensitive."""
        csd_content = " define transaction(CAUP) group(CARDDEMO)"
        filepath = self.create_test_file('test.txt', csd_content)
        
        is_valid = self.scanner._validate_csd_content(filepath)
        assert is_valid is True
    
    def test_validate_csd_content_invalid(self):
        """Test CSD content validation with invalid content."""
        content = "This is not a CSD file"
        filepath = self.create_test_file('test.txt', content)
        
        is_valid = self.scanner._validate_csd_content(filepath)
        assert is_valid is False
    
    def test_validate_csv_content_with_resource_name(self):
        """Test CSV content validation with resource_name header."""
        csv_content = "resource_name,resource_type,group_name\n"
        filepath = self.create_test_file('test.txt', csv_content)
        
        is_valid = self.scanner._validate_csv_content(filepath)
        assert is_valid is True
    
    def test_validate_csv_content_with_transaction(self):
        """Test CSV content validation with transaction header."""
        csv_content = "transaction,program,status\n"
        filepath = self.create_test_file('test.txt', csv_content)
        
        is_valid = self.scanner._validate_csv_content(filepath)
        assert is_valid is True
    
    def test_validate_csv_content_with_cics(self):
        """Test CSV content validation with cics in header."""
        csv_content = "cics_resource,type,group\n"
        filepath = self.create_test_file('test.txt', csv_content)
        
        is_valid = self.scanner._validate_csv_content(filepath)
        assert is_valid is True
    
    def test_validate_csv_content_invalid(self):
        """Test CSV content validation with invalid content."""
        content = "name,value,description\n"
        filepath = self.create_test_file('test.txt', content)
        
        is_valid = self.scanner._validate_csv_content(filepath)
        assert is_valid is False
    
    def test_is_cics_csv_with_cics_pattern(self):
        """Test CICS CSV filename pattern matching."""
        assert self.scanner._is_cics_csv('cics_inventory.csv') is True
        assert self.scanner._is_cics_csv('CICS_INVENTORY.CSV') is True
        assert self.scanner._is_cics_csv('inventory.csv') is True
        assert self.scanner._is_cics_csv('transactions.csv') is True
    
    def test_is_cics_csv_without_pattern(self):
        """Test non-CICS CSV filename."""
        assert self.scanner._is_cics_csv('data.csv') is False
        assert self.scanner._is_cics_csv('report.csv') is False


class TestFilterAndUtilities:
    """Test filter and utility methods."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.scanner = MetadataFileScanner()
    
    def test_filter_by_pattern(self):
        """Test filtering files by pattern."""
        files = [
            '/path/to/CARDDEMO.csd',
            '/path/to/OTHER.csd',
            '/path/to/TEST.csd'
        ]
        
        filtered = self.scanner.filter_by_pattern(files, 'CARDDEMO.*')
        
        assert len(filtered) == 1
        assert 'CARDDEMO.csd' in filtered[0]
    
    def test_filter_by_pattern_wildcard(self):
        """Test filtering with wildcard pattern."""
        files = [
            '/path/to/file1.csd',
            '/path/to/file2.csd',
            '/path/to/file.txt'
        ]
        
        filtered = self.scanner.filter_by_pattern(files, '*.csd')
        
        assert len(filtered) == 2
    
    def test_filter_by_pattern_no_matches(self):
        """Test filtering with no matches."""
        files = [
            '/path/to/file1.csd',
            '/path/to/file2.csd'
        ]
        
        filtered = self.scanner.filter_by_pattern(files, '*.csv')
        
        assert len(filtered) == 0
    
    def test_get_file_info(self):
        """Test getting file information."""
        temp_dir = tempfile.mkdtemp()
        try:
            filepath = os.path.join(temp_dir, 'test.csd')
            with open(filepath, 'w') as f:
                f.write(' DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)')
            
            info = self.scanner.get_file_info(filepath)
            
            assert info['path'] == filepath
            assert info['name'] == 'test.csd'
            assert info['type'] == 'csd'
            assert info['size'] > 0
            assert 'modified' in info
            assert info['directory'] == temp_dir
        finally:
            import shutil
            shutil.rmtree(temp_dir)
    
    def test_get_file_info_nonexistent(self):
        """Test getting info for nonexistent file."""
        info = self.scanner.get_file_info('/nonexistent/file.csd')
        
        assert 'error' in info
        assert info['path'] == '/nonexistent/file.csd'
    
    def test_should_skip_file_hidden(self):
        """Test skipping hidden files."""
        assert self.scanner._should_skip_file('.hidden') is True
        assert self.scanner._should_skip_file('visible') is False
    
    def test_should_skip_file_pyc(self):
        """Test skipping Python bytecode files."""
        assert self.scanner._should_skip_file('module.pyc') is True
        assert self.scanner._should_skip_file('module.py') is False
    
    def test_should_skip_file_backup(self):
        """Test skipping backup files."""
        assert self.scanner._should_skip_file('file.txt~') is True
        assert self.scanner._should_skip_file('file.txt') is False
    
    def test_matches_any_pattern(self):
        """Test pattern matching helper."""
        patterns = ['*.csd', '*cics*.csv']
        
        assert self.scanner._matches_any_pattern('test.csd', patterns) is True
        assert self.scanner._matches_any_pattern('cics_inv.csv', patterns) is True
        assert self.scanner._matches_any_pattern('data.txt', patterns) is False
    
    def test_matches_any_pattern_case_insensitive(self):
        """Test case-insensitive pattern matching."""
        patterns = ['*.csd']
        
        assert self.scanner._matches_any_pattern('TEST.CSD', patterns) is True
        assert self.scanner._matches_any_pattern('test.csd', patterns) is True


class TestRealWorldScenarios:
    """Test real-world scanning scenarios."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.scanner = MetadataFileScanner()
    
    def test_scan_carddemo_directory(self):
        """Test scanning actual CARDDEMO directory if it exists."""
        carddemo_dir = 'examples/code/cobol/carddemoV2'
        
        if os.path.exists(carddemo_dir):
            metadata = self.scanner.scan_directory(carddemo_dir, recursive=True)
            
            # Should find at least one CSD file
            assert len(metadata.csd_files) > 0
            
            # Check that CARDDEMO.csd is found
            carddemo_csd = [f for f in metadata.csd_files if 'CARDDEMO.csd' in f]
            assert len(carddemo_csd) == 1
    
    def test_scan_examples_directory(self):
        """Test scanning examples directory if it exists."""
        examples_dir = 'examples'
        
        if os.path.exists(examples_dir):
            metadata = self.scanner.scan_directory(
                examples_dir,
                recursive=True,
                file_types={'csd', 'csv'}
            )
            
            # Should find some files
            assert metadata.get_file_count() >= 0
    
    def test_scan_with_csd_pattern_only(self):
        """Test scanning for CSD files only."""
        examples_dir = 'examples'
        
        if os.path.exists(examples_dir):
            metadata = self.scanner.scan_directory(
                examples_dir,
                recursive=True,
                patterns=['*.csd']
            )
            
            # All found files should be CSD files
            for csd_file in metadata.csd_files:
                assert csd_file.endswith('.csd') or csd_file.endswith('.CSD')
