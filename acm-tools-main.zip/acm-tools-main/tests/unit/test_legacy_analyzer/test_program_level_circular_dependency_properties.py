"""Property-based tests for program-level circular dependency detection.

**Feature: program-level-dependency-tracking, Property 8: Program-level circular dependency detection**
**Validates: Requirements 4.2**
"""

import pytest
import sqlite3
import tempfile
import os
from hypothesis import given, strategies as st, settings, assume
from typing import List, Dict, Set

from tools.legacy_analyzer.models.dependency import Dependency, CircularDependency, DependencyType
from tools.legacy_analyzer.analysis.circular_detector import CircularDependencyDetector
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Strategy for generating valid program names
program_names = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), min_codepoint=65, max_codepoint=90),
    min_size=4,
    max_size=8
).map(lambda x: x.upper())

# Strategy for generating dependency types that can form cycles
cycle_dependency_types = st.sampled_from([
    DependencyType.CALL,
    DependencyType.CICS_LINK,
    DependencyType.CICS_START,
    DependencyType.EXEC_PGM
])

# Strategy for generating program types
program_types = st.sampled_from(list(ProgramType))

# Strategy for generating languages
languages = st.sampled_from(['COBOL', 'PLI', 'NATURAL', 'REXX', 'RPG', 'ASM'])


@st.composite
def program_boundary_strategy(draw):
    """Generate a valid ProgramBoundary."""
    name = draw(program_names)
    start_line = draw(st.integers(min_value=1, max_value=100))
    end_line = draw(st.integers(min_value=start_line, max_value=start_line + 50))
    prog_type = draw(program_types)
    language = draw(languages)
    entry_points = draw(st.lists(program_names, min_size=0, max_size=3))
    
    return ProgramBoundary(
        program_name=name,
        start_line=start_line,
        end_line=end_line,
        program_type=prog_type,
        language=language,
        entry_points=entry_points
    )


@st.composite
def program_dependency_strategy(draw):
    """Generate a valid program-level Dependency."""
    source = draw(program_names)
    target = draw(program_names)
    assume(source != target)  # No self-dependencies
    
    dep_type = draw(cycle_dependency_types)
    source_lang = draw(languages)
    target_lang = draw(languages)
    line_num = draw(st.integers(min_value=1, max_value=100))
    
    return Dependency(
        source_artifact=source,
        source_type='PROGRAM',
        target_artifact=target,
        target_type='PROGRAM',
        dependency_type=dep_type,
        source_language=source_lang,
        target_language=target_lang,
        line_number=line_num
    )


@st.composite
def circular_dependency_chain_strategy(draw, min_length=2, max_length=5):
    """Generate a circular dependency chain."""
    chain_length = draw(st.integers(min_value=min_length, max_value=max_length))
    programs = draw(st.lists(program_names, min_size=chain_length, max_size=chain_length, unique=True))
    
    # Create circular dependencies: A -> B -> C -> A
    dependencies = []
    for i in range(len(programs)):
        source = programs[i]
        target = programs[(i + 1) % len(programs)]
        dep_type = draw(cycle_dependency_types)
        
        dependency = Dependency(
            source_artifact=source,
            source_type='PROGRAM',
            target_artifact=target,
            target_type='PROGRAM',
            dependency_type=dep_type,
            source_language=draw(languages),
            target_language=draw(languages),
            line_number=draw(st.integers(min_value=1, max_value=100))
        )
        dependencies.append(dependency)
    
    return dependencies, programs


@st.composite
def program_file_mapping_strategy(draw, programs: List[str]):
    """Generate program-file mappings for a list of programs."""
    # Group programs into files (some files may have multiple programs)
    file_paths = draw(st.lists(
        st.text(alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), min_codepoint=65, max_codepoint=90),
                min_size=5, max_size=10).map(lambda x: f"/src/{x.lower()}.cbl"),
        min_size=1,
        max_size=max(1, len(programs) // 2 + 1)
    ))
    
    mappings = []
    current_line = 1
    
    for i, program in enumerate(programs):
        file_path = draw(st.sampled_from(file_paths))
        start_line = current_line
        end_line = current_line + draw(st.integers(min_value=10, max_value=50))
        current_line = end_line + 1
        
        mapping = {
            'program_name': program,
            'file_path': file_path,
            'start_line': start_line,
            'end_line': end_line,
            'program_type': draw(program_types).value,
            'language': draw(languages)
        }
        mappings.append(mapping)
    
    return mappings


def create_test_database_with_mappings(mappings: List[Dict]) -> sqlite3.Connection:
    """Create a test database with program-file mappings."""
    # Create temporary database
    db_fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(db_fd)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE program_file_mapping (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT NOT NULL,
            program_name VARCHAR(44) NOT NULL,
            program_index INTEGER NOT NULL,
            start_line INTEGER NOT NULL,
            end_line INTEGER NOT NULL,
            program_type VARCHAR(20) NOT NULL,
            language VARCHAR(20) NOT NULL,
            entry_points TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(file_path, program_name)
        )
    """)
    
    # Insert mappings
    for mapping in mappings:
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (file_path, program_name, program_index, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            mapping['file_path'],
            mapping['program_name'],
            0,  # program_index
            mapping['start_line'],
            mapping['end_line'],
            mapping['program_type'],
            mapping['language']
        ))
    
    conn.commit()
    return conn


class TestProgramLevelCircularDependencyProperties:
    """Property-based tests for program-level circular dependency detection."""
    
    @given(circular_dependency_chain_strategy())
    @settings(max_examples=100)
    def test_circular_dependency_detection_accuracy(self, chain_data):
        """
        **Feature: program-level-dependency-tracking, Property 8: Program-level circular dependency detection**
        **Validates: Requirements 4.2**
        
        Property: For any set of programs with circular dependencies, 
        the detector should identify cycles at the program level within and across files.
        """
        dependencies, expected_programs = chain_data
        
        # Create detector
        detector = CircularDependencyDetector(dependencies)
        
        # Detect cycles
        cycles = detector.detect_all_cycles()
        
        # Property: Should detect at least one cycle
        assert len(cycles) > 0, "Should detect circular dependencies when they exist"
        
        # Property: Detected cycle should contain the expected programs
        cycle = cycles[0]  # Get first detected cycle
        detected_programs = set(cycle.artifacts)
        expected_programs_set = set(expected_programs)
        
        # The detected cycle should be a subset of or equal to the expected programs
        # (it might detect a smaller cycle within the larger one)
        assert detected_programs.issubset(expected_programs_set) or detected_programs == expected_programs_set, \
            f"Detected programs {detected_programs} should be subset of expected {expected_programs_set}"
        
        # Property: Cycle should have valid dependency types
        assert len(cycle.dependency_types) == len(cycle.artifacts), \
            "Each program in cycle should have a corresponding dependency type"
        
        # Property: All dependency types should be valid call types
        valid_call_types = {DependencyType.CALL, DependencyType.CICS_LINK, DependencyType.CICS_START, DependencyType.EXEC_PGM}
        for dep_type in cycle.dependency_types:
            assert dep_type in valid_call_types, f"Dependency type {dep_type} should be a valid call type"
    
    @given(st.lists(program_dependency_strategy(), min_size=1, max_size=20))
    @settings(max_examples=100)
    def test_no_false_positive_cycles(self, dependencies):
        """
        Property: For any set of non-circular dependencies, 
        the detector should not report false positive cycles.
        """
        # Filter out any accidental cycles by ensuring no program calls back to itself transitively
        filtered_deps = []
        program_calls = {}
        
        for dep in dependencies:
            source = dep.source_artifact
            target = dep.target_artifact
            
            if source not in program_calls:
                program_calls[source] = set()
            
            # Only add if it doesn't create an immediate cycle
            if target not in program_calls or source not in program_calls[target]:
                program_calls[source].add(target)
                filtered_deps.append(dep)
        
        if not filtered_deps:
            return  # Skip if no valid dependencies
        
        detector = CircularDependencyDetector(filtered_deps)
        cycles = detector.detect_all_cycles()
        
        # Verify any detected cycles are actually valid
        for cycle in cycles:
            # Check that each program in the cycle actually calls the next one
            for i, program in enumerate(cycle.artifacts):
                next_program = cycle.artifacts[(i + 1) % len(cycle.artifacts)]
                
                # Find the dependency
                found_dep = False
                for dep in filtered_deps:
                    if dep.source_artifact == program and dep.target_artifact == next_program:
                        found_dep = True
                        break
                
                assert found_dep, f"Cycle claims {program} calls {next_program} but no such dependency exists"
    
    @given(circular_dependency_chain_strategy(), st.data())
    @settings(max_examples=50)
    def test_program_level_cycle_reporting_with_file_locations(self, chain_data, data):
        """
        Property: For any circular dependency, the detector should provide 
        accurate file location information when program-file mappings are available.
        """
        dependencies, programs = chain_data
        
        # Generate program-file mappings
        mappings = data.draw(program_file_mapping_strategy(programs))
        
        # Create test database with mappings
        db_conn = create_test_database_with_mappings(mappings)
        
        try:
            # Create detector with database connection
            detector = CircularDependencyDetector(dependencies, db_conn)
            
            # Detect cycles
            cycles = detector.detect_all_cycles()
            assert len(cycles) > 0, "Should detect cycles"
            
            # Generate detailed report for first cycle
            cycle = cycles[0]
            report = detector.generate_program_level_cycle_report(cycle)
            
            # Property: Report should contain file location information
            assert 'file_summary' in report, "Report should contain file summary"
            assert 'program_details' in report, "Report should contain program details"
            
            # Property: Each program should have location information
            for program_detail in report['program_details']:
                program_name = program_detail['program_name']
                
                # Find corresponding mapping
                mapping = next((m for m in mappings if m['program_name'] == program_name), None)
                if mapping:
                    assert program_detail['file_path'] == mapping['file_path'], \
                        f"File path should match mapping for {program_name}"
                    assert program_detail['start_line'] == mapping['start_line'], \
                        f"Start line should match mapping for {program_name}"
                    assert program_detail['end_line'] == mapping['end_line'], \
                        f"End line should match mapping for {program_name}"
            
            # Property: File summary should be accurate
            file_summary = report['file_summary']
            expected_files = {m['file_path'] for m in mappings if m['program_name'] in cycle.artifacts}
            actual_files = set(file_summary['files'])
            
            assert actual_files == expected_files, \
                f"File summary should list all files containing cycle programs"
            
            # Property: Cycle type classification should be correct
            within_file_cycles = detector.detect_cycles_within_files()
            across_file_cycles = detector.detect_cycles_across_files()
            
            total_detected_cycles = len(within_file_cycles) + len(across_file_cycles)
            assert total_detected_cycles >= len(cycles), \
                "Sum of within-file and across-file cycles should account for all detected cycles"
        
        finally:
            db_conn.close()
            # Clean up temporary database file
            try:
                os.unlink(db_conn.execute("PRAGMA database_list").fetchone()[2])
            except:
                pass
    
    @given(circular_dependency_chain_strategy(min_length=2, max_length=4))
    @settings(max_examples=50)
    def test_cycle_validation_accuracy(self, chain_data):
        """
        Property: For any detected circular dependency, the validation should 
        accurately verify the existence and correctness of each dependency in the cycle.
        """
        dependencies, programs = chain_data
        
        detector = CircularDependencyDetector(dependencies)
        cycles = detector.detect_all_cycles()
        
        assert len(cycles) > 0, "Should detect cycles"
        
        # Validate each detected cycle
        for cycle in cycles:
            validation = detector._validate_cycle_accuracy(cycle)
            
            # Property: Validation should check all dependencies in the cycle
            assert len(validation['dependency_validation']) == len(cycle.artifacts), \
                "Should validate each dependency in the cycle"
            
            # Property: Each dependency should be found in the original dependency list
            for dep_val in validation['dependency_validation']:
                if dep_val['actual_dependency_found']:
                    # Find the actual dependency
                    found = False
                    for dep in dependencies:
                        if (dep.source_artifact == dep_val['source_program'] and
                            dep.target_artifact == dep_val['target_program']):
                            found = True
                            break
                    assert found, f"Validated dependency should exist in original list"
            
            # Property: If all dependencies are found, cycle should be valid
            all_deps_found = all(dv['actual_dependency_found'] for dv in validation['dependency_validation'])
            if all_deps_found:
                assert validation['is_valid'], "Cycle should be valid if all dependencies are found"
    
    @given(st.lists(circular_dependency_chain_strategy(), min_size=1, max_size=3))
    @settings(max_examples=30)
    def test_cycle_statistics_accuracy(self, multiple_chains):
        """
        Property: For any set of circular dependencies, the statistics should 
        accurately count and categorize all cycles.
        """
        # Flatten all dependencies from multiple chains
        all_dependencies = []
        all_programs = set()
        
        for chain_deps, chain_programs in multiple_chains:
            all_dependencies.extend(chain_deps)
            all_programs.update(chain_programs)
        
        if not all_dependencies:
            return  # Skip empty case
        
        detector = CircularDependencyDetector(all_dependencies)
        
        # Get statistics
        stats = detector.get_cycle_statistics()
        cycles = detector.detect_all_cycles()
        
        # Property: Total cycles should match detected cycles
        assert stats['total_cycles'] == len(cycles), \
            "Statistics should report correct total cycle count"
        
        # Property: Within-file + across-file cycles should sum to total
        within_file = stats['within_file_cycles']
        across_file = stats['across_file_cycles']
        assert within_file + across_file == stats['total_cycles'], \
            "Within-file and across-file cycles should sum to total"
        
        # Property: Programs in cycles should be subset of all programs
        programs_in_cycles = set()
        for cycle in cycles:
            programs_in_cycles.update(cycle.artifacts)
        
        assert stats['programs_in_cycles'] == len(programs_in_cycles), \
            "Statistics should report correct count of programs in cycles"
        
        # Property: Cycle length distribution should be accurate
        actual_lengths = [len(cycle.artifacts) for cycle in cycles]
        if actual_lengths:
            assert stats['cycle_length_distribution']['min'] == min(actual_lengths), \
                "Minimum cycle length should be accurate"
            assert stats['cycle_length_distribution']['max'] == max(actual_lengths), \
                "Maximum cycle length should be accurate"
            
            expected_avg = sum(actual_lengths) / len(actual_lengths)
            assert abs(stats['cycle_length_distribution']['avg'] - expected_avg) < 0.01, \
                "Average cycle length should be accurate"
    
    @given(circular_dependency_chain_strategy())
    @settings(max_examples=50)
    def test_within_and_across_file_detection(self, chain_data):
        """
        Property: For any circular dependency, the detector should correctly 
        classify cycles as within-file or across-file based on program locations.
        """
        dependencies, programs = chain_data
        
        # Create mappings where some programs are in same file, others in different files
        mappings = []
        file_paths = ["/src/file1.cbl", "/src/file2.cbl", "/src/file3.cbl"]
        
        for i, program in enumerate(programs):
            # Alternate between files to create both within-file and across-file scenarios
            file_path = file_paths[i % len(file_paths)]
            mapping = {
                'program_name': program,
                'file_path': file_path,
                'start_line': (i % 3) * 100 + 1,  # Programs in same file have different line ranges
                'end_line': (i % 3) * 100 + 50,
                'program_type': 'MAIN',
                'language': 'COBOL'
            }
            mappings.append(mapping)
        
        # Create test database
        db_conn = create_test_database_with_mappings(mappings)
        
        try:
            detector = CircularDependencyDetector(dependencies, db_conn)
            
            within_file_cycles = detector.detect_cycles_within_files()
            across_file_cycles = detector.detect_cycles_across_files()
            all_cycles = detector.detect_all_cycles()
            
            # Property: Classification should be mutually exclusive and complete
            total_classified = len(within_file_cycles) + len(across_file_cycles)
            assert total_classified == len(all_cycles), \
                "All cycles should be classified as either within-file or across-file"
            
            # Property: Within-file cycles should have all programs in same file
            for cycle_info in within_file_cycles:
                cycle = cycle_info['cycle']
                file_path = cycle_info['file_path']
                
                # All programs should be in the same file
                for program in cycle.artifacts:
                    program_mapping = next((m for m in mappings if m['program_name'] == program), None)
                    if program_mapping:
                        assert program_mapping['file_path'] == file_path, \
                            f"Program {program} should be in file {file_path} for within-file cycle"
            
            # Property: Across-file cycles should span multiple files
            for cycle_info in across_file_cycles:
                files_involved = cycle_info['files_involved']
                assert len(files_involved) > 1 or cycle_info['programs_without_location'], \
                    "Across-file cycles should involve multiple files or have unmapped programs"
        
        finally:
            db_conn.close()