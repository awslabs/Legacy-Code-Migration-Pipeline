"""Tests for RPG dependency parser."""

import pytest
from tools.legacy_analyzer.parsers.rpg_parser import RPGDependencyParser


class TestRPGParser:
    """Test suite for RPG dependency parser."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = RPGDependencyParser()
    
    def test_parse_call_statements_literal(self):
        """Test parsing CALL statements with literals."""
        source = """
        C                   CALL      'PROG1'
        C                   CALL      "PROG2"
        C                   CALLB     'PROG3'
        """
        
        result = self.parser.parse(source)
        
        assert 'PROG1' in result['calls']
        assert 'PROG2' in result['calls']
        assert 'PROG3' in result['calls']
        assert len(result['calls']) == 3
    
    def test_parse_call_statements_identifier(self):
        """Test parsing CALL statements with identifiers."""
        source = """
        C                   CALL      MYPROG
        C                   CALLP     MYPROC
        """
        
        result = self.parser.parse(source)
        
        assert 'MYPROG' in result['calls']
        assert 'MYPROC' in result['calls']
    
    def test_parse_copy_statements(self):
        """Test parsing /COPY statements."""
        source = """
        /COPY QRPGLESRC,COPYBOOK1
        /COPY COPYBOOK2
        /copy mylib,copybook3
        """
        
        result = self.parser.parse(source)
        
        assert 'QRPGLESRC.COPYBOOK1' in result['copybooks']
        assert 'COPYBOOK2' in result['copybooks']
        assert 'mylib.copybook3' in result['copybooks']
        assert len(result['copybooks']) == 3
    
    def test_parse_include_statements(self):
        """Test parsing /INCLUDE statements."""
        source = """
        /INCLUDE QRPGLESRC,INCLUDE1
        /INCLUDE INCLUDE2
        """
        
        result = self.parser.parse(source)
        
        assert 'QRPGLESRC.INCLUDE1' in result['includes']
        assert 'INCLUDE2' in result['includes']
        assert len(result['includes']) == 2
    
    def test_parse_file_declarations_fspec(self):
        """Test parsing F-spec file declarations."""
        source = """
FCUSTFILE  IF   E           K DISK
FORDFILE   O    E             DISK
FWORKFILE  UF A E           K DISK
        """
        
        result = self.parser.parse(source)
        
        assert 'CUSTFILE' in result['files']
        assert 'ORDFILE' in result['files']
        assert 'WORKFILE' in result['files']
        assert len(result['files']) == 3
    
    def test_parse_file_declarations_dcl_f(self):
        """Test parsing DCL-F file declarations (free format)."""
        source = """
        **FREE
        DCL-F CUSTFILE DISK(*EXT) USAGE(*INPUT) KEYED;
        DCL-F ORDFILE DISK(*EXT) USAGE(*OUTPUT);
        """
        
        result = self.parser.parse(source)
        
        assert 'CUSTFILE' in result['files']
        assert 'ORDFILE' in result['files']
        assert len(result['files']) == 2
    
    def test_parse_file_operations(self):
        """Test parsing file operations."""
        source = """
        C                   CHAIN     CUSTKEY    CUSTFILE
        C                   READ      ORDFILE
        C                   WRITE     OUTREC
        C                   UPDATE    CUSTREC
        C                   DELETE    CUSTFILE
        """
        
        result = self.parser.parse(source)
        
        assert 'CUSTFILE' in result['files']
        assert 'ORDFILE' in result['files']
        assert 'OUTREC' in result['files']
        assert 'CUSTREC' in result['files']
    
    def test_parse_sql_tables(self):
        """Test parsing embedded SQL table references.
        
        Note: The RPG parser currently supports SQL statements on single lines
        or in free-format blocks, not C-spec continuation lines (C/EXEC SQL + C+).
        """
        source = """
        **FREE
        EXEC SQL SELECT * FROM CUSTOMER WHERE CUSTID = :CUSTID;
        EXEC SQL INSERT INTO ORDERS VALUES (:ORDER_REC);
        EXEC SQL UPDATE INVENTORY SET QTY = :QTY;
        """
        
        result = self.parser.parse(source)
        
        assert 'CUSTOMER' in result['sql_tables']
        assert 'ORDERS' in result['sql_tables']
        assert 'INVENTORY' in result['sql_tables']
    
    def test_parse_prototypes_dspec(self):
        """Test parsing D-spec procedure prototypes."""
        source = """
D GETDATE         PR
D  DATEOUT                       8A
D CALCAMT         PR            15P 2
D  AMT1                         15P 2
D  AMT2                         15P 2
        """
        
        result = self.parser.parse(source)
        
        assert 'GETDATE' in result['prototypes']
        assert 'CALCAMT' in result['prototypes']
        assert len(result['prototypes']) == 2
    
    def test_parse_prototypes_dcl_pr(self):
        """Test parsing DCL-PR procedure prototypes (free format)."""
        source = """
        **FREE
        DCL-PR GETDATE CHAR(8);
        END-PR;
        
        DCL-PR CALCAMT PACKED(15:2);
          AMT1 PACKED(15:2);
          AMT2 PACKED(15:2);
        END-PR;
        """
        
        result = self.parser.parse(source)
        
        assert 'GETDATE' in result['prototypes']
        assert 'CALCAMT' in result['prototypes']
    
    def test_normalize_source_fixed_format(self):
        """Test source normalization for fixed format."""
        source = """
      * This is a comment
     C                   CALL      'PROG1'
     C* Another comment
     C                   CALL      'PROG2'
        """
        
        normalized = self.parser._normalize_source(source)
        
        # Comments should be removed
        assert '* This is a comment' not in normalized
        assert 'CALL' in normalized
    
    def test_normalize_source_free_format(self):
        """Test source normalization for free format."""
        source = """
        **FREE
        // This is a comment
        CALL 'PROG1';
        // Another comment
        CALL 'PROG2'; // Inline comment
        """
        
        normalized = self.parser._normalize_source(source)
        
        # Comments should be removed
        assert '// This is a comment' not in normalized
        assert 'CALL' in normalized
    
    def test_get_supported_patterns(self):
        """Test getting supported patterns."""
        patterns = self.parser.get_supported_patterns()
        
        assert 'CALL/CALLB/CALLP' in patterns
        assert '/COPY' in patterns
        assert '/INCLUDE' in patterns
        assert 'F-spec file declarations' in patterns
        assert 'DCL-F file declarations' in patterns
        assert 'File operations (CHAIN, READ, WRITE, etc.)' in patterns
        assert 'Embedded SQL' in patterns
        assert 'Procedure prototypes (PR/DCL-PR)' in patterns
    
    def test_get_supported_extensions(self):
        """Test getting supported file extensions."""
        extensions = self.parser.get_supported_extensions()
        
        assert '.rpg' in extensions
        assert '.rpgle' in extensions
        assert '.sqlrpgle' in extensions
        assert '.rpg38' in extensions
        assert '.mbr' in extensions
        assert len(extensions) == 5
    
    def test_case_insensitive_parsing(self):
        """Test that parsing is case-insensitive."""
        source_upper = """
        CALL 'PROG1'
        /COPY COPYBOOK1
        """
        
        source_lower = """
        call 'PROG1'
        /copy COPYBOOK1
        """
        
        result_upper = self.parser.parse(source_upper)
        result_lower = self.parser.parse(source_lower)
        
        assert result_upper['calls'] == result_lower['calls']
        assert result_upper['copybooks'] == result_lower['copybooks']
    
    def test_empty_source(self):
        """Test parsing empty source code."""
        result = self.parser.parse("")
        
        assert result['calls'] == []
        assert result['copybooks'] == []
        assert result['includes'] == []
        assert result['files'] == []
        assert result['sql_tables'] == []
        assert result['prototypes'] == []
    
    def test_source_with_no_dependencies(self):
        """Test parsing source with no dependencies."""
        source = """
        **FREE
        DCL-S MyVar CHAR(10);
        MyVar = 'Hello';
        DSPLY MyVar;
        """
        
        result = self.parser.parse(source)
        
        assert result['calls'] == []
        assert result['copybooks'] == []
        assert result['includes'] == []
        assert result['files'] == []
        assert result['sql_tables'] == []
    
    def test_mixed_format_program(self):
        """Test parsing a program with mixed dependencies."""
        source = """
        **FREE
        DCL-F CUSTFILE DISK(*EXT) USAGE(*INPUT) KEYED;
        DCL-F ORDFILE DISK(*EXT) USAGE(*OUTPUT);
        
        /COPY QRPGLESRC,CONSTANTS
        /INCLUDE QRPGLESRC,PROTOTYPES
        
        DCL-PR GETDATE CHAR(8);
        END-PR;
        
        DCL-S CustKey CHAR(10);
        DCL-S OrderRec LIKEDS(OrderDS);
        
        // Read customer file
        CHAIN CustKey CUSTFILE;
        IF %FOUND(CUSTFILE);
          // Call external program
          CALLP CALCORDER(OrderRec);
          
          // Write to order file
          WRITE OrderRec ORDFILE;
          
          // Execute SQL
          EXEC SQL
            INSERT INTO ORDER_LOG VALUES (:OrderRec)
          END-EXEC;
        ENDIF;
        
        *INLR = *ON;
        """
        
        result = self.parser.parse(source)
        
        # Check files
        assert 'CUSTFILE' in result['files']
        assert 'ORDFILE' in result['files']
        
        # Check copybooks and includes
        assert 'QRPGLESRC.CONSTANTS' in result['copybooks']
        assert 'QRPGLESRC.PROTOTYPES' in result['includes']
        
        # Check prototypes
        assert 'GETDATE' in result['prototypes']
        
        # Check calls
        assert 'CALCORDER' in result['calls']
        
        # Check SQL tables
        assert 'ORDER_LOG' in result['sql_tables']
    
    def test_filter_rpg_keywords(self):
        """Test that RPG keywords are filtered out from calls and files."""
        source = """
        C                   CALL      PARM
        C                   CALL      RETURN
        C                   READ      DS
        """
        
        result = self.parser.parse(source)
        
        # These keywords should be filtered out
        assert 'PARM' not in result['calls']
        assert 'RETURN' not in result['calls']
        assert 'DS' not in result['files']


    def test_parse_with_program_detection_single_program(self):
        """Test program-level parsing with single program."""
        source = """
        H MAIN(TESTPROG)
        **FREE
        DCL-F CUSTFILE DISK(*EXT) USAGE(*INPUT) KEYED;
        
        /COPY QRPGLESRC,CONSTANTS
        
        CALL 'SUBPROG';
        """
        
        result = self.parser.parse_with_program_detection(source)
        
        assert result.language == "RPG"
        assert len(result.programs) == 1
        
        program = result.programs[0]
        assert program.program_name == "TESTPROG"
        assert program.program_type.value == "MAIN"
        assert program.language == "RPG"
        assert "TESTPROG" in program.entry_points
        
        # Check that dependencies are tracked per program
        assert "TESTPROG" in result.dependencies
        deps = result.dependencies["TESTPROG"]
        assert any("SUBPROG" in str(dep) for dep in deps)
        assert any("CONSTANTS" in str(dep) for dep in deps)
    
    def test_parse_with_program_detection_multiple_programs(self):
        """Test program-level parsing with multiple H-specs."""
        source = """
        H MAIN(PROG1)
        **FREE
        CALL 'SUBPROG1';
        
        H MAIN(PROG2)
        **FREE
        CALL 'SUBPROG2';
        """
        
        result = self.parser.parse_with_program_detection(source)
        
        assert result.language == "RPG"
        assert len(result.programs) == 2
        
        program_names = [p.program_name for p in result.programs]
        assert "PROG1" in program_names
        assert "PROG2" in program_names
        
        # Check that dependencies are separated by program
        assert "PROG1" in result.dependencies
        assert "PROG2" in result.dependencies
    
    def test_parse_with_program_detection_with_procedures(self):
        """Test program-level parsing with procedures."""
        source = """
        H MAIN(MAINPROG)
        **FREE
        
        DCL-PR MyProc;
        END-PR;
        
        CALL 'EXTERNAL';
        
        DCL-PROC MyProc;
          // Procedure body
        END-PROC;
        """
        
        result = self.parser.parse_with_program_detection(source)
        
        assert result.language == "RPG"
        assert len(result.programs) >= 1  # At least main program
        
        # Should have main program
        main_programs = [p for p in result.programs if p.program_type.value == "MAIN"]
        assert len(main_programs) == 1
        assert main_programs[0].program_name == "MAINPROG"
        
        # May have procedure as separate program
        proc_programs = [p for p in result.programs if p.program_type.value == "PROCEDURE"]
        if proc_programs:
            assert any(p.program_name == "MyProc" for p in proc_programs)
    
    def test_parse_with_program_detection_no_h_spec(self):
        """Test program-level parsing without H-spec."""
        source = """
        **FREE
        DCL-F CUSTFILE DISK(*EXT) USAGE(*INPUT) KEYED;
        CALL 'SUBPROG';
        """
        
        result = self.parser.parse_with_program_detection(source, "/path/to/test.rpg")
        
        assert result.language == "RPG"
        assert len(result.programs) >= 1
        
        # Should create a default program
        program = result.programs[0]
        assert program.program_type.value == "MAIN"
        assert program.language == "RPG"
    
    def test_detect_program_boundaries_h_spec_patterns(self):
        """Test H-spec pattern detection."""
        source = """
        H NOMAIN
        H MAIN(TESTPROG)
        H DFTACTGRP(*NO) MAIN(ANOTHERPROG)
        """
        
        programs = self.parser.detect_program_boundaries(source)
        
        assert len(programs) >= 2  # Should detect programs with MAIN()
        
        program_names = [p.program_name for p in programs]
        assert "TESTPROG" in program_names
        assert "ANOTHERPROG" in program_names
    
    def test_detect_program_boundaries_file_path(self):
        """Test program boundary detection with file path."""
        source = """
        H MAIN(TESTPROG)
        **FREE
        CALL 'SUBPROG';
        """
        
        file_path = "/path/to/test.rpg"
        programs = self.parser.detect_program_boundaries(source, file_path)
        
        assert len(programs) == 1
        assert programs[0].file_path == file_path
    
    def test_extract_program_level_dependencies(self):
        """Test extraction of dependencies per program."""
        source = """
        H MAIN(PROG1)
        CALL 'SUB1'
        
        H MAIN(PROG2)  
        CALL 'SUB2'
        """
        
        programs = self.parser.detect_program_boundaries(source)
        dependencies = self.parser._extract_program_level_dependencies(source, programs)
        
        assert len(dependencies) == len(programs)
        
        for program in programs:
            assert program.program_name in dependencies
            deps = dependencies[program.program_name]
            assert isinstance(deps, list)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
