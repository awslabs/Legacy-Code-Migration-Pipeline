"""Tests for migration CLI commands."""

import pytest
import json
import tempfile
import subprocess
import sys
from pathlib import Path


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    yield db_path
    
    # Cleanup
    Path(db_path).unlink(missing_ok=True)


def run_cli(*args):
    """Run CLI command and return result."""
    cmd = [sys.executable, '-m', 'tools.legacy_analyzer'] + list(args)
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True
    )
    return result


def setup_test_database(db_path):
    """Set up a test database with migration flow schema."""
    import sqlite3
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create inventory table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            artifact_name VARCHAR(44) NOT NULL,
            filename VARCHAR(44),
            program_id VARCHAR(44),
            artifact_type VARCHAR(20),
            language VARCHAR(20),
            file_extension VARCHAR(10),
            file_path TEXT NOT NULL UNIQUE,
            file_size INTEGER,
            analyzed INTEGER DEFAULT 0,
            found_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_modified TIMESTAMP
        )
    """)
    
    # Create artifact_dependencies table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS artifact_dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_artifact_name VARCHAR(44) NOT NULL,
            source_artifact_type VARCHAR(20) NOT NULL,
            target_artifact_name VARCHAR(44) NOT NULL,
            target_artifact_type VARCHAR(20) NOT NULL,
            dependency_type VARCHAR(20) NOT NULL,
            source_file_path VARCHAR(255),
            line_number INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create migration_flows table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS migration_flows (
            flow_id VARCHAR(100) PRIMARY KEY,
            name VARCHAR(200),
            entry_program VARCHAR(44),
            primary_entry_type VARCHAR(20),
            total_programs INTEGER,
            total_copybooks INTEGER,
            total_datasets INTEGER,
            complexity_total_lines INTEGER,
            complexity_cyclomatic INTEGER,
            complexity_score DECIMAL(10,2),
            complexity_tier VARCHAR(10),
            priority INTEGER,
            business_domain VARCHAR(100),
            created_date DATE,
            updated_date DATE
        )
    """)
    
    # Create external_program_config table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS external_program_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern VARCHAR(100),
            program_type VARCHAR(50),
            scope VARCHAR(20),
            is_pattern BOOLEAN DEFAULT FALSE,
            created_date DATE
        )
    """)
    
    # Create external_caller_config table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS external_caller_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            caller_name VARCHAR(100),
            target_program VARCHAR(44),
            call_type VARCHAR(20),
            metadata_json TEXT,
            created_date DATE
        )
    """)
    
    # Create program_metadata table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_metadata (
            program_name VARCHAR(44) PRIMARY KEY,
            is_utility BOOLEAN DEFAULT FALSE,
            call_count INTEGER DEFAULT 0,
            classification VARCHAR(20),
            shared_by_flow_count INTEGER DEFAULT 0,
            naming_pattern VARCHAR(50),
            created_date DATE,
            updated_date DATE
        )
    """)
    
    # Create flow_entry_types table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS flow_entry_types (
            flow_id VARCHAR(100),
            entry_type VARCHAR(20),
            caller_source VARCHAR(100),
            metadata_json TEXT,
            PRIMARY KEY (flow_id, entry_type, caller_source),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_scope table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS flow_scope (
            flow_id VARCHAR(100),
            artifact_type VARCHAR(20),
            artifact_name VARCHAR(44),
            PRIMARY KEY (flow_id, artifact_type, artifact_name),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_interfaces table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS flow_interfaces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flow_id VARCHAR(100),
            direction VARCHAR(10),
            interface_type VARCHAR(20),
            source VARCHAR(44),
            target VARCHAR(44),
            external BOOLEAN DEFAULT FALSE,
            metadata_json TEXT,
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_data_operations table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS flow_data_operations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flow_id VARCHAR(100),
            operation_category VARCHAR(20),
            operation_type VARCHAR(20),
            db_type VARCHAR(20),
            target VARCHAR(100),
            program VARCHAR(44),
            mode VARCHAR(10),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_dependencies table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS flow_dependencies (
            flow_id VARCHAR(100),
            depends_on_flow_id VARCHAR(100),
            dependency_type VARCHAR(20),
            PRIMARY KEY (flow_id, depends_on_flow_id, dependency_type),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE,
            FOREIGN KEY (depends_on_flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create program_file_mapping table (optional but prevents warnings)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT NOT NULL,
            program_name VARCHAR(44) NOT NULL,
            start_line INTEGER,
            end_line INTEGER,
            created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.commit()
    conn.close()


class TestMigrationCommands:
    """Test migration CLI commands."""
    
    def test_migration_help(self):
        """Test migration help command."""
        result = run_cli('migration', '--help')
        assert result.returncode == 0
        assert 'migration' in result.stdout.lower()
        assert 'build-flows' in result.stdout
        assert 'export-flows' in result.stdout
    
    def test_migration_build_flows_help(self):
        """Test migration build-flows help."""
        result = run_cli('migration', 'build-flows', '--help')
        assert result.returncode == 0
        assert 'build-flows' in result.stdout.lower()
        assert '--db' in result.stdout
        assert '--external-config' in result.stdout
        assert '--utility-threshold' in result.stdout
    
    def test_migration_export_flows_help(self):
        """Test migration export-flows help."""
        result = run_cli('migration', 'export-flows', '--help')
        assert result.returncode == 0
        assert 'export-flows' in result.stdout.lower()
        assert '--db' in result.stdout
        assert '--output' in result.stdout
        assert '--flows' in result.stdout
        assert '--min-complexity' in result.stdout
        assert '--business-domain' in result.stdout
        assert '--format' in result.stdout
        assert '--extended-scope' in result.stdout
    
    def test_migration_build_flows_missing_db(self):
        """Test error when database file is missing."""
        result = run_cli(
            'migration', 'build-flows',
            '--db', '/nonexistent/database.db'
        )
        
        assert result.returncode != 0
        assert 'error' in result.stdout.lower() or 'error' in result.stderr.lower()
    
    def test_migration_export_flows_missing_db(self):
        """Test error when database file is missing."""
        result = run_cli(
            'migration', 'export-flows',
            '--db', '/nonexistent/database.db',
            '--output', 'flows.json'
        )
        
        assert result.returncode != 0
        assert 'error' in result.stdout.lower() or 'error' in result.stderr.lower()
    
    def test_migration_export_flows_missing_output(self, temp_db):
        """Test error when output file is not specified."""
        setup_test_database(temp_db)
        
        result = run_cli(
            'migration', 'export-flows',
            '--db', temp_db
        )
        
        # Should fail because --output is required
        assert result.returncode != 0
    
    def test_migration_build_flows_basic(self, temp_db):
        """Test basic migration build-flows command."""
        setup_test_database(temp_db)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Add a simple program
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path) 
            VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')
        """)
        
        conn.commit()
        conn.close()
        
        # Run build-flows command
        result = run_cli(
            'migration', 'build-flows',
            '--db', temp_db
        )
        
        # Should complete successfully
        assert result.returncode == 0
        assert 'building' in result.stdout.lower() or 'built' in result.stdout.lower()
    
    def test_migration_export_flows_basic(self, temp_db):
        """Test basic migration export-flows command."""
        setup_test_database(temp_db)
        
        # Insert test flow data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO migration_flows 
            (flow_id, name, entry_program, primary_entry_type, total_programs, 
             total_copybooks, total_datasets, complexity_tier)
            VALUES ('FLOW_TESTPROG', 'Test Flow', 'TESTPROG', 'JCL', 1, 0, 0, 'LOW')
        """)
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run export-flows command
            result = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file
            )
            
            # Should complete successfully
            assert result.returncode == 0
            assert 'exported' in result.stdout.lower() or 'success' in result.stdout.lower()
            
            # Verify output file was created
            assert Path(output_file).exists()
            
            # Verify JSON content
            with open(output_file) as f:
                data = json.load(f)
            
            assert 'flows' in data or isinstance(data, list)
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_migration_export_flows_with_filters(self, temp_db):
        """Test migration export-flows with filters."""
        setup_test_database(temp_db)
        
        # Insert test flow data with different complexity tiers
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO migration_flows 
            (flow_id, name, entry_program, primary_entry_type, total_programs, 
             total_copybooks, total_datasets, complexity_tier, business_domain)
            VALUES ('FLOW_LOW', 'Low Complexity', 'PROG1', 'JCL', 1, 0, 0, 'LOW', 'Finance')
        """)
        
        cursor.execute("""
            INSERT INTO migration_flows 
            (flow_id, name, entry_program, primary_entry_type, total_programs, 
             total_copybooks, total_datasets, complexity_tier, business_domain)
            VALUES ('FLOW_HIGH', 'High Complexity', 'PROG2', 'JCL', 5, 3, 2, 'HIGH', 'Finance')
        """)
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run export-flows with min-complexity filter
            result = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file,
                '--min-complexity', 'HIGH'
            )
            
            # Should complete successfully
            assert result.returncode == 0
            
            # Verify output file was created
            assert Path(output_file).exists()
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_migration_export_flows_specific_flows(self, temp_db):
        """Test migration export-flows with specific flow IDs."""
        setup_test_database(temp_db)
        
        # Insert test flow data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        for i in range(3):
            cursor.execute(f"""
                INSERT INTO migration_flows 
                (flow_id, name, entry_program, primary_entry_type, total_programs, 
                 total_copybooks, total_datasets, complexity_tier)
                VALUES ('FLOW_PROG{i}', 'Flow {i}', 'PROG{i}', 'JCL', 1, 0, 0, 'LOW')
            """)
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run export-flows with specific flow IDs
            result = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file,
                '--flows', 'FLOW_PROG0,FLOW_PROG1'
            )
            
            # Should complete successfully
            assert result.returncode == 0
            assert 'exported' in result.stdout.lower() or 'success' in result.stdout.lower()
            
            # Verify output file was created
            assert Path(output_file).exists()
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_migration_export_flows_format_option(self, temp_db):
        """Test migration export-flows with format option."""
        setup_test_database(temp_db)
        
        # Insert test flow data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO migration_flows 
            (flow_id, name, entry_program, primary_entry_type, total_programs, 
             total_copybooks, total_datasets, complexity_tier)
            VALUES ('FLOW_TEST', 'Test Flow', 'TESTPROG', 'JCL', 1, 0, 0, 'LOW')
        """)
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run export-flows with migration format (default)
            result = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file,
                '--format', 'migration'
            )
            
            # Should complete successfully
            assert result.returncode == 0
            
            # Verify output file was created
            assert Path(output_file).exists()
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_migration_export_flows_extended_scope(self, temp_db):
        """Test migration export-flows with extended-scope option."""
        setup_test_database(temp_db)
        
        # Insert test flow data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO migration_flows 
            (flow_id, name, entry_program, primary_entry_type, total_programs, 
             total_copybooks, total_datasets, complexity_tier)
            VALUES ('FLOW_TEST', 'Test Flow', 'TESTPROG', 'JCL', 1, 0, 0, 'LOW')
        """)
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run export-flows with extended-scope
            result = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file,
                '--extended-scope'
            )
            
            # Should complete successfully
            assert result.returncode == 0
            
            # Verify output file was created
            assert Path(output_file).exists()
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_migration_build_flows_with_external_config(self, temp_db):
        """Test migration build-flows with external config."""
        setup_test_database(temp_db)
        
        # Create temporary external config file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            config_file = f.name
            f.write("""
external_programs:
  - pattern: "UTIL*"
    type: "UTILITY"
    scope: "EXTERNAL"

external_callers:
  - caller: "EXTERNAL_SYSTEM"
    calls:
      - target: "TESTPROG"
        type: "PROGRAM_CALL"
""")
        
        try:
            # Insert test data
            import sqlite3
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO inventory (artifact_name, artifact_type, file_path) 
                VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')
            """)
            
            conn.commit()
            conn.close()
            
            # Run build-flows with external config
            result = run_cli(
                'migration', 'build-flows',
                '--db', temp_db,
                '--external-config', config_file
            )
            
            # Should complete successfully
            assert result.returncode == 0
        
        finally:
            Path(config_file).unlink(missing_ok=True)
    
    def test_migration_build_flows_with_utility_threshold(self, temp_db):
        """Test migration build-flows with custom utility threshold."""
        setup_test_database(temp_db)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path) 
            VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')
        """)
        
        conn.commit()
        conn.close()
        
        # Run build-flows with custom utility threshold
        result = run_cli(
            'migration', 'build-flows',
            '--db', temp_db,
            '--utility-threshold', '10'
        )
        
        # Should complete successfully
        assert result.returncode == 0
    
    def test_migration_no_subcommand(self):
        """Test error when no subcommand is provided."""
        result = run_cli('migration')
        
        # Should fail with error message
        assert result.returncode != 0
        assert 'error' in result.stdout.lower() or 'error' in result.stderr.lower()
    
    def test_migration_invalid_subcommand(self):
        """Test error with invalid subcommand."""
        result = run_cli('migration', 'invalid-command')
        
        # Should fail with error message
        assert result.returncode != 0
    
    def test_migration_export_flows_invalid_format(self, temp_db):
        """Test error with invalid format option."""
        setup_test_database(temp_db)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            result = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file,
                '--format', 'invalid'
            )
            
            # Should fail with invalid format
            assert result.returncode != 0
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_migration_export_flows_invalid_complexity(self, temp_db):
        """Test error with invalid complexity tier."""
        setup_test_database(temp_db)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            result = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file,
                '--min-complexity', 'INVALID'
            )
            
            # Should fail with invalid complexity tier
            assert result.returncode != 0
        
        finally:
            Path(output_file).unlink(missing_ok=True)


class TestMigrationWorkflow:
    """Test complete migration workflow."""
    
    def test_build_then_export_workflow(self, temp_db):
        """Test building flows then exporting them."""
        setup_test_database(temp_db)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path) 
            VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')
        """)
        
        conn.commit()
        conn.close()
        
        # Step 1: Build flows
        result1 = run_cli(
            'migration', 'build-flows',
            '--db', temp_db
        )
        
        assert result1.returncode == 0
        
        # Step 2: Export flows
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            result2 = run_cli(
                'migration', 'export-flows',
                '--db', temp_db,
                '--output', output_file
            )
            
            assert result2.returncode == 0
            assert Path(output_file).exists()
        
        finally:
            Path(output_file).unlink(missing_ok=True)
