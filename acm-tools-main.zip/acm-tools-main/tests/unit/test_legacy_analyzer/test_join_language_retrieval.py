"""Unit tests for JOIN-based language retrieval from normalized schema.

This test suite verifies that language information can be correctly retrieved
by JOINing the artifact_dependencies table with the inventory table.
"""

import pytest
import sqlite3
import tempfile
import os
from tools.smf_analyzer.smf_loader.schemas.dependencies_schema import DependenciesSchema


class TestJoinBasedLanguageRetrieval:
    """Test suite for JOIN-based language retrieval."""
    
    @pytest.fixture
    def test_db(self):
        """Create a test database with inventory and dependencies."""
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        schema = DependenciesSchema()
        table_defs = schema.get_table_definitions()
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create artifact_dependencies table
        dep_table = table_defs['artifact_dependencies']
        col_defs = []
        for col in dep_table['columns']:
            col_def = f"{col['name']} {col['type']}"
            if col.get('primary_key'):
                col_def += " PRIMARY KEY"
                if col.get('autoincrement'):
                    col_def += " AUTOINCREMENT"
            if not col.get('nullable', True):
                col_def += " NOT NULL"
            if 'default' in col:
                col_def += f" DEFAULT {col['default']}"
            col_defs.append(col_def)
        
        create_sql = f"CREATE TABLE artifact_dependencies ({', '.join(col_defs)})"
        cursor.execute(create_sql)
        
        # Create inventory table
        inv_table = table_defs['inventory']
        col_defs = []
        for col in inv_table['columns']:
            col_def = f"{col['name']} {col['type']}"
            if col.get('primary_key'):
                col_def += " PRIMARY KEY"
                if col.get('autoincrement'):
                    col_def += " AUTOINCREMENT"
            if not col.get('nullable', True):
                col_def += " NOT NULL"
            if 'default' in col:
                col_def += f" DEFAULT {col['default']}"
            col_defs.append(col_def)
        
        create_sql = f"CREATE TABLE inventory ({', '.join(col_defs)})"
        cursor.execute(create_sql)
        
        # Create indexes
        for idx in dep_table['indexes']:
            cols = ', '.join(idx['columns'])
            cursor.execute(f"CREATE INDEX {idx['name']} ON artifact_dependencies ({cols})")
        
        for idx in inv_table['indexes']:
            cols = ', '.join(idx['columns'])
            unique = 'UNIQUE' if idx.get('unique') else ''
            cursor.execute(f"CREATE {unique} INDEX {idx['name']} ON inventory ({cols})")
        
        # Insert test inventory data
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, language, file_path)
            VALUES 
                ('PROG001', 'PROGRAM', 'COBOL', '/path/to/prog001.cbl'),
                ('PROG002', 'PROGRAM', 'COBOL', '/path/to/prog002.cbl'),
                ('PROG003', 'PROGRAM', 'Natural', '/path/to/prog003.nat'),
                ('COPY001', 'COPYBOOK', 'COBOL', '/path/to/copy001.cpy'),
                ('PROG004', 'PROGRAM', 'PL/I', '/path/to/prog004.pli')
        """)
        
        # Insert test dependency data (without language fields)
        cursor.execute("""
            INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type, source_file_path, line_number)
            VALUES 
                ('PROG001', 'PROGRAM', 'PROG002', 'PROGRAM', 'CALL', '/path/to/prog001.cbl', 100),
                ('PROG001', 'PROGRAM', 'COPY001', 'COPYBOOK', 'COPY', '/path/to/prog001.cbl', 50),
                ('PROG003', 'PROGRAM', 'PROG001', 'PROGRAM', 'CALL', '/path/to/prog003.nat', 200),
                ('PROG004', 'PROGRAM', 'PROG002', 'PROGRAM', 'CALL', '/path/to/prog004.pli', 150),
                ('PROG001', 'PROGRAM', 'PROG003', 'PROGRAM', 'CALL', '/path/to/prog001.cbl', 300)
        """)
        
        conn.commit()
        conn.close()
        
        yield db_path
        
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    def test_join_retrieves_source_language(self, test_db):
        """Test that JOIN correctly retrieves source artifact language.
        
        Requirements: 2.1, 2.2
        """
        conn = sqlite3.connect(test_db)
        cursor = conn.cursor()
        
        # Query using JOIN pattern
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                i1.language as source_language
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            WHERE d.source_artifact_name = 'PROG001'
            LIMIT 1
        """)
        
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "Query should return results"
        assert result[0] == 'PROG001', "Should return correct artifact name"
        assert result[1] == 'COBOL', "Should return correct language from inventory"
    
    def test_join_retrieves_target_language(self, test_db):
        """Test that JOIN correctly retrieves target artifact language.
        
        Requirements: 2.1, 2.3
        """
        conn = sqlite3.connect(test_db)
        cursor = conn.cursor()
        
        # Query using JOIN pattern
        cursor.execute("""
            SELECT 
                d.target_artifact_name,
                i2.language as target_language
            FROM artifact_dependencies d
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE d.target_artifact_name = 'PROG002'
            LIMIT 1
        """)
        
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "Query should return results"
        assert result[0] == 'PROG002', "Should return correct artifact name"
        assert result[1] == 'COBOL', "Should return correct language from inventory"
    
    def test_join_retrieves_both_languages(self, test_db):
        """Test that JOIN correctly retrieves both source and target languages.
        
        Requirements: 2.1, 2.2, 2.3
        """
        conn = sqlite3.connect(test_db)
        cursor = conn.cursor()
        
        # Query using JOIN pattern for both source and target
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                i1.language as source_language,
                d.target_artifact_name,
                i2.language as target_language,
                d.dependency_type
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE d.source_artifact_name = 'PROG001' 
              AND d.target_artifact_name = 'PROG002'
        """)
        
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "Query should return results"
        assert result[0] == 'PROG001', "Should return correct source artifact"
        assert result[1] == 'COBOL', "Should return correct source language"
        assert result[2] == 'PROG002', "Should return correct target artifact"
        assert result[3] == 'COBOL', "Should return correct target language"
        assert result[4] == 'CALL', "Should return correct dependency type"
    
    def test_cross_language_dependencies(self, test_db):
        """Test querying cross-language dependencies.
        
        Requirements: 2.1, 2.2, 2.3
        """
        conn = sqlite3.connect(test_db)
        cursor = conn.cursor()
        
        # Query for cross-language dependencies
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                i1.language as source_language,
                d.target_artifact_name,
                i2.language as target_language
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE i1.language IS NOT NULL 
              AND i2.language IS NOT NULL
              AND i1.language != i2.language
            ORDER BY d.source_artifact_name
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        # We should have cross-language dependencies:
        # PROG003 (Natural) -> PROG001 (COBOL)
        # PROG004 (PL/I) -> PROG002 (COBOL)
        # PROG001 (COBOL) -> PROG003 (Natural)
        assert len(results) >= 3, "Should find cross-language dependencies"
        
        # Verify at least one Natural -> COBOL dependency
        natural_to_cobol = [r for r in results if r[1] == 'Natural' and r[3] == 'COBOL']
        assert len(natural_to_cobol) > 0, "Should find Natural to COBOL dependency"
        
        # Verify at least one PL/I -> COBOL dependency
        pli_to_cobol = [r for r in results if r[1] == 'PL/I' and r[3] == 'COBOL']
        assert len(pli_to_cobol) > 0, "Should find PL/I to COBOL dependency"
    
    def test_language_pair_aggregation(self, test_db):
        """Test aggregating dependencies by language pairs.
        
        Requirements: 2.1, 2.2, 2.3
        """
        conn = sqlite3.connect(test_db)
        cursor = conn.cursor()
        
        # Query for language pair counts
        cursor.execute("""
            SELECT 
                i1.language as source_language,
                i2.language as target_language,
                COUNT(*) as count
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE i1.language IS NOT NULL AND i2.language IS NOT NULL
            GROUP BY i1.language, i2.language
            ORDER BY count DESC
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        assert len(results) > 0, "Should find language pairs"
        
        # Verify structure
        for row in results:
            assert row[0] is not None, "Source language should not be None"
            assert row[1] is not None, "Target language should not be None"
            assert row[2] > 0, "Count should be positive"
        
        # Should have COBOL -> COBOL pair (PROG001 -> PROG002, PROG001 -> COPY001)
        cobol_to_cobol = [r for r in results if r[0] == 'COBOL' and r[1] == 'COBOL']
        assert len(cobol_to_cobol) > 0, "Should find COBOL to COBOL dependencies"
    
    def test_filter_by_source_language(self, test_db):
        """Test filtering dependencies by source language.
        
        Requirements: 2.1, 2.2
        """
        conn = sqlite3.connect(test_db)
        cursor = conn.cursor()
        
        # Query for all dependencies from COBOL programs
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                d.target_artifact_name,
                i2.language as target_language
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE i1.language = 'COBOL'
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        # PROG001 is COBOL and has 3 dependencies
        assert len(results) >= 3, "Should find COBOL source dependencies"
        
        # All should have PROG001 as source
        prog001_deps = [r for r in results if r[0] == 'PROG001']
        assert len(prog001_deps) == 3, "PROG001 should have 3 dependencies"
    
    def test_filter_by_target_language(self, test_db):
        """Test filtering dependencies by target language.
        
        Requirements: 2.1, 2.3
        """
        conn = sqlite3.connect(test_db)
        cursor = conn.cursor()
        
        # Query for all dependencies targeting COBOL programs
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                i1.language as source_language,
                d.target_artifact_name
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE i2.language = 'COBOL'
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        # Multiple programs call COBOL targets
        assert len(results) > 0, "Should find dependencies targeting COBOL"
        
        # Verify all targets are COBOL programs
        for row in results:
            target = row[2]
            assert target in ['PROG001', 'PROG002', 'COPY001'], \
                f"Target {target} should be a COBOL artifact"


class TestNullLanguageHandling:
    """Test suite for NULL language handling in JOIN queries."""
    
    @pytest.fixture
    def test_db_with_missing_inventory(self):
        """Create a test database with dependencies to artifacts not in inventory."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        schema = DependenciesSchema()
        table_defs = schema.get_table_definitions()
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create tables (simplified for brevity)
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_artifact_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_artifact_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(20) NOT NULL,
                source_file_path VARCHAR(255),
                line_number INTEGER
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                artifact_name VARCHAR(44) NOT NULL,
                artifact_type VARCHAR(20),
                language VARCHAR(20),
                file_path TEXT NOT NULL
            )
        """)
        
        # Insert inventory for source only
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, language, file_path)
            VALUES ('PROG001', 'PROGRAM', 'COBOL', '/path/to/prog001.cbl')
        """)
        
        # Insert dependency where target is NOT in inventory
        cursor.execute("""
            INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type, source_file_path, line_number)
            VALUES ('PROG001', 'PROGRAM', 'MISSING', 'PROGRAM', 'CALL', '/path/to/prog001.cbl', 100)
        """)
        
        conn.commit()
        conn.close()
        
        yield db_path
        
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    def test_null_language_for_missing_target(self, test_db_with_missing_inventory):
        """Test that language is NULL when target artifact not in inventory.
        
        Requirements: 2.4, 5.3
        """
        conn = sqlite3.connect(test_db_with_missing_inventory)
        cursor = conn.cursor()
        
        # Query using LEFT JOIN
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                i1.language as source_language,
                d.target_artifact_name,
                i2.language as target_language
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
        """)
        
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "Query should return results"
        assert result[0] == 'PROG001', "Should return source artifact"
        assert result[1] == 'COBOL', "Should return source language"
        assert result[2] == 'MISSING', "Should return target artifact"
        assert result[3] is None, "Target language should be NULL for missing artifact"
    
    def test_coalesce_handles_null_language(self, test_db_with_missing_inventory):
        """Test that COALESCE provides default value for NULL language.
        
        Requirements: 2.4, 5.3
        """
        conn = sqlite3.connect(test_db_with_missing_inventory)
        cursor = conn.cursor()
        
        # Query using COALESCE for NULL handling
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                COALESCE(i1.language, 'Unknown') as source_language,
                d.target_artifact_name,
                COALESCE(i2.language, 'Unknown') as target_language
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
        """)
        
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "Query should return results"
        assert result[1] == 'COBOL', "Should return source language"
        assert result[3] == 'Unknown', "Should return 'Unknown' for missing target language"
    
    def test_null_language_excluded_from_cross_language_query(self, test_db_with_missing_inventory):
        """Test that NULL languages are excluded from cross-language queries.
        
        Requirements: 2.4, 5.3
        """
        conn = sqlite3.connect(test_db_with_missing_inventory)
        cursor = conn.cursor()
        
        # Query for cross-language dependencies (should exclude NULLs)
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                i1.language as source_language,
                d.target_artifact_name,
                i2.language as target_language
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE i1.language IS NOT NULL 
              AND i2.language IS NOT NULL
              AND i1.language != i2.language
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        # Should return no results since target language is NULL
        assert len(results) == 0, "Should exclude dependencies with NULL languages"


class TestCrossLanguageQueryEquivalence:
    """Test suite for cross-language query equivalence."""
    
    @pytest.fixture
    def test_db_with_known_cross_lang(self):
        """Create test database with known cross-language dependencies."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        schema = DependenciesSchema()
        table_defs = schema.get_table_definitions()
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create tables (simplified)
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_artifact_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_artifact_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(20) NOT NULL
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                artifact_name VARCHAR(44) NOT NULL,
                artifact_type VARCHAR(20),
                language VARCHAR(20),
                file_path TEXT NOT NULL
            )
        """)
        
        # Insert inventory with multiple languages
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, language, file_path)
            VALUES 
                ('COBOL1', 'PROGRAM', 'COBOL', '/path/cobol1.cbl'),
                ('COBOL2', 'PROGRAM', 'COBOL', '/path/cobol2.cbl'),
                ('NAT1', 'PROGRAM', 'Natural', '/path/nat1.nat'),
                ('NAT2', 'PROGRAM', 'Natural', '/path/nat2.nat'),
                ('PLI1', 'PROGRAM', 'PL/I', '/path/pli1.pli')
        """)
        
        # Insert dependencies with known cross-language patterns
        cursor.execute("""
            INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, 
                 target_artifact_type, dependency_type)
            VALUES 
                ('COBOL1', 'PROGRAM', 'COBOL2', 'PROGRAM', 'CALL'),
                ('COBOL1', 'PROGRAM', 'NAT1', 'PROGRAM', 'CALL'),
                ('NAT1', 'PROGRAM', 'COBOL2', 'PROGRAM', 'CALL'),
                ('PLI1', 'PROGRAM', 'COBOL1', 'PROGRAM', 'CALL'),
                ('NAT2', 'PROGRAM', 'PLI1', 'PROGRAM', 'CALL')
        """)
        
        conn.commit()
        conn.close()
        
        yield db_path
        
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    def test_cross_language_query_returns_expected_pairs(self, test_db_with_known_cross_lang):
        """Test that cross-language query returns expected language pairs.
        
        Requirements: 5.2
        """
        conn = sqlite3.connect(test_db_with_known_cross_lang)
        cursor = conn.cursor()
        
        # Query for cross-language dependencies
        cursor.execute("""
            SELECT 
                i1.language as source_language,
                i2.language as target_language,
                COUNT(*) as count
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE i1.language IS NOT NULL 
              AND i2.language IS NOT NULL
              AND i1.language != i2.language
            GROUP BY i1.language, i2.language
            ORDER BY source_language, target_language
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        # Convert to dict for easier verification
        lang_pairs = {(row[0], row[1]): row[2] for row in results}
        
        # Verify expected cross-language pairs exist
        assert ('COBOL', 'Natural') in lang_pairs, "Should find COBOL -> Natural"
        assert ('Natural', 'COBOL') in lang_pairs, "Should find Natural -> COBOL"
        assert ('PL/I', 'COBOL') in lang_pairs, "Should find PL/I -> COBOL"
        assert ('Natural', 'PL/I') in lang_pairs, "Should find Natural -> PL/I"
        
        # Verify counts
        assert lang_pairs[('COBOL', 'Natural')] == 1, "Should have 1 COBOL -> Natural"
        assert lang_pairs[('Natural', 'COBOL')] == 1, "Should have 1 Natural -> COBOL"
        assert lang_pairs[('PL/I', 'COBOL')] == 1, "Should have 1 PL/I -> COBOL"
        assert lang_pairs[('Natural', 'PL/I')] == 1, "Should have 1 Natural -> PL/I"
        
        # Verify same-language pairs are excluded
        assert ('COBOL', 'COBOL') not in lang_pairs, "Should exclude COBOL -> COBOL"
    
    def test_all_dependencies_with_language_info(self, test_db_with_known_cross_lang):
        """Test querying all dependencies with language information.
        
        Requirements: 5.2
        """
        conn = sqlite3.connect(test_db_with_known_cross_lang)
        cursor = conn.cursor()
        
        # Query for all dependencies with language info
        cursor.execute("""
            SELECT 
                d.source_artifact_name,
                i1.language as source_language,
                d.target_artifact_name,
                i2.language as target_language,
                d.dependency_type
            FROM artifact_dependencies d
            LEFT JOIN inventory i1 ON d.source_artifact_name = i1.artifact_name
            LEFT JOIN inventory i2 ON d.target_artifact_name = i2.artifact_name
            WHERE i1.language IS NOT NULL AND i2.language IS NOT NULL
            ORDER BY d.source_artifact_name
        """)
        
        results = cursor.fetchall()
        conn.close()
        
        # Should return all 5 dependencies
        assert len(results) == 5, "Should return all dependencies with language info"
        
        # Verify specific dependencies
        cobol1_to_nat1 = [r for r in results if r[0] == 'COBOL1' and r[2] == 'NAT1']
        assert len(cobol1_to_nat1) == 1, "Should find COBOL1 -> NAT1"
        assert cobol1_to_nat1[0][1] == 'COBOL', "Source should be COBOL"
        assert cobol1_to_nat1[0][3] == 'Natural', "Target should be Natural"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

