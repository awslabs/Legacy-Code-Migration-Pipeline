"""
Tests for mixed content detection functionality.
"""

import pytest
from pathlib import Path

from tools.legacy_analyzer.analysis.mixed_content_detector import MixedContentDetector
from tools.legacy_analyzer.analysis.pds_member_parser import PDSMemberParser
from tools.legacy_analyzer.analysis.content_type_classifier import ContentTypeClassifier
from tools.legacy_analyzer.models.program_boundary import ProgramType


class TestMixedContentDetector:
    """Test mixed content detection functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.detector = MixedContentDetector()
    
    def test_pds_format_detection(self):
        """Test detection of PDS format files."""
        # PDS format content
        pds_content = """
./ ADD NAME=$INDEX   8000-76050-76050-1740-00027-00027-00000-JAY01
$INDEX - THIS MEMBER
EX1    - RPG TUTORIAL EXAMPLE PROGRAM 1 SOURCE
./ ADD NAME=EX1      8000-76050-76050-1347-00025-00025-00000-JAY01
     H
     H* READ ADDRESS CARDS AND PRINT ADDRESS LIST
     FINCARDS IPE F  80  80            READ40
./ ADD NAME=EX1$     8002-76050-76050-1446-00012-00012-00000-JAY01
//EXAMPLE1 JOB (001),'RPG TUTORIAL 1',
//             CLASS=A,MSGCLASS=A,REGION=512K
"""
        
        # Non-PDS content
        regular_content = """
     H
     H* This is a regular RPG program
     FINCARDS IPE F  80  80            READ40
     FOUTLIST O   F 132 132     OF    LPRINTER
"""
        
        assert self.detector.is_mixed_content_file(pds_content)
        assert not self.detector.is_mixed_content_file(regular_content)
    
    def test_pds_boundary_detection(self):
        """Test detection of program boundaries in PDS format."""
        pds_content = """
./ ADD NAME=$INDEX   8000-76050-76050-1740-00027-00027-00000-JAY01
$INDEX - THIS MEMBER
EX1    - RPG TUTORIAL EXAMPLE PROGRAM 1 SOURCE
./ ADD NAME=EX1      8000-76050-76050-1347-00025-00025-00000-JAY01
     H
     H* READ ADDRESS CARDS AND PRINT ADDRESS LIST
     FINCARDS IPE F  80  80            READ40
./ ADD NAME=EX1$     8002-76050-76050-1446-00012-00012-00000-JAY01
//EXAMPLE1 JOB (001),'RPG TUTORIAL 1',
//             CLASS=A,MSGCLASS=A,REGION=512K
./ ADD NAME=EX1D     8000-76050-76050-1347-00050-00050-00000-JAY01
MICHELLE COOK            9561 BAYVIEW STREET      BALDWIN, MO 63022
PATTY JENNINGS           806 JACKSON STREET       VALPARAISO, IN 46383
"""
        
        boundaries = self.detector.detect_boundaries("test.txt", pds_content)
        
        assert len(boundaries) == 4
        
        # Check program names
        program_names = [b.program_name for b in boundaries]
        assert "$INDEX" in program_names
        assert "EX1" in program_names
        assert "EX1$" in program_names
        assert "EX1D" in program_names
        
        # Check languages
        languages = [b.language for b in boundaries]
        assert "RPG" in languages  # For $INDEX and EX1
        assert "JCL" in languages  # For EX1$
        assert "DATA" in languages  # For EX1D
        
        # Check program types
        types = [b.program_type for b in boundaries]
        assert ProgramType.MAIN in types  # RPG programs
        assert ProgramType.JOB in types   # JCL job
        assert ProgramType.DATA in types  # Data section
    
    def test_content_summary(self):
        """Test content summary generation."""
        pds_content = """
./ ADD NAME=EX1      8000-76050-76050-1347-00025-00025-00000-JAY01
     H
     FINCARDS IPE F  80  80            READ40
./ ADD NAME=EX2      8000-76050-76050-1347-00025-00025-00000-JAY01
     H
     FOUTLIST O   F 132 132     OF    LPRINTER
./ ADD NAME=EX1$     8002-76050-76050-1446-00012-00012-00000-JAY01
//EXAMPLE1 JOB (001),'RPG TUTORIAL 1',
./ ADD NAME=EX1D     8000-76050-76050-1347-00050-00050-00000-JAY01
MICHELLE COOK            9561 BAYVIEW STREET      BALDWIN, MO 63022
"""
        
        boundaries = self.detector.detect_boundaries("test.txt", pds_content)
        summary = self.detector.get_content_summary(boundaries)
        
        assert summary['total_programs'] == 4
        assert summary['is_mixed'] == True
        assert summary['overall_language'] == 'MIXED'
        
        # Check language counts
        assert summary['language_counts']['RPG'] == 2
        assert summary['language_counts']['JCL'] == 1
        assert summary['language_counts']['DATA'] == 1
        
        # No single language should be dominant (>50%)
        assert summary['dominant_language'] is None


class TestPDSMemberParser:
    """Test PDS member parsing functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = PDSMemberParser()
    
    def test_pds_format_detection(self):
        """Test PDS format detection."""
        pds_content = "./ ADD NAME=TEST   8000-76050-76050-1740-00027-00027-00000-JAY01\ntest content"
        non_pds_content = "This is not PDS format"
        
        assert self.parser.is_pds_format(pds_content)
        assert not self.parser.is_pds_format(non_pds_content)
    
    def test_section_parsing(self):
        """Test parsing of PDS sections."""
        pds_content = """
./ ADD NAME=SECTION1   8000-76050-76050-1740-00027-00027-00000-JAY01
Content for section 1
Line 2 of section 1
./ ADD NAME=SECTION2   8001-76050-76050-1347-00025-00025-00000-JAY01
Content for section 2
Line 2 of section 2
Line 3 of section 2
"""
        
        sections = self.parser.parse_sections(pds_content)
        
        assert len(sections) == 2
        
        # Check first section
        assert sections[0].name == "SECTION1"
        assert sections[0].start_line == 3  # Line after the header
        assert "Content for section 1" in sections[0].content
        assert "Line 2 of section 1" in sections[0].content
        
        # Check second section
        assert sections[1].name == "SECTION2"
        assert sections[1].start_line == 6  # Line after the second header
        assert "Content for section 2" in sections[1].content
        assert "Line 3 of section 2" in sections[1].content
    
    def test_section_validation(self):
        """Test validation of parsed sections."""
        pds_content = """
./ ADD NAME=VALID   8000-76050-76050-1740-00027-00027-00000-JAY01
Valid content
./ ADD NAME=EMPTY   8001-76050-76050-1347-00025-00025-00000-JAY01
"""
        
        sections = self.parser.parse_sections(pds_content)
        errors = self.parser.validate_sections(sections)
        
        # Should have errors for the empty section
        assert len(errors) >= 1
        error_text = " ".join(errors).lower()
        assert "empty" in error_text or "end_line before start_line" in error_text


class TestContentTypeClassifier:
    """Test content type classification functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.classifier = ContentTypeClassifier()
    
    def test_rpg_detection(self):
        """Test RPG content detection."""
        rpg_content = """
     H
     H* READ ADDRESS CARDS AND PRINT ADDRESS LIST
     FINCARDS IPE F  80  80            READ40
     FOUTLIST O   F 132 132     OF    LPRINTER
"""
        
        language, program_type = self.classifier.classify_section(rpg_content)
        
        assert language == "RPG"
        assert program_type == ProgramType.MAIN
    
    def test_jcl_detection(self):
        """Test JCL content detection."""
        jcl_content = """
//EXAMPLE1 JOB (001),'RPG TUTORIAL 1',
//             CLASS=A,MSGCLASS=A,REGION=512K
//RPGCLG   EXEC RPGECLG,COND.LKED=(9,LT,RPG)
//RPG.SYSIN DD DISP=SHR,DSN=JAY01.RPG.TUTOR(EX1)
"""
        
        language, program_type = self.classifier.classify_section(jcl_content)
        
        assert language == "JCL"
        assert program_type == ProgramType.JOB
    
    def test_data_detection(self):
        """Test data content detection."""
        data_content = """
MICHELLE COOK            9561 BAYVIEW STREET      BALDWIN, MO 63022
PATTY JENNINGS           806 JACKSON STREET       VALPARAISO, IN 46383
RICHARD SMITH            279 PARKER BLVD          NASHAU, NH 03060
"""
        
        language, program_type = self.classifier.classify_section(data_content)
        
        assert language == "DATA"
        assert program_type == ProgramType.DATA
    
    def test_assembly_detection(self):
        """Test assembly content detection."""
        asm_content = """
         TITLE 'EXAMPLE5 - BUILD SORT NAME FOR RPG MAIN PROGRAM'
* ******************************************************************* *
EXAMPLE5 CSECT
         STM   R14,R12,12(R13)
         LR    R12,R15
         USING EXAMPLE5,R12
"""
        
        language, program_type = self.classifier.classify_section(asm_content)
        
        assert language == "ASM"
        assert program_type == ProgramType.CSECT
    
    def test_confidence_scoring(self):
        """Test confidence scoring for classifications."""
        rpg_content = """
     H
     FINCARDS IPE F  80  80            READ40
     EVAL X = Y + Z
"""
        
        language, _ = self.classifier.classify_section(rpg_content)
        confidence = self.classifier.get_confidence_score(rpg_content, language)
        
        assert language == "RPG"
        assert confidence > 0.4  # Should have reasonable confidence
    
    def test_empty_content(self):
        """Test handling of empty content."""
        language, program_type = self.classifier.classify_section("")
        
        assert language == "UNKNOWN"
        assert program_type == ProgramType.UNKNOWN


if __name__ == "__main__":
    pytest.main([__file__])