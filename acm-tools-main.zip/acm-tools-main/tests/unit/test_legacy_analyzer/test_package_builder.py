"""Unit tests for package builder."""

import pytest
import sqlite3
import tempfile
import os
from tools.legacy_analyzer.migration.package_builder import PackageBuilder
from tools.legacy_analyzer.migration.package_optimizer import PackageOptimizer
from tools.legacy_analyzer.migration.package_database import PackageDatabase
from tools.legacy_analyzer.migration.package_exporter import PackageExporter
from tools.legacy_analyzer.models.package import MigrationPackage, PackageConstraints, PackageConflict


class TestPackageBuilder:
    """Test suite for PackageBuilder."""
    
    def setup_method(self):
        """Set up test fixtures with in-memory database."""
        # Create in-memory database
        self.conn = sqlite3.connect(':memory:')
        self.cursor = self.conn.cursor()
        
        # Create test schema
        self._create_test_schema()
        self._populate_test_data()
        
        # Initialize package builder
        self.builder = PackageBuilder(self.conn)
    
    def teardown_method(self):
        """Clean up test fixtures."""
        self.conn.close()
    
    def _create_test_schema(self):
        """Create test database schema."""
        # Programs table
        self.cursor.execute("""
            CREATE TABLE programs (
                program_name VARCHAR(8) PRIMARY KEY,
                library_name VARCHAR(8),
                link_date DATE
            )
        """)
        
        # Copybooks table
        self.cursor.execute("""
            CREATE TABLE copybooks (
                copybook_name VARCHAR(8) PRIMARY KEY,
                library_name VARCHAR(8)
            )
        """)
        
        # JCL table
        self.cursor.execute("""
            CREATE TABLE jcl (
                member_name VARCHAR(8) PRIMARY KEY,
                library_name VARCHAR(8)
            )
        """)
        
        # Datasets table
        self.cursor.execute("""
            CREATE TABLE datasets (
                dataset_name VARCHAR(44) PRIMARY KEY,
                creation_date DATE
            )
        """)
        
        # Dependencies table (old format)
        self.cursor.execute("""
            CREATE TABLE dependencies (
                source_artifact VARCHAR(44),
                source_type VARCHAR(20),
                target_artifact VARCHAR(44),
                target_type VARCHAR(20),
                dependency_type VARCHAR(20),
                source_file VARCHAR(255),
                line_number INTEGER
            )
        """)
        
        # Artifact dependencies table (new format)
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_artifact_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_artifact_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(20) NOT NULL,
                source_file_path VARCHAR(255),
                target_file_path VARCHAR(255),
                line_number INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create complexity_metrics table
        self.cursor.execute("""
            CREATE TABLE complexity_metrics (
                program_name VARCHAR(44) PRIMARY KEY,
                lines_of_code INTEGER,
                total_lines INTEGER,
                cyclomatic_complexity INTEGER,
                dependency_count_in INTEGER,
                dependency_count_out INTEGER,
                composite_score REAL,
                complexity_tier VARCHAR(10),
                language_factor REAL,
                is_god_program INTEGER,
                analyzed_date TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        self.conn.commit()
    
    def _populate_test_data(self):
        """Populate test data."""
        # Insert programs
        programs = [
            ('PROG1', 'PRODLIB'),
            ('PROG2', 'PRODLIB'),
            ('PROG3', 'PRODLIB'),
            ('PROG4', 'TESTLIB'),
            ('PROG5', 'TESTLIB')
        ]
        self.cursor.executemany(
            "INSERT INTO programs (program_name, library_name) VALUES (?, ?)",
            programs
        )
        
        # Insert copybooks
        copybooks = [
            ('COPY1', 'COPYLIB'),
            ('COPY2', 'COPYLIB'),
            ('COPY3', 'COPYLIB')
        ]
        self.cursor.executemany(
            "INSERT INTO copybooks (copybook_name, library_name) VALUES (?, ?)",
            copybooks
        )
        
        # Insert JCL
        jcl = [
            ('JCL1', 'JCLLIB'),
            ('JCL2', 'JCLLIB')
        ]
        self.cursor.executemany(
            "INSERT INTO jcl (member_name, library_name) VALUES (?, ?)",
            jcl
        )
        
        # Insert datasets
        datasets = [
            ('DATASET.ONE',),
            ('DATASET.TWO',)
        ]
        self.cursor.executemany(
            "INSERT INTO datasets (dataset_name) VALUES (?)",
            datasets
        )
        
        # Insert dependencies
        dependencies = [
            # PROG1 calls PROG2 and uses COPY1
            ('PROG1', 'PROGRAM', 'PROG2', 'PROGRAM', 'CALL', None, None),
            ('PROG1', 'PROGRAM', 'COPY1', 'COPYBOOK', 'COPY', None, None),
            # PROG2 calls PROG3 and uses COPY2
            ('PROG2', 'PROGRAM', 'PROG3', 'PROGRAM', 'CALL', None, None),
            ('PROG2', 'PROGRAM', 'COPY2', 'COPYBOOK', 'COPY', None, None),
            # PROG3 uses COPY3 and DATASET.ONE
            ('PROG3', 'PROGRAM', 'COPY3', 'COPYBOOK', 'COPY', None, None),
            ('PROG3', 'PROGRAM', 'DATASET.ONE', 'DATASET', 'DATASET_REF', None, None),
            # PROG4 calls PROG5
            ('PROG4', 'PROGRAM', 'PROG5', 'PROGRAM', 'CALL', None, None),
            # JCL1 executes PROG1
            ('JCL1', 'JCL', 'PROG1', 'PROGRAM', 'EXEC_PGM', None, None)
        ]
        self.cursor.executemany(
            """INSERT INTO dependencies 
               (source_artifact, source_type, target_artifact, target_type, 
                dependency_type, source_file, line_number) 
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            dependencies
        )
        
        # Insert same data into artifact_dependencies table (new format)
        artifact_dependencies = [
            # PROG1 calls PROG2 and uses COPY1
            ('PROG1', 'PROGRAM', 'PROG2', 'PROGRAM', 'CALL', None, None, None),
            ('PROG1', 'PROGRAM', 'COPY1', 'COPYBOOK', 'COPY', None, None, None),
            # PROG2 calls PROG3 and uses COPY2
            ('PROG2', 'PROGRAM', 'PROG3', 'PROGRAM', 'CALL', None, None, None),
            ('PROG2', 'PROGRAM', 'COPY2', 'COPYBOOK', 'COPY', None, None, None),
            # PROG3 uses COPY3 and DATASET.ONE
            ('PROG3', 'PROGRAM', 'COPY3', 'COPYBOOK', 'COPY', None, None, None),
            ('PROG3', 'PROGRAM', 'DATASET.ONE', 'DATASET', 'DATASET_REF', None, None, None),
            # PROG4 calls PROG5
            ('PROG4', 'PROGRAM', 'PROG5', 'PROGRAM', 'CALL', None, None, None),
            # JCL1 executes PROG1
            ('JCL1', 'JCL', 'PROG1', 'PROGRAM', 'EXEC_PGM', None, None, None)
        ]
        self.cursor.executemany(
            """INSERT INTO artifact_dependencies 
               (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, 
                dependency_type, source_file_path, target_file_path, line_number) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            artifact_dependencies
        )
        
        # Insert complexity metrics
        complexity = [
            ('PROG1', 500, 600, 10, 2, 3, 15.5, 'MEDIUM', 1.0, 0),
            ('PROG2', 300, 350, 8, 1, 2, 10.2, 'LOW', 1.0, 0),
            ('PROG3', 200, 250, 6, 3, 1, 8.1, 'LOW', 1.0, 0),
            ('PROG4', 150, 180, 4, 0, 2, 5.5, 'LOW', 1.0, 0),
            ('PROG5', 100, 120, 3, 1, 1, 3.2, 'LOW', 1.0, 0)
        ]
        self.cursor.executemany("""
            INSERT INTO complexity_metrics 
            (program_name, lines_of_code, total_lines, cyclomatic_complexity, 
             dependency_count_in, dependency_count_out, composite_score, 
             complexity_tier, language_factor, is_god_program) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, complexity)
        
        self.conn.commit()
    
    def test_create_package_single_artifact(self):
        """Test creating a package with a single seed artifact."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1'],
            include_transitive=False
        )
        
        assert package.name == 'TestPackage'
        assert 'PROG1' in package.artifacts
        assert len(package.artifacts) == 1
    
    def test_create_package_with_transitive_dependencies(self):
        """Test creating a package with transitive dependencies."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1'],
            include_transitive=True
        )
        
        assert package.name == 'TestPackage'
        # Should include PROG1, PROG2, PROG3, COPY1, COPY2, COPY3, DATASET.ONE
        assert 'PROG1' in package.artifacts
        assert 'PROG2' in package.artifacts
        assert 'PROG3' in package.artifacts
        assert 'COPY1' in package.artifacts
        assert 'COPY2' in package.artifacts
        assert 'COPY3' in package.artifacts
        assert 'DATASET.ONE' in package.artifacts
    
    def test_create_package_with_max_depth(self):
        """Test creating a package with depth limit."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1'],
            include_transitive=True,
            max_depth=1
        )
        
        # Should include PROG1 and its direct dependencies (PROG2, COPY1)
        # but not PROG3 (depth 2)
        assert 'PROG1' in package.artifacts
        assert 'PROG2' in package.artifacts
        assert 'COPY1' in package.artifacts
        # PROG3 is at depth 2, should not be included
        assert 'PROG3' not in package.artifacts
    
    def test_package_sizing(self):
        """Test package sizing calculation."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1'],
            include_transitive=True
        )
        
        # Check that metrics are calculated
        assert package.total_loc > 0
        assert package.total_complexity > 0
        assert package.total_artifacts > 0
        
        # Total LOC should be sum of PROG1, PROG2, PROG3
        # 500 + 300 + 200 = 1000 (plus estimates for copybooks)
        assert package.total_loc >= 1000
    
    def test_external_dependencies_identification(self):
        """Test identification of external dependencies."""
        # Create package with only PROG1 and PROG2
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1'],
            include_transitive=True,
            max_depth=1
        )
        
        # PROG2 calls PROG3, which is not in package
        # So PROG3 should be an external dependency
        assert len(package.external_dependencies) > 0
    
    def test_conflict_detection(self):
        """Test conflict detection between packages."""
        # Create two packages with overlapping artifacts
        package1 = self.builder.create_package(
            name='Package1',
            seed_artifacts=['PROG1'],
            include_transitive=True
        )
        
        package2 = self.builder.create_package(
            name='Package2',
            seed_artifacts=['PROG2'],
            include_transitive=True
        )
        
        # Detect conflicts
        conflicts = self.builder.detect_conflicts([package1, package2])
        
        # PROG2, PROG3, and copybooks should be in both packages
        assert len(conflicts) > 0
        
        # Check that conflicts are recorded in packages
        assert package1.has_conflicts() or package2.has_conflicts()
    
    def test_package_validation_self_contained(self):
        """Test validation of self-contained package."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1'],
            include_transitive=True
        )
        
        # This package should be self-contained (no external deps)
        is_valid, errors = self.builder.validate_package(package)
        
        # Check if self-contained
        if package.is_self_contained():
            assert is_valid
        else:
            assert not is_valid
            assert any('external' in err.lower() for err in errors)
    
    def test_package_validation_with_constraints(self):
        """Test validation against constraints."""
        constraints = PackageConstraints(
            max_artifacts=3,
            max_loc=500,
            allow_external_deps=False
        )
        
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1'],
            include_transitive=True
        )
        
        is_valid, errors = self.builder.validate_package(package, constraints)
        
        # Package likely exceeds constraints
        if not is_valid:
            assert len(errors) > 0
    
    def test_package_statistics(self):
        """Test package statistics calculation."""
        packages = [
            self.builder.create_package('Package1', ['PROG1'], include_transitive=False),
            self.builder.create_package('Package2', ['PROG2'], include_transitive=False),
            self.builder.create_package('Package3', ['PROG3'], include_transitive=False)
        ]
        
        stats = self.builder.get_package_statistics(packages)
        
        assert stats['total_packages'] == 3
        assert stats['total_artifacts'] >= 3
        assert stats['total_loc'] > 0
        assert stats['avg_artifacts_per_package'] > 0
    
    def test_artifact_type_detection(self):
        """Test artifact type detection."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1', 'COPY1', 'JCL1'],
            include_transitive=False
        )
        
        # Check that artifacts are categorized correctly
        assert 'PROG1' in package.programs
        assert 'COPY1' in package.copybooks
        assert 'JCL1' in package.jcl
    
    def test_multiple_seed_artifacts(self):
        """Test creating package with multiple seed artifacts."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['PROG1', 'PROG4'],
            include_transitive=True
        )
        
        # Should include both dependency trees
        assert 'PROG1' in package.artifacts
        assert 'PROG4' in package.artifacts
        assert 'PROG5' in package.artifacts  # Called by PROG4
    
    def test_empty_seed_artifacts(self):
        """Test creating package with no seed artifacts."""
        package = self.builder.create_package(
            name='EmptyPackage',
            seed_artifacts=[],
            include_transitive=True
        )
        
        assert package.name == 'EmptyPackage'
        assert len(package.artifacts) == 0
    
    def test_nonexistent_artifact(self):
        """Test creating package with nonexistent artifact."""
        package = self.builder.create_package(
            name='TestPackage',
            seed_artifacts=['NONEXIST'],
            include_transitive=True
        )
        
        # Should handle gracefully
        assert package.name == 'TestPackage'
        # Nonexistent artifacts are not added if not found in inventory
        # This is correct behavior - we only package known artifacts
        assert len(package.artifacts) == 0


class TestPackageDatabase:
    """Test suite for PackageDatabase."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.conn = sqlite3.connect(':memory:')
        self.db = PackageDatabase(self.conn)
        self.db.create_schema()
    
    def teardown_method(self):
        """Clean up test fixtures."""
        self.conn.close()
    
    def test_create_schema(self):
        """Test database schema creation."""
        # Check that tables exist
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='migration_packages'
        """)
        assert cursor.fetchone() is not None
    
    def test_save_and_load_package(self):
        """Test saving and loading a package."""
        package = MigrationPackage(
            name='TestPackage',
            artifacts=['PROG1', 'PROG2', 'COPY1'],
            total_loc=1000,
            total_complexity=25.5,
            programs=['PROG1', 'PROG2'],
            copybooks=['COPY1']
        )
        
        # Save package
        package_id = self.db.save_package(package)
        assert package_id > 0
        
        # Load package
        loaded = self.db.load_package('TestPackage')
        assert loaded is not None
        assert loaded.name == 'TestPackage'
        assert loaded.total_loc == 1000
        assert loaded.total_complexity == 25.5
        assert 'PROG1' in loaded.programs
        assert 'COPY1' in loaded.copybooks
    
    def test_update_existing_package(self):
        """Test updating an existing package."""
        package = MigrationPackage(
            name='TestPackage',
            artifacts=['PROG1'],
            total_loc=500,
            programs=['PROG1']
        )
        
        # Save initial version
        self.db.save_package(package)
        
        # Update package
        package.artifacts.append('PROG2')
        package.programs.append('PROG2')
        package.total_loc = 800
        
        # Save updated version
        self.db.save_package(package)
        
        # Load and verify
        loaded = self.db.load_package('TestPackage')
        assert loaded.total_loc == 800
        assert 'PROG2' in loaded.programs
    
    def test_delete_package(self):
        """Test deleting a package."""
        package = MigrationPackage(
            name='TestPackage',
            artifacts=['PROG1'],
            programs=['PROG1']
        )
        
        self.db.save_package(package)
        
        # Delete package
        deleted = self.db.delete_package('TestPackage')
        assert deleted is True
        
        # Verify deletion
        loaded = self.db.load_package('TestPackage')
        assert loaded is None
    
    def test_get_all_packages(self):
        """Test getting all packages."""
        packages = [
            MigrationPackage(name='Package1', artifacts=['PROG1'], programs=['PROG1']),
            MigrationPackage(name='Package2', artifacts=['PROG2'], programs=['PROG2']),
            MigrationPackage(name='Package3', artifacts=['PROG3'], programs=['PROG3'])
        ]
        
        for package in packages:
            self.db.save_package(package)
        
        all_packages = self.db.get_all_packages()
        assert len(all_packages) == 3
    
    def test_get_packages_containing_artifact(self):
        """Test finding packages containing a specific artifact."""
        package1 = MigrationPackage(
            name='Package1',
            artifacts=['PROG1', 'COPY1'],
            programs=['PROG1'],
            copybooks=['COPY1']
        )
        package2 = MigrationPackage(
            name='Package2',
            artifacts=['PROG2', 'COPY1'],
            programs=['PROG2'],
            copybooks=['COPY1']
        )
        
        self.db.save_package(package1)
        self.db.save_package(package2)
        
        # Find packages containing COPY1
        packages = self.db.get_packages_containing_artifact('COPY1')
        assert len(packages) == 2
        assert 'Package1' in packages
        assert 'Package2' in packages
    
    def test_get_package_conflicts(self):
        """Test getting package conflicts."""
        package1 = MigrationPackage(
            name='Package1',
            artifacts=['PROG1', 'COPY1'],
            programs=['PROG1'],
            copybooks=['COPY1']
        )
        package2 = MigrationPackage(
            name='Package2',
            artifacts=['PROG2', 'COPY1'],
            programs=['PROG2'],
            copybooks=['COPY1']
        )
        
        self.db.save_package(package1)
        self.db.save_package(package2)
        
        conflicts = self.db.get_package_conflicts()
        assert len(conflicts) > 0
        # COPY1 should be in conflict
        copy1_conflict = next((c for c in conflicts if c['artifact_name'] == 'COPY1'), None)
        assert copy1_conflict is not None
        assert copy1_conflict['count'] == 2
    
    def test_get_package_statistics(self):
        """Test getting package statistics."""
        packages = [
            MigrationPackage(name='Package1', artifacts=['PROG1'], total_loc=500, total_complexity=10.0, programs=['PROG1']),
            MigrationPackage(name='Package2', artifacts=['PROG2'], total_loc=300, total_complexity=8.0, programs=['PROG2'])
        ]
        
        for package in packages:
            self.db.save_package(package)
        
        stats = self.db.get_package_statistics()
        assert stats['total_packages'] == 2
        assert stats['total_loc'] == 800
        assert stats['avg_loc'] == 400.0


class TestPackageExporter:
    """Test suite for PackageExporter."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.exporter = PackageExporter()
        self.temp_dir = tempfile.mkdtemp()
    
    def teardown_method(self):
        """Clean up test fixtures."""
        # Clean up temp files
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def _create_test_packages(self):
        """Create test packages."""
        return [
            MigrationPackage(
                name='Package1',
                artifacts=['PROG1', 'COPY1'],
                total_loc=500,
                total_complexity=15.5,
                programs=['PROG1'],
                copybooks=['COPY1']
            ),
            MigrationPackage(
                name='Package2',
                artifacts=['PROG2', 'JCL1'],
                total_loc=300,
                total_complexity=10.2,
                programs=['PROG2'],
                jcl=['JCL1']
            )
        ]
    
    def test_export_to_csv(self):
        """Test exporting packages to CSV."""
        packages = self._create_test_packages()
        output_file = os.path.join(self.temp_dir, 'packages.csv')
        
        self.exporter.export_to_csv(packages, output_file)
        
        # Verify file exists
        assert os.path.exists(output_file)
        
        # Verify content
        with open(output_file, 'r') as f:
            content = f.read()
            assert 'Package1' in content
            assert 'Package2' in content
            assert 'PROG1' in content
    
    def test_export_to_json(self):
        """Test exporting packages to JSON."""
        packages = self._create_test_packages()
        output_file = os.path.join(self.temp_dir, 'packages.json')
        
        self.exporter.export_to_json(packages, output_file)
        
        # Verify file exists
        assert os.path.exists(output_file)
        
        # Verify content
        import json
        with open(output_file, 'r') as f:
            data = json.load(f)
            assert len(data) == 2
            assert data[0]['name'] == 'Package1'
    
    def test_export_to_markdown(self):
        """Test exporting packages to Markdown."""
        packages = self._create_test_packages()
        output_file = os.path.join(self.temp_dir, 'packages.md')
        
        self.exporter.export_to_markdown(packages, output_file)
        
        # Verify file exists
        assert os.path.exists(output_file)
        
        # Verify content
        with open(output_file, 'r') as f:
            content = f.read()
            assert '# Migration Packages' in content
            assert 'Package1' in content
            assert 'Package2' in content
    
    def test_export_summary_to_csv(self):
        """Test exporting package summary to CSV."""
        packages = self._create_test_packages()
        output_file = os.path.join(self.temp_dir, 'summary.csv')
        
        self.exporter.export_summary_to_csv(packages, output_file)
        
        # Verify file exists
        assert os.path.exists(output_file)
        
        # Verify content
        with open(output_file, 'r') as f:
            lines = f.readlines()
            assert len(lines) == 3  # Header + 2 packages


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
