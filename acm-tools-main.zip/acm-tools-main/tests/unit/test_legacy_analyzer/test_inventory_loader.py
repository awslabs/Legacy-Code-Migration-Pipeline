"""Unit tests for inventory loader."""

import pytest
import tempfile
import os
import csv
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.legacy_analyzer.inventory.inventory_loader import InventoryLoader


class TestInventoryLoader:
    """Test suite for inventory loader."""
    
    def setup_method(self):
        """Set up test fixtures."""
        # Create temporary database
        self.temp_db = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.db')
        self.temp_db.close()
        self.db_path = self.temp_db.name
        
        # Initialize database and loader
        self.database = SQLiteAdapter(self.db_path)
        self.database.connect()
        self.loader = InventoryLoader(self.database)
        self.loader.create_inventory_schema()
    
    def teardown_method(self):
        """Clean up test fixtures."""
        self.database.close()
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    def create_csv_file(self, data, headers):
        """Helper to create temporary CSV file."""
        temp_csv = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='')
        writer = csv.DictWriter(temp_csv, fieldnames=headers)
        writer.writeheader()
        writer.writerows(data)
        temp_csv.close()
        return temp_csv.name
    
    def test_load_cics_inventory_old_format(self):
        """Test loading CICS inventory with old CSV format (backward compatibility)."""
        # Old format: only required columns
        headers = ['resource_name', 'resource_type', 'group_name', 'status', 'program_name']
        data = [
            {
                'resource_name': 'CAUP',
                'resource_type': 'TRANSACTION',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': 'COACTUPC'
            },
            {
                'resource_name': 'COACTUPC',
                'resource_type': 'PROGRAM',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': ''
            },
            {
                'resource_name': 'ACCTDAT',
                'resource_type': 'FILE',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': ''
            }
        ]
        
        csv_file = self.create_csv_file(data, headers)
        
        try:
            # Load the CSV
            self.loader.load_cics_inventory(csv_file)
            
            # Verify data was loaded
            cursor = self.database.cursor()
            cursor.execute("SELECT COUNT(*) FROM inventory_cics")
            count = cursor.fetchone()[0]
            assert count == 3
            
            # Verify TRANSACTION
            cursor.execute(
                "SELECT * FROM inventory_cics WHERE resource_name = ? AND resource_type = ?",
                ('CAUP', 'TRANSACTION')
            )
            row = cursor.fetchone()
            assert row is not None
            # Get column names
            col_names = [desc[0] for desc in cursor.description]
            row_dict = dict(zip(col_names, row))
            assert row_dict['resource_name'] == 'CAUP'
            assert row_dict['resource_type'] == 'TRANSACTION'
            assert row_dict['group_name'] == 'CARDDEMO'
            assert row_dict['status'] == 'ENABLED'
            assert row_dict['program_name'] == 'COACTUPC'
            
            # Verify stats
            assert self.loader.stats['cics_processed'] == 3
            assert self.loader.stats['cics_inserted'] == 3
            
        finally:
            os.unlink(csv_file)
    
    def test_load_cics_inventory_enhanced_format(self):
        """Test loading CICS inventory with enhanced CSV format (new columns)."""
        # Enhanced format: includes dataset_name, description, language
        headers = [
            'resource_name', 'resource_type', 'group_name', 'status', 
            'program_name', 'dataset_name', 'description', 'language'
        ]
        data = [
            {
                'resource_name': 'CAUP',
                'resource_type': 'TRANSACTION',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': 'COACTUPC',
                'dataset_name': '',
                'description': 'Account Update Transaction',
                'language': ''
            },
            {
                'resource_name': 'COACTUPC',
                'resource_type': 'PROGRAM',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': '',
                'dataset_name': '',
                'description': 'Account Update Program',
                'language': 'COBOL'
            },
            {
                'resource_name': 'ACCTDAT',
                'resource_type': 'FILE',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': '',
                'dataset_name': 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS',
                'description': 'Account Data File',
                'language': ''
            }
        ]
        
        csv_file = self.create_csv_file(data, headers)
        
        try:
            # Load the CSV
            self.loader.load_cics_inventory(csv_file)
            
            # Verify data was loaded
            cursor = self.database.cursor()
            cursor.execute("SELECT COUNT(*) FROM inventory_cics")
            count = cursor.fetchone()[0]
            assert count == 3
            
            # Verify TRANSACTION with description
            cursor.execute(
                "SELECT * FROM inventory_cics WHERE resource_name = ? AND resource_type = ?",
                ('CAUP', 'TRANSACTION')
            )
            row = cursor.fetchone()
            assert row is not None
            col_names = [desc[0] for desc in cursor.description]
            row_dict = dict(zip(col_names, row))
            assert row_dict['description'] == 'Account Update Transaction'
            
            # Verify PROGRAM with language
            cursor.execute(
                "SELECT * FROM inventory_cics WHERE resource_name = ? AND resource_type = ?",
                ('COACTUPC', 'PROGRAM')
            )
            row = cursor.fetchone()
            assert row is not None
            col_names = [desc[0] for desc in cursor.description]
            row_dict = dict(zip(col_names, row))
            assert row_dict['language'] == 'COBOL'
            assert row_dict['description'] == 'Account Update Program'
            
            # Verify FILE with dataset_name
            cursor.execute(
                "SELECT * FROM inventory_cics WHERE resource_name = ? AND resource_type = ?",
                ('ACCTDAT', 'FILE')
            )
            row = cursor.fetchone()
            assert row is not None
            col_names = [desc[0] for desc in cursor.description]
            row_dict = dict(zip(col_names, row))
            assert row_dict['dataset_name'] == 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS'
            assert row_dict['description'] == 'Account Data File'
            
            # Verify enhanced column counts
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE dataset_name IS NOT NULL")
            dataset_count = cursor.fetchone()[0]
            assert dataset_count == 1
            
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE description IS NOT NULL")
            desc_count = cursor.fetchone()[0]
            assert desc_count == 3
            
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE language IS NOT NULL")
            lang_count = cursor.fetchone()[0]
            assert lang_count == 1
            
        finally:
            os.unlink(csv_file)
    
    def test_load_cics_inventory_partial_enhanced_format(self):
        """Test loading CICS inventory with only some enhanced columns."""
        # Partial enhanced format: only description column added
        headers = [
            'resource_name', 'resource_type', 'group_name', 'status', 
            'program_name', 'description'
        ]
        data = [
            {
                'resource_name': 'CAUP',
                'resource_type': 'TRANSACTION',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': 'COACTUPC',
                'description': 'Account Update Transaction'
            }
        ]
        
        csv_file = self.create_csv_file(data, headers)
        
        try:
            # Load the CSV
            self.loader.load_cics_inventory(csv_file)
            
            # Verify data was loaded
            cursor = self.database.cursor()
            cursor.execute("SELECT COUNT(*) FROM inventory_cics")
            count = cursor.fetchone()[0]
            assert count == 1
            
            # Verify description is present but dataset_name and language are not
            cursor.execute(
                "SELECT * FROM inventory_cics WHERE resource_name = ?",
                ('CAUP',)
            )
            row = cursor.fetchone()
            assert row is not None
            col_names = [desc[0] for desc in cursor.description]
            row_dict = dict(zip(col_names, row))
            assert row_dict['description'] == 'Account Update Transaction'
            # These columns should be NULL since they weren't in the CSV
            assert row_dict.get('dataset_name') is None
            assert row_dict.get('language') is None
            
        finally:
            os.unlink(csv_file)
    
    def test_load_cics_inventory_update_existing(self):
        """Test that loading CICS inventory updates existing records."""
        headers = ['resource_name', 'resource_type', 'group_name', 'status', 'program_name']
        
        # First load
        data1 = [
            {
                'resource_name': 'CAUP',
                'resource_type': 'TRANSACTION',
                'group_name': 'CARDDEMO',
                'status': 'ENABLED',
                'program_name': 'COACTUPC'
            }
        ]
        csv_file1 = self.create_csv_file(data1, headers)
        
        try:
            self.loader.load_cics_inventory(csv_file1)
            
            # Verify first load
            cursor = self.database.cursor()
            cursor.execute("SELECT COUNT(*) FROM inventory_cics")
            count = cursor.fetchone()[0]
            assert count == 1
            
            # Second load with updated data
            data2 = [
                {
                    'resource_name': 'CAUP',
                    'resource_type': 'TRANSACTION',
                    'group_name': 'CARDDEMO',
                    'status': 'DISABLED',  # Changed status
                    'program_name': 'COACTUPC'
                }
            ]
            csv_file2 = self.create_csv_file(data2, headers)
            
            try:
                self.loader.load_cics_inventory(csv_file2)
                
                # Verify still only one record
                cursor.execute("SELECT COUNT(*) FROM inventory_cics")
                count = cursor.fetchone()[0]
                assert count == 1
                
                # Verify status was updated
                cursor.execute(
                    "SELECT status FROM inventory_cics WHERE resource_name = ?",
                    ('CAUP',)
                )
                status = cursor.fetchone()[0]
                assert status == 'DISABLED'
                
                # Verify update stats
                assert self.loader.stats['cics_updated'] == 1
                
            finally:
                os.unlink(csv_file2)
                
        finally:
            os.unlink(csv_file1)
    
    def test_load_cics_inventory_validation_missing_file(self):
        """Test validation fails for missing file."""
        with pytest.raises(ValueError, match="CSV validation failed"):
            self.loader.load_cics_inventory('/nonexistent/file.csv')
    
    def test_load_cics_inventory_validation_missing_columns(self):
        """Test validation fails for missing required columns."""
        # Missing resource_type column
        headers = ['resource_name', 'group_name']
        data = [{'resource_name': 'CAUP', 'group_name': 'CARDDEMO'}]
        
        csv_file = self.create_csv_file(data, headers)
        
        try:
            with pytest.raises(ValueError, match="Missing required columns"):
                self.loader.load_cics_inventory(csv_file)
        finally:
            os.unlink(csv_file)
    
    def test_load_cics_inventory_empty_optional_columns(self):
        """Test that empty optional columns are handled as NULL."""
        headers = [
            'resource_name', 'resource_type', 'group_name', 'status', 
            'program_name', 'dataset_name', 'description', 'language'
        ]
        data = [
            {
                'resource_name': 'CAUP',
                'resource_type': 'TRANSACTION',
                'group_name': '',  # Empty optional
                'status': '',  # Empty optional
                'program_name': '',  # Empty optional
                'dataset_name': '',  # Empty enhanced
                'description': '',  # Empty enhanced
                'language': ''  # Empty enhanced
            }
        ]
        
        csv_file = self.create_csv_file(data, headers)
        
        try:
            self.loader.load_cics_inventory(csv_file)
            
            # Verify data was loaded
            cursor = self.database.cursor()
            cursor.execute("SELECT * FROM inventory_cics WHERE resource_name = ?", ('CAUP',))
            row = cursor.fetchone()
            assert row is not None
            
            col_names = [desc[0] for desc in cursor.description]
            row_dict = dict(zip(col_names, row))
            
            # All optional/enhanced columns should be NULL
            assert row_dict['group_name'] is None
            assert row_dict['status'] is None
            assert row_dict['program_name'] is None
            assert row_dict.get('dataset_name') is None
            assert row_dict.get('description') is None
            assert row_dict.get('language') is None
            
        finally:
            os.unlink(csv_file)
