"""Unit tests for parallel processor."""

import pytest
import time
from tools.legacy_analyzer.utils.parallel import (
    ParallelProcessor, BatchProcessor, ProgressTracker,
    parallel_map, parallel_filter, get_optimal_worker_count
)


def simple_function(x):
    """Simple test function that doubles a number."""
    return x * 2


def slow_function(x):
    """Slow test function for testing progress tracking."""
    time.sleep(0.1)
    return x * 2


def error_function(x):
    """Function that raises an error for testing error handling."""
    if x < 0:
        raise ValueError(f"Negative value: {x}")
    return x * 2


def predicate_function(x):
    """Predicate function for testing filtering."""
    return x % 2 == 0


class TestProgressTracker:
    """Test suite for ProgressTracker."""
    
    def test_initialization(self):
        """Test progress tracker initialization."""
        tracker = ProgressTracker(total=100, show_progress=False)
        
        assert tracker.total == 100
        assert tracker.completed == 0
        assert tracker.successful == 0
        assert tracker.failed == 0
    
    def test_update_success(self):
        """Test updating progress with successful items."""
        tracker = ProgressTracker(total=10, show_progress=False)
        
        tracker.update(success=True)
        tracker.update(success=True)
        
        assert tracker.completed == 2
        assert tracker.successful == 2
        assert tracker.failed == 0
    
    def test_update_failure(self):
        """Test updating progress with failed items."""
        tracker = ProgressTracker(total=10, show_progress=False)
        
        tracker.update(success=False)
        tracker.update(success=True)
        
        assert tracker.completed == 2
        assert tracker.successful == 1
        assert tracker.failed == 1
    
    def test_get_progress(self):
        """Test getting progress information."""
        tracker = ProgressTracker(total=10, show_progress=False)
        
        tracker.update(success=True)
        tracker.update(success=True)
        
        progress = tracker.get_progress()
        
        assert progress.total == 10
        assert progress.completed == 2
        assert progress.successful == 2
        assert progress.failed == 0
        assert progress.percent_complete == 20.0
    
    def test_items_per_second(self):
        """Test calculating items per second."""
        tracker = ProgressTracker(total=10, show_progress=False)
        
        time.sleep(0.1)
        tracker.update(success=True)
        
        progress = tracker.get_progress()
        assert progress.items_per_second > 0


class TestParallelProcessor:
    """Test suite for ParallelProcessor."""
    
    def test_process_simple(self):
        """Test processing simple items."""
        processor = ParallelProcessor(max_workers=2, show_progress=False)
        items = [1, 2, 3, 4, 5]
        
        results = processor.process(simple_function, items)
        
        assert len(results) == 5
        assert all(r.success for r in results)
        assert sorted([r.result for r in results]) == [2, 4, 6, 8, 10]
    
    def test_process_empty_list(self):
        """Test processing empty list."""
        processor = ParallelProcessor(max_workers=2, show_progress=False)
        
        results = processor.process(simple_function, [])
        
        assert len(results) == 0
    
    def test_process_with_errors(self):
        """Test processing with some errors."""
        processor = ParallelProcessor(max_workers=2, show_progress=False)
        items = [1, -1, 2, -2, 3]
        
        results = processor.process(error_function, items)
        
        assert len(results) == 5
        
        successful = [r for r in results if r.success]
        failed = [r for r in results if not r.success]
        
        assert len(successful) == 3
        assert len(failed) == 2
        assert all('Negative value' in r.error for r in failed)
    
    def test_process_with_callback(self):
        """Test processing with callback function."""
        processor = ParallelProcessor(max_workers=2, show_progress=False)
        items = [1, 2, 3]
        
        callback_results = []
        
        def callback(result):
            callback_results.append(result.item)
        
        results = processor.process_with_callback(simple_function, items, callback)
        
        assert len(results) == 3
        assert len(callback_results) == 3
        assert set(callback_results) == {1, 2, 3}
    
    def test_max_workers_auto(self):
        """Test automatic worker count detection."""
        processor = ParallelProcessor(max_workers=None, show_progress=False)
        
        import multiprocessing
        assert processor.max_workers == multiprocessing.cpu_count()
    
    def test_use_threads(self):
        """Test using threads instead of processes."""
        processor = ParallelProcessor(max_workers=2, show_progress=False, use_threads=True)
        items = [1, 2, 3]
        
        results = processor.process(simple_function, items)
        
        assert len(results) == 3
        assert all(r.success for r in results)
    
    def test_result_duration(self):
        """Test that results include duration."""
        processor = ParallelProcessor(max_workers=2, show_progress=False)
        items = [1, 2]
        
        results = processor.process(simple_function, items)
        
        assert all(r.duration >= 0 for r in results)


class TestBatchProcessor:
    """Test suite for BatchProcessor."""
    
    def test_process_batches(self):
        """Test processing items in batches."""
        processor = BatchProcessor(batch_size=2, max_workers=2, show_progress=False)
        items = [1, 2, 3, 4, 5]
        
        results = processor.process(simple_function, items)
        
        assert len(results) == 5
        assert all(r.success for r in results)
        
        result_values = sorted([r.result for r in results])
        assert result_values == [2, 4, 6, 8, 10]
    
    def test_batch_size(self):
        """Test that items are processed in correct batch sizes."""
        processor = BatchProcessor(batch_size=3, max_workers=2, show_progress=False)
        items = list(range(10))
        
        results = processor.process(simple_function, items)
        
        # Should process all items
        assert len(results) == 10
        assert all(r.success for r in results)
    
    def test_batch_with_errors(self):
        """Test batch processing with errors."""
        processor = BatchProcessor(batch_size=2, max_workers=2, show_progress=False)
        items = [1, -1, 2, -2, 3]
        
        results = processor.process(error_function, items)
        
        successful = [r for r in results if r.success]
        failed = [r for r in results if not r.success]
        
        assert len(successful) == 3
        assert len(failed) == 2


class TestParallelHelpers:
    """Test suite for parallel helper functions."""
    
    def test_parallel_map(self):
        """Test parallel_map function."""
        items = [1, 2, 3, 4, 5]
        
        results = parallel_map(simple_function, items, max_workers=2, show_progress=False)
        
        assert sorted(results) == [2, 4, 6, 8, 10]
    
    def test_parallel_map_with_errors(self):
        """Test parallel_map with errors (only returns successful)."""
        items = [1, -1, 2, -2, 3]
        
        results = parallel_map(error_function, items, max_workers=2, show_progress=False)
        
        # Should only return successful results
        assert len(results) == 3
        assert sorted(results) == [2, 4, 6]
    
    def test_parallel_filter(self):
        """Test parallel_filter function."""
        items = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        
        results = parallel_filter(predicate_function, items, max_workers=2, show_progress=False)
        
        # Should return only even numbers
        assert sorted(results) == [2, 4, 6, 8, 10]
    
    def test_get_optimal_worker_count_cpu(self):
        """Test getting optimal worker count for CPU-bound tasks."""
        import multiprocessing
        
        count = get_optimal_worker_count('cpu')
        
        assert count == multiprocessing.cpu_count()
    
    def test_get_optimal_worker_count_io(self):
        """Test getting optimal worker count for I/O-bound tasks."""
        import multiprocessing
        
        count = get_optimal_worker_count('io')
        
        # Should be 2x CPU count for I/O tasks
        assert count == multiprocessing.cpu_count() * 2
    
    def test_get_optimal_worker_count_default(self):
        """Test getting optimal worker count with unknown task type."""
        import multiprocessing
        
        count = get_optimal_worker_count('unknown')
        
        assert count == multiprocessing.cpu_count()


class TestIntegration:
    """Integration tests for parallel processing."""
    
    def test_large_dataset(self):
        """Test processing a large dataset."""
        processor = ParallelProcessor(max_workers=4, show_progress=False)
        items = list(range(1000))
        
        results = processor.process(simple_function, items)
        
        assert len(results) == 1000
        assert all(r.success for r in results)
        
        # Verify all results are correct
        expected = [x * 2 for x in items]
        actual = sorted([r.result for r in results])
        assert actual == expected
    
    def test_mixed_success_failure(self):
        """Test processing with mixed success and failure."""
        processor = ParallelProcessor(max_workers=4, show_progress=False)
        items = list(range(-50, 51))  # Mix of negative and positive
        
        results = processor.process(error_function, items)
        
        assert len(results) == 101
        
        successful = [r for r in results if r.success]
        failed = [r for r in results if not r.success]
        
        # 0 and positive numbers should succeed
        assert len(successful) == 51
        # Negative numbers should fail
        assert len(failed) == 50
