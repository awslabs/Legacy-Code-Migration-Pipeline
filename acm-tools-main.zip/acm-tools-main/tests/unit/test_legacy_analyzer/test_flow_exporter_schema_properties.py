"""
Property-based tests for MigrationFlowExporter JSON schema conformance

Tests cover:
- Property 7: JSON Schema Conformance
  For any exported flow JSON, the structure should conform to the migration flow schema
  with all required fields present and all field names using camelCase convention.
  
**Feature: flow-analysis-enhancements**
**Validates: Requirements 5.1, 5.2, 5.4**
"""

import sqlite3
import json
from hypothesis import given, strategies as st, settings, assume

from tools.legacy_analyzer.migration import (
    MigrationFlowExporter,
    MigrationFlowSchema,
    JSONSchemaValidator
)


# Strategy for generating valid program names
program_names = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), min_codepoint=65, max_codepoint=90),
    min_size=4,
    max_size=8
)

# Strategy for generating valid flow IDs
flow_ids = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_',
    min_size=5,
    max_size=20
).map(lambda x: f"FLOW_{x}")

# Strategy for generating program types
program_types = st.sampled_from(['MAIN', 'SUBPROGRAM', 'ENTRY_POINT', 'CSECT', 'ROUTINE'])

# Strategy for generating languages
languages = st.sampled_from(['COBOL', 'PLI', 'ASSEMBLER', 'REXX'])


def create_test_database_with_flow(
    flow_id: str,
    entry_program: str,
    programs: list,
    copybooks: list = None,
    datasets: list = None
):
    """
    Create an in-memory test database with a flow and program metadata.
    
    Args:
        flow_id: Flow ID
        entry_program: Entry program name
        programs: List of tuples (name, program_type, language)
        copybooks: List of copybook names
        datasets: List of dataset names
        
    Returns:
        SQLite connection with populated data
    """
    conn = sqlite3.connect(':memory:')
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    cursor = conn.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Create inventory table for copybook lookups (matching flow_exporter expectations)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            artifact_name TEXT,
            artifact_type TEXT,
            file_path TEXT,
            language TEXT,
            PRIMARY KEY (artifact_name, artifact_type)
        )
    """)
    
    # Insert flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            priority, business_domain,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        flow_id, f'Flow {entry_program}', entry_program, 'JCL',
        len(programs), len(copybooks or []), len(datasets or []),
        1000, 20, 50.0, 'MEDIUM',
        1, 'Test',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert entry type
    cursor.execute("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, (flow_id, 'JCL', 'JOB001', json.dumps({'jclName': 'JOB001'})))
    
    # Insert programs into scope and metadata
    for i, (prog_name, prog_type, lang) in enumerate(programs):
        # Add to flow scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_id, 'PROGRAM', prog_name))
        
        # Add to program_file_mapping
        file_path = f'src/{lang.lower()}/{prog_name}.{lang.lower()[:3]}'
        cursor.execute("""
            INSERT INTO program_file_mapping (
                program_name, file_path, start_line, end_line, program_type, language
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (
            prog_name,
            file_path,
            1,
            100 + i * 50,
            prog_type,
            lang
        ))
    
    # Insert copybooks
    if copybooks:
        for cb_name in copybooks:
            cursor.execute("""
                INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
                VALUES (?, ?, ?)
            """, (flow_id, 'COPYBOOK', cb_name))
            
            # Add to inventory table (matching flow_exporter expectations)
            file_path = f'src/copybooks/{cb_name}.cpy'
            cursor.execute("""
                INSERT INTO inventory (artifact_name, artifact_type, file_path, language)
                VALUES (?, ?, ?, ?)
            """, (cb_name, 'COPYBOOK', file_path, 'COBOL'))
    
    # Insert datasets
    if datasets:
        for ds_name in datasets:
            cursor.execute("""
                INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
                VALUES (?, ?, ?)
            """, (flow_id, 'DATASET', ds_name))
    
    # Insert empty data operations to avoid incomplete flow warnings
    cursor.execute("""
        INSERT INTO flow_data_operations (
            flow_id, operation_category, operation_type, db_type, target, program, mode
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (flow_id, 'READ', 'SELECT', 'DB2', 'DUMMY_TABLE', entry_program, 'INPUT'))
    
    conn.commit()
    return conn


@given(
    flow_id=flow_ids,
    entry_program=program_names,
    num_programs=st.integers(min_value=1, max_value=10),
    num_copybooks=st.integers(min_value=0, max_value=5),
    num_datasets=st.integers(min_value=0, max_value=5)
)
@settings(max_examples=100)
def test_property_json_schema_conformance(
    flow_id,
    entry_program,
    num_programs,
    num_copybooks,
    num_datasets
):
    """
    Property 7: JSON Schema Conformance
    
    For any exported flow JSON, the structure should conform to the migration flow schema
    with all required fields present and all field names using camelCase convention.
    
    **Feature: flow-analysis-enhancements, Property 7: JSON Schema Conformance**
    **Validates: Requirements 5.1, 5.2, 5.4**
    """
    # Generate unique program names
    program_names_list = [
        f"PROG{i:03d}" for i in range(num_programs)
    ]
    
    # Generate programs with metadata
    programs = [
        (name, 'MAIN' if i == 0 else 'SUBPROGRAM', 'COBOL')
        for i, name in enumerate(sorted(program_names_list))
    ]
    
    # Generate copybook names
    copybooks = [f"COPY{i:03d}" for i in range(num_copybooks)]
    
    # Generate dataset names
    datasets = [f"DATASET.{i:03d}" for i in range(num_datasets)]
    
    # Create test database
    conn = create_test_database_with_flow(
        flow_id, entry_program, programs, copybooks, datasets
    )
    
    try:
        # Create exporter
        exporter = MigrationFlowExporter(
            conn,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Export flows (returns dict with 'flows' key)
        export_data = exporter.export_flows([flow_id])
        
        # Validate JSON schema conformance
        validator = JSONSchemaValidator()
        is_valid, errors = validator.validate_export(export_data)
        
        # Assert validation passes
        assert is_valid, f"JSON schema validation failed: {errors}"
        
        # Additional checks for camelCase field names
        for flow in export_data['flows']:
            # Check top-level flow fields
            for field_name in flow.keys():
                assert validator.is_camel_case(field_name), \
                    f"Flow field '{field_name}' is not camelCase"
            
            # Check scope fields
            if 'scope' in flow:
                for field_name in flow['scope'].keys():
                    assert validator.is_camel_case(field_name), \
                        f"Scope field '{field_name}' is not camelCase"
                
                # Check program fields
                if 'programs' in flow['scope']:
                    for program in flow['scope']['programs']:
                        for field_name in program.keys():
                            assert validator.is_camel_case(field_name), \
                                f"Program field '{field_name}' is not camelCase"
                
                # Check copybook fields
                if 'copybooks' in flow['scope']:
                    for copybook in flow['scope']['copybooks']:
                        for field_name in copybook.keys():
                            assert validator.is_camel_case(field_name), \
                                f"Copybook field '{field_name}' is not camelCase"
        
    finally:
        conn.close()


@given(
    flow_id=flow_ids,
    entry_program=program_names,
    num_programs=st.integers(min_value=2, max_value=10)
)
@settings(max_examples=100)
def test_property_alphabetical_ordering(flow_id, entry_program, num_programs):
    """
    Property 7: JSON Schema Conformance (Alphabetical Ordering)
    
    For any exported flow JSON, programs and copybooks in scope should be
    sorted alphabetically by name.
    
    **Feature: flow-analysis-enhancements, Property 7: JSON Schema Conformance**
    **Validates: Requirements 5.5**
    """
    # Generate program names (intentionally unsorted)
    program_names_list = [
        f"PROG{i:03d}" for i in range(num_programs)
    ]
    
    # Shuffle to ensure they're not already sorted
    import random
    shuffled_names = program_names_list.copy()
    random.shuffle(shuffled_names)
    
    # Generate programs with metadata
    programs = [
        (name, 'MAIN' if i == 0 else 'SUBPROGRAM', 'COBOL')
        for i, name in enumerate(shuffled_names)
    ]
    
    # Create test database
    conn = create_test_database_with_flow(
        flow_id, entry_program, programs
    )
    
    try:
        # Create exporter
        exporter = MigrationFlowExporter(
            conn,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Export flows (returns dict with 'flows' key)
        export_data = exporter.export_flows([flow_id])
        
        # Check that programs are sorted alphabetically
        for flow in export_data['flows']:
            if 'scope' in flow and 'programs' in flow['scope']:
                programs_in_export = flow['scope']['programs']
                program_names_in_export = [p['name'] for p in programs_in_export]
                
                # Verify alphabetical order
                sorted_names = sorted(program_names_in_export)
                assert program_names_in_export == sorted_names, \
                    f"Programs not sorted: {program_names_in_export} != {sorted_names}"
        
    finally:
        conn.close()


@given(
    flow_id=flow_ids,
    entry_program=program_names,
    num_programs=st.integers(min_value=1, max_value=10)
)
@settings(max_examples=100)
def test_property_field_type_consistency(flow_id, entry_program, num_programs):
    """
    Property 7: JSON Schema Conformance (Field Type Consistency)
    
    For any exported flow JSON, all fields should have consistent types
    matching the expected schema.
    
    **Feature: flow-analysis-enhancements, Property 7: JSON Schema Conformance**
    **Validates: Requirements 5.1, 5.2**
    """
    # Generate programs
    program_names_list = [f"PROG{i:03d}" for i in range(num_programs)]
    programs = [
        (name, 'MAIN' if i == 0 else 'SUBPROGRAM', 'COBOL')
        for i, name in enumerate(sorted(program_names_list))
    ]
    
    # Create test database
    conn = create_test_database_with_flow(
        flow_id, entry_program, programs
    )
    
    try:
        # Create exporter
        exporter = MigrationFlowExporter(
            conn,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Export flows (returns dict with 'flows' key)
        export_data = exporter.export_flows([flow_id])
        
        # Validate field types
        validator = JSONSchemaValidator()
        
        for flow in export_data['flows']:
            # Check required string fields
            assert isinstance(flow['flowId'], str), "flowId must be string"
            assert isinstance(flow['name'], str), "name must be string"
            
            # Check entryPoint structure
            assert isinstance(flow['entryPoint'], dict), "entryPoint must be dict"
            assert isinstance(flow['entryPoint']['program'], str), "entryPoint.program must be string"
            assert isinstance(flow['entryPoint']['types'], list), "entryPoint.types must be list"
            if 'primaryType' in flow['entryPoint']:
                assert isinstance(flow['entryPoint']['primaryType'], str), "entryPoint.primaryType must be string"
            
            # Check required list fields
            assert isinstance(flow['invokedByJobs'], list), "invokedByJobs must be list"
            
            # Check required dict fields
            assert isinstance(flow['scope'], dict), "scope must be dict"
            assert isinstance(flow['interfaces'], dict), "interfaces must be dict"
            assert isinstance(flow['dataOperations'], dict), "dataOperations must be dict"
            assert isinstance(flow['dependencies'], dict), "dependencies must be dict"
            assert isinstance(flow['complexity'], dict), "complexity must be dict"
            
            # Check scope structure
            if 'programs' in flow['scope']:
                assert isinstance(flow['scope']['programs'], list), "programs must be list"
                for program in flow['scope']['programs']:
                    assert isinstance(program, dict), "program must be dict"
                    assert isinstance(program['name'], str), "program name must be string"
                    
                    # Check optional metadata fields
                    if 'filePath' in program:
                        assert isinstance(program['filePath'], str), "filePath must be string"
                    if 'startLine' in program:
                        assert isinstance(program['startLine'], int), "startLine must be int"
                    if 'endLine' in program:
                        assert isinstance(program['endLine'], int), "endLine must be int"
                    if 'programType' in program:
                        assert isinstance(program['programType'], str), "programType must be string"
                    if 'language' in program:
                        assert isinstance(program['language'], str), "language must be string"
            
            if 'copybooks' in flow['scope']:
                assert isinstance(flow['scope']['copybooks'], list), "copybooks must be list"
            
            if 'datasets' in flow['scope']:
                assert isinstance(flow['scope']['datasets'], list), "datasets must be list"
        
    finally:
        conn.close()


@given(
    flow_id=flow_ids,
    entry_program=program_names,
    num_programs=st.integers(min_value=1, max_value=5)
)
@settings(max_examples=100)
def test_property_metadata_completeness(flow_id, entry_program, num_programs):
    """
    Property 7: JSON Schema Conformance (Metadata Completeness)
    
    For any program with file metadata in the database, the exported JSON
    should include all metadata fields (filePath, startLine, endLine, programType, language).
    
    **Feature: flow-analysis-enhancements, Property 7: JSON Schema Conformance**
    **Validates: Requirements 2.2, 2.5**
    """
    # Generate programs with metadata
    program_names_list = [f"PROG{i:03d}" for i in range(num_programs)]
    programs = [
        (name, prog_type, lang)
        for i, name in enumerate(sorted(program_names_list))
        for prog_type in ['MAIN' if i == 0 else 'SUBPROGRAM']
        for lang in ['COBOL']
    ]
    
    # Create test database
    conn = create_test_database_with_flow(
        flow_id, entry_program, programs
    )
    
    try:
        # Create exporter with metadata enabled
        exporter = MigrationFlowExporter(
            conn,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Export flows (returns dict with 'flows' key)
        export_data = exporter.export_flows([flow_id])
        
        # Verify metadata completeness
        for flow in export_data['flows']:
            if 'scope' in flow and 'programs' in flow['scope']:
                for program in flow['scope']['programs']:
                    # All programs should have metadata since we added it to the database
                    assert 'filePath' in program, \
                        f"Program {program['name']} missing filePath"
                    assert 'startLine' in program, \
                        f"Program {program['name']} missing startLine"
                    assert 'endLine' in program, \
                        f"Program {program['name']} missing endLine"
                    assert 'programType' in program, \
                        f"Program {program['name']} missing programType"
                    assert 'language' in program, \
                        f"Program {program['name']} missing language"
                    
                    # Verify values are not None
                    assert program['filePath'] is not None
                    assert program['startLine'] is not None
                    assert program['endLine'] is not None
                    assert program['programType'] is not None
                    assert program['language'] is not None
        
    finally:
        conn.close()
