"""Property-based tests for flow analysis program granularity.

**Feature: program-level-dependency-tracking, Property 7: Flow analysis program granularity**
**Validates: Requirements 4.1, 4.3, 4.5**

Tests that the Flow_Analyzer operates on individual program names and maintains 
accurate program-to-program call relationships with file location references.
"""

import pytest
from hypothesis import given, strategies as st, settings, HealthCheck
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from tools.legacy_analyzer.models.dependency import Dependency, DependencyType
from tools.legacy_analyzer.models.flow import ProgramFlow
import sqlite3
import tempfile
import os


# Test data generators
@st.composite
def generate_program_name(draw):
    """Generate valid program names."""
    # Mainframe program names are typically 1-8 characters, alphanumeric
    length = draw(st.integers(min_value=1, max_value=8))
    name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
        min_size=length,
        max_size=length
    ))
    return name if name else "PROG1"  # Fallback for empty names


@st.composite
def generate_program_dependency(draw):
    """Generate a program-to-program dependency."""
    source_program = draw(generate_program_name())
    target_program = draw(generate_program_name())
    
    # Ensure source and target are different
    if source_program == target_program:
        target_program = source_program + "X"
    
    dependency_type = draw(st.sampled_from([
        DependencyType.CALL,
        DependencyType.CICS_LINK,
        DependencyType.CICS_START,
        DependencyType.EXEC_PGM
    ]))
    
    line_number = draw(st.integers(min_value=1, max_value=1000))
    
    return Dependency(
        source_artifact=source_program,
        source_type='PROGRAM',
        target_artifact=target_program,
        target_type='PROGRAM',
        dependency_type=dependency_type,
        line_number=line_number
    )


@st.composite
def generate_program_dependencies_list(draw):
    """Generate a list of program dependencies."""
    dependencies = draw(st.lists(
        generate_program_dependency(),
        min_size=1,
        max_size=20
    ))
    
    # Ensure we have at least one valid dependency chain
    if len(dependencies) >= 2:
        # Make sure first dependency's target is second dependency's source
        dependencies[1] = Dependency(
            source_artifact=dependencies[0].target_artifact,
            source_type='PROGRAM',
            target_artifact=dependencies[1].target_artifact,
            target_type='PROGRAM',
            dependency_type=dependencies[1].dependency_type,
            line_number=dependencies[1].line_number
        )
    
    return dependencies


@pytest.fixture
def temp_db():
    """Create a temporary database with program_file_mapping table."""
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE program_file_mapping (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT NOT NULL,
            program_name VARCHAR(44) NOT NULL,
            program_index INTEGER NOT NULL,
            start_line INTEGER NOT NULL,
            end_line INTEGER NOT NULL,
            program_type VARCHAR(20) NOT NULL,
            language VARCHAR(20) NOT NULL,
            entry_points TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(file_path, program_name)
        )
    """)
    
    conn.commit()
    
    yield conn
    
    conn.close()
    try:
        os.unlink(db_path)
    except OSError:
        pass


class TestFlowAnalysisProgramGranularityProperties:
    """Property-based tests for flow analysis program granularity."""
    
    @given(dependencies=generate_program_dependencies_list())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_flow_analyzer_operates_on_program_names(self, dependencies, temp_db):
        """
        **Feature: program-level-dependency-tracking, Property 7: Flow analysis program granularity**
        **Validates: Requirements 4.1, 4.3, 4.5**
        
        For any set of program dependencies, the Flow_Analyzer should operate on 
        individual program names and maintain accurate program-to-program call relationships.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db.commit()
        
        # Create FlowAnalyzer with program-level dependencies
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db)
        
        # Get all unique program names from dependencies
        all_programs = set()
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Test that analyzer extracts program calls correctly
        program_calls = analyzer._program_calls
        
        # Verify that program calls use individual program names
        for caller, callees in program_calls.items():
            assert isinstance(caller, str), "Caller should be a program name string"
            assert caller in all_programs, f"Caller {caller} should be in the program set"
            
            for callee in callees:
                assert isinstance(callee, str), "Callee should be a program name string"
                assert callee in all_programs, f"Callee {callee} should be in the program set"
        
        # Test flow analysis on each program
        for program in all_programs:
            if program in program_calls:  # Only test programs that make calls
                flow = analyzer.analyze_flow(program, max_depth=5)
                
                # Verify flow operates on program names
                assert isinstance(flow, ProgramFlow)
                assert flow.start_program == program
                assert isinstance(flow.programs, list)
                
                # All programs in flow should be individual program names
                for flow_program in flow.programs:
                    assert isinstance(flow_program, str)
                    assert flow_program in all_programs
                
                # Verify dependencies in flow are program-to-program
                for flow_dep in flow.dependencies:
                    if flow_dep.dependency_type in {
                        DependencyType.CALL, DependencyType.CICS_LINK,
                        DependencyType.CICS_START, DependencyType.EXEC_PGM
                    }:
                        assert flow_dep.source_type == 'PROGRAM'
                        assert flow_dep.target_type == 'PROGRAM'
                        assert flow_dep.source_artifact in all_programs
                        assert flow_dep.target_artifact in all_programs
    
    @given(dependencies=generate_program_dependencies_list())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_entry_point_detection_program_level(self, dependencies, temp_db):
        """
        **Feature: program-level-dependency-tracking, Property 7: Flow analysis program granularity**
        **Validates: Requirements 4.1, 4.4**
        
        For any set of program dependencies, entry point detection should identify 
        programs that are never called by other programs, regardless of file structure.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db.commit()
        
        # Create FlowAnalyzer
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db)
        
        # Get all programs and called programs
        all_programs = set()
        called_programs = set()
        
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
                # If this is a program call, target is called
                if dep.dependency_type in {
                    DependencyType.CALL, DependencyType.CICS_LINK,
                    DependencyType.CICS_START, DependencyType.EXEC_PGM
                }:
                    called_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Get entry points from analyzer
        entry_points = analyzer.get_entry_points(all_programs_in_inventory=all_programs)
        
        # Verify entry points are programs never called by others
        expected_entry_points = all_programs - called_programs
        
        # Convert to sets for comparison
        entry_points_set = set(entry_points)
        
        # All entry points should be programs that are never called
        for entry_point in entry_points_set:
            assert entry_point not in called_programs, \
                f"Entry point {entry_point} should not be called by other programs"
            assert entry_point in all_programs, \
                f"Entry point {entry_point} should be a valid program"
        
        # All programs that are never called should be entry points
        for program in expected_entry_points:
            assert program in entry_points_set, \
                f"Program {program} is never called so should be an entry point"
    
    @given(dependencies=generate_program_dependencies_list())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_program_file_mapping_support(self, dependencies, temp_db):
        """
        **Feature: program-level-dependency-tracking, Property 7: Flow analysis program granularity**
        **Validates: Requirements 4.5**
        
        For any set of program dependencies, when program-file mappings are available,
        the flow analyzer should provide file location metadata for programs.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db.commit()
        
        # Get all programs from dependencies
        all_programs = set()
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Insert program-file mappings for some programs
        program_list = list(all_programs)
        for i, program in enumerate(program_list[:min(5, len(program_list))]):
            cursor.execute("""
                INSERT OR IGNORE INTO program_file_mapping 
                (file_path, program_name, program_index, start_line, end_line, 
                 program_type, language, entry_points)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                f"/path/to/file{i % 3}.cbl",  # Group programs into files
                program,
                i,
                (i * 100) + 1,
                (i * 100) + 50,
                'MAIN',
                'COBOL',
                None
            ))
        
        temp_db.commit()
        
        # Create FlowAnalyzer with database connection
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db)
        
        # Test that program-file mappings are loaded
        for program in program_list[:min(5, len(program_list))]:
            location = analyzer.get_program_file_location(program)
            
            if location:  # Only test if mapping exists
                assert isinstance(location, dict)
                assert 'file_path' in location
                assert 'start_line' in location
                assert 'end_line' in location
                assert 'program_type' in location
                assert 'language' in location
                
                # Verify location data is reasonable
                assert location['start_line'] > 0
                assert location['end_line'] > location['start_line']
                assert location['file_path'].endswith('.cbl')
                assert location['language'] == 'COBOL'
        
        # Test flow analysis with file mapping
        if program_list and program_list[0] in analyzer._program_calls:
            flow_with_mapping = analyzer.analyze_flow_with_file_mapping(program_list[0])
            
            assert isinstance(flow_with_mapping, dict)
            assert 'flow' in flow_with_mapping
            assert 'program_locations' in flow_with_mapping
            assert 'file_summary' in flow_with_mapping
            
            # Verify program locations are included
            program_locations = flow_with_mapping['program_locations']
            for program, location in program_locations.items():
                assert isinstance(location, dict)
                assert 'file_path' in location
                assert program in all_programs
    
    @given(dependencies=generate_program_dependencies_list())
    @settings(
        max_examples=100,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_flow_depth_calculation_program_level(self, dependencies, temp_db):
        """
        **Feature: program-level-dependency-tracking, Property 7: Flow analysis program granularity**
        **Validates: Requirements 4.3**
        
        For any program flow, the depth calculation should measure the longest path 
        from entry points to individual programs at program-level granularity.
        """
        # Clean database before each example
        cursor = temp_db.cursor()
        cursor.execute("DELETE FROM program_file_mapping")
        temp_db.commit()
        
        # Create FlowAnalyzer
        analyzer = FlowAnalyzer(dependencies, db_connection=temp_db)
        
        # Get all programs
        all_programs = set()
        for dep in dependencies:
            if dep.source_type == 'PROGRAM':
                all_programs.add(dep.source_artifact)
            if dep.target_type == 'PROGRAM':
                all_programs.add(dep.target_artifact)
        
        if not all_programs:
            return  # Skip if no programs
        
        # Test flow analysis for each program that makes calls
        for program in all_programs:
            if program in analyzer._program_calls:
                flow = analyzer.analyze_flow(program, max_depth=10)
                
                # Verify depth is reasonable
                assert isinstance(flow.depth, int)
                assert flow.depth >= 0
                assert flow.depth <= 10  # Should not exceed max_depth
                
                # If there are programs in the flow, depth should be at least 0
                if flow.programs:
                    assert flow.depth >= 0
                    
                    # Start program should always be in the flow
                    assert flow.start_program in flow.programs
                    
                    # Depth should reflect the actual call chain length
                    if len(flow.programs) > 1:
                        # If there are multiple programs, there should be some depth
                        # (unless all programs are at the same level)
                        assert flow.depth >= 0