"""Unit tests for visualization components."""

import unittest
import tempfile
import json
from pathlib import Path

from tools.legacy_analyzer.visualization.graph_renderer import GraphRenderer
from tools.legacy_analyzer.visualization.report_generator import (
    ReportGenerator,
    AnalysisResults
)
from tools.legacy_analyzer.models.flow import CallGraph, ProgramFlow
from tools.legacy_analyzer.models.complexity import ComplexityMetrics
from tools.legacy_analyzer.models.dependency import Dependency, DependencyType
from tools.legacy_analyzer.models.package import MigrationPackage
from tools.legacy_analyzer.models.missing_artifact import MissingArtifact


class TestGraphRenderer(unittest.TestCase):
    """Test cases for GraphRenderer."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.renderer = GraphRenderer(
            color_by_complexity=True,
            highlight_missing=True,
            include_legend=True
        )
        
        # Create sample call graph
        self.call_graph = CallGraph(
            nodes=['PROG1', 'PROG2', 'PROG3'],
            edges=[('PROG1', 'PROG2'), ('PROG2', 'PROG3')]
        )
        
        # Create sample complexity data
        self.complexity_data = {
            'PROG1': ComplexityMetrics(
                program_name='PROG1',
                language='COBOL',
                lines_of_code=100,
                cyclomatic_complexity=5,
                dependency_count_in=0,
                dependency_count_out=1,
                composite_score=8.5,
                complexity_tier='LOW'
            ),
            'PROG2': ComplexityMetrics(
                program_name='PROG2',
                language='COBOL',
                lines_of_code=500,
                cyclomatic_complexity=25,
                dependency_count_in=1,
                dependency_count_out=1,
                composite_score=35.0,
                complexity_tier='HIGH'
            ),
            'PROG3': ComplexityMetrics(
                program_name='PROG3',
                language='COBOL',
                lines_of_code=200,
                cyclomatic_complexity=10,
                dependency_count_in=1,
                dependency_count_out=0,
                composite_score=15.0,
                complexity_tier='MEDIUM'
            )
        }
        
        self.missing_artifacts = {'PROG4'}
    
    def test_render_dot_basic(self):
        """Test basic DOT rendering."""
        dot = self.renderer.render_dot(self.call_graph)
        
        # Check structure
        self.assertIn('digraph CallGraph', dot)
        self.assertIn('rankdir=TB', dot)
        
        # Check nodes
        self.assertIn('"PROG1"', dot)
        self.assertIn('"PROG2"', dot)
        self.assertIn('"PROG3"', dot)
        
        # Check edges
        self.assertIn('"PROG1" -> "PROG2"', dot)
        self.assertIn('"PROG2" -> "PROG3"', dot)
    
    def test_render_dot_with_complexity(self):
        """Test DOT rendering with complexity coloring."""
        dot = self.renderer.render_dot(
            self.call_graph,
            complexity_data=self.complexity_data
        )
        
        # Check that complexity tiers are in labels
        self.assertIn('LOW', dot)
        self.assertIn('MEDIUM', dot)
        self.assertIn('HIGH', dot)
        
        # Check that colors are applied
        self.assertIn('fillcolor', dot)
    
    def test_render_dot_with_missing(self):
        """Test DOT rendering with missing artifacts highlighted."""
        # Add missing artifact to graph
        graph_with_missing = CallGraph(
            nodes=['PROG1', 'PROG2', 'PROG4'],
            edges=[('PROG1', 'PROG2'), ('PROG2', 'PROG4')]
        )
        
        dot = self.renderer.render_dot(
            graph_with_missing,
            missing_artifacts=self.missing_artifacts
        )
        
        # Check that missing artifact is highlighted
        self.assertIn('PROG4', dot)
        self.assertIn('color="red"', dot)
    
    def test_render_dot_with_legend(self):
        """Test DOT rendering includes legend."""
        dot = self.renderer.render_dot(
            self.call_graph,
            complexity_data=self.complexity_data
        )
        
        # Check for legend
        self.assertIn('Legend', dot)
        self.assertIn('cluster_legend', dot)
    
    def test_render_mermaid_basic(self):
        """Test basic Mermaid rendering."""
        mermaid = self.renderer.render_mermaid(self.call_graph)
        
        # Check structure
        self.assertIn('```mermaid', mermaid)
        self.assertIn('graph TD', mermaid)
        self.assertIn('```', mermaid)
        
        # Check that nodes and edges are present
        self.assertIn('PROG1', mermaid)
        self.assertIn('PROG2', mermaid)
        self.assertIn('-->', mermaid)
    
    def test_render_mermaid_with_complexity(self):
        """Test Mermaid rendering with complexity coloring."""
        mermaid = self.renderer.render_mermaid(
            self.call_graph,
            complexity_data=self.complexity_data
        )
        
        # Check for styling
        self.assertIn('style', mermaid)
        self.assertIn('fill:', mermaid)
    
    def test_render_html_basic(self):
        """Test basic HTML rendering."""
        html = self.renderer.render_html(self.call_graph)
        
        # Check structure
        self.assertIn('<!DOCTYPE html>', html)
        self.assertIn('<html>', html)
        self.assertIn('vis-network', html)
        
        # Check that data is embedded
        self.assertIn('PROG1', html)
        self.assertIn('PROG2', html)
    
    def test_render_html_with_complexity(self):
        """Test HTML rendering with complexity data."""
        html = self.renderer.render_html(
            self.call_graph,
            complexity_data=self.complexity_data
        )
        
        # Check that complexity colors are used
        self.assertIn('#90EE90', html)  # Low complexity color
        self.assertIn('#FFA500', html)  # High complexity color
    
    def test_render_flow_dot(self):
        """Test rendering program flow as DOT."""
        # Create sample flow
        flow = ProgramFlow(
            start_program='PROG1',
            depth=2,
            programs=['PROG1', 'PROG2', 'PROG3'],
            dependencies=[
                Dependency(
                    source_artifact='PROG1',
                    source_type='PROGRAM',
                    target_artifact='PROG2',
                    target_type='PROGRAM',
                    dependency_type=DependencyType.CALL
                ),
                Dependency(
                    source_artifact='PROG2',
                    source_type='PROGRAM',
                    target_artifact='PROG3',
                    target_type='PROGRAM',
                    dependency_type=DependencyType.CALL
                )
            ]
        )
        
        dot = self.renderer.render_flow_dot(flow)
        
        # Check structure
        self.assertIn('digraph CallGraph', dot)
        self.assertIn('Program Flow: PROG1', dot)
        self.assertIn('Depth: 2', dot)
    
    def test_render_flow_mermaid(self):
        """Test rendering program flow as Mermaid."""
        # Create sample flow
        flow = ProgramFlow(
            start_program='PROG1',
            depth=2,
            programs=['PROG1', 'PROG2'],
            dependencies=[
                Dependency(
                    source_artifact='PROG1',
                    source_type='PROGRAM',
                    target_artifact='PROG2',
                    target_type='PROGRAM',
                    dependency_type=DependencyType.CALL
                )
            ]
        )
        
        mermaid = self.renderer.render_flow_mermaid(flow)
        
        # Check structure
        self.assertIn('```mermaid', mermaid)
        self.assertIn('Program Flow: PROG1', mermaid)


class TestReportGenerator(unittest.TestCase):
    """Test cases for ReportGenerator."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.generator = ReportGenerator()
        
        # Create sample analysis results
        self.analysis_results = AnalysisResults(
            total_artifacts=100,
            total_programs=50,
            total_copybooks=30,
            total_datasets=20,
            complexity_distribution={
                'LOW': 20,
                'MEDIUM': 15,
                'HIGH': 10,
                'VERY_HIGH': 5
            },
            missing_artifacts_count=5,
            circular_dependencies_count=2
        )
    
    def test_generate_executive_summary(self):
        """Test executive summary generation."""
        report = self.generator.generate_executive_summary(self.analysis_results)
        
        # Check structure
        self.assertIn('EXECUTIVE SUMMARY', report)
        self.assertIn('INVENTORY OVERVIEW', report)
        self.assertIn('COMPLEXITY DISTRIBUTION', report)
        self.assertIn('MISSING ARTIFACTS', report)
        
        # Check data
        self.assertIn('100', report)  # Total artifacts
        self.assertIn('50', report)   # Total programs
        self.assertIn('5', report)    # Missing artifacts
    
    def test_generate_executive_summary_with_cics_metadata(self):
        """Test executive summary generation with CICS metadata."""
        # Create analysis results with CICS metadata
        results_with_cics = AnalysisResults(
            total_artifacts=100,
            total_programs=50,
            total_copybooks=30,
            total_datasets=20,
            complexity_distribution={
                'LOW': 20,
                'MEDIUM': 15,
                'HIGH': 10,
                'VERY_HIGH': 5
            },
            missing_artifacts_count=5,
            circular_dependencies_count=2,
            total_cics_transactions=18,
            total_cics_programs=15,
            cics_groups=['CARDDEMO', 'TESTGRP'],
            entry_points_by_type={
                'ONLINE': 18,
                'BATCH': 8,
                'INFERRED': 0
            },
            entry_points_by_confidence={
                'EXPLICIT': 26,
                'INFERRED': 0
            },
            enabled_transactions=16,
            disabled_transactions=2
        )
        
        report = self.generator.generate_executive_summary(results_with_cics)
        
        # Check CICS section exists
        self.assertIn('CICS TRANSACTIONS', report)
        self.assertIn('Total Transactions:', report)
        self.assertIn('18', report)  # Total transactions
        self.assertIn('16', report)  # Enabled
        self.assertIn('2', report)   # Disabled
        self.assertIn('15', report)  # CICS programs
        
        # Check CICS groups
        self.assertIn('CICS Groups:', report)
        self.assertIn('CARDDEMO', report)
        self.assertIn('TESTGRP', report)
        
        # Check entry points by type
        self.assertIn('ENTRY POINTS BY TYPE', report)
        self.assertIn('ONLINE', report)
        self.assertIn('BATCH', report)
        
        # Check confidence levels
        self.assertIn('ENTRY POINT CONFIDENCE', report)
        self.assertIn('EXPLICIT', report)
        self.assertIn('26', report)  # Explicit count
    
    def test_generate_executive_summary_without_cics_metadata(self):
        """Test executive summary generation without CICS metadata."""
        # Use default analysis results (no CICS data)
        report = self.generator.generate_executive_summary(self.analysis_results)
        
        # CICS sections should not appear
        self.assertNotIn('CICS TRANSACTIONS', report)
        self.assertNotIn('ENTRY POINTS BY TYPE', report)
        self.assertNotIn('ENTRY POINT CONFIDENCE', report)
    
    def test_generate_artifact_report(self):
        """Test artifact report generation."""
        complexity_metrics = ComplexityMetrics(
            program_name='TESTPROG',
            language='COBOL',
            lines_of_code=500,
            cyclomatic_complexity=25,
            dependency_count_in=5,
            dependency_count_out=3,
            composite_score=35.0,
            complexity_tier='HIGH'
        )
        
        report = self.generator.generate_artifact_report(
            'TESTPROG',
            complexity_metrics=complexity_metrics,
            callers=['PROG1', 'PROG2'],
            callees=['PROG3', 'PROG4']
        )
        
        # Check structure
        self.assertIn('ARTIFACT REPORT: TESTPROG', report)
        self.assertIn('COMPLEXITY METRICS', report)
        self.assertIn('DEPENDENCIES', report)
        
        # Check data
        self.assertIn('500', report)  # LOC
        self.assertIn('25', report)   # Cyclomatic
        self.assertIn('HIGH', report) # Tier
        self.assertIn('PROG1', report)
        self.assertIn('PROG3', report)
    
    def test_generate_package_report(self):
        """Test package report generation."""
        package = MigrationPackage(
            name='Test Package',
            artifacts=['PROG1', 'PROG2', 'PROG3'],
            total_loc=1500,
            total_complexity=75.0,
            external_dependencies=['EXTPROG1'],
            conflicts=[]
        )
        
        report = self.generator.generate_package_report(package)
        
        # Check structure
        self.assertIn('MIGRATION PACKAGE REPORT: Test Package', report)
        self.assertIn('PACKAGE SUMMARY', report)
        self.assertIn('EXTERNAL DEPENDENCIES', report)
        
        # Check data
        self.assertIn('3', report)     # Total artifacts
        self.assertIn('1,500', report) # Total LOC
        self.assertIn('EXTPROG1', report)
    
    def test_generate_complexity_summary(self):
        """Test complexity summary generation."""
        complexity_metrics = {
            'PROG1': ComplexityMetrics(
                program_name='PROG1',
                language='COBOL',
                lines_of_code=100,
                cyclomatic_complexity=5,
                dependency_count_in=0,
                dependency_count_out=1,
                composite_score=8.5,
                complexity_tier='LOW'
            ),
            'PROG2': ComplexityMetrics(
                program_name='PROG2',
                language='COBOL',
                lines_of_code=1000,
                cyclomatic_complexity=50,
                dependency_count_in=10,
                dependency_count_out=5,
                composite_score=85.0,
                complexity_tier='VERY_HIGH',
                is_god_program=True
            )
        }
        
        report = self.generator.generate_complexity_summary(complexity_metrics)
        
        # Check structure
        self.assertIn('COMPLEXITY SUMMARY', report)
        self.assertIn('DISTRIBUTION', report)
        self.assertIn('TOP', report)
        
        # Check data
        self.assertIn('PROG2', report)  # Should be in top complex
        self.assertIn('GOD PROGRAMS', report)


class TestReportExporters(unittest.TestCase):
    """Test cases for report exporters."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        
        # Create sample analysis results
        self.analysis_results = AnalysisResults(
            total_artifacts=100,
            total_programs=50,
            total_copybooks=30,
            total_datasets=20,
            complexity_distribution={
                'LOW': 20,
                'MEDIUM': 15,
                'HIGH': 10,
                'VERY_HIGH': 5
            },
            missing_artifacts_count=5,
            circular_dependencies_count=2
        )
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_json_export(self):
        """Test JSON export."""
        from tools.legacy_analyzer.visualization.html_exporter import JSONExporter
        
        exporter = JSONExporter()
        output_file = Path(self.temp_dir) / 'report.json'
        
        exporter.export_analysis_results(self.analysis_results, str(output_file))
        
        # Check file was created
        self.assertTrue(output_file.exists())
        
        # Check content
        with open(output_file, 'r') as f:
            data = json.load(f)
        
        self.assertEqual(data['inventory']['total_artifacts'], 100)
        self.assertEqual(data['inventory']['total_programs'], 50)
        self.assertEqual(data['missing_artifacts_count'], 5)
    
    def test_markdown_export(self):
        """Test Markdown export."""
        from tools.legacy_analyzer.visualization.html_exporter import MarkdownExporter
        
        exporter = MarkdownExporter()
        output_file = Path(self.temp_dir) / 'report.md'
        
        exporter.export_executive_summary(self.analysis_results, str(output_file))
        
        # Check file was created
        self.assertTrue(output_file.exists())
        
        # Check content
        with open(output_file, 'r') as f:
            content = f.read()
        
        self.assertIn('EXECUTIVE SUMMARY', content)
        self.assertIn('100', content)


if __name__ == '__main__':
    unittest.main()
