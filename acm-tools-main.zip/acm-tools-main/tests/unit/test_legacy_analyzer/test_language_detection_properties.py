#!/usr/bin/env python3
"""
Property-based tests for language detection functionality.

These tests use Hypothesis to verify correctness properties across
many randomly generated inputs.
"""

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hypothesis import given, strategies as st, settings
from tools.legacy_analyzer.language_detector import LanguageDetector


# Strategy for generating Natural file extensions
natural_extensions = st.sampled_from(['.nsp', '.nsn', '.nsc', '.nsg', '.nsl', '.nsd', '.nsa', '.ns8'])

# Strategy for generating any file content (including COBOL-like keywords)
file_content = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'P', 'Z')),
    min_size=0,
    max_size=1000
)

# Strategy for generating COBOL-like content that might confuse the detector
cobol_like_content = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n.-',
    min_size=0,
    max_size=500
).map(lambda s: s + '\nMOVE X TO Y.\nIF A = B\n  DISPLAY "TEST"\nEND-IF.\n')


# Feature: natural-analysis-workflow, Property 1: Natural extensions always return Natural
# Validates: Requirements 1.1, 1.4
@settings(max_examples=100)
@given(
    extension=natural_extensions,
    content=st.one_of(file_content, cobol_like_content, st.just(''))
)
def test_property_natural_extensions_always_return_natural(extension, content):
    """
    Property 1: Natural extensions always return Natural
    
    For any file with a Natural extension (.nsp, .nsn, .nsc, .nsg, .nsl, .nsd, .nsa, .ns8)
    and any file content, the detected language should be "Natural"
    """
    detector = LanguageDetector()
    
    # Create a temporary file path with Natural extension
    with tempfile.NamedTemporaryFile(mode='w', suffix=extension, delete=False) as f:
        f.write(content)
        temp_path = f.name
    
    try:
        # Detect language
        detected_language = detector.detect_language(temp_path, content=content)
        
        # Assert that Natural extension always returns Natural
        assert detected_language == 'NATURAL', \
            f"File with extension {extension} was detected as {detected_language}, expected NATURAL"
    finally:
        # Clean up
        if os.path.exists(temp_path):
            os.unlink(temp_path)


# Feature: natural-analysis-workflow, Property 2: Extension detection skips content analysis
# Validates: Requirements 1.2, 1.3, 2.2, 2.4
@settings(max_examples=100)
@given(
    extension=st.sampled_from(['.cbl', '.cob', '.cobol', '.nsp', '.nsn', '.jcl', '.pli', '.rexx']),
    content=st.one_of(file_content, cobol_like_content, st.just(''))
)
def test_property_extension_detection_skips_content_analysis(extension, content):
    """
    Property 2: Extension detection skips content analysis
    
    For any file with a definitive extension (not in AMBIGUOUS_EXTENSIONS),
    content-based detection should not be invoked
    """
    detector = LanguageDetector()
    
    # Create a temporary file path with definitive extension
    with tempfile.NamedTemporaryFile(mode='w', suffix=extension, delete=False) as f:
        f.write(content)
        temp_path = f.name
    
    try:
        # Mock the _detect_by_content method to track if it's called
        with patch.object(detector, '_detect_by_content', wraps=detector._detect_by_content) as mock_content:
            # Detect language
            detected_language = detector.detect_language(temp_path, content=content)
            
            # Assert that content detection was NOT called for definitive extensions
            assert mock_content.call_count == 0, \
                f"Content detection was called {mock_content.call_count} times for file with definitive extension {extension}"
            
            # Also verify we got a valid language result
            assert detected_language is not None, \
                f"Expected a language to be detected for extension {extension}, got None"
    finally:
        # Clean up
        if os.path.exists(temp_path):
            os.unlink(temp_path)


# Feature: natural-analysis-workflow, Property 3: Extension detection executes first
# Validates: Requirements 2.1, 5.1
@settings(max_examples=100)
@given(
    extension=st.sampled_from(['.cbl', '.nsp', '.jcl', '.txt', '.dat', '.unknown']),
    content=st.one_of(file_content, st.just(''))
)
def test_property_extension_detection_executes_first(extension, content):
    """
    Property 3: Extension detection executes first
    
    For any file, extension-based detection should be attempted before
    content-based detection
    """
    detector = LanguageDetector()
    
    # Create a temporary file path
    with tempfile.NamedTemporaryFile(mode='w', suffix=extension, delete=False) as f:
        f.write(content)
        temp_path = f.name
    
    try:
        # Track the order of method calls
        call_order = []
        
        original_detect_by_extension = detector._detect_by_extension
        original_detect_by_content = detector._detect_by_content
        
        def tracked_extension(*args, **kwargs):
            call_order.append('extension')
            return original_detect_by_extension(*args, **kwargs)
        
        def tracked_content(*args, **kwargs):
            call_order.append('content')
            return original_detect_by_content(*args, **kwargs)
        
        # Patch both methods to track call order
        with patch.object(detector, '_detect_by_extension', side_effect=tracked_extension):
            with patch.object(detector, '_detect_by_content', side_effect=tracked_content):
                # Detect language
                detector.detect_language(temp_path, content=content)
                
                # Assert that if both were called, extension was called first
                if len(call_order) > 0:
                    assert call_order[0] == 'extension', \
                        f"Extension detection should be called first, but call order was: {call_order}"
                
                # If content was called, extension must have been called first
                if 'content' in call_order:
                    assert call_order.index('extension') < call_order.index('content'), \
                        f"Extension detection must be called before content detection, but order was: {call_order}"
    finally:
        # Clean up
        if os.path.exists(temp_path):
            os.unlink(temp_path)


# Feature: natural-analysis-workflow, Property 4: Content detection fallback for unknown extensions
# Validates: Requirements 2.3
@settings(max_examples=100)
@given(
    extension=st.sampled_from(['.txt', '.dat', '.src', '.mbr', '.unknown', '.xyz', '']),
    language_choice=st.sampled_from(['COBOL', 'JCL', 'NONE'])
)
def test_property_content_detection_fallback_for_unknown_extensions(extension, language_choice):
    """
    Property 4: Content detection fallback for unknown extensions
    
    For any file with an ambiguous or unknown extension, content-based detection
    should be invoked and its result should be used
    """
    detector = LanguageDetector()
    
    # Build content based on language choice
    # Note: We use COBOL and JCL which have working patterns in the current implementation
    if language_choice == 'COBOL':
        content = """IDENTIFICATION DIVISION.
PROGRAM-ID. TESTPROG.
PROCEDURE DIVISION.
    MOVE X TO Y.
    DISPLAY "TEST".
"""
    elif language_choice == 'JCL':
        content = """//TESTJOB JOB (ACCT),'TEST JOB'
//STEP1   EXEC PGM=TESTPROG
//SYSOUT  DD SYSOUT=*
"""
    else:  # NONE
        content = "Some random text without patterns\n"
    
    # Create a temporary file path with ambiguous/unknown extension
    suffix = extension if extension else '.txt'
    with tempfile.NamedTemporaryFile(mode='w', suffix=suffix, delete=False) as f:
        f.write(content)
        temp_path = f.name
    
    try:
        # Mock the _detect_by_content method to track if it's called
        with patch.object(detector, '_detect_by_content', wraps=detector._detect_by_content) as mock_content:
            # Detect language
            detected_language = detector.detect_language(temp_path, content=content)
            
            # For ambiguous/unknown extensions with non-empty content, content detection should be called
            if (extension in ['.txt', '.dat', '.src', '.mbr'] or extension not in detector.EXTENSION_MAP) and content:
                assert mock_content.call_count == 1, \
                    f"Content detection should be called once for ambiguous/unknown extension {extension}, but was called {mock_content.call_count} times"
                
                # Verify the result matches what content analysis would produce
                if language_choice == 'COBOL':
                    assert detected_language == 'COBOL', \
                        f"Expected COBOL from content with COBOL patterns, got {detected_language}"
                elif language_choice == 'JCL':
                    assert detected_language == 'JCL', \
                        f"Expected JCL from content with JCL patterns, got {detected_language}"
                else:  # NONE
                    # No strong patterns means no detection
                    assert detected_language is None, \
                        f"Expected None for content with no patterns, got {detected_language}"
    finally:
        # Clean up
        if os.path.exists(temp_path):
            os.unlink(temp_path)


# Feature: natural-analysis-workflow, Property 5: Detection consistency
# Validates: Requirements 4.4
@settings(max_examples=100)
@given(
    extension=st.sampled_from(['.cbl', '.nsp', '.jcl', '.txt', '.dat', '.pli', '.rexx', '.asm']),
    content=st.one_of(file_content, cobol_like_content, st.just(''))
)
def test_property_detection_consistency(extension, content):
    """
    Property 5: Detection consistency
    
    For any file, running detection multiple times with the same inputs
    should produce the same language result
    """
    detector = LanguageDetector()
    
    # Create a temporary file path
    with tempfile.NamedTemporaryFile(mode='w', suffix=extension, delete=False) as f:
        f.write(content)
        temp_path = f.name
    
    try:
        # Run detection multiple times (5 iterations)
        results = []
        for _ in range(5):
            detected_language = detector.detect_language(temp_path, content=content)
            results.append(detected_language)
        
        # Assert all results are identical
        first_result = results[0]
        for i, result in enumerate(results[1:], start=1):
            assert result == first_result, \
                f"Detection inconsistency: iteration 0 returned {first_result}, iteration {i} returned {result}"
    finally:
        # Clean up
        if os.path.exists(temp_path):
            os.unlink(temp_path)


# Feature: natural-analysis-workflow, Property 6: Mixed language directory independence
# Validates: Requirements 3.3
@settings(max_examples=100)
@given(
    files=st.lists(
        st.tuples(
            st.sampled_from(['.cbl', '.nsp', '.jcl', '.pli', '.rexx', '.asm', '.txt']),
            st.one_of(file_content, cobol_like_content, st.just(''))
        ),
        min_size=2,
        max_size=10
    )
)
def test_property_mixed_language_directory_independence(files):
    """
    Property 6: Mixed language directory independence
    
    For any directory containing files of different languages, each file's
    detected language should be independent of other files in the directory
    """
    detector = LanguageDetector()
    
    # Create a temporary directory with multiple files
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_paths = []
        expected_results = {}
        
        # Create all files and detect their languages individually first
        for i, (extension, content) in enumerate(files):
            file_path = os.path.join(temp_dir, f'file_{i}{extension}')
            with open(file_path, 'w') as f:
                f.write(content)
            temp_paths.append(file_path)
            
            # Detect language for this file in isolation
            expected_results[file_path] = detector.detect_language(file_path, content=content)
        
        # Now detect languages again with all files present in the directory
        # Each file's detection should be independent of others
        for file_path in temp_paths:
            # Re-read content
            with open(file_path, 'r') as f:
                content = f.read()
            
            detected_language = detector.detect_language(file_path, content=content)
            expected_language = expected_results[file_path]
            
            assert detected_language == expected_language, \
                f"File {file_path} detection changed from {expected_language} to {detected_language} " \
                f"when other files were present in directory"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])
