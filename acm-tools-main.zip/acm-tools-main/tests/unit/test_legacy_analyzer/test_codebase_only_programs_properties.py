"""
Property-based tests for codebase-only programs in migration flow builder.

Property 7: Codebase-Only Programs Have Zero Inbound Interfaces
For any program that is only called by other programs in the analyzed codebase,
the system SHALL NOT create any inbound interface records for that program.

**Validates: Requirements 5.1, 5.3**
"""

import pytest
import sqlite3
from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder
from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager


class MockFlow:
    """Mock ProgramFlow object for testing."""
    
    def __init__(self, programs):
        self.programs = programs
        self.dependencies = []


def create_test_db():
    """Create an in-memory test database with required schema."""
    conn = sqlite3.connect(':memory:')
    
    # Create migration flow schema
    from tools.legacy_analyzer.migration.schema import MigrationFlowSchema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create artifact_dependencies table
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            id INTEGER PRIMARY KEY,
            source_artifact_name TEXT,
            target_artifact_name TEXT,
            dependency_type TEXT,
            source_artifact_type TEXT,
            target_artifact_type TEXT,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    # Create interface tables
    schema_manager = InterfaceSchemaManager(conn)
    schema_manager.create_tables()
    
    conn.commit()
    return conn


@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    ),
    codebase_callers=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    )
)
def test_property_codebase_only_programs_zero_inbound(flow_programs, codebase_callers):
    """
    Property: Programs only called by codebase programs have zero inbound interfaces.
    
    When a program in a flow is only called by other programs in the analyzed codebase
    (not by external systems), it should have zero inbound interfaces.
    
    **Feature: fix-inbound-interface-logic, Property 7: Codebase-Only Programs Have Zero Inbound Interfaces**
    **Validates: Requirements 5.1, 5.3**
    """
    # Ensure no overlap between flow and codebase callers
    assume(len(set(flow_programs) & set(codebase_callers)) == 0)
    
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: Insert all codebase_callers into artifact_dependencies (in codebase)
        for caller in codebase_callers:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, target_artifact_name, dependency_type)
                VALUES (?, ?, ?)
            """, (caller, 'DUMMY_TARGET', 'PROGRAM_CALL'))
        
        # Setup: Configure all codebase_callers calling the first flow program
        # (These should NOT create inbound interfaces because callers are in codebase)
        for caller in codebase_callers:
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured)
                VALUES (?, ?, ?, ?)
            """, (caller, flow_programs[0], 'PROGRAM_CALL', True))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow
        flow = MockFlow(programs=flow_programs)
        entry_program = flow_programs[0]
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: Zero inbound interfaces (all callers are in codebase)
        assert len(interfaces['inbound']) == 0, \
            f"Programs only called by codebase programs should have zero inbound interfaces. " \
            f"Got {len(interfaces['inbound'])} interfaces. " \
            f"Callers: {codebase_callers}, Target: {flow_programs[0]}"
    
    finally:
        db.close()


@settings(max_examples=100, deadline=None)
@given(
    target_program=st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
    num_codebase_callers=st.integers(min_value=1, max_value=10)
)
def test_property_many_codebase_callers_zero_inbound(target_program, num_codebase_callers):
    """
    Property: Program with many codebase callers still has zero inbound interfaces.
    
    Even if a program is called by many other programs in the codebase,
    it should have zero inbound interfaces (like CEE3ABD example).
    
    **Feature: fix-inbound-interface-logic, Property 7: Codebase-Only Programs Have Zero Inbound Interfaces**
    **Validates: Requirements 5.1, 5.3**
    """
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: Create many codebase callers
        codebase_callers = [f"CALLER_{i}" for i in range(num_codebase_callers)]
        
        # Setup: Insert all callers into artifact_dependencies (in codebase)
        for caller in codebase_callers:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, target_artifact_name, dependency_type)
                VALUES (?, ?, ?)
            """, (caller, 'DUMMY_TARGET', 'PROGRAM_CALL'))
        
        # Setup: Configure all callers calling target_program
        for caller in codebase_callers:
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured)
                VALUES (?, ?, ?, ?)
            """, (caller, target_program, 'PROGRAM_CALL', True))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow containing target_program
        flow = MockFlow(programs=[target_program])
        entry_program = target_program
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: Zero inbound interfaces despite many callers
        assert len(interfaces['inbound']) == 0, \
            f"Program with {num_codebase_callers} codebase callers should have zero inbound interfaces. " \
            f"Got {len(interfaces['inbound'])} interfaces"
    
    finally:
        db.close()


@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    ),
    codebase_callers=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    ),
    external_callers=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    )
)
def test_property_mixed_callers_only_external_create_inbound(flow_programs, codebase_callers, external_callers):
    """
    Property: With mixed callers, only external callers create inbound interfaces.
    
    When a program is called by both codebase programs and external systems,
    only the external callers should create inbound interfaces.
    
    **Feature: fix-inbound-interface-logic, Property 7: Codebase-Only Programs Have Zero Inbound Interfaces**
    **Validates: Requirements 5.1, 5.3**
    """
    # Ensure no overlap between sets
    assume(len(set(flow_programs) & set(codebase_callers)) == 0)
    assume(len(set(flow_programs) & set(external_callers)) == 0)
    assume(len(set(codebase_callers) & set(external_callers)) == 0)
    
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: Insert codebase_callers into artifact_dependencies (in codebase)
        for caller in codebase_callers:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, target_artifact_name, dependency_type)
                VALUES (?, ?, ?)
            """, (caller, 'DUMMY_TARGET', 'PROGRAM_CALL'))
        
        # Setup: external_callers are NOT in artifact_dependencies (not in codebase)
        
        # Setup: Configure both codebase and external callers calling flow program
        for caller in codebase_callers:
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured)
                VALUES (?, ?, ?, ?)
            """, (caller, flow_programs[0], 'PROGRAM_CALL', True))
        
        for caller in external_callers:
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured)
                VALUES (?, ?, ?, ?)
            """, (caller, flow_programs[0], 'PROGRAM_CALL', True))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow
        flow = MockFlow(programs=flow_programs)
        entry_program = flow_programs[0]
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: Only external callers create inbound interfaces
        inbound_sources = {i['source'] for i in interfaces['inbound']}
        
        assert inbound_sources == set(external_callers), \
            f"Only external callers should create inbound interfaces. " \
            f"Expected: {set(external_callers)}, Got: {inbound_sources}"
        
        # Verify: No codebase callers in inbound interfaces
        assert len(inbound_sources & set(codebase_callers)) == 0, \
            f"Codebase callers should not create inbound interfaces. " \
            f"Found: {inbound_sources & set(codebase_callers)}"
    
    finally:
        db.close()


@settings(max_examples=100, deadline=None)
@given(
    target_program=st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
    codebase_caller=st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',)))
)
def test_property_single_codebase_caller_zero_inbound(target_program, codebase_caller):
    """
    Property: Program with single codebase caller has zero inbound interfaces.
    
    Even with just one caller, if that caller is in the codebase,
    the target should have zero inbound interfaces.
    
    **Feature: fix-inbound-interface-logic, Property 7: Codebase-Only Programs Have Zero Inbound Interfaces**
    **Validates: Requirements 5.1, 5.3**
    """
    assume(target_program != codebase_caller)
    
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: Insert codebase_caller into artifact_dependencies (in codebase)
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, target_artifact_name, dependency_type)
            VALUES (?, ?, ?)
        """, (codebase_caller, 'DUMMY_TARGET', 'PROGRAM_CALL'))
        
        # Setup: Configure codebase_caller calling target_program
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured)
            VALUES (?, ?, ?, ?)
        """, (codebase_caller, target_program, 'PROGRAM_CALL', True))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow
        flow = MockFlow(programs=[target_program])
        entry_program = target_program
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: Zero inbound interfaces
        assert len(interfaces['inbound']) == 0, \
            f"Program with single codebase caller should have zero inbound interfaces. " \
            f"Got {len(interfaces['inbound'])} interfaces from {codebase_caller}"
    
    finally:
        db.close()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
