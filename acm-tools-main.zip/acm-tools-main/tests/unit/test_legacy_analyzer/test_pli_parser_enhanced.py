"""Tests for enhanced PL/I parser."""

import pytest
from pathlib import Path
from tools.legacy_analyzer.parsers.pli_parser import PLIDependencyParser


class TestPLIParserEnhanced:
    """Test enhanced PL/I parser functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = PLIDependencyParser()
    
    def test_parse_include_statements(self):
        """Test parsing %INCLUDE statements."""
        source = """
        %INCLUDE COCOM01Y;
        %INCLUDE COADM02Y;
        %INCLUDE DFHAID;
        %INCLUDE DFHBMSCA;
        """
        result = self.parser.parse(source)
        
        assert 'includes' in result
        assert 'COCOM01Y' in result['includes']
        assert 'COADM02Y' in result['includes']
        assert 'DFHAID' in result['includes']
        assert 'DFHBMSCA' in result['includes']
    
    def test_parse_call_statements(self):
        """Test parsing CALL statements."""
        source = """
        CALL COBDATFT(CODATECN_REC);
        CALL RETURN_TO_SIGNON_SCREEN;
        """
        result = self.parser.parse(source)
        
        assert 'calls' in result
        assert 'COBDATFT' in result['calls']
        assert 'RETURN_TO_SIGNON_SCREEN' in result['calls']
    
    def test_parse_cics_xctl_statements(self):
        """Test parsing EXEC CICS XCTL statements."""
        source = """
        EXEC CICS XCTL PROGRAM('COADM01C');
        EXEC CICS XCTL PROGRAM(CDEMO_TO_PROGRAM);
        """
        result = self.parser.parse(source)
        
        assert 'cics_xctl' in result
        assert 'COADM01C' in result['cics_xctl']
        assert 'CDEMO_TO_PROGRAM' in result['cics_xctl']
    
    def test_parse_cics_link_statements(self):
        """Test parsing EXEC CICS LINK statements."""
        source = """
        EXEC CICS LINK PROGRAM('SUBPROG');
        EXEC CICS LINK PROGRAM(LINKPROG);
        """
        result = self.parser.parse(source)
        
        assert 'cics_link' in result
        assert 'SUBPROG' in result['cics_link']
        assert 'LINKPROG' in result['cics_link']
    
    def test_parse_file_declarations(self):
        """Test parsing FILE declarations."""
        source = """
        DCL ACCTFIL FILE RECORD KEYED 
             ENV(VSAM recsize(300) keyloc(1) keylength(11));
        DCL OUTFILE FILE RECORD SEQUENTIAL ENV(F) OUTPUT;
        DCL ARRYFILE FILE RECORD SEQUENTIAL ENV(F) OUTPUT;
        """
        result = self.parser.parse(source)
        
        assert 'file_declarations' in result
        assert 'ACCTFIL' in result['file_declarations']
        assert 'OUTFILE' in result['file_declarations']
        assert 'ARRYFILE' in result['file_declarations']
    
    def test_parse_read_file_statements(self):
        """Test parsing READ FILE statements."""
        source = """
        READ FILE(ACCTFIL) INTO(ACCOUNT_RECORD);
        READ FILE(INFILE) INTO(INPUT_REC);
        """
        result = self.parser.parse(source)
        
        assert 'file_reads' in result
        assert 'ACCTFIL' in result['file_reads']
        assert 'INFILE' in result['file_reads']
    
    def test_parse_write_file_statements(self):
        """Test parsing WRITE FILE statements."""
        source = """
        WRITE FILE(OUTFILE) FROM(OUT_ACCT_REC_STR);
        WRITE FILE(ARRYFILE) FROM(ARR_ARRAY_REC_STR);
        """
        result = self.parser.parse(source)
        
        assert 'file_writes' in result
        assert 'OUTFILE' in result['file_writes']
        assert 'ARRYFILE' in result['file_writes']
    
    def test_parse_cics_read_statements(self):
        """Test parsing EXEC CICS READ statements."""
        source = """
        EXEC CICS READ
          DATASET(WS_ACCTDAT_FILE)
          INTO(ACCOUNT_RECORD);
        EXEC CICS READ FILE(CUSTFILE) INTO(CUST_REC);
        """
        result = self.parser.parse(source)
        
        assert 'cics_reads' in result
        assert 'WS_ACCTDAT_FILE' in result['cics_reads']
        assert 'CUSTFILE' in result['cics_reads']
    
    def test_parse_cics_write_statements(self):
        """Test parsing EXEC CICS WRITE statements."""
        source = """
        EXEC CICS WRITE
          DATASET(WS_TRANSACT_FILE)
          FROM(TRAN_RECORD);
        """
        result = self.parser.parse(source)
        
        assert 'cics_writes' in result
        assert 'WS_TRANSACT_FILE' in result['cics_writes']
    
    def test_parse_cics_rewrite_statements(self):
        """Test parsing EXEC CICS REWRITE statements."""
        source = """
        EXEC CICS REWRITE
          DATASET(WS_ACCTDAT_FILE)
          FROM(ACCOUNT_RECORD);
        """
        result = self.parser.parse(source)
        
        assert 'cics_rewrites' in result
        assert 'WS_ACCTDAT_FILE' in result['cics_rewrites']
    
    def test_parse_cics_delete_statements(self):
        """Test parsing EXEC CICS DELETE statements."""
        source = """
        EXEC CICS DELETE
          DATASET(WS_TRANSACT_FILE)
          RIDFLD(TRAN_ID);
        """
        result = self.parser.parse(source)
        
        assert 'cics_deletes' in result
        assert 'WS_TRANSACT_FILE' in result['cics_deletes']
    
    def test_identify_main_program(self):
        """Test identifying main programs vs subroutines."""
        main_source = """
        COADM01C: PROC(COMMPTR) OPTIONS(MAIN) REORDER;
        """
        subroutine_source = """
        PROCESS_ENTER_KEY: PROC;
        """
        
        main_result = self.parser.parse(main_source)
        sub_result = self.parser.parse(subroutine_source)
        
        assert main_result['is_main_program'] is True
        assert sub_result['is_main_program'] is False
    
    def test_filter_builtin_functions(self):
        """Test that built-in functions are filtered from CALL statements."""
        source = """
        CALL PUT('Hello');
        CALL SUBSTR(STR, 1, 5);
        CALL MYPROGRAM(PARAM);
        """
        result = self.parser.parse(source)
        
        assert 'calls' in result
        assert 'PUT' not in result['calls']
        assert 'SUBSTR' not in result['calls']
        assert 'MYPROGRAM' in result['calls']
    
    def test_supported_extensions(self):
        """Test that parser supports correct file extensions."""
        extensions = self.parser.get_supported_extensions()
        
        assert '.pli' in extensions
        assert '.pl1' in extensions
        assert '.inc' in extensions
    
    def test_supported_patterns(self):
        """Test that parser reports all supported patterns."""
        patterns = self.parser.get_supported_patterns()
        
        assert '%INCLUDE' in patterns
        assert 'CALL' in patterns
        assert 'EXEC CICS XCTL' in patterns
        assert 'EXEC CICS LINK' in patterns
        assert 'FILE DECLARATION' in patterns
        assert 'READ FILE' in patterns
        assert 'WRITE FILE' in patterns
        assert 'EXEC CICS READ' in patterns
        assert 'EXEC CICS WRITE' in patterns
        assert 'EXEC CICS REWRITE' in patterns
        assert 'EXEC CICS DELETE' in patterns
        assert 'PROCEDURE OPTIONS(MAIN)' in patterns


class TestPLIParserWithRealCode:
    """Test PL/I parser with real code samples."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = PLIDependencyParser()
        self.examples_dir = Path('examples/code/pli/carddemo/app')
    
    def test_parse_coadm01c(self):
        """Test parsing COADM01C.pli."""
        if not self.examples_dir.exists():
            pytest.skip("Example code not available")
        
        file_path = self.examples_dir / 'pli' / 'COADM01C.pli'
        if not file_path.exists():
            pytest.skip(f"File {file_path} not found")
        
        result = self.parser.parse_file(str(file_path))
        
        # Check includes
        assert 'includes' in result
        assert 'COCOM01Y' in result['includes']
        assert 'COADM02Y' in result['includes']
        assert 'DFHAID' in result['includes']
        assert 'DFHBMSCA' in result['includes']
        
        # Check CICS XCTL
        assert 'cics_xctl' in result
        # COADM01C uses EXEC CICS XCTL with variable program names
        
        # Check if it's a main program
        assert result['is_main_program'] is True
    
    def test_parse_cbact01c(self):
        """Test parsing CBACT01C.pli."""
        if not self.examples_dir.exists():
            pytest.skip("Example code not available")
        
        file_path = self.examples_dir / 'pli' / 'CBACT01C.pli'
        if not file_path.exists():
            pytest.skip(f"File {file_path} not found")
        
        result = self.parser.parse_file(str(file_path))
        
        # Check includes
        assert 'includes' in result
        assert 'CVACT01Y' in result['includes']
        assert 'CODATECN' in result['includes']
        
        # Check calls
        assert 'calls' in result
        assert 'COBDATFT' in result['calls']
        
        # Check file declarations
        assert 'file_declarations' in result
        assert 'ACCTFIL' in result['file_declarations']
        assert 'OUTFILE' in result['file_declarations']
        assert 'ARRYFILE' in result['file_declarations']
        
        # Check file reads
        assert 'file_reads' in result
        assert 'ACCTFIL' in result['file_reads']
        
        # Check file writes
        assert 'file_writes' in result
        assert 'OUTFILE' in result['file_writes']
        assert 'ARRYFILE' in result['file_writes']
        
        # Check if it's a main program
        assert result['is_main_program'] is True
    
    def test_parse_cobil00c(self):
        """Test parsing COBIL00C.pli."""
        if not self.examples_dir.exists():
            pytest.skip("Example code not available")
        
        file_path = self.examples_dir / 'pli' / 'COBIL00C.pli'
        if not file_path.exists():
            pytest.skip(f"File {file_path} not found")
        
        result = self.parser.parse_file(str(file_path))
        
        # Check includes
        assert 'includes' in result
        assert 'COCOM01Y' in result['includes']
        assert 'DFHAID' in result['includes']
        
        # Check CICS operations
        assert 'cics_reads' in result
        assert 'WS_ACCTDAT_FILE' in result['cics_reads'] or \
               'WS_CXACAIX_FILE' in result['cics_reads']
        
        assert 'cics_writes' in result
        assert 'WS_TRANSACT_FILE' in result['cics_writes']
        
        assert 'cics_rewrites' in result
        assert 'WS_ACCTDAT_FILE' in result['cics_rewrites']
        
        # Check CICS XCTL
        assert 'cics_xctl' in result
        
        # Check if it's a main program
        assert result['is_main_program'] is True
    
    def test_parse_include_file(self):
        """Test parsing an include file."""
        if not self.examples_dir.exists():
            pytest.skip("Example code not available")
        
        file_path = self.examples_dir / 'inc' / 'CVACT01Y.inc'
        if not file_path.exists():
            pytest.skip(f"File {file_path} not found")
        
        result = self.parser.parse_file(str(file_path))
        
        # Include files typically don't have main program markers
        assert result['is_main_program'] is False


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
