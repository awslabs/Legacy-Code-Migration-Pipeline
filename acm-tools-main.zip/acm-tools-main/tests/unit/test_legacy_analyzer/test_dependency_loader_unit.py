"""Unit tests for DependencyLoader methods.

Tests that loader methods work correctly without language fields.
"""

import pytest
import tempfile
import os
import csv
import json
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.legacy_analyzer.dependency_loader import DependencyLoader


class TestDependencyLoaderUnit:
    """Unit tests for DependencyLoader."""
    
    @pytest.fixture
    def temp_db(self):
        """Create a temporary database for testing."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = SQLiteAdapter(db_path)
        db.connect()
        
        # Create dependencies schema
        loader = DependencyLoader(db)
        loader.create_dependencies_schema()
        
        yield db
        
        # Cleanup
        db.close()
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    def test_load_from_csv_without_language_columns(self, temp_db):
        """Test load_from_csv() with CSV lacking language columns.
        
        Requirements: 1.3, 4.1
        """
        # Create a CSV file without language columns
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            csv_path = f.name
            writer = csv.DictWriter(f, fieldnames=[
                'source_name', 'source_type', 'target_name', 
                'target_type', 'dependency_type', 'file_path', 'line_number'
            ])
            writer.writeheader()
            writer.writerow({
                'source_name': 'PROG1',
                'source_type': 'PROGRAM',
                'target_name': 'PROG2',
                'target_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'file_path': 'TEST.SOURCE(PROG1)',
                'line_number': '100'
            })
            writer.writerow({
                'source_name': 'PROG1',
                'source_type': 'PROGRAM',
                'target_name': 'COPY1',
                'target_type': 'COPYBOOK',
                'dependency_type': 'COPY',
                'file_path': 'TEST.SOURCE(PROG1)',
                'line_number': '50'
            })
        
        try:
            loader = DependencyLoader(temp_db)
            stats = loader.load_from_csv(csv_path, skip_duplicates=True)
            
            # Verify loading succeeded
            assert stats['processed'] == 2
            assert stats['inserted'] == 2
            assert stats['errors'] == 0
            
            # Verify records in database
            cursor = temp_db.cursor()
            cursor.execute("SELECT COUNT(*) FROM artifact_dependencies")
            count = cursor.fetchone()[0]
            assert count == 2
            
            # Verify no language columns exist
            cursor.execute("PRAGMA table_info(artifact_dependencies)")
            columns = [row[1] for row in cursor.fetchall()]
            assert 'source_language' not in columns
            assert 'target_language' not in columns
            
        finally:
            os.unlink(csv_path)
    
    def test_load_from_json_without_language_fields(self, temp_db):
        """Test load_from_json() with JSON lacking language fields.
        
        Requirements: 1.3, 4.1
        """
        # Create a JSON file without language fields
        data = [
            {
                'source_name': 'PROG1',
                'source_type': 'PROGRAM',
                'target_name': 'PROG2',
                'target_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'file_path': 'TEST.SOURCE(PROG1)',
                'line_number': 100
            },
            {
                'source_name': 'PROG1',
                'source_type': 'PROGRAM',
                'target_name': 'COPY1',
                'target_type': 'COPYBOOK',
                'dependency_type': 'COPY',
                'file_path': 'TEST.SOURCE(PROG1)',
                'line_number': 50
            }
        ]
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json_path = f.name
            json.dump(data, f)
        
        try:
            loader = DependencyLoader(temp_db)
            stats = loader.load_from_json(json_path, skip_duplicates=True)
            
            # Verify loading succeeded
            assert stats['processed'] == 2
            assert stats['inserted'] == 2
            assert stats['errors'] == 0
            
            # Verify records in database
            cursor = temp_db.cursor()
            cursor.execute("SELECT COUNT(*) FROM artifact_dependencies")
            count = cursor.fetchone()[0]
            assert count == 2
            
            # Verify no language columns exist
            cursor.execute("PRAGMA table_info(artifact_dependencies)")
            columns = [row[1] for row in cursor.fetchall()]
            assert 'source_language' not in columns
            assert 'target_language' not in columns
            
        finally:
            os.unlink(json_path)
    
    def test_bulk_insert_without_language_fields(self, temp_db):
        """Test bulk_insert() with records lacking language fields.
        
        Requirements: 1.3, 4.1
        """
        # Create dependency records without language fields
        dependencies = [
            {
                'source_artifact_name': 'PROG1',
                'source_artifact_type': 'PROGRAM',
                'target_artifact_name': 'PROG2',
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'source_file_path': 'TEST.SOURCE(PROG1)',
                'line_number': 100
            },
            {
                'source_artifact_name': 'PROG1',
                'source_artifact_type': 'PROGRAM',
                'target_artifact_name': 'COPY1',
                'target_artifact_type': 'COPYBOOK',
                'dependency_type': 'COPY',
                'source_file_path': 'TEST.SOURCE(PROG1)',
                'line_number': 50
            },
            {
                'source_artifact_name': 'PROG2',
                'source_artifact_type': 'PROGRAM',
                'target_artifact_name': 'PROG3',
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL',
                'source_file_path': 'TEST.SOURCE(PROG2)',
                'line_number': 200
            }
        ]
        
        loader = DependencyLoader(temp_db)
        stats = loader.bulk_insert(dependencies, skip_duplicates=True)
        
        # Verify loading succeeded
        assert stats['processed'] == 3
        assert stats['inserted'] == 3
        assert stats['errors'] == 0
        
        # Verify records in database
        cursor = temp_db.cursor()
        cursor.execute("SELECT COUNT(*) FROM artifact_dependencies")
        count = cursor.fetchone()[0]
        assert count == 3
        
        # Verify no language columns exist
        cursor.execute("PRAGMA table_info(artifact_dependencies)")
        columns = [row[1] for row in cursor.fetchall()]
        assert 'source_language' not in columns
        assert 'target_language' not in columns
    
    def test_all_methods_succeed_without_errors(self, temp_db):
        """Verify all loader methods succeed without errors.
        
        Requirements: 1.3, 4.1
        """
        loader = DependencyLoader(temp_db)
        
        # Test 1: bulk_insert
        deps = [
            {
                'source_artifact_name': 'TEST1',
                'source_artifact_type': 'PROGRAM',
                'target_artifact_name': 'TEST2',
                'target_artifact_type': 'PROGRAM',
                'dependency_type': 'CALL'
            }
        ]
        stats1 = loader.bulk_insert(deps)
        assert stats1['errors'] == 0
        
        # Test 2: load_from_json
        json_data = [
            {
                'source_name': 'TEST3',
                'source_type': 'PROGRAM',
                'target_name': 'TEST4',
                'target_type': 'PROGRAM',
                'dependency_type': 'CALL'
            }
        ]
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json_path = f.name
            json.dump(json_data, f)
        
        try:
            stats2 = loader.load_from_json(json_path)
            assert stats2['errors'] == 0
        finally:
            os.unlink(json_path)
        
        # Test 3: load_from_csv
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            csv_path = f.name
            writer = csv.DictWriter(f, fieldnames=[
                'source_name', 'source_type', 'target_name', 
                'target_type', 'dependency_type'
            ])
            writer.writeheader()
            writer.writerow({
                'source_name': 'TEST5',
                'source_type': 'PROGRAM',
                'target_name': 'TEST6',
                'target_type': 'PROGRAM',
                'dependency_type': 'CALL'
            })
        
        try:
            stats3 = loader.load_from_csv(csv_path)
            assert stats3['errors'] == 0
        finally:
            os.unlink(csv_path)
        
        # Verify total records
        cursor = temp_db.cursor()
        cursor.execute("SELECT COUNT(*) FROM artifact_dependencies")
        count = cursor.fetchone()[0]
        assert count == 3  # All three methods inserted one record each


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
