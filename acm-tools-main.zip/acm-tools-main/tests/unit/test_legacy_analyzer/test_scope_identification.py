"""
Unit tests for scope identification in migration flow builder.

Tests the identify_scope() method which extracts programs, copybooks,
and datasets from a ProgramFlow object.
"""

import pytest
import sqlite3
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder
from tools.legacy_analyzer.models.flow import ProgramFlow
from tools.legacy_analyzer.models.dependency import Dependency


@pytest.fixture
def test_db():
    """Create an in-memory test database."""
    conn = sqlite3.connect(':memory:')
    
    # Use MigrationFlowSchema to create required tables
    from tools.legacy_analyzer.migration.schema import MigrationFlowSchema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create minimal schema for testing (part of main schema, not migration schema)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            source_artifact_name TEXT,
            source_artifact_type TEXT,
            target_artifact_name TEXT,
            target_artifact_type TEXT,
            dependency_type TEXT,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    conn.commit()
    yield conn
    conn.close()


class TestScopeIdentification:
    """Test suite for scope identification functionality."""
    
    def test_scope_with_programs_only(self, test_db):
        """Test scope identification with only programs, no copybooks or datasets."""
        # Create a simple flow with just programs
        flow = ProgramFlow(
            start_program="PROG1",
            depth=2,
            programs=["PROG1", "PROG2", "PROG3"],
            dependencies=[]
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        assert len(scope['programs']) == 3
        assert "PROG1" in scope['programs']
        assert "PROG2" in scope['programs']
        assert "PROG3" in scope['programs']
        assert len(scope['copybooks']) == 0
        assert len(scope['datasets']) == 0
    
    def test_scope_with_programs_and_copybooks(self, test_db):
        """Test scope identification with programs and copybooks."""
        # Create dependencies with copybooks
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="COPY1",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG2",
                source_type="PROGRAM",
                target_artifact="COPY2",
                target_type="COPYBOOK",
                dependency_type="COPY"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=2,
            programs=["PROG1", "PROG2"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        assert len(scope['programs']) == 2
        assert len(scope['copybooks']) == 2
        assert "COPY1" in scope['copybooks']
        assert "COPY2" in scope['copybooks']
        assert len(scope['datasets']) == 0
    
    def test_scope_with_programs_and_datasets(self, test_db):
        """Test scope identification with programs and datasets."""
        # Create dependencies with datasets
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="EMPLOYEE.MASTER",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            ),
            Dependency(
                source_artifact="PROG2",
                source_type="PROGRAM",
                target_artifact="PAYROLL.TRANS",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=2,
            programs=["PROG1", "PROG2"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        assert len(scope['programs']) == 2
        assert len(scope['copybooks']) == 0
        assert len(scope['datasets']) == 2
        assert "EMPLOYEE.MASTER" in scope['datasets']
        assert "PAYROLL.TRANS" in scope['datasets']
    
    def test_scope_with_all_artifact_types(self, test_db):
        """Test scope identification with programs, copybooks, and datasets."""
        # Create dependencies with all types
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="COPY1",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="EMPLOYEE.MASTER",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            ),
            Dependency(
                source_artifact="PROG2",
                source_type="PROGRAM",
                target_artifact="COPY2",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG2",
                source_type="PROGRAM",
                target_artifact="PAYROLL.TRANS",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=2,
            programs=["PROG1", "PROG2", "PROG3"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        assert len(scope['programs']) == 3
        assert "PROG1" in scope['programs']
        assert "PROG2" in scope['programs']
        assert "PROG3" in scope['programs']
        
        assert len(scope['copybooks']) == 2
        assert "COPY1" in scope['copybooks']
        assert "COPY2" in scope['copybooks']
        
        assert len(scope['datasets']) == 2
        assert "EMPLOYEE.MASTER" in scope['datasets']
        assert "PAYROLL.TRANS" in scope['datasets']
    
    def test_scope_deduplication_copybooks(self, test_db):
        """Test that duplicate copybooks are handled correctly."""
        # Create dependencies where multiple programs use the same copybook
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="COMMON",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG2",
                source_type="PROGRAM",
                target_artifact="COMMON",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG3",
                source_type="PROGRAM",
                target_artifact="COMMON",
                target_type="COPYBOOK",
                dependency_type="COPY"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=2,
            programs=["PROG1", "PROG2", "PROG3"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        # Should only have one instance of COMMON
        assert len(scope['copybooks']) == 1
        assert "COMMON" in scope['copybooks']
    
    def test_scope_deduplication_datasets(self, test_db):
        """Test that duplicate datasets are handled correctly."""
        # Create dependencies where multiple programs access the same dataset
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="EMPLOYEE.MASTER",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            ),
            Dependency(
                source_artifact="PROG2",
                source_type="PROGRAM",
                target_artifact="EMPLOYEE.MASTER",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            ),
            Dependency(
                source_artifact="PROG3",
                source_type="PROGRAM",
                target_artifact="EMPLOYEE.MASTER",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=2,
            programs=["PROG1", "PROG2", "PROG3"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        # Should only have one instance of EMPLOYEE.MASTER
        assert len(scope['datasets']) == 1
        assert "EMPLOYEE.MASTER" in scope['datasets']
    
    def test_scope_with_empty_flow(self, test_db):
        """Test scope identification with an empty flow."""
        flow = ProgramFlow(
            start_program="PROG1",
            depth=0,
            programs=["PROG1"],
            dependencies=[]
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        assert len(scope['programs']) == 1
        assert "PROG1" in scope['programs']
        assert len(scope['copybooks']) == 0
        assert len(scope['datasets']) == 0
    
    def test_scope_ignores_program_call_dependencies(self, test_db):
        """Test that program call dependencies don't add to copybooks or datasets."""
        # Create dependencies with program calls (should be ignored for scope)
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="PROG2",
                target_type="PROGRAM",
                dependency_type="CALL"
            ),
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="COPY1",
                target_type="COPYBOOK",
                dependency_type="COPY"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=2,
            programs=["PROG1", "PROG2"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        # Programs come from flow.programs, not dependencies
        assert len(scope['programs']) == 2
        assert "PROG1" in scope['programs']
        assert "PROG2" in scope['programs']
        
        # Only copybook dependency should be included
        assert len(scope['copybooks']) == 1
        assert "COPY1" in scope['copybooks']
        assert len(scope['datasets']) == 0
    
    def test_scope_sorted_output(self, test_db):
        """Test that copybooks and datasets are returned in sorted order."""
        # Create dependencies in non-alphabetical order
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="ZEBRA",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="ALPHA",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="MIDDLE",
                target_type="COPYBOOK",
                dependency_type="COPY"
            ),
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="Z.DATASET",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            ),
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="A.DATASET",
                target_type="DATASET",
                dependency_type="DATASET_REF"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=1,
            programs=["PROG1"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        # Check copybooks are sorted
        assert scope['copybooks'] == ["ALPHA", "MIDDLE", "ZEBRA"]
        
        # Check datasets are sorted
        assert scope['datasets'] == ["A.DATASET", "Z.DATASET"]
    
    def test_scope_with_cics_file_dependencies(self, test_db):
        """Test scope identification with CICS file dependencies."""
        # CICS files should be treated as datasets
        deps = [
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="CUSTFILE",
                target_type="DATASET",
                dependency_type="CICS_FILE"
            ),
            Dependency(
                source_artifact="PROG1",
                source_type="PROGRAM",
                target_artifact="ACCTFILE",
                target_type="DATASET",
                dependency_type="CICS_FILE"
            )
        ]
        
        flow = ProgramFlow(
            start_program="PROG1",
            depth=1,
            programs=["PROG1"],
            dependencies=deps
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        assert len(scope['datasets']) == 2
        assert "CUSTFILE" in scope['datasets']
        assert "ACCTFILE" in scope['datasets']
    
    def test_scope_structure(self, test_db):
        """Test that scope returns the correct dictionary structure."""
        flow = ProgramFlow(
            start_program="PROG1",
            depth=0,
            programs=["PROG1"],
            dependencies=[]
        )
        
        builder = MigrationFlowBuilder(db_connection=test_db)
        scope = builder.identify_scope(flow)
        
        # Check structure
        assert isinstance(scope, dict)
        assert 'programs' in scope
        assert 'copybooks' in scope
        assert 'datasets' in scope
        assert isinstance(scope['programs'], list)
        assert isinstance(scope['copybooks'], list)
        assert isinstance(scope['datasets'], list)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
