"""Integration tests for export-jobs CLI command."""

import pytest
import json
import tempfile
import subprocess
import sys
import sqlite3
from pathlib import Path


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    yield db_path
    
    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def carddemo_db():
    """Use the real carddemo database for integration tests."""
    db_path = Path('results/carddemo_analysis/carddemo.db')
    if db_path.exists():
        return str(db_path)
    return None


def run_cli(*args):
    """Run CLI command and return result."""
    cmd = [sys.executable, '-m', 'tools.legacy_analyzer'] + list(args)
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True
    )
    return result


def setup_test_database_with_jobs(db_path):
    """Set up a test database with JCL jobs."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create inventory_jcl table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory_jcl (
            member_name VARCHAR(8) PRIMARY KEY,
            library_name VARCHAR(44),
            last_modified TIMESTAMP,
            size_lines INTEGER,
            datasets TEXT
        )
    """)
    
    # Create inventory table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            name VARCHAR(44) PRIMARY KEY,
            type VARCHAR(20),
            is_entry_point BOOLEAN,
            file_path TEXT
        )
    """)
    
    # Create artifact_dependencies table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS artifact_dependencies (
            source_artifact_name VARCHAR(44),
            source_artifact_type VARCHAR(20),
            target_artifact_name VARCHAR(44),
            target_artifact_type VARCHAR(20),
            dependency_type VARCHAR(20)
        )
    """)
    
    # Create migration_flows table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS migration_flows (
            flow_id VARCHAR(100) PRIMARY KEY,
            entry_point VARCHAR(44),
            flow_type VARCHAR(20)
        )
    """)
    
    # Insert sample JCL jobs
    cursor.execute("""
        INSERT INTO inventory_jcl VALUES 
        ('JOB001', 'JCLLIB', '2024-01-01', 100, '["DATASET.ONE", "DATASET.TWO"]')
    """)
    cursor.execute("""
        INSERT INTO inventory_jcl VALUES 
        ('JOB002', 'JCLLIB', '2024-01-02', 50, '["DATASET.THREE"]')
    """)
    cursor.execute("""
        INSERT INTO inventory_jcl VALUES 
        ('JOB003', 'JCLLIB', '2024-01-03', 75, '[]')
    """)
    
    # Insert sample programs
    cursor.execute("""
        INSERT INTO inventory VALUES 
        ('CUSTPROG', 'COBOL', 1, '/path/custprog.cbl')
    """)
    cursor.execute("""
        INSERT INTO inventory VALUES 
        ('IEFBR14', 'UTILITY', 0, '/path/iefbr14')
    """)
    
    # Insert job-to-program dependencies
    cursor.execute("""
        INSERT INTO artifact_dependencies VALUES 
        ('JOB001', 'JCL', 'CUSTPROG', 'COBOL', 'EXEC_PGM')
    """)
    cursor.execute("""
        INSERT INTO artifact_dependencies VALUES 
        ('JOB002', 'JCL', 'IEFBR14', 'UTILITY', 'EXEC_PGM')
    """)
    cursor.execute("""
        INSERT INTO artifact_dependencies VALUES 
        ('JOB003', 'JCL', 'CUSTPROG', 'COBOL', 'EXEC_PGM')
    """)
    
    # Insert job-to-job dependencies
    cursor.execute("""
        INSERT INTO artifact_dependencies VALUES 
        ('JOB002', 'JCL', 'JOB001', 'JCL', 'DEPENDS_ON')
    """)
    
    # Insert flow
    cursor.execute("""
        INSERT INTO migration_flows VALUES 
        ('FLOW_CUSTPROG', 'CUSTPROG', 'APPLICATION')
    """)
    
    conn.commit()
    conn.close()


class TestExportJobsCommand:
    """Test export-jobs CLI command."""
    
    def test_export_jobs_help(self):
        """Test export-jobs help."""
        result = run_cli('migration', 'export-jobs', '--help')
        assert result.returncode == 0
        assert 'export-jobs' in result.stdout.lower() or 'export' in result.stdout.lower()
        assert '--db' in result.stdout
        assert '--output-dir' in result.stdout
        assert '--sort-by' in result.stdout
    
    def test_export_jobs_basic(self, temp_db):
        """Test basic export-jobs command."""
        # Set up database with jobs
        setup_test_database_with_jobs(temp_db)
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as temp_dir:
            # Run export-jobs command
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir
            )
            
            # Check result
            assert result.returncode == 0
            assert 'exported' in result.stdout.lower() or 'success' in result.stdout.lower()
            
            # Verify output file was created
            output_file = Path(temp_dir) / 'jobs_by_name.json'
            assert output_file.exists()
            
            # Verify JSON content
            with open(output_file) as f:
                data = json.load(f)
            
            assert 'jobs' in data
            assert 'summary' in data
            assert isinstance(data['jobs'], list)
            assert len(data['jobs']) == 3  # JOB001, JOB002, JOB003
    
    def test_export_jobs_with_sort_by_name(self, temp_db):
        """Test export-jobs with sort-by name."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir,
                '--sort-by', 'name'
            )
            
            assert result.returncode == 0
            
            # Verify output file
            output_file = Path(temp_dir) / 'jobs_by_name.json'
            assert output_file.exists()
            
            # Verify jobs are sorted by name
            with open(output_file) as f:
                data = json.load(f)
            
            job_names = [job['jobName'] for job in data['jobs']]
            assert job_names == sorted(job_names)
    
    def test_export_jobs_with_sort_by_type(self, temp_db):
        """Test export-jobs with sort-by type."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir,
                '--sort-by', 'type'
            )
            
            assert result.returncode == 0
            
            # Verify output file
            output_file = Path(temp_dir) / 'jobs_by_type.json'
            assert output_file.exists()
            
            # Verify jobs are grouped by type
            with open(output_file) as f:
                data = json.load(f)
            
            # APPLICATION jobs should come before INFRASTRUCTURE jobs
            job_types = [job['jobType'] for job in data['jobs']]
            if 'APPLICATION' in job_types and 'INFRASTRUCTURE' in job_types:
                first_infra_idx = job_types.index('INFRASTRUCTURE')
                assert all(jt == 'APPLICATION' for jt in job_types[:first_infra_idx])
    
    def test_export_jobs_with_sort_by_complexity(self, temp_db):
        """Test export-jobs with sort-by complexity."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir,
                '--sort-by', 'complexity'
            )
            
            assert result.returncode == 0
            
            # Verify output file
            output_file = Path(temp_dir) / 'jobs_by_complexity.json'
            assert output_file.exists()
    
    def test_export_jobs_with_sort_by_dependencies(self, temp_db):
        """Test export-jobs with sort-by dependencies."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir,
                '--sort-by', 'dependencies'
            )
            
            assert result.returncode == 0
            
            # Verify output file
            output_file = Path(temp_dir) / 'jobs_by_dependencies.json'
            assert output_file.exists()
    
    def test_export_jobs_default_parameters(self, temp_db):
        """Test export-jobs with default parameters."""
        setup_test_database_with_jobs(temp_db)
        
        # Run without specifying output-dir or sort-by
        result = run_cli(
            'migration', 'export-jobs',
            '--db', temp_db
        )
        
        # Should use defaults: output-dir=results/jobs, sort-by=name
        assert result.returncode == 0
        
        # Verify default output file was created
        default_output = Path('results/jobs/jobs_by_name.json')
        if default_output.exists():
            # Cleanup
            default_output.unlink()
            default_output.parent.rmdir() if not list(default_output.parent.iterdir()) else None
    
    def test_export_jobs_missing_database(self):
        """Test error when database file is missing."""
        result = run_cli(
            'migration', 'export-jobs',
            '--db', '/nonexistent/database.db'
        )
        
        assert result.returncode != 0
        assert 'error' in result.stdout.lower() or 'not found' in result.stdout.lower()
    
    def test_export_jobs_invalid_sort_by(self, temp_db):
        """Test error with invalid sort-by parameter."""
        setup_test_database_with_jobs(temp_db)
        
        result = run_cli(
            'migration', 'export-jobs',
            '--db', temp_db,
            '--sort-by', 'invalid'
        )
        
        # Should fail with invalid choice
        assert result.returncode != 0
    
    def test_export_jobs_summary_statistics(self, temp_db):
        """Test that summary statistics are displayed."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir
            )
            
            assert result.returncode == 0
            # Should show summary statistics
            assert 'summary' in result.stdout.lower() or 'total' in result.stdout.lower()
            assert '3' in result.stdout  # Should show count of 3 jobs
    
    def test_export_jobs_json_structure(self, temp_db):
        """Test that exported JSON has correct structure."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir
            )
            
            assert result.returncode == 0
            
            # Load and verify JSON structure
            output_file = Path(temp_dir) / 'jobs_by_name.json'
            with open(output_file) as f:
                data = json.load(f)
            
            # Verify top-level structure
            assert 'jobs' in data
            assert 'summary' in data
            
            # Verify summary structure
            summary = data['summary']
            assert 'totalJobs' in summary
            assert 'applicationJobs' in summary
            assert 'infrastructureJobs' in summary
            assert 'exportDate' in summary
            assert 'database' in summary
            assert 'sortedBy' in summary
            
            # Verify job structure
            if data['jobs']:
                job = data['jobs'][0]
                assert 'jobName' in job
                assert 'jobType' in job
                assert 'hasCustomCode' in job
                assert 'linkedFlow' in job or job.get('linkedFlow') is None
                assert 'steps' in job
                assert 'datasets' in job
                assert 'dependencies' in job
                
                # Verify dependencies structure
                deps = job['dependencies']
                assert 'mustRunAfter' in deps
                assert 'mustRunBefore' in deps
    
    def test_export_jobs_file_overwrite(self, temp_db):
        """Test that existing files are overwritten."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = Path(temp_dir) / 'jobs_by_name.json'
            
            # Create existing file
            output_file.write_text('{"old": "data"}')
            
            # Run export (should overwrite)
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir
            )
            
            assert result.returncode == 0
            
            # Verify file was overwritten
            with open(output_file) as f:
                data = json.load(f)
            
            assert 'jobs' in data  # New structure
            assert 'old' not in data  # Old data gone
    
    def test_export_jobs_creates_output_directory(self, temp_db):
        """Test that output directory is created if it doesn't exist."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Use a subdirectory that doesn't exist
            output_dir = Path(temp_dir) / 'nested' / 'output'
            
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', str(output_dir)
            )
            
            assert result.returncode == 0
            
            # Verify directory was created
            assert output_dir.exists()
            assert output_dir.is_dir()
            
            # Verify file was created
            output_file = output_dir / 'jobs_by_name.json'
            assert output_file.exists()
    
    @pytest.mark.skipif(
        not Path('results/carddemo_analysis/carddemo.db').exists(),
        reason="Carddemo database not available"
    )
    def test_export_jobs_with_carddemo(self, carddemo_db):
        """Test export-jobs with real carddemo database."""
        if carddemo_db is None:
            pytest.skip("Carddemo database not available")
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', carddemo_db,
                '--output-dir', temp_dir
            )
            
            assert result.returncode == 0
            
            # Verify output file
            output_file = Path(temp_dir) / 'jobs_by_name.json'
            assert output_file.exists()
            
            # Verify content
            with open(output_file) as f:
                data = json.load(f)
            
            # Carddemo should have 35 jobs
            assert len(data['jobs']) > 0
            assert data['summary']['totalJobs'] > 0
    
    @pytest.mark.skipif(
        not Path('results/carddemo_analysis/carddemo.db').exists(),
        reason="Carddemo database not available"
    )
    def test_export_jobs_all_sort_strategies_with_carddemo(self, carddemo_db):
        """Test all sorting strategies with carddemo database."""
        if carddemo_db is None:
            pytest.skip("Carddemo database not available")
        
        strategies = ['name', 'type', 'dependencies', 'complexity']
        
        with tempfile.TemporaryDirectory() as temp_dir:
            for strategy in strategies:
                result = run_cli(
                    'migration', 'export-jobs',
                    '--db', carddemo_db,
                    '--output-dir', temp_dir,
                    '--sort-by', strategy
                )
                
                assert result.returncode == 0, f"Failed with strategy: {strategy}"
                
                # Verify output file
                output_file = Path(temp_dir) / f'jobs_by_{strategy}.json'
                assert output_file.exists(), f"Output file not created for strategy: {strategy}"
                
                # Verify content
                with open(output_file) as f:
                    data = json.load(f)
                
                assert len(data['jobs']) > 0
                assert data['summary']['sortedBy'] == strategy


class TestExportJobsErrorHandling:
    """Test error handling for export-jobs command."""
    
    def test_export_jobs_empty_database(self, temp_db):
        """Test export-jobs with empty database."""
        # Create database with complete schema but no data
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_jcl (
                member_name VARCHAR(8) PRIMARY KEY,
                library_name VARCHAR(44),
                last_modified TIMESTAMP,
                size_lines INTEGER,
                datasets TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                name VARCHAR(44) PRIMARY KEY,
                type VARCHAR(20),
                is_entry_point BOOLEAN,
                file_path TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS artifact_dependencies (
                source_artifact_name VARCHAR(44),
                source_artifact_type VARCHAR(20),
                target_artifact_name VARCHAR(44),
                target_artifact_type VARCHAR(20),
                dependency_type VARCHAR(20)
            )
        """)
        conn.commit()
        conn.close()
        
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', temp_dir
            )
            
            # Should complete successfully with warning
            assert result.returncode == 0
            assert 'warning' in result.stdout.lower() or 'no jobs' in result.stdout.lower()
    
    def test_export_jobs_database_not_file(self):
        """Test error when database path is not a file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Use directory as database path
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_dir
            )
            
            assert result.returncode != 0
            assert 'error' in result.stdout.lower()
    
    def test_export_jobs_output_path_not_directory(self, temp_db):
        """Test error when output path exists but is not a directory."""
        setup_test_database_with_jobs(temp_db)
        
        with tempfile.NamedTemporaryFile(delete=False) as f:
            file_path = f.name
        
        try:
            result = run_cli(
                'migration', 'export-jobs',
                '--db', temp_db,
                '--output-dir', file_path
            )
            
            assert result.returncode != 0
            assert 'error' in result.stdout.lower()
        finally:
            Path(file_path).unlink(missing_ok=True)
