"""
Unit tests for JSONSchemaValidator.

Tests the JSON schema validation functionality for migration flow exports.
"""

import pytest
from tools.legacy_analyzer.migration import JSONSchemaValidator


class TestCamelCaseValidation:
    """Test camelCase field name validation."""
    
    def test_valid_camel_case(self):
        """Test valid camelCase field names."""
        validator = JSONSchemaValidator()
        
        assert validator.is_camel_case('name')
        assert validator.is_camel_case('filePath')
        assert validator.is_camel_case('startLine')
        assert validator.is_camel_case('endLine')
        assert validator.is_camel_case('programType')
        assert validator.is_camel_case('entryProgram')
        assert validator.is_camel_case('flowId')
    
    def test_special_case_is_utility(self):
        """Test that is_utility is allowed for backward compatibility."""
        validator = JSONSchemaValidator()
        
        assert validator.is_camel_case('is_utility')
    
    def test_invalid_snake_case(self):
        """Test that snake_case is rejected."""
        validator = JSONSchemaValidator()
        
        assert not validator.is_camel_case('file_path')
        assert not validator.is_camel_case('start_line')
        assert not validator.is_camel_case('end_line')
        assert not validator.is_camel_case('program_type')
    
    def test_invalid_pascal_case(self):
        """Test that PascalCase is rejected."""
        validator = JSONSchemaValidator()
        
        assert not validator.is_camel_case('FilePath')
        assert not validator.is_camel_case('StartLine')
        assert not validator.is_camel_case('ProgramType')


class TestFieldTypeValidation:
    """Test field type validation."""
    
    def test_valid_string_type(self):
        """Test valid string field."""
        validator = JSONSchemaValidator()
        
        is_valid, error = validator.validate_field_type('name', 'PROGRAM1', str)
        assert is_valid
        assert error is None
    
    def test_valid_int_type(self):
        """Test valid integer field."""
        validator = JSONSchemaValidator()
        
        is_valid, error = validator.validate_field_type('startLine', 100, int)
        assert is_valid
        assert error is None
    
    def test_valid_bool_type(self):
        """Test valid boolean field."""
        validator = JSONSchemaValidator()
        
        is_valid, error = validator.validate_field_type('external', True, bool)
        assert is_valid
        assert error is None
    
    def test_invalid_type(self):
        """Test invalid field type."""
        validator = JSONSchemaValidator()
        
        is_valid, error = validator.validate_field_type('startLine', '100', int)
        assert not is_valid
        assert 'startLine' in error
        assert 'str' in error
        assert 'int' in error
    
    def test_optional_field_with_value(self):
        """Test optional field with value."""
        validator = JSONSchemaValidator()
        
        is_valid, error = validator.validate_field_type(
            'filePath', 'src/program.cbl', (str, type(None))
        )
        assert is_valid
        assert error is None
    
    def test_optional_field_with_none(self):
        """Test optional field with None value."""
        validator = JSONSchemaValidator()
        
        is_valid, error = validator.validate_field_type(
            'filePath', None, (str, type(None))
        )
        assert is_valid
        assert error is None


class TestProgramValidation:
    """Test program object validation."""
    
    def test_valid_program_minimal(self):
        """Test valid program with minimal fields."""
        validator = JSONSchemaValidator()
        
        program = {'name': 'PROGRAM1'}
        errors = validator.validate_program(program)
        
        assert len(errors) == 0
    
    def test_valid_program_with_metadata(self):
        """Test valid program with file metadata."""
        validator = JSONSchemaValidator()
        
        program = {
            'name': 'PROGRAM1',
            'filePath': 'src/cobol/PROGRAM1.cbl',
            'startLine': 1,
            'endLine': 500,
            'programType': 'MAIN',
            'language': 'COBOL'
        }
        errors = validator.validate_program(program)
        
        assert len(errors) == 0
    
    def test_program_missing_name(self):
        """Test program missing required name field."""
        validator = JSONSchemaValidator()
        
        program = {'filePath': 'src/program.cbl'}
        errors = validator.validate_program(program)
        
        assert len(errors) > 0
        assert any('name' in e for e in errors)
    
    def test_program_with_snake_case_field(self):
        """Test program with snake_case field name."""
        validator = JSONSchemaValidator()
        
        program = {
            'name': 'PROGRAM1',
            'file_path': 'src/program.cbl'  # Should be filePath
        }
        errors = validator.validate_program(program)
        
        assert len(errors) > 0
        assert any('file_path' in e and 'camelCase' in e for e in errors)
    
    def test_program_with_wrong_type(self):
        """Test program with wrong field type."""
        validator = JSONSchemaValidator()
        
        program = {
            'name': 'PROGRAM1',
            'startLine': '100'  # Should be int
        }
        errors = validator.validate_program(program)
        
        assert len(errors) > 0
        assert any('startLine' in e and 'type' in e for e in errors)


class TestCopybookValidation:
    """Test copybook object validation."""
    
    def test_valid_copybook_minimal(self):
        """Test valid copybook with minimal fields."""
        validator = JSONSchemaValidator()
        
        copybook = {'name': 'COPYBOOK1'}
        errors = validator.validate_copybook(copybook)
        
        assert len(errors) == 0
    
    def test_valid_copybook_with_file_path(self):
        """Test valid copybook with file path."""
        validator = JSONSchemaValidator()
        
        copybook = {
            'name': 'COPYBOOK1',
            'filePath': 'src/copybooks/COPYBOOK1.cpy'
        }
        errors = validator.validate_copybook(copybook)
        
        assert len(errors) == 0
    
    def test_copybook_missing_name(self):
        """Test copybook missing required name field."""
        validator = JSONSchemaValidator()
        
        copybook = {'filePath': 'src/copybook.cpy'}
        errors = validator.validate_copybook(copybook)
        
        assert len(errors) > 0
        assert any('name' in e for e in errors)


class TestCallerValidation:
    """Test caller object validation."""
    
    def test_valid_caller_minimal(self):
        """Test valid caller with minimal fields."""
        validator = JSONSchemaValidator()
        
        caller = {'source': 'JCL001'}
        errors = validator.validate_caller(caller)
        
        assert len(errors) == 0
    
    def test_valid_caller_with_metadata(self):
        """Test valid caller with file path and metadata."""
        validator = JSONSchemaValidator()
        
        caller = {
            'source': 'JCL001',
            'filePath': 'jcl/JCL001.jcl',
            'metadata': {'stepName': 'STEP01'}
        }
        errors = validator.validate_caller(caller)
        
        assert len(errors) == 0
    
    def test_caller_missing_source(self):
        """Test caller missing required source field."""
        validator = JSONSchemaValidator()
        
        caller = {'filePath': 'jcl/job.jcl'}
        errors = validator.validate_caller(caller)
        
        assert len(errors) > 0
        assert any('source' in e for e in errors)


class TestDependencyValidation:
    """Test dependency object validation."""
    
    def test_valid_dependency_minimal(self):
        """Test valid dependency with minimal fields."""
        validator = JSONSchemaValidator()
        
        dependency = {
            'flowId': 'FLOW_001',
            'entryProgram': 'PROGRAM1'
        }
        errors = validator.validate_dependency(dependency)
        
        assert len(errors) == 0
    
    def test_valid_dependency_with_file_path(self):
        """Test valid dependency with file path."""
        validator = JSONSchemaValidator()
        
        dependency = {
            'flowId': 'FLOW_001',
            'entryProgram': 'PROGRAM1',
            'filePath': 'src/cobol/PROGRAM1.cbl'
        }
        errors = validator.validate_dependency(dependency)
        
        assert len(errors) == 0
    
    def test_dependency_missing_required_fields(self):
        """Test dependency missing required fields."""
        validator = JSONSchemaValidator()
        
        dependency = {'flowId': 'FLOW_001'}
        errors = validator.validate_dependency(dependency)
        
        assert len(errors) > 0
        assert any('entryProgram' in e for e in errors)


class TestAlphabeticalOrdering:
    """Test alphabetical ordering validation."""
    
    def test_strings_in_order(self):
        """Test strings sorted alphabetically."""
        validator = JSONSchemaValidator()
        
        items = ['ALPHA', 'BETA', 'GAMMA']
        errors = validator.validate_alphabetical_order(items, 'programs')
        
        assert len(errors) == 0
    
    def test_strings_out_of_order(self):
        """Test strings not sorted alphabetically."""
        validator = JSONSchemaValidator()
        
        items = ['BETA', 'ALPHA', 'GAMMA']
        errors = validator.validate_alphabetical_order(items, 'programs')
        
        assert len(errors) > 0
        assert any('alphabetically' in e for e in errors)
    
    def test_dicts_with_name_in_order(self):
        """Test dicts with name field sorted alphabetically."""
        validator = JSONSchemaValidator()
        
        items = [
            {'name': 'ALPHA', 'filePath': 'a.cbl'},
            {'name': 'BETA', 'filePath': 'b.cbl'},
            {'name': 'GAMMA', 'filePath': 'g.cbl'}
        ]
        errors = validator.validate_alphabetical_order(items, 'programs')
        
        assert len(errors) == 0
    
    def test_dicts_with_name_out_of_order(self):
        """Test dicts with name field not sorted alphabetically."""
        validator = JSONSchemaValidator()
        
        items = [
            {'name': 'BETA', 'filePath': 'b.cbl'},
            {'name': 'ALPHA', 'filePath': 'a.cbl'},
            {'name': 'GAMMA', 'filePath': 'g.cbl'}
        ]
        errors = validator.validate_alphabetical_order(items, 'programs')
        
        assert len(errors) > 0
        assert any('alphabetically' in e for e in errors)
    
    def test_empty_list(self):
        """Test empty list is valid."""
        validator = JSONSchemaValidator()
        
        items = []
        errors = validator.validate_alphabetical_order(items, 'programs')
        
        assert len(errors) == 0


class TestScopeValidation:
    """Test scope object validation."""
    
    def test_valid_scope(self):
        """Test valid scope with all sections."""
        validator = JSONSchemaValidator()
        
        scope = {
            'programs': [
                {'name': 'ALPHA'},
                {'name': 'BETA'}
            ],
            'copybooks': [
                {'name': 'COPY1'},
                {'name': 'COPY2'}
            ],
            'datasets': ['DATASET1', 'DATASET2']
        }
        errors = validator.validate_scope(scope)
        
        assert len(errors) == 0
    
    def test_scope_programs_not_sorted(self):
        """Test scope with programs not sorted alphabetically."""
        validator = JSONSchemaValidator()
        
        scope = {
            'programs': [
                {'name': 'BETA'},
                {'name': 'ALPHA'}
            ]
        }
        errors = validator.validate_scope(scope)
        
        assert len(errors) > 0
        assert any('alphabetically' in e for e in errors)
    
    def test_scope_with_snake_case_field(self):
        """Test scope with snake_case field name."""
        validator = JSONSchemaValidator()
        
        scope = {
            'program_list': []  # Should be programs
        }
        errors = validator.validate_scope(scope)
        
        assert len(errors) > 0
        assert any('program_list' in e and 'camelCase' in e for e in errors)


class TestFlowValidation:
    """Test complete flow object validation."""
    
    def test_valid_minimal_flow(self):
        """Test valid flow with minimal required fields."""
        validator = JSONSchemaValidator()
        
        flow = {
            'flowId': 'FLOW_001',
            'name': 'Test Flow',
            'entryPoint': {
                'program': 'PROGRAM1',
                'types': []
            },
            'scope': {'programs': [], 'copybooks': [], 'datasets': []},
            'interfaces': {'inbound': [], 'outbound': []},
            'dataOperations': {'databases': [], 'datasets': []},
            'invokedByJobs': [],
            'dependencies': {'requiredFlows': [], 'dependentFlows': []},
            'complexity': {}
        }
        errors = validator.validate_flow(flow)
        
        assert len(errors) == 0
    
    def test_flow_missing_required_field(self):
        """Test flow missing required field."""
        validator = JSONSchemaValidator()
        
        flow = {
            'flowId': 'FLOW_001',
            'name': 'Test Flow',
            # Missing entryPoint
        }
        errors = validator.validate_flow(flow)
        
        assert len(errors) > 0
        assert any('entryPoint' in e for e in errors)
    
    def test_flow_with_snake_case_field(self):
        """Test flow with snake_case field name."""
        validator = JSONSchemaValidator()
        
        flow = {
            'flow_id': 'FLOW_001',  # Should be flowId
            'name': 'Test Flow',
            'entryProgram': 'PROGRAM1',
            'primaryEntryType': 'JCL'
        }
        errors = validator.validate_flow(flow)
        
        assert len(errors) > 0
        assert any('flow_id' in e and 'camelCase' in e for e in errors)
    
    def test_flow_with_invalid_scope(self):
        """Test flow with invalid scope."""
        validator = JSONSchemaValidator()
        
        flow = {
            'flowId': 'FLOW_001',
            'name': 'Test Flow',
            'entryPoint': {
                'program': 'PROGRAM1',
                'types': []
            },
            'scope': {
                'programs': [
                    {'name': 'BETA'},
                    {'name': 'ALPHA'}  # Not sorted
                ]
            }
        }
        errors = validator.validate_flow(flow)
        
        assert len(errors) > 0
        assert any('alphabetically' in e for e in errors)


class TestExportValidation:
    """Test complete export validation."""
    
    def test_valid_export(self):
        """Test valid complete export."""
        validator = JSONSchemaValidator()
        
        export_data = {
            'flows': [
                {
                    'flowId': 'FLOW_001',
                    'name': 'Test Flow',
                    'entryPoint': {
                        'program': 'PROGRAM1',
                        'types': []
                    },
                    'scope': {
                        'programs': [{'name': 'ALPHA'}, {'name': 'BETA'}],
                        'copybooks': [],
                        'datasets': []
                    },
                    'interfaces': {'inbound': [], 'outbound': []},
                    'dataOperations': {'databases': [], 'datasets': []},
                    'invokedByJobs': [],
                    'dependencies': {'requiredFlows': [], 'dependentFlows': []},
                    'complexity': {}
                }
            ]
        }
        
        is_valid, errors = validator.validate_export(export_data)
        
        assert is_valid
        assert len(errors) == 0
    
    def test_export_missing_flows_key(self):
        """Test export missing flows key."""
        validator = JSONSchemaValidator()
        
        export_data = {'data': []}
        
        is_valid, errors = validator.validate_export(export_data)
        
        assert not is_valid
        assert len(errors) > 0
        assert any('flows' in e for e in errors)
    
    def test_export_flows_not_list(self):
        """Test export with flows not a list."""
        validator = JSONSchemaValidator()
        
        export_data = {'flows': {}}
        
        is_valid, errors = validator.validate_export(export_data)
        
        assert not is_valid
        assert len(errors) > 0
    
    def test_export_with_invalid_flow(self):
        """Test export with invalid flow."""
        validator = JSONSchemaValidator()
        
        export_data = {
            'flows': [
                {
                    'flowId': 'FLOW_001',
                    # Missing required fields
                }
            ]
        }
        
        is_valid, errors = validator.validate_export(export_data)
        
        assert not is_valid
        assert len(errors) > 0
