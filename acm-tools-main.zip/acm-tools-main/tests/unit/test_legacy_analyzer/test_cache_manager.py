"""Unit tests for cache manager."""

import pytest
import tempfile
import time
from pathlib import Path
from tools.legacy_analyzer.utils.cache import (
    CacheManager, ParseResultCache, AnalysisResultCache
)


class TestCacheManager:
    """Test suite for CacheManager."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.cache_dir = Path(self.temp_dir) / 'cache'
        self.cache = CacheManager(
            cache_dir=str(self.cache_dir),
            expiration=0,  # No expiration for tests
            max_size_mb=10
        )
    
    def teardown_method(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_set_and_get(self):
        """Test basic set and get operations."""
        self.cache.set('test_key', {'data': 'value'})
        result = self.cache.get('test_key')
        
        assert result == {'data': 'value'}
    
    def test_get_nonexistent_key(self):
        """Test getting a non-existent key returns None."""
        result = self.cache.get('nonexistent')
        assert result is None
    
    def test_delete(self):
        """Test deleting a cache entry."""
        self.cache.set('test_key', 'value')
        assert self.cache.get('test_key') == 'value'
        
        self.cache.delete('test_key')
        assert self.cache.get('test_key') is None
    
    def test_clear(self):
        """Test clearing all cache entries."""
        self.cache.set('key1', 'value1')
        self.cache.set('key2', 'value2')
        
        self.cache.clear()
        
        assert self.cache.get('key1') is None
        assert self.cache.get('key2') is None
    
    def test_expiration(self):
        """Test cache expiration."""
        cache = CacheManager(
            cache_dir=str(self.cache_dir / 'expiration'),
            expiration=1  # 1 second expiration
        )
        
        cache.set('test_key', 'value')
        assert cache.get('test_key') == 'value'
        
        # Wait for expiration
        time.sleep(1.1)
        
        assert cache.get('test_key') is None
    
    def test_file_mtime_invalidation(self):
        """Test cache invalidation based on file modification time."""
        # Create a test file
        test_file = Path(self.temp_dir) / 'test.txt'
        test_file.write_text('original content')
        
        cache = CacheManager(
            cache_dir=str(self.cache_dir / 'mtime'),
            invalidation_strategy='mtime'
        )
        
        # Cache with file path
        cache.set('test_key', 'cached_value', file_path=str(test_file))
        assert cache.get('test_key', file_path=str(test_file)) == 'cached_value'
        
        # Modify file
        time.sleep(0.1)  # Ensure mtime changes
        test_file.write_text('modified content')
        
        # Cache should be invalidated
        assert cache.get('test_key', file_path=str(test_file)) is None
    
    def test_file_hash_invalidation(self):
        """Test cache invalidation based on file content hash."""
        # Create a test file
        test_file = Path(self.temp_dir) / 'test.txt'
        test_file.write_text('original content')
        
        cache = CacheManager(
            cache_dir=str(self.cache_dir / 'hash'),
            invalidation_strategy='hash'
        )
        
        # Cache with file path
        cache.set('test_key', 'cached_value', file_path=str(test_file))
        assert cache.get('test_key', file_path=str(test_file)) == 'cached_value'
        
        # Modify file content
        test_file.write_text('modified content')
        
        # Cache should be invalidated
        assert cache.get('test_key', file_path=str(test_file)) is None
    
    def test_manual_invalidation(self):
        """Test manual invalidation strategy."""
        test_file = Path(self.temp_dir) / 'test.txt'
        test_file.write_text('original content')
        
        cache = CacheManager(
            cache_dir=str(self.cache_dir / 'manual'),
            invalidation_strategy='manual'
        )
        
        # Cache with file path
        cache.set('test_key', 'cached_value', file_path=str(test_file))
        assert cache.get('test_key', file_path=str(test_file)) == 'cached_value'
        
        # Modify file - cache should still be valid
        test_file.write_text('modified content')
        assert cache.get('test_key', file_path=str(test_file)) == 'cached_value'
    
    def test_get_size(self):
        """Test getting cache size."""
        initial_size = self.cache.get_size_mb()
        
        # Add some data
        self.cache.set('key1', 'x' * 1000)
        self.cache.set('key2', 'y' * 1000)
        
        new_size = self.cache.get_size_mb()
        assert new_size > initial_size
    
    def test_size_limit_enforcement(self):
        """Test that cache size limit is enforced."""
        # Create cache with very small size limit
        cache = CacheManager(
            cache_dir=str(self.cache_dir / 'size_limit'),
            max_size_mb=0.001  # 1 KB
        )
        
        # Add entries until we exceed limit
        for i in range(10):
            cache.set(f'key{i}', 'x' * 1000)
        
        # Cache should have removed old entries
        assert cache.get_size_mb() <= 0.001
    
    def test_cleanup_expired(self):
        """Test cleanup of expired entries."""
        cache = CacheManager(
            cache_dir=str(self.cache_dir / 'cleanup'),
            expiration=1
        )
        
        cache.set('key1', 'value1')
        cache.set('key2', 'value2')
        
        # Wait for expiration
        time.sleep(1.1)
        
        removed = cache.cleanup_expired()
        assert removed == 2
    
    def test_get_stats(self):
        """Test getting cache statistics."""
        self.cache.set('key1', 'value1')
        self.cache.set('key2', 'value2')
        
        stats = self.cache.get_stats()
        
        assert stats['total_entries'] == 2
        assert stats['size_mb'] > 0
        assert 'cache_dir' in stats
    
    def test_cached_decorator(self):
        """Test the cached decorator."""
        call_count = {'count': 0}
        
        @self.cache.cached(key_func=lambda x: f"func_{x}")
        def expensive_function(x):
            call_count['count'] += 1
            return x * 2
        
        # First call - should execute function
        result1 = expensive_function(5)
        assert result1 == 10
        assert call_count['count'] == 1
        
        # Second call - should use cache
        result2 = expensive_function(5)
        assert result2 == 10
        assert call_count['count'] == 1  # Not incremented
        
        # Different argument - should execute function
        result3 = expensive_function(10)
        assert result3 == 20
        assert call_count['count'] == 2


class TestParseResultCache:
    """Test suite for ParseResultCache."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.cache_dir = Path(self.temp_dir) / 'cache'
        # Use manual invalidation strategy to avoid file existence checks
        cache_manager = CacheManager(
            cache_dir=str(self.cache_dir),
            invalidation_strategy='manual'
        )
        self.cache = ParseResultCache(cache_manager)
    
    def teardown_method(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_set_and_get_parsed_file(self):
        """Test caching parsed file results."""
        # Create a test file
        test_file = Path(self.temp_dir) / 'program.cbl'
        test_file.write_text('PROGRAM-ID. TEST.')
        
        parse_result = {'dependencies': ['DEP1', 'DEP2']}
        
        self.cache.set_parsed_file(str(test_file), parse_result)
        result = self.cache.get_parsed_file(str(test_file))
        
        assert result == parse_result
    
    def test_invalidate_file(self):
        """Test invalidating cached file."""
        # Create a test file
        test_file = Path(self.temp_dir) / 'program.cbl'
        test_file.write_text('PROGRAM-ID. TEST.')
        
        parse_result = {'dependencies': ['DEP1']}
        
        self.cache.set_parsed_file(str(test_file), parse_result)
        assert self.cache.get_parsed_file(str(test_file)) is not None
        
        self.cache.invalidate_file(str(test_file))
        assert self.cache.get_parsed_file(str(test_file)) is None


class TestAnalysisResultCache:
    """Test suite for AnalysisResultCache."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.cache_dir = Path(self.temp_dir) / 'cache'
        cache_manager = CacheManager(cache_dir=str(self.cache_dir))
        self.cache = AnalysisResultCache(cache_manager)
    
    def teardown_method(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_set_and_get_complexity(self):
        """Test caching complexity results."""
        complexity = {'loc': 100, 'cyclomatic': 15}
        
        self.cache.set_complexity('PROGRAM1', complexity)
        result = self.cache.get_complexity('PROGRAM1')
        
        assert result == complexity
    
    def test_set_and_get_flow(self):
        """Test caching flow results."""
        flow = {'programs': ['PROG1', 'PROG2'], 'depth': 2}
        
        self.cache.set_flow('PROGRAM1', flow)
        result = self.cache.get_flow('PROGRAM1')
        
        assert result == flow
