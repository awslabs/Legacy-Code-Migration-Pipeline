"""Property-based tests for program-level database schema integrity.

Feature: program-level-dependency-tracking
Properties tested:
- Property 5: Program inventory completeness
- Property 6: Program-level query support
"""

import pytest
import tempfile
import os
import json
from hypothesis import given, strategies as st, settings, HealthCheck
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas.dependencies_schema import DependenciesSchema


@st.composite
def program_boundary_record(draw):
    """Generate a valid program boundary record for testing."""
    # Use integers to ensure uniqueness
    file_id = draw(st.integers(min_value=1, max_value=999999))
    program_id = draw(st.integers(min_value=1, max_value=999999))
    
    file_path = f"/path/to/file_{file_id}.cbl"
    program_name = f"PROG_{program_id}"
    
    program_index = draw(st.integers(min_value=0, max_value=99))
    start_line = draw(st.integers(min_value=1, max_value=9999))
    end_line = draw(st.integers(min_value=start_line + 1, max_value=start_line + 1000))
    
    program_types = ['MAIN', 'PROCEDURE', 'CSECT', 'SUBPROGRAM', 'FUNCTION']
    program_type = draw(st.sampled_from(program_types))
    
    languages = ['COBOL', 'PLI', 'ASM', 'NATURAL', 'REXX', 'RPG']
    language = draw(st.sampled_from(languages))
    
    # Generate entry points as JSON array
    entry_points = draw(st.lists(
        st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
            min_size=1,
            max_size=16
        ),
        min_size=0,
        max_size=5
    ))
    
    return {
        'file_path': file_path,
        'program_name': program_name,
        'program_index': program_index,
        'start_line': start_line,
        'end_line': end_line,
        'program_type': program_type,
        'language': language,
        'entry_points': json.dumps(entry_points)
    }


@st.composite
def inventory_record_with_program_info(draw):
    """Generate an inventory record with program-level information."""
    # Use integers to ensure uniqueness
    artifact_id = draw(st.integers(min_value=1, max_value=999999))
    file_id = draw(st.integers(min_value=1, max_value=999999))
    
    artifact_name = f"ARTIFACT_{artifact_id}"
    file_path = f"/path/to/file_{file_id}.cbl"
    
    # Program-level fields
    program_within_file = draw(st.one_of(
        st.none(),
        st.just(f"PROG_{artifact_id}")
    ))
    
    file_program_index = draw(st.one_of(st.none(), st.integers(min_value=0, max_value=99)))
    program_start_line = draw(st.one_of(st.none(), st.integers(min_value=1, max_value=9999)))
    program_end_line = draw(st.one_of(
        st.none(),
        st.integers(min_value=program_start_line + 1 if program_start_line else 2, max_value=10000)
    )) if program_start_line else None
    
    program_types = ['MAIN', 'PROCEDURE', 'CSECT', 'SUBPROGRAM', 'FUNCTION']
    program_type = draw(st.one_of(st.none(), st.sampled_from(program_types)))
    
    artifact_types = ['PROGRAM', 'COPYBOOK', 'PROC', 'MODULE']
    artifact_type = draw(st.sampled_from(artifact_types))
    
    languages = ['COBOL', 'PLI', 'ASM', 'NATURAL', 'REXX', 'RPG']
    language = draw(st.sampled_from(languages))
    
    return {
        'artifact_name': artifact_name,
        'file_path': file_path,
        'artifact_type': artifact_type,
        'language': language,
        'program_within_file': program_within_file,
        'file_program_index': file_program_index,
        'program_start_line': program_start_line,
        'program_end_line': program_end_line,
        'program_type': program_type,
        'analyzed': 1
    }


@st.composite
def copybook_analysis_record(draw):
    """Generate a copybook analysis record."""
    # Use integers to ensure uniqueness
    copybook_id = draw(st.integers(min_value=1, max_value=999999))
    file_id = draw(st.integers(min_value=1, max_value=999999))
    
    copybook_name = f"COPYBOOK_{copybook_id}"
    file_path = f"/path/to/copybook_{file_id}.cpy"
    
    has_executable_code = draw(st.booleans())
    confidence_level = draw(st.floats(min_value=0.0, max_value=1.0))
    
    # Generate data structures and procedure calls as JSON arrays
    data_structures = draw(st.lists(
        st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
            min_size=1,
            max_size=32
        ),
        min_size=0,
        max_size=10
    ))
    
    procedure_calls = draw(st.lists(
        st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
            min_size=1,
            max_size=32
        ),
        min_size=0,
        max_size=10
    ))
    
    return {
        'copybook_name': copybook_name,
        'file_path': file_path,
        'has_executable_code': has_executable_code,
        'confidence_level': confidence_level,
        'data_structures': json.dumps(data_structures),
        'procedure_calls': json.dumps(procedure_calls)
    }


class TestProgramLevelSchemaProperties:
    """Property-based tests for program-level schema integrity."""
    
    def create_temp_db(self):
        """Create a temporary database with enhanced schema."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = SQLiteAdapter(db_path)
        db.connect()
        
        # Create enhanced dependencies schema
        schema = DependenciesSchema()
        table_defs = schema.get_table_definitions()
        
        # Create all tables
        for table_name, table_def in table_defs.items():
            columns = []
            for col in table_def['columns']:
                col_def = f"{col['name']} {col['type']}"
                if col.get('primary_key'):
                    col_def += " PRIMARY KEY"
                if col.get('autoincrement'):
                    col_def += " AUTOINCREMENT"
                if not col.get('nullable', True):
                    col_def += " NOT NULL"
                if col.get('default'):
                    col_def += f" DEFAULT {col['default']}"
                columns.append(col_def)
            
            create_sql = f"CREATE TABLE {table_name} ({', '.join(columns)})"
            db.execute(create_sql)
            
            # Create indexes
            for index in table_def.get('indexes', []):
                index_name = index['name']
                index_cols = ', '.join(index['columns'])
                unique = 'UNIQUE ' if index.get('unique') else ''
                index_sql = f"CREATE {unique}INDEX {index_name} ON {table_name}({index_cols})"
                db.execute(index_sql)
        
        db.commit()
        return db, db_path
    
    def test_property_5_program_inventory_completeness_schema_structure(self):
        """
        **Feature: program-level-dependency-tracking, Property 5: Program inventory completeness**
        **Validates: Requirements 3.1, 3.2, 3.4**
        
        For any multi-program file, the inventory should record each individual program name 
        with accurate positional information and file mapping.
        
        This test verifies the schema supports program-level tracking.
        """
        temp_db, db_path = self.create_temp_db()
        try:
            cursor = temp_db.cursor()
            
            # Verify inventory table has enhanced columns
            cursor.execute("PRAGMA table_info(inventory)")
            columns = {row[1]: row[2] for row in cursor.fetchall()}
            
            # Check for program-level tracking columns
            assert 'program_within_file' in columns
            assert 'file_program_index' in columns
            assert 'program_start_line' in columns
            assert 'program_end_line' in columns
            assert 'program_type' in columns
            
            # Verify program_file_mapping table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='program_file_mapping'")
            assert cursor.fetchone() is not None, "program_file_mapping table should exist"
            
            # Verify program_file_mapping table structure
            cursor.execute("PRAGMA table_info(program_file_mapping)")
            pfm_columns = {row[1]: row[2] for row in cursor.fetchall()}
            
            required_pfm_columns = [
                'file_path', 'program_name', 'program_index', 'start_line', 
                'end_line', 'program_type', 'language', 'entry_points'
            ]
            
            for col in required_pfm_columns:
                assert col in pfm_columns, f"program_file_mapping should have column '{col}'"
        finally:
            temp_db.close()
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @given(program_records=st.lists(program_boundary_record(), min_size=1, max_size=50))
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_5_program_inventory_completeness_data_storage(self, program_records):
        """
        **Feature: program-level-dependency-tracking, Property 5: Program inventory completeness**
        **Validates: Requirements 3.1, 3.2, 3.4**
        
        For any set of program boundary records, the system should be able to store
        complete program-to-file mapping information.
        """
        temp_db, db_path = self.create_temp_db()
        try:
            cursor = temp_db.cursor()
            
            # Insert program boundary records (use INSERT OR IGNORE to handle duplicates)
            for record in program_records:
                cursor.execute("""
                    INSERT OR IGNORE INTO program_file_mapping 
                    (file_path, program_name, program_index, start_line, end_line, 
                     program_type, language, entry_points)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    record['file_path'], record['program_name'], record['program_index'],
                    record['start_line'], record['end_line'], record['program_type'],
                    record['language'], record['entry_points']
                ))
            
            # Verify records were stored (may be fewer due to duplicates)
            cursor.execute("SELECT COUNT(*) FROM program_file_mapping")
            stored_count = cursor.fetchone()[0]
            assert stored_count <= len(program_records)
            assert stored_count > 0
            
            # Verify data integrity - no overlapping line ranges within same file
            cursor.execute("""
                SELECT file_path, COUNT(*) as program_count,
                       MIN(start_line) as min_start, MAX(end_line) as max_end
                FROM program_file_mapping 
                GROUP BY file_path
            """)
            
            for row in cursor.fetchall():
                file_path, program_count, min_start, max_end = row
                # Basic sanity check - start should be before end
                assert min_start < max_end, f"Invalid line ranges in file {file_path}"
        finally:
            temp_db.close()
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @given(inventory_records=st.lists(inventory_record_with_program_info(), min_size=1, max_size=50))
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_6_program_level_query_support(self, inventory_records):
        """
        **Feature: program-level-dependency-tracking, Property 6: Program-level query support**
        **Validates: Requirements 3.3**
        
        For any dependency query, the system should support retrieval of program-to-program 
        relationships with complete file location metadata.
        """
        temp_db, db_path = self.create_temp_db()
        try:
            cursor = temp_db.cursor()
            
            # Insert inventory records with program-level information (use INSERT OR IGNORE to handle duplicates)
            for record in inventory_records:
                cursor.execute("""
                    INSERT OR IGNORE INTO inventory 
                    (artifact_name, file_path, artifact_type, language, program_within_file,
                     file_program_index, program_start_line, program_end_line, program_type, analyzed)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    record['artifact_name'], record['file_path'], record['artifact_type'],
                    record['language'], record['program_within_file'], record['file_program_index'],
                    record['program_start_line'], record['program_end_line'], 
                    record['program_type'], record['analyzed']
                ))
            
            # Test program-level queries
            
            # Query 1: Find all programs within multi-program files
            cursor.execute("""
                SELECT artifact_name, program_within_file, file_program_index, 
                       program_start_line, program_end_line, program_type
                FROM inventory 
                WHERE program_within_file IS NOT NULL
                ORDER BY file_path, file_program_index
            """)
            
            multi_program_results = cursor.fetchall()
            
            # Query 2: Get program-to-file mapping with location metadata
            cursor.execute("""
                SELECT file_path, artifact_name, program_within_file, 
                       program_start_line, program_end_line, language, program_type
                FROM inventory 
                WHERE program_start_line IS NOT NULL AND program_end_line IS NOT NULL
                ORDER BY file_path, program_start_line
            """)
            
            location_results = cursor.fetchall()
            
            # Verify query results maintain data integrity
            for result in location_results:
                file_path, artifact_name, program_within_file, start_line, end_line, language, program_type = result
                
                # Verify line ranges are valid
                if start_line is not None and end_line is not None:
                    assert start_line < end_line, f"Invalid line range for {artifact_name}: {start_line}-{end_line}"
            
            # Query 3: Test program type filtering
            cursor.execute("""
                SELECT DISTINCT program_type 
                FROM inventory 
                WHERE program_type IS NOT NULL
            """)
            
            program_types = [row[0] for row in cursor.fetchall()]
            
            # Verify we can filter by program type
            for prog_type in program_types:
                cursor.execute("""
                    SELECT COUNT(*) 
                    FROM inventory 
                    WHERE program_type = ?
                """, (prog_type,))
                
                count = cursor.fetchone()[0]
                assert count > 0, f"Should find programs of type {prog_type}"
        finally:
            temp_db.close()
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    @given(copybook_records=st.lists(copybook_analysis_record(), min_size=1, max_size=30))
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_copybook_analysis_table_functionality(self, copybook_records):
        """
        Test that the copybook_analysis table supports executable code detection results.
        
        This supports the program-level tracking by identifying which copybooks
        contain executable code versus data structures.
        """
        temp_db, db_path = self.create_temp_db()
        try:
            cursor = temp_db.cursor()
            
            # Insert copybook analysis records (use INSERT OR IGNORE to handle duplicates)
            for record in copybook_records:
                cursor.execute("""
                    INSERT OR IGNORE INTO copybook_analysis 
                    (copybook_name, file_path, has_executable_code, confidence_level,
                     data_structures, procedure_calls)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    record['copybook_name'], record['file_path'], record['has_executable_code'],
                    record['confidence_level'], record['data_structures'], record['procedure_calls']
                ))
            
            # Verify records were stored (may be fewer due to duplicates)
            cursor.execute("SELECT COUNT(*) FROM copybook_analysis")
            stored_count = cursor.fetchone()[0]
            assert stored_count <= len(copybook_records)
            assert stored_count > 0
            
            # Test executable code filtering
            cursor.execute("""
                SELECT copybook_name, confidence_level 
                FROM copybook_analysis 
                WHERE has_executable_code = 1
            """)
            
            executable_copybooks = cursor.fetchall()
            
            # Test confidence level queries
            cursor.execute("""
                SELECT AVG(confidence_level) as avg_confidence
                FROM copybook_analysis
            """)
            
            avg_confidence = cursor.fetchone()[0]
            if avg_confidence is not None:
                assert 0.0 <= avg_confidence <= 1.0, "Average confidence should be between 0 and 1"
            
            # Test JSON field queries (basic validation)
            cursor.execute("""
                SELECT data_structures, procedure_calls 
                FROM copybook_analysis 
                LIMIT 5
            """)
            
            for row in cursor.fetchall():
                data_structures, procedure_calls = row
                
                # Verify JSON fields can be parsed
                if data_structures:
                    try:
                        json.loads(data_structures)
                    except json.JSONDecodeError:
                        pytest.fail(f"Invalid JSON in data_structures: {data_structures}")
                
                if procedure_calls:
                    try:
                        json.loads(procedure_calls)
                    except json.JSONDecodeError:
                        pytest.fail(f"Invalid JSON in procedure_calls: {procedure_calls}")
        finally:
            temp_db.close()
            if os.path.exists(db_path):
                os.unlink(db_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])