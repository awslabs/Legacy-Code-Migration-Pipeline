"""Property-based tests for DependencyLoader.

Feature: dependency-schema-normalization
"""

import pytest
import tempfile
import os
from hypothesis import given, strategies as st, settings, HealthCheck
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.legacy_analyzer.dependency_loader import DependencyLoader


# Strategy for generating valid dependency records without language fields
@st.composite
def dependency_record(draw):
    """Generate a valid dependency record without language fields."""
    # Generate artifact names (1-44 chars, alphanumeric)
    source_name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
        min_size=1,
        max_size=44
    ))
    target_name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
        min_size=1,
        max_size=44
    ))
    
    # Generate artifact types (1-20 chars)
    artifact_types = ['PROGRAM', 'COPYBOOK', 'PROC', 'MODULE', 'SUBROUTINE']
    source_type = draw(st.sampled_from(artifact_types))
    target_type = draw(st.sampled_from(artifact_types))
    
    # Generate dependency type (1-20 chars)
    dep_types = ['CALL', 'COPY', 'EXEC', 'FETCH', 'INCLUDE']
    dep_type = draw(st.sampled_from(dep_types))
    
    # Optional fields
    file_path = draw(st.one_of(
        st.none(),
        st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd', 'P'), max_codepoint=127),
            min_size=1,
            max_size=255
        )
    ))
    
    line_number = draw(st.one_of(st.none(), st.integers(min_value=1, max_value=999999)))
    
    return {
        'source_artifact_name': source_name,
        'source_artifact_type': source_type,
        'target_artifact_name': target_name,
        'target_artifact_type': target_type,
        'dependency_type': dep_type,
        'source_file_path': file_path,
        'line_number': line_number
    }


class TestDependencyLoaderProperties:
    """Property-based tests for DependencyLoader."""
    
    @pytest.fixture
    def temp_db(self):
        """Create a temporary database for testing."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = SQLiteAdapter(db_path)
        db.connect()
        
        # Create dependencies schema
        loader = DependencyLoader(db)
        loader.create_dependencies_schema()
        
        yield db
        
        # Cleanup
        db.close()
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    @given(dependencies=st.lists(dependency_record(), min_size=1, max_size=100))
    @settings(
        max_examples=100, 
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_dependency_loading_succeeds_without_language_fields(
        self, temp_db, dependencies
    ):
        """
        Feature: dependency-schema-normalization, Property 2: Dependency loading succeeds without language fields
        
        Validates: Requirements 1.3, 4.1
        
        For any valid dependency record without language fields, loading into the 
        database should succeed without errors.
        """
        loader = DependencyLoader(temp_db)
        
        # Load dependencies using bulk_insert
        stats = loader.bulk_insert(dependencies, skip_duplicates=True)
        
        # Verify loading succeeded
        assert stats['processed'] == len(dependencies)
        assert stats['errors'] == 0
        
        # Verify records were inserted (accounting for potential duplicates)
        assert stats['inserted'] + stats['skipped'] == len(dependencies)
        
        # Query database to verify records don't have language fields
        cursor = temp_db.cursor()
        cursor.execute("PRAGMA table_info(artifact_dependencies)")
        columns = [row[1] for row in cursor.fetchall()]
        
        # Verify language columns don't exist
        assert 'source_language' not in columns
        assert 'target_language' not in columns
        
        # Verify required columns exist
        assert 'source_artifact_name' in columns
        assert 'source_artifact_type' in columns
        assert 'target_artifact_name' in columns
        assert 'target_artifact_type' in columns
        assert 'dependency_type' in columns


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
