"""
Property-Based Tests for External Interface Loader

This module contains property-based tests for the ExternalInterfaceLoader class,
validating that configuration loading prevents duplicates and maintains data integrity.
"""

import pytest
import sqlite3
import tempfile
import json
import csv
from pathlib import Path
from hypothesis import given, strategies as st, settings

from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
from tools.legacy_analyzer.migration.interface_loader import ExternalInterfaceLoader


# Strategy for generating valid interface data
@st.composite
def inbound_interface(draw):
    """Generate a valid inbound interface configuration."""
    return {
        'source_name': draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
            whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
        ))),
        'target_program': draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
            whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
        ))),
        'dependency_type': draw(st.sampled_from([
            'PROGRAM_CALL', 'CICS_LINK', 'CICS_XCTL', 'EXTERNAL_CALL'
        ])),
        'system': draw(st.one_of(st.none(), st.text(min_size=0, max_size=50))),
        'description': draw(st.one_of(st.none(), st.text(min_size=0, max_size=100)))
    }


@st.composite
def outbound_interface(draw):
    """Generate a valid outbound interface configuration."""
    return {
        'program_name': draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
            whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
        ))),
        'reason': draw(st.sampled_from(['configured', 'missing_source_code', 'assumed_external'])),
        'description': draw(st.one_of(st.none(), st.text(min_size=0, max_size=100)))
    }


class TestInterfaceLoaderProperties:
    """Property-based tests for ExternalInterfaceLoader."""
    
    @given(
        interfaces=st.lists(inbound_interface(), min_size=1, max_size=20),
        num_loads=st.integers(min_value=1, max_value=5)
    )
    @settings(max_examples=100, deadline=None)
    def test_property_9_load_prevents_duplicates_inbound(self, interfaces, num_loads):
        """
        Property 9: Configuration Loading Prevents Duplicates
        
        For any configuration loaded multiple times,
        each interface should be inserted exactly once.
        
        **Feature: fix-inbound-interface-logic, Property 9: Configuration Loading Prevents Duplicates**
        **Validates: Requirements 8.5**
        """
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        try:
            # Setup database
            conn = sqlite3.connect(db_path)
            schema_manager = InterfaceSchemaManager(conn)
            schema_manager.create_tables()
            
            # Create temporary JSON file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as tmp_file:
                json_path = tmp_file.name
                json.dump({'inbound': interfaces}, tmp_file)
            
            try:
                # Load configuration multiple times
                loader = ExternalInterfaceLoader(conn)
                
                first_count = None
                for i in range(num_loads):
                    count = loader.load_inbound_interfaces(json_path)
                    
                    if i == 0:
                        first_count = count
                    else:
                        # Subsequent loads should insert 0 new records (all duplicates)
                        assert count == 0, \
                            f"Load {i+1} inserted {count} records, expected 0 (duplicates)"
                
                # Verify total count in database matches first load
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM inbound_interfaces")
                total_count = cursor.fetchone()[0]
                
                assert total_count == first_count, \
                    f"Database has {total_count} records, expected {first_count}"
                
                # Verify each unique interface exists exactly once
                for interface in interfaces:
                    cursor.execute("""
                        SELECT COUNT(*) FROM inbound_interfaces
                        WHERE source_name = ? AND target_program = ? AND dependency_type = ?
                    """, (interface['source_name'], interface['target_program'], 
                          interface['dependency_type']))
                    
                    count = cursor.fetchone()[0]
                    assert count <= 1, \
                        f"Interface {interface['source_name']}->{interface['target_program']} " \
                        f"appears {count} times, expected 0 or 1"
                
            finally:
                Path(json_path).unlink(missing_ok=True)
            
            conn.close()
            
        finally:
            Path(db_path).unlink(missing_ok=True)
    
    @given(
        interfaces=st.lists(outbound_interface(), min_size=1, max_size=20),
        num_loads=st.integers(min_value=1, max_value=5)
    )
    @settings(max_examples=100, deadline=None)
    def test_property_9_load_prevents_duplicates_outbound(self, interfaces, num_loads):
        """
        Property 9: Configuration Loading Prevents Duplicates (Outbound)
        
        For any outbound configuration loaded multiple times,
        each interface should be inserted exactly once.
        
        **Feature: fix-inbound-interface-logic, Property 9: Configuration Loading Prevents Duplicates**
        **Validates: Requirements 8.5**
        """
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        try:
            # Setup database
            conn = sqlite3.connect(db_path)
            schema_manager = InterfaceSchemaManager(conn)
            schema_manager.create_tables()
            
            # Create temporary JSON file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as tmp_file:
                json_path = tmp_file.name
                json.dump({'outbound': interfaces}, tmp_file)
            
            try:
                # Load configuration multiple times
                loader = ExternalInterfaceLoader(conn)
                
                first_count = None
                for i in range(num_loads):
                    count = loader.load_outbound_interfaces(json_path)
                    
                    if i == 0:
                        first_count = count
                    else:
                        # Subsequent loads should insert 0 new records (all duplicates)
                        assert count == 0, \
                            f"Load {i+1} inserted {count} records, expected 0 (duplicates)"
                
                # Verify total count in database matches first load
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM outbound_interfaces")
                total_count = cursor.fetchone()[0]
                
                assert total_count == first_count, \
                    f"Database has {total_count} records, expected {first_count}"
                
                # Verify each unique interface exists exactly once
                for interface in interfaces:
                    cursor.execute("""
                        SELECT COUNT(*) FROM outbound_interfaces
                        WHERE program_name = ?
                    """, (interface['program_name'],))
                    
                    count = cursor.fetchone()[0]
                    assert count <= 1, \
                        f"Interface {interface['program_name']} " \
                        f"appears {count} times, expected 0 or 1"
                
            finally:
                Path(json_path).unlink(missing_ok=True)
            
            conn.close()
            
        finally:
            Path(db_path).unlink(missing_ok=True)
    
    @given(
        interfaces=st.lists(inbound_interface(), min_size=1, max_size=20)
    )
    @settings(max_examples=100, deadline=None)
    def test_property_metadata_preservation(self, interfaces):
        """
        Property: Metadata Preservation
        
        For any interface with metadata, the loader should preserve
        all metadata fields in the database for the FIRST occurrence
        of each unique interface (duplicates are ignored).
        
        **Validates: Requirements 8.3, 8.6**
        """
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        try:
            # Setup database
            conn = sqlite3.connect(db_path)
            schema_manager = InterfaceSchemaManager(conn)
            schema_manager.create_tables()
            
            # Create temporary JSON file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as tmp_file:
                json_path = tmp_file.name
                json.dump({'inbound': interfaces}, tmp_file)
            
            try:
                # Load configuration
                loader = ExternalInterfaceLoader(conn)
                loader.load_inbound_interfaces(json_path)
                
                # Build a map of unique interfaces (first occurrence wins)
                unique_interfaces = {}
                for interface in interfaces:
                    key = (interface['source_name'], interface['target_program'], 
                           interface['dependency_type'])
                    if key not in unique_interfaces:
                        unique_interfaces[key] = interface
                
                # Verify metadata preservation for unique interfaces only
                cursor = conn.cursor()
                for key, interface in unique_interfaces.items():
                    cursor.execute("""
                        SELECT metadata FROM inbound_interfaces
                        WHERE source_name = ? AND target_program = ? AND dependency_type = ?
                    """, key)
                    
                    result = cursor.fetchone()
                    assert result is not None, \
                        f"Interface {key} should be in database"
                    
                    metadata_json = result[0]
                    
                    # Check if metadata was stored
                    if interface.get('system') or interface.get('description'):
                        assert metadata_json is not None, \
                            f"Metadata should be stored for interface with system/description"
                        
                        metadata = json.loads(metadata_json)
                        
                        # Verify system field if present
                        if interface.get('system'):
                            assert 'system' in metadata, \
                                f"System field missing from metadata"
                            assert metadata['system'] == interface['system'], \
                                f"System field mismatch: expected {interface['system']}, got {metadata['system']}"
                        
                        # Verify description field if present
                        if interface.get('description'):
                            assert 'description' in metadata, \
                                f"Description field missing from metadata"
                            assert metadata['description'] == interface['description'], \
                                f"Description field mismatch: expected {interface['description']}, got {metadata['description']}"
                
            finally:
                Path(json_path).unlink(missing_ok=True)
            
            conn.close()
            
        finally:
            Path(db_path).unlink(missing_ok=True)
