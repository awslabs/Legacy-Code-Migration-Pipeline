"""Unit tests for CSD parser."""

import pytest
import tempfile
import os
from tools.legacy_analyzer.parsers.csd_parser import (
    CSDParser,
    CSDData,
    CICSTransaction,
    CICSProgram,
    CICSFile,
    CICSMapset
)


class TestCSDParser:
    """Test suite for CSD parser."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = CSDParser()
    
    def test_parse_transaction_basic(self):
        """Test parsing a basic TRANSACTION definition."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.transactions) == 1
        trans = csd_data.transactions[0]
        assert trans.resource_name == "CAUP"
        assert trans.resource_type == "TRANSACTION"
        assert trans.group_name == "CARDDEMO"
        assert trans.program_name == "COACTUPC"
        assert trans.status == "ENABLED"
    
    def test_parse_transaction_with_description(self):
        """Test parsing TRANSACTION with DESCRIPTION."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
 DESCRIPTION(CREDIT CARD DEMO ACCOUNT UPDATE)
        PROGRAM(COACTUPC) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.transactions) == 1
        trans = csd_data.transactions[0]
        assert trans.description == "CREDIT CARD DEMO ACCOUNT UPDATE"
    
    def test_parse_program_basic(self):
        """Test parsing a basic PROGRAM definition."""
        csd_content = """
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.programs) == 1
        prog = csd_data.programs[0]
        assert prog.resource_name == "COACTUPC"
        assert prog.resource_type == "PROGRAM"
        assert prog.group_name == "CARDDEMO"
        assert prog.language == "COBOL"
        assert prog.status == "ENABLED"
    
    def test_parse_program_with_transid(self):
        """Test parsing PROGRAM with TRANSID attribute."""
        csd_content = """
 DEFINE PROGRAM(COACTVWC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED) TRANSID(CAVW)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.programs) == 1
        prog = csd_data.programs[0]
        assert prog.transaction_id == "CAVW"
    
    def test_parse_file_with_dsname(self):
        """Test parsing FILE with DSNAME."""
        csd_content = """
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.files) == 1
        file = csd_data.files[0]
        assert file.resource_name == "ACCTDAT"
        assert file.resource_type == "FILE"
        assert file.group_name == "CARDDEMO"
        assert file.dataset_name == "AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS"
        assert file.status == "ENABLED"
    
    def test_parse_file_with_description(self):
        """Test parsing FILE with DESCRIPTION."""
        csd_content = """
 DEFINE FILE(CCXREF) GROUP(CARDDEMO)
 DESCRIPTION(CARD TO ACCOUNT XREF)
        DSNAME(AWS.M2.CARDDEMO.CARDXREF.VSAM.KSDS) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.files) == 1
        file = csd_data.files[0]
        assert file.description == "CARD TO ACCOUNT XREF"
    
    def test_parse_mapset_basic(self):
        """Test parsing a basic MAPSET definition."""
        csd_content = """
 DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
        STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.mapsets) == 1
        mapset = csd_data.mapsets[0]
        assert mapset.resource_name == "COACTUP"
        assert mapset.resource_type == "MAPSET"
        assert mapset.group_name == "CARDDEMO"
        assert mapset.status == "ENABLED"
    
    def test_parse_mapset_with_description(self):
        """Test parsing MAPSET with DESCRIPTION."""
        csd_content = """
 DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
 DESCRIPTION(CREDIT CARD ACCOUNT UPDATE MAP)
        STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.mapsets) == 1
        mapset = csd_data.mapsets[0]
        assert mapset.description == "CREDIT CARD ACCOUNT UPDATE MAP"
    
    def test_parse_multiple_resources(self):
        """Test parsing multiple resource types."""
        csd_content = """
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS) STATUS(ENABLED)
 DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
        STATUS(ENABLED)
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.files) == 1
        assert len(csd_data.mapsets) == 1
        assert len(csd_data.programs) == 1
        assert len(csd_data.transactions) == 1
    
    def test_parse_disabled_status(self):
        """Test parsing resources with DISABLED status."""
        csd_content = """
 DEFINE PROGRAM(OLDPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(DISABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.programs) == 1
        prog = csd_data.programs[0]
        assert prog.status == "DISABLED"
    
    def test_parse_default_status(self):
        """Test that STATUS defaults to ENABLED when not specified."""
        csd_content = """
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.programs) == 1
        prog = csd_data.programs[0]
        assert prog.status == "ENABLED"
    
    def test_parse_multiline_definition(self):
        """Test parsing multi-line resource definitions."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
 DESCRIPTION(CREDIT CARD DEMO ACCOUNT UPDATE)
        PROGRAM(COACTUPC) TWASIZE(0) PROFILE(DFHCICST) STATUS(ENABLED)
        TASKDATALOC(ANY) TASKDATAKEY(USER) STORAGECLEAR(NO)
        RUNAWAY(SYSTEM) SHUTDOWN(DISABLED) ISOLATE(YES) DYNAMIC(NO)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.transactions) == 1
        trans = csd_data.transactions[0]
        assert trans.resource_name == "CAUP"
        assert trans.program_name == "COACTUPC"
        assert trans.description == "CREDIT CARD DEMO ACCOUNT UPDATE"
    
    def test_parse_unsupported_resource_type(self):
        """Test that unsupported resource types are skipped."""
        csd_content = """
 DEFINE LIBRARY(CARDDLIB) GROUP(CARDDEMO)
        RANKING(50) CRITICAL(NO) STATUS(ENABLED)
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        # LIBRARY should be skipped, only PROGRAM should be parsed
        assert len(csd_data.programs) == 1
        assert len(csd_data.get_all_resources()) == 1
    
    def test_parse_file_from_carddemo(self):
        """Test parsing with actual CARDDEMO.csd sample."""
        # Use a subset of the actual CARDDEMO.csd file
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Verify we got expected resources
            assert len(csd_data.transactions) > 0
            assert len(csd_data.programs) > 0
            assert len(csd_data.files) > 0
            assert len(csd_data.mapsets) > 0
            
            # Check specific transaction
            caup_trans = [t for t in csd_data.transactions if t.resource_name == "CAUP"]
            assert len(caup_trans) == 1
            assert caup_trans[0].program_name == "COACTUPC"
            assert caup_trans[0].group_name == "CARDDEMO"
    
    def test_carddemo_file_counts(self):
        """Test that CARDDEMO.csd has expected resource counts."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Based on the actual CARDDEMO.csd file
            # 8 FILES, 17 MAPSETS, 18 PROGRAMS, 18 TRANSACTIONS
            assert len(csd_data.files) == 8
            assert len(csd_data.mapsets) == 17
            assert len(csd_data.programs) == 18
            assert len(csd_data.transactions) == 18
            
            # Total resources (excluding LIBRARY and TDQUEUE which are unsupported)
            assert len(csd_data.get_all_resources()) == 61
    
    def test_carddemo_specific_files(self):
        """Test specific FILE resources from CARDDEMO.csd."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Check ACCTDAT file
            acctdat = [f for f in csd_data.files if f.resource_name == "ACCTDAT"]
            assert len(acctdat) == 1
            assert acctdat[0].dataset_name == "AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS"
            assert acctdat[0].group_name == "CARDDEMO"
            assert acctdat[0].status == "ENABLED"
            
            # Check CCXREF file with description
            ccxref = [f for f in csd_data.files if f.resource_name == "CCXREF"]
            assert len(ccxref) == 1
            assert ccxref[0].description == "CARD TO ACCOUNT XREF"
            assert ccxref[0].dataset_name == "AWS.M2.CARDDEMO.CARDXREF.VSAM.KSDS"
            
            # Check CUSTDAT file with description
            custdat = [f for f in csd_data.files if f.resource_name == "CUSTDAT"]
            assert len(custdat) == 1
            assert custdat[0].description == "CARDDEMO CUSTOMER DATA"
            assert custdat[0].dataset_name == "AWS.M2.CARDDEMO.CUSTDATA.VSAM.KSDS"
    
    def test_carddemo_specific_programs(self):
        """Test specific PROGRAM resources from CARDDEMO.csd."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Check COACTUPC program with description
            coactupc = [p for p in csd_data.programs if p.resource_name == "COACTUPC"]
            assert len(coactupc) == 1
            assert coactupc[0].description == "CREDIT CARD DEMO ACCOUNT UPDATE"
            assert coactupc[0].group_name == "CARDDEMO"
            assert coactupc[0].status == "ENABLED"
            
            # Check COACTVWC program with TRANSID
            coactvwc = [p for p in csd_data.programs if p.resource_name == "COACTVWC"]
            assert len(coactvwc) == 1
            assert coactvwc[0].description == "VIEW ACCT"
            assert coactvwc[0].transaction_id == "CAVW"
            
            # Check COADM01C program with LANGUAGE
            coadm01c = [p for p in csd_data.programs if p.resource_name == "COADM01C"]
            assert len(coadm01c) == 1
            assert coadm01c[0].language == "COBOL"
            
            # Check COCRDLIC program with both TRANSID and description
            cocrdlic = [p for p in csd_data.programs if p.resource_name == "COCRDLIC"]
            assert len(cocrdlic) == 1
            assert cocrdlic[0].description == "LIST CARDS"
            assert cocrdlic[0].transaction_id == "CC00"
            
            # Check COSGN00C program
            cosgn00c = [p for p in csd_data.programs if p.resource_name == "COSGN00C"]
            assert len(cosgn00c) == 1
            assert cosgn00c[0].description == "LOGIN"
            assert cosgn00c[0].transaction_id == "CC00"
    
    def test_carddemo_specific_transactions(self):
        """Test specific TRANSACTION resources from CARDDEMO.csd."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Check CAUP transaction with description
            caup = [t for t in csd_data.transactions if t.resource_name == "CAUP"]
            assert len(caup) == 1
            assert caup[0].description == "CREDIT CARD DEMO ACCOUNT UPDATE"
            assert caup[0].program_name == "COACTUPC"
            assert caup[0].group_name == "CARDDEMO"
            assert caup[0].status == "ENABLED"
            
            # Check CAVW transaction
            cavw = [t for t in csd_data.transactions if t.resource_name == "CAVW"]
            assert len(cavw) == 1
            assert cavw[0].program_name == "COACTVWC"
            
            # Check CCUP transaction with description
            ccup = [t for t in csd_data.transactions if t.resource_name == "CCUP"]
            assert len(ccup) == 1
            assert ccup[0].description == "CREDIT CARD UPDATE TRANSACTION"
            assert ccup[0].program_name == "COCRDUPC"
            
            # Check CDV1 transaction with description
            cdv1 = [t for t in csd_data.transactions if t.resource_name == "CDV1"]
            assert len(cdv1) == 1
            assert cdv1[0].description == "DEVELOPER TRANSACTION - 1"
            assert cdv1[0].program_name == "COCRDSEC"
            
            # Check CC00 transaction
            cc00 = [t for t in csd_data.transactions if t.resource_name == "CC00"]
            assert len(cc00) == 1
            assert cc00[0].program_name == "COSGN00C"
    
    def test_carddemo_specific_mapsets(self):
        """Test specific MAPSET resources from CARDDEMO.csd."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Check COACTUP mapset with description
            coactup = [m for m in csd_data.mapsets if m.resource_name == "COACTUP"]
            assert len(coactup) == 1
            assert coactup[0].description == "CREDIT CARD ACCOUNT UPDATE MAP"
            assert coactup[0].group_name == "CARDDEMO"
            assert coactup[0].status == "ENABLED"
            
            # Check COACTVW mapset with description
            coactvw = [m for m in csd_data.mapsets if m.resource_name == "COACTVW"]
            assert len(coactvw) == 1
            assert coactvw[0].description == "VIEW ACCOUNT"
            
            # Check COCRDLI mapset with description
            cocrdli = [m for m in csd_data.mapsets if m.resource_name == "COCRDLI"]
            assert len(cocrdli) == 1
            assert cocrdli[0].description == "LIST CARDS"
            
            # Check COCRDSL mapset with description
            cocrdsl = [m for m in csd_data.mapsets if m.resource_name == "COCRDSL"]
            assert len(cocrdsl) == 1
            assert cocrdsl[0].description == "SEARCH CARDS"
            
            # Check COCRDUP mapset with description
            cocrdup = [m for m in csd_data.mapsets if m.resource_name == "COCRDUP"]
            assert len(cocrdup) == 1
            assert cocrdup[0].description == "CREDIT CARD UPDATE MAPSET"
    
    def test_carddemo_all_groups_are_carddemo(self):
        """Test that all resources in CARDDEMO.csd belong to CARDDEMO group."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # All resources should be in CARDDEMO group
            for resource in csd_data.get_all_resources():
                assert resource.group_name == "CARDDEMO"
    
    def test_carddemo_all_enabled_status(self):
        """Test that all parsed resources in CARDDEMO.csd are ENABLED."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # All parsed resources should be ENABLED (LIBRARY with DISABLED is not parsed)
            for resource in csd_data.get_all_resources():
                assert resource.status == "ENABLED"
    
    def test_carddemo_csv_export(self):
        """Test exporting CARDDEMO.csd data to CSV."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Export to CSV
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
                csv_file = f.name
            
            try:
                self.parser.to_csv(csd_data, csv_file)
                
                # Read and verify CSV
                with open(csv_file, 'r') as f:
                    lines = f.readlines()
                
                # Should have header + 61 resources
                assert len(lines) == 62
                
                # Check header
                header = lines[0]
                assert 'resource_name' in header
                assert 'resource_type' in header
                assert 'group_name' in header
                assert 'status' in header
                assert 'program_name' in header
                assert 'dataset_name' in header
                assert 'description' in header
                
                # Check that CAUP transaction is in CSV
                caup_lines = [l for l in lines if 'CAUP,' in l and 'TRANSACTION' in l]
                assert len(caup_lines) == 1
                assert 'COACTUPC' in caup_lines[0]
                assert 'CREDIT CARD DEMO ACCOUNT UPDATE' in caup_lines[0]
                
                # Check that ACCTDAT file is in CSV
                acctdat_lines = [l for l in lines if 'ACCTDAT,' in l and 'FILE' in l]
                assert len(acctdat_lines) == 1
                assert 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS' in acctdat_lines[0]
                
                # Check that COACTUPC program is in CSV
                coactupc_lines = [l for l in lines if 'COACTUPC,' in l and 'PROGRAM' in l]
                assert len(coactupc_lines) == 1
                assert 'CREDIT CARD DEMO ACCOUNT UPDATE' in coactupc_lines[0]
                
                # Check that COACTUP mapset is in CSV
                coactup_lines = [l for l in lines if 'COACTUP,' in l and 'MAPSET' in l]
                assert len(coactup_lines) == 1
                assert 'CREDIT CARD ACCOUNT UPDATE MAP' in coactup_lines[0]
            finally:
                os.unlink(csv_file)
    
    def test_carddemo_validation(self):
        """Test validation of CARDDEMO.csd data."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            issues = self.parser.validate_csd_data(csd_data)
            
            # Should have no errors (all data is valid)
            assert len(issues['errors']) == 0
            
            # Should have info messages about resource counts
            assert len(issues['info']) > 0
            
            # Check for expected info messages
            info_str = ' '.join(issues['info'])
            assert '18 transactions' in info_str or 'Transactions: 18' in info_str
            assert '18 programs' in info_str or 'Programs: 18' in info_str
            assert '8 files' in info_str or 'Files: 8' in info_str
            assert '17 mapsets' in info_str or 'Mapsets: 17' in info_str
    
    def test_carddemo_transaction_program_mapping(self):
        """Test that transactions correctly map to programs in CARDDEMO.csd."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Create a mapping of transaction to program
            trans_prog_map = {
                "CAUP": "COACTUPC",
                "CAVW": "COACTVWC",
                "CA00": "COADM01C",
                "CB00": "COBIL00C",
                "CCDL": "COCRDSLC",
                "CCLI": "COCRDLIC",
                "CCUP": "COCRDUPC",
                "CC00": "COSGN00C",
                "CDV1": "COCRDSEC",
                "CM00": "COMEN01C",
                "CR00": "CORPT00C",
                "CT00": "COTRN00C",
                "CT01": "COTRN01C",
                "CT02": "COTRN02C",
                "CU00": "COUSR00C",
                "CU01": "COUSR01C",
                "CU02": "COUSR02C",
                "CU03": "COUSR03C",
            }
            
            # Verify each mapping
            for trans_id, prog_name in trans_prog_map.items():
                trans = [t for t in csd_data.transactions if t.resource_name == trans_id]
                assert len(trans) == 1, f"Transaction {trans_id} not found"
                assert trans[0].program_name == prog_name, f"Transaction {trans_id} should map to {prog_name}"
    
    def test_carddemo_programs_with_transid(self):
        """Test programs that have TRANSID attribute in CARDDEMO.csd."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Programs with TRANSID attribute
            programs_with_transid = [p for p in csd_data.programs if p.transaction_id]
            
            # Based on CARDDEMO.csd, these programs have TRANSID
            expected_transids = {
                "COACTVWC": "CAVW",
                "COCRDLIC": "CC00",
                "COCRDSLC": "CCDL",
                "COSGN00C": "CC00",
            }
            
            assert len(programs_with_transid) == len(expected_transids)
            
            for prog in programs_with_transid:
                assert prog.resource_name in expected_transids
                assert prog.transaction_id == expected_transids[prog.resource_name]
    
    def test_carddemo_programs_with_language(self):
        """Test programs that have LANGUAGE attribute in CARDDEMO.csd."""
        csd_file = "examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd"
        
        if os.path.exists(csd_file):
            csd_data = self.parser.parse_file(csd_file)
            
            # Programs with LANGUAGE attribute
            programs_with_language = [p for p in csd_data.programs if p.language]
            
            # Based on CARDDEMO.csd, these programs have LANGUAGE(COBOL)
            expected_cobol_programs = [
                "COADM01C", "COBIL00C", "COMEN01C", "CORPT00C",
                "COTRN00C", "COTRN01C", "COTRN02C",
                "COUSR00C", "COUSR01C", "COUSR02C", "COUSR03C"
            ]
            
            assert len(programs_with_language) == len(expected_cobol_programs)
            
            for prog in programs_with_language:
                assert prog.resource_name in expected_cobol_programs
                assert prog.language == "COBOL"
    
    def test_to_csv_basic(self):
        """Test converting CSD data to CSV format."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
 DESCRIPTION(CREDIT CARD DEMO ACCOUNT UPDATE)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS) STATUS(ENABLED)
 DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
 DESCRIPTION(CREDIT CARD ACCOUNT UPDATE MAP)
        STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        # Write to temporary file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            csv_file = f.name
        
        try:
            self.parser.to_csv(csd_data, csv_file)
            
            # Read and verify CSV
            with open(csv_file, 'r') as f:
                lines = f.readlines()
            
            # Should have header + 4 resources
            assert len(lines) == 5
            
            # Check header
            assert 'resource_name' in lines[0]
            assert 'resource_type' in lines[0]
            assert 'program_name' in lines[0]
            assert 'dataset_name' in lines[0]
            
            # Check transaction row
            assert 'CAUP' in lines[1]
            assert 'TRANSACTION' in lines[1]
            assert 'COACTUPC' in lines[1]
            
            # Check file row
            file_line = [l for l in lines if 'ACCTDAT' in l][0]
            assert 'FILE' in file_line
            assert 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS' in file_line
        finally:
            os.unlink(csv_file)
    
    def test_to_csv_no_header(self):
        """Test CSV generation without header."""
        csd_content = """
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            csv_file = f.name
        
        try:
            self.parser.to_csv(csd_data, csv_file, include_header=False)
            
            with open(csv_file, 'r') as f:
                lines = f.readlines()
            
            # Should have only 1 line (no header)
            assert len(lines) == 1
            assert 'resource_name' not in lines[0]
        finally:
            os.unlink(csv_file)
    
    def test_parse_transactions_only(self):
        """Test parse_transactions method."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        transactions = self.parser.parse_transactions(csd_content)
        
        assert len(transactions) == 1
        assert transactions[0].resource_name == "CAUP"
    
    def test_parse_programs_only(self):
        """Test parse_programs method."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        programs = self.parser.parse_programs(csd_content)
        
        assert len(programs) == 1
        assert programs[0].resource_name == "COACTUPC"
    
    def test_parse_files_only(self):
        """Test parse_files method."""
        csd_content = """
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS) STATUS(ENABLED)
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        files = self.parser.parse_files(csd_content)
        
        assert len(files) == 1
        assert files[0].resource_name == "ACCTDAT"
    
    def test_parse_mapsets_only(self):
        """Test parse_mapsets method."""
        csd_content = """
 DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
        STATUS(ENABLED)
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        mapsets = self.parser.parse_mapsets(csd_content)
        
        assert len(mapsets) == 1
        assert mapsets[0].resource_name == "COACTUP"
    
    def test_parse_empty_content(self):
        """Test parsing empty content."""
        csd_data = self.parser.parse("")
        
        assert len(csd_data.transactions) == 0
        assert len(csd_data.programs) == 0
        assert len(csd_data.files) == 0
        assert len(csd_data.mapsets) == 0
    
    def test_parse_malformed_definition(self):
        """Test that malformed definitions are skipped gracefully."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 THIS IS NOT A VALID DEFINITION
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        
        # Should parse valid definitions and skip invalid ones
        assert len(csd_data.transactions) == 1
        assert len(csd_data.programs) == 1
    
    def test_get_all_resources(self):
        """Test get_all_resources method."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS) STATUS(ENABLED)
 DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
        STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        all_resources = csd_data.get_all_resources()
        
        assert len(all_resources) == 4
        assert any(r.resource_type == "TRANSACTION" for r in all_resources)
        assert any(r.resource_type == "PROGRAM" for r in all_resources)
        assert any(r.resource_type == "FILE" for r in all_resources)
        assert any(r.resource_type == "MAPSET" for r in all_resources)
    
    def test_case_insensitive_parsing(self):
        """Test that parsing is case-insensitive."""
        csd_content = """
 define transaction(CAUP) group(CARDDEMO)
        program(COACTUPC) status(enabled)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.transactions) == 1
        trans = csd_data.transactions[0]
        assert trans.status == "ENABLED"  # Should be normalized to uppercase
    
    def test_parse_file_not_found(self):
        """Test that FileNotFoundError is raised for missing files."""
        with pytest.raises(FileNotFoundError):
            self.parser.parse_file("/nonexistent/file.csd")
    
    def test_source_file_tracking(self):
        """Test that source file and line numbers are tracked."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content, source_file="test.csd")
        
        assert len(csd_data.transactions) == 1
        trans = csd_data.transactions[0]
        assert trans.source_file == "test.csd"
        assert trans.line_number is not None
    
    def test_multiline_attributes_with_whitespace(self):
        """Test parsing attributes that span multiple lines with extra whitespace."""
        csd_content = """
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS) RLSACCESS(NO)
        LSRPOOLNUM(1) READINTEG(UNCOMMITTED) DSNSHARING(ALLREQS)
        STRINGS(1) STATUS(ENABLED) OPENTIME(FIRSTREF)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.files) == 1
        file = csd_data.files[0]
        assert file.resource_name == "ACCTDAT"
        assert file.dataset_name == "AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS"
        assert file.status == "ENABLED"
    
    def test_multiline_description_normalization(self):
        """Test that multi-line descriptions are normalized to single line."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
 DESCRIPTION(CREDIT CARD DEMO ACCOUNT UPDATE)
        PROGRAM(COACTUPC) TWASIZE(0) PROFILE(DFHCICST) STATUS(ENABLED)
        TASKDATALOC(ANY) TASKDATAKEY(USER) STORAGECLEAR(NO)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.transactions) == 1
        trans = csd_data.transactions[0]
        assert trans.description == "CREDIT CARD DEMO ACCOUNT UPDATE"
        assert trans.program_name == "COACTUPC"
        assert trans.status == "ENABLED"
    
    def test_complex_multiline_program_definition(self):
        """Test parsing complex PROGRAM definition with many attributes."""
        csd_content = """
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
 DESCRIPTION(CREDIT CARD DEMO ACCOUNT UPDATE)
        RELOAD(NO) RESIDENT(NO) USAGE(NORMAL) USELPACOPY(NO)
        STATUS(ENABLED) CEDF(YES) DATALOCATION(ANY) EXECKEY(USER)
        CONCURRENCY(QUASIRENT) API(CICSAPI) DYNAMIC(NO)
        EXECUTIONSET(FULLAPI) JVM(NO) DEFINETIME(22/06/10 20:02:51)
        CHANGETIME(22/06/10 20:03:18) CHANGEUSRID(AWSUSER)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.programs) == 1
        prog = csd_data.programs[0]
        assert prog.resource_name == "COACTUPC"
        assert prog.description == "CREDIT CARD DEMO ACCOUNT UPDATE"
        assert prog.status == "ENABLED"
    
    def test_program_with_transid_multiline(self):
        """Test parsing PROGRAM with TRANSID in multi-line definition."""
        csd_content = """
 DEFINE PROGRAM(COACTVWC) GROUP(CARDDEMO)
 DESCRIPTION(VIEW ACCT)
        RELOAD(NO) RESIDENT(NO) USAGE(NORMAL) USELPACOPY(NO)
        STATUS(ENABLED) CEDF(YES) DATALOCATION(ANY) EXECKEY(USER)
        CONCURRENCY(QUASIRENT) API(CICSAPI) DYNAMIC(NO) TRANSID(CAVW)
        EXECUTIONSET(FULLAPI) JVM(NO)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.programs) == 1
        prog = csd_data.programs[0]
        assert prog.resource_name == "COACTVWC"
        assert prog.transaction_id == "CAVW"
        assert prog.description == "VIEW ACCT"
        assert prog.status == "ENABLED"
    
    def test_file_with_description_multiline(self):
        """Test parsing FILE with DESCRIPTION on separate line."""
        csd_content = """
 DEFINE FILE(CCXREF) GROUP(CARDDEMO)
 DESCRIPTION(CARD TO ACCOUNT XREF)
        DSNAME(AWS.M2.CARDDEMO.CARDXREF.VSAM.KSDS) RLSACCESS(NO)
        LSRPOOLNUM(1) READINTEG(UNCOMMITTED) DSNSHARING(ALLREQS)
        STRINGS(1) STATUS(ENABLED) OPENTIME(FIRSTREF)
"""
        csd_data = self.parser.parse(csd_content)
        
        assert len(csd_data.files) == 1
        file = csd_data.files[0]
        assert file.resource_name == "CCXREF"
        assert file.description == "CARD TO ACCOUNT XREF"
        assert file.dataset_name == "AWS.M2.CARDDEMO.CARDXREF.VSAM.KSDS"
        assert file.status == "ENABLED"
    
    def test_parse_file_io_error(self):
        """Test that IOError is raised for unreadable files."""
        # Try to read a directory as a file
        with pytest.raises(IOError):
            self.parser.parse_file("tests/")
    
    def test_parse_empty_file(self):
        """Test parsing an empty file returns empty CSDData."""
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csd') as f:
            csd_file = f.name
            f.write("")
        
        try:
            csd_data = self.parser.parse_file(csd_file)
            assert len(csd_data.get_all_resources()) == 0
        finally:
            os.unlink(csd_file)
    
    def test_validate_csd_data_no_issues(self):
        """Test validation with clean data."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        issues = self.parser.validate_csd_data(csd_data)
        
        assert len(issues['errors']) == 0
        assert len(issues['warnings']) == 0
        assert len(issues['info']) > 0
    
    def test_validate_csd_data_duplicate_resources(self):
        """Test validation detects duplicate resource names."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        issues = self.parser.validate_csd_data(csd_data)
        
        assert len(issues['warnings']) >= 2
        assert any('Duplicate transaction ID: CAUP' in w for w in issues['warnings'])
        assert any('Duplicate program name: TESTPROG' in w for w in issues['warnings'])
    
    def test_validate_csd_data_transaction_without_program(self):
        """Test validation detects transactions without programs."""
        csd_content = """
 DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
        STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        issues = self.parser.validate_csd_data(csd_data)
        
        assert len(issues['warnings']) >= 1
        assert any('has no program defined' in w for w in issues['warnings'])
    
    def test_validate_csd_data_file_without_dataset(self):
        """Test validation detects files without dataset names."""
        csd_content = """
 DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
        STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        issues = self.parser.validate_csd_data(csd_data)
        
        assert len(issues['warnings']) >= 1
        assert any('has no dataset name defined' in w for w in issues['warnings'])
    
    def test_validate_csd_data_long_transaction_id(self):
        """Test validation detects transaction IDs exceeding 4 characters."""
        csd_content = """
 DEFINE TRANSACTION(TOOLONG) GROUP(CARDDEMO)
        PROGRAM(COACTUPC) STATUS(ENABLED)
"""
        csd_data = self.parser.parse(csd_content)
        issues = self.parser.validate_csd_data(csd_data)
        
        assert len(issues['warnings']) >= 1
        assert any('exceeds 4 characters' in w for w in issues['warnings'])
    
    def test_to_csv_with_invalid_data(self):
        """Test CSV generation with None data raises ValueError."""
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            csv_file = f.name
        
        try:
            with pytest.raises(ValueError):
                self.parser.to_csv(None, csv_file)
        finally:
            if os.path.exists(csv_file):
                os.unlink(csv_file)
    
    def test_to_csv_with_empty_data(self):
        """Test CSV generation with empty data."""
        csd_data = CSDData()
        
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv') as f:
            csv_file = f.name
        
        try:
            self.parser.to_csv(csd_data, csv_file)
            
            with open(csv_file, 'r') as f:
                lines = f.readlines()
            
            # Should have only header
            assert len(lines) == 1
            assert 'resource_name' in lines[0]
        finally:
            os.unlink(csv_file)
    
    def test_parse_with_invalid_status(self):
        """Test that invalid status values are handled gracefully."""
        csd_content = """
 DEFINE PROGRAM(TESTPROG) GROUP(CARDDEMO)
        LANGUAGE(COBOL) STATUS(INVALID)
"""
        csd_data = self.parser.parse(csd_content)
        
        # Should default to ENABLED
        assert len(csd_data.programs) == 1
        assert csd_data.programs[0].status == "ENABLED"
