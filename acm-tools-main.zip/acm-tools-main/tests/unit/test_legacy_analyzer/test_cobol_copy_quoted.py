"""
Test COBOL parser handling of quoted COPY statements.

This test verifies that the COBOL parser correctly handles COPY statements
with both quoted and unquoted copybook names.
"""

import pytest
from tools.legacy_analyzer.parsers.cobol_parser import COBOLDependencyParser


class TestCOBOLQuotedCopyStatements:
    """Test cases for quoted COPY statement parsing."""
    
    def test_copy_with_single_quotes(self):
        """Test COPY statement with single quotes."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               COPY 'CSSTRPFY'.
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        assert 'CSSTRPFY' in result['copybooks']
    
    def test_copy_with_double_quotes(self):
        """Test COPY statement with double quotes."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               COPY "CSSTRPFY".
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        assert 'CSSTRPFY' in result['copybooks']
    
    def test_copy_without_quotes(self):
        """Test COPY statement without quotes (traditional format)."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               COPY CSSTRPFY.
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        assert 'CSSTRPFY' in result['copybooks']
    
    def test_copy_mixed_quoted_and_unquoted(self):
        """Test multiple COPY statements with mixed quoting styles."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               COPY 'CSSTRPFY'.
               COPY COPYBOOK1.
               COPY "COPYBOOK2".
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        assert 'CSSTRPFY' in result['copybooks']
        assert 'COPYBOOK1' in result['copybooks']
        assert 'COPYBOOK2' in result['copybooks']
    
    def test_copy_with_quotes_and_library(self):
        """Test COPY statement with quotes and library specification."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               COPY 'CSSTRPFY' IN MYLIB.
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        assert 'MYLIB.CSSTRPFY' in result['copybooks']
    
    def test_copy_with_quotes_and_replacing(self):
        """Test COPY statement with quotes and REPLACING clause."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               COPY 'CSSTRPFY' REPLACING ==TAG== BY ==NEWTAG==.
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        assert 'CSSTRPFY' in result['copybooks']
    
    def test_parse_copy_statements_directly(self):
        """Test parse_copy_statements method directly with various formats."""
        parser = COBOLDependencyParser()
        
        # Test with normalized source code
        source = """
        COPY 'CSSTRPFY'.
        COPY "COPYBOOK1".
        COPY COPYBOOK2.
        COPY 'COPYBOOK3' IN MYLIB.
        COPY COPYBOOK4 OF YOURLIB.
        """
        
        normalized = parser._normalize_source(source)
        copybooks = parser.parse_copy_statements(normalized)
        
        assert 'CSSTRPFY' in copybooks
        assert 'COPYBOOK1' in copybooks
        assert 'COPYBOOK2' in copybooks
        assert 'MYLIB.COPYBOOK3' in copybooks
        assert 'YOURLIB.COPYBOOK4' in copybooks
    
    def test_copy_with_hyphens_in_quotes(self):
        """Test COPY statement with hyphens in copybook name."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               COPY 'COPY-BOOK-1'.
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        assert 'COPY-BOOK-1' in result['copybooks']
    
    def test_copy_case_insensitive(self):
        """Test that COPY statement parsing is case-insensitive for the keyword."""
        parser = COBOLDependencyParser()
        source = """
               IDENTIFICATION DIVISION.
               PROGRAM-ID. TESTPROG.
               DATA DIVISION.
               WORKING-STORAGE SECTION.
               copy 'csstrpfy'.
               Copy "COPYBOOK1".
               COPY copybook2.
               PROCEDURE DIVISION.
               STOP RUN.
        """
        
        result = parser.parse(source)
        # Copybook names preserve their case as written
        assert 'csstrpfy' in result['copybooks']
        assert 'COPYBOOK1' in result['copybooks']
        assert 'copybook2' in result['copybooks']


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
