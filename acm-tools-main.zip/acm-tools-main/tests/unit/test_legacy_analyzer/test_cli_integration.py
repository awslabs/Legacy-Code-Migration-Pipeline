"""Integration tests for CLI commands."""

import pytest
import json
import tempfile
import subprocess
import sys
from pathlib import Path


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    yield db_path
    
    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def sample_cobol_code():
    """Sample COBOL code for testing."""
    return """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTPROG.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-COUNT PIC 9(5) VALUE 0.
       
       PROCEDURE DIVISION.
           IF WS-COUNT > 100
               DISPLAY 'HIGH COUNT'
           ELSE
               DISPLAY 'LOW COUNT'
           END-IF.
           
           PERFORM VARYING WS-COUNT FROM 1 BY 1
               UNTIL WS-COUNT > 10
               DISPLAY WS-COUNT
           END-PERFORM.
           
           STOP RUN.
    """


def run_cli(*args):
    """Run CLI command and return result."""
    cmd = [sys.executable, '-m', 'tools.legacy_analyzer'] + list(args)
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True
    )
    return result


def setup_test_database(db_path, include_cics=False):
    """Set up a test database with proper schema."""
    import sqlite3
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create inventory table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            artifact_name VARCHAR(44) NOT NULL,
            filename VARCHAR(44),
            program_id VARCHAR(44),
            artifact_type VARCHAR(20),
            language VARCHAR(20),
            file_extension VARCHAR(10),
            file_path TEXT NOT NULL UNIQUE,
            file_size INTEGER,
            analyzed INTEGER DEFAULT 0,
            found_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_modified TIMESTAMP
        )
    """)
    
    # Create artifact_dependencies table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS artifact_dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_artifact_name VARCHAR(44) NOT NULL,
            source_artifact_type VARCHAR(20) NOT NULL,
            target_artifact_name VARCHAR(44) NOT NULL,
            target_artifact_type VARCHAR(20) NOT NULL,
            dependency_type VARCHAR(20) NOT NULL,
            source_file_path VARCHAR(255),
            line_number INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create inventory_cics table if requested
    if include_cics:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_cics (
                resource_name VARCHAR(8) PRIMARY KEY,
                resource_type VARCHAR(20),
                group_name VARCHAR(20),
                status VARCHAR(10),
                program_name VARCHAR(44),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20)
            )
        """)
    
    conn.commit()
    conn.close()


class TestFlowCommands:
    """Test flow analysis CLI commands."""
    
    def test_flow_analyze_help(self):
        """Test flow analyze help."""
        result = run_cli('flow', 'analyze', '--help')
        assert result.returncode == 0
        assert 'analyze' in result.stdout.lower()
        assert '--program' in result.stdout
        assert '--db' in result.stdout
    
    def test_flow_graph_help(self):
        """Test flow graph help."""
        result = run_cli('flow', 'graph', '--help')
        assert result.returncode == 0
        assert 'graph' in result.stdout.lower()
        assert '--output' in result.stdout
    
    def test_flow_entry_points_help(self):
        """Test flow entry-points help."""
        result = run_cli('flow', 'entry-points', '--help')
        assert result.returncode == 0
        assert 'entry' in result.stdout.lower()
        assert '--use-metadata' in result.stdout
        assert '--include-disabled' in result.stdout
        assert '--format' in result.stdout
    
    def test_flow_circular_help(self):
        """Test flow circular help."""
        result = run_cli('flow', 'circular', '--help')
        assert result.returncode == 0
        assert 'circular' in result.stdout.lower()
    
    def test_flow_entry_points_basic(self, temp_db):
        """Test basic entry points command without metadata."""
        # Set up database with proper schema
        setup_test_database(temp_db)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG1', 'PROGRAM', '/path/prog1.cbl')")
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG2', 'PROGRAM', '/path/prog2.cbl')")
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type) 
            VALUES ('PROG1', 'PROGRAM', 'PROG2', 'PROGRAM', 'CALL')
        """)
        
        conn.commit()
        conn.close()
        
        # Run entry-points command
        result = run_cli('flow', 'entry-points', '--db', temp_db)
        
        assert result.returncode == 0
        assert 'entry point' in result.stdout.lower()
        assert 'PROG1' in result.stdout  # PROG1 should be an entry point (not called by others)
    
    def test_flow_entry_points_with_metadata(self, temp_db):
        """Test entry points command with --use-metadata flag."""
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')")
        cursor.execute("""
            INSERT INTO inventory_cics VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'TESTPROG', NULL, 'Test Transaction', NULL)
        """)
        
        conn.commit()
        conn.close()
        
        # Run entry-points command with metadata
        result = run_cli('flow', 'entry-points', '--db', temp_db, '--use-metadata')
        
        assert result.returncode == 0
        assert 'TESTPROG' in result.stdout
        assert 'ONLINE' in result.stdout or 'TRANSACTION' in result.stdout
    
    def test_flow_entry_points_with_metadata_json_format(self, temp_db):
        """Test entry points with metadata in JSON format."""
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')")
        cursor.execute("""
            INSERT INTO inventory_cics VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'TESTPROG', NULL, 'Test Transaction', NULL)
        """)
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run entry-points command with JSON format
            result = run_cli(
                'flow', 'entry-points',
                '--db', temp_db,
                '--use-metadata',
                '--format', 'json',
                '--output', output_file
            )
            
            assert result.returncode == 0
            
            # Verify JSON file was created
            assert Path(output_file).exists()
            
            # Verify JSON content
            import json
            with open(output_file) as f:
                data = json.load(f)
            
            assert 'entry_points' in data
            assert 'summary' in data
            assert isinstance(data['entry_points'], list)
            assert len(data['entry_points']) > 0
            
            # Verify entry point has metadata fields
            ep = data['entry_points'][0]
            assert 'program_name' in ep
            assert 'entry_type' in ep
            assert 'confidence' in ep
            assert 'source' in ep
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_flow_entry_points_with_metadata_csv_format(self, temp_db):
        """Test entry points with metadata in CSV format."""
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')")
        cursor.execute("""
            INSERT INTO inventory_cics VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'TESTPROG', NULL, 'Test Transaction', NULL)
        """)
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            output_file = f.name
        
        try:
            # Run entry-points command with CSV format
            result = run_cli(
                'flow', 'entry-points',
                '--db', temp_db,
                '--use-metadata',
                '--format', 'csv',
                '--output', output_file
            )
            
            assert result.returncode == 0
            
            # Verify CSV file was created
            assert Path(output_file).exists()
            
            # Verify CSV content
            csv_content = Path(output_file).read_text()
            assert 'program_name' in csv_content
            assert 'entry_type' in csv_content
            assert 'confidence' in csv_content
            assert 'TESTPROG' in csv_content
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_flow_entry_points_with_metadata_text_format(self, temp_db):
        """Test entry points with metadata in text format (default)."""
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('TESTPROG', 'PROGRAM', '/path/testprog.cbl')")
        cursor.execute("""
            INSERT INTO inventory_cics VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'TESTPROG', NULL, 'Test Transaction', NULL)
        """)
        
        conn.commit()
        conn.close()
        
        # Run entry-points command with text format (default)
        result = run_cli(
            'flow', 'entry-points',
            '--db', temp_db,
            '--use-metadata',
            '--format', 'text'
        )
        
        assert result.returncode == 0
        assert 'TESTPROG' in result.stdout
        assert 'ONLINE' in result.stdout or 'entry point' in result.stdout.lower()
    
    def test_flow_entry_points_include_disabled(self, temp_db):
        """Test entry points with --include-disabled flag."""
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        
        # Insert test data - one enabled, one disabled
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG1', 'PROGRAM', '/path/prog1.cbl')")
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG2', 'PROGRAM', '/path/prog2.cbl')")
        cursor.execute("""
            INSERT INTO inventory_cics VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG1', NULL, 'Enabled Transaction', NULL)
        """)
        cursor.execute("""
            INSERT INTO inventory_cics VALUES 
            ('TST2', 'TRANSACTION', 'TESTGRP', 'DISABLED', 'PROG2', NULL, 'Disabled Transaction', NULL)
        """)
        
        conn.commit()
        conn.close()
        
        # Run without --include-disabled (should only show enabled)
        result1 = run_cli(
            'flow', 'entry-points',
            '--db', temp_db,
            '--use-metadata'
        )
        
        assert result1.returncode == 0
        assert 'PROG1' in result1.stdout
        # PROG2 should not be in output (disabled)
        
        # Run with --include-disabled (should show both)
        result2 = run_cli(
            'flow', 'entry-points',
            '--db', temp_db,
            '--use-metadata',
            '--include-disabled'
        )
        
        assert result2.returncode == 0
        assert 'PROG1' in result2.stdout
        assert 'PROG2' in result2.stdout
    
    def test_flow_entry_points_without_metadata_fallback(self, temp_db):
        """Test that command falls back to code analysis when no metadata exists."""
        # Set up database without CICS metadata
        setup_test_database(temp_db, include_cics=False)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG1', 'PROGRAM', '/path/prog1.cbl')")
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG2', 'PROGRAM', '/path/prog2.cbl')")
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type) 
            VALUES ('PROG1', 'PROGRAM', 'PROG2', 'PROGRAM', 'CALL')
        """)
        
        conn.commit()
        conn.close()
        
        # Run with --use-metadata (should fall back gracefully)
        result = run_cli(
            'flow', 'entry-points',
            '--db', temp_db,
            '--use-metadata'
        )
        
        # Should complete successfully even without metadata
        assert result.returncode == 0
        assert 'PROG1' in result.stdout  # Should still find entry points from code analysis
    
    def test_flow_entry_points_mixed_sources(self, temp_db):
        """Test entry points from multiple sources (CICS, JCL, inferred)."""
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # ONLINE entry point (CICS transaction)
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('ONLINEPROG', 'PROGRAM', '/path/online.cbl')")
        cursor.execute("""
            INSERT INTO inventory_cics VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'ONLINEPROG', NULL, 'Online Transaction', NULL)
        """)
        
        # BATCH entry point (called by JCL)
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('BATCHPROG', 'PROGRAM', '/path/batch.cbl')")
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('TESTJCL', 'JCL', '/path/test.jcl')")
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type) 
            VALUES ('TESTJCL', 'JCL', 'BATCHPROG', 'PROGRAM', 'EXEC_PGM')
        """)
        
        # INFERRED entry point (not called by anything)
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('UTILPROG', 'PROGRAM', '/path/util.cbl')")
        
        conn.commit()
        conn.close()
        
        # Run with metadata
        result = run_cli(
            'flow', 'entry-points',
            '--db', temp_db,
            '--use-metadata'
        )
        
        assert result.returncode == 0
        # Should find ONLINE and INFERRED types
        # Note: BATCH detection requires source_type column which may not be present in all databases
        assert 'ONLINEPROG' in result.stdout
        assert 'UTILPROG' in result.stdout
        # BATCHPROG may be detected as INFERRED if BATCH detection fails
        assert 'TESTJCL' in result.stdout or 'BATCHPROG' in result.stdout
    
    def test_flow_entry_points_summary_statistics(self, temp_db):
        """Test that summary statistics are displayed."""
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        
        # Insert multiple entry points
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        for i in range(3):
            cursor.execute(f"INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG{i}', 'PROGRAM', '/path/prog{i}.cbl')")
            cursor.execute(f"""
                INSERT INTO inventory_cics VALUES 
                ('TST{i}', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG{i}', NULL, 'Transaction {i}', NULL)
            """)
        
        conn.commit()
        conn.close()
        
        # Run with metadata
        result = run_cli(
            'flow', 'entry-points',
            '--db', temp_db,
            '--use-metadata'
        )
        
        assert result.returncode == 0
        # Should show summary statistics
        assert 'summary' in result.stdout.lower() or 'total' in result.stdout.lower()
        assert '3' in result.stdout  # Should show count
    
    def test_flow_entry_points_invalid_format(self, temp_db):
        """Test error handling with invalid format option."""
        result = run_cli(
            'flow', 'entry-points',
            '--db', temp_db,
            '--format', 'invalid'
        )
        
        # Should fail with invalid format
        assert result.returncode != 0
    
    def test_flow_entry_points_missing_db(self):
        """Test error when database file is missing."""
        result = run_cli(
            'flow', 'entry-points',
            '--db', '/nonexistent/database.db'
        )
        
        assert result.returncode != 0
    
    def test_flow_entry_points_output_file_creation(self, temp_db):
        """Test that output file is created correctly."""
        # Set up database
        setup_test_database(temp_db)
        
        # Insert test data
        import sqlite3
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("INSERT INTO inventory (artifact_name, artifact_type, file_path) VALUES ('PROG1', 'PROGRAM', '/path/prog1.cbl')")
        
        conn.commit()
        conn.close()
        
        # Create output file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run command with output file
            result = run_cli(
                'flow', 'entry-points',
                '--db', temp_db,
                '--output', output_file
            )
            
            assert result.returncode == 0
            assert Path(output_file).exists()
            
            # Verify file has content
            content = Path(output_file).read_text()
            assert len(content) > 0
        
        finally:
            Path(output_file).unlink(missing_ok=True)


class TestComplexityCommands:
    """Test complexity analysis CLI commands."""
    
    @pytest.mark.skip(reason="CLI refactored - complexity command no longer exists as separate command")
    def test_complexity_analyze_help(self):
        """Test complexity analyze help."""
        result = run_cli('complexity', 'analyze', '--help')
        assert result.returncode == 0
        assert 'analyze' in result.stdout.lower()
        assert '--source-dir' in result.stdout
        assert '--db' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - complexity command no longer exists as separate command")
    def test_complexity_report_help(self):
        """Test complexity report help."""
        result = run_cli('complexity', 'report', '--help')
        assert result.returncode == 0
        assert 'report' in result.stdout.lower()
        assert '--db' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - complexity command no longer exists as separate command")
    def test_complexity_summary_help(self):
        """Test complexity summary help."""
        result = run_cli('complexity', 'summary', '--help')
        assert result.returncode == 0
        assert 'summary' in result.stdout.lower()


class TestMissingCommands:
    """Test missing code detection CLI commands."""
    
    @pytest.mark.skip(reason="CLI refactored - missing command no longer exists as separate command")
    def test_missing_detect_help(self):
        """Test missing detect help."""
        result = run_cli('missing', 'detect', '--help')
        assert result.returncode == 0
        assert 'detect' in result.stdout.lower()
        assert '--db' in result.stdout
        assert '--type' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - missing command no longer exists as separate command")
    def test_missing_completeness_help(self):
        """Test missing completeness help."""
        result = run_cli('missing', 'completeness', '--help')
        assert result.returncode == 0
        assert 'completeness' in result.stdout.lower()


class TestPackageCommands:
    """Test migration package CLI commands."""
    
    @pytest.mark.skip(reason="CLI refactored - package command no longer exists as separate command")
    def test_package_create_help(self):
        """Test package create help."""
        result = run_cli('package', 'create', '--help')
        assert result.returncode == 0
        assert 'create' in result.stdout.lower()
        assert '--name' in result.stdout
        assert '--seeds' in result.stdout
        assert '--db' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - package command no longer exists as separate command")
    def test_package_validate_help(self):
        """Test package validate help."""
        result = run_cli('package', 'validate', '--help')
        assert result.returncode == 0
        assert 'validate' in result.stdout.lower()
        assert '--package' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - package command no longer exists as separate command")
    def test_package_list_help(self):
        """Test package list help."""
        result = run_cli('package', 'list', '--help')
        assert result.returncode == 0
        assert 'list' in result.stdout.lower()


class TestReportCommands:
    """Test report generation CLI commands."""
    
    @pytest.mark.skip(reason="CLI refactored - report command no longer exists as separate command")
    def test_report_executive_help(self):
        """Test report executive help."""
        result = run_cli('report', 'executive', '--help')
        assert result.returncode == 0
        assert 'executive' in result.stdout.lower()
        assert '--db' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - report command no longer exists as separate command")
    def test_report_artifact_help(self):
        """Test report artifact help."""
        result = run_cli('report', 'artifact', '--help')
        assert result.returncode == 0
        assert 'artifact' in result.stdout.lower()
        assert '--name' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - report command no longer exists as separate command")
    def test_report_package_help(self):
        """Test report package help."""
        result = run_cli('report', 'package', '--help')
        assert result.returncode == 0
        assert 'package' in result.stdout.lower()


class TestCommandCombinations:
    """Test command combinations and workflows."""
    
    def test_main_help(self):
        """Test main help command."""
        result = run_cli('--help')
        assert result.returncode == 0
        assert 'legacy analyzer' in result.stdout.lower()
        assert 'flow' in result.stdout or 'analyze' in result.stdout
    
    def test_flow_help(self):
        """Test flow help command."""
        result = run_cli('flow', '--help')
        assert result.returncode == 0
        assert 'flow' in result.stdout.lower()
    
    @pytest.mark.skip(reason="CLI refactored - complexity command no longer exists as separate command")
    def test_complexity_help(self):
        """Test complexity help command."""
        result = run_cli('complexity', '--help')
        assert result.returncode == 0
        assert 'complexity' in result.stdout.lower()
        assert 'analyze' in result.stdout
        assert 'report' in result.stdout
        assert 'summary' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - missing command no longer exists as separate command")
    def test_missing_help(self):
        """Test missing help command."""
        result = run_cli('missing', '--help')
        assert result.returncode == 0
        assert 'missing' in result.stdout.lower()
    
    @pytest.mark.skip(reason="CLI refactored - package command no longer exists as separate command")
    def test_package_help(self):
        """Test package help command."""
        result = run_cli('package', '--help')
        assert result.returncode == 0
        assert 'package' in result.stdout.lower()
        assert 'create' in result.stdout
        assert 'validate' in result.stdout
        assert 'list' in result.stdout
    
    @pytest.mark.skip(reason="CLI refactored - report command no longer exists as separate command")
    def test_report_help(self):
        """Test report help command."""
        result = run_cli('report', '--help')
        assert result.returncode == 0
        assert 'report' in result.stdout.lower()
        assert 'executive' in result.stdout
        assert 'artifact' in result.stdout
        assert 'package' in result.stdout


class TestErrorHandling:
    """Test error handling in CLI commands."""
    
    @pytest.mark.skip(reason="CLI refactored - flow analyze command structure changed")
    def test_missing_required_argument(self):
        """Test error when required argument is missing."""
        result = run_cli('flow', 'analyze', '--db', 'test.db')
        assert result.returncode != 0
        # Should fail because --program is required
    
    def test_invalid_database_path(self):
        """Test error with invalid database path."""
        result = run_cli('flow', 'entry-points', '--db', '/nonexistent/path/db.db')
        assert result.returncode != 0
    
    def test_invalid_command(self):
        """Test error with invalid command."""
        result = run_cli('invalid-command')
        assert result.returncode != 0
    
    def test_invalid_subcommand(self):
        """Test error with invalid subcommand."""
        result = run_cli('flow', 'invalid-subcommand')
        assert result.returncode != 0


class TestComplexityAnalyzeIntegration:
    """Integration test for complexity analyze command."""
    
    @pytest.mark.skip(reason="CLI refactored - complexity command no longer exists as separate command")
    def test_complexity_analyze_with_source(self, temp_db, sample_cobol_code):
        """Test complexity analyze with actual source code."""
        # Create temporary source directory
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Write sample COBOL file
            cobol_file = source_dir / "TESTPROG.cbl"
            cobol_file.write_text(sample_cobol_code)
            
            # Run complexity analyze
            result = run_cli(
                'complexity', 'analyze',
                '--source-dir', str(source_dir),
                '--language', 'COBOL',
                '--db', temp_db
            )
            
            # Check result
            assert result.returncode == 0
            assert 'analyzed' in result.stdout.lower() or 'complete' in result.stdout.lower()


class TestPackageCreateIntegration:
    """Integration test for package create command."""
    
    @pytest.mark.skip(reason="CLI refactored - package command no longer exists as separate command")
    def test_package_create_basic(self, temp_db):
        """Test basic package creation."""
        # This test requires a database with dependencies
        # For now, just test that the command runs without crashing
        result = run_cli(
            'package', 'create',
            '--name', 'TestPackage',
            '--seeds', 'PROG1,PROG2',
            '--db', temp_db,
            '--no-transitive'
        )
        
        # May fail due to missing data, but should not crash
        # Just verify the command structure is correct
        assert 'package' in result.stdout.lower() or 'error' in result.stdout.lower()


class TestOutputFormats:
    """Test different output formats."""
    
    def test_json_output_format(self, temp_db):
        """Test JSON output format."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            # Run command with JSON output
            result = run_cli(
                'flow', 'entry-points',
                '--db', temp_db,
                '--output', output_file
            )
            
            # Check if output file was created
            if result.returncode == 0 and Path(output_file).exists():
                # Verify it's valid JSON
                with open(output_file) as f:
                    data = json.load(f)
                    assert isinstance(data, dict)
        
        finally:
            Path(output_file).unlink(missing_ok=True)


class TestLoadCommands:
    """Test inventory load CLI commands."""
    
    def test_load_help(self):
        """Test load help command."""
        result = run_cli('load', '--help')
        assert result.returncode == 0
        assert 'load' in result.stdout.lower()
        assert '--type' in result.stdout
        assert '--file' in result.stdout
        assert '--db' in result.stdout
        assert 'cics' in result.stdout
    
    def test_load_missing_required_args(self):
        """Test error when required arguments are missing."""
        # Missing --file
        result = run_cli('load', '--type', 'cics', '--db', 'test.db')
        assert result.returncode != 0
        
        # Missing --db
        result = run_cli('load', '--type', 'cics', '--file', 'test.csv')
        assert result.returncode != 0
        
        # Missing --type
        result = run_cli('load', '--file', 'test.csv', '--db', 'test.db')
        assert result.returncode != 0
    
    def test_load_cics_old_format(self):
        """Test loading CICS inventory with old CSV format (backward compatibility)."""
        # Old format: only required columns (resource_name, resource_type, group_name, status, program_name)
        old_format_csv = """resource_name,resource_type,group_name,status,program_name
TST1,TRANSACTION,TESTGRP,ENABLED,TESTPROG
TST2,TRANSACTION,TESTGRP,ENABLED,TESTPROG2
TESTPROG,PROGRAM,TESTGRP,ENABLED,
TESTPROG2,PROGRAM,TESTGRP,ENABLED,
TESTFILE,FILE,TESTGRP,ENABLED,
TESTMAP,MAPSET,TESTGRP,ENABLED,
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create CSV file
            csv_file = Path(temp_dir) / 'cics_old_format.csv'
            csv_file.write_text(old_format_csv)
            
            # Create database file
            db_file = Path(temp_dir) / 'test.db'
            
            # Run load command
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(csv_file),
                '--db', str(db_file)
            )
            
            # Check result
            assert result.returncode == 0
            assert 'loading' in result.stdout.lower()
            assert 'cics' in result.stdout.lower()
            
            # Verify database was created
            assert db_file.exists()
            
            # Verify data was loaded
            import sqlite3
            conn = sqlite3.connect(str(db_file))
            cursor = conn.cursor()
            
            # Check that records were inserted
            cursor.execute("SELECT COUNT(*) FROM inventory_cics")
            count = cursor.fetchone()[0]
            assert count == 6  # 2 transactions + 2 programs + 1 file + 1 mapset
            
            # Verify old format columns are present
            cursor.execute("SELECT resource_name, resource_type, group_name, status, program_name FROM inventory_cics WHERE resource_name='TST1'")
            row = cursor.fetchone()
            assert row[0] == 'TST1'
            assert row[1] == 'TRANSACTION'
            assert row[2] == 'TESTGRP'
            assert row[3] == 'ENABLED'
            assert row[4] == 'TESTPROG'
            
            # Verify new columns are NULL for old format
            cursor.execute("SELECT dataset_name, description, language FROM inventory_cics WHERE resource_name='TST1'")
            row = cursor.fetchone()
            assert row[0] is None  # dataset_name
            assert row[1] is None  # description
            assert row[2] is None  # language
            
            conn.close()
    
    def test_load_cics_enhanced_format(self):
        """Test loading CICS inventory with enhanced CSV format (new columns)."""
        # Enhanced format: includes dataset_name, description, language
        enhanced_format_csv = """resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
TST1,TRANSACTION,TESTGRP,ENABLED,TESTPROG,,Test Transaction 1,
TST2,TRANSACTION,TESTGRP,ENABLED,TESTPROG2,,Test Transaction 2,
TESTPROG,PROGRAM,TESTGRP,ENABLED,,,Test Program 1,COBOL
TESTPROG2,PROGRAM,TESTGRP,ENABLED,,,Test Program 2,PLI
TESTFILE,FILE,TESTGRP,ENABLED,,TEST.DATA.FILE,Test Data File,
TESTMAP,MAPSET,TESTGRP,ENABLED,,,Test Map,
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create CSV file
            csv_file = Path(temp_dir) / 'cics_enhanced_format.csv'
            csv_file.write_text(enhanced_format_csv)
            
            # Create database file
            db_file = Path(temp_dir) / 'test.db'
            
            # Run load command
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(csv_file),
                '--db', str(db_file)
            )
            
            # Check result
            assert result.returncode == 0
            assert 'loading' in result.stdout.lower()
            assert 'cics' in result.stdout.lower()
            
            # Verify database was created
            assert db_file.exists()
            
            # Verify data was loaded
            import sqlite3
            conn = sqlite3.connect(str(db_file))
            cursor = conn.cursor()
            
            # Check that records were inserted
            cursor.execute("SELECT COUNT(*) FROM inventory_cics")
            count = cursor.fetchone()[0]
            assert count == 6
            
            # Verify enhanced columns are populated for TRANSACTION
            cursor.execute("SELECT resource_name, description FROM inventory_cics WHERE resource_name='TST1'")
            row = cursor.fetchone()
            assert row[0] == 'TST1'
            assert row[1] == 'Test Transaction 1'
            
            # Verify enhanced columns are populated for PROGRAM
            cursor.execute("SELECT resource_name, description, language FROM inventory_cics WHERE resource_name='TESTPROG'")
            row = cursor.fetchone()
            assert row[0] == 'TESTPROG'
            assert row[1] == 'Test Program 1'
            assert row[2] == 'COBOL'
            
            # Verify enhanced columns are populated for FILE
            cursor.execute("SELECT resource_name, dataset_name, description FROM inventory_cics WHERE resource_name='TESTFILE'")
            row = cursor.fetchone()
            assert row[0] == 'TESTFILE'
            assert row[1] == 'TEST.DATA.FILE'
            assert row[2] == 'Test Data File'
            
            conn.close()
    
    def test_load_cics_partial_enhanced_format(self):
        """Test loading CICS inventory with partial enhanced format (some new columns)."""
        # Partial enhanced format: only description column added
        partial_format_csv = """resource_name,resource_type,group_name,status,program_name,description
TST1,TRANSACTION,TESTGRP,ENABLED,TESTPROG,Test Transaction
TESTPROG,PROGRAM,TESTGRP,ENABLED,,Test Program
TESTFILE,FILE,TESTGRP,ENABLED,,Test File
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create CSV file
            csv_file = Path(temp_dir) / 'cics_partial_format.csv'
            csv_file.write_text(partial_format_csv)
            
            # Create database file
            db_file = Path(temp_dir) / 'test.db'
            
            # Run load command
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(csv_file),
                '--db', str(db_file)
            )
            
            # Check result
            assert result.returncode == 0
            
            # Verify data was loaded
            import sqlite3
            conn = sqlite3.connect(str(db_file))
            cursor = conn.cursor()
            
            # Verify description is populated
            cursor.execute("SELECT description FROM inventory_cics WHERE resource_name='TST1'")
            row = cursor.fetchone()
            assert row[0] == 'Test Transaction'
            
            # Verify other enhanced columns are NULL
            cursor.execute("SELECT dataset_name, language FROM inventory_cics WHERE resource_name='TESTPROG'")
            row = cursor.fetchone()
            assert row[0] is None  # dataset_name
            assert row[1] is None  # language
            
            conn.close()
    
    def test_load_cics_with_example_data(self):
        """Test loading CICS inventory with actual example data file."""
        # Use the example CSV file if it exists
        example_csv = Path('examples/data/cics_inventory_example.csv')
        
        if example_csv.exists():
            with tempfile.TemporaryDirectory() as temp_dir:
                db_file = Path(temp_dir) / 'test.db'
                
                # Run load command
                result = run_cli(
                    'load',
                    '--type', 'cics',
                    '--file', str(example_csv),
                    '--db', str(db_file)
                )
                
                # Check result
                assert result.returncode == 0
                assert 'loading' in result.stdout.lower()
                
                # Verify database was created
                assert db_file.exists()
                
                # Verify data was loaded
                import sqlite3
                conn = sqlite3.connect(str(db_file))
                cursor = conn.cursor()
                
                # Check that records were inserted
                cursor.execute("SELECT COUNT(*) FROM inventory_cics")
                count = cursor.fetchone()[0]
                assert count > 0
                
                # Verify some specific records from the example file
                cursor.execute("SELECT resource_type, program_name FROM inventory_cics WHERE resource_name='CAUP'")
                row = cursor.fetchone()
                assert row[0] == 'TRANSACTION'
                assert row[1] == 'COACTUPC'
                
                conn.close()
    
    def test_load_cics_invalid_file(self):
        """Test error handling with invalid file path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            db_file = Path(temp_dir) / 'test.db'
            
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', '/nonexistent/file.csv',
                '--db', str(db_file)
            )
            
            assert result.returncode != 0
            assert 'error' in result.stdout.lower() or 'not found' in result.stdout.lower()
    
    def test_load_cics_empty_file(self):
        """Test handling of empty CSV file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create empty CSV file
            csv_file = Path(temp_dir) / 'empty.csv'
            csv_file.write_text('')
            
            db_file = Path(temp_dir) / 'test.db'
            
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(csv_file),
                '--db', str(db_file)
            )
            
            # Should fail validation
            assert result.returncode != 0
    
    def test_load_cics_missing_required_columns(self):
        """Test error handling with missing required columns."""
        # Missing resource_type column
        invalid_csv = """resource_name,group_name,status
TST1,TESTGRP,ENABLED
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            csv_file = Path(temp_dir) / 'invalid.csv'
            csv_file.write_text(invalid_csv)
            
            db_file = Path(temp_dir) / 'test.db'
            
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(csv_file),
                '--db', str(db_file)
            )
            
            # Should fail validation
            assert result.returncode != 0
            assert 'error' in result.stdout.lower() or 'validation' in result.stdout.lower()
    
    def test_load_cics_update_existing_records(self):
        """Test that loading updates existing records."""
        initial_csv = """resource_name,resource_type,group_name,status,program_name,description
TST1,TRANSACTION,TESTGRP,ENABLED,TESTPROG,Initial Description
"""
        
        updated_csv = """resource_name,resource_type,group_name,status,program_name,description
TST1,TRANSACTION,TESTGRP,DISABLED,TESTPROG,Updated Description
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            initial_file = Path(temp_dir) / 'initial.csv'
            initial_file.write_text(initial_csv)
            
            updated_file = Path(temp_dir) / 'updated.csv'
            updated_file.write_text(updated_csv)
            
            db_file = Path(temp_dir) / 'test.db'
            
            # Load initial data
            result1 = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(initial_file),
                '--db', str(db_file)
            )
            assert result1.returncode == 0
            
            # Load updated data
            result2 = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(updated_file),
                '--db', str(db_file)
            )
            assert result2.returncode == 0
            
            # Verify data was updated
            import sqlite3
            conn = sqlite3.connect(str(db_file))
            cursor = conn.cursor()
            
            cursor.execute("SELECT status, program_name, description FROM inventory_cics WHERE resource_name='TST1'")
            row = cursor.fetchone()
            assert row[0] == 'DISABLED'  # Updated status
            assert row[1] == 'TESTPROG'  # program_name stays the same
            assert row[2] == 'Updated Description'  # Updated description
            
            # Verify only one record exists (not duplicated)
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_name='TST1'")
            count = cursor.fetchone()[0]
            assert count == 1
            
            conn.close()
    
    def test_load_cics_multiple_resource_types(self):
        """Test loading CICS inventory with all resource types."""
        multi_type_csv = """resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
TRAN1,TRANSACTION,GRP1,ENABLED,PROG1,,Transaction 1,
TRAN2,TRANSACTION,GRP1,DISABLED,PROG2,,Transaction 2,
PROG1,PROGRAM,GRP1,ENABLED,,,Program 1,COBOL
PROG2,PROGRAM,GRP1,ENABLED,,,Program 2,PLI
FILE1,FILE,GRP1,ENABLED,,DATA.FILE1,File 1,
FILE2,FILE,GRP1,DISABLED,,DATA.FILE2,File 2,
MAP1,MAPSET,GRP1,ENABLED,,,Mapset 1,
MAP2,MAPSET,GRP1,ENABLED,,,Mapset 2,
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            csv_file = Path(temp_dir) / 'multi_type.csv'
            csv_file.write_text(multi_type_csv)
            
            db_file = Path(temp_dir) / 'test.db'
            
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(csv_file),
                '--db', str(db_file)
            )
            
            assert result.returncode == 0
            
            # Verify all resource types were loaded
            import sqlite3
            conn = sqlite3.connect(str(db_file))
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION'")
            assert cursor.fetchone()[0] == 2
            
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_type='PROGRAM'")
            assert cursor.fetchone()[0] == 2
            
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_type='FILE'")
            assert cursor.fetchone()[0] == 2
            
            cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_type='MAPSET'")
            assert cursor.fetchone()[0] == 2
            
            conn.close()
    
    def test_load_cics_with_empty_optional_fields(self):
        """Test loading CICS inventory with empty optional fields."""
        csv_with_empty_fields = """resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
TST1,TRANSACTION,TESTGRP,ENABLED,TESTPROG,,,
TESTPROG,PROGRAM,TESTGRP,ENABLED,,,,
TESTFILE,FILE,TESTGRP,ENABLED,,,,
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            csv_file = Path(temp_dir) / 'empty_fields.csv'
            csv_file.write_text(csv_with_empty_fields)
            
            db_file = Path(temp_dir) / 'test.db'
            
            result = run_cli(
                'load',
                '--type', 'cics',
                '--file', str(csv_file),
                '--db', str(db_file)
            )
            
            assert result.returncode == 0
            
            # Verify empty fields are stored as NULL
            import sqlite3
            conn = sqlite3.connect(str(db_file))
            cursor = conn.cursor()
            
            cursor.execute("SELECT dataset_name, description, language FROM inventory_cics WHERE resource_name='TST1'")
            row = cursor.fetchone()
            assert row[0] is None or row[0] == ''
            assert row[1] is None or row[1] == ''
            assert row[2] is None or row[2] == ''
            
            conn.close()


class TestMetadataCommands:
    """Test CICS metadata integration CLI commands."""
    
    def test_metadata_help(self):
        """Test metadata help command."""
        result = run_cli('metadata', '--help')
        assert result.returncode == 0
        assert 'metadata' in result.stdout.lower()
        assert 'convert-csd' in result.stdout
        assert 'scan' in result.stdout
    
    def test_metadata_convert_csd_help(self):
        """Test metadata convert-csd help."""
        result = run_cli('metadata', 'convert-csd', '--help')
        assert result.returncode == 0
        assert 'convert' in result.stdout.lower()
        assert '--input' in result.stdout
        assert '--output' in result.stdout
        assert '--dry-run' in result.stdout
    
    def test_metadata_convert_csd_missing_input(self):
        """Test error when input file is missing."""
        result = run_cli('metadata', 'convert-csd', '--input', '/nonexistent/file.csd', '--output', 'output.csv')
        assert result.returncode != 0
        assert 'not found' in result.stdout.lower() or 'error' in result.stdout.lower()
    
    def test_metadata_convert_csd_dry_run(self):
        """Test dry-run mode with sample CSD file."""
        # Use the sample CARDDEMO.csd file if it exists
        csd_file = Path('examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd')
        
        if csd_file.exists():
            result = run_cli(
                'metadata', 'convert-csd',
                '--input', str(csd_file),
                '--output', 'dummy.csv',
                '--dry-run'
            )
            
            assert result.returncode == 0
            assert 'parsing' in result.stdout.lower()
            assert 'transactions' in result.stdout.lower() or 'programs' in result.stdout.lower()
            assert 'dry run' in result.stdout.lower()
    
    def test_metadata_convert_csd_actual_conversion(self):
        """Test actual CSD to CSV conversion."""
        # Use the sample CARDDEMO.csd file if it exists
        csd_file = Path('examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd')
        
        if csd_file.exists():
            with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
                output_file = f.name
            
            try:
                result = run_cli(
                    'metadata', 'convert-csd',
                    '--input', str(csd_file),
                    '--output', output_file
                )
                
                assert result.returncode == 0
                assert 'completed' in result.stdout.lower() or 'success' in result.stdout.lower()
                
                # Verify CSV file was created
                assert Path(output_file).exists()
                
                # Verify CSV has content
                csv_content = Path(output_file).read_text()
                assert len(csv_content) > 0
                assert 'resource_name' in csv_content  # CSV header
                
            finally:
                Path(output_file).unlink(missing_ok=True)
    
    def test_metadata_convert_csd_with_sample_data(self):
        """Test CSD conversion with inline sample data."""
        # Create a minimal CSD file for testing
        sample_csd = """DEFINE TRANSACTION(TST1) GROUP(TESTGRP)
  PROGRAM(TESTPROG)
  STATUS(ENABLED)
  DESCRIPTION(Test Transaction)

DEFINE PROGRAM(TESTPROG) GROUP(TESTGRP)
  LANGUAGE(COBOL)
  STATUS(ENABLED)

DEFINE FILE(TESTFILE) GROUP(TESTGRP)
  DSNAME(TEST.DATA.FILE)
  STATUS(ENABLED)
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csd', delete=False) as f:
            csd_file = f.name
            f.write(sample_csd)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            output_file = f.name
        
        try:
            result = run_cli(
                'metadata', 'convert-csd',
                '--input', csd_file,
                '--output', output_file
            )
            
            assert result.returncode == 0
            
            # Verify CSV file was created and has expected content
            if Path(output_file).exists():
                csv_content = Path(output_file).read_text()
                assert 'TST1' in csv_content or 'TESTPROG' in csv_content
                assert 'TRANSACTION' in csv_content or 'PROGRAM' in csv_content
        
        finally:
            Path(csd_file).unlink(missing_ok=True)
            Path(output_file).unlink(missing_ok=True)
    
    def test_metadata_convert_csd_summary_statistics(self):
        """Test that summary statistics are displayed."""
        # Create a CSD file with multiple resource types
        sample_csd = """DEFINE TRANSACTION(TST1) GROUP(TESTGRP)
  PROGRAM(PROG1)
  STATUS(ENABLED)

DEFINE TRANSACTION(TST2) GROUP(TESTGRP)
  PROGRAM(PROG2)
  STATUS(ENABLED)

DEFINE PROGRAM(PROG1) GROUP(TESTGRP)
  LANGUAGE(COBOL)
  STATUS(ENABLED)

DEFINE PROGRAM(PROG2) GROUP(TESTGRP)
  LANGUAGE(PLI)
  STATUS(ENABLED)

DEFINE FILE(FILE1) GROUP(TESTGRP)
  DSNAME(TEST.DATA.FILE1)
  STATUS(ENABLED)

DEFINE MAPSET(MAP1) GROUP(TESTGRP)
  STATUS(ENABLED)
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csd', delete=False) as f:
            csd_file = f.name
            f.write(sample_csd)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            output_file = f.name
        
        try:
            result = run_cli(
                'metadata', 'convert-csd',
                '--input', csd_file,
                '--output', output_file
            )
            
            assert result.returncode == 0
            
            # Verify summary statistics are in output
            assert 'transactions' in result.stdout.lower()
            assert 'programs' in result.stdout.lower()
            assert 'files' in result.stdout.lower()
            assert 'mapsets' in result.stdout.lower()
            
            # Verify counts are shown
            assert '2' in result.stdout  # 2 transactions
            assert '1' in result.stdout  # 1 file
        
        finally:
            Path(csd_file).unlink(missing_ok=True)
            Path(output_file).unlink(missing_ok=True)
    
    def test_metadata_convert_csd_output_directory_creation(self):
        """Test that output directory is created if it doesn't exist."""
        sample_csd = """DEFINE TRANSACTION(TST1) GROUP(TESTGRP)
  PROGRAM(TESTPROG)
  STATUS(ENABLED)
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create input file
            csd_file = Path(temp_dir) / 'input.csd'
            csd_file.write_text(sample_csd)
            
            # Output to a subdirectory that doesn't exist yet
            output_file = Path(temp_dir) / 'output' / 'subdir' / 'result.csv'
            
            result = run_cli(
                'metadata', 'convert-csd',
                '--input', str(csd_file),
                '--output', str(output_file)
            )
            
            assert result.returncode == 0
            
            # Verify output directory was created
            assert output_file.parent.exists()
            assert output_file.exists()
    
    def test_metadata_convert_csd_missing_required_args(self):
        """Test error when required arguments are missing."""
        # Missing --output
        result = run_cli('metadata', 'convert-csd', '--input', 'test.csd')
        assert result.returncode != 0
        
        # Missing --input
        result = run_cli('metadata', 'convert-csd', '--output', 'test.csv')
        assert result.returncode != 0
    
    def test_metadata_convert_csd_invalid_csd_format(self):
        """Test handling of invalid CSD file format."""
        # Create a file with invalid CSD content
        invalid_csd = """This is not a valid CSD file
Just some random text
No DEFINE statements here
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csd', delete=False) as f:
            csd_file = f.name
            f.write(invalid_csd)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            output_file = f.name
        
        try:
            result = run_cli(
                'metadata', 'convert-csd',
                '--input', csd_file,
                '--output', output_file
            )
            
            # Should complete but with zero resources
            # The parser should handle this gracefully
            assert result.returncode == 0 or result.returncode == 1
            
            # If successful, verify output shows zero resources
            if result.returncode == 0:
                assert '0' in result.stdout or 'no' in result.stdout.lower()
        
        finally:
            Path(csd_file).unlink(missing_ok=True)
            Path(output_file).unlink(missing_ok=True)
    
    def test_metadata_convert_csd_dry_run_no_file_created(self):
        """Test that dry-run mode doesn't create output file."""
        sample_csd = """DEFINE TRANSACTION(TST1) GROUP(TESTGRP)
  PROGRAM(TESTPROG)
  STATUS(ENABLED)
"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            csd_file = Path(temp_dir) / 'input.csd'
            csd_file.write_text(sample_csd)
            
            output_file = Path(temp_dir) / 'output.csv'
            
            result = run_cli(
                'metadata', 'convert-csd',
                '--input', str(csd_file),
                '--output', str(output_file),
                '--dry-run'
            )
            
            assert result.returncode == 0
            
            # Verify output file was NOT created
            assert not output_file.exists()
            
            # Verify dry-run message is shown
            assert 'dry run' in result.stdout.lower()
            assert 'no file' in result.stdout.lower() or 'not written' in result.stdout.lower() or 'without writing' in result.stdout.lower()
    
    def test_metadata_scan_help(self):
        """Test metadata scan help."""
        result = run_cli('metadata', 'scan', '--help')
        assert result.returncode == 0
        assert 'scan' in result.stdout.lower()
        assert '--source-dir' in result.stdout
        assert '--file-types' in result.stdout
        assert '--convert' in result.stdout
        assert '--output-dir' in result.stdout
        assert '--recursive' in result.stdout
    
    def test_metadata_scan_missing_source_dir(self):
        """Test error when source directory is missing."""
        result = run_cli('metadata', 'scan')
        assert result.returncode != 0
        # Should fail because --source-dir is required
    
    def test_metadata_scan_nonexistent_directory(self):
        """Test error with nonexistent directory."""
        result = run_cli('metadata', 'scan', '--source-dir', '/nonexistent/path')
        assert result.returncode != 0
        assert 'not found' in result.stdout.lower() or 'error' in result.stdout.lower()
    
    def test_metadata_scan_basic(self):
        """Test basic directory scan."""
        # Use the sample CARDDEMO directory if it exists
        source_dir = Path('examples/code/cobol/carddemoV2')
        
        if source_dir.exists():
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir)
            )
            
            assert result.returncode == 0
            assert 'scanning' in result.stdout.lower()
            assert 'scan results' in result.stdout.lower()
            assert 'csd files' in result.stdout.lower()
            assert 'csv files' in result.stdout.lower()
    
    def test_metadata_scan_with_file_types_csd(self):
        """Test scan with file-types filter for CSD only."""
        source_dir = Path('examples/code/cobol/carddemoV2')
        
        if source_dir.exists():
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--file-types', 'csd'
            )
            
            assert result.returncode == 0
            assert 'csd' in result.stdout.lower()
    
    def test_metadata_scan_with_file_types_csv(self):
        """Test scan with file-types filter for CSV only."""
        source_dir = Path('examples/code/cobol/carddemoV2')
        
        if source_dir.exists():
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--file-types', 'csv'
            )
            
            assert result.returncode == 0
            assert 'csv' in result.stdout.lower()
    
    def test_metadata_scan_with_file_types_all(self):
        """Test scan with file-types filter for all types."""
        source_dir = Path('examples/code/cobol/carddemoV2')
        
        if source_dir.exists():
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--file-types', 'all'
            )
            
            assert result.returncode == 0
            assert 'scan results' in result.stdout.lower()
    
    def test_metadata_scan_non_recursive(self):
        """Test non-recursive scan."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create directory structure with CSD files
            source_dir = Path(temp_dir)
            
            # Create CSD file in root
            root_csd = source_dir / 'root.csd'
            root_csd.write_text('DEFINE TRANSACTION(TST1) GROUP(TEST)\n  PROGRAM(PROG1)\n')
            
            # Create subdirectory with CSD file
            subdir = source_dir / 'subdir'
            subdir.mkdir()
            sub_csd = subdir / 'sub.csd'
            sub_csd.write_text('DEFINE TRANSACTION(TST2) GROUP(TEST)\n  PROGRAM(PROG2)\n')
            
            # Scan non-recursively
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--no-recursive'
            )
            
            assert result.returncode == 0
            # Should only find root.csd, not sub.csd
            assert 'root.csd' in result.stdout or '1' in result.stdout
    
    def test_metadata_scan_recursive(self):
        """Test recursive scan."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create directory structure with CSD files
            source_dir = Path(temp_dir)
            
            # Create CSD file in root
            root_csd = source_dir / 'root.csd'
            root_csd.write_text('DEFINE TRANSACTION(TST1) GROUP(TEST)\n  PROGRAM(PROG1)\n')
            
            # Create subdirectory with CSD file
            subdir = source_dir / 'subdir'
            subdir.mkdir()
            sub_csd = subdir / 'sub.csd'
            sub_csd.write_text('DEFINE TRANSACTION(TST2) GROUP(TEST)\n  PROGRAM(PROG2)\n')
            
            # Scan recursively (default)
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir)
            )
            
            assert result.returncode == 0
            # Should find both files
            assert '2' in result.stdout or ('root.csd' in result.stdout and 'sub.csd' in result.stdout)
    
    def test_metadata_scan_with_convert(self):
        """Test scan with auto-convert flag."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create a CSD file
            csd_file = source_dir / 'test.csd'
            csd_content = """DEFINE TRANSACTION(TST1) GROUP(TESTGRP)
  PROGRAM(PROG1)
  STATUS(ENABLED)

DEFINE PROGRAM(PROG1) GROUP(TESTGRP)
  LANGUAGE(COBOL)
  STATUS(ENABLED)
"""
            csd_file.write_text(csd_content)
            
            # Scan with convert
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--convert'
            )
            
            assert result.returncode == 0
            assert 'converting' in result.stdout.lower()
            assert 'conversion complete' in result.stdout.lower()
            
            # Verify CSV file was created
            exports_dir = source_dir / 'exports'
            assert exports_dir.exists()
            csv_files = list(exports_dir.glob('*.csv'))
            assert len(csv_files) > 0
    
    def test_metadata_scan_with_convert_and_output_dir(self):
        """Test scan with convert and custom output directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            output_dir = Path(temp_dir) / 'custom_output'
            
            # Create a CSD file
            csd_file = source_dir / 'test.csd'
            csd_content = """DEFINE TRANSACTION(TST1) GROUP(TESTGRP)
  PROGRAM(PROG1)
  STATUS(ENABLED)
"""
            csd_file.write_text(csd_content)
            
            # Scan with convert and custom output dir
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--convert',
                '--output-dir', str(output_dir)
            )
            
            assert result.returncode == 0
            assert 'conversion complete' in result.stdout.lower()
            
            # Verify CSV file was created in custom directory
            assert output_dir.exists()
            csv_files = list(output_dir.glob('*.csv'))
            assert len(csv_files) > 0
    
    def test_metadata_scan_convert_multiple_csd_files(self):
        """Test scan with convert for multiple CSD files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create multiple CSD files
            for i in range(3):
                csd_file = source_dir / f'test{i}.csd'
                csd_content = f"""DEFINE TRANSACTION(TST{i}) GROUP(TESTGRP)
  PROGRAM(PROG{i})
  STATUS(ENABLED)
"""
                csd_file.write_text(csd_content)
            
            # Scan with convert
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--convert'
            )
            
            assert result.returncode == 0
            assert 'conversion complete' in result.stdout.lower()
            
            # Verify all CSV files were created
            exports_dir = source_dir / 'exports'
            csv_files = list(exports_dir.glob('*.csv'))
            assert len(csv_files) == 3
    
    def test_metadata_scan_convert_no_csd_files(self):
        """Test scan with convert when no CSD files exist."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create a non-CSD file
            txt_file = source_dir / 'readme.txt'
            txt_file.write_text('This is not a CSD file')
            
            # Scan with convert
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--convert'
            )
            
            assert result.returncode == 0
            assert 'no csd files' in result.stdout.lower()
    
    def test_metadata_scan_empty_directory(self):
        """Test scan of empty directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', temp_dir
            )
            
            assert result.returncode == 0
            assert '0' in result.stdout or 'no' in result.stdout.lower()
    
    def test_metadata_scan_with_csv_files(self):
        """Test scan that finds CSV files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create CSV files
            csv_file1 = source_dir / 'cics_inventory.csv'
            csv_file1.write_text('resource_name,resource_type,group_name,status\nTST1,TRANSACTION,TEST,ENABLED\n')
            
            csv_file2 = source_dir / 'transactions.csv'
            csv_file2.write_text('transaction_id,program_name\nTST1,PROG1\n')
            
            # Scan
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--file-types', 'csv'
            )
            
            assert result.returncode == 0
            assert 'csv files' in result.stdout.lower()
            assert '2' in result.stdout or 'cics_inventory.csv' in result.stdout
    
    def test_metadata_scan_mixed_files(self):
        """Test scan with mixed CSD and CSV files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create CSD file
            csd_file = source_dir / 'test.csd'
            csd_file.write_text('DEFINE TRANSACTION(TST1) GROUP(TEST)\n  PROGRAM(PROG1)\n')
            
            # Create CSV file
            csv_file = source_dir / 'inventory.csv'
            csv_file.write_text('resource_name,resource_type\nTST1,TRANSACTION\n')
            
            # Scan for all types
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--file-types', 'all'
            )
            
            assert result.returncode == 0
            assert 'csd files' in result.stdout.lower()
            assert 'csv files' in result.stdout.lower()
            # Should find at least one of each
            assert '1' in result.stdout
    
    def test_metadata_scan_displays_relative_paths(self):
        """Test that scan displays relative paths."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create subdirectory with CSD file
            subdir = source_dir / 'app' / 'csd'
            subdir.mkdir(parents=True)
            csd_file = subdir / 'test.csd'
            csd_file.write_text('DEFINE TRANSACTION(TST1) GROUP(TEST)\n  PROGRAM(PROG1)\n')
            
            # Scan
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir)
            )
            
            assert result.returncode == 0
            # Should show relative path like "app/csd/test.csd"
            assert 'app' in result.stdout or 'csd' in result.stdout or 'test.csd' in result.stdout
    
    def test_metadata_scan_summary_output(self):
        """Test that scan displays summary statistics."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create files
            csd_file = source_dir / 'test.csd'
            csd_file.write_text('DEFINE TRANSACTION(TST1) GROUP(TEST)\n  PROGRAM(PROG1)\n')
            
            csv_file = source_dir / 'inventory.csv'
            csv_file.write_text('resource_name,resource_type\n')
            
            # Scan
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir)
            )
            
            assert result.returncode == 0
            assert 'scan results' in result.stdout.lower()
            assert 'total' in result.stdout.lower()
            assert 'completed successfully' in result.stdout.lower()
    
    def test_metadata_scan_convert_shows_progress(self):
        """Test that convert shows progress for multiple files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create multiple CSD files
            for i in range(2):
                csd_file = source_dir / f'test{i}.csd'
                csd_content = f"""DEFINE TRANSACTION(TST{i}) GROUP(TESTGRP)
  PROGRAM(PROG{i})
  STATUS(ENABLED)
"""
                csd_file.write_text(csd_content)
            
            # Scan with convert
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--convert'
            )
            
            assert result.returncode == 0
            # Should show progress like [1/2], [2/2]
            assert '[1/' in result.stdout or '[2/' in result.stdout
            assert 'converting' in result.stdout.lower()
    
    def test_metadata_scan_convert_error_handling(self):
        """Test that convert handles errors gracefully."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_dir = Path(temp_dir)
            
            # Create a valid CSD file
            valid_csd = source_dir / 'valid.csd'
            valid_csd.write_text('DEFINE TRANSACTION(TST1) GROUP(TEST)\n  PROGRAM(PROG1)\n')
            
            # Create an invalid CSD file (empty)
            invalid_csd = source_dir / 'invalid.csd'
            invalid_csd.write_text('')
            
            # Scan with convert
            result = run_cli(
                'metadata', 'scan',
                '--source-dir', str(source_dir),
                '--convert'
            )
            
            # Should complete even if one file fails
            assert result.returncode == 0
            assert 'conversion complete' in result.stdout.lower()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])



class TestServiceCommands:
    """Test service grouping analysis CLI commands."""
    
    def test_service_help(self):
        """Test service help command."""
        result = run_cli('service', '--help')
        assert result.returncode == 0
        assert 'candidates' in result.stdout
        assert 'service' in result.stdout.lower()
    
    def test_service_candidates_help(self):
        """Test service candidates help."""
        result = run_cli('service', 'candidates', '--help')
        assert result.returncode == 0
        assert '--db' in result.stdout
        assert '--output' in result.stdout
        assert '--min-confidence' in result.stdout
        assert '--format' in result.stdout
    
    def test_service_candidates_missing_db(self):
        """Test error when database is not specified."""
        result = run_cli('service', 'candidates')
        assert result.returncode != 0
        # Should fail because --db is required
    
    def test_service_candidates_nonexistent_db(self):
        """Test error with nonexistent database."""
        result = run_cli('service', 'candidates', '--db', '/nonexistent/database.db')
        assert result.returncode != 0
        assert 'not found' in result.stdout.lower() or 'error' in result.stdout.lower()
    
    def test_service_candidates_empty_database(self, temp_db):
        """Test service candidates with empty database."""
        # Create empty database with schema
        setup_test_database(temp_db, include_cics=False)
        
        result = run_cli('service', 'candidates', '--db', temp_db)
        
        # Should succeed but find no candidates
        assert result.returncode == 0
        assert 'No service candidates found' in result.stdout or '0' in result.stdout
    
    def test_service_candidates_with_cics_data(self, temp_db):
        """Test service candidates with CICS metadata."""
        import sqlite3
        
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Create inventory_cics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(20),
                status VARCHAR(10) DEFAULT 'ENABLED',
                program_name VARCHAR(44),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20),
                source_file VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Insert sample CICS transactions
        cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG1', 'Test Transaction 1'),
            ('TST2', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG2', 'Test Transaction 2'),
            ('TST3', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG3', 'Test Transaction 3')
        """)
        
        conn.commit()
        conn.close()
        
        result = run_cli('service', 'candidates', '--db', temp_db)
        
        # Should find service candidates
        assert result.returncode == 0
        assert 'service candidate' in result.stdout.lower() or 'TESTGRP' in result.stdout
    
    def test_service_candidates_json_format(self, temp_db):
        """Test service candidates with JSON output format."""
        import sqlite3
        
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Create inventory_cics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(20),
                status VARCHAR(10) DEFAULT 'ENABLED',
                program_name VARCHAR(44),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20),
                source_file VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Insert sample CICS transactions
        cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG1', 'Test Transaction 1'),
            ('TST2', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG2', 'Test Transaction 2')
        """)
        
        conn.commit()
        conn.close()
        
        result = run_cli('service', 'candidates', '--db', temp_db, '--format', 'json')
        
        # Should return valid JSON
        assert result.returncode == 0
        try:
            # Extract JSON from output (may have database connection messages)
            output = result.stdout
            # Find the JSON object (starts with { and ends with })
            json_start = output.find('{')
            json_end = output.rfind('}') + 1
            if json_start >= 0 and json_end > json_start:
                json_str = output[json_start:json_end]
                data = json.loads(json_str)
            else:
                data = json.loads(output)
            assert 'service_candidates' in data
            assert 'summary' in data
        except json.JSONDecodeError as e:
            pytest.fail(f"Output is not valid JSON: {e}\nOutput: {result.stdout}")
    
    def test_service_candidates_with_output_file(self, temp_db):
        """Test service candidates with output file."""
        import sqlite3
        
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Create inventory_cics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(20),
                status VARCHAR(10) DEFAULT 'ENABLED',
                program_name VARCHAR(44),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20),
                source_file VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Insert sample CICS transactions
        cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG1', 'Test Transaction 1')
        """)
        
        conn.commit()
        conn.close()
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            output_file = f.name
        
        try:
            result = run_cli('service', 'candidates', '--db', temp_db, '--output', output_file, '--format', 'json')
            
            assert result.returncode == 0
            assert Path(output_file).exists()
            
            # Verify file content
            with open(output_file, 'r') as f:
                data = json.load(f)
                assert 'service_candidates' in data
        
        finally:
            Path(output_file).unlink(missing_ok=True)
    
    def test_service_candidates_min_confidence_filter(self, temp_db):
        """Test service candidates with min-confidence filter."""
        import sqlite3
        
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Create inventory_cics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(20),
                status VARCHAR(10) DEFAULT 'ENABLED',
                program_name VARCHAR(44),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20),
                source_file VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Insert sample CICS transactions (need at least 3 for HIGH confidence)
        cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG1', 'Test Transaction 1'),
            ('TST2', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG2', 'Test Transaction 2'),
            ('TST3', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG3', 'Test Transaction 3'),
            ('TST4', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG4', 'Test Transaction 4')
        """)
        
        conn.commit()
        conn.close()
        
        # Test with HIGH confidence filter
        result = run_cli('service', 'candidates', '--db', temp_db, '--min-confidence', 'HIGH')
        
        assert result.returncode == 0
        # Should filter results based on confidence
    
    def test_service_candidates_markdown_format(self, temp_db):
        """Test service candidates with markdown output format (default)."""
        import sqlite3
        
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Create inventory_cics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(20),
                status VARCHAR(10) DEFAULT 'ENABLED',
                program_name VARCHAR(44),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20),
                source_file VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Insert sample CICS transactions
        cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG1', 'Test Transaction 1'),
            ('TST2', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG2', 'Test Transaction 2')
        """)
        
        conn.commit()
        conn.close()
        
        result = run_cli('service', 'candidates', '--db', temp_db, '--format', 'markdown')
        
        assert result.returncode == 0
        assert 'SERVICE GROUPING ANALYSIS' in result.stdout
        assert 'SUMMARY STATISTICS' in result.stdout
    
    def test_service_candidates_summary_statistics(self, temp_db):
        """Test that summary statistics are displayed."""
        import sqlite3
        
        # Set up database with CICS metadata
        setup_test_database(temp_db, include_cics=True)
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Create inventory_cics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(20),
                status VARCHAR(10) DEFAULT 'ENABLED',
                program_name VARCHAR(44),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20),
                source_file VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Insert sample CICS transactions
        cursor.execute("""
            INSERT INTO inventory_cics 
            (resource_name, resource_type, group_name, status, program_name, description)
            VALUES 
            ('TST1', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG1', 'Test Transaction 1'),
            ('TST2', 'TRANSACTION', 'TESTGRP', 'ENABLED', 'PROG2', 'Test Transaction 2')
        """)
        
        conn.commit()
        conn.close()
        
        result = run_cli('service', 'candidates', '--db', temp_db)
        
        assert result.returncode == 0
        assert 'SUMMARY STATISTICS' in result.stdout
        assert 'By Grouping Strategy' in result.stdout or 'By Confidence Level' in result.stdout
