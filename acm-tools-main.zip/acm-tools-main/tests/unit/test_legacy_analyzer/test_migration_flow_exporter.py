"""
Unit tests for MigrationFlowExporter.

Tests the export functionality for migration flows, including:
- Querying flow data from database
- Formatting JSON output
- Filtering flows
- Exporting to files
"""

import pytest
import sqlite3
import json
import tempfile
import os
from tools.legacy_analyzer.migration import (
    MigrationFlowExporter,
    MigrationFlowSchema
)


def create_program_file_mapping_schema(cursor):
    """
    Helper function to create program_file_mapping and inventory tables
    with the correct schema (file_id foreign key).
    
    This matches the real database schema where program_file_mapping
    has a file_id that references inventory.id.
    """
    # Create inventory table if it doesn't exist
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT NOT NULL
        )
    """)
    
    # Create program_file_mapping table with file_id foreign key
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_id INTEGER NOT NULL,
            program_name TEXT NOT NULL,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT,
            FOREIGN KEY (file_id) REFERENCES inventory(id)
        )
    """)


def insert_program_with_metadata(cursor, program_name, file_path, start_line, end_line, program_type, language):
    """
    Helper function to insert a program with metadata into the database.
    
    This handles the two-step process of:
    1. Inserting into inventory to get file_id
    2. Inserting into program_file_mapping with the file_id
    """
    # Insert inventory entry
    cursor.execute("""
        INSERT INTO inventory (file_path)
        VALUES (?)
    """, (file_path,))
    file_id = cursor.lastrowid
    
    # Insert program mapping
    cursor.execute("""
        INSERT INTO program_file_mapping 
        (file_id, program_name, start_line, end_line, program_type, language)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (file_id, program_name, start_line, end_line, program_type, language))
    
    return file_id


@pytest.fixture
def test_db():
    """Create an in-memory test database with schema."""
    conn = sqlite3.connect(':memory:')
    
    # Create schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    yield conn
    
    conn.close()


@pytest.fixture
def populated_db(test_db):
    """Create a database populated with test data."""
    cursor = test_db.cursor()
    
    # Insert test flow 1: PAYROLL1
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            priority, business_domain,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_PAYROLL1', 'Payroll Processing', 'PAYROLL1', 'JCL',
        3, 2, 2,
        2500, 45, 67.5, 'MEDIUM',
        1, 'Finance',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert entry types for PAYROLL1
    cursor.executemany("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, [
        ('FLOW_PAYROLL1', 'JCL', 'PAYROLL01', json.dumps({'jclName': 'PAYROLL01', 'jobName': 'PAYJOB'})),
        ('FLOW_PAYROLL1', 'JCL', 'PAYWEEK', json.dumps({'jclName': 'PAYWEEK', 'jobName': 'WEEKLY'})),
        ('FLOW_PAYROLL1', 'CICS_TRANSACTION', 'PAY1', json.dumps({'transactionId': 'PAY1'}))
    ])
    
    # Insert scope for PAYROLL1
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, [
        ('FLOW_PAYROLL1', 'PROGRAM', 'PAYROLL1'),
        ('FLOW_PAYROLL1', 'PROGRAM', 'PAYCALC'),
        ('FLOW_PAYROLL1', 'PROGRAM', 'PAYDB'),
        ('FLOW_PAYROLL1', 'COPYBOOK', 'PAYCOM'),
        ('FLOW_PAYROLL1', 'COPYBOOK', 'EMPDATA'),
        ('FLOW_PAYROLL1', 'DATASET', 'EMPLOYEE.MASTER'),
        ('FLOW_PAYROLL1', 'DATASET', 'PAYROLL.TRANS')
    ])
    
    # Insert interfaces for PAYROLL1
    cursor.executemany("""
        INSERT INTO flow_interfaces (
            flow_id, direction, interface_type, source, target, external, metadata_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    """, [
        ('FLOW_PAYROLL1', 'INBOUND', 'PROGRAM_CALL', 'EXTERNAL_PROG', 'PAYCALC', 0, 
         json.dumps({'callingProgram': 'EXTERNAL_PROG'})),
        ('FLOW_PAYROLL1', 'OUTBOUND', 'PROGRAM_CALL', 'PAYDB', 'DBUTIL', 1,
         json.dumps({'callingProgram': 'PAYDB'}))
    ])
    
    # Insert data operations for PAYROLL1
    cursor.executemany("""
        INSERT INTO flow_data_operations (
            flow_id, operation_category, operation_type, db_type, target, program, mode
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    """, [
        ('FLOW_PAYROLL1', 'DATABASE', 'SELECT', 'DB2', 'EMPLOYEE_TABLE', 'PAYDB', None),
        ('FLOW_PAYROLL1', 'DATABASE', 'UPDATE', 'DB2', 'PAYROLL_TABLE', 'PAYDB', None),
        ('FLOW_PAYROLL1', 'DATASET', 'ACCESS', None, 'EMPLOYEE.MASTER', 'PAYROLL1', 'INPUT'),
        ('FLOW_PAYROLL1', 'DATASET', 'ACCESS', None, 'PAYROLL.TRANS', 'PAYCALC', 'OUTPUT')
    ])
    
    # Insert test flow 2: BILLING1
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_BILLING1', 'Billing Processing', 'BILLING1', 'CICS_TRANSACTION',
        2, 1, 1,
        1500, 30, 45.0, 'LOW',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert entry types for BILLING1
    cursor.execute("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, ('FLOW_BILLING1', 'CICS_TRANSACTION', 'BILL', json.dumps({'transactionId': 'BILL'})))
    
    # Insert scope for BILLING1
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, [
        ('FLOW_BILLING1', 'PROGRAM', 'BILLING1'),
        ('FLOW_BILLING1', 'PROGRAM', 'BILLCALC'),
        ('FLOW_BILLING1', 'COPYBOOK', 'BILLCOM'),
        ('FLOW_BILLING1', 'DATASET', 'BILLING.MASTER')
    ])
    
    # Insert dependencies
    cursor.executemany("""
        INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
        VALUES (?, ?, ?)
    """, [
        ('FLOW_BILLING1', 'FLOW_PAYROLL1', 'REQUIRED')
    ])
    
    # Insert test flow 3: HIGH complexity flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            business_domain,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_ACCT1', 'Accounting', 'ACCT1', 'JCL',
        5, 3, 4,
        5000, 80, 85.0, 'HIGH',
        'Finance',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert entry types for ACCT1
    cursor.execute("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, ('FLOW_ACCT1', 'JCL', 'ACCTJOB', json.dumps({'jclName': 'ACCTJOB'})))
    
    # Insert minimal scope for ACCT1
    cursor.execute("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, ('FLOW_ACCT1', 'PROGRAM', 'ACCT1'))
    
    test_db.commit()
    
    return test_db


class TestMigrationFlowExporter:
    """Test MigrationFlowExporter class."""
    
    def test_init(self, test_db):
        """Test exporter initialization."""
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter.db is test_db
        assert exporter.cursor is not None
    
    def test_get_flow_count(self, populated_db):
        """Test getting flow count."""
        exporter = MigrationFlowExporter(populated_db)
        
        count = exporter.get_flow_count()
        
        assert count == 3
    
    def test_get_flow_ids(self, populated_db):
        """Test getting all flow IDs."""
        exporter = MigrationFlowExporter(populated_db)
        
        flow_ids = exporter.get_flow_ids()
        
        assert len(flow_ids) == 3
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_BILLING1' in flow_ids
        assert 'FLOW_ACCT1' in flow_ids
        assert flow_ids == sorted(flow_ids)  # Should be sorted
    
    def test_flow_exists(self, populated_db):
        """Test checking if flow exists."""
        exporter = MigrationFlowExporter(populated_db)
        
        assert exporter.flow_exists('FLOW_PAYROLL1') is True
        assert exporter.flow_exists('FLOW_NONEXISTENT') is False
    
    def test_query_entry_types(self, populated_db):
        """Test querying entry point types."""
        exporter = MigrationFlowExporter(populated_db)
        
        entry_types = exporter._query_entry_types('FLOW_PAYROLL1')
        
        assert len(entry_types) == 2
        
        # Find JCL type
        jcl_type = next(t for t in entry_types if t['type'] == 'JCL')
        assert len(jcl_type['callers']) == 2
        
        # Check callers
        caller_sources = [c['source'] for c in jcl_type['callers']]
        assert 'PAYROLL01' in caller_sources
        assert 'PAYWEEK' in caller_sources
        
        # Check metadata
        payroll01_caller = next(c for c in jcl_type['callers'] if c['source'] == 'PAYROLL01')
        assert 'metadata' in payroll01_caller
        assert payroll01_caller['metadata']['jclName'] == 'PAYROLL01'
        
        # Find CICS type
        cics_type = next(t for t in entry_types if t['type'] == 'CICS_TRANSACTION')
        assert len(cics_type['callers']) == 1
        assert cics_type['callers'][0]['source'] == 'PAY1'
    
    def test_query_entry_types_with_file_metadata(self):
        """Test that file metadata is added to callers when available."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert caller programs with file metadata
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('PAYROLL01', 'jcl/PAYROLL01.jcl', 1, 50, 'MAIN', 'JCL'))
        
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('PAYWEEK', 'jcl/PAYWEEK.jcl', 1, 75, 'MAIN', 'JCL'))
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST', 'Test Flow', 'TESTPROG', 'JCL',
            1, 0, 0, 100, 10, 50.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert entry types with callers
        cursor.executemany("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, [
            ('FLOW_TEST', 'JCL', 'PAYROLL01', json.dumps({'jclName': 'PAYROLL01'})),
            ('FLOW_TEST', 'JCL', 'PAYWEEK', json.dumps({'jclName': 'PAYWEEK'}))
        ])
        
        conn.commit()
        
        # Query entry types
        exporter = MigrationFlowExporter(conn)
        entry_types = exporter._query_entry_types('FLOW_TEST')
        
        # Verify file metadata is added
        assert len(entry_types) == 1
        jcl_type = entry_types[0]
        assert jcl_type['type'] == 'JCL'
        assert len(jcl_type['callers']) == 2
        
        # Check PAYROLL01 caller has file metadata
        payroll01_caller = next(c for c in jcl_type['callers'] if c['source'] == 'PAYROLL01')
        assert 'filePath' in payroll01_caller
        assert payroll01_caller['filePath'] == 'jcl/PAYROLL01.jcl'
        assert 'metadata' in payroll01_caller
        
        # Check PAYWEEK caller has file metadata
        payweek_caller = next(c for c in jcl_type['callers'] if c['source'] == 'PAYWEEK')
        assert 'filePath' in payweek_caller
        assert payweek_caller['filePath'] == 'jcl/PAYWEEK.jcl'
        
        conn.close()
    
    def test_query_entry_types_missing_metadata_graceful(self):
        """Test that missing metadata is handled gracefully."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table (empty - no caller metadata)
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST', 'Test Flow', 'TESTPROG', 'JCL',
            1, 0, 0, 100, 10, 50.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert entry types with callers that have no file metadata
        cursor.executemany("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, [
            ('FLOW_TEST', 'JCL', 'UNKNOWN_JOB1', json.dumps({'jclName': 'UNKNOWN_JOB1'})),
            ('FLOW_TEST', 'JCL', 'UNKNOWN_JOB2', json.dumps({'jclName': 'UNKNOWN_JOB2'}))
        ])
        
        conn.commit()
        
        # Query entry types
        exporter = MigrationFlowExporter(conn)
        entry_types = exporter._query_entry_types('FLOW_TEST')
        
        # Verify export succeeds without file metadata
        assert len(entry_types) == 1
        jcl_type = entry_types[0]
        assert jcl_type['type'] == 'JCL'
        assert len(jcl_type['callers']) == 2
        
        # Check callers don't have filePath field (graceful degradation)
        for caller in jcl_type['callers']:
            assert 'source' in caller
            assert 'metadata' in caller
            assert 'filePath' not in caller  # Should be omitted, not null
        
        conn.close()
    
    def test_query_scope(self, populated_db):
        """Test querying flow scope."""
        exporter = MigrationFlowExporter(populated_db)
        
        scope = exporter._query_scope('FLOW_PAYROLL1')
        
        assert 'programs' in scope
        assert 'copybooks' in scope
        assert 'datasets' in scope
        
        assert len(scope['programs']) == 3
        
        # Programs are now objects with 'name' field
        program_names = [p['name'] for p in scope['programs']]
        assert 'PAYROLL1' in program_names
        assert 'PAYCALC' in program_names
        assert 'PAYDB' in program_names
        
        assert len(scope['copybooks']) == 2
        
        # Copybooks are now objects with 'name' field
        copybook_names = [c['name'] for c in scope['copybooks']]
        assert 'PAYCOM' in copybook_names
        assert 'EMPDATA' in copybook_names
        
        assert len(scope['datasets']) == 2
        assert 'EMPLOYEE.MASTER' in scope['datasets']
        assert 'PAYROLL.TRANS' in scope['datasets']
    
    def test_query_interfaces(self, populated_db):
        """Test querying flow interfaces."""
        exporter = MigrationFlowExporter(populated_db)
        
        interfaces = exporter._query_interfaces('FLOW_PAYROLL1')
        
        assert 'inbound' in interfaces
        assert 'outbound' in interfaces
        
        assert len(interfaces['inbound']) == 1
        inbound = interfaces['inbound'][0]
        assert inbound['type'] == 'PROGRAM_CALL'
        assert inbound['source'] == 'EXTERNAL_PROG'
        assert inbound['target'] == 'PAYCALC'
        assert 'external' not in inbound or inbound['external'] is False
        
        assert len(interfaces['outbound']) == 1
        outbound = interfaces['outbound'][0]
        assert outbound['type'] == 'PROGRAM_CALL'
        assert outbound['source'] == 'PAYDB'
        assert outbound['target'] == 'DBUTIL'
        assert outbound['external'] is True
    
    def test_query_data_operations(self, populated_db):
        """Test querying data operations."""
        exporter = MigrationFlowExporter(populated_db)
        
        data_ops = exporter._query_data_operations('FLOW_PAYROLL1')
        
        assert 'databases' in data_ops
        assert 'datasets' in data_ops
        
        # Check database operations
        assert len(data_ops['databases']) == 2
        
        select_op = next(op for op in data_ops['databases'] if op['operation'] == 'SELECT')
        assert select_op['type'] == 'DB2'
        assert select_op['target'] == 'EMPLOYEE_TABLE'
        assert select_op['program'] == 'PAYDB'
        
        update_op = next(op for op in data_ops['databases'] if op['operation'] == 'UPDATE')
        assert update_op['type'] == 'DB2'
        assert update_op['target'] == 'PAYROLL_TABLE'
        
        # Check dataset operations (consolidated by target)
        assert len(data_ops['datasets']) == 2
        
        emp_ds = next(ds for ds in data_ops['datasets'] if ds['name'] == 'EMPLOYEE.MASTER')
        assert emp_ds['mode'] == 'INPUT'
        assert 'PAYROLL1' in emp_ds['programs']
        
        pay_ds = next(ds for ds in data_ops['datasets'] if ds['name'] == 'PAYROLL.TRANS')
        assert pay_ds['mode'] == 'OUTPUT'
        assert 'PAYCALC' in pay_ds['programs']
    
    def test_query_dependencies(self, populated_db):
        """Test querying flow dependencies with new structure."""
        exporter = MigrationFlowExporter(populated_db)
        
        # BILLING1 depends on PAYROLL1
        deps = exporter._query_dependencies('FLOW_BILLING1')
        
        assert 'requiredFlows' in deps
        assert 'dependentFlows' in deps
        
        # Check new structure - should be list of dicts
        assert len(deps['requiredFlows']) == 1
        assert isinstance(deps['requiredFlows'][0], dict)
        assert deps['requiredFlows'][0]['flowId'] == 'FLOW_PAYROLL1'
        assert deps['requiredFlows'][0]['entryProgram'] == 'PAYROLL1'
        
        # PAYROLL1 has BILLING1 as dependent
        deps = exporter._query_dependencies('FLOW_PAYROLL1')
        
        assert len(deps['dependentFlows']) == 1
        assert isinstance(deps['dependentFlows'][0], dict)
        assert deps['dependentFlows'][0]['flowId'] == 'FLOW_BILLING1'
        assert deps['dependentFlows'][0]['entryProgram'] == 'BILLING1'
    
    def test_query_flow_complete(self, populated_db):
        """Test querying complete flow data."""
        exporter = MigrationFlowExporter(populated_db)
        
        flow = exporter._query_flow('FLOW_PAYROLL1')
        
        assert flow is not None
        assert flow['flowId'] == 'FLOW_PAYROLL1'
        assert flow['name'] == 'Payroll Processing'
        
        # Check entry point
        assert 'entryPoint' in flow
        assert flow['entryPoint']['program'] == 'PAYROLL1'
        assert flow['entryPoint']['primaryType'] == 'JCL'
        assert len(flow['entryPoint']['types']) == 2
        
        # Check scope
        assert 'scope' in flow
        assert len(flow['scope']['programs']) == 3
        
        # Check interfaces
        assert 'interfaces' in flow
        assert len(flow['interfaces']['inbound']) == 1
        assert len(flow['interfaces']['outbound']) == 1
        
        # Check data operations
        assert 'dataOperations' in flow
        assert len(flow['dataOperations']['databases']) == 2
        assert len(flow['dataOperations']['datasets']) == 2
        
        # Check complexity
        assert 'complexity' in flow
        assert flow['complexity']['totalPrograms'] == 3
        assert flow['complexity']['totalLines'] == 2500
        assert flow['complexity']['cyclomaticComplexity'] == 45
        assert flow['complexity']['compositeScore'] == 67.5
        assert flow['complexity']['tier'] == 'MEDIUM'
        
        # Check optional fields
        assert flow['priority'] == 1
        assert flow['businessDomain'] == 'Finance'
        
        # Check dependencies
        assert 'dependencies' in flow
        assert len(flow['dependencies']['dependentFlows']) == 1
    
    def test_query_flow_not_found(self, populated_db):
        """Test querying non-existent flow."""
        exporter = MigrationFlowExporter(populated_db)
        
        flow = exporter._query_flow('FLOW_NONEXISTENT')
        
        assert flow is None
    
    def test_export_flows_specific(self, populated_db):
        """Test exporting specific flows."""
        exporter = MigrationFlowExporter(populated_db)
        
        result = exporter.export_flows(['FLOW_PAYROLL1', 'FLOW_BILLING1'])
        
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_BILLING1' in flow_ids
    
    def test_export_flows_empty_list(self, populated_db):
        """Test exporting with empty flow list."""
        exporter = MigrationFlowExporter(populated_db)
        
        result = exporter.export_flows([])
        
        assert 'flows' in result
        assert len(result['flows']) == 0
    
    def test_export_flows_to_file(self, populated_db):
        """Test exporting flows to file."""
        exporter = MigrationFlowExporter(populated_db)
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_file = f.name
        
        try:
            result = exporter.export_flows(['FLOW_PAYROLL1'], output_file=temp_file)
            
            # Verify file was created
            assert os.path.exists(temp_file)
            
            # Read and verify file content
            with open(temp_file, 'r') as f:
                file_data = json.load(f)
            
            assert 'flows' in file_data
            assert len(file_data['flows']) == 1
            assert file_data['flows'][0]['flowId'] == 'FLOW_PAYROLL1'
            
            # Verify return value matches file content
            assert result == file_data
        
        finally:
            # Clean up
            if os.path.exists(temp_file):
                os.remove(temp_file)
    
    def test_export_all_flows_no_filters(self, populated_db):
        """Test exporting all flows without filters."""
        exporter = MigrationFlowExporter(populated_db)
        
        result = exporter.export_all_flows()
        
        assert 'flows' in result
        assert len(result['flows']) == 3
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_BILLING1' in flow_ids
        assert 'FLOW_ACCT1' in flow_ids
    
    def test_export_all_flows_filter_by_complexity(self, populated_db):
        """Test exporting flows filtered by complexity tier."""
        exporter = MigrationFlowExporter(populated_db)
        
        # Filter for HIGH complexity and above
        result = exporter.export_all_flows(min_complexity='HIGH')
        
        assert 'flows' in result
        assert len(result['flows']) == 1
        assert result['flows'][0]['flowId'] == 'FLOW_ACCT1'
        assert result['flows'][0]['complexity']['tier'] == 'HIGH'
        
        # Filter for MEDIUM complexity and above
        result = exporter.export_all_flows(min_complexity='MEDIUM')
        
        assert len(result['flows']) == 2
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_ACCT1' in flow_ids
    
    def test_export_all_flows_filter_by_business_domain(self, populated_db):
        """Test exporting flows filtered by business domain."""
        exporter = MigrationFlowExporter(populated_db)
        
        result = exporter.export_all_flows(business_domain='Finance')
        
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_ACCT1' in flow_ids
    
    def test_export_all_flows_filter_by_entry_type(self, populated_db):
        """Test exporting flows filtered by entry type."""
        exporter = MigrationFlowExporter(populated_db)
        
        result = exporter.export_all_flows(entry_type='JCL')
        
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_ACCT1' in flow_ids
        
        # Filter for CICS_TRANSACTION
        result = exporter.export_all_flows(entry_type='CICS_TRANSACTION')
        
        assert len(result['flows']) == 2
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids  # Has CICS_TRANSACTION type
        assert 'FLOW_BILLING1' in flow_ids
    
    def test_export_all_flows_combined_filters(self, populated_db):
        """Test exporting flows with multiple filters."""
        exporter = MigrationFlowExporter(populated_db)
        
        result = exporter.export_all_flows(
            min_complexity='MEDIUM',
            business_domain='Finance'
        )
        
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_ACCT1' in flow_ids
    
    def test_format_json(self, populated_db):
        """Test JSON formatting."""
        exporter = MigrationFlowExporter(populated_db)
        
        flows = [
            {'flowId': 'FLOW_TEST1', 'name': 'Test 1'},
            {'flowId': 'FLOW_TEST2', 'name': 'Test 2'}
        ]
        
        result = exporter._format_json(flows)
        
        assert 'flows' in result
        assert result['flows'] == flows
        assert len(result['flows']) == 2
    
    def test_export_handles_missing_flow(self, populated_db):
        """Test that export handles missing flows gracefully."""
        exporter = MigrationFlowExporter(populated_db)
        
        # Try to export mix of existing and non-existing flows
        result = exporter.export_flows(['FLOW_PAYROLL1', 'FLOW_NONEXISTENT', 'FLOW_BILLING1'])
        
        # Should only export the existing flows
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_BILLING1' in flow_ids
        assert 'FLOW_NONEXISTENT' not in flow_ids


if __name__ == '__main__':
    pytest.main([__file__, '-v'])


# Property-Based Tests for Flow Export Enhancement
# Feature: jcl-job-export

from hypothesis import given, settings, strategies as st, HealthCheck


@st.composite
def flow_with_jobs_strategy(draw):
    """Generate a flow with invoking jobs."""
    # Generate flow ID with uppercase letters, digits, and underscores
    flow_id_parts = draw(st.lists(
        st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'),
        min_size=5,
        max_size=20
    ))
    flow_id = ''.join(flow_id_parts)
    
    # Generate entry program name (uppercase letters and digits only)
    entry_program_parts = draw(st.lists(
        st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'),
        min_size=1,
        max_size=8
    ))
    entry_program = ''.join(entry_program_parts)
    
    # Generate job names
    num_jobs = draw(st.integers(min_value=0, max_value=10))
    job_names = []
    for _ in range(num_jobs):
        job_parts = draw(st.lists(
            st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'),
            min_size=1,
            max_size=8
        ))
        job_names.append(''.join(job_parts))
    
    return flow_id, entry_program, list(set(job_names))  # Deduplicate


# Property 19: Flow Export Enhancement
# Feature: jcl-job-export, Property 19: Flow Export Enhancement
# Validates: Requirements 9.1, 9.2
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.function_scoped_fixture
    ]
)
@given(flow_data=flow_with_jobs_strategy())
def test_property_19_flow_export_enhancement(flow_data):
    """
    Property 19: Flow Export Enhancement
    
    For any flow in the enhanced flow export, the flow object should contain
    an invokedByJobs array listing all jobs that invoke that flow's entry point.
    
    This property verifies that:
    - invokedByJobs field is present in exported flows
    - invokedByJobs contains all jobs that invoke the entry point
    - invokedByJobs is an array (possibly empty)
    """
    import tempfile
    import os
    import json
    
    flow_id, entry_program, job_names = flow_data
    
    # Create temporary database
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Insert flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            flow_id, f'Flow {flow_id}', entry_program, 'JCL',
            1, 0, 0, 100, 10, 50.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert entry type
        cursor.execute("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, (flow_id, 'JCL', 'TESTJOB', '{}'))
        
        # Insert scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_id, 'PROGRAM', entry_program))
        
        # Create inventory_jcl table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_jcl (
                name TEXT PRIMARY KEY,
                path TEXT,
                steps TEXT
            )
        """)
        
        # Insert jobs that invoke this entry program
        for job_name in job_names:
            steps = json.dumps([
                {'stepName': 'STEP1', 'program': entry_program}
            ])
            cursor.execute("""
                INSERT INTO inventory_jcl (name, path, steps)
                VALUES (?, ?, ?)
            """, (job_name, f'/path/{job_name}', steps))
        
        conn.commit()
        
        # Export flow
        exporter = MigrationFlowExporter(conn)
        result = exporter.export_flows([flow_id])
        
        # Verify invokedByJobs field exists
        assert 'flows' in result
        assert len(result['flows']) == 1
        
        flow = result['flows'][0]
        assert 'invokedByJobs' in flow, "invokedByJobs field must be present"
        assert isinstance(flow['invokedByJobs'], list), "invokedByJobs must be an array"
        
        # Verify all invoking jobs are listed
        invoked_by = set(flow['invokedByJobs'])
        expected_jobs = set(job_names)
        assert invoked_by == expected_jobs, f"Expected {expected_jobs}, got {invoked_by}"
        
        conn.close()
        
    finally:
        if os.path.exists(db_path):
            os.unlink(db_path)


# Property 20: Flow Export Backward Compatibility
# Feature: jcl-job-export, Property 20: Flow Export Backward Compatibility
# Validates: Requirements 9.4
@settings(
    max_examples=50,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.function_scoped_fixture
    ]
)
@given(flow_id_parts=st.lists(
    st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'),
    min_size=5,
    max_size=20
))
def test_property_20_flow_export_backward_compatibility(flow_id_parts):
    """
    Property 20: Flow Export Backward Compatibility
    
    For any flow in the enhanced export, all fields that existed in the
    original flow export format should still be present with the same structure.
    
    This property verifies that:
    - All original fields are present (flowId, name, entryPoint, scope, etc.)
    - Field structure remains unchanged
    - New invokedByJobs field doesn't break existing structure
    """
    import tempfile
    import os
    
    flow_id = ''.join(flow_id_parts)
    
    # Create temporary database
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Insert minimal flow
        entry_program = 'TESTPROG'
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            flow_id, f'Flow {flow_id}', entry_program, 'JCL',
            1, 0, 0, 100, 10, 50.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert entry type
        cursor.execute("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, (flow_id, 'JCL', 'TESTJOB', '{}'))
        
        # Insert scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_id, 'PROGRAM', entry_program))
        
        # Create inventory_jcl table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_jcl (
                name TEXT PRIMARY KEY,
                path TEXT,
                steps TEXT
            )
        """)
        
        conn.commit()
        
        # Export flow
        exporter = MigrationFlowExporter(conn)
        result = exporter.export_flows([flow_id])
        
        # Verify all original fields are present
        assert 'flows' in result
        assert len(result['flows']) == 1
        
        flow = result['flows'][0]
        
        # Check all required original fields
        required_fields = [
            'flowId',
            'name',
            'entryPoint',
            'scope',
            'interfaces',
            'dataOperations',
            'complexity',
            'dependencies'
        ]
        
        for field in required_fields:
            assert field in flow, f"Original field '{field}' must be present for backward compatibility"
        
        # Check entryPoint structure
        assert 'program' in flow['entryPoint']
        assert 'types' in flow['entryPoint']
        
        # Check scope structure
        assert 'programs' in flow['scope']
        assert 'copybooks' in flow['scope']
        assert 'datasets' in flow['scope']
        
        # Check interfaces structure
        assert 'inbound' in flow['interfaces']
        assert 'outbound' in flow['interfaces']
        
        # Check dataOperations structure
        assert 'databases' in flow['dataOperations']
        assert 'datasets' in flow['dataOperations']
        
        # Check complexity structure
        assert 'totalPrograms' in flow['complexity']
        assert 'totalLines' in flow['complexity']
        assert 'cyclomaticComplexity' in flow['complexity']
        assert 'compositeScore' in flow['complexity']
        assert 'tier' in flow['complexity']
        
        # Check dependencies structure
        assert 'requiredFlows' in flow['dependencies']
        assert 'dependentFlows' in flow['dependencies']
        
        # Verify new field is present but doesn't break structure
        assert 'invokedByJobs' in flow
        assert isinstance(flow['invokedByJobs'], list)
        
        conn.close()
        
    finally:
        if os.path.exists(db_path):
            os.unlink(db_path)


# Unit tests for Task 1: Program Type Classification Helper Methods
# Feature: flow-analysis-enhancements

class TestProgramTypeClassification:
    """Test program type classification helper methods."""
    
    def test_get_standalone_program_types(self):
        """Test getting list of standalone program types."""
        standalone_types = MigrationFlowExporter._get_standalone_program_types()
        
        # Verify expected types are included
        assert 'MAIN' in standalone_types
        assert 'SUBPROGRAM' in standalone_types
        assert 'ENTRY_POINT' in standalone_types
        assert 'CSECT' in standalone_types
        assert 'ROUTINE' in standalone_types
        
        # Verify internal procedure types are NOT included
        assert 'PROCEDURE' not in standalone_types
        assert 'NESTED' not in standalone_types
        assert 'FUNCTION' not in standalone_types
    
    def test_is_standalone_program_main(self, test_db):
        """Test that MAIN programs are identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert MAIN program
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('PAYROLL1', '/src/PAYROLL1.cbl', 1, 500, 'MAIN', 'COBOL'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('PAYROLL1') is True
    
    def test_is_standalone_program_subprogram(self, test_db):
        """Test that SUBPROGRAM programs are identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert SUBPROGRAM
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('UTILITY1', '/src/UTILITY1.cbl', 1, 300, 'SUBPROGRAM', 'COBOL'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('UTILITY1') is True
    
    def test_is_standalone_program_entry_point(self, test_db):
        """Test that ENTRY_POINT programs are identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert ENTRY_POINT
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('ENTRY1', '/src/MULTI.cbl', 100, 200, 'ENTRY_POINT', 'COBOL'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('ENTRY1') is True
    
    def test_is_standalone_program_csect(self, test_db):
        """Test that CSECT programs are identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert CSECT
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('ASMUTIL', '/src/ASMUTIL.asm', 1, 150, 'CSECT', 'ASSEMBLER'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('ASMUTIL') is True
    
    def test_is_standalone_program_routine(self, test_db):
        """Test that ROUTINE programs are identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert ROUTINE
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('ROUTINE1', '/src/ROUTINE1.asm', 1, 100, 'ROUTINE', 'ASSEMBLER'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('ROUTINE1') is True
    
    def test_is_standalone_program_procedure_false(self, test_db):
        """Test that PROCEDURE programs are NOT identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert PROCEDURE (internal procedure)
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('CALC_TAX', '/src/PAYROLL1.cbl', 200, 250, 'PROCEDURE', 'COBOL'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('CALC_TAX') is False
    
    def test_is_standalone_program_nested_false(self, test_db):
        """Test that NESTED programs are NOT identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert NESTED program
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('NESTED1', '/src/MAIN.cbl', 300, 400, 'NESTED', 'COBOL'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('NESTED1') is False
    
    def test_is_standalone_program_function_false(self, test_db):
        """Test that FUNCTION programs are NOT identified as standalone."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert FUNCTION
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('CALC_INTEREST', '/src/BANKING.pli', 150, 200, 'FUNCTION', 'PLI'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        assert exporter._is_standalone_program('CALC_INTEREST') is False
    
    def test_is_standalone_program_no_mapping(self, test_db):
        """Test that programs without mapping are assumed standalone (backward compatibility)."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table but don't insert the program
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        
        # Program not in mapping - should return True for backward compatibility
        assert exporter._is_standalone_program('UNKNOWN_PROG') is True
    
    def test_is_standalone_program_no_table(self, test_db):
        """Test that missing table is handled gracefully (backward compatibility)."""
        # Don't create program_file_mapping table
        
        exporter = MigrationFlowExporter(test_db)
        
        # Table doesn't exist - should return True for backward compatibility
        assert exporter._is_standalone_program('ANY_PROG') is True



# Property-Based Test for Task 1.1: Internal Procedure Exclusion
# Feature: flow-analysis-enhancements

@st.composite
def program_with_type_strategy(draw):
    """Generate a program with a specific type."""
    # Generate program name (uppercase letters and digits)
    name_parts = draw(st.lists(
        st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'),
        min_size=1,
        max_size=8
    ))
    program_name = ''.join(name_parts)
    
    # Generate program type
    all_types = ['MAIN', 'SUBPROGRAM', 'ENTRY_POINT', 'CSECT', 'ROUTINE',
                 'PROCEDURE', 'NESTED', 'FUNCTION']
    program_type = draw(st.sampled_from(all_types))
    
    # Generate file path
    file_path = f'/src/{program_name}.cbl'
    
    # Generate line numbers
    start_line = draw(st.integers(min_value=1, max_value=1000))
    end_line = draw(st.integers(min_value=start_line, max_value=start_line + 1000))
    
    # Generate language
    language = draw(st.sampled_from(['COBOL', 'PLI', 'ASSEMBLER', 'REXX']))
    
    return {
        'program_name': program_name,
        'program_type': program_type,
        'file_path': file_path,
        'start_line': start_line,
        'end_line': end_line,
        'language': language
    }


@st.composite
def flow_with_mixed_programs_strategy(draw):
    """Generate a flow with mixed program types (standalone and internal)."""
    # Generate flow ID
    flow_id_parts = draw(st.lists(
        st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'),
        min_size=5,
        max_size=20
    ))
    flow_id = ''.join(flow_id_parts)
    
    # Generate programs (mix of standalone and internal)
    num_programs = draw(st.integers(min_value=1, max_value=20))
    programs = []
    for _ in range(num_programs):
        program = draw(program_with_type_strategy())
        programs.append(program)
    
    # Deduplicate by program name
    seen_names = set()
    unique_programs = []
    for prog in programs:
        if prog['program_name'] not in seen_names:
            seen_names.add(prog['program_name'])
            unique_programs.append(prog)
    
    return flow_id, unique_programs


# Property 1: Internal Procedure Exclusion
# Feature: flow-analysis-enhancements, Property 1: Internal Procedure Exclusion
# Validates: Requirements 1.1, 1.3, 1.4
@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.function_scoped_fixture
    ]
)
@given(flow_data=flow_with_mixed_programs_strategy())
def test_property_1_internal_procedure_exclusion(flow_data):
    """
    Property 1: Internal Procedure Exclusion
    
    For any flow scope export, all programs in the scope.programs list should
    have program_type values that indicate standalone execution capability
    (MAIN, SUBPROGRAM, ENTRY_POINT, CSECT, ROUTINE), and no programs with
    program_type of PROCEDURE, NESTED, or FUNCTION should appear in the list.
    
    This property verifies that:
    - _is_standalone_program correctly identifies standalone programs
    - _is_standalone_program correctly identifies internal procedures
    - Internal procedures (PROCEDURE, NESTED, FUNCTION) return False
    - Standalone programs (MAIN, SUBPROGRAM, ENTRY_POINT, CSECT, ROUTINE) return True
    """
    import tempfile
    import os
    
    flow_id, programs = flow_data
    
    # Skip if no programs
    if not programs:
        return
    
    # Create temporary database
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert programs
        for program in programs:
            cursor.execute("""
                INSERT INTO program_file_mapping 
                (program_name, file_path, start_line, end_line, program_type, language)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                program['program_name'],
                program['file_path'],
                program['start_line'],
                program['end_line'],
                program['program_type'],
                program['language']
            ))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Define standalone and internal types
        standalone_types = {'MAIN', 'SUBPROGRAM', 'ENTRY_POINT', 'CSECT', 'ROUTINE'}
        internal_types = {'PROCEDURE', 'NESTED', 'FUNCTION'}
        
        # Test each program
        for program in programs:
            program_name = program['program_name']
            program_type = program['program_type']
            
            is_standalone = exporter._is_standalone_program(program_name)
            
            # Verify classification matches expected behavior
            if program_type in standalone_types:
                assert is_standalone is True, \
                    f"Program {program_name} with type {program_type} should be standalone"
            elif program_type in internal_types:
                assert is_standalone is False, \
                    f"Program {program_name} with type {program_type} should NOT be standalone"
            else:
                # Unknown type - should default to standalone for backward compatibility
                assert is_standalone is True, \
                    f"Program {program_name} with unknown type {program_type} should default to standalone"
        
        # Verify that internal procedures are correctly identified
        internal_programs = [p for p in programs if p['program_type'] in internal_types]
        for program in internal_programs:
            assert exporter._is_standalone_program(program['program_name']) is False, \
                f"Internal procedure {program['program_name']} should not be standalone"
        
        # Verify that standalone programs are correctly identified
        standalone_programs = [p for p in programs if p['program_type'] in standalone_types]
        for program in standalone_programs:
            assert exporter._is_standalone_program(program['program_name']) is True, \
                f"Standalone program {program['program_name']} should be standalone"
        
        conn.close()
        
    finally:
        if os.path.exists(db_path):
            os.unlink(db_path)



class TestMetadataEnrichment:
    """Test suite for file metadata enrichment methods."""
    
    def test_enrich_with_file_metadata_success(self):
        """Test successful metadata retrieval from cache."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration_flows schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create inventory table (required for JOIN)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT NOT NULL
            )
        """)
        
        # Create program_file_mapping table with file_id foreign key
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER NOT NULL,
                program_name TEXT NOT NULL,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT,
                FOREIGN KEY (file_id) REFERENCES inventory(id)
            )
        """)
        
        # Insert inventory entry
        cursor.execute("""
            INSERT INTO inventory (file_path)
            VALUES (?)
        """, ('src/cobol/PAYROLL1.cbl',))
        file_id = cursor.lastrowid
        
        # Insert test data
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (file_id, program_name, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (file_id, 'PAYROLL1', 1, 450, 'MAIN', 'COBOL'))
        
        conn.commit()
        
        # Create exporter (should load cache)
        exporter = MigrationFlowExporter(conn)
        
        # Test metadata retrieval
        metadata = exporter._enrich_with_file_metadata('PAYROLL1')
        
        assert metadata is not None
        assert metadata['filePath'] == 'src/cobol/PAYROLL1.cbl'
        assert metadata['startLine'] == 1
        assert metadata['endLine'] == 450
        assert metadata['programType'] == 'MAIN'
        assert metadata['language'] == 'COBOL'
        
        conn.close()
    
    def test_enrich_with_file_metadata_missing_program(self):
        """Test that missing program returns None."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration_flows schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table (empty)
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Test metadata retrieval for non-existent program
        metadata = exporter._enrich_with_file_metadata('NONEXISTENT')
        
        assert metadata is None
        
        conn.close()
    
    def test_enrich_with_file_metadata_field_name_conversion(self):
        """Test field name conversion from snake_case to camelCase."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration_flows schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create inventory table (required for JOIN)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT NOT NULL
            )
        """)
        
        # Create program_file_mapping table with file_id foreign key
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER NOT NULL,
                program_name TEXT NOT NULL,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT,
                FOREIGN KEY (file_id) REFERENCES inventory(id)
            )
        """)
        
        # Insert inventory entry
        cursor.execute("""
            INSERT INTO inventory (file_path)
            VALUES (?)
        """, ('src/test.cbl',))
        file_id = cursor.lastrowid
        
        # Insert test data with snake_case fields
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (file_id, program_name, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (file_id, 'TEST_PROG', 10, 100, 'SUBPROGRAM', 'COBOL'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Test metadata retrieval
        metadata = exporter._enrich_with_file_metadata('TEST_PROG')
        
        # Verify camelCase field names
        assert 'filePath' in metadata
        assert 'startLine' in metadata
        assert 'endLine' in metadata
        assert 'programType' in metadata
        assert 'language' in metadata
        
        # Verify snake_case fields are NOT present
        assert 'file_path' not in metadata
        assert 'start_line' not in metadata
        assert 'end_line' not in metadata
        assert 'program_type' not in metadata
        
        conn.close()
    
    def test_metadata_cache_functionality(self):
        """Test that metadata cache is populated and used."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration_flows schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create inventory table (required for JOIN)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT NOT NULL
            )
        """)
        
        # Create program_file_mapping table with file_id foreign key
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER NOT NULL,
                program_name TEXT NOT NULL,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT,
                FOREIGN KEY (file_id) REFERENCES inventory(id)
            )
        """)
        
        # Insert multiple programs
        programs = [
            ('PROG1', 'src/prog1.cbl', 1, 100, 'MAIN', 'COBOL'),
            ('PROG2', 'src/prog2.cbl', 1, 200, 'SUBPROGRAM', 'COBOL'),
            ('PROG3', 'src/prog3.pli', 1, 150, 'MAIN', 'PLI')
        ]
        
        for prog_name, file_path, start_line, end_line, prog_type, language in programs:
            # Insert inventory entry
            cursor.execute("""
                INSERT INTO inventory (file_path)
                VALUES (?)
            """, (file_path,))
            file_id = cursor.lastrowid
            
            # Insert program mapping
            cursor.execute("""
                INSERT INTO program_file_mapping 
                (file_id, program_name, start_line, end_line, program_type, language)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (file_id, prog_name, start_line, end_line, prog_type, language))
        
        conn.commit()
        
        # Create exporter (should load cache)
        exporter = MigrationFlowExporter(conn)
        
        # Verify cache is populated
        assert len(exporter._program_metadata_cache) == 3
        assert 'PROG1' in exporter._program_metadata_cache
        assert 'PROG2' in exporter._program_metadata_cache
        assert 'PROG3' in exporter._program_metadata_cache
        
        # Test retrieval from cache
        metadata1 = exporter._enrich_with_file_metadata('PROG1')
        assert metadata1['filePath'] == 'src/prog1.cbl'
        
        metadata2 = exporter._enrich_with_file_metadata('PROG2')
        assert metadata2['filePath'] == 'src/prog2.cbl'
        
        metadata3 = exporter._enrich_with_file_metadata('PROG3')
        assert metadata3['language'] == 'PLI'
        
        conn.close()
    
    def test_get_copybook_file_path_success(self):
        """Test successful copybook file path retrieval."""
        # Create database with inventory table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration_flows schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create inventory table
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT
            )
        """)
        
        # Insert test copybook
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path)
            VALUES (?, ?, ?)
        """, ('CUSTCOPY', 'COPYBOOK', 'src/copybooks/CUSTCOPY.cpy'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Test copybook file path retrieval
        file_path = exporter._get_copybook_file_path('CUSTCOPY')
        
        assert file_path == 'src/copybooks/CUSTCOPY.cpy'
        
        conn.close()
    
    def test_get_copybook_file_path_missing(self):
        """Test that missing copybook returns None."""
        # Create database with inventory table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration_flows schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create inventory table (empty)
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT
            )
        """)
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Test copybook file path retrieval for non-existent copybook
        file_path = exporter._get_copybook_file_path('NONEXISTENT')
        
        assert file_path is None
        
        conn.close()
    
    def test_metadata_enrichment_without_table(self):
        """Test graceful degradation when program_file_mapping table doesn't exist."""
        # Create database without program_file_mapping table
        conn = sqlite3.connect(':memory:')
        
        # Create migration_flows schema only
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create exporter (should handle missing table gracefully)
        exporter = MigrationFlowExporter(conn)
        
        # Verify cache is empty
        assert len(exporter._program_metadata_cache) == 0
        
        # Test metadata retrieval returns None
        metadata = exporter._enrich_with_file_metadata('ANYPROGRAM')
        assert metadata is None
        
        conn.close()
    
    def test_copybook_file_path_without_table(self):
        """Test graceful degradation when inventory table doesn't exist."""
        # Create database without inventory table
        conn = sqlite3.connect(':memory:')
        
        # Create migration_flows schema only
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Test copybook file path retrieval returns None
        file_path = exporter._get_copybook_file_path('ANYCOPYBOOK')
        assert file_path is None
        
        conn.close()



# Property-Based Test for File Metadata Completeness
from hypothesis import given, strategies as st, assume


@st.composite
def program_with_metadata_strategy(draw):
    """Generate a program with complete file metadata."""
    program_name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
        min_size=1,
        max_size=8
    ))
    
    # Generate file path components
    path_parts = draw(st.lists(
        st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd')),
            min_size=1,
            max_size=10
        ),
        min_size=1,
        max_size=3
    ))
    file_name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd')),
        min_size=1,
        max_size=10
    ))
    extension = draw(st.sampled_from(['cbl', 'pli', 'asm', 'rexx']))
    file_path = '/'.join(path_parts) + '/' + file_name + '.' + extension
    
    start_line = draw(st.integers(min_value=1, max_value=1000))
    end_line = draw(st.integers(min_value=start_line + 1, max_value=start_line + 10000))
    
    program_type = draw(st.sampled_from(['MAIN', 'SUBPROGRAM', 'ENTRY_POINT', 'CSECT', 'ROUTINE']))
    language = draw(st.sampled_from(['COBOL', 'PLI', 'ASSEMBLER', 'REXX']))
    
    return {
        'program_name': program_name,
        'file_path': file_path,
        'start_line': start_line,
        'end_line': end_line,
        'program_type': program_type,
        'language': language
    }


@given(program_data=program_with_metadata_strategy())
def test_property_2_file_metadata_completeness(program_data):
    """
    Property 2: File Metadata Completeness
    
    **Validates: Requirements 2.2, 2.5**
    
    For any program in a flow export that has a corresponding entry in 
    program_file_mapping, the exported program object should contain 
    filePath, startLine, endLine, programType, and language fields 
    with non-null values.
    """
    # Create database with program_file_mapping table
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create migration_flows schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Insert program with metadata
    cursor.execute("""
        INSERT INTO program_file_mapping 
        (program_name, file_path, start_line, end_line, program_type, language)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        program_data['program_name'],
        program_data['file_path'],
        program_data['start_line'],
        program_data['end_line'],
        program_data['program_type'],
        program_data['language']
    ))
    
    conn.commit()
    
    # Create exporter (should load cache)
    exporter = MigrationFlowExporter(conn)
    
    # Test metadata retrieval
    metadata = exporter._enrich_with_file_metadata(program_data['program_name'])
    
    # Property: All metadata fields should be present and non-null
    assert metadata is not None, "Metadata should not be None for programs with file mapping"
    assert 'filePath' in metadata, "filePath field should be present"
    assert 'startLine' in metadata, "startLine field should be present"
    assert 'endLine' in metadata, "endLine field should be present"
    assert 'programType' in metadata, "programType field should be present"
    assert 'language' in metadata, "language field should be present"
    
    # Verify all fields have non-null values
    assert metadata['filePath'] is not None, "filePath should not be None"
    assert metadata['startLine'] is not None, "startLine should not be None"
    assert metadata['endLine'] is not None, "endLine should not be None"
    assert metadata['programType'] is not None, "programType should not be None"
    assert metadata['language'] is not None, "language should not be None"
    
    # Verify values match input
    assert metadata['filePath'] == program_data['file_path']
    assert metadata['startLine'] == program_data['start_line']
    assert metadata['endLine'] == program_data['end_line']
    assert metadata['programType'] == program_data['program_type']
    assert metadata['language'] == program_data['language']
    
    conn.close()


# Unit tests for Task 3.4: Enhanced _query_scope() Method
# Feature: flow-analysis-enhancements

class TestEnhancedQueryScope:
    """Test enhanced _query_scope() method with filtering and metadata."""
    
    def test_query_scope_filters_internal_procedures(self, test_db):
        """Test that internal procedures are excluded from scope."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert programs with different types
        cursor.executemany("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [
            ('MAIN_PROG', '/src/MAIN_PROG.cbl', 1, 500, 'MAIN', 'COBOL'),
            ('SUB_PROG', '/src/SUB_PROG.cbl', 1, 300, 'SUBPROGRAM', 'COBOL'),
            ('INTERNAL_PROC', '/src/MAIN_PROG.cbl', 100, 200, 'PROCEDURE', 'COBOL'),
            ('NESTED_PROG', '/src/MAIN_PROG.cbl', 250, 350, 'NESTED', 'COBOL')
        ])
        
        # Create flow with all programs in scope
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST1', 'Test Flow', 'MAIN_PROG', 'JCL',
            4, 0, 0,
            1000, 20, 50.0, 'MEDIUM',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add all programs to flow scope
        cursor.executemany("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, [
            ('FLOW_TEST1', 'PROGRAM', 'MAIN_PROG'),
            ('FLOW_TEST1', 'PROGRAM', 'SUB_PROG'),
            ('FLOW_TEST1', 'PROGRAM', 'INTERNAL_PROC'),
            ('FLOW_TEST1', 'PROGRAM', 'NESTED_PROG')
        ])
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        scope = exporter._query_scope('FLOW_TEST1')
        
        # Verify internal procedures are excluded
        program_names = [p['name'] for p in scope['programs']]
        assert 'MAIN_PROG' in program_names
        assert 'SUB_PROG' in program_names
        assert 'INTERNAL_PROC' not in program_names
        assert 'NESTED_PROG' not in program_names
        assert len(scope['programs']) == 2
    
    def test_query_scope_includes_standalone_programs(self, test_db):
        """Test that standalone programs are included in scope."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert standalone programs
        cursor.executemany("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [
            ('MAIN1', '/src/MAIN1.cbl', 1, 500, 'MAIN', 'COBOL'),
            ('SUB1', '/src/SUB1.cbl', 1, 300, 'SUBPROGRAM', 'COBOL'),
            ('ENTRY1', '/src/MULTI.cbl', 100, 200, 'ENTRY_POINT', 'COBOL'),
            ('CSECT1', '/src/ASM1.asm', 1, 150, 'CSECT', 'ASSEMBLER'),
            ('ROUTINE1', '/src/ROUTINE1.pli', 1, 250, 'ROUTINE', 'PLI')
        ])
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST2', 'Test Flow 2', 'MAIN1', 'JCL',
            5, 0, 0,
            1500, 30, 60.0, 'MEDIUM',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add programs to scope
        cursor.executemany("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, [
            ('FLOW_TEST2', 'PROGRAM', 'MAIN1'),
            ('FLOW_TEST2', 'PROGRAM', 'SUB1'),
            ('FLOW_TEST2', 'PROGRAM', 'ENTRY1'),
            ('FLOW_TEST2', 'PROGRAM', 'CSECT1'),
            ('FLOW_TEST2', 'PROGRAM', 'ROUTINE1')
        ])
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        scope = exporter._query_scope('FLOW_TEST2')
        
        # Verify all standalone programs are included
        program_names = [p['name'] for p in scope['programs']]
        assert 'MAIN1' in program_names
        assert 'SUB1' in program_names
        assert 'ENTRY1' in program_names
        assert 'CSECT1' in program_names
        assert 'ROUTINE1' in program_names
        assert len(scope['programs']) == 5
    
    def test_query_scope_adds_file_metadata_to_programs(self, test_db):
        """Test that file metadata is added to program objects."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert program with metadata
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('PAYROLL1', '/src/cobol/PAYROLL1.cbl', 1, 450, 'MAIN', 'COBOL'))
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST3', 'Test Flow 3', 'PAYROLL1', 'JCL',
            1, 0, 0,
            450, 15, 40.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add program to scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST3', 'PROGRAM', 'PAYROLL1'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        scope = exporter._query_scope('FLOW_TEST3')
        
        # Verify program has metadata
        assert len(scope['programs']) == 1
        program = scope['programs'][0]
        
        assert program['name'] == 'PAYROLL1'
        assert program['filePath'] == '/src/cobol/PAYROLL1.cbl'
        assert program['startLine'] == 1
        assert program['endLine'] == 450
        assert program['programType'] == 'MAIN'
        assert program['language'] == 'COBOL'
    
    def test_query_scope_adds_file_metadata_to_copybooks(self, test_db):
        """Test that file metadata is added to copybook objects."""
        cursor = test_db.cursor()
        
        # Create inventory table
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT,
                PRIMARY KEY (artifact_name, artifact_type)
            )
        """)
        
        # Insert copybook
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path)
            VALUES (?, ?, ?)
        """, ('CUSTCOPY', 'COPYBOOK', '/src/copybooks/CUSTCOPY.cpy'))
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST4', 'Test Flow 4', 'MAIN1', 'JCL',
            0, 1, 0,
            100, 5, 20.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add copybook to scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST4', 'COPYBOOK', 'CUSTCOPY'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        scope = exporter._query_scope('FLOW_TEST4')
        
        # Verify copybook has file path
        assert len(scope['copybooks']) == 1
        copybook = scope['copybooks'][0]
        
        assert copybook['name'] == 'CUSTCOPY'
        assert copybook['filePath'] == '/src/copybooks/CUSTCOPY.cpy'
    
    def test_query_scope_handles_missing_program_metadata(self, test_db):
        """Test graceful handling of missing program metadata."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table (empty)
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST5', 'Test Flow 5', 'LEGACY1', 'JCL',
            1, 0, 0,
            500, 10, 30.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add program without metadata
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST5', 'PROGRAM', 'LEGACY1'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        scope = exporter._query_scope('FLOW_TEST5')
        
        # Verify program is included without metadata
        assert len(scope['programs']) == 1
        program = scope['programs'][0]
        
        assert program['name'] == 'LEGACY1'
        # Metadata fields should not be present
        assert 'filePath' not in program
        assert 'startLine' not in program
        assert 'endLine' not in program
        assert 'programType' not in program
        assert 'language' not in program
    
    def test_query_scope_handles_missing_copybook_metadata(self, test_db):
        """Test graceful handling of missing copybook file paths."""
        cursor = test_db.cursor()
        
        # Create inventory table (empty)
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT,
                PRIMARY KEY (artifact_name, artifact_type)
            )
        """)
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST6', 'Test Flow 6', 'MAIN1', 'JCL',
            0, 1, 0,
            100, 5, 20.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add copybook without file path
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST6', 'COPYBOOK', 'OLDCOPY'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        scope = exporter._query_scope('FLOW_TEST6')
        
        # Verify copybook is included without file path
        assert len(scope['copybooks']) == 1
        copybook = scope['copybooks'][0]
        
        assert copybook['name'] == 'OLDCOPY'
        # filePath should not be present
        assert 'filePath' not in copybook
    
    def test_query_scope_handles_null_program_type(self, test_db):
        """Test that NULL program_type is treated as standalone (backward compatibility)."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert program with NULL program_type
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('LEGACY_PROG', '/src/LEGACY_PROG.cbl', 1, 400, None, 'COBOL'))
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST7', 'Test Flow 7', 'LEGACY_PROG', 'JCL',
            1, 0, 0,
            400, 10, 30.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add program to scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST7', 'PROGRAM', 'LEGACY_PROG'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        scope = exporter._query_scope('FLOW_TEST7')
        
        # Verify program with NULL type is included (backward compatibility)
        assert len(scope['programs']) == 1
        program = scope['programs'][0]
        assert program['name'] == 'LEGACY_PROG'
    
    def test_query_scope_with_extended_scope_flag(self, test_db):
        """Test that extended_scope flag adds utility metadata."""
        cursor = test_db.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert program
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('UTIL1', '/src/UTIL1.cbl', 1, 300, 'SUBPROGRAM', 'COBOL'))
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST8', 'Test Flow 8', 'MAIN1', 'JCL',
            1, 0, 0,
            300, 8, 25.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add program to scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST8', 'PROGRAM', 'UTIL1'))
        
        test_db.commit()
        
        exporter = MigrationFlowExporter(test_db)
        exporter.extended_scope = True
        
        scope = exporter._query_scope('FLOW_TEST8')
        
        # Verify program has both file metadata and utility metadata
        assert len(scope['programs']) == 1
        program = scope['programs'][0]
        
        assert program['name'] == 'UTIL1'
        # File metadata should be present
        assert 'filePath' in program
        assert program['filePath'] == '/src/UTIL1.cbl'
        # Utility metadata should be present
        assert 'is_utility' in program
    
    def test_format_extended_scope_with_string_programs(self, test_db):
        """Test _format_extended_scope handles string program names (backward compatibility)."""
        cursor = test_db.cursor()
        
        # Create program_metadata table for utility detection
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_metadata (
                program_name TEXT PRIMARY KEY,
                is_utility INTEGER,
                call_count INTEGER,
                classification TEXT,
                shared_by_flow_count INTEGER,
                naming_pattern TEXT,
                created_date TEXT,
                updated_date TEXT
            )
        """)
        
        # Mark UTIL1 as utility
        cursor.execute("""
            INSERT INTO program_metadata (
                program_name, is_utility, call_count, classification,
                shared_by_flow_count, naming_pattern, created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, ('UTIL1', 1, 5, 'UTILITY', 3, None, '2024-01-01', '2024-01-01'))
        
        test_db.commit()
        
        # Test with string program names (old format)
        exporter = MigrationFlowExporter(test_db)
        programs = ['PROG1', 'UTIL1', 'PROG2']
        
        result = exporter._format_extended_scope(programs)
        
        # Verify all programs are converted to dict format
        assert len(result) == 3
        assert all(isinstance(p, dict) for p in result)
        assert all('name' in p for p in result)
        
        # Verify utility metadata is added
        util1 = next(p for p in result if p['name'] == 'UTIL1')
        assert util1['is_utility'] is True
        assert util1['call_count'] == 5
        assert util1['classification'] == 'UTILITY'
        
        # Verify non-utility programs
        prog1 = next(p for p in result if p['name'] == 'PROG1')
        assert prog1['is_utility'] is False
    
    def test_format_extended_scope_with_dict_programs(self, test_db):
        """Test _format_extended_scope handles dict program objects with metadata."""
        cursor = test_db.cursor()
        
        # Create program_metadata table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_metadata (
                program_name TEXT PRIMARY KEY,
                is_utility INTEGER,
                call_count INTEGER,
                classification TEXT,
                shared_by_flow_count INTEGER,
                naming_pattern TEXT,
                created_date TEXT,
                updated_date TEXT
            )
        """)
        
        # Mark UTIL1 as utility
        cursor.execute("""
            INSERT INTO program_metadata (
                program_name, is_utility, call_count, classification,
                shared_by_flow_count, naming_pattern, created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, ('UTIL1', 1, 5, 'UTILITY', 3, None, '2024-01-01', '2024-01-01'))
        
        test_db.commit()
        
        # Test with dict program objects (new format with file metadata)
        exporter = MigrationFlowExporter(test_db)
        programs = [
            {
                'name': 'PROG1',
                'filePath': '/src/PROG1.cbl',
                'startLine': 1,
                'endLine': 100,
                'programType': 'MAIN',
                'language': 'COBOL'
            },
            {
                'name': 'UTIL1',
                'filePath': '/src/UTIL1.cbl',
                'startLine': 1,
                'endLine': 50,
                'programType': 'SUBPROGRAM',
                'language': 'COBOL'
            },
            {
                'name': 'PROG2',
                'filePath': '/src/PROG2.cbl',
                'startLine': 1,
                'endLine': 200,
                'programType': 'MAIN',
                'language': 'COBOL'
            }
        ]
        
        result = exporter._format_extended_scope(programs)
        
        # Verify all programs maintain their metadata
        assert len(result) == 3
        
        # Check PROG1 - file metadata preserved, utility metadata added
        prog1 = next(p for p in result if p['name'] == 'PROG1')
        assert prog1['filePath'] == '/src/PROG1.cbl'
        assert prog1['startLine'] == 1
        assert prog1['endLine'] == 100
        assert prog1['programType'] == 'MAIN'
        assert prog1['language'] == 'COBOL'
        assert prog1['is_utility'] is False
        
        # Check UTIL1 - file metadata preserved, utility metadata added
        util1 = next(p for p in result if p['name'] == 'UTIL1')
        assert util1['filePath'] == '/src/UTIL1.cbl'
        assert util1['startLine'] == 1
        assert util1['endLine'] == 50
        assert util1['programType'] == 'SUBPROGRAM'
        assert util1['language'] == 'COBOL'
        assert util1['is_utility'] is True
        assert util1['call_count'] == 5
        assert util1['classification'] == 'UTILITY'
    
    def test_format_extended_scope_preserves_all_metadata(self, test_db):
        """Test that _format_extended_scope preserves all existing metadata fields."""
        cursor = test_db.cursor()
        
        # Create program_metadata table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_metadata (
                program_name TEXT PRIMARY KEY,
                is_utility INTEGER,
                call_count INTEGER,
                classification TEXT,
                shared_by_flow_count INTEGER,
                naming_pattern TEXT,
                created_date TEXT,
                updated_date TEXT
            )
        """)
        
        test_db.commit()
        
        # Test with program objects that have various metadata fields
        exporter = MigrationFlowExporter(test_db)
        programs = [
            {
                'name': 'PROG1',
                'filePath': '/src/PROG1.cbl',
                'startLine': 1,
                'endLine': 100,
                'programType': 'MAIN',
                'language': 'COBOL',
                'customField': 'customValue',  # Custom field should be preserved
                'anotherField': 123
            }
        ]
        
        result = exporter._format_extended_scope(programs)
        
        # Verify all original fields are preserved
        assert len(result) == 1
        prog1 = result[0]
        assert prog1['name'] == 'PROG1'
        assert prog1['filePath'] == '/src/PROG1.cbl'
        assert prog1['startLine'] == 1
        assert prog1['endLine'] == 100
        assert prog1['programType'] == 'MAIN'
        assert prog1['language'] == 'COBOL'
        assert prog1['customField'] == 'customValue'
        assert prog1['anotherField'] == 123
        assert prog1['is_utility'] is False  # Utility metadata added
    
    def test_format_extended_scope_mixed_formats(self, test_db):
        """Test _format_extended_scope handles mixed string and dict formats."""
        cursor = test_db.cursor()
        
        # Create program_metadata table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_metadata (
                program_name TEXT PRIMARY KEY,
                is_utility INTEGER,
                call_count INTEGER,
                classification TEXT,
                shared_by_flow_count INTEGER,
                naming_pattern TEXT,
                created_date TEXT,
                updated_date TEXT
            )
        """)
        
        test_db.commit()
        
        # Test with mixed formats (should handle gracefully)
        exporter = MigrationFlowExporter(test_db)
        programs = [
            'PROG1',  # String format
            {
                'name': 'PROG2',
                'filePath': '/src/PROG2.cbl',
                'programType': 'MAIN'
            },  # Dict format
            'PROG3'  # String format
        ]
        
        result = exporter._format_extended_scope(programs)
        
        # Verify all programs are converted to dict format
        assert len(result) == 3
        assert all(isinstance(p, dict) for p in result)
        assert all('name' in p for p in result)
        assert all('is_utility' in p for p in result)
        
        # Verify string programs are converted
        prog1 = next(p for p in result if p['name'] == 'PROG1')
        assert prog1['is_utility'] is False
        assert 'filePath' not in prog1  # No metadata for string format
        
        # Verify dict programs preserve metadata
        prog2 = next(p for p in result if p['name'] == 'PROG2')
        assert prog2['filePath'] == '/src/PROG2.cbl'
        assert prog2['programType'] == 'MAIN'
        assert prog2['is_utility'] is False


# Property test for Task 3.5: Scope Filtering Integration
# Feature: flow-analysis-enhancements, Property 1: Internal Procedure Exclusion (integration)
# Validates: Requirements 1.1, 1.3, 1.4

@st.composite
def flow_scope_with_mixed_programs_strategy(draw):
    """
    Strategy for generating flow scope data with mixed program types.
    
    Returns a tuple of (flow_id, programs, copybooks) where:
    - flow_id: Random flow identifier
    - programs: List of program dicts with mixed types (standalone and internal)
    - copybooks: List of copybook dicts
    """
    # Generate flow ID
    flow_id = 'FLOW_' + ''.join(draw(st.lists(
        st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'),
        min_size=5,
        max_size=10
    )))
    
    # Generate programs with mixed types
    num_programs = draw(st.integers(min_value=2, max_value=15))
    programs = []
    
    standalone_types = ['MAIN', 'SUBPROGRAM', 'ENTRY_POINT', 'CSECT', 'ROUTINE']
    internal_types = ['PROCEDURE', 'NESTED', 'FUNCTION']
    
    for i in range(num_programs):
        # Mix of standalone and internal programs
        if draw(st.booleans()):
            program_type = draw(st.sampled_from(standalone_types))
        else:
            program_type = draw(st.sampled_from(internal_types))
        
        program = {
            'program_name': f'PROG{i:03d}',
            'file_path': f'/src/PROG{i:03d}.cbl',
            'start_line': draw(st.integers(min_value=1, max_value=100)),
            'end_line': draw(st.integers(min_value=100, max_value=1000)),
            'program_type': program_type,
            'language': draw(st.sampled_from(['COBOL', 'PLI', 'ASSEMBLER']))
        }
        programs.append(program)
    
    # Generate copybooks
    num_copybooks = draw(st.integers(min_value=0, max_value=5))
    copybooks = []
    for i in range(num_copybooks):
        copybook = {
            'copybook_name': f'COPY{i:03d}',
            'file_path': f'/src/copybooks/COPY{i:03d}.cpy'
        }
        copybooks.append(copybook)
    
    return flow_id, programs, copybooks


@settings(
    max_examples=100,
    suppress_health_check=[
        HealthCheck.too_slow,
        HealthCheck.data_too_large,
        HealthCheck.function_scoped_fixture
    ]
)
@given(scope_data=flow_scope_with_mixed_programs_strategy())
def test_property_1_scope_filtering_integration(scope_data):
    """
    Property 1: Internal Procedure Exclusion (Integration Test)
    
    For any flow scope export, all programs in the scope.programs list should
    have program_type values that indicate standalone execution capability,
    and no programs with program_type of PROCEDURE, NESTED, or FUNCTION should
    appear in the exported scope.
    
    This integration test verifies that:
    - _query_scope correctly filters internal procedures from the programs list
    - Only standalone programs (MAIN, SUBPROGRAM, ENTRY_POINT, CSECT, ROUTINE) appear in output
    - Internal procedures (PROCEDURE, NESTED, FUNCTION) are excluded from output
    - File metadata is correctly added to programs and copybooks
    - The complete filtering pipeline works end-to-end
    """
    import tempfile
    import os
    
    flow_id, programs, copybooks = scope_data
    
    # Create temporary database
    fd, db_path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Create inventory table for copybooks
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT,
                PRIMARY KEY (artifact_name, artifact_type)
            )
        """)
        
        # Insert programs into program_file_mapping
        for program in programs:
            cursor.execute("""
                INSERT INTO program_file_mapping 
                (program_name, file_path, start_line, end_line, program_type, language)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                program['program_name'],
                program['file_path'],
                program['start_line'],
                program['end_line'],
                program['program_type'],
                program['language']
            ))
        
        # Insert copybooks into inventory
        for copybook in copybooks:
            cursor.execute("""
                INSERT INTO inventory (artifact_name, artifact_type, file_path)
                VALUES (?, ?, ?)
            """, (copybook['copybook_name'], 'COPYBOOK', copybook['file_path']))
        
        # Create flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            flow_id, 'Test Flow', programs[0]['program_name'], 'JCL',
            len(programs), len(copybooks), 0,
            1000, 20, 50.0, 'MEDIUM',
            '2024-01-01', '2024-01-01'
        ))
        
        # Add all programs to flow scope
        for program in programs:
            cursor.execute("""
                INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
                VALUES (?, ?, ?)
            """, (flow_id, 'PROGRAM', program['program_name']))
        
        # Add all copybooks to flow scope
        for copybook in copybooks:
            cursor.execute("""
                INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
                VALUES (?, ?, ?)
            """, (flow_id, 'COPYBOOK', copybook['copybook_name']))
        
        conn.commit()
        
        # Create exporter and query scope
        exporter = MigrationFlowExporter(conn)
        scope = exporter._query_scope(flow_id)
        
        # Define standalone and internal types
        standalone_types = {'MAIN', 'SUBPROGRAM', 'ENTRY_POINT', 'CSECT', 'ROUTINE'}
        internal_types = {'PROCEDURE', 'NESTED', 'FUNCTION'}
        
        # Property: All programs in scope should be standalone
        exported_program_names = [p['name'] for p in scope['programs']]
        
        for program in programs:
            program_name = program['program_name']
            program_type = program['program_type']
            
            if program_type in standalone_types:
                # Standalone programs should be in the exported scope
                assert program_name in exported_program_names, \
                    f"Standalone program {program_name} (type: {program_type}) should be in scope"
            elif program_type in internal_types:
                # Internal procedures should NOT be in the exported scope
                assert program_name not in exported_program_names, \
                    f"Internal procedure {program_name} (type: {program_type}) should NOT be in scope"
        
        # Property: No internal procedures should appear in exported scope
        for exported_program in scope['programs']:
            program_name = exported_program['name']
            # Find the original program data
            original_program = next(p for p in programs if p['program_name'] == program_name)
            program_type = original_program['program_type']
            
            assert program_type not in internal_types, \
                f"Exported program {program_name} has internal type {program_type}"
            assert program_type in standalone_types, \
                f"Exported program {program_name} should have standalone type, got {program_type}"
        
        # Property: File metadata should be present for programs
        for exported_program in scope['programs']:
            assert 'name' in exported_program, "Program should have 'name' field"
            
            # Find original program to verify metadata
            program_name = exported_program['name']
            original_program = next(p for p in programs if p['program_name'] == program_name)
            
            # Metadata should be present
            assert 'filePath' in exported_program, f"Program {program_name} should have filePath"
            assert 'startLine' in exported_program, f"Program {program_name} should have startLine"
            assert 'endLine' in exported_program, f"Program {program_name} should have endLine"
            assert 'programType' in exported_program, f"Program {program_name} should have programType"
            assert 'language' in exported_program, f"Program {program_name} should have language"
            
            # Verify metadata values match
            assert exported_program['filePath'] == original_program['file_path']
            assert exported_program['startLine'] == original_program['start_line']
            assert exported_program['endLine'] == original_program['end_line']
            assert exported_program['programType'] == original_program['program_type']
            assert exported_program['language'] == original_program['language']
        
        # Property: Copybooks should have file paths
        for exported_copybook in scope['copybooks']:
            assert 'name' in exported_copybook, "Copybook should have 'name' field"
            
            # Find original copybook
            copybook_name = exported_copybook['name']
            original_copybook = next(c for c in copybooks if c['copybook_name'] == copybook_name)
            
            # File path should be present
            assert 'filePath' in exported_copybook, f"Copybook {copybook_name} should have filePath"
            assert exported_copybook['filePath'] == original_copybook['file_path']
        
        conn.close()
        
    finally:
        if os.path.exists(db_path):
            os.unlink(db_path)



# Feature: flow-analysis-enhancements
class TestEnhancedQueryDependencies:
    """Test enhanced _query_dependencies() method with metadata."""
    
    def test_query_dependencies_with_file_metadata(self):
        """Test that file metadata is included in dependency objects."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert entry programs with file metadata
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('PAYROLL1', 'src/cobol/PAYROLL1.cbl', 1, 450, 'MAIN', 'COBOL'))
        
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('BILLING1', 'src/cobol/BILLING1.cbl', 1, 350, 'MAIN', 'COBOL'))
        
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('UTIL001', 'src/cobol/UTIL001.cbl', 1, 200, 'SUBPROGRAM', 'COBOL'))
        
        # Insert flows
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_PAYROLL1', 'Payroll Processing', 'PAYROLL1', 'JCL'))
        
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_BILLING1', 'Billing Processing', 'BILLING1', 'JCL'))
        
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_UTIL001', 'Utility Functions', 'UTIL001', 'PROGRAM_CALL'))
        
        # Insert dependencies
        # BILLING1 depends on PAYROLL1 and UTIL001
        cursor.execute("""
            INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
            VALUES (?, ?, ?)
        """, ('FLOW_BILLING1', 'FLOW_PAYROLL1', 'REQUIRED'))
        
        cursor.execute("""
            INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
            VALUES (?, ?, ?)
        """, ('FLOW_BILLING1', 'FLOW_UTIL001', 'REQUIRED'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Query dependencies for BILLING1
        deps = exporter._query_dependencies('FLOW_BILLING1')
        
        # Check structure
        assert 'requiredFlows' in deps
        assert 'dependentFlows' in deps
        assert len(deps['requiredFlows']) == 2
        
        # Check first dependency (PAYROLL1)
        payroll_dep = next(d for d in deps['requiredFlows'] if d['flowId'] == 'FLOW_PAYROLL1')
        assert payroll_dep['entryProgram'] == 'PAYROLL1'
        assert 'filePath' in payroll_dep
        assert payroll_dep['filePath'] == 'src/cobol/PAYROLL1.cbl'
        
        # Check second dependency (UTIL001)
        util_dep = next(d for d in deps['requiredFlows'] if d['flowId'] == 'FLOW_UTIL001')
        assert util_dep['entryProgram'] == 'UTIL001'
        assert 'filePath' in util_dep
        assert util_dep['filePath'] == 'src/cobol/UTIL001.cbl'
        
        # Query dependencies for PAYROLL1 (should have BILLING1 as dependent)
        deps = exporter._query_dependencies('FLOW_PAYROLL1')
        
        assert len(deps['dependentFlows']) == 1
        billing_dep = deps['dependentFlows'][0]
        assert billing_dep['flowId'] == 'FLOW_BILLING1'
        assert billing_dep['entryProgram'] == 'BILLING1'
        assert 'filePath' in billing_dep
        assert billing_dep['filePath'] == 'src/cobol/BILLING1.cbl'
        
        conn.close()
    
    def test_query_dependencies_missing_metadata_graceful(self):
        """Test that missing metadata is handled gracefully."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table (empty - no metadata)
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert flows without file metadata
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_PAYROLL1', 'Payroll Processing', 'PAYROLL1', 'JCL'))
        
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_BILLING1', 'Billing Processing', 'BILLING1', 'JCL'))
        
        # Insert dependency
        cursor.execute("""
            INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
            VALUES (?, ?, ?)
        """, ('FLOW_BILLING1', 'FLOW_PAYROLL1', 'REQUIRED'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Query dependencies
        deps = exporter._query_dependencies('FLOW_BILLING1')
        
        # Should succeed without file metadata
        assert len(deps['requiredFlows']) == 1
        payroll_dep = deps['requiredFlows'][0]
        assert payroll_dep['flowId'] == 'FLOW_PAYROLL1'
        assert payroll_dep['entryProgram'] == 'PAYROLL1'
        # filePath should not be present when metadata is missing
        assert 'filePath' not in payroll_dep
        
        conn.close()
    
    def test_query_dependencies_partial_metadata(self):
        """Test handling of partial metadata (some programs have metadata, others don't)."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert only PAYROLL1 with file metadata (not BILLING1 or UTIL001)
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ('PAYROLL1', 'src/cobol/PAYROLL1.cbl', 1, 450, 'MAIN', 'COBOL'))
        
        # Insert flows
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_PAYROLL1', 'Payroll Processing', 'PAYROLL1', 'JCL'))
        
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_BILLING1', 'Billing Processing', 'BILLING1', 'JCL'))
        
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_UTIL001', 'Utility Functions', 'UTIL001', 'PROGRAM_CALL'))
        
        # Insert dependencies
        cursor.execute("""
            INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
            VALUES (?, ?, ?)
        """, ('FLOW_BILLING1', 'FLOW_PAYROLL1', 'REQUIRED'))
        
        cursor.execute("""
            INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
            VALUES (?, ?, ?)
        """, ('FLOW_BILLING1', 'FLOW_UTIL001', 'REQUIRED'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Query dependencies
        deps = exporter._query_dependencies('FLOW_BILLING1')
        
        assert len(deps['requiredFlows']) == 2
        
        # PAYROLL1 should have file metadata
        payroll_dep = next(d for d in deps['requiredFlows'] if d['flowId'] == 'FLOW_PAYROLL1')
        assert payroll_dep['entryProgram'] == 'PAYROLL1'
        assert 'filePath' in payroll_dep
        assert payroll_dep['filePath'] == 'src/cobol/PAYROLL1.cbl'
        
        # UTIL001 should not have file metadata
        util_dep = next(d for d in deps['requiredFlows'] if d['flowId'] == 'FLOW_UTIL001')
        assert util_dep['entryProgram'] == 'UTIL001'
        assert 'filePath' not in util_dep
        
        conn.close()
    
    def test_query_dependencies_empty_result(self):
        """Test querying dependencies for flow with no dependencies."""
        # Create database
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Insert flow without dependencies
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type
            ) VALUES (?, ?, ?, ?)
        """, ('FLOW_STANDALONE', 'Standalone Flow', 'STANDALONE1', 'JCL'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Query dependencies
        deps = exporter._query_dependencies('FLOW_STANDALONE')
        
        # Should return empty lists
        assert 'requiredFlows' in deps
        assert 'dependentFlows' in deps
        assert len(deps['requiredFlows']) == 0
        assert len(deps['dependentFlows']) == 0
        
        conn.close()
    
    def test_query_dependencies_structure_consistency(self):
        """Test that dependency structure is consistent across multiple queries."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert programs
        programs = [
            ('PROG1', 'src/prog1.cbl', 1, 100, 'MAIN', 'COBOL'),
            ('PROG2', 'src/prog2.cbl', 1, 200, 'MAIN', 'COBOL'),
            ('PROG3', 'src/prog3.cbl', 1, 150, 'MAIN', 'COBOL')
        ]
        
        for prog in programs:
            cursor.execute("""
                INSERT INTO program_file_mapping 
                (program_name, file_path, start_line, end_line, program_type, language)
                VALUES (?, ?, ?, ?, ?, ?)
            """, prog)
        
        # Insert flows
        for i, (prog_name, _, _, _, _, _) in enumerate(programs, 1):
            cursor.execute("""
                INSERT INTO migration_flows (
                    flow_id, name, entry_program, primary_entry_type
                ) VALUES (?, ?, ?, ?)
            """, (f'FLOW_{i}', f'Flow {i}', prog_name, 'JCL'))
        
        # Create dependency chain: FLOW_3 -> FLOW_2 -> FLOW_1
        cursor.execute("""
            INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
            VALUES (?, ?, ?)
        """, ('FLOW_2', 'FLOW_1', 'REQUIRED'))
        
        cursor.execute("""
            INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
            VALUES (?, ?, ?)
        """, ('FLOW_3', 'FLOW_2', 'REQUIRED'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Query all flows
        deps1 = exporter._query_dependencies('FLOW_1')
        deps2 = exporter._query_dependencies('FLOW_2')
        deps3 = exporter._query_dependencies('FLOW_3')
        
        # Verify structure consistency
        # FLOW_1 has no required flows, but FLOW_2 depends on it
        assert len(deps1['requiredFlows']) == 0
        assert len(deps1['dependentFlows']) == 1
        assert deps1['dependentFlows'][0]['flowId'] == 'FLOW_2'
        assert deps1['dependentFlows'][0]['entryProgram'] == 'PROG2'
        assert deps1['dependentFlows'][0]['filePath'] == 'src/prog2.cbl'
        
        # FLOW_2 depends on FLOW_1, and FLOW_3 depends on it
        assert len(deps2['requiredFlows']) == 1
        assert len(deps2['dependentFlows']) == 1
        assert deps2['requiredFlows'][0]['flowId'] == 'FLOW_1'
        assert deps2['requiredFlows'][0]['entryProgram'] == 'PROG1'
        assert deps2['requiredFlows'][0]['filePath'] == 'src/prog1.cbl'
        assert deps2['dependentFlows'][0]['flowId'] == 'FLOW_3'
        
        # FLOW_3 depends on FLOW_2, no dependents
        assert len(deps3['requiredFlows']) == 1
        assert len(deps3['dependentFlows']) == 0
        assert deps3['requiredFlows'][0]['flowId'] == 'FLOW_2'
        assert deps3['requiredFlows'][0]['entryProgram'] == 'PROG2'
        assert deps3['requiredFlows'][0]['filePath'] == 'src/prog2.cbl'
        
        conn.close()



# Property-Based Test for Metadata Consistency
@st.composite
def flow_with_dependencies_strategy(draw):
    """Generate flows with dependencies where programs appear in multiple sections."""
    # Generate 3 programs with metadata
    programs = []
    for i in range(3):
        program_name = draw(st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
            min_size=4,
            max_size=8
        ))
        
        # Ensure unique program names
        while program_name in [p['program_name'] for p in programs]:
            program_name = draw(st.text(
                alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
                min_size=4,
                max_size=8
            ))
        
        file_path = f"src/{program_name.lower()}.cbl"
        start_line = draw(st.integers(min_value=1, max_value=100))
        end_line = draw(st.integers(min_value=start_line + 50, max_value=start_line + 500))
        program_type = draw(st.sampled_from(['MAIN', 'SUBPROGRAM', 'ENTRY_POINT']))
        language = 'COBOL'
        
        programs.append({
            'program_name': program_name,
            'file_path': file_path,
            'start_line': start_line,
            'end_line': end_line,
            'program_type': program_type,
            'language': language
        })
    
    return programs


@given(programs=flow_with_dependencies_strategy())
@settings(max_examples=100, deadline=None, suppress_health_check=[HealthCheck.large_base_example])
def test_property_3_metadata_consistency(programs):
    """
    Property 3: Metadata Consistency
    
    **Validates: Requirements 5.3**
    
    For any program that appears in multiple sections of a flow export 
    (entry points, scope, dependencies), the file metadata (filePath, 
    programType, language) should be identical across all occurrences.
    """
    # Skip if we don't have enough unique programs
    assume(len(programs) >= 3)
    assume(len(set(p['program_name'] for p in programs)) == 3)
    
    # Create database
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Insert programs with metadata
    for prog in programs:
        cursor.execute("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            prog['program_name'],
            prog['file_path'],
            prog['start_line'],
            prog['end_line'],
            prog['program_type'],
            prog['language']
        ))
    
    # Create flows where programs appear in multiple places
    # FLOW_1: entry_program = programs[0]
    # FLOW_2: entry_program = programs[1], depends on FLOW_1
    # FLOW_3: entry_program = programs[2], depends on FLOW_2
    
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type
        ) VALUES (?, ?, ?, ?)
    """, ('FLOW_1', 'Flow 1', programs[0]['program_name'], 'JCL'))
    
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type
        ) VALUES (?, ?, ?, ?)
    """, ('FLOW_2', 'Flow 2', programs[1]['program_name'], 'JCL'))
    
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type
        ) VALUES (?, ?, ?, ?)
    """, ('FLOW_3', 'Flow 3', programs[2]['program_name'], 'JCL'))
    
    # Add programs to scope (programs[0] appears in FLOW_2's scope)
    cursor.execute("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, ('FLOW_2', 'PROGRAM', programs[0]['program_name']))
    
    cursor.execute("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, ('FLOW_2', 'PROGRAM', programs[1]['program_name']))
    
    cursor.execute("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, ('FLOW_3', 'PROGRAM', programs[1]['program_name']))
    
    cursor.execute("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, ('FLOW_3', 'PROGRAM', programs[2]['program_name']))
    
    # Add dependencies (programs[0] appears in FLOW_2's dependencies)
    cursor.execute("""
        INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
        VALUES (?, ?, ?)
    """, ('FLOW_2', 'FLOW_1', 'REQUIRED'))
    
    cursor.execute("""
        INSERT INTO flow_dependencies (flow_id, depends_on_flow_id, dependency_type)
        VALUES (?, ?, ?)
    """, ('FLOW_3', 'FLOW_2', 'REQUIRED'))
    
    # Add entry types (programs[0] appears as caller in FLOW_2)
    cursor.execute("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, ('FLOW_2', 'PROGRAM_CALL', programs[0]['program_name'], '{}'))
    
    conn.commit()
    
    # Create exporter
    exporter = MigrationFlowExporter(conn)
    
    # Export FLOW_2 (programs[0] appears in scope, dependencies, and entry types)
    flow = exporter._query_flow('FLOW_2')
    
    # Collect all occurrences of programs[0]
    prog0_occurrences = []
    
    # Check in scope
    for prog in flow['scope']['programs']:
        if prog['name'] == programs[0]['program_name']:
            prog0_occurrences.append({
                'section': 'scope',
                'filePath': prog.get('filePath'),
                'programType': prog.get('programType'),
                'language': prog.get('language')
            })
    
    # Check in dependencies (requiredFlows)
    for dep in flow['dependencies']['requiredFlows']:
        if dep['entryProgram'] == programs[0]['program_name']:
            prog0_occurrences.append({
                'section': 'dependencies',
                'filePath': dep.get('filePath'),
                'programType': None,  # Dependencies don't include programType
                'language': None      # Dependencies don't include language
            })
    
    # Check in entry types
    for entry_type in flow['entryPoint']['types']:
        for caller in entry_type.get('callers', []):
            if caller.get('source') == programs[0]['program_name']:
                prog0_occurrences.append({
                    'section': 'entryTypes',
                    'filePath': caller.get('filePath'),
                    'programType': None,  # Entry types don't include programType
                    'language': None      # Entry types don't include language
                })
    
    # Property: All occurrences should have consistent filePath
    if len(prog0_occurrences) > 1:
        file_paths = [occ['filePath'] for occ in prog0_occurrences if occ['filePath'] is not None]
        if len(file_paths) > 1:
            # All file paths should be identical
            assert all(fp == file_paths[0] for fp in file_paths), \
                f"Inconsistent filePath for {programs[0]['program_name']}: {file_paths}"
    
    # Property: Scope metadata should match program_file_mapping
    for prog in flow['scope']['programs']:
        if prog['name'] == programs[0]['program_name']:
            assert prog['filePath'] == programs[0]['file_path']
            assert prog['programType'] == programs[0]['program_type']
            assert prog['language'] == programs[0]['language']
    
    # Property: Dependency metadata should match program_file_mapping
    for dep in flow['dependencies']['requiredFlows']:
        if dep['entryProgram'] == programs[0]['program_name']:
            assert dep['filePath'] == programs[0]['file_path']
    
    conn.close()


# ============================================================================
# Configuration Tests
# ============================================================================

def test_config_filter_internal_procedures_true(test_db):
    """Test that filter_internal_procedures=True excludes internal procedures."""
    cursor = test_db.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_TEST', 'Test Flow', 'MAINPROG', 'JCL',
        3, 0, 0, 1000, 20, 50.0, 'LOW',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert programs with different types
    cursor.executemany("""
        INSERT INTO program_file_mapping (
            program_name, file_path, start_line, end_line, program_type, language
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, [
        ('MAINPROG', 'src/MAINPROG.cbl', 1, 100, 'MAIN', 'COBOL'),
        ('SUBPROG', 'src/SUBPROG.cbl', 1, 50, 'SUBPROGRAM', 'COBOL'),
        ('INTERNAL_PROC', 'src/MAINPROG.cbl', 50, 80, 'PROCEDURE', 'COBOL'),
        ('NESTED_PROC', 'src/MAINPROG.cbl', 81, 95, 'NESTED', 'COBOL')
    ])
    
    # Insert scope with all programs
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, [
        ('FLOW_TEST', 'PROGRAM', 'MAINPROG'),
        ('FLOW_TEST', 'PROGRAM', 'SUBPROG'),
        ('FLOW_TEST', 'PROGRAM', 'INTERNAL_PROC'),
        ('FLOW_TEST', 'PROGRAM', 'NESTED_PROC')
    ])
    
    test_db.commit()
    
    # Create exporter with filter_internal_procedures=True (default)
    exporter = MigrationFlowExporter(test_db, filter_internal_procedures=True)
    
    # Query scope
    scope = exporter._query_scope('FLOW_TEST')
    
    # Verify internal procedures are excluded
    program_names = [p['name'] for p in scope['programs']]
    assert 'MAINPROG' in program_names
    assert 'SUBPROG' in program_names
    assert 'INTERNAL_PROC' not in program_names
    assert 'NESTED_PROC' not in program_names


def test_config_filter_internal_procedures_false(test_db):
    """Test that filter_internal_procedures=False includes all programs."""
    cursor = test_db.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_TEST', 'Test Flow', 'MAINPROG', 'JCL',
        4, 0, 0, 1000, 20, 50.0, 'LOW',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert programs with different types
    cursor.executemany("""
        INSERT INTO program_file_mapping (
            program_name, file_path, start_line, end_line, program_type, language
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, [
        ('MAINPROG', 'src/MAINPROG.cbl', 1, 100, 'MAIN', 'COBOL'),
        ('SUBPROG', 'src/SUBPROG.cbl', 1, 50, 'SUBPROGRAM', 'COBOL'),
        ('INTERNAL_PROC', 'src/MAINPROG.cbl', 50, 80, 'PROCEDURE', 'COBOL'),
        ('NESTED_PROC', 'src/MAINPROG.cbl', 81, 95, 'NESTED', 'COBOL')
    ])
    
    # Insert scope with all programs
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, [
        ('FLOW_TEST', 'PROGRAM', 'MAINPROG'),
        ('FLOW_TEST', 'PROGRAM', 'SUBPROG'),
        ('FLOW_TEST', 'PROGRAM', 'INTERNAL_PROC'),
        ('FLOW_TEST', 'PROGRAM', 'NESTED_PROC')
    ])
    
    test_db.commit()
    
    # Create exporter with filter_internal_procedures=False
    exporter = MigrationFlowExporter(test_db, filter_internal_procedures=False)
    
    # Query scope
    scope = exporter._query_scope('FLOW_TEST')
    
    # Verify all programs are included
    program_names = [p['name'] for p in scope['programs']]
    assert 'MAINPROG' in program_names
    assert 'SUBPROG' in program_names
    assert 'INTERNAL_PROC' in program_names
    assert 'NESTED_PROC' in program_names


def test_config_include_file_metadata_true(test_db):
    """Test that include_file_metadata=True adds file metadata."""
    cursor = test_db.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_TEST', 'Test Flow', 'MAINPROG', 'JCL',
        1, 0, 0, 1000, 20, 50.0, 'LOW',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert program with metadata
    cursor.execute("""
        INSERT INTO program_file_mapping (
            program_name, file_path, start_line, end_line, program_type, language
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, ('MAINPROG', 'src/MAINPROG.cbl', 1, 100, 'MAIN', 'COBOL'))
    
    # Insert scope
    cursor.execute("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, ('FLOW_TEST', 'PROGRAM', 'MAINPROG'))
    
    test_db.commit()
    
    # Create exporter with include_file_metadata=True (default)
    exporter = MigrationFlowExporter(test_db, include_file_metadata=True)
    
    # Query scope
    scope = exporter._query_scope('FLOW_TEST')
    
    # Verify metadata is included
    assert len(scope['programs']) == 1
    prog = scope['programs'][0]
    assert prog['name'] == 'MAINPROG'
    assert prog['filePath'] == 'src/MAINPROG.cbl'
    assert prog['startLine'] == 1
    assert prog['endLine'] == 100
    assert prog['programType'] == 'MAIN'
    assert prog['language'] == 'COBOL'


def test_config_include_file_metadata_false(test_db):
    """Test that include_file_metadata=False excludes file metadata."""
    cursor = test_db.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_TEST', 'Test Flow', 'MAINPROG', 'JCL',
        1, 0, 0, 1000, 20, 50.0, 'LOW',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert program with metadata
    cursor.execute("""
        INSERT INTO program_file_mapping (
            program_name, file_path, start_line, end_line, program_type, language
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, ('MAINPROG', 'src/MAINPROG.cbl', 1, 100, 'MAIN', 'COBOL'))
    
    # Insert scope
    cursor.execute("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, ('FLOW_TEST', 'PROGRAM', 'MAINPROG'))
    
    test_db.commit()
    
    # Create exporter with include_file_metadata=False
    exporter = MigrationFlowExporter(test_db, include_file_metadata=False)
    
    # Query scope
    scope = exporter._query_scope('FLOW_TEST')
    
    # Verify metadata is excluded
    assert len(scope['programs']) == 1
    prog = scope['programs'][0]
    assert prog['name'] == 'MAINPROG'
    assert 'filePath' not in prog
    assert 'startLine' not in prog
    assert 'endLine' not in prog
    assert 'programType' not in prog
    assert 'language' not in prog


def test_config_combinations_with_extended_scope(test_db):
    """Test configuration combinations with extended_scope flag."""
    cursor = test_db.cursor()
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Create program_metadata table for extended_scope
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_metadata (
            program_name TEXT PRIMARY KEY,
            is_utility INTEGER,
            call_count INTEGER,
            classification TEXT,
            shared_by_flow_count INTEGER,
            naming_pattern TEXT,
            created_date TEXT,
            updated_date TEXT
        )
    """)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_TEST', 'Test Flow', 'MAINPROG', 'JCL',
        2, 0, 0, 1000, 20, 50.0, 'LOW',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert programs
    cursor.executemany("""
        INSERT INTO program_file_mapping (
            program_name, file_path, start_line, end_line, program_type, language
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, [
        ('MAINPROG', 'src/MAINPROG.cbl', 1, 100, 'MAIN', 'COBOL'),
        ('UTILPROG', 'src/UTILPROG.cbl', 1, 50, 'SUBPROGRAM', 'COBOL')
    ])
    
    # Mark UTILPROG as utility in program_metadata
    cursor.execute("""
        INSERT INTO program_metadata (
            program_name, is_utility, call_count, classification,
            shared_by_flow_count, naming_pattern, created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, ('UTILPROG', 1, 5, 'UTILITY', 3, None, '2024-01-01', '2024-01-01'))
    
    # Insert scope
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, [
        ('FLOW_TEST', 'PROGRAM', 'MAINPROG'),
        ('FLOW_TEST', 'PROGRAM', 'UTILPROG')
    ])
    
    test_db.commit()
    
    # Test combination: filter=True, metadata=True, extended_scope=True
    exporter = MigrationFlowExporter(
        test_db, 
        filter_internal_procedures=True,
        include_file_metadata=True
    )
    exporter.extended_scope = True
    
    scope = exporter._query_scope('FLOW_TEST')
    
    # Verify all features work together
    assert len(scope['programs']) == 2
    
    # Check MAINPROG
    mainprog = next(p for p in scope['programs'] if p['name'] == 'MAINPROG')
    assert mainprog['filePath'] == 'src/MAINPROG.cbl'
    assert mainprog['programType'] == 'MAIN'
    assert mainprog['is_utility'] == False
    
    # Check UTILPROG
    utilprog = next(p for p in scope['programs'] if p['name'] == 'UTILPROG')
    assert utilprog['filePath'] == 'src/UTILPROG.cbl'
    assert utilprog['programType'] == 'SUBPROGRAM'
    assert utilprog['is_utility'] == True



# ============================================================================
# Property 5: Backward Compatibility
# ============================================================================

# Property 5: Backward Compatibility
# Feature: flow-analysis-enhancements, Property 5: Backward Compatibility
# Validates: Requirements 4.3, 4.5
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.too_slow, HealthCheck.data_too_large]
)
@given(
    flow_data=st.fixed_dictionaries({
        'flow_id': st.text(min_size=5, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        'entry_program': st.text(min_size=3, max_size=8, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        'programs': st.lists(
            st.fixed_dictionaries({
                'name': st.text(min_size=3, max_size=8, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
                'program_type': st.sampled_from(['MAIN', 'SUBPROGRAM', 'PROCEDURE', 'NESTED', 'ENTRY_POINT'])
            }),
            min_size=1,
            max_size=10,
            unique_by=lambda x: x['name']
        )
    })
)
def test_property_5_backward_compatibility(flow_data):
    """
    Property 5: Backward Compatibility
    
    For any flow export with filter_internal_procedures=False, the programs list
    should match the current behavior and include all programs from flow_scope
    regardless of program_type.
    
    This property ensures that disabling the filtering configuration restores
    the original behavior, maintaining backward compatibility for existing
    workflows.
    """
    # Create in-memory database
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        flow_data['flow_id'],
        'Test Flow',
        flow_data['entry_program'],
        'JCL',
        len(flow_data['programs']),
        0,
        0,
        1000,
        20,
        50.0,
        'LOW',
        '2024-01-01',
        '2024-01-01'
    ))
    
    # Insert programs with various types
    for prog in flow_data['programs']:
        cursor.execute("""
            INSERT INTO program_file_mapping (
                program_name, file_path, start_line, end_line, program_type, language
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (
            prog['name'],
            f"src/{prog['name']}.cbl",
            1,
            100,
            prog['program_type'],
            'COBOL'
        ))
        
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_data['flow_id'], 'PROGRAM', prog['name']))
    
    conn.commit()
    
    # Export with filter_internal_procedures=False (backward compatible mode)
    exporter_no_filter = MigrationFlowExporter(
        conn,
        filter_internal_procedures=False,
        include_file_metadata=False
    )
    scope_no_filter = exporter_no_filter._query_scope(flow_data['flow_id'])
    
    # Export with filter_internal_procedures=True (new behavior)
    exporter_with_filter = MigrationFlowExporter(
        conn,
        filter_internal_procedures=True,
        include_file_metadata=False
    )
    scope_with_filter = exporter_with_filter._query_scope(flow_data['flow_id'])
    
    # Property 1: With filter=False, all programs should be included
    programs_no_filter = {p['name'] for p in scope_no_filter['programs']}
    expected_all_programs = {p['name'] for p in flow_data['programs']}
    assert programs_no_filter == expected_all_programs, \
        f"With filter=False, expected all programs {expected_all_programs}, got {programs_no_filter}"
    
    # Property 2: With filter=True, only standalone programs should be included
    programs_with_filter = {p['name'] for p in scope_with_filter['programs']}
    standalone_types = {'MAIN', 'SUBPROGRAM', 'ENTRY_POINT', 'CSECT', 'ROUTINE'}
    expected_standalone = {p['name'] for p in flow_data['programs'] if p['program_type'] in standalone_types}
    assert programs_with_filter == expected_standalone, \
        f"With filter=True, expected standalone programs {expected_standalone}, got {programs_with_filter}"
    
    # Property 3: With filter=False, count should match or exceed filter=True count
    assert len(scope_no_filter['programs']) >= len(scope_with_filter['programs']), \
        "Backward compatible mode should include at least as many programs as filtered mode"
    
    # Property 4: All programs in filtered mode should also be in unfiltered mode
    assert programs_with_filter.issubset(programs_no_filter), \
        "All filtered programs should be present in unfiltered export"
    
    # Property 5: With filter=False and metadata=False, programs should be simple name-only objects
    for prog in scope_no_filter['programs']:
        assert 'name' in prog, "Program should have name field"
        # In backward compatible mode without metadata, should not have file metadata
        # (unless it was added by some other mechanism)
    
    conn.close()



class TestErrorHandling:
    """Test suite for error handling and graceful degradation."""
    
    def test_missing_program_file_mapping_table(self):
        """Test that missing program_file_mapping table is handled gracefully."""
        # Create database without program_file_mapping table
        conn = sqlite3.connect(':memory:')
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        cursor = conn.cursor()
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                priority, business_domain,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST1', 'Test Flow', 'TEST1', 'JCL',
            2, 1, 1,
            1000, 20, 50.0, 'LOW',
            1, 'Test',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert scope
        cursor.executemany("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, [
            ('FLOW_TEST1', 'PROGRAM', 'TEST1'),
            ('FLOW_TEST1', 'PROGRAM', 'TEST2'),
            ('FLOW_TEST1', 'COPYBOOK', 'TESTCOPY'),
            ('FLOW_TEST1', 'DATASET', 'TEST.DATA')
        ])
        
        conn.commit()
        
        # Create exporter - should not fail
        exporter = MigrationFlowExporter(conn)
        
        # Verify metadata_available flag is False
        assert exporter._metadata_available is False
        
        # Export should succeed with fallback behavior
        result = exporter.export_flows(['FLOW_TEST1'])
        
        assert len(result['flows']) == 1
        flow = result['flows'][0]
        
        # Verify programs are included (no filtering)
        assert len(flow['scope']['programs']) == 2
        assert flow['scope']['programs'][0]['name'] == 'TEST1'
        assert flow['scope']['programs'][1]['name'] == 'TEST2'
        
        # Verify no file metadata is present
        assert 'filePath' not in flow['scope']['programs'][0]
        assert 'filePath' not in flow['scope']['programs'][1]
        
        conn.close()
    
    def test_database_query_failure_recovery(self):
        """Test recovery from database query failures."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        cursor = conn.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                priority, business_domain,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST1', 'Test Flow', 'TEST1', 'JCL',
            1, 0, 0,
            1000, 20, 50.0, 'LOW',
            1, 'Test',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST1', 'PROGRAM', 'TEST1'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Verify metadata is available
        assert exporter._metadata_available is True
        
        # Drop the program_file_mapping table to simulate failure
        cursor.execute("DROP TABLE program_file_mapping")
        conn.commit()
        
        # Query should still succeed with fallback
        scope = exporter._query_scope('FLOW_TEST1')
        
        assert len(scope['programs']) == 1
        assert scope['programs'][0]['name'] == 'TEST1'
        
        conn.close()
    
    def test_invalid_program_type_values(self):
        """Test handling of invalid program_type values."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        cursor = conn.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Insert program with invalid program_type
        cursor.execute("""
            INSERT INTO program_file_mapping (
                program_name, file_path, start_line, end_line, program_type, language
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, ('TEST1', 'src/TEST1.cbl', 1, 100, 'INVALID_TYPE', 'COBOL'))
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                priority, business_domain,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST1', 'Test Flow', 'TEST1', 'JCL',
            1, 0, 0,
            1000, 20, 50.0, 'LOW',
            1, 'Test',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert scope
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, ('FLOW_TEST1', 'PROGRAM', 'TEST1'))
        
        conn.commit()
        
        # Create exporter
        exporter = MigrationFlowExporter(conn)
        
        # Check if program is standalone - should treat invalid type as standalone (conservative)
        is_standalone = exporter._is_standalone_program('TEST1')
        
        # Invalid types should be treated as standalone (conservative approach)
        assert is_standalone is False  # Not in the standalone list
        
        conn.close()
    
    def test_graceful_degradation_with_partial_data(self):
        """Test that export succeeds with partial metadata."""
        # Create database with program_file_mapping table
        conn = sqlite3.connect(':memory:')
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        cursor = conn.cursor()
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Create inventory table
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT
            )
        """)
        
        # Insert metadata for both programs, but TEST2 has NULL file_path
        cursor.executemany("""
            INSERT INTO program_file_mapping (
                program_name, file_path, start_line, end_line, program_type, language
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, [
            ('TEST1', 'src/TEST1.cbl', 1, 100, 'MAIN', 'COBOL'),
            ('TEST2', None, None, None, 'MAIN', 'COBOL')  # Has type but no file metadata
        ])
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                priority, business_domain,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_TEST1', 'Test Flow', 'TEST1', 'JCL',
            2, 1, 0,
            1000, 20, 50.0, 'LOW',
            1, 'Test',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert scope with two programs (only one has complete metadata)
        cursor.executemany("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, [
            ('FLOW_TEST1', 'PROGRAM', 'TEST1'),
            ('FLOW_TEST1', 'PROGRAM', 'TEST2'),  # Has type but no file metadata
            ('FLOW_TEST1', 'COPYBOOK', 'TESTCOPY')  # No metadata
        ])
        
        conn.commit()
        
        # Create exporter with filtering disabled to test metadata graceful degradation
        exporter = MigrationFlowExporter(conn, filter_internal_procedures=False)
        
        # Export should succeed
        result = exporter.export_flows(['FLOW_TEST1'])
        
        assert len(result['flows']) == 1
        flow = result['flows'][0]
        
        # Verify both programs are included
        assert len(flow['scope']['programs']) == 2
        
        # TEST1 should have metadata
        test1 = next(p for p in flow['scope']['programs'] if p['name'] == 'TEST1')
        assert 'filePath' in test1
        assert test1['filePath'] == 'src/TEST1.cbl'
        assert test1['programType'] == 'MAIN'
        
        # TEST2 should not have file metadata (graceful degradation)
        test2 = next(p for p in flow['scope']['programs'] if p['name'] == 'TEST2')
        assert 'filePath' not in test2
        assert test2['name'] == 'TEST2'
        
        # TESTCOPY should not have file path (no inventory entry)
        testcopy = next(c for c in flow['scope']['copybooks'] if c['name'] == 'TESTCOPY')
        assert 'filePath' not in testcopy
        
        conn.close()



# ============================================================================
# Property 4: Graceful Degradation
# Feature: flow-analysis-enhancements, Property 4: Graceful Degradation
# Validates: Requirements 2.6, 4.4
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.too_slow, HealthCheck.data_too_large]
)
@given(
    flow_data=st.fixed_dictionaries({
        'flow_id': st.text(min_size=5, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        'entry_program': st.text(min_size=3, max_size=8, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
        'programs': st.lists(
            st.fixed_dictionaries({
                'name': st.text(min_size=3, max_size=8, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
                'has_metadata': st.booleans()  # Some programs have metadata, some don't
            }),
            min_size=1,
            max_size=10,
            unique_by=lambda x: x['name']
        ),
        'copybooks': st.lists(
            st.fixed_dictionaries({
                'name': st.text(min_size=3, max_size=8, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
                'has_file_path': st.booleans()  # Some copybooks have file paths, some don't
            }),
            min_size=0,
            max_size=5,
            unique_by=lambda x: x['name']
        )
    })
)
def test_property_4_graceful_degradation(flow_data):
    """
    Property 4: Graceful Degradation
    
    For any program without a program_file_mapping entry, the export should
    succeed and include the program name without file metadata fields, rather
    than failing or including null values.
    
    This property ensures that missing metadata is handled gracefully and
    doesn't cause export failures or data quality issues.
    """
    # Create in-memory database
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Create inventory table for copybooks
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            artifact_name TEXT,
            artifact_type TEXT,
            file_path TEXT
        )
    """)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        flow_data['flow_id'],
        'Test Flow',
        flow_data['entry_program'],
        'JCL',
        len(flow_data['programs']),
        len(flow_data['copybooks']),
        0,
        1000,
        20,
        50.0,
        'LOW',
        '2024-01-01',
        '2024-01-01'
    ))
    
    # Track programs with and without metadata
    programs_with_metadata = []
    programs_without_metadata = []
    
    # Insert programs - only some have metadata
    for prog in flow_data['programs']:
        if prog['has_metadata']:
            cursor.execute("""
                INSERT INTO program_file_mapping (
                    program_name, file_path, start_line, end_line, program_type, language
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                prog['name'],
                f"src/{prog['name']}.cbl",
                1,
                100,
                'MAIN',
                'COBOL'
            ))
            programs_with_metadata.append(prog['name'])
        else:
            programs_without_metadata.append(prog['name'])
        
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_data['flow_id'], 'PROGRAM', prog['name']))
    
    # Track copybooks with and without file paths
    copybooks_with_path = []
    copybooks_without_path = []
    
    # Insert copybooks - only some have file paths
    for copybook in flow_data['copybooks']:
        if copybook['has_file_path']:
            cursor.execute("""
                INSERT INTO inventory (artifact_name, artifact_type, file_path)
                VALUES (?, ?, ?)
            """, (copybook['name'], 'COPYBOOK', f"src/copybooks/{copybook['name']}.cpy"))
            copybooks_with_path.append(copybook['name'])
        else:
            copybooks_without_path.append(copybook['name'])
        
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_data['flow_id'], 'COPYBOOK', copybook['name']))
    
    conn.commit()
    
    # Export with filtering disabled to test metadata graceful degradation
    exporter = MigrationFlowExporter(
        conn,
        filter_internal_procedures=False,
        include_file_metadata=True
    )
    
    # Export should succeed regardless of missing metadata
    try:
        result = exporter.export_flows([flow_data['flow_id']])
    except Exception as e:
        pytest.fail(f"Export failed with missing metadata: {e}")
    
    # Verify export succeeded
    assert len(result['flows']) == 1
    flow = result['flows'][0]
    
    # Verify all programs are included
    assert len(flow['scope']['programs']) == len(flow_data['programs'])
    
    # Verify programs with metadata have filePath
    for prog_name in programs_with_metadata:
        prog = next((p for p in flow['scope']['programs'] if p['name'] == prog_name), None)
        assert prog is not None, f"Program {prog_name} not found in export"
        assert 'filePath' in prog, f"Program {prog_name} should have filePath"
        assert prog['filePath'] == f"src/{prog_name}.cbl"
        assert 'programType' in prog
        assert prog['programType'] == 'MAIN'
    
    # Verify programs without metadata don't have filePath (graceful degradation)
    for prog_name in programs_without_metadata:
        prog = next((p for p in flow['scope']['programs'] if p['name'] == prog_name), None)
        assert prog is not None, f"Program {prog_name} not found in export"
        assert 'filePath' not in prog, f"Program {prog_name} should not have filePath"
        assert prog['name'] == prog_name
    
    # Verify all copybooks are included
    assert len(flow['scope']['copybooks']) == len(flow_data['copybooks'])
    
    # Verify copybooks with file paths have filePath
    for copybook_name in copybooks_with_path:
        copybook = next((c for c in flow['scope']['copybooks'] if c['name'] == copybook_name), None)
        assert copybook is not None, f"Copybook {copybook_name} not found in export"
        assert 'filePath' in copybook, f"Copybook {copybook_name} should have filePath"
        assert copybook['filePath'] == f"src/copybooks/{copybook_name}.cpy"
    
    # Verify copybooks without file paths don't have filePath (graceful degradation)
    for copybook_name in copybooks_without_path:
        copybook = next((c for c in flow['scope']['copybooks'] if c['name'] == copybook_name), None)
        assert copybook is not None, f"Copybook {copybook_name} not found in export"
        assert 'filePath' not in copybook, f"Copybook {copybook_name} should not have filePath"
        assert copybook['name'] == copybook_name
    
    conn.close()
