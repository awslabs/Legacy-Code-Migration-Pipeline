#!/usr/bin/env python3
"""
Unit tests for LanguageDetector class.

Tests the _detect_by_extension() method and other core functionality.
"""

import pytest
from tools.legacy_analyzer.language_detector import LanguageDetector


class TestLanguageDetectorExtension:
    """Unit tests for extension-based language detection."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.detector = LanguageDetector()
    
    def test_natural_extensions_return_natural(self):
        """Test that all Natural extensions return 'Natural'."""
        natural_extensions = ['.nsp', '.nsn', '.nsc', '.nsg', '.nsl', '.nsd', '.nsa', '.ns8']
        
        for ext in natural_extensions:
            file_path = f"test_file{ext}"
            result = self.detector._detect_by_extension(file_path)
            assert result == 'NATURAL', f"Extension {ext} should return 'NATURAL', got {result}"
    
    def test_cobol_extensions_return_cobol(self):
        """Test that COBOL extensions return 'COBOL'."""
        cobol_extensions = ['.cbl', '.cob', '.cobol', '.cpy', '.copy']
        
        for ext in cobol_extensions:
            file_path = f"test_file{ext}"
            result = self.detector._detect_by_extension(file_path)
            assert result == 'COBOL', f"Extension {ext} should return 'COBOL', got {result}"
    
    def test_ambiguous_extensions_return_none(self):
        """Test that ambiguous extensions return None."""
        ambiguous_extensions = ['.txt', '.dat', '.src', '.mbr']
        
        for ext in ambiguous_extensions:
            file_path = f"test_file{ext}"
            result = self.detector._detect_by_extension(file_path)
            assert result is None, f"Ambiguous extension {ext} should return None, got {result}"
    
    def test_unknown_extensions_return_none(self):
        """Test that unknown extensions return None."""
        unknown_extensions = ['.xyz', '.unknown', '.foo', '.bar', '.test']
        
        for ext in unknown_extensions:
            file_path = f"test_file{ext}"
            result = self.detector._detect_by_extension(file_path)
            assert result is None, f"Unknown extension {ext} should return None, got {result}"
    
    def test_extension_case_insensitive(self):
        """Test that extension detection is case-insensitive."""
        test_cases = [
            ('test.NSP', 'NATURAL'),
            ('test.Nsp', 'NATURAL'),
            ('test.CBL', 'COBOL'),
            ('test.Cbl', 'COBOL'),
        ]
        
        for file_path, expected in test_cases:
            result = self.detector._detect_by_extension(file_path)
            assert result == expected, f"File {file_path} should return {expected}, got {result}"
    
    def test_file_with_no_extension(self):
        """Test that files with no extension return None."""
        file_path = "test_file_no_extension"
        result = self.detector._detect_by_extension(file_path)
        assert result is None, "File with no extension should return None"
    
    def test_file_with_path(self):
        """Test that extension detection works with full paths."""
        test_cases = [
            ('/path/to/file.nsp', 'NATURAL'),
            ('/another/path/program.cbl', 'COBOL'),
            ('relative/path/script.rexx', 'REXX'),
            ('./local/file.jcl', 'JCL'),
        ]
        
        for file_path, expected in test_cases:
            result = self.detector._detect_by_extension(file_path)
            assert result == expected, f"File {file_path} should return {expected}, got {result}"
    
    def test_all_supported_languages(self):
        """Test that all supported language extensions are correctly mapped."""
        test_cases = [
            ('.pli', 'PLI'),
            ('.pl1', 'PLI'),
            ('.inc', 'PLI'),
            ('.jcl', 'JCL'),
            ('.rexx', 'REXX'),
            ('.rex', 'REXX'),
            ('.rpg', 'RPG'),
            ('.rpgle', 'RPG'),
            ('.sqlrpgle', 'RPG'),
            ('.rpg38', 'RPG'),
            ('.asm', 'ASM'),
            ('.s', 'ASM'),
            ('.mac', 'ASM'),
        ]
        
        for ext, expected in test_cases:
            file_path = f"test{ext}"
            result = self.detector._detect_by_extension(file_path)
            assert result == expected, f"Extension {ext} should return {expected}, got {result}"


class TestLanguageDetectorContent:
    """Unit tests for content-based language detection."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.detector = LanguageDetector()
    
    def test_natural_patterns_recognized(self):
        """Test that Natural patterns are recognized in content."""
        # Note: Current Natural patterns require sequence numbers or specific format
        # Using patterns that work with current implementation
        natural_content = """000010 DEFINE DATA
000020 LOCAL
000030 1 #VAR (A10)
000040 END-DEFINE
000050 CALLNAT 'SUBPROG'
000060 END
"""
        result = self.detector._detect_by_content(natural_content)
        assert result == 'NATURAL', f"Expected NATURAL for Natural content, got {result}"
    
    def test_cobol_patterns_recognized(self):
        """Test that COBOL patterns are recognized in content."""
        cobol_content = """IDENTIFICATION DIVISION.
PROGRAM-ID. TESTPROG.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VAR PIC X(10).
PROCEDURE DIVISION.
    MOVE 'TEST' TO WS-VAR.
    DISPLAY WS-VAR.
    STOP RUN.
"""
        result = self.detector._detect_by_content(cobol_content)
        assert result == 'COBOL', f"Expected COBOL for COBOL content, got {result}"
    
    def test_jcl_patterns_recognized(self):
        """Test that JCL patterns are recognized in content."""
        jcl_content = """//TESTJOB JOB (ACCT),'TEST JOB',CLASS=A
//STEP1   EXEC PGM=TESTPROG
//SYSOUT  DD SYSOUT=*
//SYSIN   DD *
TEST DATA
/*
"""
        result = self.detector._detect_by_content(jcl_content)
        assert result == 'JCL', f"Expected JCL for JCL content, got {result}"
    
    def test_empty_content_returns_none(self):
        """Test that empty content returns None."""
        result = self.detector._detect_by_content("")
        assert result is None, f"Expected None for empty content, got {result}"
    
    def test_whitespace_only_content_returns_none(self):
        """Test that whitespace-only content returns None."""
        result = self.detector._detect_by_content("   \n\n\t  \n")
        assert result is None, f"Expected None for whitespace-only content, got {result}"
    
    def test_no_patterns_match_returns_none(self):
        """Test that content with no matching patterns returns None."""
        random_content = "This is just some random text\nwith no programming patterns\nat all."
        result = self.detector._detect_by_content(random_content)
        assert result is None, f"Expected None for content with no patterns, got {result}"
    
    def test_highest_score_wins(self):
        """Test that language with highest score is returned."""
        # Content with both COBOL and weak patterns
        mixed_content = """IDENTIFICATION DIVISION.
PROGRAM-ID. TESTPROG.
PROCEDURE DIVISION.
    MOVE X TO Y.
"""
        result = self.detector._detect_by_content(mixed_content)
        # COBOL should win due to strong division patterns
        assert result == 'COBOL', f"Expected COBOL for mixed content, got {result}"


class TestLanguageDetectorConfidence:
    """Unit tests for detect_with_confidence() method."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.detector = LanguageDetector()
    
    def test_confidence_high_for_extension_detection(self):
        """Test that confidence is 'high' for extension-based detection."""
        # Create a temporary file with Natural extension
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.nsp', delete=False) as f:
            f.write("Some content")
            temp_path = f.name
        
        try:
            language, confidence, details = self.detector.detect_with_confidence(temp_path)
            
            assert language == 'NATURAL', f"Expected NATURAL, got {language}"
            assert confidence == 'high', f"Expected 'high' confidence for extension detection, got {confidence}"
            assert details['method'] == 'extension', f"Expected method 'extension', got {details['method']}"
        finally:
            os.unlink(temp_path)
    
    def test_confidence_medium_for_content_detection(self):
        """Test that confidence is 'medium' for content-based detection with high score."""
        # Create a temporary file with ambiguous extension but clear COBOL content
        import tempfile
        import os
        
        cobol_content = """IDENTIFICATION DIVISION.
PROGRAM-ID. TESTPROG.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VAR PIC X(10).
PROCEDURE DIVISION.
    MOVE 'TEST' TO WS-VAR.
    DISPLAY WS-VAR.
    STOP RUN.
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(cobol_content)
            temp_path = f.name
        
        try:
            language, confidence, details = self.detector.detect_with_confidence(temp_path)
            
            assert language == 'COBOL', f"Expected COBOL, got {language}"
            assert confidence == 'medium', f"Expected 'medium' confidence for content detection, got {confidence}"
            assert details['method'] == 'content', f"Expected method 'content', got {details['method']}"
        finally:
            os.unlink(temp_path)
    
    def test_confidence_low_for_weak_content_detection(self):
        """Test that confidence is 'low' for content-based detection with low score."""
        # Create a temporary file with ambiguous extension and weak patterns
        import tempfile
        import os
        
        weak_content = """MOVE X TO Y.
IF A = B
    DISPLAY 'TEST'
END-IF.
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(weak_content)
            temp_path = f.name
        
        try:
            language, confidence, details = self.detector.detect_with_confidence(temp_path)
            
            # Should detect something but with low confidence
            if language:
                assert confidence == 'low', f"Expected 'low' confidence for weak content, got {confidence}"
                assert details['method'] == 'content', f"Expected method 'content', got {details['method']}"
        finally:
            os.unlink(temp_path)
    
    def test_confidence_none_for_no_detection(self):
        """Test that confidence is 'none' when no language is detected."""
        # Create a temporary file with unknown extension and no patterns
        import tempfile
        import os
        
        random_content = "This is just random text with no programming patterns."
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.xyz', delete=False) as f:
            f.write(random_content)
            temp_path = f.name
        
        try:
            language, confidence, details = self.detector.detect_with_confidence(temp_path)
            
            assert language is None, f"Expected None, got {language}"
            assert confidence == 'none', f"Expected 'none' confidence, got {confidence}"
            # Method is 'content' because content analysis was attempted (even though it returned None)
            assert details['method'] == 'content', f"Expected method 'content', got {details['method']}"
        finally:
            os.unlink(temp_path)
    
    def test_details_dictionary_contains_correct_fields(self):
        """Test that details dictionary contains all required fields."""
        # Create a temporary file with Natural extension
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.nsp', delete=False) as f:
            f.write("Some content")
            temp_path = f.name
        
        try:
            language, confidence, details = self.detector.detect_with_confidence(temp_path)
            
            # Check all required fields are present
            assert 'extension_guess' in details, "Details should contain 'extension_guess'"
            assert 'content_scores' in details, "Details should contain 'content_scores'"
            assert 'final_language' in details, "Details should contain 'final_language'"
            assert 'method' in details, "Details should contain 'method'"
            
            # Check values are correct
            assert details['extension_guess'] == 'NATURAL', f"Expected extension_guess 'NATURAL', got {details['extension_guess']}"
            assert details['final_language'] == 'NATURAL', f"Expected final_language 'NATURAL', got {details['final_language']}"
            assert details['method'] == 'extension', f"Expected method 'extension', got {details['method']}"
        finally:
            os.unlink(temp_path)
    
    def test_extension_detection_skips_content_analysis(self):
        """Test that extension detection doesn't populate content_scores."""
        # Create a temporary file with Natural extension
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.nsp', delete=False) as f:
            f.write("Some content")
            temp_path = f.name
        
        try:
            language, confidence, details = self.detector.detect_with_confidence(temp_path)
            
            # When extension detection succeeds, content_scores should be empty
            assert details['content_scores'] == {}, f"Expected empty content_scores for extension detection, got {details['content_scores']}"
        finally:
            os.unlink(temp_path)
    
    def test_content_detection_populates_scores(self):
        """Test that content detection populates content_scores."""
        # Create a temporary file with unknown extension (not ambiguous, just unknown)
        # This will trigger content detection
        import tempfile
        import os
        
        # Use stronger COBOL patterns to ensure detection
        cobol_content = """000010 IDENTIFICATION DIVISION.
000020 PROGRAM-ID. TESTPROG.
000030 DATA DIVISION.
000040 WORKING-STORAGE SECTION.
000050 01 WS-VAR PIC X(10).
000060 PROCEDURE DIVISION.
000070     MOVE 'TEST' TO WS-VAR.
000080     DISPLAY WS-VAR.
000090     STOP RUN.
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.unknown', delete=False) as f:
            f.write(cobol_content)
            temp_path = f.name
        
        try:
            language, confidence, details = self.detector.detect_with_confidence(temp_path)
            
            # When content detection is used, content_scores should be populated
            assert len(details['content_scores']) > 0, "Expected non-empty content_scores for content detection"
            assert 'COBOL' in details['content_scores'], "Expected COBOL in content_scores"
            assert language == 'COBOL', f"Expected COBOL to be detected, got {language}"
        finally:
            os.unlink(temp_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
