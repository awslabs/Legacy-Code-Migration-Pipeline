"""
Unit tests for InterfaceSchemaManager

Tests cover:
- Table creation (inbound_interfaces and outbound_interfaces)
- Idempotent table creation (calling create_tables multiple times)
- Table existence checks
- Schema version retrieval
- Table information retrieval
"""

import pytest
import sqlite3
import tempfile
import os

from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    conn = sqlite3.Connection(path)
    
    yield conn
    
    conn.close()
    os.unlink(path)


@pytest.fixture
def schema_manager(temp_db):
    """Create an InterfaceSchemaManager instance."""
    return InterfaceSchemaManager(temp_db)


def test_create_inbound_interfaces_table(schema_manager, temp_db):
    """Test creation of inbound_interfaces table."""
    # Create tables
    schema_manager.create_tables()
    
    # Verify table exists
    assert schema_manager.table_exists('inbound_interfaces')
    
    # Verify table schema
    cursor = temp_db.cursor()
    cursor.execute("PRAGMA table_info(inbound_interfaces)")
    columns = cursor.fetchall()
    
    column_names = [col[1] for col in columns]
    assert 'id' in column_names
    assert 'source_name' in column_names
    assert 'target_program' in column_names
    assert 'dependency_type' in column_names
    assert 'is_configured' in column_names
    assert 'metadata' in column_names
    assert 'created_at' in column_names
    
    # Verify indexes exist
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='index' AND tbl_name='inbound_interfaces'
    """)
    indexes = cursor.fetchall()
    index_names = [idx[0] for idx in indexes]
    
    assert 'idx_inbound_target' in index_names
    assert 'idx_inbound_source' in index_names


def test_create_outbound_interfaces_table(schema_manager, temp_db):
    """Test creation of outbound_interfaces table."""
    # Create tables
    schema_manager.create_tables()
    
    # Verify table exists
    assert schema_manager.table_exists('outbound_interfaces')
    
    # Verify table schema
    cursor = temp_db.cursor()
    cursor.execute("PRAGMA table_info(outbound_interfaces)")
    columns = cursor.fetchall()
    
    column_names = [col[1] for col in columns]
    assert 'id' in column_names
    assert 'program_name' in column_names
    assert 'reason' in column_names
    assert 'metadata' in column_names
    assert 'created_at' in column_names
    
    # Verify index exists
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='index' AND tbl_name='outbound_interfaces'
    """)
    indexes = cursor.fetchall()
    index_names = [idx[0] for idx in indexes]
    
    assert 'idx_outbound_program' in index_names


def test_create_tables_idempotent(schema_manager):
    """Test that calling create_tables multiple times doesn't cause errors."""
    # Create tables first time
    schema_manager.create_tables()
    assert schema_manager.table_exists('inbound_interfaces')
    assert schema_manager.table_exists('outbound_interfaces')
    
    # Create tables second time (should not error)
    schema_manager.create_tables()
    assert schema_manager.table_exists('inbound_interfaces')
    assert schema_manager.table_exists('outbound_interfaces')
    
    # Create tables third time (should not error)
    schema_manager.create_tables()
    assert schema_manager.table_exists('inbound_interfaces')
    assert schema_manager.table_exists('outbound_interfaces')


def test_table_exists_check(schema_manager):
    """Test table_exists method."""
    # Before creation
    assert not schema_manager.table_exists('inbound_interfaces')
    assert not schema_manager.table_exists('outbound_interfaces')
    assert not schema_manager.table_exists('nonexistent_table')
    
    # After creation
    schema_manager.create_tables()
    assert schema_manager.table_exists('inbound_interfaces')
    assert schema_manager.table_exists('outbound_interfaces')
    assert not schema_manager.table_exists('nonexistent_table')


def test_get_schema_version(schema_manager):
    """Test schema version retrieval."""
    version = schema_manager.get_schema_version()
    assert version is not None
    assert isinstance(version, str)
    assert len(version) > 0
    # Should be in semantic versioning format
    assert version.count('.') >= 2


def test_get_table_info(schema_manager):
    """Test table info retrieval."""
    # Before creation
    info = schema_manager.get_table_info('inbound_interfaces')
    assert info is None
    
    # After creation
    schema_manager.create_tables()
    
    # Get inbound_interfaces info
    info = schema_manager.get_table_info('inbound_interfaces')
    assert info is not None
    assert len(info) > 0
    column_names = [col[1] for col in info]
    assert 'source_name' in column_names
    assert 'target_program' in column_names
    
    # Get outbound_interfaces info
    info = schema_manager.get_table_info('outbound_interfaces')
    assert info is not None
    assert len(info) > 0
    column_names = [col[1] for col in info]
    assert 'program_name' in column_names
    
    # Nonexistent table
    info = schema_manager.get_table_info('nonexistent_table')
    assert info is None


def test_drop_tables(schema_manager):
    """Test dropping tables."""
    # Create tables
    schema_manager.create_tables()
    assert schema_manager.table_exists('inbound_interfaces')
    assert schema_manager.table_exists('outbound_interfaces')
    
    # Drop tables
    schema_manager.drop_tables()
    assert not schema_manager.table_exists('inbound_interfaces')
    assert not schema_manager.table_exists('outbound_interfaces')
    
    # Drop again (should not error)
    schema_manager.drop_tables()
    assert not schema_manager.table_exists('inbound_interfaces')
    assert not schema_manager.table_exists('outbound_interfaces')


def test_unique_constraint_inbound(schema_manager, temp_db):
    """Test UNIQUE constraint on inbound_interfaces."""
    schema_manager.create_tables()
    
    cursor = temp_db.cursor()
    
    # Insert first record
    cursor.execute("""
        INSERT INTO inbound_interfaces 
        (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_A', 'PROGRAM1', 'PROGRAM_CALL', 1))
    temp_db.commit()
    
    # Try to insert duplicate (should fail)
    with pytest.raises(sqlite3.IntegrityError):
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured)
            VALUES (?, ?, ?, ?)
        """, ('EXTERNAL_A', 'PROGRAM1', 'PROGRAM_CALL', 1))
        temp_db.commit()


def test_unique_constraint_outbound(schema_manager, temp_db):
    """Test UNIQUE constraint on outbound_interfaces."""
    schema_manager.create_tables()
    
    cursor = temp_db.cursor()
    
    # Insert first record
    cursor.execute("""
        INSERT INTO outbound_interfaces 
        (program_name, reason)
        VALUES (?, ?)
    """, ('UTILITY_LIB', 'configured'))
    temp_db.commit()
    
    # Try to insert duplicate (should fail)
    with pytest.raises(sqlite3.IntegrityError):
        cursor.execute("""
            INSERT INTO outbound_interfaces 
            (program_name, reason)
            VALUES (?, ?)
        """, ('UTILITY_LIB', 'configured'))
        temp_db.commit()


def test_insert_or_ignore_inbound(schema_manager, temp_db):
    """Test INSERT OR IGNORE for inbound_interfaces."""
    schema_manager.create_tables()
    
    cursor = temp_db.cursor()
    
    # Insert first record
    cursor.execute("""
        INSERT OR IGNORE INTO inbound_interfaces 
        (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_A', 'PROGRAM1', 'PROGRAM_CALL', 1))
    temp_db.commit()
    
    # Insert duplicate with OR IGNORE (should not error)
    cursor.execute("""
        INSERT OR IGNORE INTO inbound_interfaces 
        (source_name, target_program, dependency_type, is_configured)
        VALUES (?, ?, ?, ?)
    """, ('EXTERNAL_A', 'PROGRAM1', 'PROGRAM_CALL', 1))
    temp_db.commit()
    
    # Verify only one record exists
    cursor.execute("SELECT COUNT(*) FROM inbound_interfaces")
    count = cursor.fetchone()[0]
    assert count == 1


def test_insert_or_ignore_outbound(schema_manager, temp_db):
    """Test INSERT OR IGNORE for outbound_interfaces."""
    schema_manager.create_tables()
    
    cursor = temp_db.cursor()
    
    # Insert first record
    cursor.execute("""
        INSERT OR IGNORE INTO outbound_interfaces 
        (program_name, reason)
        VALUES (?, ?)
    """, ('UTILITY_LIB', 'configured'))
    temp_db.commit()
    
    # Insert duplicate with OR IGNORE (should not error)
    cursor.execute("""
        INSERT OR IGNORE INTO outbound_interfaces 
        (program_name, reason)
        VALUES (?, ?)
    """, ('UTILITY_LIB', 'configured'))
    temp_db.commit()
    
    # Verify only one record exists
    cursor.execute("SELECT COUNT(*) FROM outbound_interfaces")
    count = cursor.fetchone()[0]
    assert count == 1
