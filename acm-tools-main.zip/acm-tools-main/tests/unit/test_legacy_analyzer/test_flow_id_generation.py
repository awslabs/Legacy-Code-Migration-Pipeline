"""
Unit tests for flow ID generation.

Tests the generate_flow_id() function to ensure:
1. Flow IDs are based on program name only (not invocation type)
2. Special characters are sanitized
3. Flow IDs are deterministic
4. Flow IDs are URL-safe
"""

import pytest
from tools.legacy_analyzer.migration.flow_builder import generate_flow_id


class TestFlowIdGeneration:
    """Test suite for flow ID generation."""
    
    def test_flow_id_program_based(self):
        """Flow IDs are based on program name, not invocation type."""
        # Same program should always generate same flow ID
        # regardless of how it's invoked (JCL, CICS, etc.)
        assert generate_flow_id("PAYROLL1") == "FLOW_PAYROLL1"
        assert generate_flow_id("BILLING") == "FLOW_BILLING"
        assert generate_flow_id("ACCTPROG") == "FLOW_ACCTPROG"
    
    def test_flow_id_sanitization(self):
        """Special characters are replaced with underscores."""
        assert generate_flow_id("PAY-ROLL#01") == "FLOW_PAY_ROLL_01"
        assert generate_flow_id("PROG@123") == "FLOW_PROG_123"
        assert generate_flow_id("TEST.PROG") == "FLOW_TEST_PROG"
        assert generate_flow_id("MY-PROG-01") == "FLOW_MY_PROG_01"
    
    def test_flow_id_deterministic(self):
        """Same program always generates same flow ID."""
        prog1_id1 = generate_flow_id("PROG1")
        prog1_id2 = generate_flow_id("PROG1")
        assert prog1_id1 == prog1_id2
        assert prog1_id1 == "FLOW_PROG1"
        
        # Multiple calls should be consistent
        for _ in range(10):
            assert generate_flow_id("TESTPROG") == "FLOW_TESTPROG"
    
    def test_flow_id_uppercase(self):
        """Program names are converted to uppercase."""
        assert generate_flow_id("payroll") == "FLOW_PAYROLL"
        assert generate_flow_id("Billing") == "FLOW_BILLING"
        assert generate_flow_id("MixedCase") == "FLOW_MIXEDCASE"
    
    def test_flow_id_url_safe(self):
        """Flow IDs are URL-safe (no spaces or special chars except underscore)."""
        # Spaces should be replaced
        assert generate_flow_id("MY PROG") == "FLOW_MY_PROG"
        
        # Special characters should be replaced
        assert generate_flow_id("PROG!@#$%") == "FLOW_PROG"
        
        # Only alphanumeric and underscores allowed
        flow_id = generate_flow_id("TEST-PROG#123")
        assert all(c.isalnum() or c == '_' for c in flow_id)
    
    def test_flow_id_multiple_underscores_collapsed(self):
        """Multiple consecutive underscores are collapsed into one."""
        assert generate_flow_id("PROG---123") == "FLOW_PROG_123"
        assert generate_flow_id("TEST___PROG") == "FLOW_TEST_PROG"
        assert generate_flow_id("A--B--C") == "FLOW_A_B_C"
    
    def test_flow_id_leading_trailing_underscores_removed(self):
        """Leading and trailing underscores are removed."""
        assert generate_flow_id("-PROG-") == "FLOW_PROG"
        assert generate_flow_id("--TEST--") == "FLOW_TEST"
        assert generate_flow_id("___PROG___") == "FLOW_PROG"
    
    def test_flow_id_numeric_programs(self):
        """Programs with numeric names work correctly."""
        assert generate_flow_id("12345") == "FLOW_12345"
        assert generate_flow_id("PROG123") == "FLOW_PROG123"
        assert generate_flow_id("123PROG") == "FLOW_123PROG"
    
    def test_flow_id_with_underscores(self):
        """Programs with underscores are preserved."""
        assert generate_flow_id("MY_PROG") == "FLOW_MY_PROG"
        assert generate_flow_id("TEST_PROG_01") == "FLOW_TEST_PROG_01"
    
    def test_flow_id_empty_program_name(self):
        """Empty program name raises ValueError."""
        with pytest.raises(ValueError, match="program_name cannot be empty"):
            generate_flow_id("")
    
    def test_flow_id_only_special_chars(self):
        """Program name with only special chars raises ValueError."""
        with pytest.raises(ValueError, match="resulted in empty flow ID"):
            generate_flow_id("---")
        
        with pytest.raises(ValueError, match="resulted in empty flow ID"):
            generate_flow_id("@#$%")
    
    def test_flow_id_real_world_examples(self):
        """Test with real-world mainframe program names."""
        # Common COBOL program naming patterns
        assert generate_flow_id("COBPROG1") == "FLOW_COBPROG1"
        assert generate_flow_id("PAYROLL") == "FLOW_PAYROLL"
        assert generate_flow_id("BILLING") == "FLOW_BILLING"
        
        # Programs with prefixes/suffixes
        assert generate_flow_id("BATCH001") == "FLOW_BATCH001"
        assert generate_flow_id("ONLINE99") == "FLOW_ONLINE99"
        
        # Programs with special naming conventions
        assert generate_flow_id("PAY-001") == "FLOW_PAY_001"
        assert generate_flow_id("ACCT.PROG") == "FLOW_ACCT_PROG"
    
    def test_flow_id_one_flow_per_program(self):
        """
        A program invoked in multiple ways gets ONE flow ID.
        
        This is the key design principle: one flow per entry point program,
        not one flow per invocation type.
        """
        # PAYROLL1 can be invoked by:
        # - JCL: PAYROLL01
        # - JCL: PAYWEEK
        # - CICS Transaction: PAY1
        # - CICS Program (CSD): PAYROLL1
        # - Screen: PAYSCREEN
        # But it should have only ONE flow ID
        
        flow_id = generate_flow_id("PAYROLL1")
        assert flow_id == "FLOW_PAYROLL1"
        
        # Regardless of invocation type, same flow ID
        # (invocation types are tracked separately in flow_entry_types table)
        assert generate_flow_id("PAYROLL1") == flow_id
        assert generate_flow_id("PAYROLL1") == flow_id
        assert generate_flow_id("PAYROLL1") == flow_id
    
    def test_flow_id_format(self):
        """Flow ID format is FLOW_{PROGRAM_NAME}."""
        flow_id = generate_flow_id("TESTPROG")
        assert flow_id.startswith("FLOW_")
        assert flow_id == "FLOW_TESTPROG"
        
        # Format should be consistent
        assert generate_flow_id("ABC") == "FLOW_ABC"
        assert generate_flow_id("XYZ123") == "FLOW_XYZ123"
    
    def test_flow_id_max_length(self):
        """Flow IDs handle long program names."""
        # Mainframe program names are typically max 8 characters
        # but test with longer names for robustness
        long_name = "A" * 100
        flow_id = generate_flow_id(long_name)
        assert flow_id == f"FLOW_{long_name}"
        assert flow_id.startswith("FLOW_")
    
    def test_flow_id_consistency_across_cases(self):
        """Different cases of same program name produce same flow ID."""
        assert generate_flow_id("PROG") == generate_flow_id("prog")
        assert generate_flow_id("PROG") == generate_flow_id("Prog")
        assert generate_flow_id("PROG") == generate_flow_id("PrOg")
        
        # All should produce FLOW_PROG
        assert generate_flow_id("PROG") == "FLOW_PROG"
        assert generate_flow_id("prog") == "FLOW_PROG"
        assert generate_flow_id("Prog") == "FLOW_PROG"


class TestFlowIdEdgeCases:
    """Test edge cases for flow ID generation."""
    
    def test_flow_id_whitespace_only(self):
        """Program name with only whitespace raises ValueError."""
        with pytest.raises(ValueError, match="resulted in empty flow ID"):
            generate_flow_id("   ")
        
        with pytest.raises(ValueError, match="resulted in empty flow ID"):
            generate_flow_id("\t\n")
    
    def test_flow_id_mixed_valid_invalid_chars(self):
        """Program name with mix of valid and invalid chars."""
        assert generate_flow_id("A@B#C$D") == "FLOW_A_B_C_D"
        assert generate_flow_id("1!2@3#4") == "FLOW_1_2_3_4"
    
    def test_flow_id_unicode_characters(self):
        """Unicode characters are sanitized."""
        # Unicode characters should be replaced with underscores
        assert generate_flow_id("PROG™") == "FLOW_PROG"
        assert generate_flow_id("TEST©123") == "FLOW_TEST_123"
    
    def test_flow_id_none_input(self):
        """None as program name raises appropriate error."""
        with pytest.raises((ValueError, AttributeError)):
            generate_flow_id(None)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
