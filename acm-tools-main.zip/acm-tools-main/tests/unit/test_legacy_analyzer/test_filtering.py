"""
Unit tests for migration flow filtering functionality.

Tests filtering flows by:
- Flow IDs
- Complexity tier
- Business domain
- Entry type
- Combined filters
"""

import pytest
import sqlite3
from tools.legacy_analyzer.migration.flow_exporter import MigrationFlowExporter


@pytest.fixture
def test_db():
    """Create in-memory test database with sample flows."""
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create migration_flows table
    cursor.execute("""
        CREATE TABLE migration_flows (
            flow_id VARCHAR(100) PRIMARY KEY,
            name VARCHAR(200),
            entry_program VARCHAR(44),
            primary_entry_type VARCHAR(20),
            total_programs INTEGER,
            total_copybooks INTEGER,
            total_datasets INTEGER,
            complexity_total_lines INTEGER,
            complexity_cyclomatic INTEGER,
            complexity_score DECIMAL(10,2),
            complexity_tier VARCHAR(10),
            priority INTEGER,
            business_domain VARCHAR(100),
            created_date DATE,
            updated_date DATE
        )
    """)
    
    # Create flow_entry_types table
    cursor.execute("""
        CREATE TABLE flow_entry_types (
            flow_id VARCHAR(100),
            entry_type VARCHAR(20),
            caller_source VARCHAR(100),
            metadata_json TEXT,
            PRIMARY KEY (flow_id, entry_type, caller_source),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_scope table
    cursor.execute("""
        CREATE TABLE flow_scope (
            flow_id VARCHAR(100),
            artifact_type VARCHAR(20),
            artifact_name VARCHAR(44),
            PRIMARY KEY (flow_id, artifact_type, artifact_name),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_interfaces table
    cursor.execute("""
        CREATE TABLE flow_interfaces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flow_id VARCHAR(100),
            direction VARCHAR(10),
            interface_type VARCHAR(20),
            source VARCHAR(44),
            target VARCHAR(44),
            external BOOLEAN DEFAULT FALSE,
            metadata_json TEXT,
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_data_operations table
    cursor.execute("""
        CREATE TABLE flow_data_operations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flow_id VARCHAR(100),
            operation_category VARCHAR(20),
            operation_type VARCHAR(20),
            db_type VARCHAR(20),
            target VARCHAR(100),
            program VARCHAR(44),
            mode VARCHAR(10),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Create flow_dependencies table
    cursor.execute("""
        CREATE TABLE flow_dependencies (
            flow_id VARCHAR(100),
            depends_on_flow_id VARCHAR(100),
            dependency_type VARCHAR(20),
            PRIMARY KEY (flow_id, depends_on_flow_id, dependency_type),
            FOREIGN KEY (flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE,
            FOREIGN KEY (depends_on_flow_id) REFERENCES migration_flows(flow_id) ON DELETE CASCADE
        )
    """)
    
    # Insert test flows with various attributes
    test_flows = [
        # Finance flows
        ('FLOW_PAYROLL1', 'Payroll Processing', 'PAYROLL1', 'JCL', 5, 3, 2, 2500, 45, 67.5, 'MEDIUM', 1, 'Finance'),
        ('FLOW_BILLING1', 'Billing System', 'BILLING1', 'CICS_TRANSACTION', 8, 5, 4, 5000, 120, 150.0, 'HIGH', 2, 'Finance'),
        ('FLOW_ACCT1', 'Accounting', 'ACCT1', 'JCL', 12, 8, 6, 8000, 200, 250.0, 'VERY_HIGH', 1, 'Finance'),
        
        # HR flows
        ('FLOW_EMPLOYEE1', 'Employee Management', 'EMPLOYEE1', 'CICS_TRANSACTION', 6, 4, 3, 3500, 80, 95.0, 'MEDIUM', 3, 'HR'),
        ('FLOW_TIMECARD1', 'Timecard Processing', 'TIMECARD1', 'JCL', 3, 2, 2, 1500, 25, 35.0, 'LOW', 4, 'HR'),
        
        # Operations flows
        ('FLOW_BACKUP1', 'Backup System', 'BACKUP1', 'JCL', 2, 1, 1, 800, 15, 20.0, 'LOW', 5, 'Operations'),
        ('FLOW_MONITOR1', 'System Monitor', 'MONITOR1', 'CICS_PROGRAM', 4, 2, 2, 2000, 40, 55.0, 'MEDIUM', 4, 'Operations'),
    ]
    
    for flow_data in test_flows:
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier, priority, business_domain
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, flow_data)
    
    # Insert entry types
    entry_types = [
        ('FLOW_PAYROLL1', 'JCL', 'PAYROLL01', None),
        ('FLOW_PAYROLL1', 'JCL', 'PAYWEEK', None),
        ('FLOW_BILLING1', 'CICS_TRANSACTION', 'BILL', None),
        ('FLOW_BILLING1', 'CICS_PROGRAM', 'BILLING1', None),
        ('FLOW_ACCT1', 'JCL', 'ACCTJOB', None),
        ('FLOW_EMPLOYEE1', 'CICS_TRANSACTION', 'EMP1', None),
        ('FLOW_TIMECARD1', 'JCL', 'TIMEJOB', None),
        ('FLOW_BACKUP1', 'JCL', 'BACKUP', None),
        ('FLOW_MONITOR1', 'CICS_PROGRAM', 'MONITOR1', None),
    ]
    
    for entry_data in entry_types:
        cursor.execute("""
            INSERT INTO flow_entry_types (
                flow_id, entry_type, caller_source, metadata_json
            ) VALUES (?, ?, ?, ?)
        """, entry_data)
    
    # Insert minimal scope data for each flow (just to make export work)
    for flow_id, _, entry_program, _, _, _, _, _, _, _, _, _, _ in test_flows:
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, 'PROGRAM', ?)
        """, (flow_id, entry_program))
    
    conn.commit()
    yield conn
    conn.close()


@pytest.fixture
def exporter(test_db):
    """Create MigrationFlowExporter instance."""
    return MigrationFlowExporter(test_db)


class TestFilterByFlowIds:
    """Tests for filter_by_flow_ids method."""
    
    def test_filter_valid_flow_ids(self, exporter):
        """Test filtering with valid flow IDs."""
        flow_ids = ['FLOW_PAYROLL1', 'FLOW_BILLING1']
        result = exporter.filter_by_flow_ids(flow_ids)
        
        assert len(result) == 2
        assert 'FLOW_PAYROLL1' in result
        assert 'FLOW_BILLING1' in result
    
    def test_filter_mixed_valid_invalid_ids(self, exporter):
        """Test filtering with mix of valid and invalid IDs."""
        flow_ids = ['FLOW_PAYROLL1', 'FLOW_INVALID', 'FLOW_BILLING1']
        result = exporter.filter_by_flow_ids(flow_ids)
        
        # Should only return valid IDs
        assert len(result) == 2
        assert 'FLOW_PAYROLL1' in result
        assert 'FLOW_BILLING1' in result
        assert 'FLOW_INVALID' not in result
    
    def test_filter_empty_list(self, exporter):
        """Test filtering with empty list."""
        result = exporter.filter_by_flow_ids([])
        assert result == []
    
    def test_filter_all_invalid_ids(self, exporter):
        """Test filtering with all invalid IDs."""
        flow_ids = ['FLOW_INVALID1', 'FLOW_INVALID2']
        result = exporter.filter_by_flow_ids(flow_ids)
        assert result == []
    
    def test_filter_single_flow_id(self, exporter):
        """Test filtering with single flow ID."""
        result = exporter.filter_by_flow_ids(['FLOW_PAYROLL1'])
        assert result == ['FLOW_PAYROLL1']


class TestFilterByComplexity:
    """Tests for filter_by_complexity method."""
    
    def test_filter_low_complexity(self, exporter):
        """Test filtering for LOW complexity and above."""
        result = exporter.filter_by_complexity('LOW')
        
        # Should return all flows (LOW, MEDIUM, HIGH, VERY_HIGH)
        assert len(result) == 7
    
    def test_filter_medium_complexity(self, exporter):
        """Test filtering for MEDIUM complexity and above."""
        result = exporter.filter_by_complexity('MEDIUM')
        
        # Should return MEDIUM, HIGH, VERY_HIGH (5 flows)
        assert len(result) == 5
        assert 'FLOW_PAYROLL1' in result  # MEDIUM
        assert 'FLOW_BILLING1' in result  # HIGH
        assert 'FLOW_ACCT1' in result  # VERY_HIGH
        assert 'FLOW_EMPLOYEE1' in result  # MEDIUM
        assert 'FLOW_MONITOR1' in result  # MEDIUM
        
        # Should not include LOW
        assert 'FLOW_TIMECARD1' not in result
        assert 'FLOW_BACKUP1' not in result
    
    def test_filter_high_complexity(self, exporter):
        """Test filtering for HIGH complexity and above."""
        result = exporter.filter_by_complexity('HIGH')
        
        # Should return HIGH, VERY_HIGH (2 flows)
        assert len(result) == 2
        assert 'FLOW_BILLING1' in result  # HIGH
        assert 'FLOW_ACCT1' in result  # VERY_HIGH
    
    def test_filter_very_high_complexity(self, exporter):
        """Test filtering for VERY_HIGH complexity only."""
        result = exporter.filter_by_complexity('VERY_HIGH')
        
        # Should return only VERY_HIGH (1 flow)
        assert len(result) == 1
        assert 'FLOW_ACCT1' in result
    
    def test_filter_case_insensitive(self, exporter):
        """Test that complexity filter is case-insensitive."""
        result_upper = exporter.filter_by_complexity('HIGH')
        result_lower = exporter.filter_by_complexity('high')
        result_mixed = exporter.filter_by_complexity('High')
        
        assert result_upper == result_lower == result_mixed
    
    def test_filter_invalid_complexity(self, exporter):
        """Test filtering with invalid complexity tier."""
        with pytest.raises(ValueError) as exc_info:
            exporter.filter_by_complexity('INVALID')
        
        assert 'Invalid complexity tier' in str(exc_info.value)


class TestFilterByBusinessDomain:
    """Tests for filter_by_business_domain method."""
    
    def test_filter_finance_domain(self, exporter):
        """Test filtering for Finance domain."""
        result = exporter.filter_by_business_domain('Finance')
        
        assert len(result) == 3
        assert 'FLOW_PAYROLL1' in result
        assert 'FLOW_BILLING1' in result
        assert 'FLOW_ACCT1' in result
    
    def test_filter_hr_domain(self, exporter):
        """Test filtering for HR domain."""
        result = exporter.filter_by_business_domain('HR')
        
        assert len(result) == 2
        assert 'FLOW_EMPLOYEE1' in result
        assert 'FLOW_TIMECARD1' in result
    
    def test_filter_operations_domain(self, exporter):
        """Test filtering for Operations domain."""
        result = exporter.filter_by_business_domain('Operations')
        
        assert len(result) == 2
        assert 'FLOW_BACKUP1' in result
        assert 'FLOW_MONITOR1' in result
    
    def test_filter_nonexistent_domain(self, exporter):
        """Test filtering for non-existent domain."""
        result = exporter.filter_by_business_domain('Marketing')
        assert result == []
    
    def test_filter_case_sensitive(self, exporter):
        """Test that business domain filter is case-sensitive."""
        result_correct = exporter.filter_by_business_domain('Finance')
        result_wrong_case = exporter.filter_by_business_domain('finance')
        
        assert len(result_correct) == 3
        assert len(result_wrong_case) == 0


class TestFilterByEntryType:
    """Tests for filter_by_entry_type method."""
    
    def test_filter_jcl_entry_type(self, exporter):
        """Test filtering for JCL entry type."""
        result = exporter.filter_by_entry_type('JCL')
        
        # Flows with JCL entry type
        assert len(result) == 4
        assert 'FLOW_PAYROLL1' in result
        assert 'FLOW_ACCT1' in result
        assert 'FLOW_TIMECARD1' in result
        assert 'FLOW_BACKUP1' in result
    
    def test_filter_cics_transaction_entry_type(self, exporter):
        """Test filtering for CICS_TRANSACTION entry type."""
        result = exporter.filter_by_entry_type('CICS_TRANSACTION')
        
        # Flows with CICS_TRANSACTION entry type
        assert len(result) == 2
        assert 'FLOW_BILLING1' in result
        assert 'FLOW_EMPLOYEE1' in result
    
    def test_filter_cics_program_entry_type(self, exporter):
        """Test filtering for CICS_PROGRAM entry type."""
        result = exporter.filter_by_entry_type('CICS_PROGRAM')
        
        # Flows with CICS_PROGRAM entry type
        assert len(result) == 2
        assert 'FLOW_BILLING1' in result
        assert 'FLOW_MONITOR1' in result
    
    def test_filter_nonexistent_entry_type(self, exporter):
        """Test filtering for non-existent entry type."""
        result = exporter.filter_by_entry_type('SCREEN')
        assert result == []
    
    def test_filter_multiple_entry_types(self, exporter):
        """Test that flows with multiple entry types are found correctly."""
        # FLOW_BILLING1 has both CICS_TRANSACTION and CICS_PROGRAM
        jcl_result = exporter.filter_by_entry_type('JCL')
        cics_trans_result = exporter.filter_by_entry_type('CICS_TRANSACTION')
        cics_prog_result = exporter.filter_by_entry_type('CICS_PROGRAM')
        
        # FLOW_BILLING1 should appear in both CICS results but not JCL
        assert 'FLOW_BILLING1' not in jcl_result
        assert 'FLOW_BILLING1' in cics_trans_result
        assert 'FLOW_BILLING1' in cics_prog_result


class TestCombinedFilters:
    """Tests for apply_combined_filters method."""
    
    def test_no_filters(self, exporter):
        """Test with no filters (should return all flows)."""
        result = exporter.apply_combined_filters()
        assert len(result) == 7
    
    def test_complexity_and_domain(self, exporter):
        """Test combining complexity and business domain filters."""
        result = exporter.apply_combined_filters(
            min_complexity='HIGH',
            business_domain='Finance'
        )
        
        # HIGH or VERY_HIGH in Finance
        assert len(result) == 2
        assert 'FLOW_BILLING1' in result  # HIGH, Finance
        assert 'FLOW_ACCT1' in result  # VERY_HIGH, Finance
    
    def test_complexity_and_entry_type(self, exporter):
        """Test combining complexity and entry type filters."""
        result = exporter.apply_combined_filters(
            min_complexity='MEDIUM',
            entry_type='JCL'
        )
        
        # MEDIUM or above with JCL entry type
        assert len(result) == 2
        assert 'FLOW_PAYROLL1' in result  # MEDIUM, JCL
        assert 'FLOW_ACCT1' in result  # VERY_HIGH, JCL
    
    def test_domain_and_entry_type(self, exporter):
        """Test combining business domain and entry type filters."""
        result = exporter.apply_combined_filters(
            business_domain='Finance',
            entry_type='JCL'
        )
        
        # Finance flows with JCL entry type
        assert len(result) == 2
        assert 'FLOW_PAYROLL1' in result
        assert 'FLOW_ACCT1' in result
    
    def test_all_three_filters(self, exporter):
        """Test combining all three filters."""
        result = exporter.apply_combined_filters(
            min_complexity='HIGH',
            business_domain='Finance',
            entry_type='JCL'
        )
        
        # HIGH or above, Finance, JCL
        assert len(result) == 1
        assert 'FLOW_ACCT1' in result
    
    def test_flow_ids_with_other_filters(self, exporter):
        """Test combining flow IDs with other filters."""
        result = exporter.apply_combined_filters(
            flow_ids=['FLOW_PAYROLL1', 'FLOW_BILLING1', 'FLOW_ACCT1'],
            min_complexity='HIGH'
        )
        
        # Only flows in the list that are HIGH or above
        assert len(result) == 2
        assert 'FLOW_BILLING1' in result  # HIGH
        assert 'FLOW_ACCT1' in result  # VERY_HIGH
        assert 'FLOW_PAYROLL1' not in result  # MEDIUM (filtered out)
    
    def test_filters_with_no_matches(self, exporter):
        """Test filters that result in no matches."""
        result = exporter.apply_combined_filters(
            min_complexity='VERY_HIGH',
            business_domain='HR'
        )
        
        # No HR flows are VERY_HIGH
        assert result == []
    
    def test_flow_ids_only(self, exporter):
        """Test with only flow IDs filter."""
        result = exporter.apply_combined_filters(
            flow_ids=['FLOW_PAYROLL1', 'FLOW_BILLING1']
        )
        
        assert len(result) == 2
        assert 'FLOW_PAYROLL1' in result
        assert 'FLOW_BILLING1' in result


class TestExportWithFilters:
    """Tests for export_all_flows with various filters."""
    
    def test_export_with_complexity_filter(self, exporter):
        """Test exporting flows with complexity filter."""
        result = exporter.export_all_flows(min_complexity='HIGH')
        
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        # Verify all exported flows are HIGH or VERY_HIGH
        for flow in result['flows']:
            assert flow['complexity']['tier'] in ['HIGH', 'VERY_HIGH']
    
    def test_export_with_domain_filter(self, exporter):
        """Test exporting flows with business domain filter."""
        result = exporter.export_all_flows(business_domain='Finance')
        
        assert 'flows' in result
        assert len(result['flows']) == 3
        
        # Verify all exported flows are in Finance domain
        for flow in result['flows']:
            assert flow['businessDomain'] == 'Finance'
    
    def test_export_with_entry_type_filter(self, exporter):
        """Test exporting flows with entry type filter."""
        result = exporter.export_all_flows(entry_type='JCL')
        
        assert 'flows' in result
        assert len(result['flows']) == 4
        
        # Verify all exported flows have JCL entry type
        for flow in result['flows']:
            entry_types = [et['type'] for et in flow['entryPoint']['types']]
            assert 'JCL' in entry_types
    
    def test_export_with_flow_ids_filter(self, exporter):
        """Test exporting specific flow IDs."""
        result = exporter.export_all_flows(
            flow_ids=['FLOW_PAYROLL1', 'FLOW_BILLING1']
        )
        
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_PAYROLL1' in flow_ids
        assert 'FLOW_BILLING1' in flow_ids
    
    def test_export_with_combined_filters(self, exporter):
        """Test exporting with multiple filters combined."""
        result = exporter.export_all_flows(
            min_complexity='MEDIUM',
            business_domain='Finance',
            entry_type='JCL'
        )
        
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        # Verify all conditions are met
        for flow in result['flows']:
            assert flow['complexity']['tier'] in ['MEDIUM', 'HIGH', 'VERY_HIGH']
            assert flow['businessDomain'] == 'Finance'
            entry_types = [et['type'] for et in flow['entryPoint']['types']]
            assert 'JCL' in entry_types
    
    def test_export_with_no_matches(self, exporter):
        """Test exporting with filters that match no flows."""
        result = exporter.export_all_flows(
            min_complexity='VERY_HIGH',
            business_domain='HR'
        )
        
        assert 'flows' in result
        assert len(result['flows']) == 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
