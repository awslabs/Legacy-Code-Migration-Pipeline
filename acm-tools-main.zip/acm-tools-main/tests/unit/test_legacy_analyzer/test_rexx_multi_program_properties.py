#!/usr/bin/env python3
"""
Property-based tests for REXX multi-program parsing.

**Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (REXX)**
**Validates: Requirements 1.4**

These tests use Hypothesis to verify correctness properties across
many randomly generated REXX source files with multiple programs.
"""

import os
import sys
import tempfile
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.parsers.rexx_parser import REXXDependencyParser
from tools.legacy_analyzer.analysis.program_boundary_detector import REXXProgramBoundaryDetector
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Strategy for generating valid REXX program names
# Exclude all built-in functions and keywords that the REXX parser filters out
rexx_builtin_functions = {
    'ABBREV', 'ABS', 'ADDRESS', 'ARG', 'B2X', 'BITAND', 'BITOR', 'BITXOR',
    'C2D', 'C2X', 'CENTER', 'CENTRE', 'CHANGESTR', 'CHARIN', 'CHAROUT',
    'CHARS', 'COMPARE', 'CONDITION', 'COPIES', 'COUNTSTR', 'D2C', 'D2X',
    'DATATYPE', 'DATE', 'DELSTR', 'DELWORD', 'DIGITS', 'ERRORTEXT', 'FORM',
    'FORMAT', 'FUZZ', 'INDEX', 'INSERT', 'LASTPOS', 'LEFT', 'LENGTH',
    'LINEIN', 'LINEOUT', 'LINES', 'MAX', 'MIN', 'OVERLAY', 'POS', 'QUEUED',
    'RANDOM', 'REVERSE', 'RIGHT', 'SIGN', 'SOURCELINE', 'SPACE', 'STREAM',
    'STRIP', 'SUBSTR', 'SUBWORD', 'SYMBOL', 'TIME', 'TRACE', 'TRANSLATE',
    'TRUNC', 'VALUE', 'VERIFY', 'WORD', 'WORDINDEX', 'WORDLENGTH', 'WORDPOS',
    'WORDS', 'X2B', 'X2C', 'X2D', 'XRANGE', 'USERID', 'SYSVAR', 'OUTTRAP',
    'LISTDSI', 'MSG', 'PROMPT', 'SYSCPUS', 'SYSDSN', 'STORAGE',
    'MVSVAR', 'SETLANG',
    # REXX keywords and control structures
    'IF', 'THEN', 'ELSE', 'DO', 'END', 'SELECT', 'WHEN', 'OTHERWISE',
    'RETURN', 'EXIT', 'SIGNAL', 'CALL', 'PROCEDURE', 'EXPOSE', 'PARSE',
    'PULL', 'PUSH', 'QUEUE', 'SAY', 'NUMERIC', 'OPTIONS', 'INTERPRET',
    'ITERATE', 'LEAVE', 'NOP', 'DROP', 'UPPER',
    # Common ISPF/TSO functions
    'DATAID', 'DATASET', 'MEMBER', 'OPTION', 'MODE', 'STATS', 'ENQ',
    'DATALOC', 'DATALEN', 'MAXLEN', 'RECFM', 'LRECL', 'BLKSIZE'
}

rexx_program_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_',
    min_size=1,
    max_size=44
).filter(lambda x: x.strip() and x[0].isalpha() and x.upper() not in rexx_builtin_functions)

# Strategy for generating REXX procedure definitions
rexx_procedure_definitions = st.builds(
    lambda proc_name: f"{proc_name}: PROCEDURE\nARG param1, param2\nRETURN result",
    proc_name=rexx_program_names
)

# Strategy for generating REXX function definitions
rexx_function_definitions = st.builds(
    lambda func_name: f"{func_name}:\nARG input\nresult = input * 2\nRETURN result",
    func_name=rexx_program_names
)

# Strategy for generating REXX subroutine definitions
rexx_subroutine_definitions = st.builds(
    lambda sub_name: f"{sub_name}:\nSAY 'Processing in {sub_name}'\nRETURN",
    sub_name=rexx_program_names
)

# Strategy for generating REXX CALL statements
rexx_call_statements = st.builds(
    lambda prog_name: f"CALL {prog_name}",
    prog_name=rexx_program_names
)

# Strategy for generating REXX ADDRESS commands
rexx_address_commands = st.builds(
    lambda env, cmd: f"ADDRESS {env} '{cmd}'",
    env=st.sampled_from(['TSO', 'ISPEXEC', 'ISREDIT', 'LINKMVS']),
    cmd=st.sampled_from(['ALLOCATE', 'LISTDSI', 'EDIT', 'BROWSE'])
)

# Strategy for generating REXX EXECIO statements
rexx_execio_statements = st.builds(
    lambda ddname: f"EXECIO * DISKR {ddname}",
    ddname=rexx_program_names
)

# Strategy for generating REXX comments
rexx_comments = st.builds(
    lambda comment: f"/* {comment} */",
    comment=st.text(alphabet='abcdefghijklmnopqrstuvwxyz0123456789 ', min_size=5, max_size=50)
)

# Strategy for generating multi-program REXX source
rexx_multi_program_source = st.builds(
    lambda programs: '\n'.join(programs),
    programs=st.lists(
        st.one_of(
            rexx_procedure_definitions,
            rexx_function_definitions,
            rexx_subroutine_definitions,
            rexx_call_statements,
            rexx_address_commands,
            rexx_execio_statements,
            rexx_comments,
            st.just("SAY 'Hello World'"),
            st.just("x = 1"),
            st.just("IF x > 0 THEN SAY 'Positive'"),
            st.just("DO i = 1 TO 10"),
            st.just("END"),
            st.just("EXIT")
        ),
        min_size=3,
        max_size=20
    )
)


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (REXX)**
# **Validates: Requirements 1.4**
@settings(max_examples=100)
@given(
    rexx_source=rexx_multi_program_source
)
def test_property_rexx_multi_program_parsing_accuracy(rexx_source):
    """
    Property 1: Multi-program file parsing accuracy (REXX)
    
    For any REXX source file containing multiple programs, parsing should identify 
    each individual program with correct boundaries and track dependencies 
    separately for each program.
    """
    parser = REXXDependencyParser()
    detector = REXXProgramBoundaryDetector()
    
    # Ensure source has some content
    lines = rexx_source.splitlines()
    assume(len(lines) >= 1)
    assume(any(line.strip() for line in lines))  # At least one non-empty line
    
    # Test program boundary detection
    programs = detector.detect_boundaries(rexx_source)
    
    # Property: All detected programs should have valid REXX characteristics
    for program in programs:
        assert program.language == "REXX", \
            f"Program '{program.program_name}' should have language 'REXX', got '{program.language}'"
        
        assert program.program_type in [ProgramType.MAIN, ProgramType.PROCEDURE, ProgramType.FUNCTION], \
            f"Program '{program.program_name}' should be MAIN, PROCEDURE, or FUNCTION, got {program.program_type}"
        
        assert program.start_line >= 1, \
            f"Program '{program.program_name}' should have start_line >= 1, got {program.start_line}"
        
        assert program.end_line >= program.start_line, \
            f"Program '{program.program_name}' should have end_line >= start_line"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
    
    # Property: Non-main programs should not overlap with each other
    # Note: In REXX, procedures/functions can be part of the main program, so main can overlap
    non_main_programs = [p for p in programs if p.program_type != ProgramType.MAIN]
    for i, prog1 in enumerate(non_main_programs):
        for prog2 in non_main_programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"REXX non-main programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: Should detect at least one program (main program if nothing else)
    assert len(programs) >= 1, \
        "REXX source should detect at least one program (main program)"
    
    # Test enhanced parser functionality
    if hasattr(parser, 'parse_with_program_detection'):
        result = parser.parse_with_program_detection(rexx_source)
        
        # Property: Parse result should contain program information
        assert result.language == "REXX", \
            f"Parse result should have language 'REXX', got '{result.language}'"
        
        assert len(result.programs) >= 0, \
            "Parse result should contain programs list"
        
        # Property: Dependencies should be tracked per program
        for program_name, deps in result.dependencies.items():
            assert isinstance(deps, list), \
                f"Dependencies for program '{program_name}' should be a list"
            
            # All dependency items should be strings
            for dep in deps:
                assert isinstance(dep, str), \
                    f"Dependency '{dep}' should be a string"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (REXX)**
# **Validates: Requirements 1.4**
@settings(max_examples=100)
@given(
    procedure_count=st.integers(min_value=1, max_value=5),
    procedure_names=st.lists(rexx_program_names, min_size=1, max_size=5)
)
def test_property_rexx_multiple_procedures_detection(procedure_count, procedure_names):
    """
    Property 1: Multi-program file parsing accuracy (REXX) - Multiple procedures
    
    For any REXX source file with multiple procedure definitions, each should be 
    detected as a separate program with correct boundaries.
    """
    assume(len(procedure_names) >= procedure_count)
    
    detector = REXXProgramBoundaryDetector()
    
    # Create source with multiple procedures
    source_lines = [
        "/* Main program */",
        "SAY 'Starting main program'",
        "CALL PROC1",
        "EXIT"
    ]
    
    for i in range(procedure_count):
        if i < len(procedure_names):
            proc_name = procedure_names[i]
            source_lines.extend([
                "",
                f"{proc_name}: PROCEDURE",
                f"ARG param{i+1}",
                f"SAY 'In procedure {proc_name}'",
                "RETURN"
            ])
    
    rexx_source = '\n'.join(source_lines)
    programs = detector.detect_boundaries(rexx_source)
    
    # Property: Should detect main program plus procedures
    assert len(programs) >= procedure_count + 1, \
        f"Should detect at least {procedure_count + 1} programs (main + {procedure_count} procedures), got {len(programs)}"
    
    # Property: Should have one main program
    main_programs = [p for p in programs if p.program_type == ProgramType.MAIN]
    assert len(main_programs) >= 1, \
        "Should detect at least one main program"
    
    # Property: Should have procedure programs
    procedure_programs = [p for p in programs if p.program_type == ProgramType.PROCEDURE]
    assert len(procedure_programs) >= procedure_count, \
        f"Should detect at least {procedure_count} procedure programs, got {len(procedure_programs)}"
    
    # Property: Each program should have distinct boundaries
    program_ranges = [(p.start_line, p.end_line) for p in programs]
    # Note: Main program might overlap with procedures in REXX, so we don't enforce strict non-overlap


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (REXX)**
# **Validates: Requirements 1.4**
@settings(max_examples=100)
@given(
    main_program=rexx_program_names,
    procedures=st.lists(rexx_program_names, min_size=0, max_size=3),
    calls=st.lists(rexx_program_names, min_size=0, max_size=3),
    datasets=st.lists(rexx_program_names, min_size=0, max_size=3)
)
def test_property_rexx_dependency_separation_per_program(main_program, procedures, calls, datasets):
    """
    Property 1: Multi-program file parsing accuracy (REXX) - Dependency separation
    
    For any REXX source file with multiple programs, dependencies should be 
    tracked separately for each program based on their line boundaries.
    """
    parser = REXXDependencyParser()
    
    # Create REXX source with main program and procedures
    source_lines = [
        f"/* Main program: {main_program} */",
        "SAY 'Starting main program'"
    ]
    
    # Add calls to main program
    for call in calls:
        source_lines.append(f"CALL {call}")
    
    # Add dataset references to main program
    for dataset in datasets:
        source_lines.append(f"EXECIO * DISKR {dataset}")
    
    source_lines.append("EXIT")
    
    # Add procedures
    for proc in procedures:
        source_lines.extend([
            "",
            f"{proc}: PROCEDURE",
            f"ARG param",
            f"SAY 'In procedure {proc}'",
            "RETURN"
        ])
    
    rexx_source = '\n'.join(source_lines)
    
    # Test traditional parsing
    traditional_result = parser.parse(rexx_source)
    
    # Property: Traditional parsing should find all dependencies
    all_expected_calls = set(calls)
    all_expected_datasets = set(datasets)
    
    found_calls = set(traditional_result.get('calls', []))
    found_datasets = set(traditional_result.get('datasets', []))
    
    assert all_expected_calls.issubset(found_calls), \
        f"Traditional parsing should find all calls: expected {all_expected_calls}, found {found_calls}"
    
    assert all_expected_datasets.issubset(found_datasets), \
        f"Traditional parsing should find all datasets: expected {all_expected_datasets}, found {found_datasets}"
    
    # Test program-level parsing if available
    if hasattr(parser, 'parse_with_program_detection'):
        program_result = parser.parse_with_program_detection(rexx_source)
        
        # Property: Should detect main program
        main_programs = [p for p in program_result.programs if p.program_type == ProgramType.MAIN]
        assert len(main_programs) >= 1, \
            "Should detect at least one main program"
        
        # Property: Dependencies should be associated with programs
        assert isinstance(program_result.dependencies, dict), \
            "Program-level dependencies should be a dictionary"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (REXX)**
# **Validates: Requirements 1.4**
@settings(max_examples=100)
@given(
    rexx_source=rexx_multi_program_source
)
def test_property_rexx_parsing_consistency(rexx_source):
    """
    Property 1: Multi-program file parsing accuracy (REXX) - Consistency
    
    For any REXX source file, running parsing multiple times should produce 
    identical results.
    """
    parser = REXXDependencyParser()
    detector = REXXProgramBoundaryDetector()
    
    # Ensure source has some content
    lines = rexx_source.splitlines()
    assume(len(lines) >= 1)
    assume(any(line.strip() for line in lines))
    
    # Run traditional parsing multiple times
    traditional_results = []
    for _ in range(3):
        result = parser.parse(rexx_source)
        traditional_results.append(result)
    
    # Property: Traditional parsing should be consistent
    first_result = traditional_results[0]
    for i, result in enumerate(traditional_results[1:], start=1):
        for key in first_result:
            assert set(result.get(key, [])) == set(first_result.get(key, [])), \
                f"Traditional parsing run {i} differs from run 0 for key '{key}'"
    
    # Run boundary detection multiple times
    boundary_results = []
    for _ in range(3):
        programs = detector.detect_boundaries(rexx_source)
        boundary_results.append(programs)
    
    # Property: Boundary detection should be consistent
    first_boundaries = boundary_results[0]
    for i, boundaries in enumerate(boundary_results[1:], start=1):
        assert len(boundaries) == len(first_boundaries), \
            f"Boundary detection run {i} found {len(boundaries)} programs, but run 0 found {len(first_boundaries)}"
        
        # Compare programs by name and boundaries
        first_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in first_boundaries}
        result_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in boundaries}
        
        assert first_dict == result_dict, \
            f"Boundary detection run {i} produced different results than run 0"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (REXX)**
# **Validates: Requirements 1.4**
@settings(max_examples=100)
@given(
    file_path=st.text(
        alphabet='abcdefghijklmnopqrstuvwxyz0123456789_-.',
        min_size=5,
        max_size=50
    ).map(lambda x: f"/path/to/{x}.rexx")
)
def test_property_rexx_file_path_handling(file_path):
    """
    Property 1: Multi-program file parsing accuracy (REXX) - File path handling
    
    For any REXX source file with a file path, program boundaries should include
    the correct file path information.
    """
    detector = REXXProgramBoundaryDetector()
    
    # Create simple REXX source
    rexx_source = """/* Main program */
SAY 'Hello World'
CALL SUBPROC
EXIT

SUBPROC: PROCEDURE
SAY 'In subroutine'
RETURN"""
    
    # Detect boundaries with file path
    programs = detector.detect_boundaries(rexx_source, file_path)
    
    # Property: All programs should have the correct file path
    for program in programs:
        assert program.file_path == file_path, \
            f"Program '{program.program_name}' should have file_path '{file_path}', got '{program.file_path}'"
    
    # Property: Parse result should include file path
    result = detector.parse_with_program_detection(rexx_source, file_path)
    assert result.file_path == file_path, \
        f"Parse result should have file_path '{file_path}', got '{result.file_path}'"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (REXX)**
# **Validates: Requirements 1.4**
@settings(max_examples=100)
@given(
    function_names=st.lists(rexx_program_names, min_size=1, max_size=3),
    subroutine_names=st.lists(rexx_program_names, min_size=1, max_size=3)
)
def test_property_rexx_function_and_subroutine_detection(function_names, subroutine_names):
    # Ensure function and subroutine names are unique to avoid conflicts
    assume(len(set(function_names + subroutine_names)) == len(function_names) + len(subroutine_names))
    """
    Property 1: Multi-program file parsing accuracy (REXX) - Functions and subroutines
    
    For any REXX source file with functions and subroutines, each should be 
    detected as separate programs with appropriate types.
    """
    detector = REXXProgramBoundaryDetector()
    
    # Create source with functions and subroutines
    source_lines = [
        "/* Main program */",
        "result = FUNC1('test')",
        "CALL SUB1",
        "EXIT"
    ]
    
    # Add functions (labels with ARG and RETURN value)
    for func_name in function_names:
        source_lines.extend([
            "",
            f"{func_name}:",
            "ARG input",
            "result = LENGTH(input)",
            "RETURN result"
        ])
    
    # Add subroutines (labels with executable code)
    for sub_name in subroutine_names:
        source_lines.extend([
            "",
            f"{sub_name}:",
            f"SAY 'Processing in {sub_name}'",
            "x = 1 + 1",
            "RETURN"
        ])
    
    rexx_source = '\n'.join(source_lines)
    programs = detector.detect_boundaries(rexx_source)
    
    # Property: Should detect main program plus functions and subroutines
    expected_min_programs = 1 + len(function_names) + len(subroutine_names)
    assert len(programs) >= expected_min_programs, \
        f"Should detect at least {expected_min_programs} programs, got {len(programs)}"
    
    # Property: Should have one main program
    main_programs = [p for p in programs if p.program_type == ProgramType.MAIN]
    assert len(main_programs) >= 1, \
        "Should detect at least one main program"
    
    # Property: Function and procedure programs should exist
    non_main_programs = [p for p in programs if p.program_type != ProgramType.MAIN]
    assert len(non_main_programs) >= len(function_names) + len(subroutine_names), \
        f"Should detect at least {len(function_names) + len(subroutine_names)} non-main programs"
    
    # Property: All program names should be valid identifiers
    for program in programs:
        assert program.program_name, \
            "All programs should have non-empty names"
        
        # Program name should be alphanumeric or underscore
        assert all(c.isalnum() or c == '_' for c in program.program_name), \
            f"Program name '{program.program_name}' should contain only alphanumeric characters and underscores"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])