"""Property-based tests for copybook analysis framework.

Feature: program-level-dependency-tracking
"""

import pytest
import tempfile
import os
from hypothesis import given, strategies as st, settings, HealthCheck, assume
from tools.legacy_analyzer.analysis.copybook_analyzer import (
    CopybookAnalyzer,
    COBOLCopybookAnalyzer,
    PLICopybookAnalyzer,
    NaturalCopybookAnalyzer
)
from tools.legacy_analyzer.models.program_boundary import CopybookAnalysisResult


# Strategy for generating COBOL copybook content
@st.composite
def cobol_copybook_content(draw):
    """Generate COBOL copybook content with mix of data and executable code."""
    lines = []
    
    # Generate some data structure lines
    data_line_count = draw(st.integers(min_value=0, max_value=10))
    for i in range(data_line_count):
        level = draw(st.integers(min_value=1, max_value=49))
        field_name = draw(st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
            min_size=1,
            max_size=30
        ).filter(lambda x: x and x[0].isalpha()))
        
        pic_clause = draw(st.sampled_from([
            "PIC X(10)",
            "PIC 9(5)",
            "PIC S9(7)V99 COMP-3",
            "PICTURE X(20)",
            "PIC 9(3) VALUE ZERO"
        ]))
        
        lines.append(f"       {level:02d} {field_name} {pic_clause}.")
    
    # Generate some executable code lines
    exec_line_count = draw(st.integers(min_value=0, max_value=10))
    for i in range(exec_line_count):
        exec_statement = draw(st.sampled_from([
            "CALL 'SUBPROG'",
            "PERFORM CALCULATE-TOTAL",
            "IF WS-FLAG = 'Y'",
            "MOVE SPACES TO WS-BUFFER",
            "ADD 1 TO WS-COUNTER",
            "EXEC CICS READ",
            "COMPUTE WS-RESULT = WS-A + WS-B"
        ]))
        
        lines.append(f"           {exec_statement}.")
    
    # Add some comments
    comment_count = draw(st.integers(min_value=0, max_value=5))
    for i in range(comment_count):
        comment = draw(st.text(min_size=1, max_size=50))
        lines.append(f"      * {comment}")
    
    return '\n'.join(lines)


@st.composite
def pli_include_content(draw):
    """Generate PL/I include content with mix of data and executable code."""
    lines = []
    
    # Generate some data declarations
    data_line_count = draw(st.integers(min_value=0, max_value=10))
    for i in range(data_line_count):
        var_name = draw(st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
            min_size=1,
            max_size=30
        ).filter(lambda x: x and x[0].isalpha()))
        
        data_type = draw(st.sampled_from([
            "CHAR(20)",
            "FIXED BIN(31)",
            "FLOAT DEC(6)",
            "BIT(8)",
            "POINTER"
        ]))
        
        lines.append(f"DCL {var_name} {data_type};")
    
    # Generate some executable code
    exec_line_count = draw(st.integers(min_value=0, max_value=10))
    for i in range(exec_line_count):
        exec_statement = draw(st.sampled_from([
            "CALL SUBPROC",
            "IF FLAG = '1' THEN",
            "DO I = 1 TO 10",
            "GET FILE(INPUT) INTO(BUFFER)",
            "PUT FILE(OUTPUT) FROM(RECORD)",
            "RETURN"
        ]))
        
        lines.append(f"{exec_statement};")
    
    return '\n'.join(lines)


@st.composite
def natural_copycode_content(draw):
    """Generate Natural copycode content with mix of data and executable code."""
    lines = []
    
    # Generate some data definitions
    data_line_count = draw(st.integers(min_value=0, max_value=10))
    for i in range(data_line_count):
        level = draw(st.integers(min_value=1, max_value=9))
        field_name = draw(st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
            min_size=1,
            max_size=30
        ).filter(lambda x: x and x[0].isalpha()))
        
        data_type = draw(st.sampled_from([
            "(A20)",
            "(N5)",
            "(P7.2)",
            "(L)",
            "(D)"
        ]))
        
        lines.append(f"{level} {field_name} {data_type}")
    
    # Generate some executable code
    exec_line_count = draw(st.integers(min_value=0, max_value=10))
    for i in range(exec_line_count):
        exec_statement = draw(st.sampled_from([
            "CALLNAT 'SUBPROG'",
            "FETCH 'MODULE'",
            "IF #FLAG = 'Y'",
            "MOVE 'TEST' TO #BUFFER",
            "ADD 1 TO #COUNTER",
            "READ EMPLOYEES BY NAME",
            "FIND CUSTOMERS WITH CITY = 'NYC'"
        ]))
        
        lines.append(exec_statement)
    
    return '\n'.join(lines)


@st.composite
def copybook_test_data(draw):
    """Generate test data for copybook analysis."""
    language = draw(st.sampled_from(['COBOL', 'PLI', 'NATURAL']))
    
    if language == 'COBOL':
        content = draw(cobol_copybook_content())
    elif language == 'PLI':
        content = draw(pli_include_content())
    else:  # NATURAL
        content = draw(natural_copycode_content())
    
    copybook_name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), max_codepoint=127),
        min_size=1,
        max_size=30
    ).filter(lambda x: x and x[0].isalpha()))
    
    return {
        'language': language,
        'content': content,
        'copybook_name': copybook_name
    }


class TestCopybookAnalysisProperties:
    """Property-based tests for copybook analysis framework."""
    
    @pytest.fixture
    def temp_copybook_file(self):
        """Create a temporary copybook file for testing."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cpy', delete=False) as f:
            temp_path = f.name
        
        yield temp_path
        
        # Cleanup
        if os.path.exists(temp_path):
            os.unlink(temp_path)
    
    @given(test_data=copybook_test_data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_copybook_executable_code_analysis(self, temp_copybook_file, test_data):
        """
        Feature: program-level-dependency-tracking, Property 3: Copybook executable code analysis
        
        Validates: Requirements 2.1, 2.2, 2.3
        
        For any copybook or include file, the system should analyze the content for 
        executable code and track dependencies found within the included content.
        """
        # Write content to temporary file
        with open(temp_copybook_file, 'w') as f:
            f.write(test_data['content'])
        
        # Analyze the copybook
        analyzer = CopybookAnalyzer()
        result = analyzer.analyze_content(
            temp_copybook_file, 
            test_data['language'], 
            test_data['content']
        )
        
        # Verify result structure
        assert isinstance(result, CopybookAnalysisResult)
        assert result.copybook_name is not None
        assert result.file_path == temp_copybook_file
        assert isinstance(result.has_executable_code, bool)
        assert isinstance(result.data_structures, list)
        assert isinstance(result.procedure_calls, list)
        assert isinstance(result.program_dependencies, list)
        assert 0.0 <= result.confidence_level <= 1.0
        assert result.language == test_data['language']
        
        # Verify that if executable code is detected, the analysis is consistent
        if result.has_executable_code:
            # Should have either procedure calls, program dependencies, or any executable statements
            # This includes control structures, I/O statements, CICS commands, SQL statements, etc.
            content_upper = test_data['content'].upper()
            has_executable_statements = any(keyword in content_upper for keyword in [
                # Control structures
                'IF ', 'DO ', 'WHILE ', 'FOR ', 'REPEAT ', 'MOVE ', 'ADD ', 'COMPUTE ', 'EVALUATE ',
                # I/O statements
                'GET ', 'PUT ', 'READ ', 'WRITE ', 'REWRITE ', 'DELETE ',
                # CICS commands
                'EXEC CICS', 'EXEC SQL',
                # COBOL statements
                'CALL ', 'PERFORM ', 'GO TO', 'STOP RUN', 'EXIT',
                # PL/I statements
                'GOTO ', 'RETURN ', 'STOP ',
                # Natural statements
                'CALLNAT ', 'FETCH ', 'ESCAPE ', 'FIND ', 'STORE ', 'UPDATE ',
                # Assignment (common in many languages)
                '=', ':='
            ])
            
            # Either has calls/dependencies OR has executable statements that justify executable classification
            assert (len(result.procedure_calls) > 0 or 
                   len(result.program_dependencies) > 0 or 
                   has_executable_statements)
        
        # Verify that all program dependencies have valid structure
        for dep in result.program_dependencies:
            assert dep.source_artifact is not None
            assert dep.target_artifact is not None
            assert dep.source_type is not None
            assert dep.target_type is not None
            assert dep.dependency_type is not None
            assert dep.source_language == test_data['language']
    
    @given(test_data=copybook_test_data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_executable_copybook_classification(self, temp_copybook_file, test_data):
        """
        Feature: program-level-dependency-tracking, Property 4: Executable copybook classification
        
        Validates: Requirements 2.4
        
        For any copybook containing executable code, the system should classify it as 
        a program artifact rather than just a data structure.
        """
        # Write content to temporary file
        with open(temp_copybook_file, 'w') as f:
            f.write(test_data['content'])
        
        # Analyze the copybook
        analyzer = CopybookAnalyzer()
        result = analyzer.analyze_content(
            temp_copybook_file, 
            test_data['language'], 
            test_data['content']
        )
        
        # Check classification logic
        content_upper = test_data['content'].upper()
        
        # Define executable indicators for each language
        executable_indicators = {
            'COBOL': ['CALL', 'PERFORM', 'IF', 'MOVE', 'ADD', 'EXEC'],
            'PLI': ['CALL', 'IF', 'DO', 'GET', 'PUT', 'RETURN'],
            'NATURAL': ['CALLNAT', 'FETCH', 'IF', 'MOVE', 'ADD', 'READ', 'FIND']
        }
        
        # Check if content has executable indicators
        has_executable_indicators = any(
            indicator in content_upper 
            for indicator in executable_indicators.get(test_data['language'], [])
        )
        
        # If we detect executable indicators, the result should reflect this
        if has_executable_indicators:
            # The analyzer should detect executable code with reasonable confidence
            if result.has_executable_code:
                assert result.confidence_level >= 0.3  # At least some confidence
        
        # Verify consistency: if marked as executable, should have supporting evidence
        if result.has_executable_code:
            # Should have either procedure calls, dependencies, control structures, or low confidence
            content_upper = test_data['content'].upper()
            # Check for any executable keywords that the analyzers recognize
            executable_keywords = [
                'IF ', 'DO ', 'WHILE ', 'FOR ', 'REPEAT ', 'MOVE ', 'ADD ', 'COMPUTE ', 'PERFORM ',
                'GET ', 'PUT ', 'READ ', 'WRITE ', 'FIND ', 'STORE ', 'UPDATE ', 'DELETE ',
                'SUBTRACT ', 'MULTIPLY ', 'DIVIDE ', 'EXEC ', 'RETURN ', 'STOP ', 'ESCAPE ',
                'EVALUATE ', 'GO TO ', 'EXIT ', 'REWRITE ', 'SELECT ', 'GOTO ', '= '
            ]
            has_control_structures = any(keyword in content_upper for keyword in executable_keywords)
            
            assert (len(result.procedure_calls) > 0 or 
                   len(result.program_dependencies) > 0 or 
                   has_control_structures or
                   result.confidence_level < 0.5)
    
    @given(test_data=copybook_test_data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_copybook_executable_code_validation(self, temp_copybook_file, test_data):
        """
        Feature: program-level-dependency-tracking, Property 15: Copybook executable code validation
        
        Validates: Requirements 8.3
        
        For any copybook identified as containing executable code, the content should 
        contain actual program logic rather than only data definitions.
        """
        # Write content to temporary file
        with open(temp_copybook_file, 'w') as f:
            f.write(test_data['content'])
        
        # Analyze the copybook
        analyzer = CopybookAnalyzer()
        result = analyzer.analyze_content(
            temp_copybook_file, 
            test_data['language'], 
            test_data['content']
        )
        
        # If marked as having executable code, validate the reasoning
        if result.has_executable_code:
            content_lines = test_data['content'].upper().splitlines()
            
            # Define what constitutes actual program logic vs data definitions
            program_logic_patterns = {
                'COBOL': [
                    r'\bCALL\s+',
                    r'\bPERFORM\s+',
                    r'\bIF\s+',
                    r'\bMOVE\s+',
                    r'\bADD\s+',
                    r'\bEXEC\s+',
                    r'\bCOMPUTE\s+'
                ],
                'PLI': [
                    r'\bCALL\s+',
                    r'\bIF\s+',
                    r'\bDO\s+',
                    r'\bGET\s+',
                    r'\bPUT\s+',
                    r'\bRETURN\s+',
                    r'=\s*'  # Assignment
                ],
                'NATURAL': [
                    r'\bCALLNAT\s+',
                    r'\bFETCH\s+',
                    r'\bIF\s+',
                    r'\bMOVE\s+',
                    r'\bADD\s+',
                    r'\bREAD\s+',
                    r'\bFIND\s+'
                ]
            }
            
            # Check if there's actual program logic
            import re
            has_program_logic = False
            patterns = program_logic_patterns.get(test_data['language'], [])
            
            for line in content_lines:
                if any(re.search(pattern, line) for pattern in patterns):
                    has_program_logic = True
                    break
            
            # If marked as executable, should have program logic OR low confidence
            assert has_program_logic or result.confidence_level < 0.8
    
    @given(test_data=copybook_test_data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_property_copybook_dependency_tracking(self, temp_copybook_file, test_data):
        """
        Feature: program-level-dependency-tracking, Property 3: Copybook executable code analysis (dependency tracking)
        
        Validates: Requirements 2.5
        
        For any copybook or include file with executable code, the system should create 
        dependency records showing the relationship between the including program and 
        any programs called from within the copybook.
        """
        # Write content to temporary file
        with open(temp_copybook_file, 'w') as f:
            f.write(test_data['content'])
        
        # Analyze the copybook
        analyzer = CopybookAnalyzer()
        result = analyzer.analyze_content(
            temp_copybook_file, 
            test_data['language'], 
            test_data['content']
        )
        
        # If the copybook has executable code, verify dependency tracking
        if result.has_executable_code:
            # Should have program dependencies if there are procedure calls
            if len(result.procedure_calls) > 0:
                # Each procedure call should have a corresponding dependency
                call_targets = set(result.procedure_calls)
                dependency_targets = set(dep.target_artifact for dep in result.program_dependencies)
                
                # All procedure calls should be tracked as dependencies
                assert call_targets.issubset(dependency_targets) or len(call_targets) == 0
            
            # Verify dependency structure for each dependency
            for dep in result.program_dependencies:
                # Should have valid source (copybook name)
                assert dep.source_artifact is not None
                assert len(dep.source_artifact) > 0
                
                # Should have valid target (called program)
                assert dep.target_artifact is not None
                assert len(dep.target_artifact) > 0
                
                # Should have correct types
                assert dep.source_type == "COPYBOOK"
                assert dep.target_type == "PROGRAM"
                
                # Should have correct language
                assert dep.source_language == test_data['language']
                
                # Should have valid line number
                assert dep.line_number is None or dep.line_number > 0
                
                # Should have valid file path
                assert dep.source_file == temp_copybook_file
        
        # If no executable code, should have no program dependencies
        else:
            program_deps = [dep for dep in result.program_dependencies 
                          if dep.target_type == "PROGRAM"]
            assert len(program_deps) == 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])