#!/usr/bin/env python3
"""
Property-based tests for program boundary completeness validation.

These tests use Hypothesis to verify correctness properties across
many randomly generated inputs.
"""

import os
import sys
import tempfile
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.analysis.program_boundary_detector import (
    ProgramBoundaryDetectorFactory,
    RPGProgramBoundaryDetector,
    AssemblerProgramBoundaryDetector,
    NaturalProgramBoundaryDetector,
    REXXProgramBoundaryDetector
)
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Strategy for generating valid program names
program_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@$-_',
    min_size=1,
    max_size=44
).filter(lambda x: x.strip() and not x.startswith('-'))

# Strategy for generating line numbers
line_numbers = st.integers(min_value=1, max_value=10000)

# Strategy for generating program types
program_types = st.sampled_from(list(ProgramType))

# Strategy for generating languages
supported_languages = st.sampled_from(['RPG', 'ASM', 'ASSEMBLER', 'NATURAL', 'REXX'])

# Strategy for generating simple source code content
simple_source_content = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n.-*/',
    min_size=10,
    max_size=1000
)


# Feature: program-level-dependency-tracking, Property 13: Program boundary completeness validation
# Validates: Requirements 8.1
@settings(max_examples=100)
@given(
    language=supported_languages,
    source_content=simple_source_content
)
def test_property_program_boundary_completeness_validation(language, source_content):
    """
    Property 13: Program boundary completeness validation
    
    For any analyzed source file, all code lines should be assigned to exactly 
    one program or marked as non-executable with no gaps or overlaps.
    """
    detector = ProgramBoundaryDetectorFactory.create_detector(language)
    assume(detector is not None)
    
    # Ensure source content has at least some lines
    lines = source_content.splitlines()
    assume(len(lines) >= 1)
    
    # Detect program boundaries
    programs = detector.detect_boundaries(source_content)
    
    # Validate boundaries using the detector's validation method
    is_valid, errors = detector.validate_boundaries(programs)
    
    # Property: No overlapping boundaries
    for i, prog1 in enumerate(programs):
        for j, prog2 in enumerate(programs[i+1:], i+1):
            assert not prog1.overlaps_with(prog2), \
                f"Programs '{prog1.program_name}' and '{prog2.program_name}' overlap: " \
                f"{prog1.start_line}-{prog1.end_line} vs {prog2.start_line}-{prog2.end_line}"
    
    # Property: All programs have valid line ranges
    for program in programs:
        assert program.start_line >= 1, \
            f"Program '{program.program_name}' has invalid start_line: {program.start_line}"
        assert program.end_line >= program.start_line, \
            f"Program '{program.program_name}' has end_line before start_line: {program.start_line}-{program.end_line}"
        assert program.end_line <= len(lines), \
            f"Program '{program.program_name}' end_line {program.end_line} exceeds total lines {len(lines)}"
    
    # Property: Validation method should return consistent results
    if programs:
        # If we have programs, validation should catch any issues we found above
        if not is_valid:
            assert len(errors) > 0, "Invalid boundaries should have error messages"
        else:
            assert len(errors) == 0, f"Valid boundaries should have no errors, but got: {errors}"


# Feature: program-level-dependency-tracking, Property 13: Program boundary non-overlap validation
# Validates: Requirements 8.1
@settings(max_examples=100)
@given(
    programs_data=st.lists(
        st.tuples(
            program_names,
            line_numbers,
            st.integers(min_value=1, max_value=100),  # line_count
            program_types
        ),
        min_size=1,
        max_size=10
    )
)
def test_property_program_boundary_non_overlap_validation(programs_data):
    """
    Property 13: Program boundary non-overlap validation
    
    For any set of program boundaries, overlapping boundaries should be 
    detected and reported as validation errors.
    """
    detector = RPGProgramBoundaryDetector()  # Use any detector for validation
    
    # Create program boundaries from the generated data
    programs = []
    for name, start_line, line_count, prog_type in programs_data:
        end_line = start_line + line_count - 1
        program = ProgramBoundary(
            program_name=name,
            start_line=start_line,
            end_line=end_line,
            program_type=prog_type,
            language="RPG",
            entry_points=[name]
        )
        programs.append(program)
    
    # Validate boundaries
    is_valid, errors = detector.validate_boundaries(programs)
    
    # Check for actual overlaps manually
    actual_overlaps = []
    for i, prog1 in enumerate(programs):
        for j, prog2 in enumerate(programs[i+1:], i+1):
            if prog1.overlaps_with(prog2):
                actual_overlaps.append((prog1, prog2))
    
    # Property: Validation should detect overlaps correctly
    if actual_overlaps:
        assert not is_valid, "Validation should report invalid when overlaps exist"
        assert len(errors) > 0, "Validation should provide error messages for overlaps"
        
        # Check that each overlap is mentioned in errors
        for prog1, prog2 in actual_overlaps:
            overlap_mentioned = any(
                prog1.program_name in error and prog2.program_name in error
                for error in errors
            )
            assert overlap_mentioned, \
                f"Overlap between '{prog1.program_name}' and '{prog2.program_name}' not mentioned in errors: {errors}"
    else:
        # No overlaps should mean valid (unless there are other issues)
        # We only check for overlaps in this test, so if no overlaps, should be valid
        overlap_errors = [e for e in errors if 'overlap' in e.lower()]
        assert len(overlap_errors) == 0, f"No overlaps exist but overlap errors reported: {overlap_errors}"


# Feature: program-level-dependency-tracking, Property 13: Program boundary line assignment completeness
# Validates: Requirements 8.1
@settings(max_examples=100)
@given(
    language=supported_languages,
    total_lines=st.integers(min_value=1, max_value=100)
)
def test_property_program_boundary_line_assignment_completeness(language, total_lines):
    """
    Property 13: Program boundary line assignment completeness
    
    For any source file, the program boundaries should account for all lines
    in the file (either assigned to programs or marked as non-executable).
    """
    detector = ProgramBoundaryDetectorFactory.create_detector(language)
    assume(detector is not None)
    
    # Create simple source content with the specified number of lines
    source_lines = [f"LINE {i+1} CONTENT" for i in range(total_lines)]
    source_content = '\n'.join(source_lines)
    
    # Parse with program detection
    result = detector.parse_with_program_detection(source_content)
    
    # Property: Total lines should match input
    assert result.total_lines == total_lines, \
        f"Expected {total_lines} total lines, but result shows {result.total_lines}"
    
    # Property: Coverage percentage should be calculated
    assert 0.0 <= result.coverage_percentage <= 100.0, \
        f"Coverage percentage should be between 0 and 100, got {result.coverage_percentage}"
    
    # Property: If programs exist, coverage should be > 0
    if result.programs:
        assert result.coverage_percentage > 0.0, \
            "If programs are detected, coverage should be greater than 0"
        
        # Property: All program lines should be within file bounds
        for program in result.programs:
            assert 1 <= program.start_line <= total_lines, \
                f"Program '{program.program_name}' start_line {program.start_line} out of bounds [1, {total_lines}]"
            assert 1 <= program.end_line <= total_lines, \
                f"Program '{program.program_name}' end_line {program.end_line} out of bounds [1, {total_lines}]"


# Feature: program-level-dependency-tracking, Property 13: Program boundary validation consistency
# Validates: Requirements 8.1
@settings(max_examples=100)
@given(
    language=supported_languages,
    source_content=simple_source_content
)
def test_property_program_boundary_validation_consistency(language, source_content):
    """
    Property 13: Program boundary validation consistency
    
    For any source file, running boundary detection and validation multiple times
    should produce consistent results.
    """
    detector = ProgramBoundaryDetectorFactory.create_detector(language)
    assume(detector is not None)
    
    # Ensure source content has at least some lines
    lines = source_content.splitlines()
    assume(len(lines) >= 1)
    
    # Run detection multiple times
    results = []
    validations = []
    
    for _ in range(3):  # Run 3 times to check consistency
        programs = detector.detect_boundaries(source_content)
        is_valid, errors = detector.validate_boundaries(programs)
        
        results.append(programs)
        validations.append((is_valid, errors))
    
    # Property: All detection results should be identical
    first_result = results[0]
    for i, result in enumerate(results[1:], start=1):
        assert len(result) == len(first_result), \
            f"Detection run {i} found {len(result)} programs, but run 0 found {len(first_result)}"
        
        # Compare each program (order might differ, so compare by name)
        first_names = {p.program_name: p for p in first_result}
        result_names = {p.program_name: p for p in result}
        
        assert first_names.keys() == result_names.keys(), \
            f"Detection run {i} found different program names: {result_names.keys()} vs {first_names.keys()}"
        
        for name in first_names:
            p1, p2 = first_names[name], result_names[name]
            assert p1.start_line == p2.start_line and p1.end_line == p2.end_line, \
                f"Program '{name}' boundaries differ between runs: {p1.start_line}-{p1.end_line} vs {p2.start_line}-{p2.end_line}"
    
    # Property: All validation results should be identical
    first_validation = validations[0]
    for i, validation in enumerate(validations[1:], start=1):
        assert validation[0] == first_validation[0], \
            f"Validation run {i} returned {validation[0]}, but run 0 returned {first_validation[0]}"
        assert len(validation[1]) == len(first_validation[1]), \
            f"Validation run {i} returned {len(validation[1])} errors, but run 0 returned {len(first_validation[1])}"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])