"""Unit tests for service grouping analyzer."""

import unittest
import sqlite3
import tempfile
import os
from tools.legacy_analyzer.analysis.service_grouping import ServiceGroupingAnalyzer
from tools.legacy_analyzer.models.flow import ServiceCandidate, EntryPoint


class TestServiceGroupingAnalyzer(unittest.TestCase):
    """Test cases for ServiceGroupingAnalyzer class."""
    
    def setUp(self):
        """Set up test database."""
        # Create temporary database
        self.db_fd, self.db_path = tempfile.mkstemp()
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create test tables
        self._create_test_tables()
        self._populate_test_data()
        
        # Create analyzer
        self.analyzer = ServiceGroupingAnalyzer(self.conn)
    
    def tearDown(self):
        """Clean up test database."""
        self.conn.close()
        os.close(self.db_fd)
        os.unlink(self.db_path)
    
    def _create_test_tables(self):
        """Create test database tables."""
        # Create inventory_cics table
        self.cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20)
            )
        """)
        
        # Create artifact_dependencies table
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(30) NOT NULL
            )
        """)
        
        self.conn.commit()
    
    def _populate_test_data(self):
        """Populate test data for service grouping analysis."""
        # Add CICS transactions for CARDDEMO group
        cics_data = [
            ('CAUP', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTUPC', 'Account Update'),
            ('CMEN', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COMENUC', 'Main Menu'),
            ('CCRD', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COCRDLIC', 'Card List'),
            ('CUSR', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COUSRC', 'User Management'),
            # Add another group
            ('PAYR', 'TRANSACTION', 'PAYROLL', 'ENABLED', 'PAYROLL1', 'Payroll Processing'),
            ('PAYE', 'TRANSACTION', 'PAYROLL', 'ENABLED', 'PAYROLL2', 'Employee Pay'),
        ]
        
        for resource_name, resource_type, group_name, status, program_name, description in cics_data:
            self.cursor.execute("""
                INSERT INTO inventory_cics 
                (resource_name, resource_type, group_name, status, program_name, description)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (resource_name, resource_type, group_name, status, program_name, description))
        
        # Add program dependencies (CALL relationships)
        call_deps = [
            # CARDDEMO programs call shared utilities
            ('COACTUPC', 'PROGRAM', 'CBACT01C', 'PROGRAM', 'CALL'),
            ('COACTUPC', 'PROGRAM', 'CBACT02C', 'PROGRAM', 'CALL'),
            ('COMENUC', 'PROGRAM', 'CBACT01C', 'PROGRAM', 'CALL'),
            ('COCRDLIC', 'PROGRAM', 'CBACT01C', 'PROGRAM', 'CALL'),
            ('COCRDLIC', 'PROGRAM', 'CBACT03C', 'PROGRAM', 'CALL'),
            # PAYROLL programs call shared utilities
            ('PAYROLL1', 'PROGRAM', 'PAYUTIL1', 'PROGRAM', 'CALL'),
            ('PAYROLL2', 'PROGRAM', 'PAYUTIL1', 'PROGRAM', 'CALL'),
        ]
        
        for source, source_type, target, target_type, dep_type in call_deps:
            self.cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_type, target_artifact_name, target_type, dependency_type)
                VALUES (?, ?, ?, ?, ?)
            """, (source, source_type, target, target_type, dep_type))
        
        # Add data dependencies (dataset access)
        data_deps = [
            # CARDDEMO programs access card-related datasets
            ('COACTUPC', 'PROGRAM', 'AWS.M2.CARDDEMO.ACCTDATA', 'DATASET', 'READ'),
            ('COACTUPC', 'PROGRAM', 'AWS.M2.CARDDEMO.ACCTDATA', 'DATASET', 'WRITE'),
            ('COMENUC', 'PROGRAM', 'AWS.M2.CARDDEMO.CUSTDATA', 'DATASET', 'READ'),
            ('COCRDLIC', 'PROGRAM', 'AWS.M2.CARDDEMO.ACCTDATA', 'DATASET', 'READ'),
            ('COCRDLIC', 'PROGRAM', 'AWS.M2.CARDDEMO.CARDDATA', 'DATASET', 'READ'),
            ('COUSRC', 'PROGRAM', 'AWS.M2.CARDDEMO.CUSTDATA', 'DATASET', 'READ'),
            ('COUSRC', 'PROGRAM', 'AWS.M2.CARDDEMO.CUSTDATA', 'DATASET', 'UPDATE'),
            # PAYROLL programs access payroll datasets
            ('PAYROLL1', 'PROGRAM', 'PAYROLL.EMPLOYEE.DATA', 'DATASET', 'READ'),
            ('PAYROLL2', 'PROGRAM', 'PAYROLL.EMPLOYEE.DATA', 'DATASET', 'READ'),
            ('PAYROLL2', 'PROGRAM', 'PAYROLL.PAYMENT.DATA', 'DATASET', 'WRITE'),
        ]
        
        for source, source_type, target, target_type, dep_type in data_deps:
            self.cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_type, target_artifact_name, target_type, dependency_type)
                VALUES (?, ?, ?, ?, ?)
            """, (source, source_type, target, target_type, dep_type))
        
        self.conn.commit()
    
    def test_check_tables_exist(self):
        """Test that analyzer correctly identifies existing tables."""
        self.assertTrue(self.analyzer._has_cics_table)
        self.assertTrue(self.analyzer._has_dependencies_table)
    
    def test_analyze_by_cics_group(self):
        """Test grouping by CICS GROUP."""
        candidates = self.analyzer.analyze_by_cics_group()
        
        # Should find 2 groups: CARDDEMO and PAYROLL
        self.assertEqual(len(candidates), 2)
        
        # Check CARDDEMO group
        carddemo = next(c for c in candidates if c.cics_group == 'CARDDEMO')
        self.assertEqual(carddemo.grouping_reason, 'CICS_GROUP')
        self.assertEqual(carddemo.total_programs, 4)
        self.assertGreater(len(carddemo.entry_points), 0)
        
        # Check that entry points are EntryPoint objects
        self.assertIsInstance(carddemo.entry_points[0], EntryPoint)
        self.assertIn('COACTUPC', [ep.program_name for ep in carddemo.entry_points])
        
        # Check that shared data is populated
        self.assertGreater(len(carddemo.shared_data), 0)
        
        # Check that shared programs is populated
        self.assertGreater(len(carddemo.shared_programs), 0)
        self.assertIn('CBACT01C', carddemo.shared_programs)
        
        # Check PAYROLL group
        payroll = next(c for c in candidates if c.cics_group == 'PAYROLL')
        self.assertEqual(payroll.total_programs, 2)
    
    def test_analyze_by_data_ownership(self):
        """Test grouping by shared data access."""
        candidates = self.analyzer.analyze_by_data_ownership()
        
        # Should find at least one cluster
        self.assertGreater(len(candidates), 0)
        
        # Check that candidates have shared data
        for candidate in candidates:
            self.assertEqual(candidate.grouping_reason, 'DATA_OWNERSHIP')
            self.assertGreater(len(candidate.shared_data), 0)
            self.assertGreater(candidate.total_programs, 0)
            # Check that entry points are EntryPoint objects
            if candidate.entry_points:
                self.assertIsInstance(candidate.entry_points[0], EntryPoint)
    
    def test_analyze_by_shared_programs(self):
        """Test grouping by shared program dependencies."""
        candidates = self.analyzer.analyze_by_shared_programs()
        
        # Should find at least one cluster
        self.assertGreater(len(candidates), 0)
        
        # Check that candidates have shared programs
        for candidate in candidates:
            self.assertEqual(candidate.grouping_reason, 'SHARED_PROGRAMS')
            self.assertGreater(len(candidate.shared_programs), 0)
            self.assertGreater(candidate.total_programs, 0)
            # Check that entry points are EntryPoint objects
            if candidate.entry_points:
                self.assertIsInstance(candidate.entry_points[0], EntryPoint)
    
    def test_calculate_consolidation_score(self):
        """Test consolidation score calculation."""
        # High score: many entry points, shared data, and programs
        score1 = self.analyzer._calculate_consolidation_score(5, 3, 4)
        self.assertGreater(score1, 50)
        
        # Medium score: some entry points and resources
        score2 = self.analyzer._calculate_consolidation_score(2, 1, 1)
        self.assertGreater(score2, 20)
        self.assertLess(score2, 50)
        
        # Low score: few entry points and resources
        score3 = self.analyzer._calculate_consolidation_score(1, 0, 0)
        self.assertLess(score3, 20)
        
        # Scores should be ordered
        self.assertGreater(score1, score2)
        self.assertGreater(score2, score3)
    
    def test_determine_confidence(self):
        """Test confidence level determination."""
        # High confidence: multiple entry points with shared resources
        conf1 = self.analyzer._determine_confidence(4, 3, 2)
        self.assertEqual(conf1, 'HIGH')
        
        # Medium confidence: some entry points with some resources
        conf2 = self.analyzer._determine_confidence(2, 1, 1)
        self.assertEqual(conf2, 'MEDIUM')
        
        # Low confidence: few entry points or no shared resources
        conf3 = self.analyzer._determine_confidence(1, 0, 0)
        self.assertEqual(conf3, 'LOW')
    
    def test_generate_recommendation(self):
        """Test recommendation generation."""
        # CONSIDER_MERGE: high score and multiple entry points
        rec1 = self.analyzer._generate_recommendation(4, 65.0)
        self.assertEqual(rec1, 'CONSIDER_MERGE')
        
        # KEEP_SEPARATE: low score or few entry points
        rec2 = self.analyzer._generate_recommendation(1, 20.0)
        self.assertEqual(rec2, 'KEEP_SEPARATE')
        
        # NEEDS_REVIEW: borderline cases
        rec3 = self.analyzer._generate_recommendation(2, 45.0)
        self.assertEqual(rec3, 'NEEDS_REVIEW')
    
    def test_generate_service_name(self):
        """Test service name generation from CICS group."""
        name1 = self.analyzer._generate_service_name('CARDDEMO')
        self.assertIn('Card', name1)
        self.assertIn('Service', name1)
        
        name2 = self.analyzer._generate_service_name('PAYROLL')
        self.assertIn('Payroll', name2)
        self.assertIn('Service', name2)
    
    def test_generate_service_name_from_dataset(self):
        """Test service name generation from dataset name."""
        name1 = self.analyzer._generate_service_name_from_dataset(
            'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS'
        )
        self.assertIn('Service', name1)
        
        name2 = self.analyzer._generate_service_name_from_dataset(
            'PAYROLL.EMPLOYEE.DATA'
        )
        self.assertIn('Service', name2)
    
    def test_service_candidate_to_dict(self):
        """Test ServiceCandidate.to_dict() method."""
        entry_point = EntryPoint(
            program_name='TESTPROG',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='TEST',
            description='Test'
        )
        
        candidate = ServiceCandidate(
            name='Test Service',
            entry_points=[entry_point],
            grouping_reason='CICS_GROUP',
            confidence='HIGH',
            cics_group='TESTGRP',
            shared_data=['DATASET1', 'DATASET2'],
            shared_programs=['UTIL1', 'UTIL2'],
            total_complexity=75.5,
            recommendation='CONSIDER_MERGE'
        )
        
        result = candidate.to_dict()
        
        self.assertEqual(result['name'], 'Test Service')
        self.assertEqual(result['grouping_reason'], 'CICS_GROUP')
        self.assertEqual(result['confidence'], 'HIGH')
        self.assertEqual(result['cics_group'], 'TESTGRP')
        self.assertEqual(len(result['entry_points']), 1)
        self.assertEqual(len(result['shared_data']), 2)
        self.assertEqual(len(result['shared_programs']), 2)
        self.assertEqual(result['total_programs'], 1)
        self.assertEqual(result['total_complexity'], 75.5)
        self.assertEqual(result['recommendation'], 'CONSIDER_MERGE')
    
    def test_get_shared_data_for_group(self):
        """Test getting shared data for a CICS group."""
        shared_data = self.analyzer._get_shared_data_for_group('CARDDEMO')
        
        # Should find datasets accessed by CARDDEMO programs
        self.assertGreater(len(shared_data), 0)
        self.assertIn('AWS.M2.CARDDEMO.ACCTDATA', shared_data)
    
    def test_get_shared_programs_for_group(self):
        """Test getting shared programs for a CICS group."""
        shared_programs = self.analyzer._get_shared_programs_for_group('CARDDEMO')
        
        # Should find CBACT01C (called by multiple CARDDEMO programs)
        self.assertGreater(len(shared_programs), 0)
        self.assertIn('CBACT01C', shared_programs)
    
    def test_get_entry_points_for_programs(self):
        """Test getting entry point information for programs."""
        programs = {'COACTUPC', 'COMENUC'}
        entry_points = self.analyzer._get_entry_points_for_programs(programs)
        
        # Should find entry points for these programs
        self.assertEqual(len(entry_points), 2)
        
        # Check that they are EntryPoint objects
        self.assertIsInstance(entry_points[0], EntryPoint)
        
        # Check that transaction IDs are included
        trans_ids = [ep.transaction_id for ep in entry_points]
        self.assertIn('CAUP', trans_ids)
        self.assertIn('CMEN', trans_ids)
    
    def test_get_shared_programs_for_programs(self):
        """Test getting shared programs for a set of programs."""
        programs = {'COACTUPC', 'COMENUC', 'COCRDLIC'}
        shared_programs = self.analyzer._get_shared_programs_for_programs(programs)
        
        # Should find CBACT01C (called by multiple programs)
        self.assertGreater(len(shared_programs), 0)
        self.assertIn('CBACT01C', shared_programs)
    
    def test_get_shared_data_for_programs(self):
        """Test getting shared data for a set of programs."""
        programs = {'COACTUPC', 'COCRDLIC'}
        shared_data = self.analyzer._get_shared_data_for_programs(programs)
        
        # Should find shared dataset
        self.assertGreater(len(shared_data), 0)
        self.assertIn('AWS.M2.CARDDEMO.ACCTDATA', shared_data)
    
    def test_missing_cics_table(self):
        """Test graceful handling when inventory_cics table doesn't exist."""
        # Create new database without CICS table
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        
        try:
            analyzer = ServiceGroupingAnalyzer(conn)
            
            # Should not have CICS table
            self.assertFalse(analyzer._has_cics_table)
            
            # Should return empty list, not error
            candidates = analyzer.analyze_by_cics_group()
            self.assertEqual(len(candidates), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)
    
    def test_missing_dependencies_table(self):
        """Test graceful handling when artifact_dependencies table doesn't exist."""
        # Create new database without dependencies table
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        
        try:
            analyzer = ServiceGroupingAnalyzer(conn)
            
            # Should not have dependencies table
            self.assertFalse(analyzer._has_dependencies_table)
            
            # Should return empty list, not error
            candidates = analyzer.analyze_by_data_ownership()
            self.assertEqual(len(candidates), 0)
            
            candidates = analyzer.analyze_by_shared_programs()
            self.assertEqual(len(candidates), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)
    
    def test_empty_database(self):
        """Test behavior with empty database."""
        # Create new database with tables but no data
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                description TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(30) NOT NULL
            )
        """)
        
        conn.commit()
        
        try:
            analyzer = ServiceGroupingAnalyzer(conn)
            
            # Should handle empty database gracefully
            candidates = analyzer.analyze_by_cics_group()
            self.assertEqual(len(candidates), 0)
            
            candidates = analyzer.analyze_by_data_ownership()
            self.assertEqual(len(candidates), 0)
            
            candidates = analyzer.analyze_by_shared_programs()
            self.assertEqual(len(candidates), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)


if __name__ == '__main__':
    unittest.main()
