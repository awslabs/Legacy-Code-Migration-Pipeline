#!/usr/bin/env python3
"""
Property-based tests for language-specific program boundary detection.

These tests use Hypothesis to verify correctness properties across
many randomly generated inputs for different programming languages.
"""

import os
import sys
import tempfile
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.analysis.program_boundary_detector import (
    ProgramBoundaryDetectorFactory,
    RPGProgramBoundaryDetector,
    AssemblerProgramBoundaryDetector,
    NaturalProgramBoundaryDetector,
    REXXProgramBoundaryDetector
)
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Strategy for generating valid program names
program_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@$_',
    min_size=1,
    max_size=44
).filter(lambda x: x.strip() and not x.startswith('-'))

# Strategy for generating RPG source code with H-specs
rpg_source_content = st.builds(
    lambda h_specs, other_lines: '\n'.join(h_specs + other_lines),
    h_specs=st.lists(
        st.builds(
            lambda name: f"H NOMAIN MAIN({name})" if name else "H NOMAIN",
            name=st.one_of(st.none(), program_names)
        ),
        min_size=1,
        max_size=3
    ),
    other_lines=st.lists(
        st.sampled_from([
            "F MYFILE   IF   E           DISK",
            "D MyVar           S             10A",
            "C                   EVAL      MyVar = 'TEST'",
            "DCL-PR MyProc;",
            "END-PR;",
            "DCL-PROC MyProc;",
            "END-PROC;",
            ""
        ]),
        min_size=0,
        max_size=10
    )
)

# Strategy for generating Assembler source code with CSECT
assembler_source_content = st.builds(
    lambda csects, other_lines: '\n'.join(csects + other_lines),
    csects=st.lists(
        st.builds(
            lambda name: f"{name}    CSECT",
            name=program_names
        ),
        min_size=1,
        max_size=3
    ),
    other_lines=st.lists(
        st.sampled_from([
            "         USING *,15",
            "         LR    1,2",
            "         ST    1,SAVEAREA",
            "         ENTRY MYENTRY",
            "         BR    14",
            "SAVEAREA DS    F",
            "         END",
            ""
        ]),
        min_size=0,
        max_size=10
    )
)

# Strategy for generating Natural source code
natural_source_content = st.builds(
    lambda programs, other_lines: '\n'.join(programs + other_lines),
    programs=st.lists(
        st.one_of(
            st.just("DEFINE DATA PROGRAM"),
            st.just("DEFINE DATA SUBPROGRAM")
        ),
        min_size=1,
        max_size=3
    ),
    other_lines=st.lists(
        st.sampled_from([
            "LOCAL",
            "1 #VAR (A10)",
            "END-DEFINE",
            "MOVE 'TEST' TO #VAR",
            "CALLNAT 'SUBPROG'",
            "END",
            ""
        ]),
        min_size=0,
        max_size=10
    )
)

# Strategy for generating REXX source code
rexx_source_content = st.builds(
    lambda procedures, other_lines: '\n'.join(other_lines + procedures),
    procedures=st.lists(
        st.builds(
            lambda name: f"{name}: PROCEDURE\n  RETURN",
            name=program_names
        ),
        min_size=0,
        max_size=3
    ),
    other_lines=st.lists(
        st.sampled_from([
            "/* REXX */",
            "SAY 'Hello World'",
            "CALL MYPROC",
            "EXIT 0",
            ""
        ]),
        min_size=1,
        max_size=10
    )
)


# Feature: program-level-dependency-tracking, Property 11: Language-specific program boundary detection
# Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
@settings(max_examples=100)
@given(
    rpg_content=rpg_source_content
)
def test_property_rpg_program_boundary_detection(rpg_content):
    """
    Property 11: Language-specific program boundary detection (RPG)
    
    For any RPG source file, the parser should identify program boundaries 
    using H-spec, F-spec, and procedure definitions with accurate line numbers.
    """
    detector = RPGProgramBoundaryDetector()
    
    # Ensure content has some lines
    lines = rpg_content.splitlines()
    assume(len(lines) >= 1)
    
    # Detect program boundaries
    programs = detector.detect_boundaries(rpg_content)
    
    # Property: All detected programs should have valid RPG characteristics
    for program in programs:
        assert program.language == "RPG", \
            f"Program '{program.program_name}' should have language 'RPG', got '{program.language}'"
        
        assert program.program_type in [ProgramType.MAIN, ProgramType.PROCEDURE], \
            f"Program '{program.program_name}' should be MAIN or PROCEDURE, got {program.program_type}"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
    
    # Property: Programs should not overlap
    for i, prog1 in enumerate(programs):
        for prog2 in programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"RPG programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: If H-spec lines exist, should detect at least one program
    h_spec_lines = [line for line in lines if line.strip().upper().startswith('H')]
    if h_spec_lines:
        assert len(programs) > 0, \
            "RPG source with H-spec should detect at least one program"


# Feature: program-level-dependency-tracking, Property 11: Language-specific program boundary detection
# Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
@settings(max_examples=100)
@given(
    asm_content=assembler_source_content
)
def test_property_assembler_program_boundary_detection(asm_content):
    """
    Property 11: Language-specific program boundary detection (Assembler)
    
    For any Assembler source file, the parser should identify CSECT boundaries 
    and ENTRY points as separate programs with accurate line numbers.
    """
    detector = AssemblerProgramBoundaryDetector()
    
    # Ensure content has some lines
    lines = asm_content.splitlines()
    assume(len(lines) >= 1)
    
    # Detect program boundaries
    programs = detector.detect_boundaries(asm_content)
    
    # Property: All detected programs should have valid Assembler characteristics
    for program in programs:
        assert program.language == "ASM", \
            f"Program '{program.program_name}' should have language 'ASM', got '{program.language}'"
        
        assert program.program_type in [ProgramType.CSECT, ProgramType.MAIN, ProgramType.ENTRY_POINT], \
            f"Program '{program.program_name}' should be CSECT, MAIN, or ENTRY_POINT type, got {program.program_type}"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
    
    # Property: Programs should not overlap
    for i, prog1 in enumerate(programs):
        for prog2 in programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"Assembler programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: If CSECT lines exist, should detect corresponding programs
    csect_lines = [line for line in lines if 'CSECT' in line.upper()]
    if csect_lines:
        assert len(programs) > 0, \
            "Assembler source with CSECT should detect at least one program"
        
        # Should have at least as many programs as CSECT definitions
        assert len(programs) >= len(csect_lines), \
            f"Should detect at least {len(csect_lines)} programs for {len(csect_lines)} CSECT definitions"


# Feature: program-level-dependency-tracking, Property 11: Language-specific program boundary detection
# Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
@settings(max_examples=100)
@given(
    natural_content=natural_source_content
)
def test_property_natural_program_boundary_detection(natural_content):
    """
    Property 11: Language-specific program boundary detection (Natural)
    
    For any Natural source file, the parser should identify DEFINE DATA PROGRAM 
    and DEFINE DATA SUBPROGRAM boundaries with accurate line numbers.
    """
    detector = NaturalProgramBoundaryDetector()
    
    # Ensure content has some lines
    lines = natural_content.splitlines()
    assume(len(lines) >= 1)
    
    # Detect program boundaries
    programs = detector.detect_boundaries(natural_content)
    
    # Property: All detected programs should have valid Natural characteristics
    for program in programs:
        assert program.language == "NATURAL", \
            f"Program '{program.program_name}' should have language 'NATURAL', got '{program.language}'"
        
        assert program.program_type in [ProgramType.MAIN, ProgramType.SUBPROGRAM], \
            f"Program '{program.program_name}' should be MAIN or SUBPROGRAM, got {program.program_type}"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
    
    # Property: Programs should not overlap
    for i, prog1 in enumerate(programs):
        for prog2 in programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"Natural programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: If DEFINE DATA lines exist, should detect corresponding programs
    define_lines = [line for line in lines if 'DEFINE DATA' in line.upper()]
    if define_lines:
        assert len(programs) > 0, \
            "Natural source with DEFINE DATA should detect at least one program"


# Feature: program-level-dependency-tracking, Property 11: Language-specific program boundary detection
# Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
@settings(max_examples=100)
@given(
    rexx_content=rexx_source_content
)
def test_property_rexx_program_boundary_detection(rexx_content):
    """
    Property 11: Language-specific program boundary detection (REXX)
    
    For any REXX source file, the parser should identify procedure definitions 
    and their boundaries with accurate line numbers.
    """
    detector = REXXProgramBoundaryDetector()
    
    # Ensure content has some lines
    lines = rexx_content.splitlines()
    assume(len(lines) >= 1)
    
    # Detect program boundaries
    programs = detector.detect_boundaries(rexx_content)
    
    # Property: All detected programs should have valid REXX characteristics
    for program in programs:
        assert program.language == "REXX", \
            f"Program '{program.program_name}' should have language 'REXX', got '{program.language}'"
        
        assert program.program_type in [ProgramType.MAIN, ProgramType.PROCEDURE], \
            f"Program '{program.program_name}' should be MAIN or PROCEDURE, got {program.program_type}"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
    
    # Property: Programs should not overlap
    for i, prog1 in enumerate(programs):
        for prog2 in programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"REXX programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: Should always detect at least a main program
    assert len(programs) >= 1, \
        "REXX source should always detect at least a main program"
    
    # Property: Should have exactly one MAIN program
    main_programs = [p for p in programs if p.program_type == ProgramType.MAIN]
    assert len(main_programs) <= 1, \
        f"REXX source should have at most one MAIN program, found {len(main_programs)}"


# Feature: program-level-dependency-tracking, Property 11: Language-specific boundary detection factory
# Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
@settings(max_examples=100)
@given(
    language=st.sampled_from(['RPG', 'ASM', 'ASSEMBLER', 'NATURAL', 'REXX'])
)
def test_property_language_specific_detector_factory(language):
    """
    Property 11: Language-specific boundary detection factory
    
    For any supported language, the factory should create the appropriate 
    detector that returns results consistent with the language.
    """
    detector = ProgramBoundaryDetectorFactory.create_detector(language)
    
    # Property: Factory should create detector for supported languages
    assert detector is not None, \
        f"Factory should create detector for supported language '{language}'"
    
    # Property: Detector should report correct language
    assert detector.get_language() == language or (language == 'ASSEMBLER' and detector.get_language() == 'ASM'), \
        f"Detector should report language '{language}', got '{detector.get_language()}'"
    
    # Property: Detector should have supported file extensions
    extensions = detector.get_supported_file_extensions()
    assert isinstance(extensions, list), \
        f"Detector should return list of extensions, got {type(extensions)}"
    
    # Property: All extensions should start with dot
    for ext in extensions:
        assert ext.startswith('.'), \
            f"File extension '{ext}' should start with dot"


# Feature: program-level-dependency-tracking, Property 11: Language-specific boundary detection consistency
# Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
@settings(max_examples=100)
@given(
    language=st.sampled_from(['RPG', 'ASM', 'NATURAL', 'REXX']),
    source_content=st.text(
        alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n.-*/:',
        min_size=10,
        max_size=500
    )
)
def test_property_language_specific_boundary_detection_consistency(language, source_content):
    """
    Property 11: Language-specific boundary detection consistency
    
    For any language and source content, running boundary detection multiple times
    should produce identical results.
    """
    detector = ProgramBoundaryDetectorFactory.create_detector(language)
    assume(detector is not None)
    
    # Ensure source content has at least some lines
    lines = source_content.splitlines()
    assume(len(lines) >= 1)
    
    # Run detection multiple times
    results = []
    for _ in range(3):
        programs = detector.detect_boundaries(source_content)
        results.append(programs)
    
    # Property: All results should be identical
    first_result = results[0]
    for i, result in enumerate(results[1:], start=1):
        assert len(result) == len(first_result), \
            f"Detection run {i} found {len(result)} programs, but run 0 found {len(first_result)}"
        
        # Compare programs by name and boundaries
        first_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in first_result}
        result_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in result}
        
        assert first_dict == result_dict, \
            f"Detection run {i} produced different results than run 0"


# Feature: program-level-dependency-tracking, Property 11: Language-specific boundary detection with file paths
# Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
@settings(max_examples=100)
@given(
    language=st.sampled_from(['RPG', 'ASM', 'NATURAL', 'REXX']),
    file_path=st.text(
        alphabet='abcdefghijklmnopqrstuvwxyz0123456789_-.',
        min_size=5,
        max_size=50
    ).map(lambda x: f"/path/to/{x}.src")
)
def test_property_language_specific_boundary_detection_with_file_paths(language, file_path):
    """
    Property 11: Language-specific boundary detection with file paths
    
    For any language and file path, boundary detection should work correctly
    and include file path information in the results.
    """
    detector = ProgramBoundaryDetectorFactory.create_detector(language)
    assume(detector is not None)
    
    # Create simple source content
    source_content = "LINE 1\nLINE 2\nLINE 3"
    
    # Detect boundaries with file path
    programs = detector.detect_boundaries(source_content, file_path)
    
    # Property: All programs should have the correct file path
    for program in programs:
        assert program.file_path == file_path, \
            f"Program '{program.program_name}' should have file_path '{file_path}', got '{program.file_path}'"
    
    # Property: Parse result should include file path
    result = detector.parse_with_program_detection(source_content, file_path)
    assert result.file_path == file_path, \
        f"Parse result should have file_path '{file_path}', got '{result.file_path}'"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])