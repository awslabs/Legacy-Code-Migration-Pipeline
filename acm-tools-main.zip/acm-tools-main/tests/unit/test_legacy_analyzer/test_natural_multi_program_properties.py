#!/usr/bin/env python3
"""
Property-based tests for Natural multi-program parsing.

**Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Natural)**
**Validates: Requirements 1.3**

These tests use Hypothesis to verify correctness properties across
many randomly generated Natural source files with multiple programs.
"""

import os
import sys
import tempfile
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.parsers.natural_parser import NaturalDependencyParser
from tools.legacy_analyzer.analysis.program_boundary_detector import NaturalProgramBoundaryDetector
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Strategy for generating valid Natural program names
natural_program_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_',
    min_size=1,
    max_size=44
).filter(lambda x: x.strip() and not x.startswith('-') and x.replace('-', '').replace('_', '').isalnum())

# Strategy for generating Natural DEFINE DATA statements
natural_define_data_program = st.just("DEFINE DATA PROGRAM")
natural_define_data_subprogram = st.just("DEFINE DATA SUBPROGRAM")
natural_define_data_parameter = st.just("DEFINE DATA PARAMETER")
natural_define_data_local = st.just("DEFINE DATA\nLOCAL")
natural_define_data_global = st.just("DEFINE DATA GLOBAL")

# Strategy for generating Natural END-DEFINE statements
natural_end_define = st.just("END-DEFINE")

# Strategy for generating Natural program statements
natural_callnat_statements = st.builds(
    lambda prog_name: f"CALLNAT '{prog_name}' #PARAM",
    prog_name=natural_program_names
)

natural_fetch_statements = st.builds(
    lambda prog_name: f"FETCH '{prog_name}'",
    prog_name=natural_program_names
)

natural_include_statements = st.builds(
    lambda copycode: f"INCLUDE {copycode}",
    copycode=natural_program_names
)

natural_using_statements = st.builds(
    lambda data_area: f"GLOBAL USING {data_area}",
    data_area=natural_program_names
)

# Strategy for generating Natural variable definitions
natural_variable_definitions = st.builds(
    lambda var_name: f"1 #{var_name} (A10)",
    var_name=natural_program_names.filter(lambda x: len(x) <= 10)
)

# Strategy for generating Natural comments
natural_comments = st.builds(
    lambda comment: f"* {comment}",
    comment=st.text(alphabet='abcdefghijklmnopqrstuvwxyz0123456789 .,!?', min_size=1, max_size=50)
)

# Strategy for generating Natural END statements
natural_end_statement = st.just("END")

# Strategy for generating multi-program Natural source
natural_multi_program_source = st.builds(
    lambda statements: '\n'.join(statements),
    statements=st.lists(
        st.one_of(
            natural_define_data_program,
            natural_define_data_subprogram,
            natural_define_data_parameter,
            natural_define_data_local,
            natural_define_data_global,
            natural_end_define,
            natural_callnat_statements,
            natural_fetch_statements,
            natural_include_statements,
            natural_using_statements,
            natural_variable_definitions,
            natural_comments,
            natural_end_statement,
            st.just("WRITE 'Hello World'"),
            st.just("RESET #VAR")
        ),
        min_size=3,
        max_size=20
    )
)


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Natural)**
# **Validates: Requirements 1.3**
@settings(max_examples=100)
@given(
    natural_source=natural_multi_program_source
)
def test_property_natural_multi_program_parsing_accuracy(natural_source):
    """
    Property 1: Multi-program file parsing accuracy (Natural)
    
    For any Natural source file containing multiple programs, parsing should identify 
    each individual program with correct boundaries and track dependencies 
    separately for each program.
    """
    parser = NaturalDependencyParser()
    detector = NaturalProgramBoundaryDetector()
    
    # Ensure source has some content
    lines = natural_source.splitlines()
    assume(len(lines) >= 1)
    assume(any(line.strip() for line in lines))  # At least one non-empty line
    
    # Test program boundary detection
    programs = detector.detect_boundaries(natural_source)
    
    # Property: All detected programs should have valid Natural characteristics
    for program in programs:
        assert program.language == "NATURAL", \
            f"Program '{program.program_name}' should have language 'NATURAL', got '{program.language}'"
        
        assert program.program_type in [ProgramType.MAIN, ProgramType.SUBPROGRAM, ProgramType.FUNCTION], \
            f"Program '{program.program_name}' should be MAIN, SUBPROGRAM, or FUNCTION, got {program.program_type}"
        
        assert program.start_line >= 1, \
            f"Program '{program.program_name}' should have start_line >= 1, got {program.start_line}"
        
        assert program.end_line >= program.start_line, \
            f"Program '{program.program_name}' should have end_line >= start_line"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
        
        assert 0.0 <= program.confidence_level <= 1.0, \
            f"Program '{program.program_name}' should have confidence_level between 0.0 and 1.0"
    
    # Property: Programs should not overlap
    for i, prog1 in enumerate(programs):
        for prog2 in programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"Natural programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: If DEFINE DATA PROGRAM/SUBPROGRAM lines exist, should detect at least one program
    define_program_lines = [line for line in lines 
                          if 'DEFINE DATA PROGRAM' in line.upper() or 'DEFINE DATA SUBPROGRAM' in line.upper()]
    if define_program_lines:
        assert len(programs) > 0, \
            "Natural source with DEFINE DATA PROGRAM/SUBPROGRAM should detect at least one program"
    
    # Test enhanced parser functionality
    if hasattr(parser, 'detect_program_boundaries'):
        parser_programs = parser.detect_program_boundaries(natural_source)
        
        # Property: Parser and detector should produce consistent results
        assert len(parser_programs) == len(programs), \
            f"Parser detected {len(parser_programs)} programs, detector found {len(programs)}"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Natural)**
# **Validates: Requirements 1.3**
@settings(max_examples=100)
@given(
    program_count=st.integers(min_value=1, max_value=5),
    program_names=st.lists(natural_program_names, min_size=1, max_size=5)
)
def test_property_natural_multiple_define_data_detection(program_count, program_names):
    """
    Property 1: Multi-program file parsing accuracy (Natural) - Multiple DEFINE DATA
    
    For any Natural source file with multiple DEFINE DATA PROGRAM/SUBPROGRAM statements,
    each should be detected as a separate program with correct boundaries.
    """
    assume(len(program_names) >= program_count)
    
    detector = NaturalProgramBoundaryDetector()
    
    # Create source with multiple DEFINE DATA statements
    source_lines = []
    for i in range(program_count):
        if i % 2 == 0:
            source_lines.append("DEFINE DATA PROGRAM")
        else:
            source_lines.append("DEFINE DATA SUBPROGRAM")
        
        # Add some content after each DEFINE DATA
        source_lines.extend([
            "LOCAL",
            f"1 #VAR{i+1} (A10)",
            "END-DEFINE",
            f"WRITE 'Program {i+1}'",
            "END",
            ""
        ])
    
    natural_source = '\n'.join(source_lines)
    programs = detector.detect_boundaries(natural_source)
    
    # Property: Should detect at least as many programs as DEFINE DATA statements
    assert len(programs) >= program_count, \
        f"Should detect at least {program_count} programs for {program_count} DEFINE DATA statements, got {len(programs)}"
    
    # Property: Each program should have distinct boundaries
    program_ranges = [(p.start_line, p.end_line) for p in programs]
    assert len(set(program_ranges)) == len(program_ranges), \
        "All programs should have distinct line ranges"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Natural)**
# **Validates: Requirements 1.3**
@settings(max_examples=100)
@given(
    main_program=natural_program_names,
    callnats=st.lists(natural_program_names, min_size=0, max_size=3),
    fetches=st.lists(natural_program_names, min_size=0, max_size=3),
    includes=st.lists(natural_program_names, min_size=0, max_size=3),
    usings=st.lists(natural_program_names, min_size=0, max_size=3)
)
def test_property_natural_dependency_separation_per_program(main_program, callnats, fetches, includes, usings):
    """
    Property 1: Multi-program file parsing accuracy (Natural) - Dependency separation
    
    For any Natural source file with multiple programs, dependencies should be 
    tracked separately for each program based on their line boundaries.
    """
    parser = NaturalDependencyParser()
    
    # Create Natural source with main program
    source_lines = [
        "DEFINE DATA PROGRAM",
        "LOCAL"
    ]
    
    # Add USING statements
    for using in usings:
        source_lines.append(f"GLOBAL USING {using}")
    
    source_lines.extend([
        "1 #VAR (A10)",
        "END-DEFINE"
    ])
    
    # Add INCLUDE statements
    for include in includes:
        source_lines.append(f"INCLUDE {include}")
    
    # Add CALLNAT statements
    for callnat in callnats:
        source_lines.append(f"CALLNAT '{callnat}' #VAR")
    
    # Add FETCH statements
    for fetch in fetches:
        source_lines.append(f"FETCH '{fetch}'")
    
    source_lines.append("END")
    
    natural_source = '\n'.join(source_lines)
    
    # Test traditional parsing
    traditional_result = parser.parse(natural_source)
    
    # Property: Traditional parsing should find all dependencies
    all_expected_callnats = set(callnats)
    all_expected_fetches = set(fetches)
    all_expected_includes = set(includes)
    all_expected_usings = set(usings)
    
    found_callnats = set(traditional_result.get('callnat', []))
    found_fetches = set(traditional_result.get('fetch', []))
    found_includes = set(traditional_result.get('includes', []))
    found_usings = set(traditional_result.get('using', []))
    
    assert all_expected_callnats.issubset(found_callnats), \
        f"Traditional parsing should find all CALLNATs: expected {all_expected_callnats}, found {found_callnats}"
    
    assert all_expected_fetches.issubset(found_fetches), \
        f"Traditional parsing should find all FETCHes: expected {all_expected_fetches}, found {found_fetches}"
    
    assert all_expected_includes.issubset(found_includes), \
        f"Traditional parsing should find all INCLUDEs: expected {all_expected_includes}, found {found_includes}"
    
    assert all_expected_usings.issubset(found_usings), \
        f"Traditional parsing should find all USINGs: expected {all_expected_usings}, found {found_usings}"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Natural)**
# **Validates: Requirements 1.3**
@settings(max_examples=100)
@given(
    natural_source=natural_multi_program_source
)
def test_property_natural_parsing_consistency(natural_source):
    """
    Property 1: Multi-program file parsing accuracy (Natural) - Consistency
    
    For any Natural source file, running parsing multiple times should produce 
    identical results.
    """
    parser = NaturalDependencyParser()
    detector = NaturalProgramBoundaryDetector()
    
    # Ensure source has some content
    lines = natural_source.splitlines()
    assume(len(lines) >= 1)
    assume(any(line.strip() for line in lines))
    
    # Run traditional parsing multiple times
    traditional_results = []
    for _ in range(3):
        result = parser.parse(natural_source)
        traditional_results.append(result)
    
    # Property: Traditional parsing should be consistent
    first_result = traditional_results[0]
    for i, result in enumerate(traditional_results[1:], start=1):
        for key in first_result:
            if isinstance(first_result[key], list):
                assert set(result.get(key, [])) == set(first_result.get(key, [])), \
                    f"Traditional parsing run {i} differs from run 0 for key '{key}'"
            else:
                assert result.get(key) == first_result.get(key), \
                    f"Traditional parsing run {i} differs from run 0 for key '{key}'"
    
    # Run boundary detection multiple times
    boundary_results = []
    for _ in range(3):
        programs = detector.detect_boundaries(natural_source)
        boundary_results.append(programs)
    
    # Property: Boundary detection should be consistent
    first_boundaries = boundary_results[0]
    for i, boundaries in enumerate(boundary_results[1:], start=1):
        assert len(boundaries) == len(first_boundaries), \
            f"Boundary detection run {i} found {len(boundaries)} programs, but run 0 found {len(first_boundaries)}"
        
        # Compare programs by name and boundaries
        first_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in first_boundaries}
        result_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in boundaries}
        
        assert first_dict == result_dict, \
            f"Boundary detection run {i} produced different results than run 0"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Natural)**
# **Validates: Requirements 1.3**
@settings(max_examples=100)
@given(
    file_path=st.text(
        alphabet='abcdefghijklmnopqrstuvwxyz0123456789_-.',
        min_size=5,
        max_size=50
    ).map(lambda x: f"/path/to/{x}.nsp")
)
def test_property_natural_file_path_handling(file_path):
    """
    Property 1: Multi-program file parsing accuracy (Natural) - File path handling
    
    For any Natural source file with a file path, program boundaries should include
    the correct file path information.
    """
    detector = NaturalProgramBoundaryDetector()
    
    # Create simple Natural source
    natural_source = """DEFINE DATA
LOCAL
1 #VAR (A10)
END-DEFINE
WRITE 'Hello World'
END"""
    
    # Detect boundaries with file path
    programs = detector.detect_boundaries(natural_source, file_path)
    
    # Property: All programs should have the correct file path
    for program in programs:
        assert program.file_path == file_path, \
            f"Program '{program.program_name}' should have file_path '{file_path}', got '{program.file_path}'"
    
    # Property: Parse result should include file path
    result = detector.parse_with_program_detection(natural_source, file_path)
    assert result.file_path == file_path, \
        f"Parse result should have file_path '{file_path}', got '{result.file_path}'"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (Natural)**
# **Validates: Requirements 1.3**
@settings(max_examples=100)
@given(
    extension=st.sampled_from(['.NSP', '.NSN', '.NSC', '.NSL', '.NSG', '.NSD', '.NSA', '.NS8'])
)
def test_property_natural_file_extension_classification(extension):
    """
    Property 1: Multi-program file parsing accuracy (Natural) - File extension classification
    
    For any Natural source file, the program type should be correctly classified
    based on the file extension and content.
    """
    detector = NaturalProgramBoundaryDetector()
    
    # Create Natural source appropriate for the extension
    if extension == '.NSN':
        # Subprogram
        natural_source = """DEFINE DATA PARAMETER
1 #INPUT (A10)
1 #OUTPUT (A20)
END-DEFINE
MOVE #INPUT TO #OUTPUT
END"""
    elif extension == '.NSG':
        # Global data area
        natural_source = """DEFINE DATA GLOBAL
1 #GLOBAL-VAR (A10)
END-DEFINE"""
    else:
        # Regular program
        natural_source = """DEFINE DATA
LOCAL
1 #VAR (A10)
END-DEFINE
WRITE 'Hello World'
END"""
    
    file_path = f"/path/to/testprog{extension}"
    
    # Detect boundaries
    programs = detector.detect_boundaries(natural_source, file_path)
    
    # Property: Should detect at least one program
    assert len(programs) >= 1, \
        f"Should detect at least one program for {extension} file"
    
    # Property: Program type should be appropriate for extension
    program = programs[0]
    if extension == '.NSN':
        assert program.program_type in [ProgramType.SUBPROGRAM, ProgramType.MAIN], \
            f"NSN file should be classified as SUBPROGRAM or MAIN, got {program.program_type}"
    elif extension == '.NSA' or extension == '.NS8':
        assert program.program_type in [ProgramType.FUNCTION, ProgramType.MAIN], \
            f"{extension} file should be classified as FUNCTION or MAIN, got {program.program_type}"
    else:
        assert program.program_type in [ProgramType.MAIN, ProgramType.SUBPROGRAM, ProgramType.FUNCTION], \
            f"{extension} file should have valid program type, got {program.program_type}"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])