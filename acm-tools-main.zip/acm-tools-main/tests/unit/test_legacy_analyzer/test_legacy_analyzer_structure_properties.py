"""Property-based tests for Legacy Analyzer tool directory structure.

Feature: project-reorganization
"""

import pytest
import os
from pathlib import Path
from hypothesis import given, strategies as st, settings


class TestLegacyAnalyzerStructureProperties:
    """Property-based tests for Legacy Analyzer tool structure."""
    
    def test_property_1_tool_directory_structure_correctness(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any reorganized toolkit, all expected legacy analyzer tool directories should exist 
        with correct contents in their new locations under tools/legacy_analyzer/.
        """
        # Define the expected structure for Legacy Analyzer tool
        expected_structure = {
            'tools/legacy_analyzer': {
                'type': 'directory',
                'required_files': ['__init__.py', '__main__.py', 'api.py', 'cli.py', 'requirements.txt', 'README.md'],
                'required_subdirs': ['analysis', 'parsers', 'inventory', 'models', 'utils', 'migration', 'visualization', 'reports', 'metadata', 'docs']
            },
            'tools/legacy_analyzer/analysis': {
                'type': 'directory',
                'required_files': ['__init__.py', 'flow_analyzer.py', 'complexity_analyzer.py', 'entry_point_detector.py'],
                'optional_files': ['call_graph.py', 'circular_detector.py', 'missing_code_detector.py']
            },
            'tools/legacy_analyzer/parsers': {
                'type': 'directory',
                'required_files': ['__init__.py', 'base_parser.py', 'parser_factory.py'],
                'optional_files': ['cobol_parser.py', 'jcl_parser.py', 'pli_parser.py', 'rexx_parser.py', 'natural_parser.py', 'rpg_parser.py', 'asm_parser.py']
            },
            'tools/legacy_analyzer/inventory': {
                'type': 'directory',
                'required_files': ['__init__.py', 'inventory_loader.py', 'base_loader.py'],
                'optional_files': ['csv_validator.py']
            },
            'tools/legacy_analyzer/models': {
                'type': 'directory',
                'required_files': ['__init__.py', 'dependency.py', 'complexity.py', 'artifact.py'],
                'optional_files': ['flow.py', 'package.py', 'cics.py']
            },
            'tools/legacy_analyzer/utils': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'optional_files': ['cache.py', 'config.py', 'parallel.py', 'database_utils.py']
            },
            'tools/legacy_analyzer/migration': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'optional_files': ['package_builder.py', 'package_optimizer.py', 'package_exporter.py']
            },
            'tools/legacy_analyzer/visualization': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'optional_files': ['graph_renderer.py', 'html_exporter.py', 'report_generator.py']
            },
            'tools/legacy_analyzer/reports': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'optional_files': ['cics_report.py']
            },
            'tools/legacy_analyzer/metadata': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'optional_files': ['scanner.py', 'reconciliation.py']
            },
            'tools/legacy_analyzer/docs': {
                'type': 'directory',
                'required_files': [],
                'optional_files': ['README.md', 'CICS_METADATA_GUIDE.md', 'INVENTORY_MANAGEMENT.md']
            }
        }
        
        # Verify each expected directory and its contents
        for path_str, expected in expected_structure.items():
            path = Path(path_str)
            
            # Directory should exist
            assert path.exists(), f"Directory {path_str} should exist"
            assert path.is_dir(), f"{path_str} should be a directory"
            
            # Check required files
            for required_file in expected['required_files']:
                file_path = path / required_file
                assert file_path.exists(), f"Required file {path_str}/{required_file} should exist"
                assert file_path.is_file(), f"{path_str}/{required_file} should be a file"
            
            # Check required subdirectories
            for required_subdir in expected.get('required_subdirs', []):
                subdir_path = path / required_subdir
                assert subdir_path.exists(), f"Required subdirectory {path_str}/{required_subdir} should exist"
                assert subdir_path.is_dir(), f"{path_str}/{required_subdir} should be a directory"
        
        # Verify that old location no longer exists (it should have been moved)
        old_location = Path('legacy_analyzer')
        assert not old_location.exists(), f"Old location 'legacy_analyzer' should no longer exist after move"
    
    def test_property_1_legacy_analyzer_main_files_structure(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any reorganized legacy analyzer tool, the main files should contain the expected
        structure and imports to provide a unified interface.
        """
        # Check main __init__.py file
        init_file = Path('tools/legacy_analyzer/__init__.py')
        assert init_file.exists(), "Legacy analyzer __init__.py should exist"
        
        with open(init_file, 'r') as f:
            init_content = f.read()
        
        # Verify it's a valid Python file (can be imported)
        assert 'import' in init_content or 'from' in init_content or len(init_content.strip()) == 0, "__init__.py should be a valid Python file"
        
        # Check __main__.py file
        main_file = Path('tools/legacy_analyzer/__main__.py')
        assert main_file.exists(), "Legacy analyzer __main__.py should exist"
        
        with open(main_file, 'r') as f:
            main_content = f.read()
        
        # Verify main entry point structure
        assert ('if __name__ == "__main__":' in main_content or "if __name__ == '__main__':" in main_content), "__main__.py should have main entry point"
        
        # Check API file
        api_file = Path('tools/legacy_analyzer/api.py')
        assert api_file.exists(), "Legacy analyzer api.py should exist"
        
        # Check CLI file
        cli_file = Path('tools/legacy_analyzer/cli.py')
        assert cli_file.exists(), "Legacy analyzer cli.py should exist"
    
    def test_property_1_legacy_analyzer_requirements_structure(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any reorganized legacy analyzer tool, the requirements.txt file should contain
        the appropriate dependencies for legacy code analysis functionality.
        """
        requirements_file = Path('tools/legacy_analyzer/requirements.txt')
        assert requirements_file.exists(), "Legacy analyzer requirements.txt should exist"
        
        with open(requirements_file, 'r') as f:
            requirements_content = f.read()
        
        # Verify key dependencies are present
        expected_dependencies = [
            'PyYAML>=6.0',
            'pytest>=7.4.0',
            'hypothesis>=6.0.0'
        ]
        
        for expected_dep in expected_dependencies:
            assert expected_dep in requirements_content, f"Expected dependency '{expected_dep}' should be in requirements.txt"
        
        # Verify it contains tool-specific header
        assert 'Legacy Analyzer Tool Requirements' in requirements_content, "Requirements should have tool-specific header"
    
    def test_property_1_legacy_analyzer_readme_structure(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any reorganized legacy analyzer tool, the README.md file should contain
        comprehensive documentation for the tool.
        """
        readme_file = Path('tools/legacy_analyzer/README.md')
        assert readme_file.exists(), "Legacy analyzer README.md should exist"
        
        with open(readme_file, 'r') as f:
            readme_content = f.read()
        
        # Verify key sections are present
        expected_sections = [
            '# Legacy Analyzer Tool',
            '## Tool Overview',
            '## Quick Start'
        ]
        
        for expected_section in expected_sections:
            assert expected_section in readme_content, f"Expected section '{expected_section}' should be in README.md"
        
        # Verify tool description mentions key capabilities
        expected_capabilities = [
            'static code analysis',
            'dependency tracking',
            'migration planning'
        ]
        
        for expected_capability in expected_capabilities:
            assert expected_capability in readme_content.lower(), f"Capability '{expected_capability}' should be mentioned in README.md"
    
    @settings(max_examples=10)
    @given(
        component_name=st.sampled_from(['analysis', 'parsers', 'inventory', 'models', 'utils', 'migration', 'visualization', 'reports', 'metadata', 'docs'])
    )
    def test_property_1_component_preservation(self, component_name):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any legacy analyzer component that was moved to tools/legacy_analyzer/, all original files
        and subdirectories should be preserved in the new location.
        """
        component_path = Path(f'tools/legacy_analyzer/{component_name}')
        assert component_path.exists(), f"Component {component_name} should exist in new location"
        assert component_path.is_dir(), f"Component {component_name} should be a directory"
        
        # Verify the component has some content (not empty) or is allowed to be empty for docs
        contents = list(component_path.iterdir())
        if component_name != 'docs':  # docs directory can be empty initially
            assert len(contents) > 0, f"Component {component_name} should not be empty"
        
        # Check for __init__.py in Python package directories
        if component_name in ['analysis', 'parsers', 'inventory', 'models', 'utils', 'migration', 'visualization', 'reports', 'metadata']:
            init_file = component_path / '__init__.py'
            assert init_file.exists(), f"{component_name} should have __init__.py"
    
    def test_property_1_core_functionality_files_exist(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any reorganized legacy analyzer tool, core functionality files should exist
        to ensure the tool can perform its primary functions.
        """
        # Core files that should exist for basic functionality
        core_files = [
            'tools/legacy_analyzer/analysis_orchestrator.py',
            'tools/legacy_analyzer/dependency_analyzer.py',
            'tools/legacy_analyzer/inventory_manager.py',
            'tools/legacy_analyzer/language_detector.py',
            'tools/legacy_analyzer/report_generator.py',
            'tools/legacy_analyzer/constants.py',
            'tools/legacy_analyzer/exceptions.py',
            'tools/legacy_analyzer/validation.py'
        ]
        
        for core_file in core_files:
            file_path = Path(core_file)
            assert file_path.exists(), f"Core file {core_file} should exist"
            assert file_path.is_file(), f"{core_file} should be a file"
            
            # Verify it's a non-empty Python file
            with open(file_path, 'r') as f:
                content = f.read()
            assert len(content.strip()) > 0, f"{core_file} should not be empty"
            assert content.strip().startswith('"""') or content.strip().startswith('#') or 'import' in content or 'from' in content or 'class' in content or 'def' in content, f"{core_file} should be a valid Python file"
    
    @settings(max_examples=5)
    @given(
        parser_name=st.sampled_from(['cobol_parser.py', 'jcl_parser.py', 'pli_parser.py', 'rexx_parser.py', 'natural_parser.py', 'rpg_parser.py', 'asm_parser.py'])
    )
    def test_property_1_language_parsers_preservation(self, parser_name):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any language parser that was moved to tools/legacy_analyzer/parsers/, the parser
        should be preserved and functional in the new location.
        """
        parser_path = Path(f'tools/legacy_analyzer/parsers/{parser_name}')
        
        # Parser file should exist
        assert parser_path.exists(), f"Parser {parser_name} should exist in new location"
        assert parser_path.is_file(), f"Parser {parser_name} should be a file"
        
        # Verify it's a non-empty Python file
        with open(parser_path, 'r') as f:
            content = f.read()
        assert len(content.strip()) > 0, f"Parser {parser_name} should not be empty"
        
        # Verify it contains parser-like content
        parser_indicators = ['class', 'def parse', 'def get_supported_patterns', 'BaseDependencyParser']
        has_parser_content = any(indicator in content for indicator in parser_indicators)
        assert has_parser_content, f"Parser {parser_name} should contain parser-related code"
    
    def test_property_1_tool_isolation(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 2.1, 2.2**
        
        For any reorganized legacy analyzer tool, it should be properly isolated within
        the tools directory structure and not interfere with other tools.
        """
        # Legacy analyzer should be in tools directory
        legacy_analyzer_path = Path('tools/legacy_analyzer')
        assert legacy_analyzer_path.exists(), "Legacy analyzer should be in tools directory"
        
        # Should not exist in root anymore
        root_legacy_path = Path('legacy_analyzer')
        assert not root_legacy_path.exists(), "Legacy analyzer should not exist in root after move"
        
        # Should be separate from other tools
        tools_dir = Path('tools')
        assert tools_dir.exists(), "Tools directory should exist"
        
        # Check that it's one of the expected tools
        expected_tools = ['smf_analyzer', 'legacy_analyzer', 'migration_planner']
        actual_tools = [item.name for item in tools_dir.iterdir() if item.is_dir()]
        
        assert 'legacy_analyzer' in actual_tools, "legacy_analyzer should be in tools directory"
        
        # Verify no unexpected mixing of tool contents
        for tool_name in actual_tools:
            if tool_name != 'legacy_analyzer':
                tool_path = tools_dir / tool_name
                # Other tools should not contain legacy analyzer specific files
                legacy_specific_files = ['analysis_orchestrator.py', 'dependency_analyzer.py', 'inventory_manager.py']
                for legacy_file in legacy_specific_files:
                    legacy_file_path = tool_path / legacy_file
                    assert not legacy_file_path.exists(), f"Tool {tool_name} should not contain legacy analyzer file {legacy_file}"