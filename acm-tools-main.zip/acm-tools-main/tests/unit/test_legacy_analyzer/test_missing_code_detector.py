"""Unit tests for missing code detector."""

import unittest
import sqlite3
from datetime import datetime
from tools.legacy_analyzer.models.dependency import Dependency, DependencyType
from tools.legacy_analyzer.models.missing_artifact import (
    MissingArtifact,
    MissingArtifactReference,
    CompletenessReport,
    SeverityThreshold
)
from tools.legacy_analyzer.analysis.missing_code_detector import MissingCodeDetector
from tools.legacy_analyzer.analysis.missing_code_database import MissingCodeDatabase


class TestMissingCodeDetector(unittest.TestCase):
    """Test cases for MissingCodeDetector."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create in-memory database
        self.conn = sqlite3.connect(':memory:')
        self.cursor = self.conn.cursor()
        
        # Create inventory tables
        self.cursor.execute("""
            CREATE TABLE programs (
                program_name VARCHAR(8) PRIMARY KEY
            )
        """)
        
        self.cursor.execute("""
            CREATE TABLE copybooks (
                copybook_name VARCHAR(8) PRIMARY KEY
            )
        """)
        
        self.cursor.execute("""
            CREATE TABLE datasets (
                dataset_name VARCHAR(44) PRIMARY KEY
            )
        """)
        
        # Add some inventory data
        self.cursor.execute("INSERT INTO programs VALUES ('PROG001')")
        self.cursor.execute("INSERT INTO programs VALUES ('PROG002')")
        self.cursor.execute("INSERT INTO copybooks VALUES ('COPY001')")
        self.cursor.execute("INSERT INTO datasets VALUES ('DATASET1')")
        
        self.conn.commit()
        
        # Create test dependencies with incomplete inventory
        self.dependencies = [
            # Program calls - PROG003 is missing
            Dependency(
                source_artifact='PROG001',
                source_type='PROGRAM',
                target_artifact='PROG002',
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL
            ),
            Dependency(
                source_artifact='PROG001',
                source_type='PROGRAM',
                target_artifact='PROG003',
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL
            ),
            Dependency(
                source_artifact='PROG002',
                source_type='PROGRAM',
                target_artifact='PROG003',
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL
            ),
            # Copybook includes - COPY002 is missing
            Dependency(
                source_artifact='PROG001',
                source_type='PROGRAM',
                target_artifact='COPY001',
                target_type='COPYBOOK',
                dependency_type=DependencyType.COPY
            ),
            Dependency(
                source_artifact='PROG001',
                source_type='PROGRAM',
                target_artifact='COPY002',
                target_type='COPYBOOK',
                dependency_type=DependencyType.COPY
            ),
            # Dataset references - DATASET2 is missing
            Dependency(
                source_artifact='PROG001',
                source_type='PROGRAM',
                target_artifact='DATASET1',
                target_type='DATASET',
                dependency_type=DependencyType.DATASET_REF
            ),
            Dependency(
                source_artifact='PROG001',
                source_type='PROGRAM',
                target_artifact='DATASET2',
                target_type='DATASET',
                dependency_type=DependencyType.DATASET_REF
            ),
        ]
        
        self.detector = MissingCodeDetector(self.dependencies, self.conn)
    
    def tearDown(self):
        """Clean up test fixtures."""
        self.conn.close()
    
    def test_detect_missing_programs(self):
        """Test detection of missing programs."""
        missing = self.detector.detect_missing_programs()
        
        # Should find PROG003 as missing
        self.assertEqual(len(missing), 1)
        self.assertEqual(missing[0].artifact_name, 'PROG003')
        self.assertEqual(missing[0].artifact_type, 'PROGRAM')
        self.assertEqual(missing[0].reference_count, 2)
        self.assertIn('PROG001', missing[0].referenced_by)
        self.assertIn('PROG002', missing[0].referenced_by)
    
    def test_detect_missing_copybooks(self):
        """Test detection of missing copybooks."""
        missing = self.detector.detect_missing_copybooks()
        
        # Should find COPY002 as missing
        self.assertEqual(len(missing), 1)
        self.assertEqual(missing[0].artifact_name, 'COPY002')
        self.assertEqual(missing[0].artifact_type, 'COPYBOOK')
        self.assertEqual(missing[0].reference_count, 1)
        self.assertIn('PROG001', missing[0].referenced_by)
    
    def test_detect_missing_datasets(self):
        """Test detection of missing datasets."""
        missing = self.detector.detect_missing_datasets()
        
        # Should find DATASET2 as missing
        self.assertEqual(len(missing), 1)
        self.assertEqual(missing[0].artifact_name, 'DATASET2')
        self.assertEqual(missing[0].artifact_type, 'DATASET')
        self.assertEqual(missing[0].reference_count, 1)
        self.assertIn('PROG001', missing[0].referenced_by)
    
    def test_detect_all_missing(self):
        """Test detection of all missing artifacts."""
        missing = self.detector.detect_all_missing()
        
        # Should find 3 missing artifacts total
        self.assertEqual(len(missing), 3)
        
        # Check artifact types
        types = {m.artifact_type for m in missing}
        self.assertEqual(types, {'PROGRAM', 'COPYBOOK', 'DATASET'})
    
    def test_severity_classification(self):
        """Test severity classification based on reference count."""
        # Create dependencies with varying reference counts
        deps = []
        
        # HIGH severity - 10+ references
        for i in range(12):
            deps.append(Dependency(
                source_artifact=f'PROG{i:03d}',
                source_type='PROGRAM',
                target_artifact='MISSING_HIGH',
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL
            ))
        
        # MEDIUM severity - 3-9 references
        for i in range(5):
            deps.append(Dependency(
                source_artifact=f'PROG{i:03d}',
                source_type='PROGRAM',
                target_artifact='MISSING_MED',
                target_type='PROGRAM',
                dependency_type=DependencyType.CALL
            ))
        
        # LOW severity - 1-2 references
        deps.append(Dependency(
            source_artifact='PROG001',
            source_type='PROGRAM',
            target_artifact='MISSING_LOW',
            target_type='PROGRAM',
            dependency_type=DependencyType.CALL
        ))
        
        detector = MissingCodeDetector(deps, self.conn)
        missing = detector.detect_missing_programs()
        
        # Check severities
        severity_map = {m.artifact_name: m.severity for m in missing}
        self.assertEqual(severity_map['MISSING_HIGH'], 'HIGH')
        self.assertEqual(severity_map['MISSING_MED'], 'MEDIUM')
        self.assertEqual(severity_map['MISSING_LOW'], 'LOW')
    
    def test_completeness_score(self):
        """Test completeness score calculation."""
        report = self.detector.calculate_completeness_score()
        
        # Check program completeness
        # Referenced: PROG002, PROG003 (2 total)
        # Found: PROG002 (1 found)
        # Missing: PROG003 (1 missing)
        self.assertEqual(report.total_referenced_programs, 2)
        self.assertEqual(report.found_programs, 1)
        self.assertEqual(report.missing_programs, 1)
        self.assertEqual(report.program_completeness, 0.5)
        
        # Check copybook completeness
        # Referenced: COPY001, COPY002 (2 total)
        # Found: COPY001 (1 found)
        # Missing: COPY002 (1 missing)
        self.assertEqual(report.total_referenced_copybooks, 2)
        self.assertEqual(report.found_copybooks, 1)
        self.assertEqual(report.missing_copybooks, 1)
        self.assertEqual(report.copybook_completeness, 0.5)
        
        # Check dataset completeness
        # Referenced: DATASET1, DATASET2 (2 total)
        # Found: DATASET1 (1 found)
        # Missing: DATASET2 (1 missing)
        self.assertEqual(report.total_referenced_datasets, 2)
        self.assertEqual(report.found_datasets, 1)
        self.assertEqual(report.missing_datasets, 1)
        self.assertEqual(report.dataset_completeness, 0.5)
        
        # Check overall completeness
        # Total: 6 referenced, 3 found, 3 missing
        self.assertEqual(report.overall_completeness, 0.5)
        
        # Check missing artifacts list
        self.assertEqual(len(report.missing_artifacts), 3)
    
    def test_completeness_with_complete_inventory(self):
        """Test completeness score with complete inventory."""
        # Add missing artifacts to inventory
        self.cursor.execute("INSERT INTO programs VALUES ('PROG003')")
        self.cursor.execute("INSERT INTO copybooks VALUES ('COPY002')")
        self.cursor.execute("INSERT INTO datasets VALUES ('DATASET2')")
        self.conn.commit()
        
        # Re-create detector to reload inventory
        detector = MissingCodeDetector(self.dependencies, self.conn)
        report = detector.calculate_completeness_score()
        
        # Should be 100% complete
        self.assertEqual(report.overall_completeness, 1.0)
        self.assertEqual(report.program_completeness, 1.0)
        self.assertEqual(report.copybook_completeness, 1.0)
        self.assertEqual(report.dataset_completeness, 1.0)
        self.assertEqual(len(report.missing_artifacts), 0)
    
    def test_get_missing_artifact_references(self):
        """Test getting references to a specific missing artifact."""
        references = self.detector.get_missing_artifact_references('PROG003', 'PROGRAM')
        
        # Should have 2 references
        self.assertEqual(len(references), 2)
        
        # Check reference details
        ref_sources = {ref.referenced_by for ref in references}
        self.assertEqual(ref_sources, {'PROG001', 'PROG002'})
        
        for ref in references:
            self.assertEqual(ref.missing_artifact, 'PROG003')
            self.assertEqual(ref.missing_artifact_type, 'PROGRAM')
            self.assertEqual(ref.reference_type, DependencyType.CALL)
    
    def test_empty_dependencies(self):
        """Test detector with no dependencies."""
        detector = MissingCodeDetector([], self.conn)
        
        missing = detector.detect_all_missing()
        self.assertEqual(len(missing), 0)
        
        report = detector.calculate_completeness_score()
        self.assertEqual(report.overall_completeness, 1.0)
    
    def test_no_database_connection(self):
        """Test detector without database connection."""
        detector = MissingCodeDetector(self.dependencies, None)
        
        # Should still work but treat all as missing
        missing = detector.detect_missing_programs()
        
        # All referenced programs are missing without inventory
        self.assertEqual(len(missing), 2)  # PROG002 and PROG003


class TestMissingCodeDatabase(unittest.TestCase):
    """Test cases for MissingCodeDatabase."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.conn = sqlite3.connect(':memory:')
        self.db = MissingCodeDatabase(self.conn)
        self.db.create_schema()
    
    def tearDown(self):
        """Clean up test fixtures."""
        self.conn.close()
    
    def test_create_schema(self):
        """Test database schema creation."""
        # Check that tables exist
        cursor = self.conn.cursor()
        
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='missing_artifacts'
        """)
        self.assertIsNotNone(cursor.fetchone())
        
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='missing_artifact_references'
        """)
        self.assertIsNotNone(cursor.fetchone())
        
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='completeness_reports'
        """)
        self.assertIsNotNone(cursor.fetchone())
    
    def test_save_and_load_missing_artifact(self):
        """Test saving and loading missing artifacts."""
        artifact = MissingArtifact(
            artifact_name='PROG001',
            artifact_type='PROGRAM',
            reference_count=5,
            referenced_by=['PROG002', 'PROG003'],
            severity='MEDIUM',
            first_detected=datetime.now()
        )
        
        # Save artifact
        artifact_id = self.db.save_missing_artifact(artifact)
        self.assertIsNotNone(artifact_id)
        
        # Load artifact
        loaded = self.db.load_missing_artifact('PROG001', 'PROGRAM')
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded.artifact_name, 'PROG001')
        self.assertEqual(loaded.artifact_type, 'PROGRAM')
        self.assertEqual(loaded.reference_count, 5)
        self.assertEqual(loaded.severity, 'MEDIUM')
    
    def test_save_duplicate_artifact(self):
        """Test saving duplicate artifact updates existing record."""
        artifact1 = MissingArtifact(
            artifact_name='PROG001',
            artifact_type='PROGRAM',
            reference_count=5,
            severity='MEDIUM'
        )
        
        artifact2 = MissingArtifact(
            artifact_name='PROG001',
            artifact_type='PROGRAM',
            reference_count=10,
            severity='HIGH'
        )
        
        # Save first artifact
        id1 = self.db.save_missing_artifact(artifact1)
        
        # Save duplicate - should update
        id2 = self.db.save_missing_artifact(artifact2)
        
        # Should have same ID
        self.assertEqual(id1, id2)
        
        # Load and check updated values
        loaded = self.db.load_missing_artifact('PROG001', 'PROGRAM')
        self.assertEqual(loaded.reference_count, 10)
        self.assertEqual(loaded.severity, 'HIGH')
    
    def test_load_all_missing_artifacts(self):
        """Test loading all missing artifacts."""
        # Save multiple artifacts
        artifacts = [
            MissingArtifact('PROG001', 'PROGRAM', 10, severity='HIGH'),
            MissingArtifact('PROG002', 'PROGRAM', 5, severity='MEDIUM'),
            MissingArtifact('COPY001', 'COPYBOOK', 2, severity='LOW'),
        ]
        
        for artifact in artifacts:
            self.db.save_missing_artifact(artifact)
        
        # Load all
        loaded = self.db.load_all_missing_artifacts()
        self.assertEqual(len(loaded), 3)
        
        # Should be sorted by severity and reference count
        self.assertEqual(loaded[0].severity, 'HIGH')
        self.assertEqual(loaded[1].severity, 'MEDIUM')
        self.assertEqual(loaded[2].severity, 'LOW')
    
    def test_load_missing_artifacts_by_type(self):
        """Test loading missing artifacts filtered by type."""
        # Save artifacts of different types
        self.db.save_missing_artifact(MissingArtifact('PROG001', 'PROGRAM', 5, severity='MEDIUM'))
        self.db.save_missing_artifact(MissingArtifact('COPY001', 'COPYBOOK', 3, severity='MEDIUM'))
        
        # Load only programs
        programs = self.db.load_all_missing_artifacts('PROGRAM')
        self.assertEqual(len(programs), 1)
        self.assertEqual(programs[0].artifact_type, 'PROGRAM')
        
        # Load only copybooks
        copybooks = self.db.load_all_missing_artifacts('COPYBOOK')
        self.assertEqual(len(copybooks), 1)
        self.assertEqual(copybooks[0].artifact_type, 'COPYBOOK')
    
    def test_save_and_load_completeness_report(self):
        """Test saving and loading completeness reports."""
        report = CompletenessReport(
            total_referenced_programs=10,
            found_programs=8,
            missing_programs=2,
            program_completeness=0.8,
            total_referenced_copybooks=5,
            found_copybooks=4,
            missing_copybooks=1,
            copybook_completeness=0.8,
            total_referenced_datasets=3,
            found_datasets=3,
            missing_datasets=0,
            dataset_completeness=1.0,
            overall_completeness=0.85
        )
        
        # Save report
        report_id = self.db.save_completeness_report(report)
        self.assertIsNotNone(report_id)
        
        # Load latest report
        loaded = self.db.load_latest_completeness_report()
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded.overall_completeness, 0.85)
        self.assertEqual(loaded.program_completeness, 0.8)
    
    def test_delete_missing_artifact(self):
        """Test deleting missing artifacts."""
        artifact = MissingArtifact('PROG001', 'PROGRAM', 5, severity='MEDIUM')
        self.db.save_missing_artifact(artifact)
        
        # Delete artifact
        deleted = self.db.delete_missing_artifact('PROG001', 'PROGRAM')
        self.assertTrue(deleted)
        
        # Should not be found
        loaded = self.db.load_missing_artifact('PROG001', 'PROGRAM')
        self.assertIsNone(loaded)
    
    def test_get_statistics(self):
        """Test getting missing artifact statistics."""
        # Save artifacts with different severities
        self.db.save_missing_artifact(MissingArtifact('PROG001', 'PROGRAM', 15, severity='HIGH'))
        self.db.save_missing_artifact(MissingArtifact('PROG002', 'PROGRAM', 5, severity='MEDIUM'))
        self.db.save_missing_artifact(MissingArtifact('COPY001', 'COPYBOOK', 2, severity='LOW'))
        
        stats = self.db.get_missing_artifact_statistics()
        
        self.assertEqual(stats['total_missing'], 3)
        self.assertEqual(stats['missing_programs'], 2)
        self.assertEqual(stats['missing_copybooks'], 1)
        self.assertEqual(stats['high_severity'], 1)
        self.assertEqual(stats['medium_severity'], 1)
        self.assertEqual(stats['low_severity'], 1)
        self.assertEqual(stats['total_references'], 22)


class TestSeverityThreshold(unittest.TestCase):
    """Test cases for SeverityThreshold."""
    
    def test_classify_high(self):
        """Test HIGH severity classification."""
        self.assertEqual(SeverityThreshold.classify(10), 'HIGH')
        self.assertEqual(SeverityThreshold.classify(15), 'HIGH')
        self.assertEqual(SeverityThreshold.classify(100), 'HIGH')
    
    def test_classify_medium(self):
        """Test MEDIUM severity classification."""
        self.assertEqual(SeverityThreshold.classify(3), 'MEDIUM')
        self.assertEqual(SeverityThreshold.classify(5), 'MEDIUM')
        self.assertEqual(SeverityThreshold.classify(9), 'MEDIUM')
    
    def test_classify_low(self):
        """Test LOW severity classification."""
        self.assertEqual(SeverityThreshold.classify(1), 'LOW')
        self.assertEqual(SeverityThreshold.classify(2), 'LOW')


if __name__ == '__main__':
    unittest.main()
