"""Tests for REXX dependency parser."""

import pytest
import os
from tools.legacy_analyzer.parsers.rexx_parser import REXXDependencyParser


class TestREXXParser:
    """Test suite for REXX dependency parser."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = REXXDependencyParser()
    
    def test_parse_call_statements(self):
        """Test parsing CALL statements."""
        source = """
        CALL BINTDECR
        CALL 'DATECNV'
        CALL PACTDECR(SMF30DTE)
        """
        
        result = self.parser.parse(source)
        
        assert 'BINTDECR' in result['calls']
        assert 'DATECNV' in result['calls']
        assert 'PACTDECR' in result['calls']
        assert len(result['calls']) == 3
    
    def test_parse_function_style_calls(self):
        """Test parsing function-style calls (assignment with function)."""
        source = """
        SMF30RTY = BINTDECR(SMF30RTY)
        SMF30TME = DATECNV(SMF30TME)
        PACKED = PACTDECR(SMF30DTE)
        """
        
        result = self.parser.parse(source)
        
        assert 'BINTDECR' in result['calls']
        assert 'DATECNV' in result['calls']
        assert 'PACTDECR' in result['calls']
    
    def test_parse_procedure_definitions(self):
        """Test parsing procedure definitions."""
        source = """
DATECNV:
ARG HSTIME
NUMERIC DIGITS 20
RETURN HH || ':' || MM || ':' || SS

FIX_TIME: PROCEDURE
RETURN SMF30SIT SMF30TME

TOTSEC:
ARG TIMEVAL
PARSE VAR TIMEVAL HH ':' MM ':' SS
RETURN (HH * 3600) + (MM * 60) + SS
        """
        
        result = self.parser.parse(source)
        
        assert 'DATECNV' in result['procedures']
        assert 'FIX_TIME' in result['procedures']
        assert 'TOTSEC' in result['procedures']
    
    def test_parse_execio_statements(self):
        """Test parsing EXECIO statements for dataset references."""
        source = """
        "EXECIO 0 DISKR INPUT (OPEN"
        "EXECIO 1 DISKR INPUT"
        "EXECIO 1 DISKW OUTPUT"
        "EXECIO * DISKR MYDATA"
        """
        
        result = self.parser.parse(source)
        
        assert 'INPUT' in result['datasets']
        assert 'OUTPUT' in result['datasets']
        assert 'MYDATA' in result['datasets']
    
    def test_parse_address_commands(self):
        """Test parsing ADDRESS commands."""
        source = """
        ADDRESS TSO
        ADDRESS ISPEXEC
        ADDRESS ISREDIT
        ADDRESS LINKMVS
        """
        
        result = self.parser.parse(source)
        
        assert 'TSO' in result['address_environments']
        assert 'ISPEXEC' in result['address_environments']
        assert 'ISREDIT' in result['address_environments']
        assert 'LINKMVS' in result['address_environments']
    
    def test_parse_address_link_commands(self):
        """Test parsing ADDRESS LINKMVS/LINKPGM commands."""
        source = """
        ADDRESS LINKMVS 'PROGNAME'
        ADDRESS LINKPGM 'TESTPROG'
        """
        
        result = self.parser.parse(source)
        
        assert 'PROGNAME' in result['address_links']
        assert 'TESTPROG' in result['address_links']
    
    def test_parse_include_directives(self):
        """Test parsing /* INCLUDE filename */ directives."""
        source = """
        /* INCLUDE IO.rex */
        /* INCLUDE HELPER */
        /* INCLUDE file2 */
        """
        
        result = self.parser.parse(source)
        
        assert 'IO.rex' in result['includes']
        assert 'HELPER' in result['includes']
        assert 'file2' in result['includes']
    
    def test_parse_tso_commands(self):
        """Test parsing TSO commands."""
        source = """
        ADDRESS TSO 'ALLOCATE DATASET(MY.FILE) NEW'
        'LISTDSI MY.DATASET'
        'LISTCAT ENTRIES(MY.CATALOG)'
        """
        
        result = self.parser.parse(source)
        
        assert 'ALLOCATE' in result['tso_commands']
        assert 'LISTDSI' in result['tso_commands']
        assert 'LISTCAT' in result['tso_commands']
    
    def test_parse_ispexec_commands(self):
        """Test parsing ISPEXEC commands."""
        source = """
        'LMINIT DATAID(hFile) DATASET(&sFile)'
        'LMOPEN DATAID(&hFile) OPTION(INPUT)'
        'LMCLOSE DATAID(&hFile)'
        'LMFREE DATAID(&hFile)'
        'EDIT DATASET(MY.FILE)'
        """
        
        result = self.parser.parse(source)
        
        assert 'LMINIT' in result['ispexec_commands']
        assert 'LMOPEN' in result['ispexec_commands']
        assert 'LMCLOSE' in result['ispexec_commands']
        assert 'LMFREE' in result['ispexec_commands']
        assert 'EDIT' in result['ispexec_commands']
    
    def test_exclude_builtin_functions(self):
        """Test that built-in REXX functions are excluded."""
        source = """
        result = SUBSTR(string, 1, 10)
        value = C2D(hex_value)
        text = LEFT(data, 20)
        """
        
        result = self.parser.parse(source)
        
        # Built-in functions should not appear in calls or function_calls
        assert 'SUBSTR' not in result['calls']
        assert 'C2D' not in result['calls']
        assert 'LEFT' not in result['calls']
        assert 'SUBSTR' not in result['function_calls']
        assert 'C2D' not in result['function_calls']
        assert 'LEFT' not in result['function_calls']
    
    def test_exclude_rexx_keywords(self):
        """Test that REXX keywords are excluded from function calls."""
        source = """
        IF condition THEN DO
          PARSE VAR data field1 field2
          RETURN result
        END
        """
        
        result = self.parser.parse(source)
        
        # Keywords should not appear in function_calls
        assert 'IF' not in result['function_calls']
        assert 'THEN' not in result['function_calls']
        assert 'DO' not in result['function_calls']
        assert 'PARSE' not in result['function_calls']
        assert 'RETURN' not in result['function_calls']
    
    def test_exclude_internal_procedures(self):
        """Test that internal procedures are excluded from function calls."""
        source = """
HELPER: PROCEDURE
  ARG param
  RETURN result

MAIN:
  result = HELPER(data)
  RETURN
        """
        
        result = self.parser.parse(source)
        
        # HELPER is defined internally, so should not be in function_calls
        assert 'HELPER' in result['procedures']
        assert 'HELPER' not in result['function_calls']
    
    def test_comment_removal(self):
        """Test that comments are properly removed."""
        source = """
        /* This is a comment */
        CALL PROGNAME  /* inline comment */
        /* Multi-line
           comment
           here */
        CALL ANOTHER
        """
        
        result = self.parser.parse(source)
        
        assert 'PROGNAME' in result['calls']
        assert 'ANOTHER' in result['calls']
    
    def test_line_continuation(self):
        """Test handling of line continuations."""
        source = """
        CALL PROGNAME,
             ARG1,
             ARG2
        """
        
        result = self.parser.parse(source)
        
        assert 'PROGNAME' in result['calls']
    
    def test_get_supported_patterns(self):
        """Test getting supported patterns."""
        patterns = self.parser.get_supported_patterns()
        
        assert 'CALL' in patterns
        assert 'PROCEDURE' in patterns
        assert 'EXECIO' in patterns
        assert 'ADDRESS' in patterns
        assert '/* INCLUDE */' in patterns
    
    def test_get_supported_extensions(self):
        """Test getting supported extensions."""
        extensions = self.parser.get_supported_extensions()
        
        assert '.rexx' in extensions
        assert '.rex' in extensions
        assert '.txt' in extensions
    
    def test_parse_real_file_rexsmf30(self):
        """Test parsing real REXX file REXSMF30.txt."""
        file_path = 'examples/code/rexx/cbtapes_file_617/REXSMF30.txt'
        
        if not os.path.exists(file_path):
            pytest.skip(f"Test file not found: {file_path}")
        
        result = self.parser.parse_file(file_path)
        
        # Should detect EXECIO dataset references
        assert 'INPUT' in result['datasets']
        assert 'OUTPUT' in result['datasets']
        
        # Should detect function calls to helper routines
        assert 'BINTDECR' in result['calls'] or 'BINTDECR' in result['function_calls']
        assert 'DATECNV' in result['calls'] or 'DATECNV' in result['function_calls']
        assert 'PACTDECR' in result['calls'] or 'PACTDECR' in result['function_calls']
        
        # Should detect procedure definitions
        assert 'FIX_TIME' in result['procedures']
        assert 'TOTSEC' in result['procedures']
    
    def test_parse_real_file_datecnv(self):
        """Test parsing real REXX file DATECNV.txt."""
        file_path = 'examples/code/rexx/cbtapes_file_617/DATECNV.txt'
        
        if not os.path.exists(file_path):
            pytest.skip(f"Test file not found: {file_path}")
        
        result = self.parser.parse_file(file_path)
        
        # Should detect procedure definition
        assert 'DATECNV' in result['procedures']
    
    def test_parse_real_file_rexxpp(self):
        """Test parsing real REXX file REXXPP.rexx."""
        file_path = 'examples/code/rexx/cbtapes_file_647/REXXPP.rexx'
        
        if not os.path.exists(file_path):
            pytest.skip(f"Test file not found: {file_path}")
        
        result = self.parser.parse_file(file_path)
        
        # Should detect ADDRESS commands
        assert 'TSO' in result['address_environments']
        assert 'ISPEXEC' in result['address_environments']
        
        # Should detect INCLUDE directives
        assert len(result['includes']) > 0
        
        # Should detect ISPEXEC commands
        assert 'LMINIT' in result['ispexec_commands']
        assert 'LMOPEN' in result['ispexec_commands']
        
        # Should detect procedure definitions
        assert 'openFile' in result['procedures']
        assert 'closeFile' in result['procedures']
        assert 'getLine' in result['procedures']
        assert 'putLine' in result['procedures']
    
    def test_empty_source(self):
        """Test parsing empty source code."""
        result = self.parser.parse("")
        
        assert result['calls'] == []
        assert result['procedures'] == []
        assert result['datasets'] == []
    
    def test_complex_call_patterns(self):
        """Test various complex CALL patterns."""
        source = """
        CALL PROG1
        CALL 'PROG2'
        CALL "PROG3"
        CALL PROG4 ARG1, ARG2
        CALL 'PROG5' ARG1 ARG2
        """
        
        result = self.parser.parse(source)
        
        assert 'PROG1' in result['calls']
        assert 'PROG2' in result['calls']
        assert 'PROG3' in result['calls']
        assert 'PROG4' in result['calls']
        assert 'PROG5' in result['calls']
