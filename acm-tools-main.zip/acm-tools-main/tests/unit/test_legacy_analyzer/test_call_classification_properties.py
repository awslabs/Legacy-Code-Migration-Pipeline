"""
Property-based tests for correct call classification in migration flow builder.

Property 5: Correct Call Classification
For any call between two programs, the system SHALL correctly classify it as:
- internal (same flow)
- cross-flow (different flows in codebase)
- external (caller not in codebase)

Only external calls SHALL create inbound interfaces.

**Validates: Requirements 3.3**
"""

import pytest
import sqlite3
from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder
from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager


class MockFlow:
    """Mock ProgramFlow object for testing."""
    
    def __init__(self, programs):
        self.programs = programs
        self.dependencies = []


def create_test_db():
    """Create an in-memory test database with required schema."""
    conn = sqlite3.connect(':memory:')
    
    # Create migration flow schema
    from tools.legacy_analyzer.migration.schema import MigrationFlowSchema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create artifact_dependencies table
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            id INTEGER PRIMARY KEY,
            source_artifact_name TEXT,
            target_artifact_name TEXT,
            dependency_type TEXT,
            source_artifact_type TEXT,
            target_artifact_type TEXT,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    # Create interface tables
    schema_manager = InterfaceSchemaManager(conn)
    schema_manager.create_tables()
    
    conn.commit()
    return conn


@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    ),
    codebase_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=0,
        max_size=5,
        unique=True
    ),
    external_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=0,
        max_size=5,
        unique=True
    )
)
def test_property_correct_call_classification(flow_programs, codebase_programs, external_programs):
    """
    Property: For any call between two programs, the system correctly classifies it.
    
    Classification rules:
    1. Internal call (same flow): No inbound interface
    2. Cross-flow call (different flows in codebase): No inbound interface
    3. External call (caller not in codebase): Inbound interface IF configured
    
    **Feature: fix-inbound-interface-logic, Property 5: Correct Call Classification**
    **Validates: Requirements 3.3**
    """
    # Ensure no overlap between sets
    assume(len(set(flow_programs) & set(codebase_programs)) == 0)
    assume(len(set(flow_programs) & set(external_programs)) == 0)
    assume(len(set(codebase_programs) & set(external_programs)) == 0)
    assume(len(flow_programs) > 0)
    
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: Insert codebase programs into artifact_dependencies
        for prog in codebase_programs:
            cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, target_artifact_name, dependency_type)
                VALUES (?, ?, ?)
            """, (prog, 'DUMMY_TARGET', 'PROGRAM_CALL'))
        
        # Setup: Configure external programs in inbound_interfaces
        for ext_prog in external_programs:
            # External programs call the first flow program
            if len(flow_programs) > 0:
                cursor.execute("""
                    INSERT INTO inbound_interfaces 
                    (source_name, target_program, dependency_type, is_configured)
                    VALUES (?, ?, ?, ?)
                """, (ext_prog, flow_programs[0], 'PROGRAM_CALL', True))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow
        flow = MockFlow(programs=flow_programs)
        entry_program = flow_programs[0]
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: Only external programs create inbound interfaces
        inbound_sources = {i['source'] for i in interfaces['inbound']}
        
        # All inbound interface sources should be external programs
        assert inbound_sources.issubset(set(external_programs)), \
            f"Inbound interfaces should only come from external programs. " \
            f"Got: {inbound_sources}, Expected subset of: {set(external_programs)}"
        
        # No codebase programs should create inbound interfaces
        assert len(inbound_sources & set(codebase_programs)) == 0, \
            f"Codebase programs should not create inbound interfaces. " \
            f"Found: {inbound_sources & set(codebase_programs)}"
        
        # No flow programs should create inbound interfaces
        assert len(inbound_sources & set(flow_programs)) == 0, \
            f"Flow programs should not create inbound interfaces. " \
            f"Found: {inbound_sources & set(flow_programs)}"
        
        # All configured external programs should create inbound interfaces
        # (since they all target flow_programs[0])
        if len(external_programs) > 0:
            assert inbound_sources == set(external_programs), \
                f"All configured external programs should create inbound interfaces. " \
                f"Expected: {set(external_programs)}, Got: {inbound_sources}"
    
    finally:
        db.close()


@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=2,
        max_size=5,
        unique=True
    )
)
def test_property_internal_calls_no_inbound(flow_programs):
    """
    Property: Internal calls (within same flow) never create inbound interfaces.
    
    **Feature: fix-inbound-interface-logic, Property 5: Correct Call Classification**
    **Validates: Requirements 3.3**
    """
    assume(len(flow_programs) >= 2)
    
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: Configure internal call (flow_programs[0] -> flow_programs[1])
        # This should NOT create an inbound interface
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured)
            VALUES (?, ?, ?, ?)
        """, (flow_programs[0], flow_programs[1], 'PROGRAM_CALL', True))
        
        # Also insert into artifact_dependencies to mark as in codebase
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, target_artifact_name, dependency_type)
            VALUES (?, ?, ?)
        """, (flow_programs[0], 'DUMMY', 'PROGRAM_CALL'))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow
        flow = MockFlow(programs=flow_programs)
        entry_program = flow_programs[0]
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: No inbound interfaces (internal call)
        assert len(interfaces['inbound']) == 0, \
            f"Internal calls should not create inbound interfaces. " \
            f"Got {len(interfaces['inbound'])} interfaces"
    
    finally:
        db.close()


@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    ),
    codebase_caller=st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',)))
)
def test_property_cross_flow_calls_no_inbound(flow_programs, codebase_caller):
    """
    Property: Cross-flow calls (from codebase to flow) never create inbound interfaces.
    
    **Feature: fix-inbound-interface-logic, Property 5: Correct Call Classification**
    **Validates: Requirements 3.3**
    """
    assume(codebase_caller not in flow_programs)
    
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: Insert codebase_caller into artifact_dependencies (in codebase)
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, target_artifact_name, dependency_type)
            VALUES (?, ?, ?)
        """, (codebase_caller, 'DUMMY_TARGET', 'PROGRAM_CALL'))
        
        # Setup: Configure codebase_caller calling flow program
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured)
            VALUES (?, ?, ?, ?)
        """, (codebase_caller, flow_programs[0], 'PROGRAM_CALL', True))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow
        flow = MockFlow(programs=flow_programs)
        entry_program = flow_programs[0]
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: No inbound interfaces (cross-flow call from codebase)
        assert len(interfaces['inbound']) == 0, \
            f"Cross-flow calls from codebase should not create inbound interfaces. " \
            f"Got {len(interfaces['inbound'])} interfaces from {codebase_caller}"
    
    finally:
        db.close()


@settings(max_examples=100, deadline=None)
@given(
    flow_programs=st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',))),
        min_size=1,
        max_size=5,
        unique=True
    ),
    external_caller=st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu',)))
)
def test_property_external_calls_create_inbound(flow_programs, external_caller):
    """
    Property: External calls (from non-codebase to flow) create inbound interfaces.
    
    **Feature: fix-inbound-interface-logic, Property 5: Correct Call Classification**
    **Validates: Requirements 3.3**
    """
    assume(external_caller not in flow_programs)
    
    # Create test database
    db = create_test_db()
    cursor = db.cursor()
    
    try:
        # Setup: external_caller is NOT in artifact_dependencies (not in codebase)
        # (No need to insert - it's already not there)
        
        # Setup: Configure external_caller calling flow program
        cursor.execute("""
            INSERT INTO inbound_interfaces 
            (source_name, target_program, dependency_type, is_configured)
            VALUES (?, ?, ?, ?)
        """, (external_caller, flow_programs[0], 'PROGRAM_CALL', True))
        
        db.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db)
        
        # Create flow
        flow = MockFlow(programs=flow_programs)
        entry_program = flow_programs[0]
        
        # Identify interfaces
        interfaces = flow_builder.identify_interfaces(
            flow=flow,
            entry_program=entry_program
        )
        
        # Verify: One inbound interface (external call)
        assert len(interfaces['inbound']) == 1, \
            f"External calls should create inbound interfaces. " \
            f"Got {len(interfaces['inbound'])} interfaces"
        
        assert interfaces['inbound'][0]['source'] == external_caller, \
            f"Inbound interface source should be {external_caller}, " \
            f"got {interfaces['inbound'][0]['source']}"
    
    finally:
        db.close()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
