"""Property-based tests for program-level statistics accuracy.

**Feature: program-level-dependency-tracking, Property 16: Program-level statistics accuracy**
**Validates: Requirements 8.5**

This module tests that program-level dependency tracking statistics provide accurate
validation reports comparing file-level versus program-level dependency counts.
"""

import pytest
import tempfile
import sqlite3
import os
from pathlib import Path
from typing import Dict, List, Any
from hypothesis import given, strategies as st, assume, settings
from dataclasses import dataclass

from tools.legacy_analyzer.analysis.program_validation import (
    ProgramLevelStatisticsGenerator,
    ValidationReport,
    AccuracyMetrics,
    PerformanceMetrics,
    create_validation_report
)
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType
from tools.legacy_analyzer.dependency_loader import DependencyLoader


@dataclass
class TestDependency:
    """Test dependency for statistics validation."""
    source: str
    target: str
    dependency_type: str = "CALL"
    is_program_level: bool = True


# Generators for test data
@st.composite
def generate_program_boundary(draw):
    """Generate a valid ProgramBoundary for testing."""
    program_name = draw(st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd')), 
        min_size=1, 
        max_size=8
    ))
    start_line = draw(st.integers(min_value=1, max_value=100))
    end_line = draw(st.integers(min_value=start_line, max_value=start_line + 50))
    program_type = draw(st.sampled_from(list(ProgramType)))
    language = draw(st.sampled_from(['RPG', 'ASM', 'NATURAL', 'REXX', 'COBOL']))
    
    return ProgramBoundary(
        program_name=program_name,
        start_line=start_line,
        end_line=end_line,
        program_type=program_type,
        language=language,
        entry_points=[program_name],
        file_path=f"test_{program_name.lower()}.{language.lower()}"
    )


@st.composite
def generate_test_dependencies(draw, programs: List[ProgramBoundary]):
    """Generate test dependencies between programs."""
    if len(programs) < 2:
        return []
    
    num_deps = draw(st.integers(min_value=0, max_value=len(programs) * 2))
    dependencies = []
    
    for _ in range(num_deps):
        source_prog = draw(st.sampled_from(programs))
        target_prog = draw(st.sampled_from(programs))
        
        # Avoid self-references for cleaner tests
        if source_prog.program_name != target_prog.program_name:
            dependencies.append(TestDependency(
                source=source_prog.program_name,
                target=target_prog.program_name,
                is_program_level=draw(st.booleans())
            ))
    
    return dependencies


@st.composite
def generate_validation_report(draw):
    """Generate a ValidationReport for testing."""
    programs = draw(st.lists(generate_program_boundary(), min_size=1, max_size=5))
    dependencies = draw(generate_test_dependencies(programs))
    
    # Create accuracy metrics
    accuracy_metrics = AccuracyMetrics()
    accuracy_metrics.total_programs_detected = len(programs)
    accuracy_metrics.valid_programs = draw(st.integers(min_value=0, max_value=len(programs)))
    accuracy_metrics.invalid_programs = len(programs) - accuracy_metrics.valid_programs
    accuracy_metrics.total_dependencies = len(dependencies)
    accuracy_metrics.valid_dependencies = draw(st.integers(min_value=0, max_value=len(dependencies)))
    accuracy_metrics.invalid_dependencies = len(dependencies) - accuracy_metrics.valid_dependencies
    accuracy_metrics.calculate_scores()
    
    # Create performance metrics
    performance_metrics = PerformanceMetrics(
        operation_name="test_analysis",
        start_time=1000.0,
        end_time=1000.0 + draw(st.floats(min_value=0.1, max_value=10.0)),
        files_processed=1,
        programs_detected=len(programs),
        dependencies_extracted=len(dependencies)
    )
    performance_metrics.calculate_duration()
    
    language = draw(st.sampled_from(['RPG', 'ASM', 'NATURAL', 'REXX', 'COBOL']))
    file_path = f"test_file.{language.lower()}"
    
    return ValidationReport(
        file_path=file_path,
        language=language,
        boundary_validation=None,  # Not needed for statistics tests
        dependency_validation=None,  # Not needed for statistics tests
        accuracy_metrics=accuracy_metrics,
        performance_metrics=performance_metrics,
        programs_detected=programs
    )


class TestProgramLevelStatisticsAccuracy:
    """Test class for program-level statistics accuracy properties."""
    
    def setup_method(self):
        """Set up test database for each test."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.db_path = self.temp_db.name
        
        # Initialize database with required tables
        self._setup_test_database()
    
    def teardown_method(self):
        """Clean up test database after each test."""
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    def _setup_test_database(self):
        """Set up test database with required tables."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create inventory table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    artifact_name VARCHAR(44) NOT NULL,
                    program_within_file VARCHAR(44),
                    file_path TEXT NOT NULL,
                    language VARCHAR(20),
                    artifact_type VARCHAR(20),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create dependencies table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS dependencies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_artifact_name VARCHAR(44) NOT NULL,
                    target_artifact_name VARCHAR(44) NOT NULL,
                    dependency_type VARCHAR(20) NOT NULL,
                    source_file_path TEXT,
                    target_file_path TEXT,
                    line_number INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.commit()
    
    def _populate_test_data(self, programs: List[ProgramBoundary], dependencies: List[TestDependency]):
        """Populate test database with programs and dependencies."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Insert programs into inventory
            for program in programs:
                cursor.execute("""
                    INSERT INTO inventory (artifact_name, program_within_file, file_path, language, artifact_type)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    program.program_name,
                    program.program_name,
                    program.file_path or f"test_{program.program_name}.{program.language.lower()}",
                    program.language,
                    'PROGRAM'
                ))
            
            # Insert dependencies
            for dep in dependencies:
                # Determine if this is file-level or program-level based on naming convention
                source_name = dep.source if dep.is_program_level else f"file_for_{dep.source}"
                target_name = dep.target if dep.is_program_level else f"file_for_{dep.target}"
                
                cursor.execute("""
                    INSERT INTO dependencies (source_artifact_name, target_artifact_name, dependency_type)
                    VALUES (?, ?, ?)
                """, (source_name, target_name, dep.dependency_type))
            
            conn.commit()
    
    @given(st.lists(generate_validation_report(), min_size=1, max_size=10))
    @settings(max_examples=50, deadline=None)
    def test_statistics_accuracy_consistency(self, validation_reports: List[ValidationReport]):
        """
        **Property 16: Program-level statistics accuracy**
        
        For any set of validation reports, the generated statistics should be mathematically
        consistent and provide accurate comparisons between file-level and program-level counts.
        """
        assume(len(validation_reports) > 0)
        
        # Populate database with test data from validation reports
        all_programs = []
        all_dependencies = []
        
        for report in validation_reports:
            all_programs.extend(report.programs_detected)
            # Create some test dependencies based on the programs
            for i, program in enumerate(report.programs_detected):
                if i < len(report.programs_detected) - 1:
                    next_program = report.programs_detected[i + 1]
                    all_dependencies.append(TestDependency(
                        source=program.program_name,
                        target=next_program.program_name,
                        is_program_level=True
                    ))
        
        self._populate_test_data(all_programs, all_dependencies)
        
        # Generate statistics report
        stats_generator = ProgramLevelStatisticsGenerator(self.db_path)
        accuracy_report = stats_generator.generate_accuracy_report(validation_reports)
        
        # Verify report structure and consistency
        assert 'summary' in accuracy_report
        assert 'accuracy_metrics' in accuracy_report
        assert 'language_breakdown' in accuracy_report
        assert 'file_vs_program_comparison' in accuracy_report
        
        summary = accuracy_report['summary']
        
        # Verify mathematical consistency
        assert summary['total_files_analyzed'] == len(validation_reports)
        
        expected_total_programs = sum(len(report.programs_detected) for report in validation_reports)
        assert summary['total_programs_detected'] == expected_total_programs
        
        if summary['total_files_analyzed'] > 0:
            expected_avg_programs = expected_total_programs / summary['total_files_analyzed']
            assert abs(summary['average_programs_per_file'] - expected_avg_programs) < 0.001
        
        # Verify accuracy metrics are within valid ranges
        accuracy_metrics = accuracy_report['accuracy_metrics']
        
        for metric_type in ['boundary_completeness', 'dependency_accuracy', 'overall_accuracy']:
            metric = accuracy_metrics[metric_type]
            assert 0.0 <= metric['average'] <= 1.0
            assert 0.0 <= metric['minimum'] <= 1.0
            assert 0.0 <= metric['maximum'] <= 1.0
            assert metric['minimum'] <= metric['average'] <= metric['maximum']
        
        # Verify language breakdown consistency
        language_breakdown = accuracy_report['language_breakdown']
        total_files_in_breakdown = sum(lang_data['files'] for lang_data in language_breakdown.values())
        assert total_files_in_breakdown == len(validation_reports)
        
        total_programs_in_breakdown = sum(lang_data['programs'] for lang_data in language_breakdown.values())
        assert total_programs_in_breakdown == expected_total_programs
    
    @given(
        st.lists(generate_validation_report(), min_size=2, max_size=5),
        st.integers(min_value=1, max_value=10)
    )
    @settings(max_examples=30, deadline=None)
    def test_file_vs_program_comparison_accuracy(self, validation_reports: List[ValidationReport], file_level_deps: int):
        """
        Test that file-level vs program-level comparison provides accurate metrics.
        """
        assume(len(validation_reports) >= 2)
        
        # Create mixed file-level and program-level dependencies
        all_programs = []
        all_dependencies = []
        
        for report in validation_reports:
            all_programs.extend(report.programs_detected)
        
        # Add some file-level dependencies (without program separator)
        for i in range(file_level_deps):
            if len(all_programs) >= 2:
                source_prog = all_programs[i % len(all_programs)]
                target_prog = all_programs[(i + 1) % len(all_programs)]
                all_dependencies.append(TestDependency(
                    source=f"file_for_{source_prog.program_name}",
                    target=f"file_for_{target_prog.program_name}",
                    is_program_level=False
                ))
        
        # Add some program-level dependencies (with program separator or direct program names)
        program_level_deps = len(all_programs) // 2
        for i in range(program_level_deps):
            if len(all_programs) >= 2:
                source_prog = all_programs[i % len(all_programs)]
                target_prog = all_programs[(i + 1) % len(all_programs)]
                all_dependencies.append(TestDependency(
                    source=source_prog.program_name,
                    target=target_prog.program_name,
                    is_program_level=True
                ))
        
        self._populate_test_data(all_programs, all_dependencies)
        
        # Generate statistics
        stats_generator = ProgramLevelStatisticsGenerator(self.db_path)
        accuracy_report = stats_generator.generate_accuracy_report(validation_reports)
        
        # Verify file vs program comparison
        comparison = accuracy_report['file_vs_program_comparison']
        
        if 'error' not in comparison:
            total_deps = comparison['total_dependencies']
            file_deps = comparison['file_level_dependencies']
            prog_deps = comparison['program_level_dependencies']
            
            # Verify mathematical consistency
            assert total_deps == file_deps + prog_deps
            
            if total_deps > 0:
                expected_percentage = (prog_deps / total_deps) * 100
                assert abs(comparison['program_level_percentage'] - expected_percentage) < 0.001
                
                if file_deps > 0:
                    expected_improvement = prog_deps / file_deps
                    assert abs(comparison['granularity_improvement_factor'] - expected_improvement) < 0.001
    
    @given(st.lists(generate_validation_report(), min_size=1, max_size=8))
    @settings(max_examples=40, deadline=None)
    def test_performance_metrics_consistency(self, validation_reports: List[ValidationReport]):
        """
        Test that performance metrics in statistics reports are mathematically consistent.
        """
        assume(len(validation_reports) > 0)
        
        # Extract performance metrics
        performance_metrics = [report.performance_metrics for report in validation_reports]
        
        # Populate database for statistics generation
        all_programs = []
        for report in validation_reports:
            all_programs.extend(report.programs_detected)
        
        self._populate_test_data(all_programs, [])
        
        # Generate statistics
        stats_generator = ProgramLevelStatisticsGenerator(self.db_path)
        accuracy_report = stats_generator.generate_accuracy_report(validation_reports)
        performance_report = stats_generator.generate_performance_report(performance_metrics)
        
        # Verify performance summary consistency
        perf_summary = performance_report['summary']
        
        assert perf_summary['total_operations'] == len(performance_metrics)
        
        expected_total_duration = sum(metric.duration_seconds for metric in performance_metrics)
        assert abs(perf_summary['total_duration_seconds'] - expected_total_duration) < 0.001
        
        expected_total_files = sum(metric.files_processed for metric in performance_metrics)
        assert perf_summary['total_files_processed'] == expected_total_files
        
        expected_total_programs = sum(metric.programs_detected for metric in performance_metrics)
        assert perf_summary['total_programs_detected'] == expected_total_programs
        
        if len(performance_metrics) > 0:
            expected_avg_duration = expected_total_duration / len(performance_metrics)
            assert abs(perf_summary['average_duration_per_operation'] - expected_avg_duration) < 0.001
        
        # Verify throughput metrics are reasonable
        throughput = performance_report['throughput_metrics']
        
        assert throughput['average_files_per_second'] >= 0
        assert throughput['average_programs_per_second'] >= 0
        assert throughput['peak_files_per_second'] >= throughput['average_files_per_second']
        assert throughput['peak_programs_per_second'] >= throughput['average_programs_per_second']
    
    @given(
        st.lists(generate_validation_report(), min_size=1, max_size=5),
        st.floats(min_value=0.0, max_value=1.0),
        st.floats(min_value=0.0, max_value=1.0)
    )
    @settings(max_examples=30, deadline=None)
    def test_accuracy_score_calculation_correctness(self, validation_reports: List[ValidationReport], 
                                                   boundary_accuracy: float, dependency_accuracy: float):
        """
        Test that accuracy score calculations are mathematically correct.
        """
        assume(len(validation_reports) > 0)
        
        # Modify validation reports to have specific accuracy scores
        for report in validation_reports:
            report.accuracy_metrics.boundary_completeness_score = boundary_accuracy
            report.accuracy_metrics.dependency_accuracy_score = dependency_accuracy
            
            # Recalculate overall score using the same formula as the implementation
            if report.accuracy_metrics.total_programs_detected > 0 and report.accuracy_metrics.total_dependencies > 0:
                expected_overall = (boundary_accuracy * 0.6) + (dependency_accuracy * 0.4)
            elif report.accuracy_metrics.total_programs_detected > 0:
                expected_overall = boundary_accuracy
            elif report.accuracy_metrics.total_dependencies > 0:
                expected_overall = dependency_accuracy
            else:
                expected_overall = 0.0
            
            report.accuracy_metrics.overall_accuracy_score = expected_overall
        
        # Populate database
        all_programs = []
        for report in validation_reports:
            all_programs.extend(report.programs_detected)
        
        self._populate_test_data(all_programs, [])
        
        # Generate statistics
        stats_generator = ProgramLevelStatisticsGenerator(self.db_path)
        accuracy_report = stats_generator.generate_accuracy_report(validation_reports)
        
        # Verify accuracy calculations
        accuracy_metrics = accuracy_report['accuracy_metrics']
        
        # Check that averages are calculated correctly
        expected_boundary_avg = sum(report.accuracy_metrics.boundary_completeness_score 
                                  for report in validation_reports) / len(validation_reports)
        assert abs(accuracy_metrics['boundary_completeness']['average'] - expected_boundary_avg) < 0.001
        
        expected_dependency_avg = sum(report.accuracy_metrics.dependency_accuracy_score 
                                    for report in validation_reports) / len(validation_reports)
        assert abs(accuracy_metrics['dependency_accuracy']['average'] - expected_dependency_avg) < 0.001
        
        expected_overall_avg = sum(report.accuracy_metrics.overall_accuracy_score 
                                 for report in validation_reports) / len(validation_reports)
        assert abs(accuracy_metrics['overall_accuracy']['average'] - expected_overall_avg) < 0.001
        
        # Verify min/max calculations
        boundary_scores = [report.accuracy_metrics.boundary_completeness_score for report in validation_reports]
        assert accuracy_metrics['boundary_completeness']['minimum'] == min(boundary_scores)
        assert accuracy_metrics['boundary_completeness']['maximum'] == max(boundary_scores)
    
    def test_empty_validation_reports_handling(self):
        """
        Test that statistics generation handles empty validation reports gracefully.
        """
        stats_generator = ProgramLevelStatisticsGenerator(self.db_path)
        
        # Test with empty list
        empty_report = stats_generator.generate_accuracy_report([])
        assert 'error' in empty_report
        assert empty_report['error'] == 'No validation results provided'
        
        # Test with empty performance metrics
        empty_perf_report = stats_generator.generate_performance_report([])
        assert 'error' in empty_perf_report
        assert empty_perf_report['error'] == 'No performance metrics provided'
    
    @given(st.lists(generate_validation_report(), min_size=1, max_size=3))
    @settings(max_examples=20, deadline=None)
    def test_language_breakdown_accuracy(self, validation_reports: List[ValidationReport]):
        """
        Test that language breakdown statistics are accurate and consistent.
        """
        assume(len(validation_reports) > 0)
        
        # Populate database
        all_programs = []
        for report in validation_reports:
            all_programs.extend(report.programs_detected)
        
        self._populate_test_data(all_programs, [])
        
        # Generate statistics
        stats_generator = ProgramLevelStatisticsGenerator(self.db_path)
        accuracy_report = stats_generator.generate_accuracy_report(validation_reports)
        
        # Verify language breakdown
        language_breakdown = accuracy_report['language_breakdown']
        
        # Count expected values by language
        expected_by_language = {}
        for report in validation_reports:
            lang = report.language
            if lang not in expected_by_language:
                expected_by_language[lang] = {'files': 0, 'programs': 0, 'total_accuracy': 0.0}
            
            expected_by_language[lang]['files'] += 1
            expected_by_language[lang]['programs'] += len(report.programs_detected)
            expected_by_language[lang]['total_accuracy'] += report.accuracy_metrics.overall_accuracy_score
        
        # Verify each language's statistics
        for lang, expected_data in expected_by_language.items():
            assert lang in language_breakdown
            actual_data = language_breakdown[lang]
            
            assert actual_data['files'] == expected_data['files']
            assert actual_data['programs'] == expected_data['programs']
            
            expected_avg_accuracy = expected_data['total_accuracy'] / expected_data['files']
            assert abs(actual_data['avg_accuracy'] - expected_avg_accuracy) < 0.001


if __name__ == "__main__":
    pytest.main([__file__, "-v"])