"""Unit tests for ParserFactory."""

import pytest
from tools.legacy_analyzer.parsers.parser_factory import ParserFactory
from tools.legacy_analyzer.parsers.base_parser import BaseDependencyParser
from tools.legacy_analyzer.parsers.cobol_parser import COBOLDependencyParser
from tools.legacy_analyzer.parsers.jcl_parser import JCLDependencyParser
from tools.legacy_analyzer.parsers.pli_parser import PLIDependencyParser
from tools.legacy_analyzer.parsers.rpg_parser import RPGDependencyParser
from tools.legacy_analyzer.parsers.natural_parser import NaturalDependencyParser
from tools.legacy_analyzer.parsers.rexx_parser import REXXDependencyParser


class TestParserFactory:
    """Test suite for ParserFactory class."""
    
    def test_create_parser_cobol(self):
        """Test creating COBOL parser."""
        parser = ParserFactory.create_parser('COBOL')
        
        assert parser is not None
        assert isinstance(parser, COBOLDependencyParser)
        assert isinstance(parser, BaseDependencyParser)
    
    def test_create_parser_jcl(self):
        """Test creating JCL parser."""
        parser = ParserFactory.create_parser('JCL')
        
        assert parser is not None
        assert isinstance(parser, JCLDependencyParser)
        assert isinstance(parser, BaseDependencyParser)
    
    def test_create_parser_pli(self):
        """Test creating PL/I parser."""
        parser = ParserFactory.create_parser('PLI')
        
        assert parser is not None
        assert isinstance(parser, PLIDependencyParser)
        assert isinstance(parser, BaseDependencyParser)
    
    def test_create_parser_pli_alternate_name(self):
        """Test creating PL/I parser with alternate name."""
        parser = ParserFactory.create_parser('PL/I')
        
        assert parser is not None
        assert isinstance(parser, PLIDependencyParser)
    
    def test_create_parser_rpg(self):
        """Test creating RPG parser."""
        parser = ParserFactory.create_parser('RPG')
        
        assert parser is not None
        assert isinstance(parser, RPGDependencyParser)
        assert isinstance(parser, BaseDependencyParser)
    
    def test_create_parser_natural(self):
        """Test creating Natural parser."""
        parser = ParserFactory.create_parser('NATURAL')
        
        assert parser is not None
        assert isinstance(parser, NaturalDependencyParser)
        assert isinstance(parser, BaseDependencyParser)
    
    def test_create_parser_rexx(self):
        """Test creating REXX parser."""
        parser = ParserFactory.create_parser('REXX')
        
        assert parser is not None
        assert isinstance(parser, REXXDependencyParser)
        assert isinstance(parser, BaseDependencyParser)
    
    def test_create_parser_case_insensitive(self):
        """Test that language names are case-insensitive."""
        parser_upper = ParserFactory.create_parser('COBOL')
        parser_lower = ParserFactory.create_parser('cobol')
        parser_mixed = ParserFactory.create_parser('Cobol')
        
        assert type(parser_upper) == type(parser_lower) == type(parser_mixed)
    
    def test_create_parser_unsupported_language(self):
        """Test that unsupported language raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            ParserFactory.create_parser('FORTRAN')
        
        assert 'Unsupported language' in str(exc_info.value)
        assert 'FORTRAN' in str(exc_info.value)
    
    def test_get_parser_for_file_cobol(self):
        """Test auto-detecting COBOL parser from file extension."""
        parser = ParserFactory.get_parser_for_file('PROGRAM1.cbl')
        assert isinstance(parser, COBOLDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('PROGRAM2.cob')
        assert isinstance(parser, COBOLDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('PROGRAM3.cobol')
        assert isinstance(parser, COBOLDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('COPYBOOK1.cpy')
        assert isinstance(parser, COBOLDependencyParser)
    
    def test_get_parser_for_file_jcl(self):
        """Test auto-detecting JCL parser from file extension."""
        parser = ParserFactory.get_parser_for_file('JOB1.jcl')
        assert isinstance(parser, JCLDependencyParser)
    
    def test_get_parser_for_file_pli(self):
        """Test auto-detecting PL/I parser from file extension."""
        parser = ParserFactory.get_parser_for_file('PROGRAM1.pli')
        assert isinstance(parser, PLIDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('PROGRAM2.pl1')
        assert isinstance(parser, PLIDependencyParser)
    
    def test_get_parser_for_file_rpg(self):
        """Test auto-detecting RPG parser from file extension."""
        parser = ParserFactory.get_parser_for_file('PROGRAM1.rpg')
        assert isinstance(parser, RPGDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('PROGRAM2.rpgle')
        assert isinstance(parser, RPGDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('PROGRAM3.sqlrpgle')
        assert isinstance(parser, RPGDependencyParser)
    
    def test_get_parser_for_file_natural(self):
        """Test auto-detecting Natural parser from file extension."""
        parser = ParserFactory.get_parser_for_file('PROGRAM1.NSP')
        assert isinstance(parser, NaturalDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('SUBPROG1.NSN')
        assert isinstance(parser, NaturalDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('COPYCODE1.NSC')
        assert isinstance(parser, NaturalDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('LOCAL1.NSL')
        assert isinstance(parser, NaturalDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('GLOBAL1.NSG')
        assert isinstance(parser, NaturalDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('DATA1.NSD')
        assert isinstance(parser, NaturalDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('SUBR1.NSA')
        assert isinstance(parser, NaturalDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('HELPER1.NS8')
        assert isinstance(parser, NaturalDependencyParser)
    
    def test_get_parser_for_file_rexx(self):
        """Test auto-detecting REXX parser from file extension."""
        parser = ParserFactory.get_parser_for_file('SCRIPT1.rexx')
        assert isinstance(parser, REXXDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('SCRIPT2.rex')
        assert isinstance(parser, REXXDependencyParser)
    
    def test_get_parser_for_file_case_insensitive(self):
        """Test that file extensions are case-insensitive."""
        parser_upper = ParserFactory.get_parser_for_file('PROGRAM.CBL')
        parser_lower = ParserFactory.get_parser_for_file('program.cbl')
        parser_mixed = ParserFactory.get_parser_for_file('Program.CbL')
        
        assert type(parser_upper) == type(parser_lower) == type(parser_mixed)
    
    def test_get_parser_for_file_unsupported_extension(self):
        """Test that unsupported extension returns None."""
        parser = ParserFactory.get_parser_for_file('document.txt')
        assert parser is None
        
        parser = ParserFactory.get_parser_for_file('script.py')
        assert parser is None
    
    def test_get_parser_for_file_with_path(self):
        """Test auto-detecting parser with full file path."""
        parser = ParserFactory.get_parser_for_file('/path/to/PROGRAM1.cbl')
        assert isinstance(parser, COBOLDependencyParser)
        
        parser = ParserFactory.get_parser_for_file('C:\\path\\to\\PROGRAM1.jcl')
        assert isinstance(parser, JCLDependencyParser)
    
    def test_register_parser(self):
        """Test registering a custom parser."""
        # Create a mock parser class
        class CustomParser(BaseDependencyParser):
            def parse(self, source_code):
                return {}
            
            def get_supported_patterns(self):
                return ['CUSTOM']
            
            def get_supported_extensions(self):
                return ['.custom']
        
        # Register the custom parser
        ParserFactory.register_parser('CUSTOM', CustomParser, ['.custom', '.cst'])
        
        # Verify it was registered
        assert 'CUSTOM' in ParserFactory.get_supported_languages()
        assert '.custom' in ParserFactory.get_supported_extensions()
        assert '.cst' in ParserFactory.get_supported_extensions()
        
        # Verify we can create it
        parser = ParserFactory.create_parser('CUSTOM')
        assert isinstance(parser, CustomParser)
        
        # Verify we can get it by extension
        parser = ParserFactory.get_parser_for_file('test.custom')
        assert isinstance(parser, CustomParser)
        
        parser = ParserFactory.get_parser_for_file('test.cst')
        assert isinstance(parser, CustomParser)
    
    def test_register_parser_without_extensions(self):
        """Test registering a parser without specifying extensions."""
        class AnotherParser(BaseDependencyParser):
            def parse(self, source_code):
                return {}
            
            def get_supported_patterns(self):
                return ['ANOTHER']
            
            def get_supported_extensions(self):
                return ['.another']
        
        # Register without extensions
        ParserFactory.register_parser('ANOTHER', AnotherParser)
        
        # Verify it was registered
        assert 'ANOTHER' in ParserFactory.get_supported_languages()
        
        # Verify we can create it
        parser = ParserFactory.create_parser('ANOTHER')
        assert isinstance(parser, AnotherParser)
    
    def test_register_parser_invalid_class(self):
        """Test that registering non-parser class raises TypeError."""
        class NotAParser:
            pass
        
        with pytest.raises(TypeError) as exc_info:
            ParserFactory.register_parser('INVALID', NotAParser)
        
        assert 'must inherit from BaseDependencyParser' in str(exc_info.value)
    
    def test_get_supported_languages(self):
        """Test getting list of supported languages."""
        languages = ParserFactory.get_supported_languages()
        
        assert isinstance(languages, list)
        assert 'COBOL' in languages
        assert 'JCL' in languages
        assert 'PLI' in languages
        assert 'PL/I' in languages
        assert 'RPG' in languages
        assert 'NATURAL' in languages
        assert 'REXX' in languages
    
    def test_get_supported_extensions(self):
        """Test getting list of supported extensions."""
        extensions = ParserFactory.get_supported_extensions()
        
        assert isinstance(extensions, list)
        # COBOL extensions
        assert '.cbl' in extensions
        assert '.cob' in extensions
        assert '.cobol' in extensions
        assert '.cpy' in extensions
        # JCL extensions
        assert '.jcl' in extensions
        # PL/I extensions
        assert '.pli' in extensions
        assert '.pl1' in extensions
        # RPG extensions
        assert '.rpg' in extensions
        assert '.rpgle' in extensions
        assert '.sqlrpgle' in extensions
        # Natural extensions
        assert '.nsp' in extensions
        assert '.nsn' in extensions
        assert '.nsc' in extensions
        assert '.nsl' in extensions
        assert '.nsg' in extensions
        assert '.nsd' in extensions
        assert '.nsa' in extensions
        assert '.ns8' in extensions
        # REXX extensions
        assert '.rexx' in extensions
        assert '.rex' in extensions
    
    def test_multiple_parser_instances(self):
        """Test that factory creates separate instances."""
        parser1 = ParserFactory.create_parser('COBOL')
        parser2 = ParserFactory.create_parser('COBOL')
        
        assert parser1 is not parser2
        assert type(parser1) == type(parser2)
    
    def test_cross_language_support(self):
        """Test that factory supports all required languages."""
        # Test all languages from requirements
        languages = ['COBOL', 'JCL', 'PLI', 'RPG', 'NATURAL', 'REXX']
        
        for language in languages:
            parser = ParserFactory.create_parser(language)
            assert parser is not None
            assert isinstance(parser, BaseDependencyParser)
