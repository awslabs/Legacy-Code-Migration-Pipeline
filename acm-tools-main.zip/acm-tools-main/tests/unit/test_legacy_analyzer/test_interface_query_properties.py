"""
Property-based tests for database query methods in MigrationFlowBuilder.

This module tests the correctness properties of database query operations
for external interface configuration.
"""

import pytest
import sqlite3
import json
from contextlib import contextmanager
from hypothesis import given, strategies as st, settings
from tools.legacy_analyzer.migration.flow_builder import MigrationFlowBuilder
from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager


@contextmanager
def create_test_db():
    """Create an in-memory database for testing."""
    conn = sqlite3.Connection(":memory:")
    
    try:
        # Create required tables
        schema_manager = InterfaceSchemaManager(conn)
        schema_manager.create_tables()
        
        # Create artifact_dependencies table (required by MigrationFlowBuilder)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT,
                source_file_path TEXT,
                line_number INTEGER
            )
        """)
        
        # Create external_program_config table (required by ExternalConfigLoader)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS external_program_config (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern VARCHAR(100) NOT NULL,
                program_type VARCHAR(50),
                scope VARCHAR(50),
                is_pattern BOOLEAN DEFAULT 0,
                created_date DATE
            )
        """)
        
        # Create external_caller_config table (required by ExternalConfigLoader)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS external_caller_config (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                caller_name VARCHAR(100) NOT NULL,
                target_program VARCHAR(44) NOT NULL,
                call_type VARCHAR(20),
                metadata_json TEXT,
                created_date DATE
            )
        """)
        
        # Create program_file_mapping table (required by ExternalConfigLoader)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT NOT NULL,
                language TEXT
            )
        """)
        
        # Create inventory table (required by ExternalConfigLoader)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT
            )
        """)
        
        conn.commit()
        
        yield conn
    finally:
        conn.close()


# Strategy for generating valid program names
program_name_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), min_codepoint=65, max_codepoint=90),
    min_size=1,
    max_size=8
)

# Strategy for generating dependency types
dependency_type_strategy = st.sampled_from([
    'PROGRAM_CALL', 'CICS_LINK', 'CICS_XCTL', 'EXTERNAL_CALL'
])


@settings(max_examples=100, deadline=None)
@given(
    interfaces=st.lists(
        st.tuples(
            program_name_strategy,  # source_name
            program_name_strategy,  # target_program
            dependency_type_strategy  # dependency_type
        ),
        min_size=0,
        max_size=20,
        unique=True
    )
)
def test_property_inbound_query_consistency(interfaces):
    """
    Property 10: Database Query Consistency (Inbound Interfaces)
    
    For any set of inbound interfaces stored in the database,
    querying those interfaces SHALL return the same data that was inserted.
    
    **Feature: fix-inbound-interface-logic, Property 10: Database Query Consistency**
    **Validates: Requirements 10.1**
    """
    with create_test_db() as db_connection:
        cursor = db_connection.cursor()
        
        # Insert test data into inbound_interfaces table
        for source_name, target_program, dependency_type in interfaces:
            metadata = json.dumps({'system': 'TEST_SYSTEM'})
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured, metadata)
                VALUES (?, ?, ?, 1, ?)
            """, (source_name, target_program, dependency_type, metadata))
        
        db_connection.commit()
        
        # Create flow builder and query inbound interfaces
        flow_builder = MigrationFlowBuilder(db_connection)
        queried_interfaces = flow_builder._query_inbound_interfaces()
        
        # Verify all inserted interfaces are in the query result
        for source_name, target_program, dependency_type in interfaces:
            assert source_name in queried_interfaces, \
                f"Source {source_name} not found in query results"
            
            # Find the target in the list
            targets = queried_interfaces[source_name]
            matching_targets = [
                t for t in targets 
                if t['target'] == target_program and t['type'] == dependency_type
            ]
            
            assert len(matching_targets) == 1, \
                f"Expected exactly one match for {source_name} -> {target_program}, found {len(matching_targets)}"
            
            # Verify metadata is preserved
            assert 'metadata' in matching_targets[0], \
                f"Metadata missing for {source_name} -> {target_program}"
            assert matching_targets[0]['metadata'].get('system') == 'TEST_SYSTEM', \
                f"Metadata not preserved for {source_name} -> {target_program}"


@settings(max_examples=100, deadline=None)
@given(
    programs=st.lists(
        program_name_strategy,
        min_size=0,
        max_size=20,
        unique=True
    )
)
def test_property_outbound_query_consistency(programs):
    """
    Property 10: Database Query Consistency (Outbound Interfaces)
    
    For any set of outbound interfaces stored in the database,
    querying those interfaces SHALL return the same data that was inserted.
    
    **Feature: fix-inbound-interface-logic, Property 10: Database Query Consistency**
    **Validates: Requirements 10.2**
    """
    with create_test_db() as db_connection:
        cursor = db_connection.cursor()
        
        # Insert test data into outbound_interfaces table
        for program_name in programs:
            cursor.execute("""
                INSERT INTO outbound_interfaces 
                (program_name, reason, metadata)
                VALUES (?, 'configured', NULL)
            """, (program_name,))
        
        db_connection.commit()
        
        # Create flow builder and query outbound interfaces
        flow_builder = MigrationFlowBuilder(db_connection)
        queried_programs = flow_builder._query_outbound_interfaces()
        
        # Verify all inserted programs are in the query result
        for program_name in programs:
            assert program_name in queried_programs, \
                f"Program {program_name} not found in query results"
        
        # Verify no extra programs in result
        assert len(queried_programs) == len(programs), \
            f"Expected {len(programs)} programs, got {len(queried_programs)}"


@settings(max_examples=100, deadline=None)
@given(
    interfaces=st.lists(
        st.tuples(
            program_name_strategy,  # source_name
            program_name_strategy,  # target_program
            dependency_type_strategy  # dependency_type
        ),
        min_size=1,
        max_size=10,
        unique=True
    )
)
def test_property_query_caching(interfaces):
    """
    Property: Query results are cached per flow builder instance.
    
    For any flow builder instance, querying interfaces multiple times
    SHALL return the same cached result without re-querying the database.
    
    **Feature: fix-inbound-interface-logic**
    **Validates: Requirements 10.3, 10.4**
    """
    with create_test_db() as db_connection:
        cursor = db_connection.cursor()
        
        # Insert test data
        for source_name, target_program, dependency_type in interfaces:
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured, metadata)
                VALUES (?, ?, ?, 1, NULL)
            """, (source_name, target_program, dependency_type))
        
        db_connection.commit()
        
        # Create flow builder
        flow_builder = MigrationFlowBuilder(db_connection)
        
        # Query inbound interfaces twice
        result1 = flow_builder._query_inbound_interfaces()
        result2 = flow_builder._query_inbound_interfaces()
        
        # Verify results are identical (same object reference due to caching)
        assert result1 is result2, \
            "Query results should be cached and return the same object"
        
        # Query outbound interfaces twice
        result3 = flow_builder._query_outbound_interfaces()
        result4 = flow_builder._query_outbound_interfaces()
        
        # Verify results are identical
        assert result3 is result4, \
            "Query results should be cached and return the same object"


@settings(max_examples=50, deadline=None)
@given(
    interfaces=st.lists(
        st.tuples(
            program_name_strategy,  # source_name
            program_name_strategy,  # target_program
            dependency_type_strategy  # dependency_type
        ),
        min_size=1,
        max_size=10,
        unique=True
    )
)
def test_property_empty_table_returns_empty_result(interfaces):
    """
    Property: Querying empty tables returns empty results.
    
    For any flow builder instance with empty interface tables,
    querying SHALL return empty collections without errors.
    
    **Feature: fix-inbound-interface-logic**
    **Validates: Requirements 10.1, 10.2**
    """
    with create_test_db() as db_connection:
        # Create flow builder (tables are empty)
        flow_builder = MigrationFlowBuilder(db_connection)
        
        # Query inbound interfaces
        inbound_result = flow_builder._query_inbound_interfaces()
        assert inbound_result == {}, \
            "Empty inbound_interfaces table should return empty dict"
        
        # Query outbound interfaces
        outbound_result = flow_builder._query_outbound_interfaces()
        assert outbound_result == set(), \
            "Empty outbound_interfaces table should return empty set"


@settings(max_examples=100, deadline=None)
@given(
    source_name=program_name_strategy,
    targets=st.lists(
        st.tuples(
            program_name_strategy,  # target_program
            dependency_type_strategy  # dependency_type
        ),
        min_size=1,
        max_size=10,
        unique=True
    )
)
def test_property_multiple_targets_per_source(source_name, targets):
    """
    Property: A single external caller can have multiple target programs.
    
    For any external caller with multiple target programs,
    querying SHALL return all targets grouped under the source name.
    
    **Feature: fix-inbound-interface-logic**
    **Validates: Requirements 10.1**
    """
    with create_test_db() as db_connection:
        cursor = db_connection.cursor()
        
        # Insert multiple targets for the same source
        for target_program, dependency_type in targets:
            cursor.execute("""
                INSERT INTO inbound_interfaces 
                (source_name, target_program, dependency_type, is_configured, metadata)
                VALUES (?, ?, ?, 1, NULL)
            """, (source_name, target_program, dependency_type))
        
        db_connection.commit()
        
        # Create flow builder and query
        flow_builder = MigrationFlowBuilder(db_connection)
        queried_interfaces = flow_builder._query_inbound_interfaces()
        
        # Verify source exists
        assert source_name in queried_interfaces, \
            f"Source {source_name} not found in query results"
        
        # Verify all targets are present
        queried_targets = queried_interfaces[source_name]
        assert len(queried_targets) == len(targets), \
            f"Expected {len(targets)} targets, got {len(queried_targets)}"
        
        # Verify each target is present
        for target_program, dependency_type in targets:
            matching = [
                t for t in queried_targets
                if t['target'] == target_program and t['type'] == dependency_type
            ]
            assert len(matching) == 1, \
                f"Expected exactly one match for {target_program}, found {len(matching)}"
