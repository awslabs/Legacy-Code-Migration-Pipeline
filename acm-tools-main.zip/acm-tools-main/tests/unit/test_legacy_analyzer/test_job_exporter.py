"""
Unit Tests for JobExporter.

This module contains unit tests for the JCL job export functionality,
testing specific examples and edge cases.

Feature: jcl-job-export
"""

import pytest
import sqlite3
import tempfile
import os
from tools.legacy_analyzer.migration.job_exporter import JobExporter
from tools.legacy_analyzer.migration.exceptions import ExportError


@pytest.fixture
def temp_db():
    """Create a temporary database file with schema."""
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    
    # Create basic schema
    conn = sqlite3.connect(path)
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE inventory_jcl (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_name VARCHAR(8) NOT NULL,
            library_name VARCHAR(44) NOT NULL,
            last_modified DATE,
            size_lines INTEGER,
            datasets TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            source_artifact_name TEXT,
            source_artifact_type TEXT,
            target_artifact_name TEXT,
            target_artifact_type TEXT,
            dependency_type TEXT
        )
    """)
    
    cursor.execute("""
        CREATE TABLE inventory (
            name TEXT PRIMARY KEY,
            type TEXT,
            is_entry_point BOOLEAN
        )
    """)
    
    conn.commit()
    conn.close()
    
    yield path
    
    # Cleanup
    if os.path.exists(path):
        os.unlink(path)


@pytest.fixture
def carddemo_db():
    """Use the actual carddemo database for integration tests."""
    db_path = 'results/carddemo_analysis/carddemo.db'
    
    if not os.path.exists(db_path):
        pytest.skip(f"Carddemo database not found at {db_path}")
    
    return db_path


class TestDatabaseConnection:
    """Tests for database connection and initialization."""
    
    def test_connection_success(self, temp_db):
        """Test successful database connection."""
        with JobExporter(temp_db) as exporter:
            assert exporter.db is not None
            assert exporter.cursor is not None
            assert exporter.db_path == temp_db
    
    def test_connection_failure_nonexistent_db(self):
        """Test connection failure with non-existent database."""
        with pytest.raises(ExportError) as exc_info:
            JobExporter('/nonexistent/path/to/database.db')
        
        assert 'Database file not found' in str(exc_info.value)
        assert exc_info.value.operation == 'connect'
    
    def test_context_manager_closes_connection(self, temp_db):
        """Test that context manager properly closes database connection."""
        exporter = JobExporter(temp_db)
        
        with exporter:
            assert exporter.db is not None
        
        # After context exit, connection should be closed
        with pytest.raises(sqlite3.ProgrammingError):
            exporter.cursor.execute("SELECT 1")
    
    def test_explicit_close(self, temp_db):
        """Test explicit close method."""
        exporter = JobExporter(temp_db)
        exporter.close()
        
        # After close, connection should be closed
        with pytest.raises(sqlite3.ProgrammingError):
            exporter.cursor.execute("SELECT 1")


class TestQueryJobs:
    """Tests for _query_jobs method."""
    
    def test_query_jobs_empty_database(self, temp_db):
        """Test querying jobs from empty database returns empty list."""
        with JobExporter(temp_db) as exporter:
            jobs = exporter._query_jobs()
        
        assert jobs == []
        assert isinstance(jobs, list)
    
    def test_query_jobs_single_job(self, temp_db):
        """Test querying single job from database."""
        # Add a job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            jobs = exporter._query_jobs()
        
        assert len(jobs) == 1
        job = jobs[0]
        
        # Verify structure
        assert 'jobName' in job
        assert 'library' in job
        assert 'lastModified' in job
        assert 'sizeLines' in job
        
        # Verify values
        assert job['jobName'] == 'TESTJOB1'
        assert job['library'] == 'JCL'
        assert job['sizeLines'] == 100
    
    def test_query_jobs_multiple_jobs(self, temp_db):
        """Test querying multiple jobs from database."""
        # Add multiple jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOB1', 'JCL', 100),
            ('JOB2', 'JCL', 200),
            ('JOB3', 'JCL', 150),
        ])
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            jobs = exporter._query_jobs()
        
        assert len(jobs) == 3
        
        # Verify all jobs are present
        job_names = {job['jobName'] for job in jobs}
        assert job_names == {'JOB1', 'JOB2', 'JOB3'}
    
    def test_query_jobs_sorted_by_name(self, temp_db):
        """Test that jobs are returned sorted by name."""
        # Add jobs in non-alphabetical order
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('ZJOB', 'JCL', 100),
            ('AJOB', 'JCL', 200),
            ('MJOB', 'JCL', 150),
        ])
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            jobs = exporter._query_jobs()
        
        # Verify sorted order
        job_names = [job['jobName'] for job in jobs]
        assert job_names == ['AJOB', 'MJOB', 'ZJOB']
    
    def test_query_jobs_with_carddemo(self, carddemo_db):
        """Test querying jobs from actual carddemo database (35 jobs expected)."""
        with JobExporter(carddemo_db) as exporter:
            jobs = exporter._query_jobs()
        
        # Carddemo should have 35 JCL jobs
        assert len(jobs) == 35, f"Expected 35 jobs, got {len(jobs)}"
        
        # Verify all jobs have required fields
        for job in jobs:
            assert 'jobName' in job
            assert 'library' in job
            assert 'lastModified' in job
            assert 'sizeLines' in job
            assert isinstance(job['jobName'], str)
            assert len(job['jobName']) > 0


class TestQueryJobSteps:
    """Tests for _query_job_steps method."""
    
    def test_query_steps_empty_dependencies(self, temp_db):
        """Test querying steps for job with no dependencies."""
        # Add a job with no dependencies
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            steps = exporter._query_job_steps('TESTJOB1')
        
        assert steps == []
        assert isinstance(steps, list)
    
    def test_query_steps_single_program(self, temp_db):
        """Test querying steps for job with single program dependency."""
        # Add a job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        
        # Add dependency
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, ('TESTJOB1', 'JCL', 'PROG1', 'COBOL', 'INVOKES'))
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            steps = exporter._query_job_steps('TESTJOB1')
        
        assert len(steps) == 1
        step = steps[0]
        
        # Verify structure
        assert 'stepName' in step
        assert 'program' in step
        assert 'type' in step
        assert 'purpose' in step
        assert 'flowEntry' in step
        
        # Verify values
        assert step['program'] == 'PROG1'
        assert step['stepName'] == 'STEP01'
        assert step['type'] == 'UNKNOWN'
        assert step['flowEntry'] is False
    
    def test_query_steps_multiple_programs(self, temp_db):
        """Test querying steps for job with multiple program dependencies."""
        # Add a job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        
        # Add multiple dependencies
        cursor.executemany("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ('TESTJOB1', 'JCL', 'PROG1', 'COBOL', 'INVOKES'),
            ('TESTJOB1', 'JCL', 'PROG2', 'COBOL', 'INVOKES'),
            ('TESTJOB1', 'JCL', 'PROG3', 'PLI', 'INVOKES'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            steps = exporter._query_job_steps('TESTJOB1')
        
        assert len(steps) == 3
        
        # Verify programs
        programs = {step['program'] for step in steps}
        assert programs == {'PROG1', 'PROG2', 'PROG3'}
        
        # Verify step names are sequential
        step_names = [step['stepName'] for step in steps]
        assert 'STEP01' in step_names
        assert 'STEP02' in step_names
        assert 'STEP03' in step_names
    
    def test_query_steps_nonexistent_job(self, temp_db):
        """Test querying steps for non-existent job returns empty list."""
        with JobExporter(temp_db) as exporter:
            steps = exporter._query_job_steps('NONEXISTENT')
        
        assert steps == []
    
    def test_query_steps_with_utility_programs(self, temp_db):
        """Test querying steps that include utility programs."""
        # Add a job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        
        # Add dependencies including utilities
        cursor.executemany("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ('TESTJOB1', 'JCL', 'IEFBR14', 'UTILITY', 'INVOKES'),
            ('TESTJOB1', 'JCL', 'PROG1', 'COBOL', 'INVOKES'),
            ('TESTJOB1', 'JCL', 'IDCAMS', 'UTILITY', 'INVOKES'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            steps = exporter._query_job_steps('TESTJOB1')
        
        assert len(steps) == 3
        
        # Verify all programs are included
        programs = {step['program'] for step in steps}
        assert programs == {'IEFBR14', 'PROG1', 'IDCAMS'}
    
    def test_query_steps_with_carddemo_job(self, carddemo_db):
        """Test querying steps from actual carddemo job."""
        # First get a job name from carddemo
        with JobExporter(carddemo_db) as exporter:
            jobs = exporter._query_jobs()
        
        if not jobs:
            pytest.skip("No jobs found in carddemo database")
        
        # Query steps for first job
        job_name = jobs[0]['jobName']
        
        with JobExporter(carddemo_db) as exporter:
            steps = exporter._query_job_steps(job_name)
        
        # Verify structure (even if empty)
        assert isinstance(steps, list)
        
        # If steps exist, verify structure
        for step in steps:
            assert 'stepName' in step
            assert 'program' in step
            assert 'type' in step
            assert 'purpose' in step
            assert 'flowEntry' in step


class TestErrorHandling:
    """Tests for error handling."""
    
    def test_query_jobs_database_error(self, temp_db):
        """Test handling of database query errors."""
        # Create exporter
        exporter = JobExporter(temp_db)
        
        # Close connection to force error
        exporter.db.close()
        
        # Query should raise ExportError
        with pytest.raises(ExportError) as exc_info:
            exporter._query_jobs()
        
        assert 'Failed to query jobs' in str(exc_info.value)
        assert exc_info.value.operation == 'query'
    
    def test_query_steps_database_error(self, temp_db):
        """Test handling of database query errors for steps."""
        # Create exporter
        exporter = JobExporter(temp_db)
        
        # Close connection to force error
        exporter.db.close()
        
        # Query should raise ExportError
        with pytest.raises(ExportError) as exc_info:
            exporter._query_job_steps('TESTJOB1')
        
        assert 'Failed to query steps' in str(exc_info.value)
        assert exc_info.value.operation == 'query'


class TestUtilityProgramDetection:
    """Tests for _is_utility_program method."""
    
    def test_is_utility_program_known_utilities(self, temp_db):
        """Test that known utility programs are correctly identified."""
        with JobExporter(temp_db) as exporter:
            # Test common utilities
            assert exporter._is_utility_program('IEFBR14') is True
            assert exporter._is_utility_program('IDCAMS') is True
            assert exporter._is_utility_program('IEBGENER') is True
            assert exporter._is_utility_program('SORT') is True
            assert exporter._is_utility_program('DFSORT') is True
            assert exporter._is_utility_program('IKJEFT01') is True
    
    def test_is_utility_program_case_insensitive(self, temp_db):
        """Test that utility detection is case-insensitive."""
        with JobExporter(temp_db) as exporter:
            # Test lowercase
            assert exporter._is_utility_program('iefbr14') is True
            assert exporter._is_utility_program('idcams') is True
            
            # Test mixed case
            assert exporter._is_utility_program('IefBr14') is True
            assert exporter._is_utility_program('IdCaMs') is True
    
    def test_is_utility_program_with_whitespace(self, temp_db):
        """Test that utility detection handles whitespace."""
        with JobExporter(temp_db) as exporter:
            # Test with leading/trailing whitespace
            assert exporter._is_utility_program('  IEFBR14  ') is True
            assert exporter._is_utility_program('\tIDCAMS\n') is True
    
    def test_is_utility_program_custom_programs(self, temp_db):
        """Test that custom programs are not identified as utilities."""
        with JobExporter(temp_db) as exporter:
            # Test custom program names
            assert exporter._is_utility_program('CUSTPROG') is False
            assert exporter._is_utility_program('MYPROG') is False
            assert exporter._is_utility_program('COBOL001') is False
            assert exporter._is_utility_program('TESTPROG') is False
    
    def test_is_utility_program_empty_string(self, temp_db):
        """Test that empty string returns False."""
        with JobExporter(temp_db) as exporter:
            assert exporter._is_utility_program('') is False
            assert exporter._is_utility_program('   ') is False
    
    def test_is_utility_program_none(self, temp_db):
        """Test that None returns False."""
        with JobExporter(temp_db) as exporter:
            assert exporter._is_utility_program(None) is False


class TestJobCategorization:
    """Tests for _categorize_job method - edge cases."""
    
    def test_categorize_job_no_steps(self, temp_db):
        """Test categorization of job with no steps."""
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job([])
        
        assert job_type == 'INFRASTRUCTURE'
        assert has_custom_code is False
    
    def test_categorize_job_only_utilities(self, temp_db):
        """Test categorization of job with only utility programs."""
        steps = [
            {'program': 'IEFBR14', 'stepName': 'STEP01'},
            {'program': 'IDCAMS', 'stepName': 'STEP02'},
            {'program': 'IEBGENER', 'stepName': 'STEP03'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        assert job_type == 'INFRASTRUCTURE'
        assert has_custom_code is False
    
    def test_categorize_job_only_custom_programs(self, temp_db):
        """Test categorization of job with only custom programs."""
        steps = [
            {'program': 'CUSTPROG1', 'stepName': 'STEP01'},
            {'program': 'CUSTPROG2', 'stepName': 'STEP02'},
            {'program': 'CUSTPROG3', 'stepName': 'STEP03'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        assert job_type == 'APPLICATION'
        assert has_custom_code is True
    
    def test_categorize_job_mixed_custom_and_utility(self, temp_db):
        """Test categorization of job with mixed custom and utility programs."""
        steps = [
            {'program': 'IEFBR14', 'stepName': 'STEP01'},
            {'program': 'CUSTPROG1', 'stepName': 'STEP02'},
            {'program': 'IDCAMS', 'stepName': 'STEP03'},
            {'program': 'CUSTPROG2', 'stepName': 'STEP04'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        # Should be APPLICATION because it has at least one custom program
        assert job_type == 'APPLICATION'
        assert has_custom_code is True
    
    def test_categorize_job_single_utility_step(self, temp_db):
        """Test categorization of job with single utility step."""
        steps = [
            {'program': 'IEFBR14', 'stepName': 'STEP01'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        assert job_type == 'INFRASTRUCTURE'
        assert has_custom_code is False
    
    def test_categorize_job_single_custom_step(self, temp_db):
        """Test categorization of job with single custom step."""
        steps = [
            {'program': 'CUSTPROG', 'stepName': 'STEP01'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        assert job_type == 'APPLICATION'
        assert has_custom_code is True
    
    def test_categorize_job_custom_program_first(self, temp_db):
        """Test that categorization stops at first custom program."""
        steps = [
            {'program': 'CUSTPROG', 'stepName': 'STEP01'},
            {'program': 'IEFBR14', 'stepName': 'STEP02'},
            {'program': 'IDCAMS', 'stepName': 'STEP03'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        # Should be APPLICATION because first step is custom
        assert job_type == 'APPLICATION'
        assert has_custom_code is True
    
    def test_categorize_job_custom_program_last(self, temp_db):
        """Test categorization when custom program is last step."""
        steps = [
            {'program': 'IEFBR14', 'stepName': 'STEP01'},
            {'program': 'IDCAMS', 'stepName': 'STEP02'},
            {'program': 'CUSTPROG', 'stepName': 'STEP03'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        # Should be APPLICATION because it has a custom program
        assert job_type == 'APPLICATION'
        assert has_custom_code is True
    
    def test_categorize_job_step_without_program(self, temp_db):
        """Test categorization when step has no program field."""
        steps = [
            {'stepName': 'STEP01'},  # Missing program field
            {'program': 'IEFBR14', 'stepName': 'STEP02'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        # Step without program is treated as custom (not a utility)
        assert job_type == 'APPLICATION'
        assert has_custom_code is True
    
    def test_categorize_job_step_with_empty_program(self, temp_db):
        """Test categorization when step has empty program name."""
        steps = [
            {'program': '', 'stepName': 'STEP01'},
            {'program': 'IEFBR14', 'stepName': 'STEP02'},
        ]
        
        with JobExporter(temp_db) as exporter:
            job_type, has_custom_code = exporter._categorize_job(steps)
        
        # Empty program is treated as custom (not a utility)
        assert job_type == 'APPLICATION'
        assert has_custom_code is True



class TestStepPurposeGeneration:
    """Tests for _generate_step_purpose method."""
    
    def test_generate_purpose_for_known_utilities(self, temp_db):
        """Test that known utilities get specific purpose descriptions."""
        with JobExporter(temp_db) as exporter:
            # Test common utilities
            assert exporter._generate_step_purpose('IEFBR14') == 'Allocate or delete datasets'
            assert exporter._generate_step_purpose('IDCAMS') == 'VSAM dataset operations'
            assert exporter._generate_step_purpose('IEBGENER') == 'Copy sequential dataset'
            assert exporter._generate_step_purpose('SORT') == 'Sort dataset'
            assert exporter._generate_step_purpose('DSNTEP2') == 'Execute DB2 commands'
            assert exporter._generate_step_purpose('IKJEFT01') == 'Execute TSO commands'
    
    def test_generate_purpose_case_insensitive(self, temp_db):
        """Test that purpose generation is case-insensitive."""
        with JobExporter(temp_db) as exporter:
            # Test lowercase
            assert exporter._generate_step_purpose('iefbr14') == 'Allocate or delete datasets'
            assert exporter._generate_step_purpose('idcams') == 'VSAM dataset operations'
            
            # Test mixed case
            assert exporter._generate_step_purpose('IefBr14') == 'Allocate or delete datasets'
    
    def test_generate_purpose_for_custom_programs(self, temp_db):
        """Test that custom programs get generic execution description."""
        with JobExporter(temp_db) as exporter:
            assert exporter._generate_step_purpose('CUSTPROG') == 'Execute CUSTPROG'
            assert exporter._generate_step_purpose('MYPROG') == 'Execute MYPROG'
            assert exporter._generate_step_purpose('COBOL001') == 'Execute COBOL001'
    
    def test_generate_purpose_empty_string(self, temp_db):
        """Test that empty string returns generic description."""
        with JobExporter(temp_db) as exporter:
            assert exporter._generate_step_purpose('') == 'Execute program'
    
    def test_generate_purpose_none(self, temp_db):
        """Test that None returns generic description."""
        with JobExporter(temp_db) as exporter:
            assert exporter._generate_step_purpose(None) == 'Execute program'


class TestCustomProgramDetection:
    """Tests for _is_custom_program method."""
    
    def test_is_custom_program_in_inventory(self, temp_db):
        """Test that programs in inventory are correctly identified as custom."""
        # Add a custom program to inventory
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('CUSTPROG', 'COBOL', False))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            assert exporter._is_custom_program('CUSTPROG') is True
    
    def test_is_custom_program_utility_in_inventory(self, temp_db):
        """Test that utilities in inventory are not identified as custom."""
        # Add a utility to inventory
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('IEFBR14', 'UTILITY', False))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            assert exporter._is_custom_program('IEFBR14') is False
    
    def test_is_custom_program_not_in_inventory_known_utility(self, temp_db):
        """Test that known utilities not in inventory are not identified as custom."""
        with JobExporter(temp_db) as exporter:
            # Known utilities should return False even if not in inventory
            assert exporter._is_custom_program('IEFBR14') is False
            assert exporter._is_custom_program('IDCAMS') is False
            assert exporter._is_custom_program('SORT') is False
    
    def test_is_custom_program_not_in_inventory_unknown(self, temp_db):
        """Test that unknown programs not in inventory are assumed to be custom."""
        with JobExporter(temp_db) as exporter:
            # Unknown programs should be assumed custom
            assert exporter._is_custom_program('UNKNOWNPROG') is True
            assert exporter._is_custom_program('CUSTPROG') is True
    
    def test_is_custom_program_empty_string(self, temp_db):
        """Test that empty string returns False."""
        with JobExporter(temp_db) as exporter:
            assert exporter._is_custom_program('') is False
    
    def test_is_custom_program_none(self, temp_db):
        """Test that None returns False."""
        with JobExporter(temp_db) as exporter:
            assert exporter._is_custom_program(None) is False


class TestFlowEntryPointDetection:
    """Tests for _is_flow_entry_point method."""
    
    def test_is_flow_entry_point_true(self, temp_db):
        """Test that programs marked as entry points are correctly identified."""
        # Add an entry point program to inventory
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('ENTRYPROG', 'COBOL', True))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            assert exporter._is_flow_entry_point('ENTRYPROG') is True
    
    def test_is_flow_entry_point_false(self, temp_db):
        """Test that programs not marked as entry points return False."""
        # Add a non-entry point program to inventory
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('NORMALPROG', 'COBOL', False))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            assert exporter._is_flow_entry_point('NORMALPROG') is False
    
    def test_is_flow_entry_point_not_in_inventory(self, temp_db):
        """Test that programs not in inventory return False."""
        with JobExporter(temp_db) as exporter:
            assert exporter._is_flow_entry_point('UNKNOWNPROG') is False
    
    def test_is_flow_entry_point_empty_string(self, temp_db):
        """Test that empty string returns False."""
        with JobExporter(temp_db) as exporter:
            assert exporter._is_flow_entry_point('') is False
    
    def test_is_flow_entry_point_none(self, temp_db):
        """Test that None returns False."""
        with JobExporter(temp_db) as exporter:
            assert exporter._is_flow_entry_point(None) is False


class TestAssignStepTypes:
    """Tests for _assign_step_types method."""
    
    def test_assign_step_types_utility_programs(self, temp_db):
        """Test that utility programs are assigned type UTILITY."""
        steps = [
            {'stepName': 'STEP01', 'program': 'IEFBR14', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
            {'stepName': 'STEP02', 'program': 'IDCAMS', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
        ]
        
        with JobExporter(temp_db) as exporter:
            result = exporter._assign_step_types(steps)
        
        assert result[0]['type'] == 'UTILITY'
        assert result[1]['type'] == 'UTILITY'
        assert result[0]['flowEntry'] is False
        assert result[1]['flowEntry'] is False
    
    def test_assign_step_types_custom_programs(self, temp_db):
        """Test that custom programs are assigned type CUSTOM."""
        # Add custom programs to inventory
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, [
            ('CUSTPROG1', 'COBOL', False),
            ('CUSTPROG2', 'PLI', False),
        ])
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'CUSTPROG1', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
            {'stepName': 'STEP02', 'program': 'CUSTPROG2', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
        ]
        
        with JobExporter(temp_db) as exporter:
            result = exporter._assign_step_types(steps)
        
        assert result[0]['type'] == 'CUSTOM'
        assert result[1]['type'] == 'CUSTOM'
    
    def test_assign_step_types_flow_entry_points(self, temp_db):
        """Test that flow entry points are marked with flowEntry=True."""
        # Add entry point program to inventory
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('ENTRYPROG', 'COBOL', True))
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'ENTRYPROG', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
        ]
        
        with JobExporter(temp_db) as exporter:
            result = exporter._assign_step_types(steps)
        
        assert result[0]['type'] == 'CUSTOM'
        assert result[0]['flowEntry'] is True
    
    def test_assign_step_types_mixed_programs(self, temp_db):
        """Test assignment with mixed utility and custom programs."""
        # Add custom program to inventory
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('CUSTPROG', 'COBOL', False))
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'IEFBR14', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
            {'stepName': 'STEP02', 'program': 'CUSTPROG', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
            {'stepName': 'STEP03', 'program': 'IDCAMS', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
        ]
        
        with JobExporter(temp_db) as exporter:
            result = exporter._assign_step_types(steps)
        
        assert result[0]['type'] == 'UTILITY'
        assert result[1]['type'] == 'CUSTOM'
        assert result[2]['type'] == 'UTILITY'
    
    def test_assign_step_types_empty_list(self, temp_db):
        """Test that empty list returns empty list."""
        with JobExporter(temp_db) as exporter:
            result = exporter._assign_step_types([])
        
        assert result == []
    
    def test_assign_step_types_modifies_in_place(self, temp_db):
        """Test that _assign_step_types modifies steps in place."""
        steps = [
            {'stepName': 'STEP01', 'program': 'IEFBR14', 'type': 'UNKNOWN', 'purpose': 'Test', 'flowEntry': False},
        ]
        
        with JobExporter(temp_db) as exporter:
            result = exporter._assign_step_types(steps)
        
        # Verify that the original list was modified
        assert steps is result
        assert steps[0]['type'] == 'UTILITY'



class TestLinkToFlow:
    """Tests for _link_to_flow method."""
    
    def test_link_to_flow_with_entry_point(self, temp_db):
        """Test linking job to flow when step has entry point."""
        # Add entry point program and flow to database
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('ENTRYPROG', 'COBOL', True))
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            INSERT INTO migration_flows (flow_id, entry_point)
            VALUES (?, ?)
        """, ('FLOW_ENTRYPROG', 'ENTRYPROG'))
        
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'ENTRYPROG', 'type': 'CUSTOM', 'purpose': 'Test', 'flowEntry': True},
        ]
        
        with JobExporter(temp_db) as exporter:
            linked_flow = exporter._link_to_flow(steps)
        
        assert linked_flow == 'FLOW_ENTRYPROG'
    
    def test_link_to_flow_without_entry_point(self, temp_db):
        """Test linking job to flow when no entry point exists."""
        steps = [
            {'stepName': 'STEP01', 'program': 'IEFBR14', 'type': 'UTILITY', 'purpose': 'Test', 'flowEntry': False},
            {'stepName': 'STEP02', 'program': 'CUSTPROG', 'type': 'CUSTOM', 'purpose': 'Test', 'flowEntry': False},
        ]
        
        with JobExporter(temp_db) as exporter:
            linked_flow = exporter._link_to_flow(steps)
        
        assert linked_flow is None
    
    def test_link_to_flow_empty_steps(self, temp_db):
        """Test linking job to flow with empty steps list."""
        with JobExporter(temp_db) as exporter:
            linked_flow = exporter._link_to_flow([])
        
        assert linked_flow is None
    
    def test_link_to_flow_multiple_entry_points(self, temp_db):
        """Test that first entry point is used when multiple exist."""
        # Add entry point programs and flows to database
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.executemany("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, [
            ('ENTRY1', 'COBOL', True),
            ('ENTRY2', 'COBOL', True),
        ])
        
        cursor.executemany("""
            INSERT INTO migration_flows (flow_id, entry_point)
            VALUES (?, ?)
        """, [
            ('FLOW_ENTRY1', 'ENTRY1'),
            ('FLOW_ENTRY2', 'ENTRY2'),
        ])
        
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'ENTRY1', 'type': 'CUSTOM', 'purpose': 'Test', 'flowEntry': True},
            {'stepName': 'STEP02', 'program': 'ENTRY2', 'type': 'CUSTOM', 'purpose': 'Test', 'flowEntry': True},
        ]
        
        with JobExporter(temp_db) as exporter:
            linked_flow = exporter._link_to_flow(steps)
        
        # Should link to first entry point
        assert linked_flow == 'FLOW_ENTRY1'
    
    def test_link_to_flow_entry_point_not_first(self, temp_db):
        """Test linking when entry point is not the first step."""
        # Add entry point program and flow to database
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('ENTRYPROG', 'COBOL', True))
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            INSERT INTO migration_flows (flow_id, entry_point)
            VALUES (?, ?)
        """, ('FLOW_ENTRYPROG', 'ENTRYPROG'))
        
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'IEFBR14', 'type': 'UTILITY', 'purpose': 'Test', 'flowEntry': False},
            {'stepName': 'STEP02', 'program': 'ENTRYPROG', 'type': 'CUSTOM', 'purpose': 'Test', 'flowEntry': True},
            {'stepName': 'STEP03', 'program': 'IDCAMS', 'type': 'UTILITY', 'purpose': 'Test', 'flowEntry': False},
        ]
        
        with JobExporter(temp_db) as exporter:
            linked_flow = exporter._link_to_flow(steps)
        
        assert linked_flow == 'FLOW_ENTRYPROG'
    
    def test_link_to_flow_flow_not_in_database(self, temp_db):
        """Test linking when flow doesn't exist in database."""
        # Add entry point program but no flow
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('ENTRYPROG', 'COBOL', True))
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'ENTRYPROG', 'type': 'CUSTOM', 'purpose': 'Test', 'flowEntry': True},
        ]
        
        with JobExporter(temp_db) as exporter:
            linked_flow = exporter._link_to_flow(steps)
        
        # Should return None because flow doesn't exist
        assert linked_flow is None
    
    def test_link_to_flow_naming_convention(self, temp_db):
        """Test that flow naming follows FLOW_{program} convention."""
        # Add entry point program and flow to database
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES (?, ?, ?)
        """, ('MAINPROG', 'COBOL', True))
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            INSERT INTO migration_flows (flow_id, entry_point)
            VALUES (?, ?)
        """, ('FLOW_MAINPROG', 'MAINPROG'))
        
        conn.commit()
        conn.close()
        
        steps = [
            {'stepName': 'STEP01', 'program': 'MAINPROG', 'type': 'CUSTOM', 'purpose': 'Test', 'flowEntry': True},
        ]
        
        with JobExporter(temp_db) as exporter:
            linked_flow = exporter._link_to_flow(steps)
        
        # Verify naming convention
        assert linked_flow.startswith('FLOW_')
        assert linked_flow == 'FLOW_MAINPROG'


class TestValidateFlowExists:
    """Tests for _validate_flow_exists method."""
    
    def test_validate_flow_exists_true(self, temp_db):
        """Test validation when flow exists in database."""
        # Create migration_flows table and add a flow
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            INSERT INTO migration_flows (flow_id, entry_point)
            VALUES (?, ?)
        """, ('FLOW_TESTPROG', 'TESTPROG'))
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            exists = exporter._validate_flow_exists('FLOW_TESTPROG')
        
        assert exists is True
    
    def test_validate_flow_exists_false(self, temp_db):
        """Test validation when flow doesn't exist in database."""
        # Create migration_flows table but don't add the flow
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            exists = exporter._validate_flow_exists('FLOW_NONEXISTENT')
        
        assert exists is False
    
    def test_validate_flow_exists_no_table(self, temp_db):
        """Test validation when migration_flows table doesn't exist."""
        with JobExporter(temp_db) as exporter:
            exists = exporter._validate_flow_exists('FLOW_TESTPROG')
        
        # Should return False when table doesn't exist
        assert exists is False
    
    def test_validate_flow_exists_empty_string(self, temp_db):
        """Test validation with empty string."""
        with JobExporter(temp_db) as exporter:
            exists = exporter._validate_flow_exists('')
        
        assert exists is False
    
    def test_validate_flow_exists_none(self, temp_db):
        """Test validation with None."""
        with JobExporter(temp_db) as exporter:
            exists = exporter._validate_flow_exists(None)
        
        assert exists is False
    
    def test_validate_flow_exists_multiple_flows(self, temp_db):
        """Test validation with multiple flows in database."""
        # Create migration_flows table and add multiple flows
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE migration_flows (
                flow_id TEXT PRIMARY KEY,
                entry_point TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.executemany("""
            INSERT INTO migration_flows (flow_id, entry_point)
            VALUES (?, ?)
        """, [
            ('FLOW_PROG1', 'PROG1'),
            ('FLOW_PROG2', 'PROG2'),
            ('FLOW_PROG3', 'PROG3'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            # Test existing flows
            assert exporter._validate_flow_exists('FLOW_PROG1') is True
            assert exporter._validate_flow_exists('FLOW_PROG2') is True
            assert exporter._validate_flow_exists('FLOW_PROG3') is True
            
            # Test non-existing flow
            assert exporter._validate_flow_exists('FLOW_PROG4') is False



class TestQueryExplicitDependencies:
    """Tests for _query_explicit_dependencies method."""
    
    def test_query_explicit_dependencies_no_dependencies(self, temp_db):
        """Test querying explicit dependencies when none exist."""
        # Add a job with no dependencies
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._query_explicit_dependencies('TESTJOB1')
        
        assert deps == {'mustRunAfter': [], 'mustRunBefore': []}
    
    def test_query_explicit_dependencies_with_must_run_after(self, temp_db):
        """Test querying explicit dependencies with mustRunAfter."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOB1', 'JCL', 100),
            ('JOB2', 'JCL', 100),
        ])
        
        # Add dependency: JOB2 depends on JOB1 (JOB2 must run after JOB1)
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, ('JOB2', 'JCL', 'JOB1', 'JCL', 'DEPENDS_ON'))
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._query_explicit_dependencies('JOB2')
        
        assert deps['mustRunAfter'] == ['JOB1']
        assert deps['mustRunBefore'] == []
    
    def test_query_explicit_dependencies_with_must_run_before(self, temp_db):
        """Test querying explicit dependencies with mustRunBefore."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOB1', 'JCL', 100),
            ('JOB2', 'JCL', 100),
        ])
        
        # Add dependency: JOB2 depends on JOB1 (JOB1 must run before JOB2)
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, ('JOB2', 'JCL', 'JOB1', 'JCL', 'DEPENDS_ON'))
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._query_explicit_dependencies('JOB1')
        
        assert deps['mustRunAfter'] == []
        assert deps['mustRunBefore'] == ['JOB2']
    
    def test_query_explicit_dependencies_multiple(self, temp_db):
        """Test querying explicit dependencies with multiple dependencies."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOB1', 'JCL', 100),
            ('JOB2', 'JCL', 100),
            ('JOB3', 'JCL', 100),
            ('JOB4', 'JCL', 100),
        ])
        
        # Add dependencies:
        # JOB3 depends on JOB1 and JOB2
        # JOB4 depends on JOB3
        cursor.executemany("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ('JOB3', 'JCL', 'JOB1', 'JCL', 'DEPENDS_ON'),
            ('JOB3', 'JCL', 'JOB2', 'JCL', 'DEPENDS_ON'),
            ('JOB4', 'JCL', 'JOB3', 'JCL', 'DEPENDS_ON'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            # Test JOB3
            deps3 = exporter._query_explicit_dependencies('JOB3')
            assert sorted(deps3['mustRunAfter']) == ['JOB1', 'JOB2']
            assert deps3['mustRunBefore'] == ['JOB4']
            
            # Test JOB1
            deps1 = exporter._query_explicit_dependencies('JOB1')
            assert deps1['mustRunAfter'] == []
            assert deps1['mustRunBefore'] == ['JOB3']
    
    def test_query_explicit_dependencies_sorted(self, temp_db):
        """Test that dependencies are returned in sorted order."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOBA', 'JCL', 100),
            ('JOBB', 'JCL', 100),
            ('JOBC', 'JCL', 100),
            ('JOBD', 'JCL', 100),
        ])
        
        # Add dependencies in non-alphabetical order
        cursor.executemany("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ('JOBD', 'JCL', 'JOBC', 'JCL', 'DEPENDS_ON'),
            ('JOBD', 'JCL', 'JOBA', 'JCL', 'DEPENDS_ON'),
            ('JOBD', 'JCL', 'JOBB', 'JCL', 'DEPENDS_ON'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._query_explicit_dependencies('JOBD')
        
        # Verify sorted order
        assert deps['mustRunAfter'] == ['JOBA', 'JOBB', 'JOBC']


class TestInferDatasetDependencies:
    """Tests for _infer_dataset_dependencies method."""
    
    def test_infer_dataset_dependencies_returns_empty(self, temp_db):
        """Test that dataset inference returns empty dependencies (current implementation)."""
        with JobExporter(temp_db) as exporter:
            deps = exporter._infer_dataset_dependencies('TESTJOB1', ['TESTJOB1', 'TESTJOB2'])
        
        # Current implementation returns empty dependencies
        assert deps == {'mustRunAfter': [], 'mustRunBefore': []}
    
    def test_infer_dataset_dependencies_structure(self, temp_db):
        """Test that dataset inference returns correct structure."""
        with JobExporter(temp_db) as exporter:
            deps = exporter._infer_dataset_dependencies('TESTJOB1', ['TESTJOB1'])
        
        # Verify structure
        assert isinstance(deps, dict)
        assert 'mustRunAfter' in deps
        assert 'mustRunBefore' in deps
        assert isinstance(deps['mustRunAfter'], list)
        assert isinstance(deps['mustRunBefore'], list)


class TestExtractDependencies:
    """Tests for _extract_dependencies method."""
    
    def test_extract_dependencies_no_dependencies(self, temp_db):
        """Test extracting dependencies when none exist."""
        # Add a job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._extract_dependencies('TESTJOB1', ['TESTJOB1'])
        
        assert deps == {'mustRunAfter': [], 'mustRunBefore': []}
    
    def test_extract_dependencies_combines_explicit_and_inferred(self, temp_db):
        """Test that extract combines explicit and inferred dependencies."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOB1', 'JCL', 100),
            ('JOB2', 'JCL', 100),
        ])
        
        # Add explicit dependency
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, ('JOB2', 'JCL', 'JOB1', 'JCL', 'DEPENDS_ON'))
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._extract_dependencies('JOB2', ['JOB1', 'JOB2'])
        
        # Should have explicit dependency
        assert 'JOB1' in deps['mustRunAfter']
    
    def test_extract_dependencies_removes_self_dependencies(self, temp_db):
        """Test that self-dependencies are removed."""
        # Add a job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        
        # Add self-dependency (should be removed)
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, ('TESTJOB1', 'JCL', 'TESTJOB1', 'JCL', 'DEPENDS_ON'))
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._extract_dependencies('TESTJOB1', ['TESTJOB1'])
        
        # Self-dependency should be removed
        assert 'TESTJOB1' not in deps['mustRunAfter']
        assert 'TESTJOB1' not in deps['mustRunBefore']
    
    def test_extract_dependencies_removes_duplicates(self, temp_db):
        """Test that duplicate dependencies are removed."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOB1', 'JCL', 100),
            ('JOB2', 'JCL', 100),
        ])
        
        # Add duplicate dependencies
        cursor.executemany("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ('JOB2', 'JCL', 'JOB1', 'JCL', 'DEPENDS_ON'),
            ('JOB2', 'JCL', 'JOB1', 'JCL', 'DEPENDS_ON'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._extract_dependencies('JOB2', ['JOB1', 'JOB2'])
        
        # Should have only one instance of JOB1
        assert deps['mustRunAfter'].count('JOB1') == 1
    
    def test_extract_dependencies_sorted_output(self, temp_db):
        """Test that dependencies are returned in sorted order."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOBA', 'JCL', 100),
            ('JOBB', 'JCL', 100),
            ('JOBC', 'JCL', 100),
            ('JOBD', 'JCL', 100),
        ])
        
        # Add dependencies in non-alphabetical order
        cursor.executemany("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ('JOBD', 'JCL', 'JOBC', 'JCL', 'DEPENDS_ON'),
            ('JOBD', 'JCL', 'JOBA', 'JCL', 'DEPENDS_ON'),
            ('JOBD', 'JCL', 'JOBB', 'JCL', 'DEPENDS_ON'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._extract_dependencies('JOBD', ['JOBA', 'JOBB', 'JOBC', 'JOBD'])
        
        # Verify sorted order
        assert deps['mustRunAfter'] == ['JOBA', 'JOBB', 'JOBC']
    
    def test_extract_dependencies_detects_circular(self, temp_db):
        """Test that circular dependencies are detected and logged."""
        # Add jobs
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.executemany("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, [
            ('JOB1', 'JCL', 100),
            ('JOB2', 'JCL', 100),
        ])
        
        # Add circular dependencies
        cursor.executemany("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ('JOB1', 'JCL', 'JOB2', 'JCL', 'DEPENDS_ON'),
            ('JOB2', 'JCL', 'JOB1', 'JCL', 'DEPENDS_ON'),
        ])
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            # Should not raise an error, but should log warning
            deps1 = exporter._extract_dependencies('JOB1', ['JOB1', 'JOB2'])
            deps2 = exporter._extract_dependencies('JOB2', ['JOB1', 'JOB2'])
        
        # Both jobs should have each other in their dependencies
        assert 'JOB2' in deps1['mustRunAfter']
        assert 'JOB2' in deps1['mustRunBefore']
        assert 'JOB1' in deps2['mustRunAfter']
        assert 'JOB1' in deps2['mustRunBefore']
    
    def test_extract_dependencies_structure(self, temp_db):
        """Test that extract returns correct structure."""
        # Add a job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES (?, ?, ?)
        """, ('TESTJOB1', 'JCL', 100))
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._extract_dependencies('TESTJOB1', ['TESTJOB1'])
        
        # Verify structure
        assert isinstance(deps, dict)
        assert 'mustRunAfter' in deps
        assert 'mustRunBefore' in deps
        assert isinstance(deps['mustRunAfter'], list)
        assert isinstance(deps['mustRunBefore'], list)



class TestFileOperations:
    """Tests for file operations - directory creation, file overwrite, output path display."""
    
    def test_directory_creation(self, temp_db):
        """Test that output directory is created if it doesn't exist."""
        import tempfile
        import shutil
        
        # Create a temporary directory that we'll delete
        temp_parent = tempfile.mkdtemp()
        
        try:
            # Create a non-existent subdirectory path
            output_dir = os.path.join(temp_parent, 'nonexistent', 'nested', 'dir')
            
            # Verify directory doesn't exist
            assert not os.path.exists(output_dir)
            
            # Populate database with a test job
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, ('TESTJOB1', 'JCL', 100))
            conn.commit()
            conn.close()
            
            # Export jobs (should create directory)
            with JobExporter(temp_db) as exporter:
                result = exporter.export_jobs(output_dir, sort_by='name')
            
            # Verify directory was created
            assert os.path.exists(output_dir)
            assert os.path.isdir(output_dir)
            
            # Verify output file exists
            output_file = os.path.join(output_dir, 'jobs_by_name.json')
            assert os.path.exists(output_file)
        
        finally:
            # Cleanup
            if os.path.exists(temp_parent):
                shutil.rmtree(temp_parent)
    
    def test_file_overwrite_behavior(self, temp_db):
        """Test that existing files are overwritten without prompting."""
        import tempfile
        import json
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Populate database with a test job
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, ('TESTJOB1', 'JCL', 100))
            conn.commit()
            conn.close()
            
            # Create an existing file with different content
            output_file = os.path.join(output_dir, 'jobs_by_name.json')
            with open(output_file, 'w') as f:
                json.dump({'old': 'data'}, f)
            
            # Verify file exists with old content
            assert os.path.exists(output_file)
            with open(output_file, 'r') as f:
                old_content = json.load(f)
            assert old_content == {'old': 'data'}
            
            # Export jobs (should overwrite file)
            with JobExporter(temp_db) as exporter:
                result = exporter.export_jobs(output_dir, sort_by='name')
            
            # Verify file was overwritten with new content
            assert os.path.exists(output_file)
            with open(output_file, 'r') as f:
                new_content = json.load(f)
            
            # Verify new content is different and has expected structure
            assert new_content != old_content
            assert 'jobs' in new_content
            assert 'summary' in new_content
            assert len(new_content['jobs']) == 1
    
    def test_output_path_display(self, temp_db, capsys):
        """Test that full output path is displayed to console."""
        import tempfile
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Populate database with a test job
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, ('TESTJOB1', 'JCL', 100))
            conn.commit()
            conn.close()
            
            # Export jobs
            with JobExporter(temp_db) as exporter:
                result = exporter.export_jobs(output_dir, sort_by='name')
            
            # Capture console output
            captured = capsys.readouterr()
            
            # Verify output path is displayed
            assert 'Job export written to:' in captured.out
            
            # Verify full absolute path is shown
            expected_filename = 'jobs_by_name.json'
            assert expected_filename in captured.out
            
            # Verify the path shown is absolute
            output_lines = captured.out.split('\n')
            path_line = [line for line in output_lines if 'Job export written to:' in line][0]
            
            # Extract path from output
            path_shown = path_line.split('Job export written to:')[1].strip()
            
            # Verify it's an absolute path
            assert os.path.isabs(path_shown), f"Path should be absolute: {path_shown}"
            
            # Verify the file actually exists at that path
            assert os.path.exists(path_shown), f"File should exist at displayed path: {path_shown}"
    
    def test_multiple_exports_different_strategies(self, temp_db):
        """Test that multiple exports with different strategies create separate files."""
        import tempfile
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Populate database with test jobs
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.executemany("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, [
                ('JOB1', 'JCL', 100),
                ('JOB2', 'JCL', 200),
            ])
            conn.commit()
            conn.close()
            
            # Export with different strategies
            strategies = ['name', 'type', 'dependencies', 'complexity']
            
            with JobExporter(temp_db) as exporter:
                for strategy in strategies:
                    exporter.export_jobs(output_dir, sort_by=strategy)
            
            # Verify all files were created
            for strategy in strategies:
                expected_file = os.path.join(output_dir, f'jobs_by_{strategy}.json')
                assert os.path.exists(expected_file), f"File should exist: {expected_file}"
                
                # Verify file has valid JSON content
                with open(expected_file, 'r') as f:
                    import json
                    content = json.load(f)
                    assert 'jobs' in content
                    assert 'summary' in content
                    assert content['summary']['sortedBy'] == strategy
    
    def test_output_file_permissions(self, temp_db):
        """Test that output files are created with appropriate permissions."""
        import tempfile
        import stat
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Populate database with a test job
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, ('TESTJOB1', 'JCL', 100))
            conn.commit()
            conn.close()
            
            # Export jobs
            with JobExporter(temp_db) as exporter:
                result = exporter.export_jobs(output_dir, sort_by='name')
            
            # Check file permissions
            output_file = os.path.join(output_dir, 'jobs_by_name.json')
            file_stat = os.stat(output_file)
            
            # Verify file is readable
            assert file_stat.st_mode & stat.S_IRUSR, "File should be readable by owner"
            
            # Verify file is writable
            assert file_stat.st_mode & stat.S_IWUSR, "File should be writable by owner"
    
    def test_json_encoding_utf8(self, temp_db):
        """Test that JSON files are written with UTF-8 encoding."""
        import tempfile
        import json
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Populate database with a test job
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES (?, ?, ?)
            """, ('TESTJOB1', 'JCL', 100))
            conn.commit()
            conn.close()
            
            # Export jobs
            with JobExporter(temp_db) as exporter:
                result = exporter.export_jobs(output_dir, sort_by='name')
            
            # Read file with UTF-8 encoding
            output_file = os.path.join(output_dir, 'jobs_by_name.json')
            
            # Verify file can be read as UTF-8
            with open(output_file, 'r', encoding='utf-8') as f:
                content = json.load(f)
            
            # Verify content is valid
            assert 'jobs' in content
            assert 'summary' in content
    
    def test_empty_database_creates_valid_file(self, temp_db):
        """Test that exporting from empty database creates valid JSON file."""
        import tempfile
        import json
        
        # Create temporary output directory
        with tempfile.TemporaryDirectory() as output_dir:
            # Export jobs from empty database
            with JobExporter(temp_db) as exporter:
                result = exporter.export_jobs(output_dir, sort_by='name')
            
            # Verify file was created
            output_file = os.path.join(output_dir, 'jobs_by_name.json')
            assert os.path.exists(output_file)
            
            # Verify file has valid JSON structure
            with open(output_file, 'r') as f:
                content = json.load(f)
            
            # Verify structure
            assert 'jobs' in content
            assert 'summary' in content
            assert content['jobs'] == []
            assert content['summary']['totalJobs'] == 0



class TestErrorHandling:
    """Comprehensive tests for error handling and edge cases."""
    
    def test_missing_database_file(self):
        """Test error handling when database file doesn't exist."""
        # Requirements: 10.1
        with pytest.raises(ExportError) as exc_info:
            JobExporter('/nonexistent/path/database.db')
        
        assert 'Database file not found' in str(exc_info.value)
        assert exc_info.value.operation == 'connect'
    
    def test_database_path_is_directory(self, tmp_path):
        """Test error handling when database path is a directory."""
        # Requirements: 10.1
        # Create a directory instead of a file
        db_dir = tmp_path / "database.db"
        db_dir.mkdir()
        
        with pytest.raises(ExportError) as exc_info:
            JobExporter(str(db_dir))
        
        assert 'not a file' in str(exc_info.value)
        assert exc_info.value.operation == 'connect'
    
    def test_unwritable_output_directory(self, temp_db, tmp_path):
        """Test error handling when output directory is not writable."""
        # Requirements: 10.2
        # Create a read-only directory
        output_dir = tmp_path / "readonly"
        output_dir.mkdir()
        output_dir.chmod(0o444)  # Read-only
        
        try:
            with JobExporter(temp_db) as exporter:
                with pytest.raises(ExportError) as exc_info:
                    exporter.export_jobs(str(output_dir), sort_by='name')
                
                assert 'not writable' in str(exc_info.value)
                assert exc_info.value.operation == 'write'
        finally:
            # Restore permissions for cleanup
            output_dir.chmod(0o755)
    
    def test_empty_database(self, temp_db, tmp_path):
        """Test handling of empty database (no jobs)."""
        # Requirements: 10.3
        output_dir = tmp_path / "output"
        
        with JobExporter(temp_db) as exporter:
            # Export from empty database
            result = exporter.export_jobs(str(output_dir), sort_by='name')
            
            # Should create valid empty export
            assert result['jobs'] == []
            assert result['summary']['totalJobs'] == 0
            assert result['summary']['applicationJobs'] == 0
            assert result['summary']['infrastructureJobs'] == 0
            
            # Output file should exist
            output_file = output_dir / "jobs_by_name.json"
            assert output_file.exists()
    
    def test_database_query_failure(self, temp_db):
        """Test handling of database query failures."""
        # Requirements: 10.4
        with JobExporter(temp_db) as exporter:
            # Close database to force query failure
            exporter.db.close()
            
            with pytest.raises(ExportError) as exc_info:
                exporter._query_jobs()
            
            assert 'Failed to query jobs' in str(exc_info.value)
            assert exc_info.value.operation == 'query'
            assert exc_info.value.cause is not None
    
    def test_json_serialization_failure(self, temp_db, tmp_path, monkeypatch):
        """Test handling of JSON serialization failures."""
        # Requirements: 10.5
        import json
        
        # Mock json.dumps to raise an error
        original_dumps = json.dumps
        
        def mock_dumps(*args, **kwargs):
            raise TypeError("Cannot serialize object")
        
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        
        with JobExporter(temp_db) as exporter:
            # Add a test job
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO inventory_jcl (member_name, library_name, size_lines)
                VALUES ('TESTJOB', 'TEST.LIB', 10)
            """)
            conn.commit()
            conn.close()
            
            # Patch json.dumps in the job_exporter module
            monkeypatch.setattr('tools.legacy_analyzer.migration.job_exporter.json.dumps', mock_dumps)
            
            with pytest.raises(ExportError) as exc_info:
                exporter.export_jobs(str(output_dir), sort_by='name')
            
            assert 'Failed to serialize' in str(exc_info.value)
            assert exc_info.value.operation == 'serialize'
    
    def test_circular_dependency_handling(self, temp_db):
        """Test handling of circular dependencies."""
        # Requirements: 10.3
        # Create jobs with circular dependencies
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Add jobs
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES ('JOB1', 'TEST.LIB', 10), ('JOB2', 'TEST.LIB', 10)
        """)
        
        # Add circular dependencies: JOB1 -> JOB2 and JOB2 -> JOB1
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES 
            ('JOB1', 'JCL', 'JOB2', 'JCL', 'CALLS'),
            ('JOB2', 'JCL', 'JOB1', 'JCL', 'CALLS')
        """)
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            # Should handle circular dependencies gracefully
            deps = exporter._extract_dependencies('JOB1', ['JOB1', 'JOB2'])
            
            # Should not crash, and should log warning
            assert isinstance(deps, dict)
            assert 'mustRunAfter' in deps
            assert 'mustRunBefore' in deps
    
    def test_missing_flow_reference(self, temp_db):
        """Test handling of missing flow references."""
        # Requirements: 10.3
        # Create a job that references a non-existent flow
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Add job
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES ('TESTJOB', 'TEST.LIB', 10)
        """)
        
        # Add program as entry point
        cursor.execute("""
            INSERT INTO inventory (name, type, is_entry_point)
            VALUES ('MAINPROG', 'COBOL', 1)
        """)
        
        # Add dependency to entry point
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES ('TESTJOB', 'JCL', 'MAINPROG', 'COBOL', 'CALLS')
        """)
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            steps = exporter._query_job_steps('TESTJOB')
            steps = exporter._assign_step_types(steps)
            
            # Should return None for missing flow (not crash)
            linked_flow = exporter._link_to_flow(steps)
            assert linked_flow is None
    
    def test_invalid_sort_strategy(self, temp_db, tmp_path):
        """Test error handling for invalid sort strategy."""
        # Requirements: 7.5
        output_dir = tmp_path / "output"
        
        with JobExporter(temp_db) as exporter:
            with pytest.raises(ValueError) as exc_info:
                exporter.export_jobs(str(output_dir), sort_by='invalid_strategy')
            
            assert 'Invalid sort_by parameter' in str(exc_info.value)
    
    def test_directory_creation_failure(self, temp_db, tmp_path, monkeypatch):
        """Test handling of directory creation failures."""
        # Requirements: 10.2
        import os
        
        # Mock os.makedirs to raise an error
        def mock_makedirs(*args, **kwargs):
            raise OSError("Permission denied")
        
        output_dir = tmp_path / "output"
        
        with JobExporter(temp_db) as exporter:
            monkeypatch.setattr('os.makedirs', mock_makedirs)
            
            with pytest.raises(ExportError) as exc_info:
                exporter.export_jobs(str(output_dir), sort_by='name')
            
            assert 'Cannot create output directory' in str(exc_info.value)
            assert exc_info.value.operation == 'create_directory'
    
    def test_file_write_failure(self, temp_db, tmp_path, monkeypatch):
        """Test handling of file write failures."""
        # Requirements: 10.2
        # Create output directory
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        
        # Add a test job
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES ('TESTJOB', 'TEST.LIB', 10)
        """)
        conn.commit()
        conn.close()
        
        # Mock open to raise an error
        original_open = open
        
        def mock_open(*args, **kwargs):
            if 'jobs_by_' in str(args[0]):
                raise OSError("Disk full")
            return original_open(*args, **kwargs)
        
        with JobExporter(temp_db) as exporter:
            monkeypatch.setattr('builtins.open', mock_open)
            
            with pytest.raises(ExportError) as exc_info:
                exporter.export_jobs(str(output_dir), sort_by='name')
            
            assert 'Failed to write export file' in str(exc_info.value)
            assert exc_info.value.operation == 'write'
    
    def test_graceful_exit_on_error(self, temp_db):
        """Test that errors result in graceful exit with proper error messages."""
        # Requirements: 10.4, 10.5
        # Test with non-existent database
        try:
            exporter = JobExporter('/nonexistent/database.db')
            assert False, "Should have raised ExportError"
        except ExportError as e:
            # Should have clear error message
            assert str(e)
            assert e.operation == 'connect'
            # Should not crash - exception is properly structured
    
    def test_error_with_cause_chain(self, temp_db):
        """Test that errors properly chain underlying causes."""
        # Requirements: 10.4, 10.5
        with JobExporter(temp_db) as exporter:
            # Close database to force error
            exporter.db.close()
            
            try:
                exporter._query_jobs()
                assert False, "Should have raised ExportError"
            except ExportError as e:
                # Should have cause chain
                assert e.cause is not None
                assert isinstance(e.cause, sqlite3.Error)
                # Error message should include cause information
                assert 'caused by' in str(e)


class TestEdgeCases:
    """Tests for edge cases and boundary conditions."""
    
    def test_job_with_no_steps(self, temp_db):
        """Test handling of job with no steps."""
        # Requirements: 2.4
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Add job with no dependencies (no steps)
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES ('EMPTYJOB', 'TEST.LIB', 5)
        """)
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            steps = exporter._query_job_steps('EMPTYJOB')
            assert steps == []
            
            # Should categorize as INFRASTRUCTURE
            job_type, has_custom_code = exporter._categorize_job(steps)
            assert job_type == 'INFRASTRUCTURE'
            assert has_custom_code is False
    
    def test_job_with_null_datasets(self, temp_db):
        """Test handling of job with NULL datasets column."""
        # Requirements: 6.5
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Add job with NULL datasets
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
            VALUES ('TESTJOB', 'TEST.LIB', 10, NULL)
        """)
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            datasets = exporter._extract_datasets('TESTJOB')
            # Should return empty list, not None
            assert datasets == []
            assert isinstance(datasets, list)
    
    def test_job_with_malformed_datasets_json(self, temp_db):
        """Test handling of job with malformed datasets JSON."""
        # Requirements: 6.5
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Add job with invalid JSON
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines, datasets)
            VALUES ('TESTJOB', 'TEST.LIB', 10, 'invalid json')
        """)
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            datasets = exporter._extract_datasets('TESTJOB')
            # Should return empty list on parse error
            assert datasets == []
            assert isinstance(datasets, list)
    
    def test_self_dependency_removal(self, temp_db):
        """Test that self-dependencies are removed."""
        # Requirements: 5.5
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Add job
        cursor.execute("""
            INSERT INTO inventory_jcl (member_name, library_name, size_lines)
            VALUES ('TESTJOB', 'TEST.LIB', 10)
        """)
        
        # Add self-dependency
        cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES ('TESTJOB', 'JCL', 'TESTJOB', 'JCL', 'CALLS')
        """)
        
        conn.commit()
        conn.close()
        
        with JobExporter(temp_db) as exporter:
            deps = exporter._extract_dependencies('TESTJOB', ['TESTJOB'])
            
            # Self-dependency should be removed
            assert 'TESTJOB' not in deps['mustRunAfter']
            assert 'TESTJOB' not in deps['mustRunBefore']
