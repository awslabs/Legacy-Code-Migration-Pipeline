"""Unit tests for entry point detector."""

import unittest
import sqlite3
import tempfile
import os
from tools.legacy_analyzer.analysis.entry_point_detector import EntryPointDetector
from tools.legacy_analyzer.models.flow import EntryPoint


class TestEntryPointDetector(unittest.TestCase):
    """Test cases for EntryPointDetector class."""
    
    def setUp(self):
        """Set up test database."""
        # Create temporary database
        self.db_fd, self.db_path = tempfile.mkstemp()
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create test tables
        self._create_test_tables()
        self._populate_test_data()
        
        # Create detector
        self.detector = EntryPointDetector(self.conn)
    
    def tearDown(self):
        """Clean up test database."""
        self.conn.close()
        os.close(self.db_fd)
        os.unlink(self.db_path)
    
    def _create_test_tables(self):
        """Create test database tables."""
        # Create inventory_cics table
        self.cursor.execute("""
            CREATE TABLE inventory_cics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name VARCHAR(8) NOT NULL,
                resource_type VARCHAR(20) NOT NULL,
                group_name VARCHAR(8),
                status VARCHAR(20),
                program_name VARCHAR(8),
                dataset_name VARCHAR(44),
                description TEXT,
                language VARCHAR(20)
            )
        """)
        
        # Create artifact_dependencies table
        self.cursor.execute("""
            CREATE TABLE artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name VARCHAR(44) NOT NULL,
                source_artifact_type VARCHAR(20) NOT NULL,
                target_artifact_name VARCHAR(44) NOT NULL,
                target_artifact_type VARCHAR(20) NOT NULL,
                dependency_type VARCHAR(30) NOT NULL
            )
        """)
        
        self.conn.commit()
    
    def _populate_test_data(self):
        """Populate test data."""
        # Add CICS transactions
        cics_data = [
            ('CAUP', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COACTUPC', 'Account Update'),
            ('CMEN', 'TRANSACTION', 'CARDDEMO', 'ENABLED', 'COMENUC', 'Main Menu'),
            ('COLD', 'TRANSACTION', 'CARDDEMO', 'DISABLED', 'COLDPROG', 'Old Transaction'),
            ('CPGM', 'PROGRAM', 'CARDDEMO', 'ENABLED', None, 'Program Definition'),
        ]
        
        for resource_name, resource_type, group_name, status, program_name, description in cics_data:
            self.cursor.execute("""
                INSERT INTO inventory_cics 
                (resource_name, resource_type, group_name, status, program_name, description)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (resource_name, resource_type, group_name, status, program_name, description))
        
        # Add JCL dependencies
        jcl_data = [
            ('DAILYJOB', 'JCL', 'CBACT01C', 'PROGRAM', 'EXEC_PGM'),
            ('MONTHJOB', 'JCL', 'CBACT02C', 'PROGRAM', 'EXEC_PGM'),
            ('DAILYJOB', 'JCL', 'CBACT03C', 'PROGRAM', 'EXEC_PGM'),
        ]
        
        for source, source_type, target, target_type, dep_type in jcl_data:
            self.cursor.execute("""
                INSERT INTO artifact_dependencies 
                (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
                VALUES (?, ?, ?, ?, ?)
            """, (source, source_type, target, target_type, dep_type))
        
        self.conn.commit()
    
    def test_check_tables_exist(self):
        """Test that detector correctly identifies existing tables."""
        self.assertTrue(self.detector._has_cics_table)
        self.assertTrue(self.detector._has_dependencies_table)
    
    def test_get_online_entry_points_enabled_only(self):
        """Test getting ONLINE entry points (enabled only)."""
        entry_points = self.detector.get_online_entry_points(include_disabled=False)
        
        # Should find 2 enabled transactions
        self.assertEqual(len(entry_points), 2)
        
        # Check first entry point
        ep1 = next(ep for ep in entry_points if ep.program_name == 'COACTUPC')
        self.assertEqual(ep1.entry_type, 'ONLINE')
        self.assertEqual(ep1.confidence, 'EXPLICIT')
        self.assertEqual(ep1.source, 'CSD')
        self.assertEqual(ep1.transaction_id, 'CAUP')
        self.assertEqual(ep1.cics_group, 'CARDDEMO')
        self.assertEqual(ep1.status, 'ENABLED')
        self.assertEqual(ep1.description, 'Account Update')
        
        # Check second entry point
        ep2 = next(ep for ep in entry_points if ep.program_name == 'COMENUC')
        self.assertEqual(ep2.transaction_id, 'CMEN')
    
    def test_get_online_entry_points_include_disabled(self):
        """Test getting ONLINE entry points including disabled."""
        entry_points = self.detector.get_online_entry_points(include_disabled=True)
        
        # Should find 3 transactions (including disabled)
        self.assertEqual(len(entry_points), 3)
        
        # Check disabled entry point
        ep_disabled = next(ep for ep in entry_points if ep.program_name == 'COLDPROG')
        self.assertEqual(ep_disabled.status, 'DISABLED')
    
    def test_get_batch_entry_points(self):
        """Test getting BATCH entry points from JCL."""
        entry_points = self.detector.get_batch_entry_points()
        
        # Should find 3 batch programs
        self.assertEqual(len(entry_points), 3)
        
        # Check first entry point
        ep1 = next(ep for ep in entry_points if ep.program_name == 'CBACT01C')
        self.assertEqual(ep1.entry_type, 'BATCH')
        self.assertEqual(ep1.confidence, 'EXPLICIT')
        self.assertEqual(ep1.source, 'JCL')
        self.assertEqual(ep1.jcl_name, 'DAILYJOB')
        self.assertEqual(ep1.status, 'ENABLED')
        
        # Check that CBACT03C also has DAILYJOB as jcl_name
        ep3 = next(ep for ep in entry_points if ep.program_name == 'CBACT03C')
        self.assertEqual(ep3.jcl_name, 'DAILYJOB')
    
    def test_get_inferred_entry_points(self):
        """Test getting INFERRED entry points from code analysis."""
        all_programs = {'PROG1', 'PROG2', 'PROG3', 'PROG4'}
        called_programs = {'PROG2', 'PROG3'}  # PROG1 and PROG4 are not called
        
        entry_points = self.detector.get_inferred_entry_points(
            all_programs,
            called_programs
        )
        
        # Should find 2 inferred entry points
        self.assertEqual(len(entry_points), 2)
        
        # Check that PROG1 and PROG4 are found
        program_names = {ep.program_name for ep in entry_points}
        self.assertEqual(program_names, {'PROG1', 'PROG4'})
        
        # Check properties
        for ep in entry_points:
            self.assertEqual(ep.entry_type, 'INFERRED')
            self.assertEqual(ep.confidence, 'INFERRED')
            self.assertEqual(ep.source, 'CODE_ANALYSIS')
    
    def test_detect_entry_points_priority(self):
        """Test that detect_entry_points respects priority (ONLINE > BATCH > INFERRED)."""
        # Create a scenario where same program appears in multiple sources
        # Add COACTUPC to JCL (it's already in CICS)
        self.cursor.execute("""
            INSERT INTO artifact_dependencies 
            (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type)
            VALUES ('TESTJCL', 'JCL', 'COACTUPC', 'PROGRAM', 'EXEC_PGM')
        """)
        self.conn.commit()
        
        # Recreate detector to pick up new data
        detector = EntryPointDetector(self.conn)
        
        # Set up programs: COACTUPC and COMENUC are in CICS, CBACT01C is in JCL
        # UTILPROG is not in any metadata, so it should be INFERRED
        # SUBPROG is called by others, so it should NOT be an entry point
        all_programs = {'COACTUPC', 'COMENUC', 'CBACT01C', 'UTILPROG', 'SUBPROG'}
        called_programs = {'SUBPROG'}  # SUBPROG is called, so not an entry point
        
        entry_points = detector.detect_entry_points(
            all_programs=all_programs,
            called_programs=called_programs,
            include_disabled=False,
            include_inferred=True
        )
        
        # Get program names for debugging
        program_names = {ep.program_name for ep in entry_points}
        
        # COACTUPC should be ONLINE (highest priority), not BATCH or INFERRED
        ep_coactupc = next(ep for ep in entry_points if ep.program_name == 'COACTUPC')
        self.assertEqual(ep_coactupc.entry_type, 'ONLINE')
        self.assertEqual(ep_coactupc.source, 'CSD')
        
        # CBACT01C should be BATCH (not INFERRED)
        ep_cbact01c = next(ep for ep in entry_points if ep.program_name == 'CBACT01C')
        self.assertEqual(ep_cbact01c.entry_type, 'BATCH')
        self.assertEqual(ep_cbact01c.source, 'JCL')
        
        # UTILPROG should be INFERRED (not in CICS or JCL)
        self.assertIn('UTILPROG', program_names, 
                     f"UTILPROG should be found as INFERRED entry point. Found: {program_names}")
        ep_utilprog = next(ep for ep in entry_points if ep.program_name == 'UTILPROG')
        self.assertEqual(ep_utilprog.entry_type, 'INFERRED')
        self.assertEqual(ep_utilprog.source, 'CODE_ANALYSIS')
        
        # SUBPROG should NOT be an entry point (it's called by others)
        self.assertNotIn('SUBPROG', program_names,
                        "SUBPROG should not be an entry point since it's called by others")
    
    def test_detect_entry_points_no_inferred(self):
        """Test detect_entry_points with include_inferred=False."""
        all_programs = {'COACTUPC', 'COMENUC', 'CBACT01C', 'UTILPROG'}
        called_programs = set()
        
        entry_points = self.detector.detect_entry_points(
            all_programs=all_programs,
            called_programs=called_programs,
            include_disabled=False,
            include_inferred=False  # Don't include inferred
        )
        
        # Should only have ONLINE and BATCH, not INFERRED
        entry_types = {ep.entry_type for ep in entry_points}
        self.assertNotIn('INFERRED', entry_types)
        self.assertIn('ONLINE', entry_types)
        self.assertIn('BATCH', entry_types)
    
    def test_get_entry_point_statistics(self):
        """Test entry point statistics calculation."""
        all_programs = {'COACTUPC', 'COMENUC', 'CBACT01C', 'UTILPROG'}
        called_programs = set()
        
        entry_points = self.detector.detect_entry_points(
            all_programs=all_programs,
            called_programs=called_programs,
            include_disabled=True,  # Include disabled to test status counting
            include_inferred=True
        )
        
        stats = self.detector.get_entry_point_statistics(entry_points)
        
        # Check total
        self.assertGreater(stats['total'], 0)
        
        # Check by_type
        self.assertIn('ONLINE', stats['by_type'])
        self.assertIn('BATCH', stats['by_type'])
        self.assertIn('INFERRED', stats['by_type'])
        
        # Check by_confidence
        self.assertIn('EXPLICIT', stats['by_confidence'])
        self.assertIn('INFERRED', stats['by_confidence'])
        
        # Check by_status
        self.assertIn('ENABLED', stats['by_status'])
        self.assertIn('DISABLED', stats['by_status'])
    
    def test_entry_point_to_dict(self):
        """Test EntryPoint.to_dict() method."""
        entry_point = EntryPoint(
            program_name='TESTPROG',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            transaction_id='TEST',
            cics_group='TESTGRP',
            status='ENABLED',
            description='Test program'
        )
        
        result = entry_point.to_dict()
        
        self.assertEqual(result['program_name'], 'TESTPROG')
        self.assertEqual(result['entry_type'], 'ONLINE')
        self.assertEqual(result['confidence'], 'EXPLICIT')
        self.assertEqual(result['source'], 'CSD')
        self.assertEqual(result['transaction_id'], 'TEST')
        self.assertEqual(result['cics_group'], 'TESTGRP')
        self.assertEqual(result['status'], 'ENABLED')
        self.assertEqual(result['description'], 'Test program')
    
    def test_entry_point_helper_methods(self):
        """Test EntryPoint helper methods."""
        ep_explicit = EntryPoint(
            program_name='PROG1',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            status='ENABLED'
        )
        
        self.assertTrue(ep_explicit.is_explicit())
        self.assertFalse(ep_explicit.is_inferred())
        self.assertTrue(ep_explicit.is_enabled())
        
        ep_inferred = EntryPoint(
            program_name='PROG2',
            entry_type='INFERRED',
            confidence='INFERRED',
            source='CODE_ANALYSIS'
        )
        
        self.assertFalse(ep_inferred.is_explicit())
        self.assertTrue(ep_inferred.is_inferred())
        self.assertTrue(ep_inferred.is_enabled())  # No status means enabled
        
        ep_disabled = EntryPoint(
            program_name='PROG3',
            entry_type='ONLINE',
            confidence='EXPLICIT',
            source='CSD',
            status='DISABLED'
        )
        
        self.assertFalse(ep_disabled.is_enabled())
    
    def test_missing_cics_table(self):
        """Test graceful handling when inventory_cics table doesn't exist."""
        # Create new database without CICS table
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        
        try:
            detector = EntryPointDetector(conn)
            
            # Should not have CICS table
            self.assertFalse(detector._has_cics_table)
            
            # Should return empty list, not error
            entry_points = detector.get_online_entry_points()
            self.assertEqual(len(entry_points), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)
    
    def test_missing_dependencies_table(self):
        """Test graceful handling when artifact_dependencies table doesn't exist."""
        # Create new database without dependencies table
        db_fd, db_path = tempfile.mkstemp()
        conn = sqlite3.connect(db_path)
        
        try:
            detector = EntryPointDetector(conn)
            
            # Should not have dependencies table
            self.assertFalse(detector._has_dependencies_table)
            
            # Should return empty list, not error
            entry_points = detector.get_batch_entry_points()
            self.assertEqual(len(entry_points), 0)
            
        finally:
            conn.close()
            os.close(db_fd)
            os.unlink(db_path)


if __name__ == '__main__':
    unittest.main()
