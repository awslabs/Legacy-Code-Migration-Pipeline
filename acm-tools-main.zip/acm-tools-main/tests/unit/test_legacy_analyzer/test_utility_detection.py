"""
Unit tests for utility program detection.

Tests the UtilityDetector class and detect_utility_programs function.
"""

import pytest
import sqlite3
from datetime import datetime
from tools.legacy_analyzer.migration.utility_detector import (
    UtilityDetector,
    detect_utility_programs
)
from tools.legacy_analyzer.migration.schema import MigrationFlowSchema


@pytest.fixture
def db_connection():
    """Create in-memory database with schema."""
    conn = sqlite3.connect(':memory:')
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    yield conn
    conn.close()


@pytest.fixture
def sample_flows():
    """Create sample flows for testing."""
    return {
        'FLOW_PAYROLL1': {
            'flow_id': 'FLOW_PAYROLL1',
            'entry_program': 'PAYROLL1',
            'start_program': 'PAYROLL1',
            'programs': ['PAYROLL1', 'PAYCALC', 'UTIL_COMMON', 'UTIL_DB']
        },
        'FLOW_BILLING1': {
            'flow_id': 'FLOW_BILLING1',
            'entry_program': 'BILLING1',
            'start_program': 'BILLING1',
            'programs': ['BILLING1', 'BILLCALC', 'UTIL_COMMON', 'UTIL_DB']
        },
        'FLOW_ACCT1': {
            'flow_id': 'FLOW_ACCT1',
            'entry_program': 'ACCT1',
            'start_program': 'ACCT1',
            'programs': ['ACCT1', 'ACCTCALC', 'UTIL_COMMON']
        },
        'FLOW_REPORT1': {
            'flow_id': 'FLOW_REPORT1',
            'entry_program': 'REPORT1',
            'start_program': 'REPORT1',
            'programs': ['REPORT1', 'RPTGEN', 'UTIL_COMMON', 'UTIL_DB']
        },
        'FLOW_BATCH1': {
            'flow_id': 'FLOW_BATCH1',
            'entry_program': 'BATCH1',
            'start_program': 'BATCH1',
            'programs': ['BATCH1', 'BATCHPROC', 'UTIL_COMMON', 'UTIL_DB']
        },
        'FLOW_ONLINE1': {
            'flow_id': 'FLOW_ONLINE1',
            'entry_program': 'ONLINE1',
            'start_program': 'ONLINE1',
            'programs': ['ONLINE1', 'ONLINEPROC', 'UTIL_COMMON']
        }
    }


class TestUtilityDetector:
    """Test UtilityDetector class."""
    
    def test_initialization(self, db_connection):
        """Test UtilityDetector initialization."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        assert detector.conn == db_connection
        assert detector.call_threshold == 5
    
    def test_count_program_calls(self, db_connection, sample_flows):
        """Test counting program calls across flows."""
        detector = UtilityDetector(db_connection)
        counts = detector._count_program_calls(sample_flows)
        
        # UTIL_COMMON appears in 6 flows (not counting as entry point)
        assert counts['UTIL_COMMON'] == 6
        
        # UTIL_DB appears in 4 flows
        assert counts['UTIL_DB'] == 4
        
        # Entry point programs should have 0 count
        assert counts.get('PAYROLL1', 0) == 0
        assert counts.get('BILLING1', 0) == 0
    
    def test_track_program_flows(self, db_connection, sample_flows):
        """Test tracking which flows use each program."""
        detector = UtilityDetector(db_connection)
        program_flows = detector._track_program_flows(sample_flows)
        
        # UTIL_COMMON is used by 6 flows
        assert len(program_flows['UTIL_COMMON']) == 6
        assert 'FLOW_PAYROLL1' in program_flows['UTIL_COMMON']
        assert 'FLOW_BILLING1' in program_flows['UTIL_COMMON']
        
        # UTIL_DB is used by 4 flows
        assert len(program_flows['UTIL_DB']) == 4
        
        # Entry point programs should not be tracked
        assert 'PAYROLL1' not in program_flows or len(program_flows['PAYROLL1']) == 0
    
    def test_matches_pattern(self, db_connection):
        """Test pattern matching for utility programs."""
        detector = UtilityDetector(db_connection)
        
        # Test wildcard patterns
        assert detector._matches_pattern('UTIL_COMMON', 'UTIL*')
        assert detector._matches_pattern('UTIL_DB', 'UTIL*')
        assert not detector._matches_pattern('PAYROLL1', 'UTIL*')
        
        # Test case insensitivity
        assert detector._matches_pattern('util_common', 'UTIL*')
        assert detector._matches_pattern('UTIL_COMMON', 'util*')
        
        # Test question mark wildcard
        assert detector._matches_pattern('UTIL1', 'UTIL?')
        assert not detector._matches_pattern('UTIL12', 'UTIL?')
    
    def test_detect_utilities_by_call_threshold(self, db_connection, sample_flows):
        """Test detecting utilities by call frequency threshold."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(sample_flows)
        
        # UTIL_COMMON should be detected (6 calls >= 5 threshold)
        assert 'UTIL_COMMON' in utilities
        assert utilities['UTIL_COMMON']['is_utility'] is True
        assert utilities['UTIL_COMMON']['call_count'] == 6
        assert utilities['UTIL_COMMON']['shared_by_flow_count'] == 6
        
        # UTIL_DB should not be detected (4 calls < 5 threshold)
        assert 'UTIL_DB' not in utilities
    
    def test_detect_utilities_by_naming_pattern(self, db_connection, sample_flows):
        """Test detecting utilities by naming patterns."""
        detector = UtilityDetector(db_connection, call_threshold=10)  # High threshold
        utilities = detector.detect_utility_programs(
            sample_flows,
            utility_patterns=['UTIL*', 'COMMON*']
        )
        
        # Both UTIL_COMMON and UTIL_DB should be detected by pattern
        assert 'UTIL_COMMON' in utilities
        assert utilities['UTIL_COMMON']['naming_pattern'] == 'UTIL*'
        
        assert 'UTIL_DB' in utilities
        assert utilities['UTIL_DB']['naming_pattern'] == 'UTIL*'
    
    def test_detect_utilities_combined_criteria(self, db_connection, sample_flows):
        """Test detecting utilities with both threshold and patterns."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(
            sample_flows,
            utility_patterns=['UTIL*']
        )
        
        # UTIL_COMMON: detected by both threshold (6 >= 5) and pattern
        assert 'UTIL_COMMON' in utilities
        assert utilities['UTIL_COMMON']['call_count'] == 6
        
        # UTIL_DB: detected by pattern only (4 < 5)
        assert 'UTIL_DB' in utilities
        assert utilities['UTIL_DB']['call_count'] == 4
        assert utilities['UTIL_DB']['naming_pattern'] == 'UTIL*'
    
    def test_write_utility_metadata(self, db_connection, sample_flows):
        """Test writing utility metadata to database."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(
            sample_flows,
            utility_patterns=['UTIL*']
        )
        
        # Write to database
        detector.write_utility_metadata(utilities)
        
        # Verify data was written
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM program_metadata WHERE is_utility = 1")
        count = cursor.fetchone()[0]
        assert count == 2  # UTIL_COMMON and UTIL_DB
        
        # Verify specific program
        cursor.execute("""
            SELECT call_count, classification, shared_by_flow_count
            FROM program_metadata
            WHERE program_name = 'UTIL_COMMON'
        """)
        row = cursor.fetchone()
        assert row[0] == 6  # call_count
        assert row[1] == 'UTILITY'  # classification
        assert row[2] == 6  # shared_by_flow_count
    
    def test_write_utility_metadata_update(self, db_connection, sample_flows):
        """Test updating existing utility metadata."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(
            sample_flows,
            utility_patterns=['UTIL*']
        )
        
        # Write initial data
        detector.write_utility_metadata(utilities)
        
        # Modify and write again
        utilities['UTIL_COMMON']['call_count'] = 10
        detector.write_utility_metadata(utilities)
        
        # Verify update
        cursor = db_connection.cursor()
        cursor.execute("""
            SELECT call_count FROM program_metadata WHERE program_name = 'UTIL_COMMON'
        """)
        count = cursor.fetchone()[0]
        assert count == 10
    
    def test_get_utility_programs(self, db_connection, sample_flows):
        """Test retrieving utility programs from database."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(
            sample_flows,
            utility_patterns=['UTIL*']
        )
        
        # Write to database
        detector.write_utility_metadata(utilities)
        
        # Retrieve from database
        retrieved = detector.get_utility_programs()
        
        assert len(retrieved) == 2
        assert 'UTIL_COMMON' in retrieved
        assert 'UTIL_DB' in retrieved
        assert retrieved['UTIL_COMMON']['is_utility'] is True
    
    def test_is_utility_program(self, db_connection, sample_flows):
        """Test checking if a program is a utility."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(
            sample_flows,
            utility_patterns=['UTIL*']
        )
        
        # Write to database
        detector.write_utility_metadata(utilities)
        
        # Check utility programs
        assert detector.is_utility_program('UTIL_COMMON') is True
        assert detector.is_utility_program('UTIL_DB') is True
        
        # Check non-utility programs
        assert detector.is_utility_program('PAYROLL1') is False
        assert detector.is_utility_program('NONEXISTENT') is False
    
    def test_get_shared_flows(self, db_connection, sample_flows):
        """Test getting flows that share a utility program."""
        # First, populate flow_scope table
        cursor = db_connection.cursor()
        for flow_id, flow in sample_flows.items():
            for program in flow['programs']:
                cursor.execute("""
                    INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
                    VALUES (?, 'PROGRAM', ?)
                """, (flow_id, program))
        db_connection.commit()
        
        detector = UtilityDetector(db_connection)
        
        # Get flows sharing UTIL_COMMON
        shared_flows = detector.get_shared_flows('UTIL_COMMON')
        assert len(shared_flows) == 6
        assert 'FLOW_PAYROLL1' in shared_flows
        assert 'FLOW_BILLING1' in shared_flows
        
        # Get flows sharing UTIL_DB
        shared_flows = detector.get_shared_flows('UTIL_DB')
        assert len(shared_flows) == 4
    
    def test_format_extended_scope(self, db_connection, sample_flows):
        """Test formatting programs with utility metadata."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(
            sample_flows,
            utility_patterns=['UTIL*']
        )
        
        # Write to database
        detector.write_utility_metadata(utilities)
        
        # Populate flow_scope for get_shared_flows
        cursor = db_connection.cursor()
        for flow_id, flow in sample_flows.items():
            for program in flow['programs']:
                cursor.execute("""
                    INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
                    VALUES (?, 'PROGRAM', ?)
                """, (flow_id, program))
        db_connection.commit()
        
        # Format extended scope
        programs = ['PAYROLL1', 'PAYCALC', 'UTIL_COMMON', 'UTIL_DB']
        extended = detector.format_extended_scope(programs)
        
        assert len(extended) == 4
        
        # Check non-utility program
        payroll = next(p for p in extended if p['name'] == 'PAYROLL1')
        assert payroll['is_utility'] is False
        
        # Check utility program
        util_common = next(p for p in extended if p['name'] == 'UTIL_COMMON')
        assert util_common['is_utility'] is True
        assert util_common['call_count'] == 6
        assert len(util_common['shared_by_flows']) == 6
        assert util_common['classification'] == 'UTILITY'
    
    def test_empty_flows(self, db_connection):
        """Test with empty flows dictionary."""
        detector = UtilityDetector(db_connection)
        utilities = detector.detect_utility_programs({})
        assert len(utilities) == 0
    
    def test_no_utility_patterns(self, db_connection, sample_flows):
        """Test detection with no utility patterns."""
        detector = UtilityDetector(db_connection, call_threshold=5)
        utilities = detector.detect_utility_programs(sample_flows, utility_patterns=None)
        
        # Only UTIL_COMMON should be detected by threshold
        assert 'UTIL_COMMON' in utilities
        assert utilities['UTIL_COMMON']['naming_pattern'] is None
    
    def test_high_threshold_no_matches(self, db_connection, sample_flows):
        """Test with threshold higher than any call count."""
        detector = UtilityDetector(db_connection, call_threshold=100)
        utilities = detector.detect_utility_programs(sample_flows)
        
        # No programs should meet the threshold
        assert len(utilities) == 0


class TestDetectUtilityProgramsFunction:
    """Test the convenience function detect_utility_programs."""
    
    def test_convenience_function(self, db_connection, sample_flows):
        """Test the convenience function works correctly."""
        utilities = detect_utility_programs(
            db_connection,
            sample_flows,
            utility_patterns=['UTIL*'],
            call_threshold=5
        )
        
        assert 'UTIL_COMMON' in utilities
        assert 'UTIL_DB' in utilities
        assert utilities['UTIL_COMMON']['call_count'] == 6
    
    def test_convenience_function_default_threshold(self, db_connection, sample_flows):
        """Test convenience function with default threshold."""
        utilities = detect_utility_programs(
            db_connection,
            sample_flows,
            utility_patterns=['UTIL*']
        )
        
        # Default threshold is 5
        assert 'UTIL_COMMON' in utilities
        assert 'UTIL_DB' in utilities


class TestEdgeCases:
    """Test edge cases and error conditions."""
    
    def test_program_as_entry_point_in_one_flow(self, db_connection):
        """Test program that is entry point in one flow but called in others."""
        flows = {
            'FLOW_UTIL1': {
                'flow_id': 'FLOW_UTIL1',
                'entry_program': 'UTIL_PROG',
                'start_program': 'UTIL_PROG',
                'programs': ['UTIL_PROG', 'HELPER1']
            },
            'FLOW_APP1': {
                'flow_id': 'FLOW_APP1',
                'entry_program': 'APP1',
                'start_program': 'APP1',
                'programs': ['APP1', 'UTIL_PROG']
            },
            'FLOW_APP2': {
                'flow_id': 'FLOW_APP2',
                'entry_program': 'APP2',
                'start_program': 'APP2',
                'programs': ['APP2', 'UTIL_PROG']
            }
        }
        
        detector = UtilityDetector(db_connection, call_threshold=2)
        utilities = detector.detect_utility_programs(flows)
        
        # UTIL_PROG is called by 2 flows (not counting its own entry point flow)
        assert 'UTIL_PROG' in utilities
        assert utilities['UTIL_PROG']['call_count'] == 2
    
    def test_multiple_patterns_match(self, db_connection):
        """Test program matching multiple patterns."""
        flows = {
            'FLOW_APP1': {
                'flow_id': 'FLOW_APP1',
                'entry_program': 'APP1',
                'start_program': 'APP1',
                'programs': ['APP1', 'COMMON_UTIL']
            }
        }
        
        detector = UtilityDetector(db_connection, call_threshold=10)
        utilities = detector.detect_utility_programs(
            flows,
            utility_patterns=['COMMON*', 'UTIL*', '*UTIL']
        )
        
        # Should match first pattern
        assert 'COMMON_UTIL' in utilities
        assert utilities['COMMON_UTIL']['naming_pattern'] == 'COMMON*'
    
    def test_special_characters_in_program_names(self, db_connection):
        """Test programs with special characters."""
        flows = {
            'FLOW_APP1': {
                'flow_id': 'FLOW_APP1',
                'entry_program': 'APP1',
                'start_program': 'APP1',
                'programs': ['APP1', 'UTIL-PROG', 'UTIL$PROG']
            }
        }
        
        detector = UtilityDetector(db_connection)
        utilities = detector.detect_utility_programs(
            flows,
            utility_patterns=['UTIL*']
        )
        
        # Both should match pattern
        assert 'UTIL-PROG' in utilities
        assert 'UTIL$PROG' in utilities
