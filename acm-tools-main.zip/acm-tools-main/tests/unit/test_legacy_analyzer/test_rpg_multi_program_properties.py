#!/usr/bin/env python3
"""
Property-based tests for RPG multi-program parsing.

**Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (RPG)**
**Validates: Requirements 1.1**

These tests use Hypothesis to verify correctness properties across
many randomly generated RPG source files with multiple programs.
"""

import os
import sys
import tempfile
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hypothesis import given, strategies as st, settings, assume
from tools.legacy_analyzer.parsers.rpg_parser import RPGDependencyParser
from tools.legacy_analyzer.analysis.program_boundary_detector import RPGProgramBoundaryDetector
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Strategy for generating valid RPG program names
rpg_program_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@$_',
    min_size=1,
    max_size=44
).filter(lambda x: x.strip() and not x.startswith('-') and x.isalnum())

# Strategy for generating RPG H-spec lines
rpg_h_spec_lines = st.builds(
    lambda name, options: f"H {options} MAIN({name})" if name else f"H {options}",
    name=st.one_of(st.none(), rpg_program_names),
    options=st.sampled_from(['NOMAIN', 'DFTACTGRP(*NO)', 'ACTGRP(*NEW)', ''])
)

# Strategy for generating RPG F-spec lines
rpg_f_spec_lines = st.builds(
    lambda filename: f"F{filename:<10} IF   E           DISK",
    filename=rpg_program_names.filter(lambda x: len(x) <= 10)
)

# Strategy for generating RPG procedure definitions
rpg_procedure_definitions = st.builds(
    lambda proc_name: f"DCL-PR {proc_name};\nEND-PR;\nDCL-PROC {proc_name};\nEND-PROC;",
    proc_name=rpg_program_names
)

# Strategy for generating RPG CALL statements
rpg_call_statements = st.builds(
    lambda prog_name: f"CALL '{prog_name}';",
    prog_name=rpg_program_names
)

# Strategy for generating RPG /COPY statements
rpg_copy_statements = st.builds(
    lambda copybook: f"/COPY {copybook}",
    copybook=rpg_program_names
)

# Strategy for generating multi-program RPG source
rpg_multi_program_source = st.builds(
    lambda programs: '\n'.join(programs),
    programs=st.lists(
        st.one_of(
            rpg_h_spec_lines,
            rpg_f_spec_lines,
            rpg_procedure_definitions,
            rpg_call_statements,
            rpg_copy_statements,
            st.just("**FREE"),
            st.just("// Comment line"),
            st.just("DCL-S MyVar CHAR(10);"),
            st.just("MyVar = 'TEST';")
        ),
        min_size=3,
        max_size=20
    )
)


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (RPG)**
# **Validates: Requirements 1.1**
@settings(max_examples=100)
@given(
    rpg_source=rpg_multi_program_source
)
def test_property_rpg_multi_program_parsing_accuracy(rpg_source):
    """
    Property 1: Multi-program file parsing accuracy (RPG)
    
    For any RPG source file containing multiple programs, parsing should identify 
    each individual program with correct boundaries and track dependencies 
    separately for each program.
    """
    parser = RPGDependencyParser()
    detector = RPGProgramBoundaryDetector()
    
    # Ensure source has some content
    lines = rpg_source.splitlines()
    assume(len(lines) >= 1)
    assume(any(line.strip() for line in lines))  # At least one non-empty line
    
    # Test program boundary detection
    programs = detector.detect_boundaries(rpg_source)
    
    # Property: All detected programs should have valid RPG characteristics
    for program in programs:
        assert program.language == "RPG", \
            f"Program '{program.program_name}' should have language 'RPG', got '{program.language}'"
        
        assert program.program_type in [ProgramType.MAIN, ProgramType.PROCEDURE], \
            f"Program '{program.program_name}' should be MAIN or PROCEDURE, got {program.program_type}"
        
        assert program.start_line >= 1, \
            f"Program '{program.program_name}' should have start_line >= 1, got {program.start_line}"
        
        assert program.end_line >= program.start_line, \
            f"Program '{program.program_name}' should have end_line >= start_line"
        
        assert len(program.entry_points) > 0, \
            f"Program '{program.program_name}' should have at least one entry point"
        
        assert program.program_name in program.entry_points, \
            f"Program '{program.program_name}' should include itself in entry points"
    
    # Property: Programs should not overlap
    for i, prog1 in enumerate(programs):
        for prog2 in programs[i+1:]:
            assert not prog1.overlaps_with(prog2), \
                f"RPG programs '{prog1.program_name}' and '{prog2.program_name}' should not overlap"
    
    # Property: If H-spec lines exist, should detect at least one program
    h_spec_lines = [line for line in lines if line.strip().upper().startswith('H')]
    if h_spec_lines:
        assert len(programs) > 0, \
            "RPG source with H-spec should detect at least one program"
    
    # Test enhanced parser functionality
    if hasattr(parser, 'parse_with_program_detection'):
        result = parser.parse_with_program_detection(rpg_source)
        
        # Property: Parse result should contain program information
        assert result.language == "RPG", \
            f"Parse result should have language 'RPG', got '{result.language}'"
        
        assert len(result.programs) >= 0, \
            "Parse result should contain programs list"
        
        # Property: Dependencies should be tracked per program
        for program_name, deps in result.dependencies.items():
            assert isinstance(deps, list), \
                f"Dependencies for program '{program_name}' should be a list"
            
            # All dependency items should be strings
            for dep in deps:
                assert isinstance(dep, str), \
                    f"Dependency '{dep}' should be a string"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (RPG)**
# **Validates: Requirements 1.1**
@settings(max_examples=100)
@given(
    h_spec_count=st.integers(min_value=1, max_value=5),
    program_names=st.lists(rpg_program_names, min_size=1, max_size=5)
)
def test_property_rpg_multiple_h_specs_detection(h_spec_count, program_names):
    """
    Property 1: Multi-program file parsing accuracy (RPG) - Multiple H-specs
    
    For any RPG source file with multiple H-spec lines, each should be detected
    as a separate program with correct boundaries.
    """
    assume(len(program_names) >= h_spec_count)
    
    detector = RPGProgramBoundaryDetector()
    
    # Create source with multiple H-specs
    source_lines = []
    for i in range(h_spec_count):
        if i < len(program_names):
            source_lines.append(f"H MAIN({program_names[i]})")
        else:
            source_lines.append("H NOMAIN")
        
        # Add some content after each H-spec
        source_lines.extend([
            f"F FILE{i+1}    IF   E           DISK",
            f"DCL-S Var{i+1} CHAR(10);",
            f"Var{i+1} = 'TEST{i+1}';",
            ""
        ])
    
    rpg_source = '\n'.join(source_lines)
    programs = detector.detect_boundaries(rpg_source)
    
    # Property: Should detect at least as many programs as H-specs
    assert len(programs) >= h_spec_count, \
        f"Should detect at least {h_spec_count} programs for {h_spec_count} H-specs, got {len(programs)}"
    
    # Property: Each program should have distinct boundaries
    program_ranges = [(p.start_line, p.end_line) for p in programs]
    assert len(set(program_ranges)) == len(program_ranges), \
        "All programs should have distinct line ranges"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (RPG)**
# **Validates: Requirements 1.1**
@settings(max_examples=100)
@given(
    main_program=rpg_program_names,
    procedures=st.lists(rpg_program_names, min_size=0, max_size=3),
    calls=st.lists(rpg_program_names, min_size=0, max_size=3),
    copybooks=st.lists(rpg_program_names, min_size=0, max_size=3)
)
def test_property_rpg_dependency_separation_per_program(main_program, procedures, calls, copybooks):
    """
    Property 1: Multi-program file parsing accuracy (RPG) - Dependency separation
    
    For any RPG source file with multiple programs, dependencies should be 
    tracked separately for each program based on their line boundaries.
    """
    parser = RPGDependencyParser()
    
    # Create RPG source with main program and procedures
    source_lines = [
        f"H MAIN({main_program})",
        "**FREE"
    ]
    
    # Add copybooks to main program
    for copybook in copybooks:
        source_lines.append(f"/COPY {copybook}")
    
    # Add calls to main program
    for call in calls:
        source_lines.append(f"CALL '{call}';")
    
    # Add procedures
    for proc in procedures:
        source_lines.extend([
            f"DCL-PR {proc};",
            "END-PR;",
            f"DCL-PROC {proc};",
            f"  // Procedure {proc} body",
            "END-PROC;"
        ])
    
    rpg_source = '\n'.join(source_lines)
    
    # Test traditional parsing
    traditional_result = parser.parse(rpg_source)
    
    # Property: Traditional parsing should find all dependencies
    all_expected_calls = set(calls)
    all_expected_copybooks = set(copybooks)
    
    found_calls = set(traditional_result.get('calls', []))
    found_copybooks = set(traditional_result.get('copybooks', []))
    
    assert all_expected_calls.issubset(found_calls), \
        f"Traditional parsing should find all calls: expected {all_expected_calls}, found {found_calls}"
    
    assert all_expected_copybooks.issubset(found_copybooks), \
        f"Traditional parsing should find all copybooks: expected {all_expected_copybooks}, found {found_copybooks}"
    
    # Test program-level parsing if available
    if hasattr(parser, 'parse_with_program_detection'):
        program_result = parser.parse_with_program_detection(rpg_source)
        
        # Property: Should detect main program
        main_programs = [p for p in program_result.programs if p.program_type == ProgramType.MAIN]
        assert len(main_programs) >= 1, \
            "Should detect at least one main program"
        
        # Property: Dependencies should be associated with programs
        assert isinstance(program_result.dependencies, dict), \
            "Program-level dependencies should be a dictionary"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (RPG)**
# **Validates: Requirements 1.1**
@settings(max_examples=100)
@given(
    rpg_source=rpg_multi_program_source
)
def test_property_rpg_parsing_consistency(rpg_source):
    """
    Property 1: Multi-program file parsing accuracy (RPG) - Consistency
    
    For any RPG source file, running parsing multiple times should produce 
    identical results.
    """
    parser = RPGDependencyParser()
    detector = RPGProgramBoundaryDetector()
    
    # Ensure source has some content
    lines = rpg_source.splitlines()
    assume(len(lines) >= 1)
    assume(any(line.strip() for line in lines))
    
    # Run traditional parsing multiple times
    traditional_results = []
    for _ in range(3):
        result = parser.parse(rpg_source)
        traditional_results.append(result)
    
    # Property: Traditional parsing should be consistent
    first_result = traditional_results[0]
    for i, result in enumerate(traditional_results[1:], start=1):
        for key in first_result:
            assert set(result.get(key, [])) == set(first_result.get(key, [])), \
                f"Traditional parsing run {i} differs from run 0 for key '{key}'"
    
    # Run boundary detection multiple times
    boundary_results = []
    for _ in range(3):
        programs = detector.detect_boundaries(rpg_source)
        boundary_results.append(programs)
    
    # Property: Boundary detection should be consistent
    first_boundaries = boundary_results[0]
    for i, boundaries in enumerate(boundary_results[1:], start=1):
        assert len(boundaries) == len(first_boundaries), \
            f"Boundary detection run {i} found {len(boundaries)} programs, but run 0 found {len(first_boundaries)}"
        
        # Compare programs by name and boundaries
        first_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in first_boundaries}
        result_dict = {p.program_name: (p.start_line, p.end_line, p.program_type) for p in boundaries}
        
        assert first_dict == result_dict, \
            f"Boundary detection run {i} produced different results than run 0"


# **Feature: program-level-dependency-tracking, Property 1: Multi-program file parsing accuracy (RPG)**
# **Validates: Requirements 1.1**
@settings(max_examples=100)
@given(
    file_path=st.text(
        alphabet='abcdefghijklmnopqrstuvwxyz0123456789_-.',
        min_size=5,
        max_size=50
    ).map(lambda x: f"/path/to/{x}.rpg")
)
def test_property_rpg_file_path_handling(file_path):
    """
    Property 1: Multi-program file parsing accuracy (RPG) - File path handling
    
    For any RPG source file with a file path, program boundaries should include
    the correct file path information.
    """
    detector = RPGProgramBoundaryDetector()
    
    # Create simple RPG source
    rpg_source = """H MAIN(TESTPROG)
**FREE
DCL-S MyVar CHAR(10);
MyVar = 'TEST';"""
    
    # Detect boundaries with file path
    programs = detector.detect_boundaries(rpg_source, file_path)
    
    # Property: All programs should have the correct file path
    for program in programs:
        assert program.file_path == file_path, \
            f"Program '{program.program_name}' should have file_path '{file_path}', got '{program.file_path}'"
    
    # Property: Parse result should include file path
    result = detector.parse_with_program_detection(rpg_source, file_path)
    assert result.file_path == file_path, \
        f"Parse result should have file_path '{file_path}', got '{result.file_path}'"


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])