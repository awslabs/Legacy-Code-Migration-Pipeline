"""Unit tests for CICS data models."""

import pytest
from tools.legacy_analyzer.models.cics import (
    CICSResource,
    CICSTransaction,
    CICSProgram,
    CICSFile,
    CICSMapset
)


class TestCICSResource:
    """Test CICSResource base class."""
    
    def test_create_cics_resource(self):
        """Test creating a basic CICS resource."""
        resource = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED'
        )
        
        assert resource.resource_name == 'TEST'
        assert resource.resource_type == 'PROGRAM'
        assert resource.group_name == 'TESTGRP'
        assert resource.status == 'ENABLED'
        assert resource.source_file is None
        assert resource.line_number is None
    
    def test_cics_resource_with_source_info(self):
        """Test CICS resource with source file information."""
        resource = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED',
            source_file='test.csd',
            line_number=42
        )
        
        assert resource.source_file == 'test.csd'
        assert resource.line_number == 42
    
    def test_cics_resource_to_csv_row(self):
        """Test converting CICS resource to CSV row."""
        resource = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED'
        )
        
        csv_row = resource.to_csv_row()
        
        assert csv_row['resource_name'] == 'TEST'
        assert csv_row['resource_type'] == 'PROGRAM'
        assert csv_row['group_name'] == 'TESTGRP'
        assert csv_row['status'] == 'ENABLED'
        assert csv_row['program_name'] == ''
        assert csv_row['dataset_name'] == ''
        assert csv_row['description'] == ''
    
    def test_cics_resource_str(self):
        """Test string representation of CICS resource."""
        resource = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED'
        )
        
        assert str(resource) == 'PROGRAM(TEST) in TESTGRP'
    
    def test_cics_resource_equality(self):
        """Test CICS resource equality."""
        resource1 = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED'
        )
        resource2 = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='DISABLED'
        )
        resource3 = CICSResource(
            resource_name='OTHER',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED'
        )
        
        assert resource1 == resource2  # Same name and type
        assert resource1 != resource3  # Different name
    
    def test_cics_resource_hash(self):
        """Test CICS resource hashing."""
        resource1 = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED'
        )
        resource2 = CICSResource(
            resource_name='TEST',
            resource_type='PROGRAM',
            group_name='TESTGRP',
            status='ENABLED'
        )
        
        assert hash(resource1) == hash(resource2)
        
        # Can be used in sets
        resource_set = {resource1, resource2}
        assert len(resource_set) == 1


class TestCICSTransaction:
    """Test CICSTransaction model."""
    
    def test_create_cics_transaction(self):
        """Test creating a CICS transaction."""
        transaction = CICSTransaction(
            transaction_id='CAUP',
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert transaction.transaction_id == 'CAUP'
        assert transaction.program_name == 'COACTUPC'
        assert transaction.group_name == 'CARDDEMO'
        assert transaction.status == 'ENABLED'
        assert transaction.resource_name == 'CAUP'
        assert transaction.resource_type == 'TRANSACTION'
    
    def test_cics_transaction_with_description(self):
        """Test CICS transaction with description."""
        transaction = CICSTransaction(
            transaction_id='CAUP',
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED',
            description='Account Update Transaction',
            priority=5
        )
        
        assert transaction.description == 'Account Update Transaction'
        assert transaction.priority == 5
    
    def test_cics_transaction_to_csv_row(self):
        """Test converting CICS transaction to CSV row."""
        transaction = CICSTransaction(
            transaction_id='CAUP',
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED',
            description='Account Update'
        )
        
        csv_row = transaction.to_csv_row()
        
        assert csv_row['resource_name'] == 'CAUP'
        assert csv_row['resource_type'] == 'TRANSACTION'
        assert csv_row['group_name'] == 'CARDDEMO'
        assert csv_row['status'] == 'ENABLED'
        assert csv_row['program_name'] == 'COACTUPC'
        assert csv_row['dataset_name'] == ''
        assert csv_row['description'] == 'Account Update'
    
    def test_cics_transaction_str(self):
        """Test string representation of CICS transaction."""
        transaction = CICSTransaction(
            transaction_id='CAUP',
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert str(transaction) == 'TRANSACTION(CAUP) -> COACTUPC'
    
    def test_cics_transaction_default_status(self):
        """Test CICS transaction with default status."""
        transaction = CICSTransaction(
            transaction_id='CAUP',
            program_name='COACTUPC',
            group_name='CARDDEMO'
        )
        
        assert transaction.status == 'ENABLED'


class TestCICSProgram:
    """Test CICSProgram model."""
    
    def test_create_cics_program(self):
        """Test creating a CICS program."""
        program = CICSProgram(
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert program.program_name == 'COACTUPC'
        assert program.group_name == 'CARDDEMO'
        assert program.status == 'ENABLED'
        assert program.resource_name == 'COACTUPC'
        assert program.resource_type == 'PROGRAM'
    
    def test_cics_program_with_language(self):
        """Test CICS program with language."""
        program = CICSProgram(
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED',
            language='COBOL',
            transaction_id='CAUP',
            concurrency='QUASIRENT'
        )
        
        assert program.language == 'COBOL'
        assert program.transaction_id == 'CAUP'
        assert program.concurrency == 'QUASIRENT'
    
    def test_cics_program_to_csv_row(self):
        """Test converting CICS program to CSV row."""
        program = CICSProgram(
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED',
            language='COBOL'
        )
        
        csv_row = program.to_csv_row()
        
        assert csv_row['resource_name'] == 'COACTUPC'
        assert csv_row['resource_type'] == 'PROGRAM'
        assert csv_row['group_name'] == 'CARDDEMO'
        assert csv_row['status'] == 'ENABLED'
        assert csv_row['program_name'] == ''
        assert csv_row['dataset_name'] == ''
    
    def test_cics_program_str(self):
        """Test string representation of CICS program."""
        program = CICSProgram(
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED',
            language='COBOL'
        )
        
        assert str(program) == 'PROGRAM(COACTUPC) (COBOL)'
    
    def test_cics_program_str_without_language(self):
        """Test string representation of CICS program without language."""
        program = CICSProgram(
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert str(program) == 'PROGRAM(COACTUPC)'


class TestCICSFile:
    """Test CICSFile model."""
    
    def test_create_cics_file(self):
        """Test creating a CICS file."""
        file = CICSFile(
            file_name='ACCTDAT',
            dataset_name='AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert file.file_name == 'ACCTDAT'
        assert file.dataset_name == 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS'
        assert file.group_name == 'CARDDEMO'
        assert file.status == 'ENABLED'
        assert file.resource_name == 'ACCTDAT'
        assert file.resource_type == 'FILE'
    
    def test_cics_file_with_type(self):
        """Test CICS file with file type."""
        file = CICSFile(
            file_name='ACCTDAT',
            dataset_name='AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS',
            group_name='CARDDEMO',
            status='ENABLED',
            file_type='VSAM'
        )
        
        assert file.file_type == 'VSAM'
    
    def test_cics_file_to_csv_row(self):
        """Test converting CICS file to CSV row."""
        file = CICSFile(
            file_name='ACCTDAT',
            dataset_name='AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        csv_row = file.to_csv_row()
        
        assert csv_row['resource_name'] == 'ACCTDAT'
        assert csv_row['resource_type'] == 'FILE'
        assert csv_row['group_name'] == 'CARDDEMO'
        assert csv_row['status'] == 'ENABLED'
        assert csv_row['program_name'] == ''
        assert csv_row['dataset_name'] == 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS'
    
    def test_cics_file_str(self):
        """Test string representation of CICS file."""
        file = CICSFile(
            file_name='ACCTDAT',
            dataset_name='AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert str(file) == 'FILE(ACCTDAT) -> AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS'


class TestCICSMapset:
    """Test CICSMapset model."""
    
    def test_create_cics_mapset(self):
        """Test creating a CICS mapset."""
        mapset = CICSMapset(
            mapset_name='COACTUP',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert mapset.mapset_name == 'COACTUP'
        assert mapset.group_name == 'CARDDEMO'
        assert mapset.status == 'ENABLED'
        assert mapset.resource_name == 'COACTUP'
        assert mapset.resource_type == 'MAPSET'
    
    def test_cics_mapset_with_description(self):
        """Test CICS mapset with description."""
        mapset = CICSMapset(
            mapset_name='COACTUP',
            group_name='CARDDEMO',
            status='ENABLED',
            description='Account Update Map'
        )
        
        assert mapset.description == 'Account Update Map'
    
    def test_cics_mapset_to_csv_row(self):
        """Test converting CICS mapset to CSV row."""
        mapset = CICSMapset(
            mapset_name='COACTUP',
            group_name='CARDDEMO',
            status='ENABLED',
            description='Account Update Map'
        )
        
        csv_row = mapset.to_csv_row()
        
        assert csv_row['resource_name'] == 'COACTUP'
        assert csv_row['resource_type'] == 'MAPSET'
        assert csv_row['group_name'] == 'CARDDEMO'
        assert csv_row['status'] == 'ENABLED'
        assert csv_row['program_name'] == ''
        assert csv_row['dataset_name'] == ''
        assert csv_row['description'] == 'Account Update Map'
    
    def test_cics_mapset_str(self):
        """Test string representation of CICS mapset."""
        mapset = CICSMapset(
            mapset_name='COACTUP',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        assert str(mapset) == 'MAPSET(COACTUP)'


class TestCICSModelIntegration:
    """Test integration between CICS models."""
    
    def test_transaction_and_program_relationship(self):
        """Test relationship between transaction and program."""
        transaction = CICSTransaction(
            transaction_id='CAUP',
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        program = CICSProgram(
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED',
            transaction_id='CAUP'
        )
        
        # Verify they reference each other
        assert transaction.program_name == program.program_name
        assert program.transaction_id == transaction.transaction_id
    
    def test_csv_row_format_consistency(self):
        """Test that all models produce consistent CSV row format."""
        transaction = CICSTransaction(
            transaction_id='CAUP',
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        program = CICSProgram(
            program_name='COACTUPC',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        file = CICSFile(
            file_name='ACCTDAT',
            dataset_name='AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        mapset = CICSMapset(
            mapset_name='COACTUP',
            group_name='CARDDEMO',
            status='ENABLED'
        )
        
        # All should have the same keys
        trans_row = transaction.to_csv_row()
        prog_row = program.to_csv_row()
        file_row = file.to_csv_row()
        mapset_row = mapset.to_csv_row()
        
        expected_keys = {
            'resource_name', 'resource_type', 'group_name', 
            'status', 'program_name', 'dataset_name', 'description'
        }
        
        assert set(trans_row.keys()) == expected_keys
        assert set(prog_row.keys()) == expected_keys
        assert set(file_row.keys()) == expected_keys
        assert set(mapset_row.keys()) == expected_keys
    
    def test_disabled_resources(self):
        """Test creating disabled CICS resources."""
        transaction = CICSTransaction(
            transaction_id='OLD1',
            program_name='OLDPROG',
            group_name='LEGACY',
            status='DISABLED'
        )
        
        assert transaction.status == 'DISABLED'
        
        csv_row = transaction.to_csv_row()
        assert csv_row['status'] == 'DISABLED'
