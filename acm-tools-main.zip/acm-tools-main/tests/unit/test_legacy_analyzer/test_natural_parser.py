"""Tests for Natural dependency parser."""

import pytest
import os
from tools.legacy_analyzer.parsers.natural_parser import NaturalDependencyParser


class TestNaturalParser:
    """Test suite for Natural dependency parser."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = NaturalDependencyParser()
    
    def test_parse_callnat_statements(self):
        """Test parsing CALLNAT statements."""
        source = """
        DEFINE DATA
        LOCAL
        1 #PARAM (A10)
        END-DEFINE
        *
        CALLNAT 'AJY00N21' #PARAM
        CALLNAT "GET-EMPL" #PARAM
        END
        """
        
        result = self.parser.parse(source)
        
        assert 'AJY00N21' in result['callnat']
        assert 'GET-EMPL' in result['callnat']
        assert len(result['callnat']) == 2
    
    def test_parse_fetch_statements(self):
        """Test parsing FETCH statements."""
        source = """
        DEFINE DATA
        END-DEFINE
        *
        FETCH 'LOGIN'
        FETCH RETURN 'MG-PDF'
        END
        """
        
        result = self.parser.parse(source)
        
        assert 'LOGIN' in result['fetch']
        assert 'MG-PDF' in result['fetch']
        assert len(result['fetch']) == 2
    
    def test_parse_include_statements(self):
        """Test parsing INCLUDE statements."""
        source = """
        DEFINE DATA
        END-DEFINE
        *
        INCLUDE ERRHANDL
        INCLUDE AJY00C01
        END
        """
        
        result = self.parser.parse(source)
        
        assert 'ERRHANDL' in result['includes']
        assert 'AJY00C01' in result['includes']
        assert len(result['includes']) == 2
    
    def test_parse_using_statements(self):
        """Test parsing USING statements."""
        source = """
        DEFINE DATA
        GLOBAL USING AJY00G00
        LOCAL USING AJY00L00
        LOCAL USING AJY00A20
        END-DEFINE
        END
        """
        
        result = self.parser.parse(source)
        
        assert 'AJY00G00' in result['using']
        assert 'AJY00L00' in result['using']
        assert 'AJY00A20' in result['using']
        assert len(result['using']) == 3
    
    def test_parse_define_data_global(self):
        """Test detecting DEFINE DATA GLOBAL."""
        source_global = """
        DEFINE DATA GLOBAL
        1 #VARIABLE (A10)
        END-DEFINE
        """
        
        source_local = """
        DEFINE DATA
        LOCAL
        1 #VARIABLE (A10)
        END-DEFINE
        """
        
        result_global = self.parser.parse(source_global)
        result_local = self.parser.parse(source_local)
        
        assert result_global['is_global_data_area'] is True
        assert result_local['is_global_data_area'] is False
    
    def test_parse_view_of_statements(self):
        """Test parsing VIEW OF statements."""
        source = """
        DEFINE DATA
        LOCAL
        1 EMPLOYEE VIEW OF EMPLOYEES
          2 PERSONNEL-ID (A8)
          2 NAME (A20)
        1 EMPL1 VIEW OF EMPLOYEES
        END-DEFINE
        END
        """
        
        result = self.parser.parse(source)
        
        assert 'EMPLOYEES' in result['view_of']
        assert len(result['view_of']) == 1  # Should deduplicate
    
    def test_parse_read_statements(self):
        """Test parsing READ and FIND statements with VIEW resolution."""
        source = """
        DEFINE DATA
        END-DEFINE
        *
        READ EMPLOYEE WITH NAME FROM #FROM TO #TO
        FIND EMPL1 WITH PERSONNEL-ID = #ID
        END
        """
        
        result = self.parser.parse(source)
        
        # After enhancement: reads are resolved into view_of
        assert 'EMPLOYEE' in result['view_of']
        assert 'EMPL1' in result['view_of']
        assert len(result['reads']) == 0  # Empty - resolved to view_of
    
    def test_extract_header_metadata(self):
        """Test extracting metadata from Natural source header."""
        source = """
        * >Natural Source Header 000000
        * :Mode S
        * :CP windows-1252
        * :LineIncrement 10
        * <Natural Source Header
        DEFINE DATA
        END-DEFINE
        END
        """
        
        result = self.parser.parse(source)
        metadata = result['metadata']
        
        assert metadata['mode'] == 'S'
        assert metadata['code_page'] == 'windows-1252'
        assert metadata['line_increment'] == '10'
    
    def test_extract_header_metadata_empty_cp(self):
        """Test extracting metadata when CP is empty."""
        source = """
        * >Natural Source Header 000000
        * :Mode R
        * :CP
        * :LineIncrement 10
        * <Natural Source Header
        DEFINE DATA
        END-DEFINE
        END
        """
        
        result = self.parser.parse(source)
        metadata = result['metadata']
        
        assert metadata['mode'] == 'R'
        assert metadata['code_page'] is None
        assert metadata['line_increment'] == '10'
    
    def test_normalize_source_removes_comments(self):
        """Test that source normalization removes comments."""
        source = """
        * This is a comment line
        DEFINE DATA
        LOCAL
        1 #VAR (A10) /* Inline comment
        END-DEFINE
        /** Documentation comment
        CALLNAT 'PROG1'
        END
        """
        
        normalized = self.parser._normalize_source(source)
        
        # Comments should be removed
        assert '* This is a comment line' not in normalized
        assert 'DEFINE DATA' in normalized
        assert 'CALLNAT' in normalized
    
    def test_get_supported_patterns(self):
        """Test getting supported patterns."""
        patterns = self.parser.get_supported_patterns()
        
        assert 'CALLNAT' in patterns
        assert 'FETCH' in patterns
        assert 'INCLUDE' in patterns
        assert 'USING' in patterns
        assert 'VIEW OF' in patterns
        assert 'READ/FIND/HISTOGRAM' in patterns
        assert 'VIEW DEFINITIONS' in patterns
        assert 'NSD FILE HEADERS' in patterns
    
    def test_get_supported_extensions(self):
        """Test getting supported file extensions."""
        extensions = self.parser.get_supported_extensions()
        
        assert '.NSP' in extensions
        assert '.NSN' in extensions
        assert '.NSC' in extensions
        assert '.NSL' in extensions
        assert '.NSG' in extensions
        assert '.NSD' in extensions
        assert '.NSA' in extensions
        assert '.NS8' in extensions
        assert len(extensions) == 8
    
    def test_parse_real_natural_program(self):
        """Test parsing a real Natural program file."""
        # Test with AJY00P20.NSP
        test_file = 'examples/code/natural/n-one/TRAVEL/SRC/AJY00P20.NSP'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        result = self.parser.parse_file(test_file)
        
        # Should find CALLNAT to AJY00N21
        assert 'AJY00N21' in result['callnat']
        
        # Should find USING statements
        assert 'AJY00G00' in result['using']
        assert 'AJY00A20' in result['using']
        
        # Should extract metadata
        assert result['metadata']['mode'] == 'R'
        assert result['metadata']['code_page'] == 'windows-1252'
        assert result['metadata']['line_increment'] == '10'
    
    def test_parse_real_natural_subprogram(self):
        """Test parsing a real Natural subprogram file."""
        # Test with GET-EMPL.NSN
        test_file = 'examples/code/natural/n-one/TRAVEL/SRC/GET-EMPL.NSN'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        result = self.parser.parse_file(test_file)
        
        # Should find VIEW OF EMPLOYEES
        assert 'EMPLOYEES' in result['view_of']
        
        # After enhancement: reads are resolved into view_of
        assert len(result['reads']) == 0  # Empty - resolved to view_of
        
        # Should extract metadata
        assert result['metadata']['mode'] == 'S'
    
    def test_parse_real_natural_copycode(self):
        """Test parsing a real Natural copycode file."""
        # Test with ERRHANDL.NSC
        test_file = 'examples/code/natural/n-one/TRAVEL/SRC/ERRHANDL.NSC'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        result = self.parser.parse_file(test_file)
        
        # Should find FETCH 'LOGIN'
        assert 'LOGIN' in result['fetch']
        
        # Should extract metadata
        assert result['metadata']['mode'] == 'S'
        assert result['metadata']['code_page'] == 'windows-1252'
    
    def test_parse_real_natural_global_data_area(self):
        """Test parsing a real Natural global data area file."""
        # Test with AJY00G00.NSG
        test_file = 'examples/code/natural/n-one/TRAVEL/SRC/AJY00G00.NSG'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        result = self.parser.parse_file(test_file)
        
        # Should be identified as global data area
        assert result['is_global_data_area'] is True
        
        # Should extract metadata
        assert result['metadata']['mode'] == 'S'
        assert result['metadata']['code_page'] == 'windows-1252'
    
    def test_parse_real_natural_local_data_area(self):
        """Test parsing a real Natural local data area file."""
        # Test with AJY00L00.NSL
        test_file = 'examples/code/natural/n-one/TRAVEL/SRC/AJY00L00.NSL'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        result = self.parser.parse_file(test_file)
        
        # Should NOT be identified as global data area
        assert result['is_global_data_area'] is False
        
        # Should extract metadata
        assert result['metadata']['mode'] == 'R'
        assert result['metadata']['code_page'] == 'windows-1252'
    
    def test_parse_complex_natural_program(self):
        """Test parsing a complex Natural program with multiple dependencies."""
        # Test with MG-SUPP.NSP
        test_file = 'examples/code/natural/n-one/TRAVEL/SRC/MG-SUPP.NSP'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        result = self.parser.parse_file(test_file)
        
        # Should find multiple USING statements
        assert 'AJY00G00' in result['using']
        assert 'AJY00A31' in result['using']
        assert 'AJY00L31' in result['using']
        
        # Should find INCLUDE statements
        assert 'AJY00C01' in result['includes']
        assert 'ERRHANDL' in result['includes']
        
        # Should find FETCH statements
        assert 'MG-PDF' in result['fetch']
        assert 'LOGIN' in result['fetch']
        
        # After enhancement: EMPL1 is resolved to view_of (or stays if can't resolve)
        # EMPL1 is defined in AJY00L31 LDA, so it appears in view_of
        assert 'EMPL1' in result['view_of']  # Can't resolve cross-file, so stays as-is
    
    def test_parse_natural_with_callnat_and_fetch(self):
        """Test parsing Natural program with both CALLNAT and FETCH."""
        # Test with LOGIN.NSP
        test_file = 'examples/code/natural/n-one/TRAVEL/SRC/LOGIN.NSP'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        result = self.parser.parse_file(test_file)
        
        # Should find CALLNAT statements
        assert 'GET-EMPL' in result['callnat']
        assert 'GET-STAT' in result['callnat']
        
        # Should find FETCH statements
        assert 'MG-SUPP' in result['fetch']
        assert 'TR-SUPP' in result['fetch']
        
        # Should find INCLUDE statement
        assert 'ERRHANDL' in result['includes']
        
        # Should find USING statement
        assert 'AJY00G00' in result['using']
    
    def test_case_insensitive_parsing(self):
        """Test that parsing is case-insensitive."""
        source_upper = """
        CALLNAT 'PROG1'
        FETCH 'PROG2'
        INCLUDE COPY1
        """
        
        source_lower = """
        callnat 'PROG1'
        fetch 'PROG2'
        include COPY1
        """
        
        result_upper = self.parser.parse(source_upper)
        result_lower = self.parser.parse(source_lower)
        
        assert result_upper['callnat'] == result_lower['callnat']
        assert result_upper['fetch'] == result_lower['fetch']
        assert result_upper['includes'] == result_lower['includes']
    
    def test_empty_source(self):
        """Test parsing empty source code."""
        result = self.parser.parse("")
        
        assert result['callnat'] == []
        assert result['fetch'] == []
        assert result['includes'] == []
        assert result['using'] == []
        assert result['is_global_data_area'] is False
        assert result['view_of'] == []
        assert result['reads'] == []
    
    def test_source_with_no_dependencies(self):
        """Test parsing source with no dependencies."""
        source = """
        DEFINE DATA
        LOCAL
        1 #VAR (A10)
        END-DEFINE
        *
        WRITE 'Hello World'
        END
        """
        
        result = self.parser.parse(source)
        
        assert result['callnat'] == []
        assert result['fetch'] == []
        assert result['includes'] == []
        assert result['using'] == []
        assert result['view_of'] == []
        assert result['reads'] == []


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
