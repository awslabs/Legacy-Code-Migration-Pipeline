"""Property-based tests for call graph program representation.

**Feature: program-level-dependency-tracking, Property 10: Call graph program representation**
**Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5**

Tests that call graph generation creates program-level nodes with accurate call relationships
and complete file location metadata.
"""

import pytest
from hypothesis import given, settings, strategies as st, HealthCheck
from typing import List, Dict, Any
import tempfile
import os

from tools.legacy_analyzer.analysis.call_graph import CallGraphBuilder
from tools.legacy_analyzer.models.dependency import Dependency, DependencyType
from tools.legacy_analyzer.models.program_boundary import ProgramBoundary, ProgramType


# Hypothesis strategies for generating test data
program_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    min_size=3,
    max_size=8
).filter(lambda x: x.strip())

file_paths = st.builds(
    lambda base, ext: f"src/{base}.{ext}",
    base=st.text(alphabet='abcdefghijklmnopqrstuvwxyz0123456789_', min_size=3, max_size=10),
    ext=st.sampled_from(['cbl', 'pli', 'nat', 'rex', 'rpg', 'asm'])
)

languages = st.sampled_from(['COBOL', 'PL/I', 'NATURAL', 'REXX', 'RPG', 'ASSEMBLER'])

program_types = st.sampled_from([ProgramType.MAIN, ProgramType.PROCEDURE, ProgramType.CSECT, ProgramType.SUBPROGRAM])

dependency_types = st.sampled_from([
    DependencyType.CALL,
    DependencyType.CICS_LINK,
    DependencyType.CICS_START,
    DependencyType.EXEC_PGM
])


def program_boundary_strategy():
    """Generate a ProgramBoundary for testing."""
    return st.builds(
        ProgramBoundary,
        program_name=program_names,
        start_line=st.integers(min_value=1, max_value=50),
        end_line=st.integers(min_value=51, max_value=100),
        program_type=program_types,
        language=languages,
        entry_points=st.lists(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ', min_size=2, max_size=6), min_size=0, max_size=2),
        file_path=file_paths,
        confidence_level=st.floats(min_value=0.8, max_value=1.0)
    )


def program_dependency_strategy():
    """Generate a program-level Dependency for testing."""
    return st.builds(
        Dependency,
        source_artifact=program_names,
        source_type=st.just('PROGRAM'),
        target_artifact=program_names,
        target_type=st.just('PROGRAM'),
        dependency_type=dependency_types,
        line_number=st.integers(min_value=1, max_value=100)
    )


def generate_program_file_mapping(programs: List[ProgramBoundary]) -> Dict[str, Dict]:
    """Generate program-to-file mapping from program boundaries."""
    mapping = {}
    for program in programs:
        mapping[program.program_name] = {
            'file_path': program.file_path,
            'start_line': program.start_line,
            'end_line': program.end_line,
            'program_type': program.program_type.value,
            'language': program.language,
            'entry_points': program.entry_points
        }
    return mapping


class TestCallGraphProgramRepresentation:
    """Property-based tests for call graph program representation."""
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=2, max_size=10, unique_by=lambda x: x.program_name),
        dependencies=st.lists(program_dependency_strategy(), min_size=1, max_size=20)
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[
            HealthCheck.function_scoped_fixture,
            HealthCheck.too_slow,
            HealthCheck.filter_too_much
        ]
    )
    def test_property_10_call_graph_creates_program_level_nodes(self, programs, dependencies):
        """
        **Feature: program-level-dependency-tracking, Property 10: Call graph program representation**
        **Validates: Requirements 5.1, 5.2**
        
        For any call graph generation, nodes should represent individual programs rather than files.
        """
        # Ensure dependencies reference existing programs
        program_names_set = {p.program_name for p in programs}
        valid_dependencies = []
        
        for dep in dependencies:
            if dep.source_artifact in program_names_set and dep.target_artifact in program_names_set:
                valid_dependencies.append(dep)
        
        if not valid_dependencies:
            # Create at least one valid dependency
            if len(programs) >= 2:
                dep = Dependency(
                    source_artifact=programs[0].program_name,
                    source_type='PROGRAM',
                    target_artifact=programs[1].program_name,
                    target_type='PROGRAM',
                    dependency_type=DependencyType.CALL,
                    line_number=10
                )
                valid_dependencies = [dep]
        
        # Generate program-file mapping
        program_file_mapping = generate_program_file_mapping(programs)
        
        # Build call graph
        builder = CallGraphBuilder(valid_dependencies, program_file_mapping)
        graph = builder.build_full_call_graph()
        
        # Verify nodes represent individual programs, not files
        for node in graph.nodes:
            # Node should be a program name, not a file path
            assert '/' not in node or '\\' not in node, f"Node {node} appears to be a file path, not a program name"
            assert node in program_names_set, f"Node {node} should be a program name from the input programs"
        
        # Verify all programs with dependencies are represented as nodes
        programs_with_deps = set()
        for dep in valid_dependencies:
            programs_with_deps.add(dep.source_artifact)
            programs_with_deps.add(dep.target_artifact)
        
        for program in programs_with_deps:
            assert program in graph.nodes, f"Program {program} with dependencies should be a node in the graph"
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=3, max_size=8, unique_by=lambda x: x.program_name),
        dependencies=st.lists(program_dependency_strategy(), min_size=2, max_size=15)
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[
            HealthCheck.function_scoped_fixture,
            HealthCheck.too_slow,
            HealthCheck.filter_too_much
        ]
    )
    def test_property_10_call_graph_connects_specific_programs(self, programs, dependencies):
        """
        **Feature: program-level-dependency-tracking, Property 10: Call graph program representation**
        **Validates: Requirements 5.2**
        
        For any call graph generation, edges should connect specific programs with accurate call relationships.
        """
        # Ensure dependencies reference existing programs
        program_names_set = {p.program_name for p in programs}
        valid_dependencies = []
        
        for dep in dependencies:
            if (dep.source_artifact in program_names_set and 
                dep.target_artifact in program_names_set and
                dep.source_artifact != dep.target_artifact):  # Avoid self-loops
                valid_dependencies.append(dep)
        
        if not valid_dependencies:
            return  # Skip if no valid dependencies
        
        # Generate program-file mapping
        program_file_mapping = generate_program_file_mapping(programs)
        
        # Build call graph
        builder = CallGraphBuilder(valid_dependencies, program_file_mapping)
        graph = builder.build_full_call_graph()
        
        # Verify edges connect specific programs accurately
        for caller, callee in graph.edges:
            # Both caller and callee should be program names
            assert caller in program_names_set, f"Caller {caller} should be a program name"
            assert callee in program_names_set, f"Callee {callee} should be a program name"
            
            # There should be a corresponding dependency
            found_dependency = False
            for dep in valid_dependencies:
                if dep.source_artifact == caller and dep.target_artifact == callee:
                    found_dependency = True
                    break
            
            assert found_dependency, f"Edge ({caller}, {callee}) should have a corresponding dependency"
        
        # Verify all valid dependencies are represented as edges
        for dep in valid_dependencies:
            edge = (dep.source_artifact, dep.target_artifact)
            assert edge in graph.edges, f"Dependency from {dep.source_artifact} to {dep.target_artifact} should be an edge"
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=2, max_size=6, unique_by=lambda x: x.program_name),
        dependencies=st.lists(program_dependency_strategy(), min_size=1, max_size=10)
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[
            HealthCheck.function_scoped_fixture,
            HealthCheck.too_slow,
            HealthCheck.filter_too_much
        ]
    )
    def test_property_10_call_graph_includes_file_location_metadata(self, programs, dependencies):
        """
        **Feature: program-level-dependency-tracking, Property 10: Call graph program representation**
        **Validates: Requirements 5.3**
        
        For any call graph generation, nodes should include file location information for each program.
        """
        # Ensure dependencies reference existing programs
        program_names_set = {p.program_name for p in programs}
        valid_dependencies = []
        
        for dep in dependencies:
            if dep.source_artifact in program_names_set and dep.target_artifact in program_names_set:
                valid_dependencies.append(dep)
        
        if not valid_dependencies:
            # Create at least one valid dependency
            if len(programs) >= 2:
                dep = Dependency(
                    source_artifact=programs[0].program_name,
                    source_type='PROGRAM',
                    target_artifact=programs[1].program_name,
                    target_type='PROGRAM',
                    dependency_type=DependencyType.CALL,
                    line_number=10
                )
                valid_dependencies = [dep]
        
        # Generate program-file mapping
        program_file_mapping = generate_program_file_mapping(programs)
        
        # Build call graph
        builder = CallGraphBuilder(valid_dependencies, program_file_mapping)
        graph = builder.build_full_call_graph()
        
        # Verify file location metadata is included for each node
        for node in graph.nodes:
            metadata = graph.get_node_metadata(node)
            
            # Should have file location information
            assert 'file_path' in metadata, f"Node {node} should have file_path metadata"
            assert 'start_line' in metadata, f"Node {node} should have start_line metadata"
            assert 'end_line' in metadata, f"Node {node} should have end_line metadata"
            assert 'program_type' in metadata, f"Node {node} should have program_type metadata"
            assert 'language' in metadata, f"Node {node} should have language metadata"
            
            # If program exists in our mapping, verify metadata matches
            if node in program_file_mapping:
                expected = program_file_mapping[node]
                assert metadata['file_path'] == expected['file_path'], f"File path metadata mismatch for {node}"
                assert metadata['start_line'] == expected['start_line'], f"Start line metadata mismatch for {node}"
                assert metadata['end_line'] == expected['end_line'], f"End line metadata mismatch for {node}"
                assert metadata['program_type'] == expected['program_type'], f"Program type metadata mismatch for {node}"
                assert metadata['language'] == expected['language'], f"Language metadata mismatch for {node}"
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=3, max_size=8, unique_by=lambda x: x.program_name),
        dependencies=st.lists(program_dependency_strategy(), min_size=1, max_size=12)
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[
            HealthCheck.function_scoped_fixture,
            HealthCheck.too_slow,
            HealthCheck.filter_too_much
        ]
    )
    def test_property_10_call_graph_represents_multi_program_files_separately(self, programs, dependencies):
        """
        **Feature: program-level-dependency-tracking, Property 10: Call graph program representation**
        **Validates: Requirements 5.4**
        
        For any call graph generation, all programs from multi-program files should be represented as separate entities.
        """
        # Create multi-program files by assigning multiple programs to same file
        if len(programs) >= 3:
            # Assign first 3 programs to the same file
            shared_file = programs[0].file_path
            for i in range(3):
                programs[i].file_path = shared_file
        
        # Ensure dependencies reference existing programs
        program_names_set = {p.program_name for p in programs}
        valid_dependencies = []
        
        for dep in dependencies:
            if dep.source_artifact in program_names_set and dep.target_artifact in program_names_set:
                valid_dependencies.append(dep)
        
        if not valid_dependencies:
            # Create dependencies between programs in the same file
            if len(programs) >= 2:
                dep = Dependency(
                    source_artifact=programs[0].program_name,
                    source_type='PROGRAM',
                    target_artifact=programs[1].program_name,
                    target_type='PROGRAM',
                    dependency_type=DependencyType.CALL,
                    line_number=10
                )
                valid_dependencies = [dep]
        
        # Generate program-file mapping
        program_file_mapping = generate_program_file_mapping(programs)
        
        # Build call graph
        builder = CallGraphBuilder(valid_dependencies, program_file_mapping)
        graph = builder.build_full_call_graph()
        
        # Group programs by file
        programs_by_file = {}
        for program in programs:
            file_path = program.file_path
            if file_path not in programs_by_file:
                programs_by_file[file_path] = []
            programs_by_file[file_path].append(program.program_name)
        
        # Verify that programs from multi-program files are separate entities
        for file_path, file_programs in programs_by_file.items():
            if len(file_programs) > 1:  # Multi-program file
                # All programs should be separate nodes
                for program_name in file_programs:
                    if program_name in {dep.source_artifact for dep in valid_dependencies} or \
                       program_name in {dep.target_artifact for dep in valid_dependencies}:
                        assert program_name in graph.nodes, f"Program {program_name} from multi-program file should be a separate node"
                
                # Verify they have the same file path but are distinct entities
                file_programs_in_graph = [p for p in file_programs if p in graph.nodes]
                if len(file_programs_in_graph) > 1:
                    for program in file_programs_in_graph:
                        metadata = graph.get_node_metadata(program)
                        assert metadata.get('file_path') == file_path, f"Program {program} should have correct file path"
                    
                    # Verify they are distinct nodes (not merged)
                    assert len(set(file_programs_in_graph)) == len(file_programs_in_graph), \
                        "Programs from same file should be distinct nodes"
    
    @given(
        programs=st.lists(program_boundary_strategy(), min_size=2, max_size=6, unique_by=lambda x: x.program_name),
        dependencies=st.lists(program_dependency_strategy(), min_size=1, max_size=10)
    )
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[
            HealthCheck.function_scoped_fixture,
            HealthCheck.too_slow,
            HealthCheck.filter_too_much
        ]
    )
    def test_property_10_call_graph_provides_program_to_file_mapping(self, programs, dependencies):
        """
        **Feature: program-level-dependency-tracking, Property 10: Call graph program representation**
        **Validates: Requirements 5.5**
        
        For any call graph generation, program-to-file mapping information should be provided for traceability.
        """
        # Ensure dependencies reference existing programs
        program_names_set = {p.program_name for p in programs}
        valid_dependencies = []
        
        for dep in dependencies:
            if dep.source_artifact in program_names_set and dep.target_artifact in program_names_set:
                valid_dependencies.append(dep)
        
        if not valid_dependencies:
            # Create at least one valid dependency
            if len(programs) >= 2:
                dep = Dependency(
                    source_artifact=programs[0].program_name,
                    source_type='PROGRAM',
                    target_artifact=programs[1].program_name,
                    target_type='PROGRAM',
                    dependency_type=DependencyType.CALL,
                    line_number=10
                )
                valid_dependencies = [dep]
        
        # Generate program-file mapping
        program_file_mapping = generate_program_file_mapping(programs)
        
        # Build call graph
        builder = CallGraphBuilder(valid_dependencies, program_file_mapping)
        graph = builder.build_full_call_graph()
        
        # Test export program-to-file mapping
        exported_mapping = builder.export_program_to_file_mapping()
        
        # Verify mapping is available and accurate
        assert isinstance(exported_mapping, dict), "Exported mapping should be a dictionary"
        
        for program_name in program_names_set:
            if program_name in exported_mapping:
                mapping = exported_mapping[program_name]
                assert 'file_path' in mapping, f"Mapping for {program_name} should include file_path"
                
                # Find original program
                original_program = next((p for p in programs if p.program_name == program_name), None)
                if original_program:
                    assert mapping['file_path'] == original_program.file_path, \
                        f"File path mapping for {program_name} should match original"
        
        # Test graph serialization includes mapping
        graph_dict = graph.to_dict()
        assert 'program_to_file_mapping' in graph_dict, "Graph serialization should include program-to-file mapping"
        
        # Verify mapping in serialized graph
        serialized_mapping = graph_dict['program_to_file_mapping']
        for node in graph.nodes:
            if node in program_file_mapping:
                expected_file = program_file_mapping[node]['file_path']
                if node in serialized_mapping:
                    assert serialized_mapping[node] == expected_file, \
                        f"Serialized mapping for {node} should match expected file path"
        
        # Test utility methods
        for program in programs:
            program_name = program.program_name
            file_path = program.file_path
            
            # Test get_file_for_program
            result_file = builder.get_file_for_program(program_name)
            if result_file is not None:
                assert result_file == file_path, f"get_file_for_program should return correct file for {program_name}"
            
            # Test get_programs_in_file
            programs_in_file = builder.get_programs_in_file(file_path)
            if programs_in_file:
                # Should include this program if it has dependencies
                if (program_name in {dep.source_artifact for dep in valid_dependencies} or 
                    program_name in {dep.target_artifact for dep in valid_dependencies}):
                    assert program_name in programs_in_file, \
                        f"get_programs_in_file should include {program_name} for file {file_path}"