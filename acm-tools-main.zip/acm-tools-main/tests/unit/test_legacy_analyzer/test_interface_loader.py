"""
Unit Tests for External Interface Loader

This module contains unit tests for the ExternalInterfaceLoader class,
validating JSON/CSV loading, format detection, and database operations.
"""

import pytest
import sqlite3
import tempfile
import json
import csv
from pathlib import Path

from tools.legacy_analyzer.migration.interface_schema import InterfaceSchemaManager
from tools.legacy_analyzer.migration.interface_loader import (
    ExternalInterfaceLoader,
    ExternalInterfaceLoaderError
)


@pytest.fixture
def db_connection():
    """Create a temporary database with schema."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
        db_path = tmp_db.name
    
    conn = sqlite3.connect(db_path)
    schema_manager = InterfaceSchemaManager(conn)
    schema_manager.create_tables()
    
    yield conn
    
    conn.close()
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def loader(db_connection):
    """Create an ExternalInterfaceLoader instance."""
    return ExternalInterfaceLoader(db_connection)


class TestLoadJson:
    """Tests for load_json() method."""
    
    def test_load_json_with_valid_inbound(self, loader):
        """Test loading valid JSON with inbound interfaces."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    'target_program': 'PROG1',
                    'dependency_type': 'PROGRAM_CALL',
                    'system': 'System A',
                    'description': 'Test interface'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            result = loader.load_json(json_path)
            
            assert 'inbound' in result
            assert len(result['inbound']) == 1
            assert result['inbound'][0]['source_name'] == 'EXTERNAL_A'
            assert result['inbound'][0]['target_program'] == 'PROG1'
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_json_with_valid_outbound(self, loader):
        """Test loading valid JSON with outbound interfaces."""
        data = {
            'outbound': [
                {
                    'program_name': 'UTIL_LIB',
                    'reason': 'configured',
                    'description': 'Utility library'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            result = loader.load_json(json_path)
            
            assert 'outbound' in result
            assert len(result['outbound']) == 1
            assert result['outbound'][0]['program_name'] == 'UTIL_LIB'
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_json_with_combined_format(self, loader):
        """Test loading JSON with both inbound and outbound."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    'target_program': 'PROG1',
                    'dependency_type': 'PROGRAM_CALL'
                }
            ],
            'outbound': [
                {
                    'program_name': 'UTIL_LIB',
                    'reason': 'configured'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            result = loader.load_json(json_path)
            
            assert 'inbound' in result
            assert 'outbound' in result
            assert len(result['inbound']) == 1
            assert len(result['outbound']) == 1
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_json_invalid_format(self, loader):
        """Test loading invalid JSON format."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write("not valid json")
            json_path = f.name
        
        try:
            with pytest.raises(ExternalInterfaceLoaderError, match="Invalid JSON"):
                loader.load_json(json_path)
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_json_missing_keys(self, loader):
        """Test loading JSON without inbound/outbound keys returns empty result."""
        data = {'other_key': 'value'}
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            result = loader.load_json(json_path)
            # Should return empty dict when no inbound/outbound keys
            assert result == {}
        finally:
            Path(json_path).unlink(missing_ok=True)


class TestLoadCsv:
    """Tests for load_csv() method."""
    
    def test_load_csv_with_valid_inbound(self, loader):
        """Test loading valid CSV with inbound interfaces."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='_inbound.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'source_name', 'target_program', 'dependency_type', 'system', 'description'
            ])
            writer.writeheader()
            writer.writerow({
                'source_name': 'EXTERNAL_A',
                'target_program': 'PROG1',
                'dependency_type': 'PROGRAM_CALL',
                'system': 'System A',
                'description': 'Test'
            })
            csv_path = f.name
        
        try:
            result = loader.load_csv(csv_path)
            
            assert 'inbound' in result
            assert len(result['inbound']) == 1
            assert result['inbound'][0]['source_name'] == 'EXTERNAL_A'
            
        finally:
            Path(csv_path).unlink(missing_ok=True)
    
    def test_load_csv_with_valid_outbound(self, loader):
        """Test loading valid CSV with outbound interfaces."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='_outbound.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['program_name', 'reason', 'description'])
            writer.writeheader()
            writer.writerow({
                'program_name': 'UTIL_LIB',
                'reason': 'configured',
                'description': 'Utility'
            })
            csv_path = f.name
        
        try:
            result = loader.load_csv(csv_path)
            
            assert 'outbound' in result
            assert len(result['outbound']) == 1
            assert result['outbound'][0]['program_name'] == 'UTIL_LIB'
            
        finally:
            Path(csv_path).unlink(missing_ok=True)
    
    def test_load_csv_auto_detect_type(self, loader):
        """Test CSV type auto-detection from filename."""
        # Test inbound detection
        with tempfile.NamedTemporaryFile(mode='w', suffix='_inbound_interfaces.csv', 
                                        delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['source_name', 'target_program', 'dependency_type'])
            writer.writeheader()
            writer.writerow({
                'source_name': 'EXT',
                'target_program': 'PROG',
                'dependency_type': 'CALL'
            })
            csv_path = f.name
        
        try:
            result = loader.load_csv(csv_path)
            assert 'inbound' in result
        finally:
            Path(csv_path).unlink(missing_ok=True)
    
    def test_load_csv_explicit_type(self, loader):
        """Test CSV loading with explicit interface type."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['program_name'])
            writer.writeheader()
            writer.writerow({'program_name': 'PROG1'})
            csv_path = f.name
        
        try:
            result = loader.load_csv(csv_path, interface_type='outbound')
            assert 'outbound' in result
        finally:
            Path(csv_path).unlink(missing_ok=True)
    
    def test_load_csv_cannot_detect_type(self, loader):
        """Test CSV loading fails when type cannot be detected."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['field'])
            writer.writeheader()
            csv_path = f.name
        
        try:
            with pytest.raises(ExternalInterfaceLoaderError, match="Cannot auto-detect"):
                loader.load_csv(csv_path)
        finally:
            Path(csv_path).unlink(missing_ok=True)


class TestLoadFromFile:
    """Tests for load_from_file() method with format auto-detection."""
    
    def test_load_from_file_json(self, loader):
        """Test format auto-detection for JSON files."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXT',
                    'target_program': 'PROG',
                    'dependency_type': 'CALL'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            file_path = f.name
        
        try:
            result = loader.load_from_file(file_path)
            assert 'inbound' in result
        finally:
            Path(file_path).unlink(missing_ok=True)
    
    def test_load_from_file_csv(self, loader):
        """Test format auto-detection for CSV files."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='_inbound.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['source_name', 'target_program', 'dependency_type'])
            writer.writeheader()
            writer.writerow({
                'source_name': 'EXT',
                'target_program': 'PROG',
                'dependency_type': 'CALL'
            })
            file_path = f.name
        
        try:
            result = loader.load_from_file(file_path)
            assert 'inbound' in result
        finally:
            Path(file_path).unlink(missing_ok=True)
    
    def test_load_from_file_unsupported_format(self, loader):
        """Test error for unsupported file format."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            file_path = f.name
        
        try:
            with pytest.raises(ExternalInterfaceLoaderError, match="Unsupported file format"):
                loader.load_from_file(file_path)
        finally:
            Path(file_path).unlink(missing_ok=True)
    
    def test_load_from_file_not_found(self, loader):
        """Test error for non-existent file."""
        with pytest.raises(FileNotFoundError):
            loader.load_from_file('/nonexistent/file.json')


class TestLoadInboundInterfaces:
    """Tests for load_inbound_interfaces() method."""
    
    def test_load_inbound_interfaces_from_config(self, loader, db_connection):
        """Test loading inbound interfaces into database."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    'target_program': 'PROG1',
                    'dependency_type': 'PROGRAM_CALL',
                    'system': 'System A',
                    'description': 'Test interface'
                },
                {
                    'source_name': 'EXTERNAL_B',
                    'target_program': 'PROG2',
                    'dependency_type': 'CICS_LINK'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            count = loader.load_inbound_interfaces(json_path)
            
            assert count == 2
            
            # Verify database contents
            cursor = db_connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM inbound_interfaces")
            assert cursor.fetchone()[0] == 2
            
            # Verify is_configured flag
            cursor.execute("SELECT is_configured FROM inbound_interfaces")
            for row in cursor.fetchall():
                assert row[0] == 1  # True
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_prevents_duplicates(self, loader, db_connection):
        """Test that duplicate interfaces are not inserted."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    'target_program': 'PROG1',
                    'dependency_type': 'PROGRAM_CALL'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            # Load first time
            count1 = loader.load_inbound_interfaces(json_path)
            assert count1 == 1
            
            # Load second time (should be duplicate)
            count2 = loader.load_inbound_interfaces(json_path)
            assert count2 == 0
            
            # Verify only one record in database
            cursor = db_connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM inbound_interfaces")
            assert cursor.fetchone()[0] == 1
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_preserves_metadata(self, loader, db_connection):
        """Test that metadata is preserved in database."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    'target_program': 'PROG1',
                    'dependency_type': 'PROGRAM_CALL',
                    'system': 'System A',
                    'description': 'Test interface'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            loader.load_inbound_interfaces(json_path)
            
            # Verify metadata
            cursor = db_connection.cursor()
            cursor.execute("SELECT metadata FROM inbound_interfaces")
            metadata_json = cursor.fetchone()[0]
            
            assert metadata_json is not None
            metadata = json.loads(metadata_json)
            assert metadata['system'] == 'System A'
            assert metadata['description'] == 'Test interface'
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_missing_required_field(self, loader):
        """Test error handling for missing required fields."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    # Missing target_program
                    'dependency_type': 'PROGRAM_CALL'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            with pytest.raises(ExternalInterfaceLoaderError, match="Missing required field"):
                loader.load_inbound_interfaces(json_path)
        finally:
            Path(json_path).unlink(missing_ok=True)


class TestLoadOutboundInterfaces:
    """Tests for load_outbound_interfaces() method."""
    
    def test_load_outbound_interfaces_from_config(self, loader, db_connection):
        """Test loading outbound interfaces into database."""
        data = {
            'outbound': [
                {
                    'program_name': 'UTIL_LIB',
                    'reason': 'configured',
                    'description': 'Utility library'
                },
                {
                    'program_name': 'SFTP_HANDLER',
                    'reason': 'configured'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            count = loader.load_outbound_interfaces(json_path)
            
            assert count == 2
            
            # Verify database contents
            cursor = db_connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM outbound_interfaces")
            assert cursor.fetchone()[0] == 2
            
            # Verify reason field
            cursor.execute("SELECT reason FROM outbound_interfaces")
            for row in cursor.fetchall():
                assert row[0] == 'configured'
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_outbound_prevents_duplicates(self, loader, db_connection):
        """Test that duplicate outbound interfaces are not inserted."""
        data = {
            'outbound': [
                {
                    'program_name': 'UTIL_LIB',
                    'reason': 'configured'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            # Load first time
            count1 = loader.load_outbound_interfaces(json_path)
            assert count1 == 1
            
            # Load second time (should be duplicate)
            count2 = loader.load_outbound_interfaces(json_path)
            assert count2 == 0
            
            # Verify only one record in database
            cursor = db_connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM outbound_interfaces")
            assert cursor.fetchone()[0] == 1
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_outbound_missing_required_field(self, loader):
        """Test error handling for missing program_name."""
        data = {
            'outbound': [
                {
                    'reason': 'configured'
                    # Missing program_name
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            with pytest.raises(ExternalInterfaceLoaderError, match="Missing required field"):
                loader.load_outbound_interfaces(json_path)
        finally:
            Path(json_path).unlink(missing_ok=True)


class TestLoadAll:
    """Tests for load_all() method."""
    
    def test_load_all_returns_counts(self, loader, db_connection):
        """Test that load_all returns correct counts."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    'target_program': 'PROG1',
                    'dependency_type': 'PROGRAM_CALL'
                },
                {
                    'source_name': 'EXTERNAL_B',
                    'target_program': 'PROG2',
                    'dependency_type': 'CICS_LINK'
                }
            ],
            'outbound': [
                {
                    'program_name': 'UTIL_LIB',
                    'reason': 'configured'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            counts = loader.load_all(json_path)
            
            assert counts['inbound'] == 2
            assert counts['outbound'] == 1
            
            # Verify database
            cursor = db_connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM inbound_interfaces")
            assert cursor.fetchone()[0] == 2
            
            cursor.execute("SELECT COUNT(*) FROM outbound_interfaces")
            assert cursor.fetchone()[0] == 1
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_all_with_only_inbound(self, loader):
        """Test load_all with only inbound interfaces."""
        data = {
            'inbound': [
                {
                    'source_name': 'EXTERNAL_A',
                    'target_program': 'PROG1',
                    'dependency_type': 'PROGRAM_CALL'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            counts = loader.load_all(json_path)
            
            assert counts['inbound'] == 1
            assert counts['outbound'] == 0
            
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_load_all_with_only_outbound(self, loader):
        """Test load_all with only outbound interfaces."""
        data = {
            'outbound': [
                {
                    'program_name': 'UTIL_LIB',
                    'reason': 'configured'
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            counts = loader.load_all(json_path)
            
            assert counts['inbound'] == 0
            assert counts['outbound'] == 1
            
        finally:
            Path(json_path).unlink(missing_ok=True)


class TestErrorHandling:
    """Tests for error handling."""
    
    def test_invalid_json_format(self, loader):
        """Test error handling for invalid JSON format."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write("not valid json")
            json_path = f.name
        
        try:
            with pytest.raises(ExternalInterfaceLoaderError, match="Invalid JSON"):
                loader.load_inbound_interfaces(json_path)
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_missing_inbound_key(self, loader):
        """Test warning when inbound key is missing."""
        data = {'outbound': []}
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            count = loader.load_inbound_interfaces(json_path)
            assert count == 0  # Should return 0, not error
        finally:
            Path(json_path).unlink(missing_ok=True)
    
    def test_missing_outbound_key(self, loader):
        """Test warning when outbound key is missing."""
        data = {'inbound': []}
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(data, f)
            json_path = f.name
        
        try:
            count = loader.load_outbound_interfaces(json_path)
            assert count == 0  # Should return 0, not error
        finally:
            Path(json_path).unlink(missing_ok=True)
