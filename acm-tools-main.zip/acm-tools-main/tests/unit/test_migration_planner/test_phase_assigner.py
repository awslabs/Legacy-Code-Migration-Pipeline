"""
Unit tests for PhaseAssigner.

Tests specific examples and edge cases for phase assignment and dependency validation.
Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 8.1, 8.2, 8.3, 8.4, 8.5, 8.6
"""

import pytest
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.models.workpackage import WorkpackageAssignment
from tools.migration_planner.phase.phase_assigner import PhaseAssigner, ValidationError


class TestPhaseAssigner:
    """Test suite for PhaseAssigner class."""
    
    def test_simple_linear_dependencies(self):
        """
        Test phase assignment with simple linear dependencies: A -> B -> C.
        
        Requirements: 3.1, 3.2, 3.5, 3.6
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_C",
                name="Flow C",
                programs=[Program(name="PROG_C", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_B"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                                priority_score=float(i), preexistent_modules=[])
            for i, flow in enumerate(flows)
        ]
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
        
        # Verify phases
        assert assigner.flow_phases["FLOW_A"] == 1
        assert assigner.flow_phases["FLOW_B"] == 2
        assert assigner.flow_phases["FLOW_C"] == 3
        
        # Verify phase list
        assert len(phase_list) == 3
        assert phase_list[0].phase_id == 1
        assert phase_list[1].phase_id == 2
        assert phase_list[2].phase_id == 3
        
        # Verify migration sequence
        assert len(migration_sequence) == 3
        assert migration_sequence[0].flow_id == "FLOW_A"
        assert migration_sequence[1].flow_id == "FLOW_B"
        assert migration_sequence[2].flow_id == "FLOW_C"
        
        # Verify prerequisites
        assert migration_sequence[0].prerequisites == []
        assert migration_sequence[1].prerequisites == [1]
        assert migration_sequence[2].prerequisites == [2]
    
    def test_complex_dependency_tree(self):
        """
        Test phase assignment with complex dependency tree.
        
        Requirements: 3.1, 3.2, 3.5, 3.6
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_C",
                name="Flow C",
                programs=[Program(name="PROG_C", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A", "FLOW_B"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_D",
                name="Flow D",
                programs=[Program(name="PROG_D", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_B"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_E",
                name="Flow E",
                programs=[Program(name="PROG_E", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_C", "FLOW_D"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                                priority_score=float(i), preexistent_modules=[])
            for i, flow in enumerate(flows)
        ]
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
        
        # Verify phases
        assert assigner.flow_phases["FLOW_A"] == 1
        assert assigner.flow_phases["FLOW_B"] == 1
        assert assigner.flow_phases["FLOW_C"] == 2
        assert assigner.flow_phases["FLOW_D"] == 2
        assert assigner.flow_phases["FLOW_E"] == 3
        
        # Verify phase list
        assert len(phase_list) == 3
    
    def test_circular_dependency_detection(self):
        """
        Test detection of circular dependencies.
        
        Requirements: 3.3, 3.4, 8.3, 8.4, 8.5
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_B"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                                priority_score=float(i), preexistent_modules=[])
            for i, flow in enumerate(flows)
        ]
        
        assigner = PhaseAssigner()
        
        # Should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            assigner.assign_phases(workpackages, flows)
        
        error_message = str(exc_info.value)
        assert "Circular dependencies detected" in error_message
        assert "FLOW_A" in error_message
        assert "FLOW_B" in error_message
    
    def test_missing_flow_reference_error(self):
        """
        Test error handling for missing flow references.
        
        Requirements: 8.1, 8.2
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_NONEXISTENT"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=1, flow_id="FLOW_A",
                                priority_score=10.0, preexistent_modules=[])
        ]
        
        assigner = PhaseAssigner()
        
        # Should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            assigner.assign_phases(workpackages, flows)
        
        error_message = str(exc_info.value)
        assert "non-existent" in error_message.lower()
        assert "FLOW_NONEXISTENT" in error_message
    
    def test_phase_1_assignment_for_independent_flows(self):
        """
        Test that independent flows (no dependencies) are assigned to phase 1.
        
        Requirements: 3.1
        """
        flows = [
            BusinessFlow(
                flow_id=f"FLOW_{i}",
                name=f"Flow {i}",
                programs=[Program(name=f"PROG_{i}", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            for i in range(5)
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                                priority_score=float(i), preexistent_modules=[])
            for i, flow in enumerate(flows)
        ]
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
        
        # All flows should be in phase 1
        for flow in flows:
            assert assigner.flow_phases[flow.flow_id] == 1
        
        # Should have exactly one phase
        assert len(phase_list) == 1
        assert phase_list[0].phase_id == 1
        assert len(phase_list[0].workpackages) == 5
    
    def test_three_node_circular_dependency(self):
        """
        Test detection of three-node circular dependency: A -> B -> C -> A.
        
        Requirements: 3.3, 3.4, 8.4
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_B"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_C"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_C",
                name="Flow C",
                programs=[Program(name="PROG_C", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                                priority_score=float(i), preexistent_modules=[])
            for i, flow in enumerate(flows)
        ]
        
        assigner = PhaseAssigner()
        
        # Should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            assigner.assign_phases(workpackages, flows)
        
        error_message = str(exc_info.value)
        assert "Circular dependencies detected" in error_message
    
    def test_topological_sort(self):
        """
        Test topological sort functionality.
        
        Requirements: 3.5, 3.6
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_C",
                name="Flow C",
                programs=[Program(name="PROG_C", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_D",
                name="Flow D",
                programs=[Program(name="PROG_D", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_B", "FLOW_C"],
                dependent_flows=[]
            )
        ]
        
        assigner = PhaseAssigner()
        sorted_flows = assigner.topological_sort(flows)
        
        # Verify topological order
        flow_positions = {flow_id: i for i, flow_id in enumerate(sorted_flows)}
        
        # FLOW_A should come before FLOW_B and FLOW_C
        assert flow_positions["FLOW_A"] < flow_positions["FLOW_B"]
        assert flow_positions["FLOW_A"] < flow_positions["FLOW_C"]
        
        # FLOW_B and FLOW_C should come before FLOW_D
        assert flow_positions["FLOW_B"] < flow_positions["FLOW_D"]
        assert flow_positions["FLOW_C"] < flow_positions["FLOW_D"]
    
    def test_phase_metadata_generation(self):
        """
        Test generation of phase metadata.
        
        Requirements: 3.5
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=1, flow_id="FLOW_A",
                                priority_score=10.0, preexistent_modules=[]),
            WorkpackageAssignment(workpackage_id=2, flow_id="FLOW_B",
                                priority_score=20.0, preexistent_modules=[])
        ]
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
        
        # Verify phase metadata
        assert len(phase_list) == 2
        
        # Phase 1
        assert phase_list[0].phase_id == 1
        assert phase_list[0].workpackages == [1]
        assert phase_list[0].dependencies == []
        
        # Phase 2
        assert phase_list[1].phase_id == 2
        assert phase_list[1].workpackages == [2]
        assert phase_list[1].dependencies == [1]
    
    def test_migration_sequence_generation(self):
        """
        Test generation of migration sequence.
        
        Requirements: 3.6
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=1, flow_id="FLOW_A",
                                priority_score=10.0, preexistent_modules=[]),
            WorkpackageAssignment(workpackage_id=2, flow_id="FLOW_B",
                                priority_score=20.0, preexistent_modules=[])
        ]
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
        
        # Verify migration sequence
        assert len(migration_sequence) == 2
        
        # First item
        assert migration_sequence[0].sequence_number == 1
        assert migration_sequence[0].workpackage_id == 1
        assert migration_sequence[0].flow_id == "FLOW_A"
        assert migration_sequence[0].phase == 1
        assert migration_sequence[0].prerequisites == []
        
        # Second item
        assert migration_sequence[1].sequence_number == 2
        assert migration_sequence[1].workpackage_id == 2
        assert migration_sequence[1].flow_id == "FLOW_B"
        assert migration_sequence[1].phase == 2
        assert migration_sequence[1].prerequisites == [1]
    
    def test_empty_flow_list(self):
        """
        Test phase assignment with empty flow list.
        
        Requirements: 3.1, 3.5, 3.6
        """
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases([], [])
        
        assert len(phase_list) == 0
        assert len(migration_sequence) == 0
    
    def test_single_flow_no_dependencies(self):
        """
        Test phase assignment with a single flow and no dependencies.
        
        Requirements: 3.1, 3.5, 3.6
        """
        flow = BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        workpackage = WorkpackageAssignment(
            workpackage_id=1,
            flow_id="FLOW_A",
            priority_score=10.0,
            preexistent_modules=[]
        )
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases([workpackage], [flow])
        
        # Should be in phase 1
        assert assigner.flow_phases["FLOW_A"] == 1
        
        # Should have one phase
        assert len(phase_list) == 1
        assert phase_list[0].phase_id == 1
        
        # Should have one migration sequence item
        assert len(migration_sequence) == 1
        assert migration_sequence[0].flow_id == "FLOW_A"
    
    def test_diamond_dependency_pattern(self):
        """
        Test phase assignment with diamond dependency pattern.
        
        Requirements: 3.1, 3.2, 3.5, 3.6, 8.6
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_C",
                name="Flow C",
                programs=[Program(name="PROG_C", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A"],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_D",
                name="Flow D",
                programs=[Program(name="PROG_D", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_B", "FLOW_C"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                                priority_score=float(i), preexistent_modules=[])
            for i, flow in enumerate(flows)
        ]
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
        
        # Verify phases
        assert assigner.flow_phases["FLOW_A"] == 1
        assert assigner.flow_phases["FLOW_B"] == 2
        assert assigner.flow_phases["FLOW_C"] == 2
        assert assigner.flow_phases["FLOW_D"] == 3
        
        # Verify phase list
        assert len(phase_list) == 3
    
    def test_self_referencing_flow(self):
        """
        Test detection of self-referencing flow.
        
        Requirements: 3.3, 3.4, 8.4
        """
        flow = BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A"],  # Self-reference
            dependent_flows=[]
        )
        
        workpackage = WorkpackageAssignment(
            workpackage_id=1,
            flow_id="FLOW_A",
            priority_score=10.0,
            preexistent_modules=[]
        )
        
        assigner = PhaseAssigner()
        
        # Should raise ValidationError
        with pytest.raises(ValidationError):
            assigner.assign_phases([workpackage], [flow])
    
    def test_phase_dependencies_are_correct(self):
        """
        Test that phase dependencies are correctly calculated.
        
        Requirements: 3.5, 8.6
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW_A",
                name="Flow A",
                programs=[Program(name="PROG_A", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_B",
                name="Flow B",
                programs=[Program(name="PROG_B", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW_C",
                name="Flow C",
                programs=[Program(name="PROG_C", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=["FLOW_A", "FLOW_B"],
                dependent_flows=[]
            )
        ]
        
        workpackages = [
            WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                                priority_score=float(i), preexistent_modules=[])
            for i, flow in enumerate(flows)
        ]
        
        assigner = PhaseAssigner()
        phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
        
        # Phase 1 should have no dependencies
        assert phase_list[0].dependencies == []
        
        # Phase 2 should depend on phase 1
        assert phase_list[1].dependencies == [1]
