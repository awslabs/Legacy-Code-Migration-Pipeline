"""
Unit tests for WorkpackageAssigner.

Tests specific examples and edge cases for workpackage assignment.
Requirements: 2.1, 2.2, 2.3, 2.4, 2.5
"""

import pytest
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.models.priority import PriorityResult, PriorityFactors
from tools.migration_planner.workpackage.workpackage_assigner import WorkpackageAssigner


class TestWorkpackageAssigner:
    """Test suite for WorkpackageAssigner class."""
    
    def test_sequential_id_assignment(self):
        """
        Test that workpackage IDs are assigned sequentially starting from 1.
        
        Requirements: 2.1, 2.3
        """
        # Create 5 flows with different priorities
        flows = []
        priorities = {}
        
        for i in range(5):
            flow_id = f"FLOW{i:03d}"
            flow = BusinessFlow(
                flow_id=flow_id,
                name=f"Flow {i}",
                programs=[Program(name=f"PROG{i}", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            flows.append(flow)
            
            # Assign priorities in reverse order (FLOW004 has lowest priority)
            factors = PriorityFactors(
                total_programs=1,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow_id] = PriorityResult(
                flow_id=flow_id,
                priority_score=float((4 - i) * 10),  # 40, 30, 20, 10, 0
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # Verify sequential IDs
        assert len(assignments) == 5
        for i, assignment in enumerate(assignments):
            assert assignment.workpackage_id == i + 1
    
    def test_stable_sorting_with_equal_priorities(self):
        """
        Test that flows with equal priorities are sorted by flowId (stable sort).
        
        Requirements: 2.2, 2.3
        """
        # Create flows with equal priorities but different flowIds
        flows = []
        priorities = {}
        
        flow_ids = ["FLOW_C", "FLOW_A", "FLOW_B", "FLOW_D"]
        for flow_id in flow_ids:
            flow = BusinessFlow(
                flow_id=flow_id,
                name=f"Flow {flow_id}",
                programs=[Program(name=f"PROG_{flow_id}", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            flows.append(flow)
            
            # All flows have the same priority
            factors = PriorityFactors(
                total_programs=1,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow_id] = PriorityResult(
                flow_id=flow_id,
                priority_score=50.0,
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # Verify flows are sorted by flowId
        expected_order = ["FLOW_A", "FLOW_B", "FLOW_C", "FLOW_D"]
        actual_order = [assignment.flow_id for assignment in assignments]
        
        assert actual_order == expected_order
    
    def test_preexistent_module_tracking(self):
        """
        Test that pre-existent modules are correctly identified.
        
        Requirements: 2.4, 2.5
        """
        # Create flows with overlapping programs
        flows = []
        priorities = {}
        
        # Flow 1: PROG1, PROG2
        flow1 = BusinessFlow(
            flow_id="FLOW001",
            name="Flow 1",
            programs=[
                Program(name="PROG1", is_utility=False),
                Program(name="PROG2", is_utility=False)
            ],
            databases=[],
            total_programs=2,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow1)
        
        # Flow 2: PROG2, PROG3 (PROG2 is pre-existent)
        flow2 = BusinessFlow(
            flow_id="FLOW002",
            name="Flow 2",
            programs=[
                Program(name="PROG2", is_utility=False),
                Program(name="PROG3", is_utility=False)
            ],
            databases=[],
            total_programs=2,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow2)
        
        # Flow 3: PROG1, PROG3, PROG4 (PROG1 and PROG3 are pre-existent)
        flow3 = BusinessFlow(
            flow_id="FLOW003",
            name="Flow 3",
            programs=[
                Program(name="PROG1", is_utility=False),
                Program(name="PROG3", is_utility=False),
                Program(name="PROG4", is_utility=False)
            ],
            databases=[],
            total_programs=3,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow3)
        
        # Assign priorities (FLOW001 highest, FLOW003 lowest)
        for i, flow in enumerate(flows):
            factors = PriorityFactors(
                total_programs=flow.total_programs,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow.flow_id] = PriorityResult(
                flow_id=flow.flow_id,
                priority_score=float(i * 10),
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # Verify pre-existent modules
        assert len(assignments[0].preexistent_modules) == 0  # First workpackage has none
        assert assignments[1].preexistent_modules == ["PROG2"]  # PROG2 from FLOW001
        assert assignments[2].preexistent_modules == ["PROG1", "PROG3"]  # Both from earlier flows
    
    def test_empty_flow_list(self):
        """
        Test workpackage assignment with empty flow list.
        
        Requirements: 2.1, 2.3
        """
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages({}, [])
        
        assert len(assignments) == 0
    
    def test_single_flow(self):
        """
        Test workpackage assignment with a single flow.
        
        Requirements: 2.1, 2.3, 2.4
        """
        flow = BusinessFlow(
            flow_id="FLOW001",
            name="Single Flow",
            programs=[Program(name="PROG1", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        factors = PriorityFactors(
            total_programs=1,
            common_modules=0,
            composite_score=10.0,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities = {
            "FLOW001": PriorityResult(
                flow_id="FLOW001",
                priority_score=25.0,
                factors=factors
            )
        }
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, [flow])
        
        assert len(assignments) == 1
        assert assignments[0].workpackage_id == 1
        assert assignments[0].flow_id == "FLOW001"
        assert assignments[0].priority_score == 25.0
        assert len(assignments[0].preexistent_modules) == 0
    
    def test_flows_with_no_overlapping_programs(self):
        """
        Test that flows with no overlapping programs have no pre-existent modules.
        
        Requirements: 2.4, 2.5
        """
        flows = []
        priorities = {}
        
        for i in range(3):
            flow_id = f"FLOW{i:03d}"
            # Each flow has unique programs
            programs = [Program(name=f"PROG{i}_{j}", is_utility=False) for j in range(3)]
            
            flow = BusinessFlow(
                flow_id=flow_id,
                name=f"Flow {i}",
                programs=programs,
                databases=[],
                total_programs=3,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            flows.append(flow)
            
            factors = PriorityFactors(
                total_programs=3,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow_id] = PriorityResult(
                flow_id=flow_id,
                priority_score=float(i * 10),
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # No workpackage should have pre-existent modules
        for assignment in assignments:
            assert len(assignment.preexistent_modules) == 0
    
    def test_flows_with_complete_overlap(self):
        """
        Test that flows with complete program overlap identify all as pre-existent.
        
        Requirements: 2.4, 2.5
        """
        # Create shared programs
        shared_programs = [
            Program(name="SHARED1", is_utility=False),
            Program(name="SHARED2", is_utility=False),
            Program(name="SHARED3", is_utility=False)
        ]
        
        flows = []
        priorities = {}
        
        for i in range(3):
            flow_id = f"FLOW{i:03d}"
            
            flow = BusinessFlow(
                flow_id=flow_id,
                name=f"Flow {i}",
                programs=shared_programs.copy(),
                databases=[],
                total_programs=3,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            flows.append(flow)
            
            factors = PriorityFactors(
                total_programs=3,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow_id] = PriorityResult(
                flow_id=flow_id,
                priority_score=float(i * 10),
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # First workpackage has no pre-existent modules
        assert len(assignments[0].preexistent_modules) == 0
        
        # All subsequent workpackages have all programs as pre-existent
        for i in range(1, len(assignments)):
            assert set(assignments[i].preexistent_modules) == {"SHARED1", "SHARED2", "SHARED3"}
    
    def test_priority_score_sorting_ascending(self):
        """
        Test that flows are sorted by priority score in ascending order.
        
        Requirements: 2.1, 2.2
        """
        flows = []
        priorities = {}
        
        # Create flows with different priorities
        priority_scores = [100.0, 25.0, 75.0, 10.0, 50.0]
        
        for i, score in enumerate(priority_scores):
            flow_id = f"FLOW{i:03d}"
            flow = BusinessFlow(
                flow_id=flow_id,
                name=f"Flow {i}",
                programs=[Program(name=f"PROG{i}", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            flows.append(flow)
            
            factors = PriorityFactors(
                total_programs=1,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow_id] = PriorityResult(
                flow_id=flow_id,
                priority_score=score,
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # Verify ascending order
        expected_order = ["FLOW003", "FLOW001", "FLOW004", "FLOW002", "FLOW000"]  # 10, 25, 50, 75, 100
        actual_order = [assignment.flow_id for assignment in assignments]
        
        assert actual_order == expected_order
        
        # Verify priority scores are in ascending order
        for i in range(len(assignments) - 1):
            assert assignments[i].priority_score <= assignments[i + 1].priority_score
    
    def test_preexistent_modules_are_sorted(self):
        """
        Test that pre-existent modules list is sorted alphabetically.
        
        Requirements: 2.4, 2.5
        """
        # Create flows with overlapping programs in different orders
        flow1 = BusinessFlow(
            flow_id="FLOW001",
            name="Flow 1",
            programs=[
                Program(name="PROG_Z", is_utility=False),
                Program(name="PROG_A", is_utility=False),
                Program(name="PROG_M", is_utility=False)
            ],
            databases=[],
            total_programs=3,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        flow2 = BusinessFlow(
            flow_id="FLOW002",
            name="Flow 2",
            programs=[
                Program(name="PROG_M", is_utility=False),
                Program(name="PROG_Z", is_utility=False),
                Program(name="PROG_B", is_utility=False)
            ],
            databases=[],
            total_programs=3,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        flows = [flow1, flow2]
        priorities = {}
        
        for i, flow in enumerate(flows):
            factors = PriorityFactors(
                total_programs=3,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow.flow_id] = PriorityResult(
                flow_id=flow.flow_id,
                priority_score=float(i * 10),
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # Second workpackage should have pre-existent modules sorted
        assert assignments[1].preexistent_modules == ["PROG_M", "PROG_Z"]
    
    def test_assignment_includes_correct_priority_score(self):
        """
        Test that each assignment includes the correct priority score.
        
        Requirements: 2.5
        """
        flows = []
        priorities = {}
        
        for i in range(3):
            flow_id = f"FLOW{i:03d}"
            flow = BusinessFlow(
                flow_id=flow_id,
                name=f"Flow {i}",
                programs=[Program(name=f"PROG{i}", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            flows.append(flow)
            
            priority_score = float(i * 15.5)
            factors = PriorityFactors(
                total_programs=1,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow_id] = PriorityResult(
                flow_id=flow_id,
                priority_score=priority_score,
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # Verify each assignment has the correct priority score
        for assignment in assignments:
            expected_score = priorities[assignment.flow_id].priority_score
            assert assignment.priority_score == expected_score
    
    def test_mixed_priority_and_stable_sort(self):
        """
        Test combination of priority sorting and stable sort by flowId.
        
        Requirements: 2.1, 2.2, 2.3
        """
        flows = []
        priorities = {}
        
        # Create flows with some equal priorities
        flow_data = [
            ("FLOW_C", 50.0),
            ("FLOW_A", 50.0),
            ("FLOW_D", 25.0),
            ("FLOW_B", 50.0),
            ("FLOW_E", 75.0)
        ]
        
        for flow_id, priority_score in flow_data:
            flow = BusinessFlow(
                flow_id=flow_id,
                name=f"Flow {flow_id}",
                programs=[Program(name=f"PROG_{flow_id}", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=10.0,
                required_flows=[],
                dependent_flows=[]
            )
            flows.append(flow)
            
            factors = PriorityFactors(
                total_programs=1,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=0,
                simple_flow_bonus=0
            )
            priorities[flow_id] = PriorityResult(
                flow_id=flow_id,
                priority_score=priority_score,
                factors=factors
            )
        
        assigner = WorkpackageAssigner()
        assignments = assigner.assign_workpackages(priorities, flows)
        
        # Expected order: FLOW_D (25), then FLOW_A, FLOW_B, FLOW_C (all 50, sorted by ID), then FLOW_E (75)
        expected_order = ["FLOW_D", "FLOW_A", "FLOW_B", "FLOW_C", "FLOW_E"]
        actual_order = [assignment.flow_id for assignment in assignments]
        
        assert actual_order == expected_order
