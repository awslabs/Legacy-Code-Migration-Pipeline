"""Unit tests for output generator."""

import json
import tempfile
from pathlib import Path

from tools.migration_planner.models import (
    BusinessFlow,
    Program,
    PriorityResult,
    PriorityFactors,
    WorkpackageAssignment,
    PhaseAssignment,
    MigrationSequenceItem,
    PlanningData,
    Metadata,
    Statistics,
)
from tools.migration_planner.output import OutputGenerator


def test_output_generator_initialization():
    """Test OutputGenerator initialization creates output directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir) / "output"
        generator = OutputGenerator(output_base, "test_project")
        
        assert generator.output_base == output_base
        assert generator.project_name == "test_project"
        assert output_base.exists(), "Output directory should be created"
        assert generator.progress_dir.exists(), "Progress subdirectory should be created"
        assert generator.reports_dir.exists(), "Reports subdirectory should be created"


def test_generate_planning_json_structure():
    """Test planning JSON output structure."""
    # Create test data
    flow1 = BusinessFlow(
        flow_id="FLOW001",
        name="Test Flow 1",
        programs=[Program(name="PROG001", is_utility=False)],
        databases=["DB1"],
        total_programs=1,
        composite_score=10.0,
        required_flows=[],
        dependent_flows=[]
    )
    
    flow2 = BusinessFlow(
        flow_id="FLOW002",
        name="Test Flow 2",
        programs=[Program(name="PROG002", is_utility=False)],
        databases=[],
        total_programs=1,
        composite_score=5.0,
        required_flows=["FLOW001"],
        dependent_flows=[]
    )
    
    flows = [flow1, flow2]
    
    priorities = {
        "FLOW001": PriorityResult(
            flow_id="FLOW001",
            priority_score=10.0,
            factors=PriorityFactors(
                total_programs=1,
                common_modules=0,
                composite_score=10.0,
                complete_flow_bonus=-5,
                simple_flow_bonus=-3
            )
        ),
        "FLOW002": PriorityResult(
            flow_id="FLOW002",
            priority_score=15.0,
            factors=PriorityFactors(
                total_programs=1,
                common_modules=0,
                composite_score=5.0,
                complete_flow_bonus=0,
                simple_flow_bonus=-3
            )
        )
    }
    
    flow_priorities = {
        "FLOW001": WorkpackageAssignment(
            workpackage_id=1,
            flow_id="FLOW001",
            priority_score=10.0,
            preexistent_modules=[]
        ),
        "FLOW002": WorkpackageAssignment(
            workpackage_id=2,
            flow_id="FLOW002",
            priority_score=15.0,
            preexistent_modules=["PROG001"]
        )
    }
    
    phases = [
        PhaseAssignment(phase_id=1, workpackages=[1], dependencies=[]),
        PhaseAssignment(phase_id=2, workpackages=[2], dependencies=[1])
    ]
    
    migration_sequence = [
        MigrationSequenceItem(
            sequence_number=1,
            workpackage_id=1,
            flow_id="FLOW001",
            phase=1,
            prerequisites=[]
        ),
        MigrationSequenceItem(
            sequence_number=2,
            workpackage_id=2,
            flow_id="FLOW002",
            phase=2,
            prerequisites=[1]
        )
    ]
    
    metadata = Metadata.create("test_project")
    statistics = Statistics.calculate(flow_priorities, phases)
    
    planning_data = PlanningData(
        metadata=metadata,
        flow_priorities=flow_priorities,
        phases=phases,
        migration_sequence=migration_sequence,
        statistics=statistics
    )
    
    # Generate output
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, "test_project")
        output_path = generator.generate_planning_json(planning_data, priorities, flows)
        
        # Verify file exists
        assert output_path.exists()
        assert output_path.name == "Workpackage_Planning.json"
        
        # Load and verify structure
        with open(output_path, 'r') as f:
            output = json.load(f)
        
        assert "metadata" in output
        assert "flowPriorities" in output
        assert "phases" in output
        assert "migrationSequence" in output
        assert "statistics" in output
        
        # Verify metadata
        assert output["metadata"]["projectName"] == "test_project"
        assert output["metadata"]["phase"] == "WORKPACKAGE_PLANNING"
        
        # Verify flowPriorities
        assert len(output["flowPriorities"]) == 2
        assert "FLOW001" in output["flowPriorities"]
        assert output["flowPriorities"]["FLOW001"]["workpackageId"] == 1
        assert output["flowPriorities"]["FLOW001"]["priorityScore"] == 10.0
        
        # Verify phases
        assert len(output["phases"]) == 2
        assert output["phases"][0]["phaseId"] == 1
        assert output["phases"][1]["dependencies"] == [1]
        
        # Verify migration sequence
        assert len(output["migrationSequence"]) == 2
        assert output["migrationSequence"][0]["sequenceNumber"] == 1
        assert output["migrationSequence"][1]["prerequisites"] == [1]


def test_generate_status_json():
    """Test status JSON generation."""
    workpackages = [
        WorkpackageAssignment(
            workpackage_id=1,
            flow_id="FLOW001",
            priority_score=10.0,
            preexistent_modules=[]
        ),
        WorkpackageAssignment(
            workpackage_id=2,
            flow_id="FLOW002",
            priority_score=15.0,
            preexistent_modules=[]
        )
    ]
    
    phases = [
        PhaseAssignment(phase_id=1, workpackages=[1], dependencies=[]),
        PhaseAssignment(phase_id=2, workpackages=[2], dependencies=[1])
    ]
    
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, "test_project")
        output_path = generator.generate_status_json(workpackages, phases)
        
        # Verify file exists
        assert output_path.exists()
        assert output_path.name == "Workpackage_Status.json"
        assert output_path.parent.name == "progress", "Status file should be in progress subfolder"
        
        # Load and verify structure
        with open(output_path, 'r') as f:
            output = json.load(f)
        
        assert "metadata" in output
        assert "status" in output
        assert "workpackages" in output
        
        # Verify metadata
        assert output["metadata"]["projectName"] == "test_project"
        assert output["metadata"]["version"] == "1.0"
        
        # Verify status
        assert output["status"] == "completed"
        
        # Verify workpackages
        assert len(output["workpackages"]) == 2
        
        for entry in output["workpackages"]:
            assert entry["status"] == "NOT_STARTED"
            assert entry["startDate"] is None
            assert entry["endDate"] is None
            assert entry["notes"] == ""
            assert "workpackageId" in entry
            assert "flowId" in entry
            assert "phase" in entry


def test_generate_roadmap_markdown():
    """Test markdown roadmap generation."""
    flow1 = BusinessFlow(
        flow_id="FLOW001",
        name="Test Flow 1",
        programs=[Program(name="PROG001", is_utility=False)],
        databases=["DB1"],
        total_programs=1,
        composite_score=10.0,
        required_flows=[],
        dependent_flows=[]
    )
    
    flow2 = BusinessFlow(
        flow_id="FLOW002",
        name="Test Flow 2",
        programs=[Program(name="PROG002", is_utility=False)],
        databases=[],
        total_programs=1,
        composite_score=5.0,
        required_flows=["FLOW001"],
        dependent_flows=[]
    )
    
    flows = [flow1, flow2]
    
    flow_priorities = {
        "FLOW001": WorkpackageAssignment(
            workpackage_id=1,
            flow_id="FLOW001",
            priority_score=10.0,
            preexistent_modules=[]
        ),
        "FLOW002": WorkpackageAssignment(
            workpackage_id=2,
            flow_id="FLOW002",
            priority_score=15.0,
            preexistent_modules=[]
        )
    }
    
    phases = [
        PhaseAssignment(phase_id=1, workpackages=[1], dependencies=[]),
        PhaseAssignment(phase_id=2, workpackages=[2], dependencies=[1])
    ]
    
    migration_sequence = [
        MigrationSequenceItem(
            sequence_number=1,
            workpackage_id=1,
            flow_id="FLOW001",
            phase=1,
            prerequisites=[]
        ),
        MigrationSequenceItem(
            sequence_number=2,
            workpackage_id=2,
            flow_id="FLOW002",
            phase=2,
            prerequisites=[1]
        )
    ]
    
    metadata = Metadata.create("test_project")
    statistics = Statistics.calculate(flow_priorities, phases)
    
    planning_data = PlanningData(
        metadata=metadata,
        flow_priorities=flow_priorities,
        phases=phases,
        migration_sequence=migration_sequence,
        statistics=statistics
    )
    
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, "test_project")
        output_path = generator.generate_roadmap_markdown(planning_data, flows)
        
        # Verify file exists
        assert output_path.exists()
        assert output_path.name == "Workpackage_Definition_Roadmap.md"
        assert output_path.parent.name == "reports", "Roadmap file should be in reports subfolder"
        
        # Read and verify content
        with open(output_path, 'r') as f:
            content = f.read()
        
        # Verify sections exist
        assert "# Migration Workpackage Roadmap: test_project" in content
        assert "## Executive Summary" in content
        assert "## Phase Breakdown" in content
        assert "## Dependency Visualization" in content
        assert "## Migration Sequence" in content
        
        # Verify metadata
        assert "**Generated:**" in content
        assert "**Version:**" in content
        
        # Verify statistics
        assert "**Total Flows:** 2" in content
        assert "**Total Phases:** 2" in content
        
        # Verify phases
        assert "### Phase 1" in content
        assert "### Phase 2" in content
        
        # Verify table structure
        assert "| Seq | Workpackage | Flow ID | Phase | Prerequisites |" in content
        assert "|-----|-------------|---------|-------|---------------|" in content


def test_directory_creation():
    """Test that output directories are created if they don't exist."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir) / "nested" / "output" / "dir"
        generator = OutputGenerator(output_base, "test_project")
        
        assert output_base.exists(), "Nested directories should be created"


def test_file_writing_to_configured_paths():
    """Test that files are written to the configured output base path with subfolders."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir) / "custom_output"
        generator = OutputGenerator(output_base, "test_project")
        
        # Create minimal test data
        workpackages = [
            WorkpackageAssignment(
                workpackage_id=1,
                flow_id="FLOW001",
                priority_score=10.0,
                preexistent_modules=[]
            )
        ]
        
        phases = [
            PhaseAssignment(phase_id=1, workpackages=[1], dependencies=[])
        ]
        
        # Generate status file
        status_path = generator.generate_status_json(workpackages, phases)
        
        # Verify file is in correct location (progress subfolder)
        assert status_path.parent == output_base / "progress"
        assert status_path.exists()
