"""Unit tests for CLI module."""

import json
import sys
import tempfile
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest

from tools.migration_planner.cli import parse_arguments, main
from tools.migration_planner import __version__


class TestParseArguments:
    """Test argument parsing."""
    
    def test_parse_arguments_with_defaults(self, tmp_path):
        """Test argument parsing with default values."""
        # Create a temporary flows file
        flows_file = tmp_path / "flows.json"
        flows_file.write_text('{"flows": []}')
        
        args = parse_arguments(['--flows-file', str(flows_file)])
        
        assert args.flows_file == flows_file
        assert args.classifications_file is None
        assert args.output_base == Path('./results/migration/')
        assert args.project_name is not None
        assert args.log_level == 'INFO'
    
    def test_parse_arguments_with_custom_values(self, tmp_path):
        """Test argument parsing with custom values."""
        # Create temporary files
        flows_file = tmp_path / "custom_flows.json"
        flows_file.write_text('{"flows": []}')
        
        classifications_file = tmp_path / "classifications.json"
        classifications_file.write_text('{}')
        
        output_dir = tmp_path / "output"
        
        args = parse_arguments([
            '--flows-file', str(flows_file),
            '--classifications-file', str(classifications_file),
            '--output-base', str(output_dir),
            '--project-name', 'my-project',
            '--log-level', 'DEBUG'
        ])
        
        assert args.flows_file == flows_file
        assert args.classifications_file == classifications_file
        assert args.output_base == output_dir
        assert args.project_name == 'my-project'
        assert args.log_level == 'DEBUG'
    
    def test_parse_arguments_version(self):
        """Test --version argument."""
        with pytest.raises(SystemExit) as exc_info:
            parse_arguments(['--version'])
        
        assert exc_info.value.code == 0
    
    def test_parse_arguments_help(self):
        """Test --help argument."""
        with pytest.raises(SystemExit) as exc_info:
            parse_arguments(['--help'])
        
        assert exc_info.value.code == 0
    
    def test_parse_arguments_missing_flows_file_error(self):
        """Test error when flows file doesn't exist."""
        with pytest.raises(SystemExit) as exc_info:
            parse_arguments(['--flows-file', '/nonexistent/file.json'])
        
        assert exc_info.value.code != 0
    
    def test_parse_arguments_extracts_project_name_from_path(self, tmp_path):
        """Test project name extraction from flows file path."""
        # Create directory structure: results/my_project/flows/
        project_dir = tmp_path / "results" / "my_project" / "flows"
        project_dir.mkdir(parents=True)
        
        flows_file = project_dir / "Business_Flows.json"
        flows_file.write_text('{"flows": []}')
        
        args = parse_arguments(['--flows-file', str(flows_file)])
        
        assert args.project_name == 'my_project'
    
    def test_parse_arguments_default_project_name_when_no_results_dir(self, tmp_path):
        """Test default project name when path doesn't contain 'results'."""
        flows_file = tmp_path / "flows.json"
        flows_file.write_text('{"flows": []}')
        
        args = parse_arguments(['--flows-file', str(flows_file)])
        
        assert args.project_name == 'migration_project'
    
    def test_parse_arguments_log_level_choices(self, tmp_path):
        """Test log level validation."""
        flows_file = tmp_path / "flows.json"
        flows_file.write_text('{"flows": []}')
        
        # Valid log levels
        for level in ['DEBUG', 'INFO', 'WARNING', 'ERROR']:
            args = parse_arguments([
                '--flows-file', str(flows_file),
                '--log-level', level
            ])
            assert args.log_level == level
        
        # Invalid log level
        with pytest.raises(SystemExit):
            parse_arguments([
                '--flows-file', str(flows_file),
                '--log-level', 'INVALID'
            ])
    
    def test_parse_arguments_converts_paths_to_path_objects(self, tmp_path):
        """Test that string paths are converted to Path objects."""
        flows_file = tmp_path / "flows.json"
        flows_file.write_text('{"flows": []}')
        
        args = parse_arguments(['--flows-file', str(flows_file)])
        
        assert isinstance(args.flows_file, Path)
        assert isinstance(args.output_base, Path)


class TestMain:
    """Test main CLI entry point."""
    
    def test_main_success(self, tmp_path):
        """Test successful execution."""
        # Create test data
        flows_file = tmp_path / "flows.json"
        flows_data = {
            'flows': [{
                'flowId': 'TEST_FLOW',
                'name': 'Test Flow',
                'scope': {
                    'programs': [{'name': 'PROG1', 'isUtility': False}]
                },
                'complexity': {
                    'totalPrograms': 1,
                    'compositeScore': 10.0
                },
                'dependencies': {
                    'requiredFlows': [],
                    'dependentFlows': []
                }
            }]
        }
        flows_file.write_text(json.dumps(flows_data))
        
        output_dir = tmp_path / "output"
        
        # Mock sys.argv
        with patch.object(sys, 'argv', [
            'migration-planner',
            '--flows-file', str(flows_file),
            '--output-base', str(output_dir),
            '--log-level', 'ERROR'  # Suppress logs
        ]):
            exit_code = main()
        
        assert exit_code == 0
        
        # Verify output files were created
        assert (output_dir / 'Workpackage_Planning.json').exists()
        assert (output_dir / 'progress' / 'Workpackage_Status.json').exists()
        assert (output_dir / 'reports' / 'Workpackage_Definition_Roadmap.md').exists()
    
    def test_main_file_not_found_error(self):
        """Test exit code for file not found error."""
        with patch.object(sys, 'argv', [
            'migration-planner',
            '--flows-file', '/nonexistent/file.json'
        ]):
            # argparse will raise SystemExit(2) for missing file
            with pytest.raises(SystemExit) as exc_info:
                main()
            
            assert exc_info.value.code == 2
    
    def test_main_validation_error(self, tmp_path):
        """Test exit code for validation error."""
        # Create invalid JSON file
        flows_file = tmp_path / "invalid.json"
        flows_file.write_text('{"flows": [invalid}')
        
        with patch.object(sys, 'argv', [
            'migration-planner',
            '--flows-file', str(flows_file)
        ]):
            exit_code = main()
        
        assert exit_code != 0
    
    def test_main_circular_dependency_error(self, tmp_path):
        """Test exit code for circular dependency error."""
        # Create flows with circular dependency
        flows_file = tmp_path / "circular.json"
        flows_data = {
            'flows': [
                {
                    'flowId': 'FLOW1',
                    'name': 'Flow 1',
                    'scope': {'programs': [{'name': 'PROG1', 'isUtility': False}]},
                    'complexity': {'totalPrograms': 1, 'compositeScore': 10.0},
                    'dependencies': {'requiredFlows': ['FLOW2'], 'dependentFlows': []}
                },
                {
                    'flowId': 'FLOW2',
                    'name': 'Flow 2',
                    'scope': {'programs': [{'name': 'PROG2', 'isUtility': False}]},
                    'complexity': {'totalPrograms': 1, 'compositeScore': 10.0},
                    'dependencies': {'requiredFlows': ['FLOW1'], 'dependentFlows': []}
                }
            ]
        }
        flows_file.write_text(json.dumps(flows_data))
        
        with patch.object(sys, 'argv', [
            'migration-planner',
            '--flows-file', str(flows_file)
        ]):
            exit_code = main()
        
        assert exit_code != 0


class TestCLIIntegration:
    """Integration tests for CLI."""
    
    def test_cli_as_module(self, tmp_path):
        """Test running CLI as a module."""
        # Create test data
        flows_file = tmp_path / "flows.json"
        flows_data = {
            'flows': [{
                'flowId': 'TEST_FLOW',
                'name': 'Test Flow',
                'scope': {'programs': [{'name': 'PROG1', 'isUtility': False}]},
                'complexity': {'totalPrograms': 1, 'compositeScore': 10.0},
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        flows_file.write_text(json.dumps(flows_data))
        
        output_dir = tmp_path / "output"
        
        # Run as module
        result = subprocess.run(
            [sys.executable, '-m', 'tools.migration_planner',
             '--flows-file', str(flows_file),
             '--output-base', str(output_dir),
             '--log-level', 'ERROR'],
            capture_output=True,
            text=True
        )
        
        assert result.returncode == 0
        assert (output_dir / 'Workpackage_Planning.json').exists()
    
    def test_cli_version_output(self):
        """Test --version output."""
        result = subprocess.run(
            [sys.executable, '-m', 'tools.migration_planner', '--version'],
            capture_output=True,
            text=True
        )
        
        assert result.returncode == 0
        assert __version__ in result.stdout or __version__ in result.stderr
    
    def test_cli_help_output(self):
        """Test --help output."""
        result = subprocess.run(
            [sys.executable, '-m', 'tools.migration_planner', '--help'],
            capture_output=True,
            text=True
        )
        
        assert result.returncode == 0
        output = result.stdout + result.stderr
        assert 'migration' in output.lower()
        assert 'flows-file' in output.lower()
    
    def test_cli_missing_file_exit_code(self):
        """Test exit code when file is missing."""
        result = subprocess.run(
            [sys.executable, '-m', 'tools.migration_planner',
             '--flows-file', '/nonexistent/file.json'],
            capture_output=True,
            text=True
        )
        
        assert result.returncode != 0
        assert 'error' in (result.stdout + result.stderr).lower()
    
    def test_cli_invalid_json_exit_code(self, tmp_path):
        """Test exit code for invalid JSON."""
        flows_file = tmp_path / "invalid.json"
        flows_file.write_text('{"flows": [invalid}')
        
        result = subprocess.run(
            [sys.executable, '-m', 'tools.migration_planner',
             '--flows-file', str(flows_file)],
            capture_output=True,
            text=True
        )
        
        assert result.returncode != 0
        assert 'error' in (result.stdout + result.stderr).lower()


class TestErrorCodes:
    """Test specific error codes."""
    
    def test_file_not_found_returns_code_2(self):
        """Test that file not found returns exit code 2."""
        with patch.object(sys, 'argv', [
            'migration-planner',
            '--flows-file', '/nonexistent/file.json'
        ]):
            # argparse will raise SystemExit(2) for missing file
            with pytest.raises(SystemExit) as exc_info:
                main()
            
            assert exc_info.value.code == 2
    
    def test_validation_error_returns_code_1(self, tmp_path):
        """Test that validation error returns exit code 1."""
        flows_file = tmp_path / "invalid.json"
        flows_file.write_text('{"flows": [invalid}')
        
        with patch.object(sys, 'argv', [
            'migration-planner',
            '--flows-file', str(flows_file)
        ]):
            exit_code = main()
        
        assert exit_code == 1
    
    def test_circular_dependency_returns_code_3(self, tmp_path):
        """Test that circular dependency returns exit code 3."""
        flows_file = tmp_path / "circular.json"
        flows_data = {
            'flows': [
                {
                    'flowId': 'FLOW1',
                    'name': 'Flow 1',
                    'scope': {'programs': [{'name': 'PROG1', 'isUtility': False}]},
                    'complexity': {'totalPrograms': 1, 'compositeScore': 10.0},
                    'dependencies': {'requiredFlows': ['FLOW2'], 'dependentFlows': []}
                },
                {
                    'flowId': 'FLOW2',
                    'name': 'Flow 2',
                    'scope': {'programs': [{'name': 'PROG2', 'isUtility': False}]},
                    'complexity': {'totalPrograms': 1, 'compositeScore': 10.0},
                    'dependencies': {'requiredFlows': ['FLOW1'], 'dependentFlows': []}
                }
            ]
        }
        flows_file.write_text(json.dumps(flows_data))
        
        with patch.object(sys, 'argv', [
            'migration-planner',
            '--flows-file', str(flows_file)
        ]):
            exit_code = main()
        
        assert exit_code == 3
