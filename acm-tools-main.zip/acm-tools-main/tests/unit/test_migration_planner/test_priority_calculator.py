"""
Unit tests for PriorityCalculator.

Tests specific examples and edge cases for priority calculation.
Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10, 1.11
"""

import pytest
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.priority.priority_calculator import PriorityCalculator


class TestPriorityCalculator:
    """Test suite for PriorityCalculator class."""
    
    def test_priority_with_all_bonuses_applied(self):
        """
        Test priority calculation with all bonuses applied.
        
        Flow characteristics:
        - 3 programs (simple flow bonus: -3)
        - Has databases (complete flow bonus: -5)
        - 2 common modules
        - Composite score: 10.0
        
        Expected: (3 * 2) + (2 * 3) + (10.0 * 0.5) + (-5) + (-3) = 6 + 6 + 5 - 5 - 3 = 9.0
        """
        programs = [
            Program(name="PROG1", is_utility=False),
            Program(name="PROG2", is_utility=False),
            Program(name="PROG3", is_utility=False)
        ]
        
        flow = BusinessFlow(
            flow_id="FLOW001",
            name="Test Flow with All Bonuses",
            programs=programs,
            databases=["DB1", "DB2"],
            total_programs=3,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        classifications = {
            "PROG1": "COMMONLY_USED",
            "PROG2": "COMMONLY_USED",
            "PROG3": "UTILITY"
        }
        
        calculator = PriorityCalculator(classifications=classifications)
        result = calculator.calculate_priority(flow)
        
        assert result.priority_score == 9.0
        assert result.flow_id == "FLOW001"
        assert result.factors.total_programs == 3
        assert result.factors.common_modules == 2
        assert result.factors.composite_score == 10.0
        assert result.factors.complete_flow_bonus == -5
        assert result.factors.simple_flow_bonus == -3
    
    def test_priority_with_no_bonuses(self):
        """
        Test priority calculation with no bonuses.
        
        Flow characteristics:
        - 10 programs (no simple flow bonus: 0)
        - No databases (no complete flow bonus: 0)
        - 0 common modules
        - Composite score: 20.0
        
        Expected: (10 * 2) + (0 * 3) + (20.0 * 0.5) + 0 + 0 = 20 + 0 + 10 + 0 + 0 = 30.0
        """
        programs = [Program(name=f"PROG{i}", is_utility=False) for i in range(10)]
        
        flow = BusinessFlow(
            flow_id="FLOW002",
            name="Test Flow with No Bonuses",
            programs=programs,
            databases=[],
            total_programs=10,
            composite_score=20.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.priority_score == 30.0
        assert result.factors.total_programs == 10
        assert result.factors.common_modules == 0
        assert result.factors.composite_score == 20.0
        assert result.factors.complete_flow_bonus == 0
        assert result.factors.simple_flow_bonus == 0
    
    def test_priority_with_missing_classifications(self):
        """
        Test priority calculation when classifications file is not provided.
        
        Flow characteristics:
        - 5 programs (simple flow bonus: -1)
        - Has databases (complete flow bonus: -5)
        - No classifications provided (common modules: 0)
        - Composite score: 15.0
        
        Expected: (5 * 2) + (0 * 3) + (15.0 * 0.5) + (-5) + (-1) = 10 + 0 + 7.5 - 5 - 1 = 11.5
        """
        programs = [Program(name=f"PROG{i}", is_utility=False) for i in range(5)]
        
        flow = BusinessFlow(
            flow_id="FLOW003",
            name="Test Flow without Classifications",
            programs=programs,
            databases=["DB1"],
            total_programs=5,
            composite_score=15.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications=None)
        result = calculator.calculate_priority(flow)
        
        assert result.priority_score == 11.5
        assert result.factors.common_modules == 0
    
    def test_priority_with_zero_programs(self):
        """
        Test priority calculation with 0 programs (edge case).
        
        Flow characteristics:
        - 0 programs (simple flow bonus: -3, since 0 <= 3)
        - No databases (complete flow bonus: 0)
        - Composite score: 5.0
        
        Expected: (0 * 2) + (0 * 3) + (5.0 * 0.5) + 0 + (-3) = 0 + 0 + 2.5 + 0 - 3 = -0.5
        """
        flow = BusinessFlow(
            flow_id="FLOW004",
            name="Empty Flow",
            programs=[],
            databases=[],
            total_programs=0,
            composite_score=5.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.priority_score == -0.5
        assert result.factors.total_programs == 0
        assert result.factors.simple_flow_bonus == -3
    
    def test_priority_with_very_high_composite_score(self):
        """
        Test priority calculation with very high composite score (edge case).
        
        Flow characteristics:
        - 1 program (simple flow bonus: -3)
        - No databases (complete flow bonus: 0)
        - Composite score: 1000.0
        
        Expected: (1 * 2) + (0 * 3) + (1000.0 * 0.5) + 0 + (-3) = 2 + 0 + 500 + 0 - 3 = 499.0
        """
        programs = [Program(name="PROG1", is_utility=False)]
        
        flow = BusinessFlow(
            flow_id="FLOW005",
            name="High Complexity Flow",
            programs=programs,
            databases=[],
            total_programs=1,
            composite_score=1000.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.priority_score == 499.0
        assert result.factors.composite_score == 1000.0
    
    def test_simple_flow_bonus_boundary_at_3(self):
        """
        Test simple flow bonus at boundary (exactly 3 programs).
        
        Expected bonus: -3
        """
        programs = [Program(name=f"PROG{i}", is_utility=False) for i in range(3)]
        
        flow = BusinessFlow(
            flow_id="FLOW006",
            name="Boundary Test - 3 Programs",
            programs=programs,
            databases=[],
            total_programs=3,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.factors.simple_flow_bonus == -3
    
    def test_simple_flow_bonus_boundary_at_4(self):
        """
        Test simple flow bonus just above boundary (4 programs).
        
        Expected bonus: -1
        """
        programs = [Program(name=f"PROG{i}", is_utility=False) for i in range(4)]
        
        flow = BusinessFlow(
            flow_id="FLOW007",
            name="Boundary Test - 4 Programs",
            programs=programs,
            databases=[],
            total_programs=4,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.factors.simple_flow_bonus == -1
    
    def test_simple_flow_bonus_boundary_at_5(self):
        """
        Test simple flow bonus at upper boundary (exactly 5 programs).
        
        Expected bonus: -1
        """
        programs = [Program(name=f"PROG{i}", is_utility=False) for i in range(5)]
        
        flow = BusinessFlow(
            flow_id="FLOW008",
            name="Boundary Test - 5 Programs",
            programs=programs,
            databases=[],
            total_programs=5,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.factors.simple_flow_bonus == -1
    
    def test_simple_flow_bonus_boundary_at_6(self):
        """
        Test simple flow bonus just above upper boundary (6 programs).
        
        Expected bonus: 0
        """
        programs = [Program(name=f"PROG{i}", is_utility=False) for i in range(6)]
        
        flow = BusinessFlow(
            flow_id="FLOW009",
            name="Boundary Test - 6 Programs",
            programs=programs,
            databases=[],
            total_programs=6,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.factors.simple_flow_bonus == 0
    
    def test_complete_flow_bonus_with_single_database(self):
        """
        Test complete flow bonus with exactly one database.
        
        Expected bonus: -5
        """
        flow = BusinessFlow(
            flow_id="FLOW010",
            name="Single Database Flow",
            programs=[Program(name="PROG1", is_utility=False)],
            databases=["DB1"],
            total_programs=1,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.factors.complete_flow_bonus == -5
    
    def test_complete_flow_bonus_with_multiple_databases(self):
        """
        Test complete flow bonus with multiple databases.
        
        Expected bonus: -5 (same as single database)
        """
        flow = BusinessFlow(
            flow_id="FLOW011",
            name="Multiple Database Flow",
            programs=[Program(name="PROG1", is_utility=False)],
            databases=["DB1", "DB2", "DB3"],
            total_programs=1,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        calculator = PriorityCalculator(classifications={})
        result = calculator.calculate_priority(flow)
        
        assert result.factors.complete_flow_bonus == -5
    
    def test_calculate_all_priorities(self):
        """
        Test calculate_all_priorities method with multiple flows.
        """
        flows = [
            BusinessFlow(
                flow_id="FLOW001",
                name="Flow 1",
                programs=[Program(name="PROG1", is_utility=False)],
                databases=[],
                total_programs=1,
                composite_score=5.0,
                required_flows=[],
                dependent_flows=[]
            ),
            BusinessFlow(
                flow_id="FLOW002",
                name="Flow 2",
                programs=[Program(name=f"PROG{i}", is_utility=False) for i in range(10)],
                databases=["DB1"],
                total_programs=10,
                composite_score=20.0,
                required_flows=[],
                dependent_flows=[]
            )
        ]
        
        calculator = PriorityCalculator(classifications={})
        results = calculator.calculate_all_priorities(flows)
        
        assert len(results) == 2
        assert "FLOW001" in results
        assert "FLOW002" in results
        assert results["FLOW001"].flow_id == "FLOW001"
        assert results["FLOW002"].flow_id == "FLOW002"
    
    def test_common_modules_count_with_partial_classifications(self):
        """
        Test common modules count when only some programs are classified.
        """
        programs = [
            Program(name="PROG1", is_utility=False),
            Program(name="PROG2", is_utility=False),
            Program(name="PROG3", is_utility=False)
        ]
        
        flow = BusinessFlow(
            flow_id="FLOW012",
            name="Partial Classifications",
            programs=programs,
            databases=[],
            total_programs=3,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        # Only PROG1 is classified as COMMONLY_USED, PROG2 is not in classifications
        classifications = {
            "PROG1": "COMMONLY_USED",
            "PROG3": "UTILITY"
        }
        
        calculator = PriorityCalculator(classifications=classifications)
        result = calculator.calculate_priority(flow)
        
        assert result.factors.common_modules == 1
    
    def test_common_modules_count_with_all_common(self):
        """
        Test common modules count when all programs are COMMONLY_USED.
        """
        programs = [
            Program(name="PROG1", is_utility=False),
            Program(name="PROG2", is_utility=False),
            Program(name="PROG3", is_utility=False)
        ]
        
        flow = BusinessFlow(
            flow_id="FLOW013",
            name="All Common Modules",
            programs=programs,
            databases=[],
            total_programs=3,
            composite_score=0.0,
            required_flows=[],
            dependent_flows=[]
        )
        
        classifications = {
            "PROG1": "COMMONLY_USED",
            "PROG2": "COMMONLY_USED",
            "PROG3": "COMMONLY_USED"
        }
        
        calculator = PriorityCalculator(classifications=classifications)
        result = calculator.calculate_priority(flow)
        
        assert result.factors.common_modules == 3
