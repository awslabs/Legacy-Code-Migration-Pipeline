"""
Unit tests for input module in migration workpackage planner.

Tests cover:
- Valid flow loading
- Missing required fields error handling
- Missing optional file handling
- Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7
"""

import json
import tempfile
import pytest
from pathlib import Path

from tools.migration_planner.input import FlowDataLoader
from tools.migration_planner.models import BusinessFlow, Program


class TestFlowDataLoader:
    """Test suite for FlowDataLoader class."""
    
    def test_load_valid_flows(self):
        """Test loading valid flows from JSON file."""
        # Requirement 4.1: Read Business_Flows.json from configured path
        loader = FlowDataLoader()
        
        # Create test data
        flows_data = {
            'flows': [
                {
                    'flowId': 'FLOW001',
                    'name': 'Test Flow 1',
                    'scope': {
                        'programs': [
                            {'name': 'PROG001', 'isUtility': False},
                            {'name': 'PROG002', 'isUtility': True}
                        ]
                    },
                    'complexity': {
                        'totalPrograms': 2,
                        'compositeScore': 15.5
                    },
                    'dependencies': {
                        'requiredFlows': ['FLOW002'],
                        'dependentFlows': []
                    },
                    'dataOperations': {
                        'databases': ['DB001', 'DB002']
                    }
                }
            ]
        }
        
        # Write to temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            # Load flows
            flows = loader.load_flows(temp_path)
            
            # Verify results
            assert len(flows) == 1
            flow = flows[0]
            assert isinstance(flow, BusinessFlow)
            assert flow.flow_id == 'FLOW001'
            assert flow.name == 'Test Flow 1'
            assert len(flow.programs) == 2
            assert flow.programs[0].name == 'PROG001'
            assert flow.programs[0].is_utility is False
            assert flow.programs[1].name == 'PROG002'
            assert flow.programs[1].is_utility is True
            assert flow.total_programs == 2
            assert flow.composite_score == 15.5
            assert flow.required_flows == ['FLOW002']
            assert flow.dependent_flows == []
            assert flow.databases == ['DB001', 'DB002']
        
        finally:
            temp_path.unlink()
    
    def test_load_multiple_flows(self):
        """Test loading multiple flows from JSON file."""
        # Requirement 4.1, 4.2
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [
                {
                    'flowId': 'FLOW001',
                    'name': 'Flow 1',
                    'scope': {'programs': [{'name': 'PROG001'}]},
                    'complexity': {'totalPrograms': 1},
                    'dependencies': {'requiredFlows': [], 'dependentFlows': []}
                },
                {
                    'flowId': 'FLOW002',
                    'name': 'Flow 2',
                    'scope': {'programs': [{'name': 'PROG002'}]},
                    'complexity': {'totalPrograms': 1},
                    'dependencies': {'requiredFlows': [], 'dependentFlows': []}
                },
                {
                    'flowId': 'FLOW003',
                    'name': 'Flow 3',
                    'scope': {'programs': [{'name': 'PROG003'}]},
                    'complexity': {'totalPrograms': 1},
                    'dependencies': {'requiredFlows': [], 'dependentFlows': []}
                }
            ]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            flows = loader.load_flows(temp_path)
            assert len(flows) == 3
            assert flows[0].flow_id == 'FLOW001'
            assert flows[1].flow_id == 'FLOW002'
            assert flows[2].flow_id == 'FLOW003'
        finally:
            temp_path.unlink()
    
    def test_missing_file_raises_error(self):
        """Test that missing file raises FileNotFoundError."""
        # Requirement 4.1
        loader = FlowDataLoader()
        non_existent_path = Path('/tmp/nonexistent_file_12345.json')
        
        with pytest.raises(FileNotFoundError) as exc_info:
            loader.load_flows(non_existent_path)
        
        assert 'not found' in str(exc_info.value).lower()
    
    def test_invalid_json_raises_error(self):
        """Test that invalid JSON raises ValueError."""
        # Requirement 4.2
        loader = FlowDataLoader()
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('{"flows": [invalid json}')
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            assert 'json' in str(exc_info.value).lower()
        finally:
            temp_path.unlink()
    
    def test_missing_flows_array_raises_error(self):
        """Test that missing 'flows' array raises ValueError."""
        # Requirement 4.2
        loader = FlowDataLoader()
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump({'data': []}, f)  # Wrong key
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            assert 'flows' in str(exc_info.value).lower()
        finally:
            temp_path.unlink()
    
    def test_missing_flowid_raises_error(self):
        """Test that missing flowId raises ValueError."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'name': 'Test Flow',
                'scope': {'programs': [{'name': 'PROG001'}]},
                'complexity': {'totalPrograms': 1},
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            error_msg = str(exc_info.value).lower()
            assert 'flowid' in error_msg or 'missing' in error_msg
        finally:
            temp_path.unlink()
    
    def test_missing_scope_raises_error(self):
        """Test that missing scope raises ValueError."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'complexity': {'totalPrograms': 1},
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            error_msg = str(exc_info.value).lower()
            assert 'scope' in error_msg or 'missing' in error_msg
        finally:
            temp_path.unlink()
    
    def test_missing_programs_raises_error(self):
        """Test that missing scope.programs raises ValueError."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'scope': {},  # Missing programs
                'complexity': {'totalPrograms': 1},
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            error_msg = str(exc_info.value).lower()
            assert 'programs' in error_msg or 'missing' in error_msg
        finally:
            temp_path.unlink()
    
    def test_missing_complexity_raises_error(self):
        """Test that missing complexity raises ValueError."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'scope': {'programs': [{'name': 'PROG001'}]},
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            error_msg = str(exc_info.value).lower()
            assert 'complexity' in error_msg or 'missing' in error_msg
        finally:
            temp_path.unlink()
    
    def test_missing_total_programs_raises_error(self):
        """Test that missing complexity.totalPrograms raises ValueError."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'scope': {'programs': [{'name': 'PROG001'}]},
                'complexity': {},  # Missing totalPrograms
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            error_msg = str(exc_info.value).lower()
            assert 'totalprograms' in error_msg or 'missing' in error_msg
        finally:
            temp_path.unlink()
    
    def test_missing_dependencies_raises_error(self):
        """Test that missing dependencies raises ValueError."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'scope': {'programs': [{'name': 'PROG001'}]},
                'complexity': {'totalPrograms': 1}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            error_msg = str(exc_info.value).lower()
            assert 'dependencies' in error_msg or 'missing' in error_msg
        finally:
            temp_path.unlink()
    
    def test_missing_program_name_raises_error(self):
        """Test that program without name raises ValueError."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'scope': {'programs': [{'isUtility': True}]},  # Missing name
                'complexity': {'totalPrograms': 1},
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            with pytest.raises(ValueError) as exc_info:
                loader.load_flows(temp_path)
            
            error_msg = str(exc_info.value).lower()
            assert 'name' in error_msg
        finally:
            temp_path.unlink()
    
    def test_missing_composite_score_defaults_to_zero(self):
        """Test that missing compositeScore defaults to 0."""
        # Requirement 4.7
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'scope': {'programs': [{'name': 'PROG001'}]},
                'complexity': {'totalPrograms': 1},  # No compositeScore
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            flows = loader.load_flows(temp_path)
            assert len(flows) == 1
            assert flows[0].composite_score == 0.0
        finally:
            temp_path.unlink()
    
    def test_missing_databases_defaults_to_empty_list(self):
        """Test that missing dataOperations.databases defaults to empty list."""
        # Requirement 4.7
        loader = FlowDataLoader()
        
        flows_data = {
            'flows': [{
                'flowId': 'FLOW001',
                'scope': {'programs': [{'name': 'PROG001'}]},
                'complexity': {'totalPrograms': 1},
                'dependencies': {'requiredFlows': [], 'dependentFlows': []}
                # No dataOperations
            }]
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
        
        try:
            flows = loader.load_flows(temp_path)
            assert len(flows) == 1
            assert flows[0].databases == []
        finally:
            temp_path.unlink()
    
    def test_load_classifications_valid_file(self):
        """Test loading valid classifications file."""
        # Requirement 4.3
        loader = FlowDataLoader()
        
        classifications_data = {
            'PROG001': 'COMMONLY_USED',
            'PROG002': 'UTILITY',
            'PROG003': 'COMMONLY_USED'
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(classifications_data, f)
            temp_path = Path(f.name)
        
        try:
            classifications = loader.load_classifications(temp_path)
            assert len(classifications) == 3
            assert classifications['PROG001'] == 'COMMONLY_USED'
            assert classifications['PROG002'] == 'UTILITY'
            assert classifications['PROG003'] == 'COMMONLY_USED'
        finally:
            temp_path.unlink()
    
    def test_load_classifications_none_path(self):
        """Test loading classifications with None path returns empty dict."""
        # Requirement 4.4
        loader = FlowDataLoader()
        
        classifications = loader.load_classifications(None)
        assert classifications == {}
        assert loader.classifications == {}
    
    def test_load_classifications_missing_file(self):
        """Test loading classifications with missing file returns empty dict."""
        # Requirement 4.4
        loader = FlowDataLoader()
        
        non_existent_path = Path('/tmp/nonexistent_classifications_12345.json')
        classifications = loader.load_classifications(non_existent_path)
        
        assert classifications == {}
        assert loader.classifications == {}
    
    def test_load_classifications_invalid_json(self):
        """Test loading classifications with invalid JSON returns empty dict."""
        # Requirement 4.4
        loader = FlowDataLoader()
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('invalid json')
            temp_path = Path(f.name)
        
        try:
            classifications = loader.load_classifications(temp_path)
            assert classifications == {}
            assert loader.classifications == {}
        finally:
            temp_path.unlink()
    
    def test_validate_flow_with_all_fields(self):
        """Test validate_flow with all fields present."""
        # Requirement 4.5, 4.6
        loader = FlowDataLoader()
        
        flow_data = {
            'flowId': 'FLOW001',
            'name': 'Test Flow',
            'scope': {
                'programs': [
                    {'name': 'PROG001', 'isUtility': False},
                    {'name': 'PROG002', 'isUtility': True}
                ]
            },
            'complexity': {
                'totalPrograms': 2,
                'compositeScore': 25.0
            },
            'dependencies': {
                'requiredFlows': ['FLOW002'],
                'dependentFlows': ['FLOW003']
            },
            'dataOperations': {
                'databases': ['DB001']
            }
        }
        
        flow = loader.validate_flow(flow_data)
        
        assert isinstance(flow, BusinessFlow)
        assert flow.flow_id == 'FLOW001'
        assert flow.name == 'Test Flow'
        assert len(flow.programs) == 2
        assert flow.total_programs == 2
        assert flow.composite_score == 25.0
        assert flow.required_flows == ['FLOW002']
        assert flow.dependent_flows == ['FLOW003']
        assert flow.databases == ['DB001']
    
    def test_validate_flow_with_minimal_fields(self):
        """Test validate_flow with only required fields."""
        # Requirement 4.7
        loader = FlowDataLoader()
        
        flow_data = {
            'flowId': 'FLOW001',
            'scope': {
                'programs': [{'name': 'PROG001'}]
            },
            'complexity': {
                'totalPrograms': 1
            },
            'dependencies': {
                'requiredFlows': [],
                'dependentFlows': []
            }
        }
        
        flow = loader.validate_flow(flow_data)
        
        assert flow.flow_id == 'FLOW001'
        assert flow.name == 'FLOW001'  # Defaults to flowId
        assert flow.composite_score == 0.0  # Default
        assert flow.databases == []  # Default
