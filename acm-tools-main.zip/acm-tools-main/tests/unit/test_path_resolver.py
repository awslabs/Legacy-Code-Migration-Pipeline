"""
Unit tests for PathResolver.

Tests path resolution, caching, prefix detection, and error handling.
"""

import pytest
from pathlib import Path
from tools.atx.dependency_transformer.loaders.path_resolver import PathResolver


class TestPathResolverInitialization:
    """Test PathResolver initialization."""
    
    def test_default_search_paths(self):
        """Test initialization with default search paths."""
        resolver = PathResolver()
        assert resolver.search_paths == ['.', './examples/code']
    
    def test_custom_search_paths(self):
        """Test initialization with custom search paths."""
        custom_paths = ['./custom/path1', './custom/path2']
        resolver = PathResolver(search_paths=custom_paths)
        assert resolver.search_paths == custom_paths
    
    def test_empty_search_paths(self):
        """Test initialization with empty search paths list defaults to standard paths."""
        resolver = PathResolver(search_paths=[])
        # Empty list triggers default behavior (or operator)
        assert resolver.search_paths == ['.', './examples/code']


class TestPathResolution:
    """Test path resolution functionality."""
    
    def test_resolve_nonexistent_file(self):
        """Test resolving a non-existent file returns None."""
        resolver = PathResolver(search_paths=['.'])
        result = resolver.resolve_path('nonexistent/path/to/file.cbl')
        assert result is None
    
    def test_resolve_with_empty_path(self):
        """Test resolving an empty path."""
        resolver = PathResolver()
        result = resolver.resolve_path('')
        assert result is None
    
    def test_resolve_existing_file(self):
        """Test resolving an existing file."""
        resolver = PathResolver(search_paths=['.', './examples/code'])
        
        # Try to resolve a known file (if it exists)
        test_path = 'aws-mainframe-modernization-carddemo-main/app/cbl/COMEN01C.cbl'
        result = resolver.resolve_path(test_path)
        
        # If the file exists, result should be a valid path
        if result:
            assert Path(result).exists()
            assert result.endswith('COMEN01C.cbl')


class TestCaching:
    """Test caching behavior."""
    
    def test_cache_hit_for_resolved_path(self):
        """Test that resolved paths are cached."""
        resolver = PathResolver()
        
        # Resolve a path twice
        path = 'test/path/file.cbl'
        result1 = resolver.resolve_path(path)
        result2 = resolver.resolve_path(path)
        
        # Results should be identical
        assert result1 == result2
        
        # Check cache statistics
        stats = resolver.get_statistics()
        assert stats['cached_paths'] >= 1
    
    def test_cache_hit_for_missing_file(self):
        """Test that missing files are cached."""
        resolver = PathResolver()
        
        # Try to resolve a non-existent file twice
        path = 'nonexistent/file.cbl'
        result1 = resolver.resolve_path(path)
        result2 = resolver.resolve_path(path)
        
        assert result1 is None
        assert result2 is None
        
        # Check that it's tracked as missing
        stats = resolver.get_statistics()
        assert stats['missing_files'] == 1
    
    def test_clear_cache(self):
        """Test clearing the cache."""
        resolver = PathResolver()
        
        # Resolve some paths
        resolver.resolve_path('test1.cbl')
        resolver.resolve_path('test2.cbl')
        
        # Verify cache has entries
        stats_before = resolver.get_statistics()
        assert stats_before['cached_paths'] > 0 or stats_before['missing_files'] > 0
        
        # Clear cache
        resolver.clear_cache()
        
        # Verify cache is empty
        stats_after = resolver.get_statistics()
        assert stats_after['cached_paths'] == 0
        assert stats_after['prefix_mappings'] == 0
        assert stats_after['missing_files'] == 0


class TestPrefixMapping:
    """Test prefix mapping detection and caching."""
    
    def test_get_path_mapping_empty(self):
        """Test getting path mappings when none exist."""
        resolver = PathResolver()
        mappings = resolver.get_path_mapping()
        assert isinstance(mappings, dict)
        assert len(mappings) == 0
    
    def test_get_path_mapping_returns_copy(self):
        """Test that get_path_mapping returns a copy, not the original."""
        resolver = PathResolver()
        mappings1 = resolver.get_path_mapping()
        mappings2 = resolver.get_path_mapping()
        
        # Should be equal but not the same object
        assert mappings1 == mappings2
        assert mappings1 is not mappings2
    
    def test_prefix_mapping_detection(self):
        """Test that prefix mappings are detected when files are resolved."""
        resolver = PathResolver(search_paths=['.', './examples/code'])
        
        # Try to resolve a file that might exist
        test_path = 'aws-mainframe-modernization-carddemo-main/app/cbl/COMEN01C.cbl'
        result = resolver.resolve_path(test_path)
        
        if result:
            # Check that a prefix mapping was created
            mappings = resolver.get_path_mapping()
            assert len(mappings) > 0


class TestBatchResolution:
    """Test batch path resolution."""
    
    def test_resolve_batch_empty_list(self):
        """Test batch resolution with empty list."""
        resolver = PathResolver()
        results = resolver.resolve_batch([])
        assert results == {}
    
    def test_resolve_batch_single_path(self):
        """Test batch resolution with single path."""
        resolver = PathResolver()
        paths = ['test/file.cbl']
        results = resolver.resolve_batch(paths)
        
        assert len(results) == 1
        assert 'test/file.cbl' in results
    
    def test_resolve_batch_multiple_paths(self):
        """Test batch resolution with multiple paths."""
        resolver = PathResolver()
        paths = ['test1.cbl', 'test2.cbl', 'test3.cbl']
        results = resolver.resolve_batch(paths)
        
        assert len(results) == 3
        for path in paths:
            assert path in results
    
    def test_resolve_batch_uses_cache(self):
        """Test that batch resolution uses cache."""
        resolver = PathResolver()
        
        # Resolve a path individually first
        path = 'test/file.cbl'
        resolver.resolve_path(path)
        
        # Get initial cache size
        stats_before = resolver.get_statistics()
        
        # Resolve the same path in a batch
        results = resolver.resolve_batch([path])
        
        # Cache size should not increase (path was already cached)
        stats_after = resolver.get_statistics()
        assert stats_after['cached_paths'] == stats_before['cached_paths']


class TestStatistics:
    """Test statistics tracking."""
    
    def test_initial_statistics(self):
        """Test initial statistics are all zero."""
        resolver = PathResolver()
        stats = resolver.get_statistics()
        
        assert stats['cached_paths'] == 0
        assert stats['prefix_mappings'] == 0
        assert stats['missing_files'] == 0
    
    def test_statistics_after_resolution(self):
        """Test statistics are updated after path resolution."""
        resolver = PathResolver()
        
        # Resolve some paths
        resolver.resolve_path('test1.cbl')
        resolver.resolve_path('test2.cbl')
        
        stats = resolver.get_statistics()
        
        # Should have some cached paths or missing files
        assert stats['cached_paths'] > 0 or stats['missing_files'] > 0
    
    def test_statistics_structure(self):
        """Test that statistics have the expected structure."""
        resolver = PathResolver()
        stats = resolver.get_statistics()
        
        assert 'cached_paths' in stats
        assert 'prefix_mappings' in stats
        assert 'missing_files' in stats
        assert isinstance(stats['cached_paths'], int)
        assert isinstance(stats['prefix_mappings'], int)
        assert isinstance(stats['missing_files'], int)


class TestEdgeCases:
    """Test edge cases and special scenarios."""
    
    def test_resolve_path_with_backslashes(self):
        """Test resolving paths with backslashes (Windows-style)."""
        resolver = PathResolver()
        # PathResolver should handle both forward and backslashes
        result = resolver.resolve_path('test\\path\\file.cbl')
        # Should return None or a valid path, but not crash
        assert result is None or isinstance(result, str)
    
    def test_resolve_path_with_dots(self):
        """Test resolving paths with . and .. components."""
        resolver = PathResolver()
        result = resolver.resolve_path('./test/../file.cbl')
        assert result is None or isinstance(result, str)
    
    def test_resolve_absolute_path(self):
        """Test resolving an absolute path."""
        resolver = PathResolver()
        result = resolver.resolve_path('/absolute/path/file.cbl')
        # Should handle gracefully
        assert result is None or isinstance(result, str)
    
    def test_multiple_resolvers_independent(self):
        """Test that multiple resolver instances are independent."""
        resolver1 = PathResolver(search_paths=['./path1'])
        resolver2 = PathResolver(search_paths=['./path2'])
        
        # Resolve different paths
        resolver1.resolve_path('test1.cbl')
        resolver2.resolve_path('test2.cbl')
        
        # Statistics should be independent
        stats1 = resolver1.get_statistics()
        stats2 = resolver2.get_statistics()
        
        # Each should have their own cache
        assert stats1['cached_paths'] >= 1
        assert stats2['cached_paths'] >= 1


class TestRealWorldScenarios:
    """Test real-world usage scenarios."""
    
    def test_carddemo_file_resolution(self):
        """Test resolving CardDemo files if they exist."""
        resolver = PathResolver(search_paths=['.', './examples/code', './examples/code/cobol'])
        
        # Common CardDemo file paths
        test_paths = [
            'aws-mainframe-modernization-carddemo-main/app/cbl/COMEN01C.cbl',
            'carddemo/app/cbl/COMEN01C.cbl',
            'app/cbl/COMEN01C.cbl',
        ]
        
        resolved_count = 0
        for path in test_paths:
            result = resolver.resolve_path(path)
            if result:
                assert Path(result).exists()
                assert result.endswith('COMEN01C.cbl')
                resolved_count += 1
        
        # At least one variant should resolve if CardDemo exists
        # (but test should pass even if files don't exist)
        if resolved_count > 0:
            # Verify prefix mappings were created
            mappings = resolver.get_path_mapping()
            assert len(mappings) > 0
    
    def test_mixed_existing_and_missing_files(self):
        """Test resolving a mix of existing and missing files."""
        resolver = PathResolver(search_paths=['.', './examples/code'])
        
        paths = [
            'nonexistent1.cbl',
            'aws-mainframe-modernization-carddemo-main/app/cbl/COMEN01C.cbl',
            'nonexistent2.cbl',
        ]
        
        results = resolver.resolve_batch(paths)
        
        # Should have results for all paths
        assert len(results) == 3
        
        # Some should be None (missing), some might be resolved
        none_count = sum(1 for v in results.values() if v is None)
        assert none_count >= 2  # At least the two nonexistent files


# ============================================================================
# Property-Based Tests
# ============================================================================

try:
    from hypothesis import given, strategies as st, settings
    import tempfile
    import os
    
    HYPOTHESIS_AVAILABLE = True
except ImportError:
    HYPOTHESIS_AVAILABLE = False


@pytest.mark.skipif(not HYPOTHESIS_AVAILABLE, reason="Hypothesis not available")
class TestPathResolverProperties:
    """Property-based tests for PathResolver.
    
    These tests validate universal correctness properties that should hold
    for all valid inputs.
    """
    
    @given(
        prefix=st.text(
            alphabet=st.characters(min_codepoint=97, max_codepoint=122),
            min_size=3,
            max_size=20
        ),
        suffix_parts=st.lists(
            st.text(
                alphabet=st.characters(min_codepoint=97, max_codepoint=122),
                min_size=1,
                max_size=10
            ),
            min_size=1,
            max_size=5
        ),
        num_paths=st.integers(min_value=2, max_value=10)
    )
    @settings(max_examples=50, deadline=None)
    def test_property_18_path_resolution_consistency(self, prefix, suffix_parts, num_paths):
        """
        Property 18: Path Resolution Consistency
        
        For any ATX path with a detected prefix mapping, all subsequent paths
        with the same prefix should be resolved using the same local root path.
        
        Validates: Requirements AC-4.4, AC-4.5
        """
        # Create a temporary directory structure for testing
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a subdirectory structure
            local_root = Path(tmpdir) / "local_root"
            local_root.mkdir(parents=True)
            
            # Create test files with the same prefix but different suffixes
            atx_paths = []
            for i in range(num_paths):
                # Create unique suffix for each file
                suffix = '/'.join(suffix_parts) + f'/file{i}.txt'
                atx_path = f"{prefix}/{suffix}"
                atx_paths.append(atx_path)
                
                # Create the actual file in local filesystem
                local_file = local_root / suffix
                local_file.parent.mkdir(parents=True, exist_ok=True)
                local_file.write_text(f"test content {i}")
            
            # Initialize resolver with the temp directory
            resolver = PathResolver(search_paths=[tmpdir])
            
            # Resolve all paths
            resolved_paths = []
            for atx_path in atx_paths:
                resolved = resolver.resolve_path(atx_path)
                if resolved:
                    resolved_paths.append(resolved)
            
            # If any paths were resolved, check consistency
            if len(resolved_paths) >= 2:
                # Get the prefix mappings
                mappings = resolver.get_path_mapping()
                
                # All resolved paths should use the same local root
                # Extract the local root from each resolved path
                local_roots = set()
                for resolved_path in resolved_paths:
                    # The local root is everything before the suffix
                    for atx_path in atx_paths:
                        suffix = '/'.join(suffix_parts)
                        if suffix in resolved_path:
                            local_root_part = resolved_path.split(suffix)[0].rstrip('/')
                            local_roots.add(local_root_part)
                            break
                
                # Property: All paths with the same prefix should use the same local root
                assert len(local_roots) <= 1, \
                    f"Inconsistent local roots detected: {local_roots}"
                
                # Property: The prefix mapping should be consistent
                if prefix in mappings:
                    mapped_root = mappings[prefix]
                    for resolved_path in resolved_paths:
                        assert resolved_path.startswith(mapped_root), \
                            f"Path {resolved_path} does not start with mapped root {mapped_root}"
    
    @given(
        prefix=st.text(
            alphabet=st.characters(min_codepoint=97, max_codepoint=122),
            min_size=3,
            max_size=15
        ),
        dir_parts=st.lists(
            st.text(
                alphabet=st.characters(min_codepoint=97, max_codepoint=122),
                min_size=1,
                max_size=8
            ),
            min_size=1,
            max_size=4
        ),
        filename=st.text(
            alphabet=st.characters(min_codepoint=97, max_codepoint=122),
            min_size=1,
            max_size=10
        )
    )
    @settings(max_examples=50, deadline=None)
    def test_property_19_path_structure_preservation(self, prefix, dir_parts, filename):
        """
        Property 19: Path Structure Preservation
        
        For any resolved path, the directory structure after the root prefix
        should match the directory structure in the original ATX path exactly.
        
        Validates: Requirements AC-4.5
        """
        # Create a temporary directory structure
        with tempfile.TemporaryDirectory() as tmpdir:
            # Build the ATX path
            dir_structure = '/'.join(dir_parts)
            atx_path = f"{prefix}/{dir_structure}/{filename}.txt"
            
            # Create the local file with a different root
            local_root = Path(tmpdir) / "different_root"
            local_file = local_root / dir_structure / f"{filename}.txt"
            local_file.parent.mkdir(parents=True, exist_ok=True)
            local_file.write_text("test content")
            
            # Initialize resolver
            resolver = PathResolver(search_paths=[tmpdir])
            
            # Resolve the path
            resolved_path = resolver.resolve_path(atx_path)
            
            if resolved_path:
                # Property: The directory structure should be preserved
                # Extract the structure after the root
                resolved_parts = Path(resolved_path).parts
                atx_parts = Path(atx_path).parts
                
                # The suffix (dir_structure + filename) should match exactly
                expected_suffix = Path(dir_structure) / f"{filename}.txt"
                expected_parts = expected_suffix.parts
                
                # Check that the resolved path ends with the expected structure
                assert len(resolved_parts) >= len(expected_parts), \
                    f"Resolved path {resolved_path} is shorter than expected structure"
                
                actual_suffix_parts = resolved_parts[-len(expected_parts):]
                
                # Property: Directory structure is preserved exactly
                assert actual_suffix_parts == expected_parts, \
                    f"Structure mismatch: expected {expected_parts}, got {actual_suffix_parts}"
                
                # Property: The resolved path should point to an existing file
                assert Path(resolved_path).exists(), \
                    f"Resolved path {resolved_path} does not exist"
    
    @given(
        prefix=st.text(
            alphabet=st.characters(min_codepoint=97, max_codepoint=122),
            min_size=3,
            max_size=15
        ),
        filename=st.text(
            alphabet=st.characters(min_codepoint=97, max_codepoint=122),
            min_size=1,
            max_size=10
        ),
        num_resolutions=st.integers(min_value=2, max_value=5)
    )
    @settings(max_examples=50, deadline=None)
    def test_property_20_path_resolution_caching(self, prefix, filename, num_resolutions):
        """
        Property 20: Path Resolution Caching
        
        For any ATX path that has been resolved once, subsequent resolutions
        of the same path should return the cached result without filesystem access.
        
        Validates: Requirements AC-4.8
        """
        # Create a temporary directory structure
        with tempfile.TemporaryDirectory() as tmpdir:
            # Build the ATX path
            atx_path = f"{prefix}/{filename}.txt"
            
            # Create the local file
            local_root = Path(tmpdir) / "local"
            local_file = local_root / f"{filename}.txt"
            local_file.parent.mkdir(parents=True, exist_ok=True)
            local_file.write_text("test content")
            
            # Initialize resolver
            resolver = PathResolver(search_paths=[tmpdir])
            
            # First resolution
            first_result = resolver.resolve_path(atx_path)
            
            # Get initial cache statistics
            stats_after_first = resolver.get_statistics()
            initial_cached = stats_after_first['cached_paths']
            
            # Resolve the same path multiple times
            subsequent_results = []
            for _ in range(num_resolutions - 1):
                result = resolver.resolve_path(atx_path)
                subsequent_results.append(result)
            
            # Get final cache statistics
            stats_after_multiple = resolver.get_statistics()
            final_cached = stats_after_multiple['cached_paths']
            
            # Property: All resolutions should return the same result
            for result in subsequent_results:
                assert result == first_result, \
                    f"Inconsistent resolution: first={first_result}, subsequent={result}"
            
            # Property: Cache size should not increase after first resolution
            # (the path is already cached)
            assert final_cached == initial_cached, \
                f"Cache size increased from {initial_cached} to {final_cached}, " \
                f"indicating filesystem access on subsequent resolutions"
            
            # Property: If the path was resolved, it should be in the cache
            if first_result is not None:
                assert initial_cached > 0, \
                    "Resolved path should be cached"
            
            # Additional verification: Delete the file and verify cached result still works
            if first_result is not None and Path(first_result).exists():
                # Delete the actual file
                Path(first_result).unlink()
                
                # Resolve again - should still return cached result
                cached_result = resolver.resolve_path(atx_path)
                
                # Property: Cached result should be returned even if file no longer exists
                assert cached_result == first_result, \
                    "Cache should return result even if file was deleted"
