"""Property-based tests for QueryEngine with configuration support."""

import pytest
from hypothesis import given, strategies as st, settings
from typing import Dict, List
from tools.smf_analyzer.smf_queries import QueryEngine
from tools.smf_analyzer.smf_queries.base_query import BaseQuery
from tools.smf_analyzer.smf_queries.config_parameter import ConfigParameter
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter


# Helper to create a mock query class dynamically
def create_mock_query_class(
    name: str,
    description: str,
    purpose: str,
    category: str,
    record_types: List[int],
    migration_impact: str,
    requires_inventory: bool,
    config_params: Dict[str, ConfigParameter]
):
    """Create a mock query class with given properties."""
    
    class DynamicMockQuery(BaseQuery):
        @property
        def name(self) -> str:
            return name
        
        @property
        def description(self) -> str:
            return description
        
        @property
        def purpose(self) -> str:
            return purpose
        
        @property
        def category(self) -> str:
            return category
        
        @property
        def record_types(self) -> List[int]:
            return record_types
        
        @property
        def migration_impact(self) -> str:
            return migration_impact
        
        @property
        def requires_inventory(self) -> bool:
            return requires_inventory
        
        @property
        def configuration_parameters(self) -> Dict[str, ConfigParameter]:
            return config_params
        
        def get_sql(self, **params) -> str:
            return "SELECT 1"
    
    return DynamicMockQuery


class TestProperty2CategoryFilteringCorrectness:
    """
    **Feature: smf-queries-modernization, Property 2: Category Filtering Correctness**
    
    For any category and any set of registered queries, filtering queries by that 
    category should return only queries whose category field matches the filter, 
    and all queries with that category should be included in the results.
    
    **Validates: Requirements 2.2, 2.4**
    """
    
    @given(
        categories=st.lists(
            st.sampled_from([
                'Code Artifact Analysis',
                'Infrastructure Sizing',
                'Cost Analysis',
                'Migration Planning'
            ]),
            min_size=1,
            max_size=10
        )
    )
    @settings(max_examples=50)
    def test_property_2_category_filtering(self, categories):
        """
        Test that list_queries_by_category returns only queries matching each category.
        """
        # Create database and engine
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Create and register queries with different categories
        query_by_category = {}
        for i, category in enumerate(categories):
            query_name = f'query_{i}'
            QueryClass = create_mock_query_class(
                name=query_name,
                description=f'Query {i}',
                purpose=f'Purpose {i}',
                category=category,
                record_types=[30],
                migration_impact='Test impact',
                requires_inventory=False,
                config_params={}
            )
            
            query = QueryClass()
            engine.register_query(query)
            
            if category not in query_by_category:
                query_by_category[category] = []
            query_by_category[category].append(query_name)
        
        # Get queries grouped by category
        result = engine.list_queries_by_category()
        
        # Verify all categories are present
        for category in set(categories):
            assert category in result, f"Category {category} not in results"
        
        # Verify each category contains only queries with that category
        for category, queries in result.items():
            assert category in set(categories), f"Unexpected category {category}"
            
            # Extract query names from result
            query_names = [q['name'] for q in queries]
            
            # Verify all queries in this category are present
            expected_queries = query_by_category[category]
            assert set(query_names) == set(expected_queries), \
                f"Category {category}: expected {expected_queries}, got {query_names}"
    
    def test_property_2_empty_category_filter(self):
        """Test that filtering with no queries returns empty dict."""
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        result = engine.list_queries_by_category()
        assert result == {}
    
    def test_property_2_single_category(self):
        """Test filtering with a single category."""
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Register query
        QueryClass = create_mock_query_class(
            name='test_query',
            description='Test',
            purpose='Test purpose',
            category='Code Artifact Analysis',
            record_types=[30],
            migration_impact='Test impact',
            requires_inventory=False,
            config_params={}
        )
        
        query = QueryClass()
        engine.register_query(query)
        
        result = engine.list_queries_by_category()
        
        assert 'Code Artifact Analysis' in result
        assert len(result['Code Artifact Analysis']) == 1
        assert result['Code Artifact Analysis'][0]['name'] == 'test_query'
    
    def test_property_2_multiple_queries_same_category(self):
        """Test that multiple queries in same category are all returned."""
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Register multiple queries with same category
        for i in range(3):
            QueryClass = create_mock_query_class(
                name=f'query_{i}',
                description=f'Query {i}',
                purpose=f'Purpose {i}',
                category='Infrastructure Sizing',
                record_types=[30],
                migration_impact='Test impact',
                requires_inventory=False,
                config_params={}
            )
            
            query = QueryClass()
            engine.register_query(query)
        
        result = engine.list_queries_by_category()
        
        assert 'Infrastructure Sizing' in result
        assert len(result['Infrastructure Sizing']) == 3
        query_names = [q['name'] for q in result['Infrastructure Sizing']]
        assert set(query_names) == {'query_0', 'query_1', 'query_2'}


class TestProperty12DashboardAPICompleteness:
    """
    **Feature: smf-queries-modernization, Property 12: Dashboard API Completeness**
    
    For any QueryEngine instance with registered queries, calling get_query_metadata,
    get_configuration_parameters, and list_queries_by_category should all succeed 
    and return properly structured dictionaries.
    
    **Validates: Requirements 11.1, 11.2, 11.4**
    """
    
    def test_property_12_dashboard_api_methods_exist(self):
        """Test that all dashboard API methods exist and are callable."""
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Verify methods exist
        assert hasattr(engine, 'get_query_metadata')
        assert hasattr(engine, 'get_configuration_parameters')
        assert hasattr(engine, 'list_queries_by_category')
        assert callable(engine.get_query_metadata)
        assert callable(engine.get_configuration_parameters)
        assert callable(engine.list_queries_by_category)
    
    def test_property_12_get_query_metadata_structure(self):
        """Test that get_query_metadata returns properly structured dict."""
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Register a query with configuration parameters
        config_params = {
            'analysis_days': ConfigParameter(
                name='analysis_days',
                description='Number of days to analyze',
                default_value=365,
                parameter_type='int',
                unit='days',
                min_value=1,
                max_value=3650,
                examples=[90, 180, 365]
            )
        }
        
        QueryClass = create_mock_query_class(
            name='test_query',
            description='Test query',
            purpose='Test purpose',
            category='Code Artifact Analysis',
            record_types=[30, 110],
            migration_impact='Test impact',
            requires_inventory=True,
            config_params=config_params
        )
        
        query = QueryClass()
        engine.register_query(query)
        
        # Get metadata
        metadata = engine.get_query_metadata('test_query')
        
        # Verify structure
        required_fields = [
            'name', 'description', 'purpose', 'category',
            'record_types', 'migration_impact', 'requires_inventory',
            'configuration_parameters', 'runtime_parameters'
        ]
        
        for field in required_fields:
            assert field in metadata, f"Missing field: {field}"
        
        # Verify configuration_parameters structure
        assert 'analysis_days' in metadata['configuration_parameters']
        param_meta = metadata['configuration_parameters']['analysis_days']
        
        param_fields = ['description', 'default_value', 'type', 'unit', 
                       'min_value', 'max_value', 'examples']
        for field in param_fields:
            assert field in param_meta, f"Missing param field: {field}"
    
    def test_property_12_get_configuration_parameters_structure(self):
        """Test that get_configuration_parameters returns properly structured dict."""
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Register queries with configuration parameters
        config_params = {
            'analysis_days': ConfigParameter(
                name='analysis_days',
                description='Number of days to analyze',
                default_value=365,
                parameter_type='int',
                unit='days',
                min_value=1,
                max_value=3650,
                examples=[90, 180, 365]
            ),
            'BATCH_CPU_CONVERSION_RATIO': ConfigParameter(
                name='BATCH_CPU_CONVERSION_RATIO',
                description='CPU conversion ratio',
                default_value=0.5,
                parameter_type='float',
                unit='ratio',
                min_value=0.1,
                max_value=2.0,
                examples=[0.4, 0.5, 0.6]
            )
        }
        
        QueryClass = create_mock_query_class(
            name='test_query',
            description='Test query',
            purpose='Test purpose',
            category='Infrastructure Sizing',
            record_types=[30],
            migration_impact='Test impact',
            requires_inventory=False,
            config_params=config_params
        )
        
        query = QueryClass()
        engine.register_query(query)
        
        # Get configuration parameters
        params = engine.get_configuration_parameters()
        
        # Verify structure
        assert 'analysis_days' in params
        assert 'BATCH_CPU_CONVERSION_RATIO' in params
        
        # Verify each parameter has required fields
        required_fields = ['description', 'default_value', 'type', 'unit',
                          'min_value', 'max_value', 'examples', 'current_value']
        
        for param_name, param_meta in params.items():
            for field in required_fields:
                assert field in param_meta, \
                    f"Parameter {param_name} missing field: {field}"
    
    def test_property_12_list_queries_by_category_structure(self):
        """Test that list_queries_by_category returns properly structured dict."""
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Register queries
        QueryClass = create_mock_query_class(
            name='test_query',
            description='Test query',
            purpose='Test purpose',
            category='Cost Analysis',
            record_types=[30],
            migration_impact='Test impact',
            requires_inventory=False,
            config_params={}
        )
        
        query = QueryClass()
        engine.register_query(query)
        
        # Get queries by category
        result = engine.list_queries_by_category()
        
        # Verify structure
        assert isinstance(result, dict)
        assert 'Cost Analysis' in result
        assert isinstance(result['Cost Analysis'], list)
        assert len(result['Cost Analysis']) > 0
        
        # Verify query info structure
        query_info = result['Cost Analysis'][0]
        required_fields = ['name', 'description', 'purpose', 'requires_inventory']
        
        for field in required_fields:
            assert field in query_info, f"Query info missing field: {field}"


class TestProperty14QueryExecutionWithConfigurationInjection:
    """
    **Feature: smf-queries-modernization, Property 14: Query Execution with Configuration Injection**
    
    For any query that declares configuration parameters, executing that query should 
    automatically inject the configured values (or defaults) without requiring the 
    caller to provide them.
    
    **Validates: Requirements 3.2, 4.1**
    """
    
    def test_property_14_configuration_injection_with_defaults(self):
        """Test that configuration parameters are injected with default values."""
        db = SQLiteAdapter(':memory:')
        db.connect()  # Need to connect before using cursor
        engine = QueryEngine(db)  # No config manager
        
        # Create query with configuration parameters
        config_params = {
            'analysis_days': ConfigParameter(
                name='analysis_days',
                description='Number of days to analyze',
                default_value=365,
                parameter_type='int',
                unit='days',
                min_value=1,
                max_value=3650
            )
        }
        
        class TestQuery(BaseQuery):
            @property
            def name(self) -> str:
                return 'test_query'
            
            @property
            def description(self) -> str:
                return 'Test'
            
            @property
            def purpose(self) -> str:
                return 'Test purpose'
            
            @property
            def category(self) -> str:
                return 'Code Artifact Analysis'
            
            @property
            def record_types(self) -> List[int]:
                return [30]
            
            @property
            def migration_impact(self) -> str:
                return 'Test'
            
            @property
            def requires_inventory(self) -> bool:
                return False
            
            @property
            def configuration_parameters(self) -> Dict[str, ConfigParameter]:
                return config_params
            
            def get_parameters(self) -> Dict[str, Dict]:
                # Configuration parameters should be allowed as runtime params too
                return {
                    'analysis_days': {
                        'type': 'int',
                        'required': False,
                        'default': 365,
                        'description': 'Number of days to analyze'
                    }
                }
            
            def get_sql(self, **params) -> str:
                # Verify analysis_days was injected
                assert 'analysis_days' in params
                assert params['analysis_days'] == 365  # Default value
                return "SELECT 1 as result"
        
        query = TestQuery()
        engine.register_query(query)
        
        # Execute without providing analysis_days - should use default
        result = engine.execute('test_query')
        
        # Verify execution succeeded
        assert result is not None
        assert result.query_name == 'test_query'
    
    def test_property_14_runtime_params_override_config(self):
        """Test that runtime parameters override configuration parameters."""
        db = SQLiteAdapter(':memory:')
        db.connect()  # Need to connect before using cursor
        engine = QueryEngine(db)
        
        # Create query with configuration parameters
        config_params = {
            'analysis_days': ConfigParameter(
                name='analysis_days',
                description='Number of days to analyze',
                default_value=365,
                parameter_type='int',
                unit='days',
                min_value=1,
                max_value=3650
            )
        }
        
        class TestQuery(BaseQuery):
            @property
            def name(self) -> str:
                return 'test_query'
            
            @property
            def description(self) -> str:
                return 'Test'
            
            @property
            def purpose(self) -> str:
                return 'Test purpose'
            
            @property
            def category(self) -> str:
                return 'Code Artifact Analysis'
            
            @property
            def record_types(self) -> List[int]:
                return [30]
            
            @property
            def migration_impact(self) -> str:
                return 'Test'
            
            @property
            def requires_inventory(self) -> bool:
                return False
            
            @property
            def configuration_parameters(self) -> Dict[str, ConfigParameter]:
                return config_params
            
            def get_parameters(self) -> Dict[str, Dict]:
                # Configuration parameters should be allowed as runtime params too
                return {
                    'analysis_days': {
                        'type': 'int',
                        'required': False,
                        'default': 365,
                        'description': 'Number of days to analyze'
                    }
                }
            
            def get_sql(self, **params) -> str:
                # Verify analysis_days was overridden
                assert 'analysis_days' in params
                assert params['analysis_days'] == 180  # Runtime override
                return "SELECT 1 as result"
        
        query = TestQuery()
        engine.register_query(query)
        
        # Execute with runtime override
        result = engine.execute('test_query', analysis_days=180)
        
        # Verify execution succeeded
        assert result is not None
        assert result.query_name == 'test_query'
