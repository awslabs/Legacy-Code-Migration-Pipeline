"""Property-based tests for Configuration Manager."""

import pytest
import tempfile
import os
from hypothesis import given, strategies as st, settings, assume
from typing import Any
from tools.smf_analyzer.smf_queries.configuration_manager import ConfigurationManager
from tools.smf_analyzer.smf_queries.database_config_manager import DatabaseConfigurationManager
from tools.smf_analyzer.smf_queries.file_config_manager import FileConfigurationManager
from tools.smf_analyzer.smf_queries.config_parameter import ConfigParameter
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter


# Strategy for generating valid configuration keys
config_key_strategy = st.text(
    min_size=1,
    max_size=50,
    alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'),
        whitelist_characters='_'
    )
)

# Strategy for generating configuration values of different types
def config_value_strategy():
    """Generate configuration values of various types."""
    return st.one_of(
        st.integers(min_value=-1000000, max_value=1000000),
        st.floats(min_value=-1000000.0, max_value=1000000.0, allow_nan=False, allow_infinity=False),
        st.text(min_size=0, max_size=100),
        st.booleans()
    )


class TestProperty3ConfigurationRoundTripConsistency:
    """
    Property 3: Configuration Round-Trip Consistency
    
    For any configuration parameter name and any valid value of the appropriate type,
    setting the parameter to that value and then retrieving it should return the same value.
    
    Validates: Requirements 3.1, 3.2, 3.4, 3.6
    """
    
    @given(
        key=config_key_strategy,
        value=config_value_strategy()
    )
    @settings(max_examples=100)
    def test_property_3_database_round_trip(self, key: str, value: Any):
        """
        Property test: Database config manager should preserve values in round-trip.
        
        Feature: smf-queries-modernization
        Property 3: Configuration Round-Trip Consistency
        """
        # Create in-memory database
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        # Set value
        config_manager.set(key, value)
        
        # Get value back
        retrieved_value = config_manager.get(key)
        
        # Verify round-trip consistency
        assert retrieved_value == value, \
            f"Round-trip failed: set {value!r}, got {retrieved_value!r}"
        
        # Verify type is preserved
        assert type(retrieved_value) == type(value), \
            f"Type not preserved: expected {type(value)}, got {type(retrieved_value)}"
    
    @given(
        key=config_key_strategy,
        value=config_value_strategy()
    )
    @settings(max_examples=100)
    def test_property_3_file_yaml_round_trip(self, key: str, value: Any):
        """
        Property test: YAML file config manager should preserve values in round-trip.
        
        Feature: smf-queries-modernization
        Property 3: Configuration Round-Trip Consistency
        """
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            temp_file = f.name
        
        try:
            config_manager = FileConfigurationManager(temp_file, file_format='yaml')
            
            # Set value
            config_manager.set(key, value)
            
            # Get value back
            retrieved_value = config_manager.get(key)
            
            # Verify round-trip consistency
            assert retrieved_value == value, \
                f"Round-trip failed: set {value!r}, got {retrieved_value!r}"
            
            # Verify type is preserved (with YAML type coercion considerations)
            assert type(retrieved_value) == type(value), \
                f"Type not preserved: expected {type(value)}, got {type(retrieved_value)}"
        finally:
            # Cleanup
            if os.path.exists(temp_file):
                os.unlink(temp_file)
    
    @given(
        key=config_key_strategy,
        value=config_value_strategy()
    )
    @settings(max_examples=100)
    def test_property_3_file_json_round_trip(self, key: str, value: Any):
        """
        Property test: JSON file config manager should preserve values in round-trip.
        
        Feature: smf-queries-modernization
        Property 3: Configuration Round-Trip Consistency
        """
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_file = f.name
        
        try:
            config_manager = FileConfigurationManager(temp_file, file_format='json')
            
            # Set value
            config_manager.set(key, value)
            
            # Get value back
            retrieved_value = config_manager.get(key)
            
            # Verify round-trip consistency
            assert retrieved_value == value, \
                f"Round-trip failed: set {value!r}, got {retrieved_value!r}"
            
            # Verify type is preserved
            assert type(retrieved_value) == type(value), \
                f"Type not preserved: expected {type(value)}, got {type(retrieved_value)}"
        finally:
            # Cleanup
            if os.path.exists(temp_file):
                os.unlink(temp_file)
    
    @given(
        keys_and_values=st.lists(
            st.tuples(config_key_strategy, config_value_strategy()),
            min_size=1,
            max_size=10,
            unique_by=lambda x: x[0]  # Unique keys
        )
    )
    @settings(max_examples=50)
    def test_property_3_multiple_values_round_trip(self, keys_and_values):
        """
        Property test: Multiple configuration values should all round-trip correctly.
        
        Feature: smf-queries-modernization
        Property 3: Configuration Round-Trip Consistency
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        # Set all values
        for key, value in keys_and_values:
            config_manager.set(key, value)
        
        # Verify all values round-trip correctly
        for key, expected_value in keys_and_values:
            retrieved_value = config_manager.get(key)
            assert retrieved_value == expected_value, \
                f"Round-trip failed for key {key}: set {expected_value!r}, got {retrieved_value!r}"
    
    @given(
        key=config_key_strategy,
        value=config_value_strategy()
    )
    @settings(max_examples=50)
    def test_property_3_get_all_includes_set_value(self, key: str, value: Any):
        """
        Property test: get_all() should include values set via set().
        
        Feature: smf-queries-modernization
        Property 3: Configuration Round-Trip Consistency
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        # Set value
        config_manager.set(key, value)
        
        # Get all values
        all_config = config_manager.get_all()
        
        # Verify key is present
        assert key in all_config, f"Key {key} not found in get_all() result"
        
        # Verify value matches
        assert all_config[key] == value, \
            f"Value mismatch in get_all(): expected {value!r}, got {all_config[key]!r}"


class TestProperty4ConfigurationTypePreservation:
    """
    Property 4: Configuration Type Preservation
    
    For any configuration parameter of type integer, float, string, or boolean,
    setting a value of that type and retrieving it should return a value of the same type.
    
    Validates: Requirements 3.5
    """
    
    @given(value=st.integers(min_value=-1000000, max_value=1000000))
    @settings(max_examples=50)
    def test_property_4_integer_type_preservation(self, value: int):
        """
        Property test: Integer values should preserve type.
        
        Feature: smf-queries-modernization
        Property 4: Configuration Type Preservation
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        config_manager.set('test_int', value)
        retrieved = config_manager.get('test_int')
        
        assert isinstance(retrieved, int), \
            f"Expected int, got {type(retrieved).__name__}"
        assert retrieved == value
    
    @given(value=st.floats(min_value=-1000000.0, max_value=1000000.0, allow_nan=False, allow_infinity=False))
    @settings(max_examples=50)
    def test_property_4_float_type_preservation(self, value: float):
        """
        Property test: Float values should preserve type.
        
        Feature: smf-queries-modernization
        Property 4: Configuration Type Preservation
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        config_manager.set('test_float', value)
        retrieved = config_manager.get('test_float')
        
        assert isinstance(retrieved, float), \
            f"Expected float, got {type(retrieved).__name__}"
        assert retrieved == value
    
    @given(value=st.text(min_size=0, max_size=100))
    @settings(max_examples=50)
    def test_property_4_string_type_preservation(self, value: str):
        """
        Property test: String values should preserve type.
        
        Feature: smf-queries-modernization
        Property 4: Configuration Type Preservation
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        config_manager.set('test_str', value)
        retrieved = config_manager.get('test_str')
        
        assert isinstance(retrieved, str), \
            f"Expected str, got {type(retrieved).__name__}"
        assert retrieved == value
    
    @given(value=st.booleans())
    @settings(max_examples=20)
    def test_property_4_boolean_type_preservation(self, value: bool):
        """
        Property test: Boolean values should preserve type.
        
        Feature: smf-queries-modernization
        Property 4: Configuration Type Preservation
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        config_manager.set('test_bool', value)
        retrieved = config_manager.get('test_bool')
        
        assert isinstance(retrieved, bool), \
            f"Expected bool, got {type(retrieved).__name__}"
        assert retrieved == value


class TestProperty6CacheConsistencyAfterUpdate:
    """
    Property 6: Cache Consistency After Update
    
    For any configuration parameter, after updating its value, the next retrieval
    should return the updated value (not a stale cached value).
    
    Validates: Requirements 3.7, 3.8, 14.1
    """
    
    @given(
        key=config_key_strategy,
        initial_value=config_value_strategy(),
        updated_value=config_value_strategy()
    )
    @settings(max_examples=100)
    def test_property_6_cache_invalidation_on_update(
        self,
        key: str,
        initial_value: Any,
        updated_value: Any
    ):
        """
        Property test: Cache should be invalidated after update.
        
        Feature: smf-queries-modernization
        Property 6: Cache Consistency After Update
        """
        # Ensure values are different to test cache invalidation
        assume(initial_value != updated_value)
        
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        # Set initial value
        config_manager.set(key, initial_value)
        
        # Get value (populates cache)
        first_retrieval = config_manager.get(key)
        assert first_retrieval == initial_value
        
        # Update value
        config_manager.set(key, updated_value)
        
        # Get value again (should get updated value, not cached)
        second_retrieval = config_manager.get(key)
        assert second_retrieval == updated_value, \
            f"Cache not invalidated: expected {updated_value!r}, got {second_retrieval!r}"
        
        # Verify it's not the old value
        assert second_retrieval != initial_value, \
            "Got stale cached value after update"
    
    @given(
        key=config_key_strategy,
        values=st.lists(config_value_strategy(), min_size=2, max_size=5)
    )
    @settings(max_examples=50)
    def test_property_6_multiple_updates_cache_consistency(
        self,
        key: str,
        values: list
    ):
        """
        Property test: Multiple updates should all invalidate cache correctly.
        
        Feature: smf-queries-modernization
        Property 6: Cache Consistency After Update
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        # Perform multiple updates and verify each one
        for value in values:
            config_manager.set(key, value)
            retrieved = config_manager.get(key)
            assert retrieved == value, \
                f"Cache inconsistency after update: expected {value!r}, got {retrieved!r}"
    
    @given(
        keys_and_values=st.lists(
            st.tuples(config_key_strategy, config_value_strategy()),
            min_size=2,
            max_size=5,
            unique_by=lambda x: x[0]
        )
    )
    @settings(max_examples=50)
    def test_property_6_get_all_reflects_updates(self, keys_and_values):
        """
        Property test: get_all() should reflect all updates.
        
        Feature: smf-queries-modernization
        Property 6: Cache Consistency After Update
        """
        db = SQLiteAdapter(':memory:')
        db.connect()
        config_manager = DatabaseConfigurationManager(db)
        
        # Set all initial values
        for key, value in keys_and_values:
            config_manager.set(key, value)
        
        # Get all (populates cache)
        all_config = config_manager.get_all()
        
        # Verify all values are present
        for key, value in keys_and_values:
            assert all_config[key] == value
        
        # Update one value
        first_key, _ = keys_and_values[0]
        new_value = "updated_value_12345"
        config_manager.set(first_key, new_value)
        
        # Get all again (should reflect update)
        updated_all_config = config_manager.get_all()
        assert updated_all_config[first_key] == new_value, \
            "get_all() did not reflect update"


class TestProperty7StorageBackendAPIConsistency:
    """
    Property 7: Storage Backend API Consistency
    
    For any configuration operation (get, set, get_all) performed on
    DatabaseConfigurationManager and FileConfigurationManager with the same
    initial state, both should produce the same results.
    
    Validates: Requirements 9.4
    """
    
    @given(
        key=config_key_strategy,
        value=config_value_strategy()
    )
    @settings(max_examples=50)
    def test_property_7_set_and_get_consistency(self, key: str, value: Any):
        """
        Property test: Database and file backends should behave consistently.
        
        Feature: smf-queries-modernization
        Property 7: Storage Backend API Consistency
        """
        # Setup database backend
        db = SQLiteAdapter(':memory:')
        db.connect()
        db_config = DatabaseConfigurationManager(db)
        
        # Setup file backend
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            temp_file = f.name
        
        try:
            file_config = FileConfigurationManager(temp_file, file_format='yaml')
            
            # Perform same operation on both
            db_config.set(key, value)
            file_config.set(key, value)
            
            # Verify both return same value
            db_result = db_config.get(key)
            file_result = file_config.get(key)
            
            assert db_result == file_result, \
                f"Backend inconsistency: DB returned {db_result!r}, File returned {file_result!r}"
            
            # Verify both have same type
            assert type(db_result) == type(file_result), \
                f"Type inconsistency: DB type {type(db_result)}, File type {type(file_result)}"
        finally:
            if os.path.exists(temp_file):
                os.unlink(temp_file)
    
    @given(
        keys_and_values=st.lists(
            st.tuples(config_key_strategy, config_value_strategy()),
            min_size=1,
            max_size=5,
            unique_by=lambda x: x[0]
        )
    )
    @settings(max_examples=30)
    def test_property_7_get_all_consistency(self, keys_and_values):
        """
        Property test: get_all() should return same results across backends.
        
        Feature: smf-queries-modernization
        Property 7: Storage Backend API Consistency
        """
        # Setup database backend
        db = SQLiteAdapter(':memory:')
        db.connect()
        db_config = DatabaseConfigurationManager(db)
        
        # Setup file backend
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            temp_file = f.name
        
        try:
            file_config = FileConfigurationManager(temp_file, file_format='yaml')
            
            # Set same values in both
            for key, value in keys_and_values:
                db_config.set(key, value)
                file_config.set(key, value)
            
            # Get all from both
            db_all = db_config.get_all()
            file_all = file_config.get_all()
            
            # Verify same keys
            assert set(db_all.keys()) == set(file_all.keys()), \
                "Different keys returned by backends"
            
            # Verify same values for each key
            for key, expected_value in keys_and_values:
                assert db_all[key] == file_all[key], \
                    f"Value mismatch for key {key}: DB={db_all[key]!r}, File={file_all[key]!r}"
        finally:
            if os.path.exists(temp_file):
                os.unlink(temp_file)
    
    @given(
        key=config_key_strategy,
        default=config_value_strategy()
    )
    @settings(max_examples=30)
    def test_property_7_default_value_consistency(self, key: str, default: Any):
        """
        Property test: Default values should work consistently across backends.
        
        Feature: smf-queries-modernization
        Property 7: Storage Backend API Consistency
        """
        # Setup database backend
        db = SQLiteAdapter(':memory:')
        db.connect()
        db_config = DatabaseConfigurationManager(db)
        
        # Setup file backend
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            temp_file = f.name
        
        try:
            file_config = FileConfigurationManager(temp_file, file_format='yaml')
            
            # Get non-existent key with default from both
            db_result = db_config.get(key, default)
            file_result = file_config.get(key, default)
            
            # Both should return the default
            assert db_result == default, \
                f"DB did not return default: got {db_result!r}"
            assert file_result == default, \
                f"File did not return default: got {file_result!r}"
            assert db_result == file_result, \
                "Backends returned different defaults"
        finally:
            if os.path.exists(temp_file):
                os.unlink(temp_file)
