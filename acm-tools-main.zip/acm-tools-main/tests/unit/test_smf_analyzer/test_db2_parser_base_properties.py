"""Property-based tests for DB2 parser base class.

Feature: db2-versioned-smf-parsers
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers.db2_parser_base import DB2ParserBase
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_smf_record_with_qwhs(
    record_type: int,
    qwhs_data: dict,
    record_length: int = 300
) -> bytes:
    """Create a synthetic SMF record with QWHS header.
    
    Args:
        record_type: SMF record type (100, 101, or 102)
        qwhs_data: Dictionary with QWHS field values
        record_length: Total record length
        
    Returns:
        Binary SMF record with QWHS header in product section
    """
    record = bytearray(record_length)
    
    # Standard SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, record_type)  # Record type
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = qwhs_data.get('system_id', 'SYS1').encode('cp037')
    record[14:18] = sys_id[:4].ljust(4, b' ')
    
    # Subsystem ID (EBCDIC)
    subsys_id = qwhs_data.get('subsystem_id', 'DB2P').encode('cp037')
    record[18:22] = subsys_id[:4].ljust(4, b' ')
    
    # Subtype
    struct.pack_into('>H', record, 22, 0)
    
    # Triplet count
    struct.pack_into('>H', record, 24, 1)
    
    # Reserved
    struct.pack_into('>H', record, 26, 0)
    
    # Product section triplet (offset 28)
    product_offset = 44  # Start product section after header
    product_length = 150  # Length of product section
    struct.pack_into('>I', record, 28, product_offset)  # Offset
    struct.pack_into('>H', record, 32, product_length)  # Length
    struct.pack_into('>H', record, 34, 1)  # Count
    
    # Data section triplet (offset 36) - not used
    struct.pack_into('>I', record, 36, 0)
    struct.pack_into('>H', record, 40, 0)
    struct.pack_into('>H', record, 42, 0)
    
    # QWHS standard header in product section (starts at product_offset)
    qwhs_offset = product_offset
    
    # QWHSLEN - Header length
    header_length = qwhs_data.get('header_length', 94)
    struct.pack_into('>H', record, qwhs_offset, header_length)
    
    # QWHSTYPE - Header type (1 for QWHS)
    header_type = qwhs_data.get('header_type', 1)
    struct.pack_into('B', record, qwhs_offset + 2, header_type)
    
    # QWHSRMID - Resource manager ID (0xDB for DB2)
    rm_id = qwhs_data.get('resource_manager_id', 0xDB)
    struct.pack_into('B', record, qwhs_offset + 3, rm_id)
    
    # QWHSIFID - IFCID
    ifcid = qwhs_data.get('ifcid', 1)
    struct.pack_into('>H', record, qwhs_offset + 4, ifcid)
    
    # QWHSRELN - Release number
    release_number = qwhs_data.get('release_number', 0x0C00)  # V12
    struct.pack_into('>H', record, qwhs_offset + 6, release_number)
    
    # QWHSNSDA - Number of self-defining areas
    num_sda = qwhs_data.get('num_self_defining_areas', 0)
    struct.pack_into('B', record, qwhs_offset + 8, num_sda)
    
    # QWHSRELI - Release indicator
    rel_ind = qwhs_data.get('release_indicator', 0)
    struct.pack_into('B', record, qwhs_offset + 9, rel_ind)
    
    # QWHSACEA - ACE address
    ace_addr = qwhs_data.get('ace_address', 0)
    struct.pack_into('>I', record, qwhs_offset + 10, ace_addr)
    
    # QWHSSSID - Subsystem name (EBCDIC)
    subsys_name = qwhs_data.get('subsystem_name', 'DB2P').encode('cp037')
    # Pad with EBCDIC spaces (0x40) not null bytes
    record[qwhs_offset + 14:qwhs_offset + 18] = subsys_name[:4].ljust(4, b'\x40')
    
    # QWHSSTCK - Store clock
    store_clock = qwhs_data.get('store_clock', 0)
    struct.pack_into('>Q', record, qwhs_offset + 18, store_clock)
    
    # QWHSISEQ - IFCID sequence
    ifcid_seq = qwhs_data.get('ifcid_sequence', 0)
    struct.pack_into('>I', record, qwhs_offset + 26, ifcid_seq)
    
    # QWHSDSEQ - Destination sequence
    dest_seq = qwhs_data.get('destination_sequence', 0)
    struct.pack_into('>I', record, qwhs_offset + 30, dest_seq)
    
    # QWHSTNUM - Trace number mask
    trace_mask = qwhs_data.get('trace_number_mask', 0)
    struct.pack_into('>I', record, qwhs_offset + 34, trace_mask)
    
    # QWHSLCNM - Local location name (EBCDIC)
    loc_name = qwhs_data.get('local_location_name', 'LOCATION').encode('cp037')
    # Pad with EBCDIC spaces (0x40) not null bytes
    record[qwhs_offset + 38:qwhs_offset + 54] = loc_name[:16].ljust(16, b'\x40')
    
    # QWHSLUWI - LUWID (EBCDIC)
    luwid = qwhs_data.get('luwid', 'LUWID').encode('cp037')
    # Pad with EBCDIC spaces (0x40) not null bytes
    record[qwhs_offset + 54:qwhs_offset + 78] = luwid[:24].ljust(24, b'\x40')
    
    # QWHSNETW - Network ID (EBCDIC)
    network_id = qwhs_data.get('network_id', 'NETWORK').encode('cp037')
    # Pad with EBCDIC spaces (0x40) not null bytes
    record[qwhs_offset + 78:qwhs_offset + 86] = network_id[:8].ljust(8, b'\x40')
    
    # QWHSLUNM - LU name (EBCDIC)
    luname = qwhs_data.get('luname', 'LUNAME').encode('cp037')
    # Pad with EBCDIC spaces (0x40) not null bytes
    record[qwhs_offset + 86:qwhs_offset + 94] = luname[:8].ljust(8, b'\x40')
    
    return bytes(record)


# Strategies for generating test data

# Valid DB2 record types
db2_record_types = st.sampled_from([100, 101, 102])

# Valid IFCID values (0-65535)
ifcid_values = st.integers(min_value=0, max_value=65535)

# Valid release numbers (DB2 V10-V13)
release_numbers = st.sampled_from([0x0A00, 0x0B00, 0x0C00, 0x0D00])

# Valid subsystem names (4 chars, uppercase alphanumeric, EBCDIC-safe)
subsystem_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    min_size=1,
    max_size=4
)

# Valid location names (up to 16 chars, EBCDIC-safe)
location_names = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ',
    min_size=1,
    max_size=16
)


class TestDB2ParserBaseProperties:
    """Property-based tests for DB2 parser base class."""
    
    @settings(max_examples=100)
    @given(
        record_type=db2_record_types,
        ifcid=ifcid_values,
        release_number=release_numbers,
        subsystem_name=subsystem_names,
        location_name=location_names
    )
    def test_property_7_qwhs_header_extraction(
        self,
        record_type,
        ifcid,
        release_number,
        subsystem_name,
        location_name
    ):
        """
        **Feature: db2-versioned-smf-parsers, Property 7: QWHS Header Extraction**
        **Validates: Requirements 3.2, 4.3, 5.4**
        
        For any SMF record of type 100, 101, or 102 with a valid product section,
        parsing the record should extract the QWHS standard header from the product section.
        """
        # Create QWHS data with test values
        qwhs_data = {
            'ifcid': ifcid,
            'release_number': release_number,
            'subsystem_name': subsystem_name,
            'local_location_name': location_name,
        }
        
        # Create test record
        record_data = create_smf_record_with_qwhs(record_type, qwhs_data)
        
        # Create parser
        base_parser = BaseRecordParser(encoding='EBCDIC')
        db2_parser = DB2ParserBase(base_parser)
        
        # Parse product section triplet
        product_section = db2_parser.parse_product_section_header(record_data)
        
        # Verify product section triplet is valid
        assert product_section['offset'] > 0, "Product section offset should be positive"
        assert product_section['length'] > 0, "Product section length should be positive"
        assert product_section['count'] >= 1, "Product section count should be at least 1"
        
        # Parse QWHS header
        qwhs_offset = product_section['offset']
        qwhs = db2_parser.parse_qwhs_header(record_data, qwhs_offset)
        
        # Verify QWHS header was extracted
        assert qwhs is not None, "QWHS header should be extracted"
        assert isinstance(qwhs, dict), "QWHS header should be a dictionary"
        
        # Verify key fields match input
        assert qwhs['ifcid'] == ifcid, \
            f"IFCID should be {ifcid}, got {qwhs['ifcid']}"
        assert qwhs['release_number'] == release_number, \
            f"Release number should be {release_number:04X}, got {qwhs['release_number']:04X}"
        assert qwhs['subsystem_name'].strip() == subsystem_name.strip(), \
            f"Subsystem name should be '{subsystem_name}', got '{qwhs['subsystem_name']}'"
        assert qwhs['local_location_name'].strip() == location_name.strip(), \
            f"Location name should be '{location_name}', got '{qwhs['local_location_name']}'"
        
        # Verify header type is correct (1 for QWHS)
        assert qwhs['header_type'] == 1, \
            f"Header type should be 1 for QWHS, got {qwhs['header_type']}"
        
        # Verify resource manager ID is DB2 (0xDB)
        assert qwhs['resource_manager_id'] == 0xDB, \
            f"Resource manager ID should be 0xDB for DB2, got {qwhs['resource_manager_id']:02X}"
        
        # Verify all expected fields are present
        expected_fields = [
            'header_length', 'header_type', 'resource_manager_id', 'ifcid',
            'release_number', 'num_self_defining_areas', 'release_indicator',
            'ace_address', 'subsystem_name', 'store_clock', 'ifcid_sequence',
            'destination_sequence', 'trace_number_mask', 'local_location_name',
            'luwid', 'network_id', 'luname'
        ]
        
        for field in expected_fields:
            assert field in qwhs, f"QWHS header should contain field '{field}'"
    
    @settings(max_examples=50)
    @given(
        record_type=db2_record_types,
        header_type=st.integers(min_value=2, max_value=32)
    )
    def test_find_header_by_type_locates_optional_headers(
        self,
        record_type,
        header_type
    ):
        """
        Test that find_header_by_type can locate optional headers in product section.
        
        This validates the header scanning logic used for optional headers like
        correlation, trace, CPU, distributed, and data sharing headers.
        """
        # Create a record with QWHS header
        qwhs_data = {'ifcid': 1, 'release_number': 0x0C00}
        record_data = bytearray(create_smf_record_with_qwhs(record_type, qwhs_data))
        
        # Get product section location
        base_parser = BaseRecordParser(encoding='EBCDIC')
        db2_parser = DB2ParserBase(base_parser)
        product_section = db2_parser.parse_product_section_header(bytes(record_data))
        
        product_offset = product_section['offset']
        product_length = product_section['length']
        
        # Add a second header after QWHS
        qwhs_length = 94
        second_header_offset = product_offset + qwhs_length
        
        # Ensure we have space for the second header
        if second_header_offset + 20 < len(record_data):
            # Write second header
            struct.pack_into('>H', record_data, second_header_offset, 20)  # Header length
            struct.pack_into('B', record_data, second_header_offset + 2, header_type)  # Header type
            struct.pack_into('B', record_data, second_header_offset + 3, 0xDB)  # RM ID
            
            # Update product section length to include second header
            new_product_length = qwhs_length + 20
            struct.pack_into('>H', record_data, 32, new_product_length)
            
            # Find the header
            found_offset = db2_parser.find_header_by_type(
                bytes(record_data),
                product_offset,
                new_product_length,
                header_type
            )
            
            # Verify header was found
            assert found_offset is not None, \
                f"Header type {header_type} should be found"
            assert found_offset == second_header_offset, \
                f"Header should be at offset {second_header_offset}, found at {found_offset}"
    
    @settings(max_examples=50)
    @given(
        record_type=db2_record_types,
        header_type=st.integers(min_value=2, max_value=32)
    )
    def test_find_header_by_type_returns_none_when_not_found(
        self,
        record_type,
        header_type
    ):
        """
        Test that find_header_by_type returns None when header type is not present.
        """
        # Create a record with only QWHS header (type 1)
        qwhs_data = {'ifcid': 1, 'release_number': 0x0C00}
        record_data = create_smf_record_with_qwhs(record_type, qwhs_data)
        
        # Get product section location
        base_parser = BaseRecordParser(encoding='EBCDIC')
        db2_parser = DB2ParserBase(base_parser)
        product_section = db2_parser.parse_product_section_header(record_data)
        
        product_offset = product_section['offset']
        product_length = product_section['length']
        
        # Try to find a header type that doesn't exist
        found_offset = db2_parser.find_header_by_type(
            record_data,
            product_offset,
            product_length,
            header_type
        )
        
        # Verify header was not found (only QWHS with type 1 exists)
        assert found_offset is None, \
            f"Header type {header_type} should not be found (only QWHS exists)"
    
    @settings(max_examples=100)
    @given(
        record_type=db2_record_types
    )
    def test_parse_smf_header_extracts_all_fields(self, record_type):
        """
        Test that parse_smf_header extracts all standard SMF header fields.
        """
        # Create test record
        qwhs_data = {'ifcid': 1, 'release_number': 0x0C00}
        record_data = create_smf_record_with_qwhs(record_type, qwhs_data)
        
        # Create parser
        base_parser = BaseRecordParser(encoding='EBCDIC')
        db2_parser = DB2ParserBase(base_parser)
        
        # Parse SMF header
        smf_header = db2_parser.parse_smf_header(record_data)
        
        # Verify all expected fields are present
        expected_fields = [
            'record_length', 'segment_descriptor', 'system_indicator',
            'record_type', 'timestamp', 'date', 'system_id', 'subsystem_id',
            'subtype'
        ]
        
        for field in expected_fields:
            assert field in smf_header, f"SMF header should contain field '{field}'"
        
        # Verify record type matches
        assert smf_header['record_type'] == record_type, \
            f"Record type should be {record_type}, got {smf_header['record_type']}"
        
        # Verify system_id and subsystem_id are strings
        assert isinstance(smf_header['system_id'], str), \
            "system_id should be a string"
        assert isinstance(smf_header['subsystem_id'], str), \
            "subsystem_id should be a string"
    
    @settings(max_examples=100)
    @given(
        record_type=db2_record_types,
        field_offset=st.integers(min_value=100, max_value=200),
        field_length=st.integers(min_value=1, max_value=50),
        field_value=st.integers(min_value=0, max_value=0xFFFFFFFF)
    )
    def test_property_8_variable_length_field_handling(
        self,
        record_type,
        field_offset,
        field_length,
        field_value
    ):
        """
        **Feature: db2-versioned-smf-parsers, Property 8: Variable-Length Field Handling**
        **Validates: Requirements 3.3**
        
        For any SMF record with variable-length fields defined by offset/length triplets,
        parsing the record should correctly extract fields at the specified offsets with
        the specified lengths.
        """
        # Create a record large enough to hold the field
        record_length = max(300, field_offset + field_length + 10)
        record = bytearray(record_length)
        
        # Standard SMF header
        struct.pack_into('>H', record, 0, record_length)
        struct.pack_into('B', record, 5, record_type)
        
        # Create a triplet pointing to our test field
        triplet_offset = 28  # Standard location for first triplet
        struct.pack_into('>I', record, triplet_offset, field_offset)  # Offset
        struct.pack_into('>H', record, triplet_offset + 4, field_length)  # Length
        struct.pack_into('>H', record, triplet_offset + 6, 1)  # Count
        
        # Write the field value at the specified offset
        # Truncate value to fit in field_length bytes
        bytes_to_write = min(field_length, 4)  # Max 4 bytes for integer
        if bytes_to_write > 0:
            # Write as big-endian integer
            value_bytes = field_value.to_bytes(4, byteorder='big', signed=False)
            record[field_offset:field_offset + bytes_to_write] = value_bytes[-bytes_to_write:]
        
        record_data = bytes(record)
        
        # Create parser
        base_parser = BaseRecordParser(encoding='EBCDIC')
        
        # Read the triplet
        read_offset = base_parser.read_binary(record_data, triplet_offset, 4)
        read_length = base_parser.read_binary(record_data, triplet_offset + 4, 2)
        read_count = base_parser.read_binary(record_data, triplet_offset + 6, 2)
        
        # Verify triplet values match what we wrote
        assert read_offset == field_offset, \
            f"Triplet offset should be {field_offset}, got {read_offset}"
        assert read_length == field_length, \
            f"Triplet length should be {field_length}, got {read_length}"
        assert read_count == 1, \
            f"Triplet count should be 1, got {read_count}"
        
        # Read the field value using the triplet
        if bytes_to_write > 0:
            read_value = base_parser.read_binary(record_data, read_offset, bytes_to_write)
            
            # Verify the value matches (truncated to bytes_to_write)
            expected_value = field_value & ((1 << (bytes_to_write * 8)) - 1)
            assert read_value == expected_value, \
                f"Field value should be {expected_value}, got {read_value}"
    
    @settings(max_examples=50)
    @given(
        record_type=db2_record_types,
        num_triplets=st.integers(min_value=1, max_value=5)
    )
    def test_multiple_triplets_handled_correctly(
        self,
        record_type,
        num_triplets
    ):
        """
        Test that multiple triplets can be read and used to locate multiple sections.
        
        This validates handling of records with multiple variable-length sections.
        """
        record_length = 500
        record = bytearray(record_length)
        
        # Standard SMF header
        struct.pack_into('>H', record, 0, record_length)
        struct.pack_into('B', record, 5, record_type)
        
        # Write multiple triplets starting at offset 28
        triplet_base = 28
        section_base = 200  # Start sections at offset 200
        
        for i in range(num_triplets):
            triplet_offset = triplet_base + (i * 8)
            section_offset = section_base + (i * 20)
            section_length = 20
            
            # Write triplet
            struct.pack_into('>I', record, triplet_offset, section_offset)
            struct.pack_into('>H', record, triplet_offset + 4, section_length)
            struct.pack_into('>H', record, triplet_offset + 6, 1)
            
            # Write a marker value in the section
            marker_value = 0x1000 + i
            struct.pack_into('>H', record, section_offset, marker_value)
        
        record_data = bytes(record)
        
        # Create parser
        base_parser = BaseRecordParser(encoding='EBCDIC')
        
        # Read and verify each triplet
        for i in range(num_triplets):
            triplet_offset = triplet_base + (i * 8)
            
            # Read triplet
            offset = base_parser.read_binary(record_data, triplet_offset, 4)
            length = base_parser.read_binary(record_data, triplet_offset + 4, 2)
            count = base_parser.read_binary(record_data, triplet_offset + 6, 2)
            
            # Verify triplet
            expected_offset = section_base + (i * 20)
            assert offset == expected_offset, \
                f"Triplet {i} offset should be {expected_offset}, got {offset}"
            assert length == 20, \
                f"Triplet {i} length should be 20, got {length}"
            assert count == 1, \
                f"Triplet {i} count should be 1, got {count}"
            
            # Read marker from section
            marker = base_parser.read_binary(record_data, offset, 2)
            expected_marker = 0x1000 + i
            assert marker == expected_marker, \
                f"Section {i} marker should be {expected_marker:04X}, got {marker:04X}"
    
    @settings(max_examples=100)
    @given(
        ascii_string=st.text(
            alphabet=st.characters(
                whitelist_categories=('Lu', 'Ll', 'Nd'),
                min_codepoint=32,
                max_codepoint=126
            ),
            min_size=1,
            max_size=16
        )
    )
    def test_property_9_ebcdic_string_round_trip(self, ascii_string):
        """
        **Feature: db2-versioned-smf-parsers, Property 9: EBCDIC String Round-Trip**
        **Validates: Requirements 3.4**
        
        For any ASCII string encoded as EBCDIC in an SMF record field, parsing that
        field should produce the original ASCII string.
        """
        # Encode string to EBCDIC
        try:
            ebcdic_bytes = ascii_string.encode('cp037')
        except UnicodeEncodeError:
            # Skip strings that can't be encoded in EBCDIC
            return
        
        # Create a record with the EBCDIC string
        record_length = 200
        record = bytearray(record_length)
        
        # Write string at offset 100
        string_offset = 100
        string_length = len(ebcdic_bytes)
        
        # Pad with spaces if needed (EBCDIC space is 0x40)
        padded_bytes = ebcdic_bytes.ljust(16, b'\x40')
        record[string_offset:string_offset + 16] = padded_bytes[:16]
        
        record_data = bytes(record)
        
        # Create parser
        base_parser = BaseRecordParser(encoding='EBCDIC')
        
        # Parse the string
        parsed_string = base_parser.read_string(
            record_data,
            string_offset,
            16,
            'test_field'
        )
        
        # Verify round-trip (strip trailing spaces)
        assert parsed_string.strip() == ascii_string.strip(), \
            f"Round-trip failed: expected '{ascii_string}', got '{parsed_string}'"
    
    @settings(max_examples=50)
    @given(
        string_length=st.integers(min_value=1, max_value=32),
        fill_char=st.sampled_from(['A', 'B', '0', '1', ' '])
    )
    def test_ebcdic_string_with_padding(self, string_length, fill_char):
        """
        Test EBCDIC string parsing with various padding scenarios.
        
        This validates that strings padded with spaces or other characters
        are correctly parsed and trimmed.
        """
        # Create a string filled with the character
        ascii_string = fill_char * string_length
        
        # Encode to EBCDIC
        ebcdic_bytes = ascii_string.encode('cp037')
        
        # Create record
        record_length = 200
        record = bytearray(record_length)
        
        string_offset = 100
        # Pad with EBCDIC spaces (0x40)
        padded_bytes = ebcdic_bytes.ljust(32, b'\x40')
        record[string_offset:string_offset + 32] = padded_bytes[:32]
        
        record_data = bytes(record)
        
        # Parse
        base_parser = BaseRecordParser(encoding='EBCDIC')
        parsed_string = base_parser.read_string(
            record_data,
            string_offset,
            32,
            'test_field'
        )
        
        # Verify (strip trailing spaces)
        assert parsed_string.strip() == ascii_string.strip(), \
            f"Expected '{ascii_string}', got '{parsed_string}'"
    
    @settings(max_examples=50)
    @given(
        record_type=db2_record_types
    )
    def test_ebcdic_null_field_handling(self, record_type):
        """
        Test that fields filled with null bytes are handled correctly.
        
        This validates that unused/empty fields (all zeros) return empty strings.
        """
        # Create record with null-filled field
        record_length = 200
        record = bytearray(record_length)
        
        # Standard SMF header
        struct.pack_into('>H', record, 0, record_length)
        struct.pack_into('B', record, 5, record_type)
        
        # Leave a field at offset 100 filled with zeros (default)
        string_offset = 100
        string_length = 16
        
        record_data = bytes(record)
        
        # Parse the null field
        base_parser = BaseRecordParser(encoding='EBCDIC')
        parsed_string = base_parser.read_string(
            record_data,
            string_offset,
            string_length,
            'null_field'
        )
        
        # Verify it returns empty string
        assert parsed_string == "", \
            f"Null field should return empty string, got '{parsed_string}'"


    @settings(max_examples=100)
    @given(
        record_type=st.sampled_from([101]),  # Type 101 has optional headers
        has_correlation=st.booleans(),
        has_trace=st.booleans(),
        has_cpu=st.booleans(),
        has_distributed=st.booleans(),
        has_data_sharing=st.booleans()
    )
    def test_property_10_optional_header_extraction(
        self,
        record_type,
        has_correlation,
        has_trace,
        has_cpu,
        has_distributed,
        has_data_sharing
    ):
        """
        **Feature: db2-versioned-smf-parsers, Property 10: Optional Header Extraction**
        **Validates: Requirements 4.4**
        
        For any SMF Type 101 record containing optional headers (correlation, trace,
        CPU, distributed, data sharing), parsing the record should extract all present
        optional headers.
        """
        # Create base record with QWHS header
        qwhs_data = {'ifcid': 3, 'release_number': 0x0B00}  # V11, IFCID 3 (accounting)
        record_data = bytearray(create_smf_record_with_qwhs(record_type, qwhs_data, record_length=500))
        
        # Get product section location
        base_parser = BaseRecordParser(encoding='EBCDIC')
        db2_parser = DB2ParserBase(base_parser)
        product_section = db2_parser.parse_product_section_header(bytes(record_data))
        
        product_offset = product_section['offset']
        qwhs_length = 94  # Standard QWHS header length
        
        # Track which headers we add and their offsets
        added_headers = {}
        current_offset = product_offset + qwhs_length
        
        # Header type mapping
        header_configs = [
            (has_correlation, 2, 'correlation', 40),
            (has_trace, 4, 'trace', 36),
            (has_cpu, 8, 'cpu', 32),
            (has_distributed, 16, 'distributed', 44),
            (has_data_sharing, 32, 'data_sharing', 48)
        ]
        
        # Add optional headers based on flags
        for should_add, header_type, header_name, header_length in header_configs:
            if should_add:
                # Write header at current offset
                struct.pack_into('>H', record_data, current_offset, header_length)  # Length
                struct.pack_into('B', record_data, current_offset + 2, header_type)  # Type
                struct.pack_into('B', record_data, current_offset + 3, 0xDB)  # RM ID
                
                added_headers[header_name] = {
                    'offset': current_offset,
                    'type': header_type,
                    'length': header_length
                }
                
                current_offset += header_length
        
        # Update product section length to include all headers
        total_product_length = current_offset - product_offset
        struct.pack_into('>H', record_data, 32, total_product_length)
        
        record_data = bytes(record_data)
        
        # Now test that we can find all the headers we added
        for header_name, header_info in added_headers.items():
            found_offset = db2_parser.find_header_by_type(
                record_data,
                product_offset,
                total_product_length,
                header_info['type']
            )
            
            assert found_offset is not None, \
                f"Optional header '{header_name}' (type {header_info['type']}) should be found"
            assert found_offset == header_info['offset'], \
                f"Header '{header_name}' should be at offset {header_info['offset']}, found at {found_offset}"
            
            # Verify we can read the header
            read_length = base_parser.read_binary(record_data, found_offset, 2)
            read_type = base_parser.read_binary(record_data, found_offset + 2, 1)
            
            assert read_length == header_info['length'], \
                f"Header '{header_name}' length should be {header_info['length']}, got {read_length}"
            assert read_type == header_info['type'], \
                f"Header '{header_name}' type should be {header_info['type']}, got {read_type}"
        
        # Verify that headers we didn't add are not found
        all_header_types = {2: 'correlation', 4: 'trace', 8: 'cpu', 16: 'distributed', 32: 'data_sharing'}
        for header_type, header_name in all_header_types.items():
            if header_name not in added_headers:
                found_offset = db2_parser.find_header_by_type(
                    record_data,
                    product_offset,
                    total_product_length,
                    header_type
                )
                
                assert found_offset is None, \
                    f"Header '{header_name}' (type {header_type}) should not be found (was not added)"
    
    @settings(max_examples=50)
    @given(
        record_type=st.sampled_from([101]),
        num_optional_headers=st.integers(min_value=0, max_value=5)
    )
    def test_optional_headers_in_sequence(
        self,
        record_type,
        num_optional_headers
    ):
        """
        Test that multiple optional headers can be found when present in sequence.
        
        This validates that the header scanning logic correctly handles multiple
        headers in the product section.
        """
        # Create base record
        qwhs_data = {'ifcid': 3, 'release_number': 0x0B00}
        record_data = bytearray(create_smf_record_with_qwhs(record_type, qwhs_data, record_length=500))
        
        # Get product section location
        base_parser = BaseRecordParser(encoding='EBCDIC')
        db2_parser = DB2ParserBase(base_parser)
        product_section = db2_parser.parse_product_section_header(bytes(record_data))
        
        product_offset = product_section['offset']
        qwhs_length = 94
        current_offset = product_offset + qwhs_length
        
        # Add specified number of optional headers
        header_types = [2, 4, 8, 16, 32]  # correlation, trace, cpu, distributed, data_sharing
        added_headers = []
        
        for i in range(min(num_optional_headers, len(header_types))):
            header_type = header_types[i]
            header_length = 40
            
            # Write header
            struct.pack_into('>H', record_data, current_offset, header_length)
            struct.pack_into('B', record_data, current_offset + 2, header_type)
            struct.pack_into('B', record_data, current_offset + 3, 0xDB)
            
            added_headers.append({
                'type': header_type,
                'offset': current_offset,
                'length': header_length
            })
            
            current_offset += header_length
        
        # Update product section length
        total_product_length = current_offset - product_offset
        struct.pack_into('>H', record_data, 32, total_product_length)
        
        record_data = bytes(record_data)
        
        # Verify all added headers can be found
        for header_info in added_headers:
            found_offset = db2_parser.find_header_by_type(
                record_data,
                product_offset,
                total_product_length,
                header_info['type']
            )
            
            assert found_offset == header_info['offset'], \
                f"Header type {header_info['type']} should be at offset {header_info['offset']}, found at {found_offset}"
    
    @settings(max_examples=50)
    @given(
        record_type=st.sampled_from([101])
    )
    def test_optional_headers_with_qwhs_only(self, record_type):
        """
        Test that when only QWHS header is present, no optional headers are found.
        
        This validates the baseline case where a record has no optional headers.
        """
        # Create record with only QWHS header
        qwhs_data = {'ifcid': 3, 'release_number': 0x0B00}
        record_data = create_smf_record_with_qwhs(record_type, qwhs_data)
        
        # Get product section location
        base_parser = BaseRecordParser(encoding='EBCDIC')
        db2_parser = DB2ParserBase(base_parser)
        product_section = db2_parser.parse_product_section_header(record_data)
        
        product_offset = product_section['offset']
        product_length = product_section['length']
        
        # Try to find optional headers - none should be found
        optional_header_types = [2, 4, 8, 16, 32]
        
        for header_type in optional_header_types:
            found_offset = db2_parser.find_header_by_type(
                record_data,
                product_offset,
                product_length,
                header_type
            )
            
            assert found_offset is None, \
                f"Optional header type {header_type} should not be found (only QWHS present)"
