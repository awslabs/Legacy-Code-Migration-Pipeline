#!/usr/bin/env python3
"""Unit tests for SMF Type 110 exception record parsing.

This module tests the enhanced exception record parsing functionality
that extracts exception type, resource name, and exception count.
"""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers.smf110_parser_v3r2 import SMF110ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser


class TestSMF110ExceptionParsing:
    """Test suite for SMF Type 110 exception record parsing."""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance for tests."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        return SMF110ParserV3R2(base_parser)
    
    @pytest.fixture
    def ebcdic_map(self):
        """EBCDIC character mapping for test data."""
        return {
            'A': 0xC1, 'B': 0xC2, 'C': 0xC3, 'D': 0xC4, 'E': 0xC5, 'F': 0xC6, 'G': 0xC7,
            'H': 0xC8, 'I': 0xC9, 'J': 0xD1, 'K': 0xD2, 'L': 0xD3, 'M': 0xD4, 'N': 0xD5,
            'O': 0xD6, 'P': 0xD7, 'Q': 0xD8, 'R': 0xD9, 'S': 0xE2, 'T': 0xE3, 'U': 0xE4,
            'V': 0xE5, 'W': 0xE6, 'X': 0xE7, 'Y': 0xE8, 'Z': 0xE9, ' ': 0x40, '0': 0xF0,
            '1': 0xF1, '2': 0xF2, '3': 0xF3, '4': 0xF4, '5': 0xF5, '6': 0xF6, '7': 0xF7,
            '8': 0xF8, '9': 0xF9
        }
    
    def create_exception_record(self, exception_type, resource_name, exception_count, ebcdic_map):
        """Helper to create test exception record."""
        # Convert resource name to EBCDIC
        resource_bytes = bytes([ebcdic_map.get(c, 0x40) for c in resource_name.ljust(8)])
        
        # Build exception record
        data = struct.pack('>H', exception_type)  # 2 bytes, big-endian
        data += resource_bytes  # 8 bytes EBCDIC
        data += struct.pack('>I', exception_count)  # 4 bytes, big-endian
        
        return data
    
    def test_parse_storage_shortage_exception(self, parser, ebcdic_map):
        """Test parsing storage shortage exception."""
        # Create test data
        exception_data = self.create_exception_record(1, 'TESTPOOL', 5, ebcdic_map)
        
        # Parse
        result = parser.parse_exception_record(exception_data, 0, len(exception_data))
        
        # Verify
        assert result['exception_type'] == 1
        assert result['resource_name'] == 'TESTPOOL'
        assert result['exception_count'] == 5
        assert result['exception_description'] == 'Storage shortage'
    
    def test_parse_task_limit_exception(self, parser, ebcdic_map):
        """Test parsing task limit exceeded exception."""
        exception_data = self.create_exception_record(2, 'MAXTASKS', 10, ebcdic_map)
        
        result = parser.parse_exception_record(exception_data, 0, len(exception_data))
        
        assert result['exception_type'] == 2
        assert result['resource_name'] == 'MAXTASKS'
        assert result['exception_count'] == 10
        assert result['exception_description'] == 'Task limit exceeded'
    
    def test_parse_file_control_shortage(self, parser, ebcdic_map):
        """Test parsing file control shortage exception."""
        exception_data = self.create_exception_record(3, 'FCTSHR', 3, ebcdic_map)
        
        result = parser.parse_exception_record(exception_data, 0, len(exception_data))
        
        assert result['exception_type'] == 3
        assert result['resource_name'] == 'FCTSHR'
        assert result['exception_count'] == 3
        assert result['exception_description'] == 'File control shortage'
    
    def test_parse_unknown_exception_type(self, parser, ebcdic_map):
        """Test parsing unknown exception type."""
        exception_data = self.create_exception_record(99, 'UNKNOWN', 1, ebcdic_map)
        
        result = parser.parse_exception_record(exception_data, 0, len(exception_data))
        
        assert result['exception_type'] == 99
        assert result['resource_name'] == 'UNKNOWN'
        assert result['exception_count'] == 1
        assert 'Unknown exception type 99' in result['exception_description']
    
    def test_parse_exception_with_zero_count(self, parser, ebcdic_map):
        """Test parsing exception with zero count."""
        exception_data = self.create_exception_record(1, 'ZEROTEST', 0, ebcdic_map)
        
        result = parser.parse_exception_record(exception_data, 0, len(exception_data))
        
        assert result['exception_type'] == 1
        assert result['resource_name'] == 'ZEROTEST'
        assert result['exception_count'] == 0
    
    def test_parse_exception_minimal_length(self, parser, ebcdic_map):
        """Test parsing exception with minimal length (no count field)."""
        # Only type and resource name (10 bytes)
        exception_type = 1
        resource_name = 'MINTEST'
        resource_bytes = bytes([ebcdic_map.get(c, 0x40) for c in resource_name.ljust(8)])
        exception_data = struct.pack('>H', exception_type) + resource_bytes
        
        result = parser.parse_exception_record(exception_data, 0, len(exception_data))
        
        assert result['exception_type'] == 1
        assert result['resource_name'] == 'MINTEST'
        assert 'exception_count' not in result  # Count field not present
    
    def test_parse_exception_too_short(self, parser):
        """Test parsing exception record that's too short."""
        # Only 5 bytes - not enough for type + resource name
        exception_data = b'\x00\x01\x00\x00\x00'
        
        result = parser.parse_exception_record(exception_data, 0, len(exception_data))
        
        assert 'note' in result
        assert 'too short' in result['note']
    
    def test_parse_exception_with_offset(self, parser, ebcdic_map):
        """Test parsing exception at non-zero offset."""
        # Create padding + exception data
        padding = b'\x00' * 50
        exception_data = self.create_exception_record(1, 'OFFSET', 7, ebcdic_map)
        full_data = padding + exception_data
        
        result = parser.parse_exception_record(full_data, 50, len(exception_data))
        
        assert result['offset'] == 50
        assert result['exception_type'] == 1
        assert result['resource_name'] == 'OFFSET'
        assert result['exception_count'] == 7
    
    def test_all_exception_types(self, parser, ebcdic_map):
        """Test all defined exception types."""
        exception_types = {
            1: 'Storage shortage',
            2: 'Task limit exceeded',
            3: 'File control shortage',
            4: 'Temporary storage shortage',
            5: 'Transient data shortage',
            6: 'Program compression',
            7: 'Transaction abend',
            8: 'System abend',
            9: 'Deadlock timeout',
            10: 'Resource unavailable'
        }
        
        for exc_type, expected_desc in exception_types.items():
            exception_data = self.create_exception_record(exc_type, 'TEST', 1, ebcdic_map)
            result = parser.parse_exception_record(exception_data, 0, len(exception_data))
            
            assert result['exception_type'] == exc_type
            assert result['exception_description'] == expected_desc


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
