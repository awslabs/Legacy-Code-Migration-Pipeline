"""Tests for SMF Type 2 parser."""

import pytest
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF2ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF2ParserV3R2:
    """Test suite for SMF Type 2 parser."""
    
    def test_parse_standard_header_only(self):
        """Test parsing SMF Type 2 record with standard header only (no subtypes)."""
        # Create a minimal SMF Type 2 record (18 bytes)
        # Standard header without subtypes
        record_data = bytearray(18)
        
        # Record length (offset 0, 2 bytes) = 18
        record_data[0:2] = (18).to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes) = 0
        record_data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte) = 0x38 (no subtype bit, bit 1 = 0x40 is OFF)
        # Bits 3-6 are version indicators, so 0x38 = 0011 1000
        record_data[4] = 0x38
        
        # Record type (offset 5, 1 byte) = 2
        record_data[5] = 2
        
        # Time (offset 6, 4 bytes) = 36000 (10:00:00.00)
        record_data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes packed) = 0x0124001F (2024-001)
        record_data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes EBCDIC) = "SYS1"
        # EBCDIC encoding for "SYS1"
        sys_id_ebcdic = "SYS1".encode('cp037')
        record_data[14:18] = sys_id_ebcdic
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF2ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Verify basic fields
        assert result.record_type == 2
        assert result.subtype == 0
        assert result.record_length == 18
        assert result.system_id == "SYS1"
        assert result.date == date(2024, 1, 1)
        assert result.header['subtypes_supported'] is False
    
    def test_parse_subtype1_signature_group(self):
        """Test parsing SMF Type 2 subtype 1 (signature group) record."""
        # Create a minimal SMF Type 2 subtype 1 record
        # Need at least 88 bytes (header + signature fields + minimal signature)
        record_data = bytearray(88)
        
        # Record length (offset 0, 2 bytes) = 88
        record_data[0:2] = (88).to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes) = 0
        record_data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte) = 0xF8 (subtype bit ON = 0x40 | 0x78)
        record_data[4] = 0xF8
        
        # Record type (offset 5, 1 byte) = 2
        record_data[5] = 2
        
        # Time (offset 6, 4 bytes) = 36000 (10:00:00.00)
        record_data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes packed) = 0x0124001F (2024-001)
        record_data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes EBCDIC) = "DUMY"
        sys_id_ebcdic = "DUMY".encode('cp037')
        record_data[14:18] = sys_id_ebcdic
        
        # Subsystem ID (offset 18, 4 bytes EBCDIC) = "SMFG"
        subsys_id_ebcdic = "SMFG".encode('cp037')
        record_data[18:22] = subsys_id_ebcdic
        
        # Subtype (offset 22, 2 bytes) = 1
        record_data[22:24] = (1).to_bytes(2, 'big')
        
        # Group's SID (offset 24, 4 bytes EBCDIC) = "SYS1"
        group_sid_ebcdic = "SYS1".encode('cp037')
        record_data[24:28] = group_sid_ebcdic
        
        # Group flags (offset 28, 1 byte) = 0x80 (first group written)
        record_data[28] = 0x80
        
        # Group record type (offset 29, 1 byte) = 30
        record_data[29] = 30
        
        # Group record subtype (offset 30, 2 bytes) = 1
        record_data[30:32] = (1).to_bytes(2, 'big')
        
        # First record time (offset 32, 4 bytes) = 36000
        record_data[32:36] = (36000).to_bytes(4, 'big')
        
        # First record date (offset 36, 4 bytes packed) = 0x0124001F
        record_data[36:40] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # Record count (offset 40, 4 bytes) = 100
        record_data[40:44] = (100).to_bytes(4, 'big')
        
        # Hash method (offset 44, 1 byte) = 0x40 (SHA256)
        record_data[44] = 0x40
        
        # Signature type (offset 45, 1 byte) = 0x80 (RSA)
        record_data[45] = 0x80
        
        # Token name (offset 46, 32 bytes EBCDIC) = "TOKEN001"
        token_name_ebcdic = "TOKEN001".ljust(32).encode('cp037')
        record_data[46:78] = token_name_ebcdic
        
        # Extended record type (offset 78, 2 bytes) = 0
        record_data[78:80] = (0).to_bytes(2, 'big')
        
        # Signature length (offset 80, 4 bytes) = 4
        record_data[80:84] = (4).to_bytes(4, 'big')
        
        # Digital signature (offset 84, 4 bytes) = dummy data
        record_data[84:88] = bytes([0xDE, 0xAD, 0xBE, 0xEF])
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF2ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Verify basic fields
        assert result.record_type == 2
        assert result.subtype == 1
        assert result.record_length == 88
        assert result.system_id == "DUMY"
        assert result.header['subtypes_supported'] is True
        assert result.header['subsystem_id'] == "SMFG"
        
        # Verify signature data
        assert result.subsystem is not None
        sig_data = result.subsystem['signature_data']
        assert sig_data is not None
        assert sig_data['group_sid'] == "SYS1"
        assert sig_data['first_group_written'] is True
        assert sig_data['group_record_type'] == 30
        assert sig_data['group_record_subtype'] == 1
        assert sig_data['record_count'] == 100
        assert "SHA256" in sig_data['hash_method']
        assert "RSA" in sig_data['signature_type']
        assert sig_data['signature_length'] == 4
        assert sig_data['digital_signature'] == "deadbeef"
    
    def test_parse_subtype2_signature_interval(self):
        """Test parsing SMF Type 2 subtype 2 (signature interval) record."""
        # Create a minimal SMF Type 2 subtype 2 record
        # Need at least 104 bytes (header + signature fields + minimal signature)
        record_data = bytearray(104)
        
        # Record length (offset 0, 2 bytes) = 104
        record_data[0:2] = (104).to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes) = 0
        record_data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte) = 0xF8 (subtype bit ON)
        record_data[4] = 0xF8
        
        # Record type (offset 5, 1 byte) = 2
        record_data[5] = 2
        
        # Time (offset 6, 4 bytes) = 36000
        record_data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes packed) = 0x0124001F
        record_data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes EBCDIC) = "DUMY"
        sys_id_ebcdic = "DUMY".encode('cp037')
        record_data[14:18] = sys_id_ebcdic
        
        # Subsystem ID (offset 18, 4 bytes EBCDIC) = "SMFI"
        subsys_id_ebcdic = "SMFI".encode('cp037')
        record_data[18:22] = subsys_id_ebcdic
        
        # Subtype (offset 22, 2 bytes) = 2
        record_data[22:24] = (2).to_bytes(2, 'big')
        
        # Interval's SID (offset 24, 4 bytes EBCDIC) = "SYS1"
        interval_sid_ebcdic = "SYS1".encode('cp037')
        record_data[24:28] = interval_sid_ebcdic
        
        # Interval flags (offset 28, 1 byte) = 0x80 (first interval written)
        record_data[28] = 0x80
        
        # Interval record type (offset 29, 1 byte) = 30
        record_data[29] = 30
        
        # Interval record subtype (offset 30, 2 bytes) = 1
        record_data[30:32] = (1).to_bytes(2, 'big')
        
        # First record time (offset 32, 4 bytes) = 36000
        record_data[32:36] = (36000).to_bytes(4, 'big')
        
        # First record date (offset 36, 4 bytes packed) = 0x0124001F
        record_data[36:40] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # Last record time (offset 40, 4 bytes) = 72000
        record_data[40:44] = (72000).to_bytes(4, 'big')
        
        # Last record date (offset 44, 4 bytes packed) = 0x0124001F
        record_data[44:48] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # Next interval time (offset 48, 4 bytes) = 108000
        record_data[48:52] = (108000).to_bytes(4, 'big')
        
        # Next interval date (offset 52, 4 bytes packed) = 0x0124001F
        record_data[52:56] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # Record count (offset 56, 4 bytes) = 500
        record_data[56:60] = (500).to_bytes(4, 'big')
        
        # Hash method (offset 60, 1 byte) = 0x10 (SHA512)
        record_data[60] = 0x10
        
        # Signature type (offset 61, 1 byte) = 0x40 (ECDSA)
        record_data[61] = 0x40
        
        # Token name (offset 62, 32 bytes EBCDIC) = "TOKEN002"
        token_name_ebcdic = "TOKEN002".ljust(32).encode('cp037')
        record_data[62:94] = token_name_ebcdic
        
        # Extended record type (offset 94, 2 bytes) = 0
        record_data[94:96] = (0).to_bytes(2, 'big')
        
        # Signature length (offset 96, 4 bytes) = 4
        record_data[96:100] = (4).to_bytes(4, 'big')
        
        # Digital signature (offset 100, 4 bytes) = dummy data
        record_data[100:104] = bytes([0xCA, 0xFE, 0xBA, 0xBE])
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF2ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Verify basic fields
        assert result.record_type == 2
        assert result.subtype == 2
        assert result.record_length == 104
        assert result.system_id == "DUMY"
        assert result.header['subtypes_supported'] is True
        assert result.header['subsystem_id'] == "SMFI"
        
        # Verify signature data
        assert result.subsystem is not None
        sig_data = result.subsystem['signature_data']
        assert sig_data is not None
        assert sig_data['interval_sid'] == "SYS1"
        assert sig_data['first_interval_written'] is True
        assert sig_data['interval_record_type'] == 30
        assert sig_data['interval_record_subtype'] == 1
        assert sig_data['record_count'] == 500
        assert "SHA512" in sig_data['hash_method']
        assert "ECDSA" in sig_data['signature_type']
        assert sig_data['signature_length'] == 4
        assert sig_data['digital_signature'] == "cafebabe"
    
    def test_invalid_record_type(self):
        """Test that parser rejects records with wrong record type."""
        # Create a record with wrong type
        record_data = bytearray(18)
        record_data[0:2] = (18).to_bytes(2, 'big')
        record_data[5] = 30  # Wrong type (should be 2)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF2ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(record_data))
        
        assert "Record type mismatch" in str(exc_info.value)
    
    def test_invalid_record_length(self):
        """Test that parser rejects records with mismatched length."""
        # Create a record with wrong length field
        record_data = bytearray(18)
        record_data[0:2] = (100).to_bytes(2, 'big')  # Wrong length (actual is 18)
        record_data[5] = 2
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF2ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(record_data))
        
        assert "Record length mismatch" in str(exc_info.value)
