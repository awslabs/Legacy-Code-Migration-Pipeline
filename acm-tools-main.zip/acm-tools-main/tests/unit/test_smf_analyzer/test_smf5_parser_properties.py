"""Property-based tests for SMF Type 5 parser.

Feature: smf-parser-expansion
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers import SMF5ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_type5_record(
    record_length: int = 200,
    system_id: str = "SYS1",
    job_name: str = "TESTJOB",
    user_id: str = "USER1",
    num_steps: int = 1,
    job_completion_code: int = 0,
    job_priority: int = 10,
    programmer_name: str = "PROGRAMMER",
    num_acct_fields: int = 0
) -> bytes:
    """Create a synthetic Type 5 record for testing.
    
    Args:
        record_length: Total record length
        system_id: 4-character system ID
        job_name: 8-character job name
        user_id: 8-character user ID
        num_steps: Number of steps in job (1-255)
        job_completion_code: Job completion code
        job_priority: Job priority (0-13)
        programmer_name: 20-character programmer name
        num_acct_fields: Number of accounting fields (0-255)
        
    Returns:
        Binary SMF Type 5 record
    """
    record = bytearray(record_length)
    
    # Standard SMF header (18 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 5)  # Record type = 5
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    
    # Date (packed decimal 0cyydddF) - 2025001F (Jan 1, 2025)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    # System ID (EBCDIC)
    sys_id_bytes = system_id.ljust(4).encode('cp037')[:4]
    record[14:18] = sys_id_bytes
    
    # Job identification (offsets 18-41)
    job_name_bytes = job_name.ljust(8).encode('cp037')[:8]
    record[18:26] = job_name_bytes
    
    struct.pack_into('>I', record, 26, 18000)  # Reader start time
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader start date
    
    user_id_bytes = user_id.ljust(8).encode('cp037')[:8]
    record[34:42] = user_id_bytes
    
    # Job statistics (offsets 42-65)
    struct.pack_into('B', record, 42, num_steps)  # Number of steps
    struct.pack_into('>I', record, 43, 19000)  # Initiator select time
    record[47:51] = bytes([0x01, 0x25, 0x00, 0x1F])  # Initiator select date
    struct.pack_into('>I', record, 51, 100)  # Card image count
    struct.pack_into('>H', record, 55, job_completion_code)  # Job completion code
    struct.pack_into('B', record, 57, job_priority)  # Job priority
    struct.pack_into('>I', record, 58, 20000)  # Reader end time
    record[62:66] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader end date
    
    # Job termination indicator (offset 66)
    struct.pack_into('B', record, 66, 0)  # Normal termination
    
    # Reserved (offset 67)
    struct.pack_into('B', record, 67, 0)
    
    # Transaction and timing data (offsets 68-95)
    struct.pack_into('>I', record, 68, 1000)  # Transaction residency time
    struct.pack_into('B', record, 73, 1)  # Reader device class
    struct.pack_into('B', record, 74, 1)  # Reader unit type
    
    job_input_class = "A".encode('cp037')
    record[75:76] = job_input_class
    
    struct.pack_into('B', record, 76, 8)  # Storage protect key
    
    # SRB CPU time (3 bytes at offset 77)
    srb_time = 100
    record[77] = (srb_time >> 16) & 0xFF
    record[78] = (srb_time >> 8) & 0xFF
    record[79] = srb_time & 0xFF
    
    struct.pack_into('>I', record, 80, 5000)  # Job service
    struct.pack_into('>I', record, 84, 2000)  # Transaction active time
    struct.pack_into('>H', record, 92, 1)  # Performance group
    
    # Fixed portion length and programmer name (offsets 96-116)
    struct.pack_into('B', record, 96, 21)  # Fixed length
    
    prog_name_bytes = programmer_name.ljust(20).encode('cp037')[:20]
    record[97:117] = prog_name_bytes
    
    # Accounting section (offset 120+)
    struct.pack_into('B', record, 120, num_acct_fields)  # Number of accounting fields
    
    # For simplicity, no accounting fields in this test
    # Relocate section would follow accounting fields
    
    return bytes(record)


# Strategies for generating test data
ebcdic_chars = st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

system_ids = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=4
).map(lambda x: x.ljust(4)[:4])

names_8char = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=8
).map(lambda x: x.ljust(8)[:8])

names_20char = st.text(
    alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ',
    min_size=1,
    max_size=20
).map(lambda x: x.ljust(20)[:20])


class TestSMF5ParserProperties:
    """Property-based tests for SMF Type 5 parser."""
    
    @settings(max_examples=100)
    @given(
        system_id=system_ids,
        job_name=names_8char,
        user_id=names_8char,
        num_steps=st.integers(min_value=1, max_value=255),
        job_completion_code=st.integers(min_value=0, max_value=65535),
        job_priority=st.integers(min_value=0, max_value=13),
        programmer_name=names_20char
    )
    def test_property_1_field_extraction_completeness(
        self, system_id, job_name, user_id, num_steps,
        job_completion_code, job_priority, programmer_name
    ):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.4**
        
        For any SMF Type 5 record, parsing should extract all standard header fields
        (record_type, subtype, system_id, timestamp, date, record_length) and all
        documented type-specific fields.
        """
        # Create test record
        record_data = create_type5_record(
            system_id=system_id,
            job_name=job_name,
            user_id=user_id,
            num_steps=num_steps,
            job_completion_code=job_completion_code,
            job_priority=job_priority,
            programmer_name=programmer_name
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header fields are present
        assert parsed.record_type == 5, "record_type should be 5"
        assert parsed.subtype == 0, "subtype should be 0 (Type 5 has no subtypes)"
        assert parsed.system_id is not None, "system_id should be extracted"
        assert parsed.timestamp is not None, "timestamp should be extracted"
        assert parsed.date is not None, "date should be extracted"
        assert parsed.record_length == 200, "record_length should match"
        
        # Verify identification section is present
        assert parsed.identification is not None, "identification section should be present"
        ident = parsed.identification
        
        assert 'job_name' in ident, "job_name should be extracted"
        assert 'user_id' in ident, "user_id should be extracted"
        assert 'reader_start_time' in ident, "reader_start_time should be extracted"
        assert 'reader_start_date' in ident, "reader_start_date should be extracted"
        
        # Verify performance section is present
        assert parsed.performance is not None, "performance section should be present"
        perf = parsed.performance
        
        assert 'num_steps' in perf, "num_steps should be extracted"
        assert 'initiator_select_time' in perf, "initiator_select_time should be extracted"
        assert 'initiator_select_date' in perf, "initiator_select_date should be extracted"
        assert 'card_image_count' in perf, "card_image_count should be extracted"
        assert 'job_completion_code' in perf, "job_completion_code should be extracted"
        assert 'job_priority' in perf, "job_priority should be extracted"
        assert 'reader_end_time' in perf, "reader_end_time should be extracted"
        assert 'reader_end_date' in perf, "reader_end_date should be extracted"
        assert 'job_termination_indicator' in perf, "job_termination_indicator should be extracted"
        assert 'transaction_residency_time' in perf, "transaction_residency_time should be extracted"
        assert 'reader_device_class' in perf, "reader_device_class should be extracted"
        assert 'reader_unit_type' in perf, "reader_unit_type should be extracted"
        assert 'job_input_class' in perf, "job_input_class should be extracted"
        assert 'storage_protect_key' in perf, "storage_protect_key should be extracted"
        assert 'srb_cpu_time' in perf, "srb_cpu_time should be extracted"
        assert 'job_service' in perf, "job_service should be extracted"
        assert 'transaction_active_time' in perf, "transaction_active_time should be extracted"
        assert 'performance_group' in perf, "performance_group should be extracted"
        assert 'fixed_length' in perf, "fixed_length should be extracted"
        assert 'programmer_name' in perf, "programmer_name should be extracted"
        assert 'abend' in perf, "abend flag should be extracted"
        assert 'canceled_by_iefujv' in perf, "canceled_by_iefujv flag should be extracted"
        assert 'canceled_by_iefuji' in perf, "canceled_by_iefuji flag should be extracted"
        assert 'canceled_by_iefusi' in perf, "canceled_by_iefusi flag should be extracted"
        assert 'canceled_by_iefactrt' in perf, "canceled_by_iefactrt flag should be extracted"
        
        # Verify accounting section is present
        assert parsed.accounting is not None, "accounting section should be present"
        acct = parsed.accounting
        assert 'num_fields' in acct, "num_fields should be extracted"
        
        # Verify extracted values match input
        assert ident['job_name'].strip() == job_name.strip(), \
            "job_name value should match input"
        assert ident['user_id'].strip() == user_id.strip(), \
            "user_id value should match input"
        assert perf['num_steps'] == num_steps, \
            "num_steps value should match input"
        assert perf['job_completion_code'] == job_completion_code, \
            "job_completion_code value should match input"
        assert perf['job_priority'] == job_priority, \
            "job_priority value should match input"
        assert perf['programmer_name'].strip() == programmer_name.strip(), \
            "programmer_name value should match input"
