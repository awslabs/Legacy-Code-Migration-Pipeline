"""Unit tests for SMF Type 101 V11 and V12 parsers.

Feature: db2-versioned-smf-parsers
Tests: Requirements 4.1, 4.2, 4.5, 9.1
"""

import pytest
import struct
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf101_parser_v11 import SMF101ParserV11
from tools.smf_analyzer.smf_record_parser.parsers.smf101_parser_v12 import SMF101ParserV12
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_smf101_record(
    db2_version: str = "V11",
    ifcid: int = 3,
    record_length: int = 400,
    system_id: str = "SYS1",
    subsystem_id: str = "DB2P",
    include_optional_headers: bool = True
) -> bytes:
    """Create a synthetic SMF Type 101 record for testing.
    
    Args:
        db2_version: DB2 version ("V11" or "V12")
        ifcid: IFCID value (3 for accounting)
        record_length: Total record length
        system_id: System identifier (4 chars)
        subsystem_id: Subsystem identifier (4 chars)
        include_optional_headers: Whether to include optional headers
        
    Returns:
        Synthetic SMF Type 101 record as bytes
    """
    record = bytearray(record_length + 1)
    
    # SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0)  # System indicator
    struct.pack_into('B', record, 5, 101)  # Record type
    
    # Timestamp (4 bytes at offset 6)
    struct.pack_into('>I', record, 6, 0x12345678)
    
    # Date (4 bytes at offset 10)
    struct.pack_into('>I', record, 10, 0x20240115)
    
    # System ID (4 bytes at offset 14)
    record[14:18] = system_id.ljust(4).encode('cp037')
    
    # Subsystem ID (4 bytes at offset 18)
    record[18:22] = subsystem_id.ljust(4).encode('cp037')
    
    # Subtype (2 bytes at offset 22)
    struct.pack_into('>H', record, 22, ifcid)
    
    # Product section triplet (at offset 28)
    product_offset = 136  # After self-defining section
    product_length = 94  # QWHS header length
    
    if include_optional_headers:
        # Add space for optional headers
        product_length += 160  # Space for 4 optional headers
    
    struct.pack_into('>I', record, 28, product_offset)  # Offset
    struct.pack_into('>H', record, 32, product_length)  # Length
    struct.pack_into('>H', record, 34, 1)  # Count
    
    # Self-defining section triplets (QWA0 structure starting at offset 36)
    # QWAC triplet (R1)
    struct.pack_into('>I', record, 36, 300)  # Offset
    struct.pack_into('>H', record, 40, 50)  # Length
    struct.pack_into('>H', record, 42, 1)  # Number
    
    # QXST triplet (R2)
    struct.pack_into('>I', record, 44, 350)  # Offset
    struct.pack_into('>H', record, 48, 40)  # Length
    struct.pack_into('>H', record, 50, 1)  # Number
    
    # QBAC triplet (R3)
    struct.pack_into('>I', record, 52, 0)  # Offset (not present)
    struct.pack_into('>H', record, 56, 0)  # Length
    struct.pack_into('>H', record, 58, 0)  # Number
    
    # QTXA triplet (R4)
    struct.pack_into('>I', record, 60, 0)  # Offset (not present)
    struct.pack_into('>H', record, 64, 0)  # Length
    struct.pack_into('>H', record, 66, 0)  # Number
    
    # QLAC triplet (R5)
    struct.pack_into('>I', record, 68, 0)  # Offset (not present)
    struct.pack_into('>H', record, 72, 0)  # Length
    struct.pack_into('>H', record, 74, 0)  # Number
    
    # QMDA triplet (R6)
    struct.pack_into('>I', record, 76, 0)  # Offset (not present)
    struct.pack_into('>H', record, 80, 0)  # Length
    struct.pack_into('>H', record, 82, 0)  # Number
    
    # QIFA triplet (R7)
    struct.pack_into('>I', record, 84, 0)  # Offset (not present)
    struct.pack_into('>H', record, 88, 0)  # Length
    struct.pack_into('>H', record, 90, 0)  # Number
    
    # QWAR triplet (R8)
    struct.pack_into('>I', record, 92, 0)  # Offset (not present)
    struct.pack_into('>H', record, 96, 0)  # Length
    struct.pack_into('>H', record, 98, 0)  # Number
    
    # QBGA triplet (R9)
    struct.pack_into('>I', record, 100, 0)  # Offset (not present)
    struct.pack_into('>H', record, 104, 0)  # Length
    struct.pack_into('>H', record, 106, 0)  # Number
    
    # QTGA triplet (RA)
    struct.pack_into('>I', record, 108, 0)  # Offset (not present)
    struct.pack_into('>H', record, 112, 0)  # Length
    struct.pack_into('>H', record, 114, 0)  # Number
    
    # QWDA triplet (RB) - only for V11
    if db2_version == "V11":
        struct.pack_into('>I', record, 116, 0)  # Offset (not present)
        struct.pack_into('>H', record, 120, 0)  # Length
        struct.pack_into('>H', record, 122, 0)  # Number
    
    # QWAX triplet (RC)
    struct.pack_into('>I', record, 124, 0)  # Offset (not present)
    struct.pack_into('>H', record, 128, 0)  # Length
    struct.pack_into('>H', record, 130, 0)  # Number
    
    # Q8AC triplet (RD)
    struct.pack_into('>I', record, 132, 0)  # Offset (not present)
    struct.pack_into('>H', record, 136, 0)  # Length
    struct.pack_into('>H', record, 138, 0)  # Number
    
    # QWHS standard header (at product_offset)
    release_number = 0x0B00 if db2_version == "V11" else 0x0C00
    
    struct.pack_into('>H', record, product_offset, 94)  # Header length
    struct.pack_into('B', record, product_offset + 2, 1)  # Header type (QWHS)
    struct.pack_into('B', record, product_offset + 3, 0xDB)  # Resource manager ID (DB2)
    struct.pack_into('>H', record, product_offset + 4, ifcid)  # IFCID
    struct.pack_into('>H', record, product_offset + 6, release_number)  # Release number
    struct.pack_into('B', record, product_offset + 8, 0)  # Num self-defining areas
    struct.pack_into('B', record, product_offset + 9, 0)  # Release indicator
    struct.pack_into('>I', record, product_offset + 10, 0)  # ACE address
    
    # Subsystem name (4 bytes at product_offset + 14)
    record[product_offset + 14:product_offset + 18] = subsystem_id.ljust(4).encode('cp037')
    
    # Store clock (8 bytes at product_offset + 18)
    struct.pack_into('>Q', record, product_offset + 18, 0x1234567890ABCDEF)
    
    # IFCID sequence (4 bytes at product_offset + 26)
    struct.pack_into('>I', record, product_offset + 26, 12345)
    
    # Destination sequence (4 bytes at product_offset + 30)
    struct.pack_into('>I', record, product_offset + 30, 67890)
    
    # Trace number mask (4 bytes at product_offset + 34)
    struct.pack_into('>I', record, product_offset + 34, 0xFFFFFFFF)
    
    # Local location name (16 bytes at product_offset + 38)
    record[product_offset + 38:product_offset + 54] = b'LOCATION1       '
    
    # LUWID (24 bytes at product_offset + 54)
    record[product_offset + 54:product_offset + 78] = b'LUWID123456789012345678'
    
    # Network ID (8 bytes at product_offset + 78)
    record[product_offset + 78:product_offset + 86] = b'NETID123'
    
    # LUNAME (8 bytes at product_offset + 86)
    record[product_offset + 86:product_offset + 94] = b'LUNAME12'
    
    # Add optional headers if requested
    if include_optional_headers:
        current_offset = product_offset + 94
        
        # Correlation header (type 2)
        struct.pack_into('>H', record, current_offset, 40)  # Length
        struct.pack_into('B', record, current_offset + 2, 2)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 40
        
        # Trace header (type 4)
        struct.pack_into('>H', record, current_offset, 36)  # Length
        struct.pack_into('B', record, current_offset + 2, 4)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 36
        
        # CPU header (type 8)
        struct.pack_into('>H', record, current_offset, 32)  # Length
        struct.pack_into('B', record, current_offset + 2, 8)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 32
        
        # Distributed header (type 16)
        struct.pack_into('>H', record, current_offset, 44)  # Length
        struct.pack_into('B', record, current_offset + 2, 16)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 44
    
    return bytes(record[:record_length])


def create_smf101_record_with_data_sections(
    db2_version: str = "V11",
    include_qbac: bool = False,
    include_qlac: bool = False
) -> bytes:
    """Create SMF 101 record with populated data sections for testing.
    
    Args:
        db2_version: DB2 version ("V11" or "V12")
        include_qbac: Whether to include QBAC section
        include_qlac: Whether to include QLAC section
        
    Returns:
        Synthetic SMF Type 101 record with data sections
    """
    record_length = 750  # Increased to accommodate all sections including QLAC
    record = bytearray(record_length + 1)
    
    # SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('B', record, 5, 101)  # Record type
    struct.pack_into('>I', record, 6, 0x12345678)  # Timestamp
    struct.pack_into('>I', record, 10, 0x20240115)  # Date
    record[14:18] = b'SYS1'
    record[18:22] = b'DB2P'
    struct.pack_into('>H', record, 22, 3)  # IFCID
    
    # Product section triplet
    product_offset = 200
    struct.pack_into('>I', record, 28, product_offset)
    struct.pack_into('>H', record, 32, 94)
    struct.pack_into('>H', record, 34, 1)
    
    # QWAC triplet (R1) - at offset 36
    qwac_offset = 300
    struct.pack_into('>I', record, 36, qwac_offset)
    struct.pack_into('>H', record, 40, 250)  # Length
    struct.pack_into('>H', record, 42, 1)  # Number
    
    # QXST triplet (R2) - at offset 44
    qxst_offset = 400
    struct.pack_into('>I', record, 44, qxst_offset)
    struct.pack_into('>H', record, 48, 200)  # Length
    struct.pack_into('>H', record, 50, 1)  # Number
    
    # QBAC triplet (R3) - at offset 52
    if include_qbac:
        qbac_offset = 500
        struct.pack_into('>I', record, 52, qbac_offset)
        struct.pack_into('>H', record, 56, 50)
        struct.pack_into('>H', record, 58, 1)
    else:
        struct.pack_into('>I', record, 52, 0)
        struct.pack_into('>H', record, 56, 0)
        struct.pack_into('>H', record, 58, 0)
    
    # QTXA triplet (R4) - at offset 60
    struct.pack_into('>I', record, 60, 0)
    struct.pack_into('>H', record, 64, 0)
    struct.pack_into('>H', record, 66, 0)
    
    # QLAC triplet (R5) - at offset 68 (varying length)
    if include_qlac:
        qlac_offset = 550
        struct.pack_into('>I', record, 68, qlac_offset)
        struct.pack_into('>H', record, 72, 0)  # Length = 0 for varying
        struct.pack_into('>H', record, 74, 2)  # Number = 2 members
    else:
        struct.pack_into('>I', record, 68, 0)
        struct.pack_into('>H', record, 72, 0)
        struct.pack_into('>H', record, 74, 0)
    
    # Remaining triplets (R6-RD) - all empty
    for i in range(6, 14):
        offset_pos = 76 + ((i - 6) * 8)
        struct.pack_into('>I', record, offset_pos, 0)
        struct.pack_into('>H', record, offset_pos + 4, 0)
        struct.pack_into('>H', record, offset_pos + 6, 0)
    
    # QWHS header at product_offset
    release_number = 0x0B00 if db2_version == "V11" else 0x0C00
    struct.pack_into('>H', record, product_offset, 94)
    struct.pack_into('B', record, product_offset + 2, 1)
    struct.pack_into('B', record, product_offset + 3, 0xDB)
    struct.pack_into('>H', record, product_offset + 4, 3)  # IFCID
    struct.pack_into('>H', record, product_offset + 6, release_number)
    record[product_offset + 14:product_offset + 18] = b'DB2P'
    
    # QWAC section data at qwac_offset
    struct.pack_into('>Q', record, qwac_offset, 0x1234567890ABCDEF)  # Begin store clock
    struct.pack_into('>Q', record, qwac_offset + 8, 0x1234567890ABCDF0)  # End store clock
    struct.pack_into('>Q', record, qwac_offset + 16, 1000000)  # Begin CPU time
    struct.pack_into('>Q', record, qwac_offset + 24, 2000000)  # End CPU time
    struct.pack_into('>I', record, qwac_offset + 48, 1)  # Reason invoked
    struct.pack_into('>I', record, qwac_offset + 68, 5)  # Commit count
    struct.pack_into('>I', record, qwac_offset + 72, 0)  # Abort count
    struct.pack_into('>Q', record, qwac_offset + 76, 5000000)  # Accumulated elapsed
    struct.pack_into('>Q', record, qwac_offset + 84, 3000000)  # Accumulated CPU
    struct.pack_into('>Q', record, qwac_offset + 100, 500000)  # Wait I/O
    struct.pack_into('>Q', record, qwac_offset + 108, 100000)  # Wait lock
    struct.pack_into('>I', record, qwac_offset + 116, 10)  # Entry/exit count
    struct.pack_into('>H', record, qwac_offset + 224, 0x0003)  # Flags (class2+class3)
    struct.pack_into('>H', record, qwac_offset + 226, 2)  # Package count
    
    # QXST section data at qxst_offset
    struct.pack_into('>Q', record, qxst_offset + 8, 100)  # SELECT count
    struct.pack_into('>Q', record, qxst_offset + 16, 20)  # INSERT count
    struct.pack_into('>Q', record, qxst_offset + 24, 15)  # UPDATE count
    struct.pack_into('>Q', record, qxst_offset + 32, 5)  # DELETE count
    struct.pack_into('>Q', record, qxst_offset + 40, 10)  # DESCRIBE count
    struct.pack_into('>Q', record, qxst_offset + 48, 25)  # PREPARE count
    struct.pack_into('>Q', record, qxst_offset + 56, 30)  # OPEN count
    struct.pack_into('>Q', record, qxst_offset + 64, 30)  # CLOSE count
    struct.pack_into('>Q', record, qxst_offset + 192, 500)  # FETCH count
    
    # QBAC section data if included
    if include_qbac:
        struct.pack_into('>I', record, qbac_offset, 1)  # Buffer pool ID
        struct.pack_into('>I', record, qbac_offset + 4, 10000)  # Getpage requests
        struct.pack_into('>I', record, qbac_offset + 16, 100)  # Sync read I/O
        struct.pack_into('>I', record, qbac_offset + 20, 50)  # Seq prefetch
        struct.pack_into('>I', record, qbac_offset + 28, 25)  # List prefetch
        struct.pack_into('>I', record, qbac_offset + 32, 10)  # Dynamic prefetch
    
    # QLAC section data if included (varying length)
    if include_qlac:
        current_offset = qlac_offset
        
        # Member 1
        member1_length = 80
        struct.pack_into('>H', record, current_offset, member1_length)
        current_offset += 2
        record[current_offset + 8:current_offset + 24] = b'REMOTE_LOC1     '
        struct.pack_into('>Q', record, current_offset + 32, 5)  # Conversations
        struct.pack_into('>Q', record, current_offset + 56, 100)  # Messages sent
        struct.pack_into('>Q', record, current_offset + 64, 95)  # Messages received
        current_offset += member1_length
        
        # Member 2
        member2_length = 80
        struct.pack_into('>H', record, current_offset, member2_length)
        current_offset += 2
        record[current_offset + 8:current_offset + 24] = b'REMOTE_LOC2     '
        struct.pack_into('>Q', record, current_offset + 32, 3)  # Conversations
        struct.pack_into('>Q', record, current_offset + 56, 50)  # Messages sent
        struct.pack_into('>Q', record, current_offset + 64, 48)  # Messages received
    
    return bytes(record[:record_length])


def create_smf101_record_with_optional_headers(db2_version: str = "V11") -> bytes:
    """Create SMF 101 record with detailed optional headers for testing.
    
    Args:
        db2_version: DB2 version ("V11" or "V12")
        
    Returns:
        Synthetic SMF Type 101 record with optional headers
    """
    record_length = 500
    record = bytearray(record_length + 1)
    
    # SMF header
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('B', record, 5, 101)
    struct.pack_into('>I', record, 6, 0x12345678)
    struct.pack_into('>I', record, 10, 0x20240115)
    record[14:18] = b'SYS1'
    record[18:22] = b'DB2P'
    struct.pack_into('>H', record, 22, 3)
    
    # Product section triplet
    product_offset = 200
    product_length = 94 + 80 + 60 + 40  # QWHS + QWHC + QWHD + QWHA
    struct.pack_into('>I', record, 28, product_offset)
    struct.pack_into('>H', record, 32, product_length)
    struct.pack_into('>H', record, 34, 1)
    
    # Empty data section triplets
    for i in range(13):
        offset_pos = 36 + (i * 8)
        struct.pack_into('>I', record, offset_pos, 0)
        struct.pack_into('>H', record, offset_pos + 4, 0)
        struct.pack_into('>H', record, offset_pos + 6, 0)
    
    # QWHS header
    release_number = 0x0B00 if db2_version == "V11" else 0x0C00
    current_offset = product_offset
    struct.pack_into('>H', record, current_offset, 94)
    struct.pack_into('B', record, current_offset + 2, 1)  # Type
    struct.pack_into('B', record, current_offset + 3, 0xDB)
    struct.pack_into('>H', record, current_offset + 4, 3)  # IFCID
    struct.pack_into('>H', record, current_offset + 6, release_number)
    record[current_offset + 14:current_offset + 18] = b'DB2P'
    current_offset += 94
    
    # QWHC (Correlation) header
    struct.pack_into('>H', record, current_offset, 80)  # Length
    struct.pack_into('B', record, current_offset + 2, 2)  # Type
    struct.pack_into('B', record, current_offset + 3, 0xDB)
    record[current_offset + 4:current_offset + 12] = b'AUTHID01'  # Authorization ID
    record[current_offset + 12:current_offset + 24] = b'CORR12345678'  # Correlation ID
    record[current_offset + 24:current_offset + 32] = b'CONN0001'  # Connection name
    record[current_offset + 32:current_offset + 40] = b'PLAN0001'  # Plan name
    struct.pack_into('>I', record, current_offset + 48, 1)  # Connection type
    current_offset += 80
    
    # QWHD (Distributed) header
    struct.pack_into('>H', record, current_offset, 60)  # Length
    struct.pack_into('B', record, current_offset + 2, 16)  # Type
    struct.pack_into('B', record, current_offset + 3, 0xDB)
    record[current_offset + 4:current_offset + 20] = b'REQUESTER_LOC   '  # Requester location
    record[current_offset + 28:current_offset + 44] = b'SERVER_NAME     '  # Server name
    record[current_offset + 44:current_offset + 52] = b'PROD_ID1'  # Product ID
    current_offset += 60
    
    # QWHA (Data Sharing) header
    struct.pack_into('>H', record, current_offset, 40)  # Length
    struct.pack_into('B', record, current_offset + 2, 32)  # Type
    struct.pack_into('B', record, current_offset + 3, 0xDB)
    record[current_offset + 4:current_offset + 12] = b'MEMBER01'  # Member name
    record[current_offset + 12:current_offset + 20] = b'GROUP001'  # Group name
    
    return bytes(record[:record_length])


def create_smf101_record_with_rollup_flag(db2_version: str = "V11") -> bytes:
    """Create SMF 101 record with rollup flag set in QWAC section.
    
    Args:
        db2_version: DB2 version ("V11" or "V12")
        
    Returns:
        Synthetic SMF Type 101 record with rollup flag
    """
    record = bytearray(create_smf101_record_with_data_sections(db2_version))
    
    # Find QWAC offset (at triplet R1, offset 36)
    qwac_offset = struct.unpack('>I', record[36:40])[0]
    
    # Set QWACPARR flag (bit 0x0040) in flags at offset 224
    flags = struct.unpack('>H', record[qwac_offset + 224:qwac_offset + 226])[0]
    flags |= 0x0040  # Set rollup flag
    struct.pack_into('>H', record, qwac_offset + 224, flags)
    
    return bytes(record)


class TestSMF101ParserV11:
    """Unit tests for SMF Type 101 V11 parser."""
    
    def test_parse_basic_structure(self):
        """
        Test parsing basic Type 101 V11 record structure.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify basic structure
        assert result.record_type == 101
        assert result.subtype == 3  # IFCID 3 (accounting)
        assert result.system_id.strip() == "SYS1"
        assert 'smf_header' in result.header
        assert 'qwhs_header' in result.header
        assert 'self_defining_section' in result.header
    
    def test_parse_smf_header_fields(self):
        """
        Test that all SMF header fields are extracted.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        smf_header = result.header['smf_header']
        
        # Verify all expected fields are present
        assert 'record_length' in smf_header
        assert 'record_type' in smf_header
        assert 'system_id' in smf_header
        assert 'subsystem_id' in smf_header
        assert 'timestamp' in smf_header
        assert 'date' in smf_header
        
        # Verify values
        assert smf_header['record_type'] == 101
        assert smf_header['system_id'].strip() == "SYS1"
        assert smf_header['subsystem_id'].strip() == "DB2P"
    
    def test_parse_qwhs_header_fields(self):
        """
        Test that all QWHS header fields are extracted.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        qwhs = result.header['qwhs_header']
        
        # Verify all expected fields are present
        assert 'header_length' in qwhs
        assert 'header_type' in qwhs
        assert 'resource_manager_id' in qwhs
        assert 'ifcid' in qwhs
        assert 'release_number' in qwhs
        assert 'subsystem_name' in qwhs
        
        # Verify values
        assert qwhs['header_type'] == 1  # QWHS
        assert qwhs['resource_manager_id'] == 0xDB  # DB2
        assert qwhs['ifcid'] == 3  # Accounting
        assert qwhs['release_number'] == 0x0B00  # V11
        assert qwhs['subsystem_name'].strip() == "DB2P"
    
    def test_parse_self_defining_section(self):
        """
        Test parsing self-defining section (QWA0).
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        sds = result.header['self_defining_section']
        
        # Verify structure
        assert 'triplets' in sds
        
        # Verify QWA0 triplets are present
        triplets = sds['triplets']
        assert 'product_section' in triplets
        assert 'qwac' in triplets  # IFC Accounting
        assert 'qxst' in triplets  # SQL Accounting
        assert 'qbac' in triplets  # Buffer Manager
        assert 'qtxa' in triplets  # Locking
        assert 'qlac' in triplets  # DDF
        assert 'qmda' in triplets  # MVS and DDF
        assert 'qifa' in triplets  # Changed Data Capture
        assert 'qwar' in triplets  # Rollup Accounting
        assert 'qbga' in triplets  # Buffer Manager Data Sharing
        assert 'qtga' in triplets  # Data Sharing Global Locking
        assert 'qwda' in triplets  # Data Sharing Accounting (V11 only)
        assert 'qwax' in triplets  # Accounting Class 3 Overflow
        assert 'q8ac' in triplets  # Accelerator Services
    
    def test_parse_optional_headers(self):
        """
        Test parsing optional headers in product section.
        
        Requirements: 4.4
        """
        record_data = create_smf101_record(db2_version="V11", include_optional_headers=True)
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify optional headers are present
        assert 'optional_headers' in result.header
        optional_headers = result.header['optional_headers']
        
        # Check for expected optional headers
        # Note: Some headers may have field-level parsing, others may be minimal
        assert len(optional_headers) > 0
        
        # Verify each header has at least basic structure
        for header_name, header_data in optional_headers.items():
            assert isinstance(header_data, dict)
            # Headers can have either detailed fields or basic offset/length/type
            assert len(header_data) > 0
    
    def test_parse_without_optional_headers(self):
        """
        Test parsing record without optional headers.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record(db2_version="V11", include_optional_headers=False)
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify record parses successfully
        assert result.record_type == 101
        
        # Optional headers should be empty or not present
        if 'optional_headers' in result.header:
            assert len(result.header['optional_headers']) == 0
    
    def test_parse_data_sections(self):
        """
        Test that data sections are identified when present.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify data sections are captured
        if 'data_sections' in result.header:
            data_sections = result.header['data_sections']
            
            # Check that sections with non-zero triplets are identified
            for section_name, section_data in data_sections.items():
                assert isinstance(section_data, dict)
                # Sections can have either parsed fields or error messages
                if 'error' not in section_data:
                    # Successfully parsed sections should have meaningful data
                    assert len(section_data) > 0
    
    def test_db2_version_attribute(self):
        """
        Test that parser has correct DB2 version attribute.
        
        Requirements: 4.1
        """
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        assert parser.db2_version == "V11"
    
    def test_error_handling_invalid_record_type(self):
        """
        Test error handling for invalid record type.
        
        Requirements: 4.1, 9.1
        """
        record_data = create_smf101_record(db2_version="V11")
        record_data = bytearray(record_data)
        record_data[5] = 100  # Change to Type 100
        record_data = bytes(record_data)
        
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "record type" in str(exc_info.value).lower()
    
    def test_error_handling_missing_product_section(self):
        """
        Test error handling when product section is missing.
        
        Requirements: 4.1, 9.1
        """
        record_data = create_smf101_record(db2_version="V11")
        record_data = bytearray(record_data)
        
        # Set product section count to 0
        struct.pack_into('>H', record_data, 34, 0)
        record_data = bytes(record_data)
        
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "product section" in str(exc_info.value).lower()
    
    def test_parse_qwac_section_fields(self):
        """
        Test field-level parsing of QWAC section.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record_with_data_sections(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify QWAC section is parsed
        assert 'data_sections' in result.header
        assert 'qwac' in result.header['data_sections']
        
        qwac = result.header['data_sections']['qwac']
        
        # Verify key timing fields
        assert 'begin_store_clock' in qwac
        assert 'end_store_clock' in qwac
        assert 'begin_cpu_time' in qwac
        assert 'end_cpu_time' in qwac
        
        # Verify commit/abort counts
        assert 'commit_count' in qwac
        assert 'abort_count' in qwac
        
        # Verify accumulated times
        assert 'accumulated_elapsed_in_db2' in qwac
        assert 'accumulated_cpu_in_db2' in qwac
        assert 'accumulated_wait_io' in qwac
        assert 'accumulated_wait_lock' in qwac
        
        # Verify flags and rollup detection
        assert 'flags' in qwac
        assert 'is_rollup' in qwac
        assert 'class2_active' in qwac
        assert 'class3_active' in qwac
        assert isinstance(qwac['is_rollup'], bool)
    
    def test_parse_qxst_section_fields(self):
        """
        Test field-level parsing of QXST section.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record_with_data_sections(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify QXST section is parsed
        assert 'data_sections' in result.header
        assert 'qxst' in result.header['data_sections']
        
        qxst = result.header['data_sections']['qxst']
        
        # Verify SQL statement counts
        assert 'select_count' in qxst
        assert 'insert_count' in qxst
        assert 'update_count' in qxst
        assert 'delete_count' in qxst
        assert 'describe_count' in qxst
        assert 'prepare_count' in qxst
        assert 'open_count' in qxst
        assert 'close_count' in qxst
        assert 'fetch_count' in qxst
    
    def test_parse_qbac_section_fields(self):
        """
        Test field-level parsing of QBAC section.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record_with_data_sections(
            db2_version="V11", include_qbac=True
        )
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify QBAC section is parsed
        assert 'data_sections' in result.header
        assert 'qbac' in result.header['data_sections']
        
        qbac = result.header['data_sections']['qbac']
        
        # Verify buffer manager statistics
        assert 'buffer_pool_id' in qbac
        assert 'getpage_requests' in qbac
        assert 'sync_read_io' in qbac
        assert 'seq_prefetch_requests' in qbac
        assert 'list_prefetch_requests' in qbac
        assert 'dynamic_prefetch_requests' in qbac
    
    def test_parse_qlac_varying_length_group(self):
        """
        Test parsing of QLAC section as varying length repeating group.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record_with_data_sections(
            db2_version="V11", include_qlac=True
        )
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify QLAC section is parsed
        assert 'data_sections' in result.header
        assert 'qlac' in result.header['data_sections']
        
        qlac = result.header['data_sections']['qlac']
        
        # Verify it's identified as varying length group
        assert 'type' in qlac
        assert qlac['type'] == 'varying_length_group'
        assert 'member_count' in qlac
        assert 'members' in qlac
        
        # Verify members have expected fields
        if qlac['member_count'] > 0:
            member = qlac['members'][0]
            assert 'length' in member
            assert 'location_name' in member
            assert 'conversations_started' in member
            assert 'messages_sent' in member
            assert 'messages_received' in member
    
    def test_parse_optional_header_qwhc_fields(self):
        """
        Test field-level parsing of QWHC (Correlation) header.
        
        Requirements: 4.4
        """
        record_data = create_smf101_record_with_optional_headers(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify correlation header is parsed
        assert 'optional_headers' in result.header
        assert 'correlation' in result.header['optional_headers']
        
        qwhc = result.header['optional_headers']['correlation']
        
        # Verify key fields
        assert 'header_length' in qwhc
        assert 'header_type' in qwhc
        assert 'authorization_id' in qwhc
        assert 'correlation_id' in qwhc
        assert 'connection_name' in qwhc
        assert 'plan_name' in qwhc
        assert 'connection_type' in qwhc
        assert 'accounting_token' in qwhc
        
        assert qwhc['header_type'] == 2  # Correlation header
    
    def test_parse_optional_header_qwhd_fields(self):
        """
        Test field-level parsing of QWHD (Distributed) header.
        
        Requirements: 4.4
        """
        record_data = create_smf101_record_with_optional_headers(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify distributed header is parsed
        assert 'optional_headers' in result.header
        assert 'distributed' in result.header['optional_headers']
        
        qwhd = result.header['optional_headers']['distributed']
        
        # Verify key fields
        assert 'header_length' in qwhd
        assert 'header_type' in qwhd
        assert 'requester_location' in qwhd
        assert 'server_name' in qwhd
        assert 'product_id' in qwhd
        
        assert qwhd['header_type'] == 16  # Distributed header
    
    def test_parse_optional_header_qwha_fields(self):
        """
        Test field-level parsing of QWHA (Data Sharing) header.
        
        Requirements: 4.4
        """
        record_data = create_smf101_record_with_optional_headers(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify data sharing header is parsed
        assert 'optional_headers' in result.header
        assert 'data_sharing' in result.header['optional_headers']
        
        qwha = result.header['optional_headers']['data_sharing']
        
        # Verify key fields
        assert 'header_length' in qwha
        assert 'header_type' in qwha
        assert 'member_name' in qwha
        assert 'group_name' in qwha
        
        assert qwha['header_type'] == 32  # Data sharing header
    
    def test_rollup_record_detection(self):
        """
        Test detection of rollup records via QWACPARR flag.
        
        Requirements: 4.1, 4.5
        """
        record_data = create_smf101_record_with_rollup_flag(db2_version="V11")
        parser = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify rollup flag is detected
        assert 'data_sections' in result.header
        assert 'qwac' in result.header['data_sections']
        
        qwac = result.header['data_sections']['qwac']
        assert 'is_rollup' in qwac
        assert qwac['is_rollup'] is True


class TestSMF101ParserV12:
    """Unit tests for SMF Type 101 V12 parser."""
    
    def test_parse_basic_structure(self):
        """
        Test parsing basic Type 101 V12 record structure.
        
        Requirements: 4.2, 4.5
        """
        record_data = create_smf101_record(db2_version="V12")
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify basic structure
        assert result.record_type == 101
        assert result.subtype == 3  # IFCID 3 (accounting)
        assert result.system_id.strip() == "SYS1"
        assert 'smf_header' in result.header
        assert 'qwhs_header' in result.header
        assert 'self_defining_section' in result.header
    
    def test_parse_qwhs_header_v12_release_number(self):
        """
        Test that QWHS header has V12 release number.
        
        Requirements: 4.2, 4.5
        """
        record_data = create_smf101_record(db2_version="V12")
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        qwhs = result.header['qwhs_header']
        
        # Verify V12 release number
        assert qwhs['release_number'] == 0x0C00  # V12
    
    def test_parse_self_defining_section_v12(self):
        """
        Test parsing self-defining section for V12 (QWDA not supported).
        
        Requirements: 4.2, 4.5
        """
        record_data = create_smf101_record(db2_version="V12")
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        sds = result.header['self_defining_section']
        triplets = sds['triplets']
        
        # Verify QWA0 triplets are present
        assert 'qwac' in triplets
        assert 'qxst' in triplets
        assert 'qwax' in triplets
        assert 'q8ac' in triplets
        
        # QWDA should not be in V12 (it's no longer supported)
        # The parser skips RB triplet for V12
        assert 'qwda' not in triplets
    
    def test_parse_optional_headers_v12(self):
        """
        Test parsing optional headers in V12 record.
        
        Requirements: 4.2, 4.4, 4.5
        """
        record_data = create_smf101_record(db2_version="V12", include_optional_headers=True)
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify optional headers are present
        assert 'optional_headers' in result.header
        optional_headers = result.header['optional_headers']
        
        # Check for expected optional headers
        assert 'correlation' in optional_headers
        assert 'trace' in optional_headers
        assert 'cpu' in optional_headers
        assert 'distributed' in optional_headers
    
    def test_db2_version_attribute(self):
        """
        Test that parser has correct DB2 version attribute.
        
        Requirements: 4.2
        """
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        assert parser.db2_version == "V12"
    
    def test_v11_vs_v12_differences(self):
        """
        Test that V11 and V12 parsers handle version-specific differences.
        
        Requirements: 4.2, 4.5
        """
        # Parse same record with both parsers
        record_v11 = create_smf101_record(db2_version="V11")
        record_v12 = create_smf101_record(db2_version="V12")
        
        parser_v11 = SMF101ParserV11(BaseRecordParser(encoding='EBCDIC'))
        parser_v12 = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        
        result_v11 = parser_v11.parse(record_v11)
        result_v12 = parser_v12.parse(record_v12)
        
        # Verify version attributes
        assert parser_v11.db2_version == "V11"
        assert parser_v12.db2_version == "V12"
        
        # Verify release numbers
        assert result_v11.header['qwhs_header']['release_number'] == 0x0B00
        assert result_v12.header['qwhs_header']['release_number'] == 0x0C00
        
        # Verify V11 has QWDA triplet, V12 does not
        triplets_v11 = result_v11.header['self_defining_section']['triplets']
        triplets_v12 = result_v12.header['self_defining_section']['triplets']
        
        assert 'qwda' in triplets_v11
        assert 'qwda' not in triplets_v12
    
    def test_error_handling_invalid_record_type(self):
        """
        Test error handling for invalid record type.
        
        Requirements: 4.2, 9.1
        """
        record_data = create_smf101_record(db2_version="V12")
        record_data = bytearray(record_data)
        record_data[5] = 102  # Change to Type 102
        record_data = bytes(record_data)
        
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "record type" in str(exc_info.value).lower()
    
    def test_parse_qwac_section_fields_v12(self):
        """
        Test field-level parsing of QWAC section in V12.
        
        Requirements: 4.2, 4.5
        """
        record_data = create_smf101_record_with_data_sections(db2_version="V12")
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify QWAC section is parsed
        assert 'data_sections' in result.header
        assert 'qwac' in result.header['data_sections']
        
        qwac = result.header['data_sections']['qwac']
        
        # Verify key fields are present
        assert 'begin_store_clock' in qwac
        assert 'commit_count' in qwac
        assert 'is_rollup' in qwac
    
    def test_parse_qxst_section_fields_v12(self):
        """
        Test field-level parsing of QXST section in V12.
        
        Requirements: 4.2, 4.5
        """
        record_data = create_smf101_record_with_data_sections(db2_version="V12")
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify QXST section is parsed
        assert 'data_sections' in result.header
        assert 'qxst' in result.header['data_sections']
        
        qxst = result.header['data_sections']['qxst']
        
        # Verify SQL statement counts
        assert 'select_count' in qxst
        assert 'insert_count' in qxst
        assert 'update_count' in qxst
    
    def test_parse_optional_header_fields_v12(self):
        """
        Test field-level parsing of optional headers in V12.
        
        Requirements: 4.2, 4.4, 4.5
        """
        record_data = create_smf101_record_with_optional_headers(db2_version="V12")
        parser = SMF101ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify optional headers are parsed with fields
        assert 'optional_headers' in result.header
        
        if 'correlation' in result.header['optional_headers']:
            qwhc = result.header['optional_headers']['correlation']
            assert 'authorization_id' in qwhc
            assert 'plan_name' in qwhc
        
        if 'distributed' in result.header['optional_headers']:
            qwhd = result.header['optional_headers']['distributed']
            assert 'requester_location' in qwhd
            assert 'server_name' in qwhd
