"""Property-based tests for smf_queries modernization."""

import pytest
from hypothesis import given, strategies as st, settings
from typing import Dict, List
from tools.smf_analyzer.smf_queries.base_query import BaseQuery, QueryResult
from tools.smf_analyzer.smf_queries.config_parameter import ConfigParameter


# Helper to create a mock query class dynamically
def create_mock_query_class(
    name: str,
    description: str,
    purpose: str,
    category: str,
    record_types: List[int],
    migration_impact: str,
    requires_inventory: bool,
    config_params: Dict[str, ConfigParameter]
):
    """Create a mock query class with given properties."""
    
    class DynamicMockQuery(BaseQuery):
        @property
        def name(self) -> str:
            return name
        
        @property
        def description(self) -> str:
            return description
        
        @property
        def purpose(self) -> str:
            return purpose
        
        @property
        def category(self) -> str:
            return category
        
        @property
        def record_types(self) -> List[int]:
            return record_types
        
        @property
        def migration_impact(self) -> str:
            return migration_impact
        
        @property
        def requires_inventory(self) -> bool:
            return requires_inventory
        
        @property
        def configuration_parameters(self) -> Dict[str, ConfigParameter]:
            return config_params
        
        def get_sql(self, **params) -> str:
            return "SELECT 1"
    
    return DynamicMockQuery


class TestProperty1QueryMetadataCompleteness:
    """
    Property 1: Query Metadata Completeness
    
    For any query registered with the QueryEngine, retrieving its metadata 
    should return a dictionary containing all required fields: name, description, 
    purpose, category, record_types, migration_impact, requires_inventory, 
    and configuration_parameters.
    
    Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 1.6
    """
    
    @given(
        name=st.text(min_size=1, max_size=50, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_')),
        description=st.text(min_size=1, max_size=200),
        purpose=st.text(min_size=1, max_size=500),
        category=st.sampled_from(['Code Artifact Analysis', 'Infrastructure Sizing', 'Cost Analysis', 'Migration Planning']),
        record_types=st.lists(st.integers(min_value=1, max_value=255), min_size=0, max_size=5, unique=True),
        migration_impact=st.text(min_size=0, max_size=500),
        requires_inventory=st.booleans()
    )
    @settings(max_examples=100)
    def test_property_1_metadata_completeness(
        self,
        name: str,
        description: str,
        purpose: str,
        category: str,
        record_types: List[int],
        migration_impact: str,
        requires_inventory: bool
    ):
        """
        Property test: Query metadata should contain all required fields.
        
        Feature: smf-queries-modernization
        Property 1: Query Metadata Completeness
        """
        # Create a mock query with the generated properties
        config_params = {
            'test_param': ConfigParameter(
                name='test_param',
                description='Test parameter',
                default_value=100,
                parameter_type='int'
            )
        }
        
        QueryClass = create_mock_query_class(
            name=name,
            description=description,
            purpose=purpose,
            category=category,
            record_types=record_types,
            migration_impact=migration_impact,
            requires_inventory=requires_inventory,
            config_params=config_params
        )
        
        query = QueryClass()
        
        # Verify all required metadata fields are present and accessible
        assert hasattr(query, 'name'), "Query must have 'name' property"
        assert hasattr(query, 'description'), "Query must have 'description' property"
        assert hasattr(query, 'purpose'), "Query must have 'purpose' property"
        assert hasattr(query, 'category'), "Query must have 'category' property"
        assert hasattr(query, 'record_types'), "Query must have 'record_types' property"
        assert hasattr(query, 'migration_impact'), "Query must have 'migration_impact' property"
        assert hasattr(query, 'requires_inventory'), "Query must have 'requires_inventory' property"
        assert hasattr(query, 'configuration_parameters'), "Query must have 'configuration_parameters' property"
        
        # Verify the values match what was set
        assert query.name == name
        assert query.description == description
        assert query.purpose == purpose
        assert query.category == category
        assert query.record_types == record_types
        assert query.migration_impact == migration_impact
        assert query.requires_inventory == requires_inventory
        assert isinstance(query.configuration_parameters, dict)
        
        # Verify types are correct
        assert isinstance(query.name, str)
        assert isinstance(query.description, str)
        assert isinstance(query.purpose, str)
        assert isinstance(query.category, str)
        assert isinstance(query.record_types, list)
        assert isinstance(query.migration_impact, str)
        assert isinstance(query.requires_inventory, bool)
        assert isinstance(query.configuration_parameters, dict)
    
    def test_property_1_with_query_engine_metadata_retrieval(self):
        """
        Test that QueryEngine.get_query_metadata returns all required fields.
        
        This is a specific example test that complements the property test.
        """
        from tools.smf_analyzer.smf_queries import QueryEngine
        from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
        
        # Create a test database
        db = SQLiteAdapter(':memory:')
        engine = QueryEngine(db)
        
        # Create and register a mock query
        config_params = {
            'analysis_days': ConfigParameter(
                name='analysis_days',
                description='Number of days to analyze',
                default_value=365,
                parameter_type='int',
                unit='days',
                min_value=1,
                max_value=3650
            )
        }
        
        QueryClass = create_mock_query_class(
            name='test_query',
            description='Test query description',
            purpose='Test query purpose',
            category='Code Artifact Analysis',
            record_types=[30, 110],
            migration_impact='Test migration impact',
            requires_inventory=True,
            config_params=config_params
        )
        
        query = QueryClass()
        engine.register_query(query)
        
        # Retrieve metadata through QueryEngine
        metadata = engine.get_query_metadata('test_query')
        
        # Verify all required fields are present in metadata dict
        required_fields = [
            'name', 'description', 'purpose', 'category', 
            'record_types', 'migration_impact', 'requires_inventory',
            'configuration_parameters'
        ]
        
        for field in required_fields:
            assert field in metadata, f"Metadata must contain '{field}' field"
        
        # Verify values
        assert metadata['name'] == 'test_query'
        assert metadata['description'] == 'Test query description'
        assert metadata['purpose'] == 'Test query purpose'
        assert metadata['category'] == 'Code Artifact Analysis'
        assert metadata['record_types'] == [30, 110]
        assert metadata['migration_impact'] == 'Test migration impact'
        assert metadata['requires_inventory'] is True
        assert 'analysis_days' in metadata['configuration_parameters']


class TestProperty9QueryResultSerializationConsistency:
    """
    Property 9: Query Result Serialization Consistency
    
    For any QueryResult, serializing to dictionary format and then extracting 
    the rows should produce the same data as the original rows (preserving 
    column order and values).
    
    Validates: Requirements 12.1, 12.5
    """
    
    @given(
        query_name=st.text(min_size=1, max_size=50),
        description=st.text(min_size=1, max_size=200),
        columns=st.lists(
            st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_')),
            min_size=1,
            max_size=10,
            unique=True
        ),
        num_rows=st.integers(min_value=0, max_value=20)
    )
    @settings(max_examples=100)
    def test_property_9_serialization_consistency(
        self,
        query_name: str,
        description: str,
        columns: List[str],
        num_rows: int
    ):
        """
        Property test: QueryResult serialization should preserve data.
        
        Feature: smf-queries-modernization
        Property 9: Query Result Serialization Consistency
        """
        # Generate rows with values matching the columns
        rows = []
        for i in range(num_rows):
            row = tuple(f"value_{i}_{j}" for j in range(len(columns)))
            rows.append(row)
        
        # Create QueryResult
        result = QueryResult(
            query_name=query_name,
            description=description,
            columns=columns,
            rows=rows
        )
        
        # Serialize to dict
        dict_result = result.to_dict()
        
        # Verify structure
        assert 'query_name' in dict_result
        assert 'description' in dict_result
        assert 'columns' in dict_result
        assert 'rows' in dict_result
        assert 'row_count' in dict_result
        
        # Verify metadata
        assert dict_result['query_name'] == query_name
        assert dict_result['description'] == description
        assert dict_result['columns'] == columns
        assert dict_result['row_count'] == num_rows
        
        # Verify rows are preserved
        assert len(dict_result['rows']) == num_rows
        
        # Verify each row preserves column order and values
        for i, row_dict in enumerate(dict_result['rows']):
            original_row = rows[i]
            
            # Check all columns are present
            assert len(row_dict) == len(columns)
            
            # Check column order and values
            for j, col_name in enumerate(columns):
                assert col_name in row_dict
                assert row_dict[col_name] == original_row[j]
    
    @given(
        columns=st.lists(
            st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_')),
            min_size=1,
            max_size=5,
            unique=True
        ),
        num_rows=st.integers(min_value=1, max_value=10)
    )
    @settings(max_examples=50)
    def test_property_9_to_list_of_dicts_consistency(
        self,
        columns: List[str],
        num_rows: int
    ):
        """
        Property test: to_list_of_dicts should preserve row data.
        
        Feature: smf-queries-modernization
        Property 9: Query Result Serialization Consistency
        """
        # Generate rows
        rows = []
        for i in range(num_rows):
            row = tuple(f"val_{i}_{j}" for j in range(len(columns)))
            rows.append(row)
        
        # Create QueryResult
        result = QueryResult(
            query_name="test",
            description="test",
            columns=columns,
            rows=rows
        )
        
        # Convert to list of dicts
        list_result = result.to_list_of_dicts()
        
        # Verify length
        assert len(list_result) == num_rows
        
        # Verify each row
        for i, row_dict in enumerate(list_result):
            original_row = rows[i]
            
            # Check all columns present
            assert set(row_dict.keys()) == set(columns)
            
            # Check values match
            for j, col_name in enumerate(columns):
                assert row_dict[col_name] == original_row[j]
    
    def test_property_9_empty_result_serialization(self):
        """Test serialization of empty QueryResult."""
        result = QueryResult(
            query_name="empty_query",
            description="Empty result",
            columns=['col1', 'col2'],
            rows=[]
        )
        
        # Test to_dict
        dict_result = result.to_dict()
        assert dict_result['row_count'] == 0
        assert dict_result['rows'] == []
        
        # Test to_list_of_dicts
        list_result = result.to_list_of_dicts()
        assert list_result == []
        
        # Test to_csv
        csv_result = result.to_csv()
        lines = [line.strip() for line in csv_result.strip().split('\n')]
        assert len(lines) == 1  # Only header
        assert lines[0] == 'col1,col2'
        
        # Test to_json
        json_result = result.to_json()
        assert '"row_count": 0' in json_result
        
        # Test to_markdown
        md_result = result.to_markdown()
        assert 'No results' in md_result
    
    @given(
        value_type=st.sampled_from(['int', 'float', 'str', 'bool', 'none'])
    )
    @settings(max_examples=20)
    def test_property_9_value_type_preservation(self, value_type: str):
        """
        Property test: Serialization should handle different value types.
        
        Feature: smf-queries-modernization
        Property 9: Query Result Serialization Consistency
        """
        # Generate value based on type
        if value_type == 'int':
            value = 42
        elif value_type == 'float':
            value = 3.14
        elif value_type == 'str':
            value = 'test_string'
        elif value_type == 'bool':
            value = True
        else:  # none
            value = None
        
        result = QueryResult(
            query_name="test",
            description="test",
            columns=['col1'],
            rows=[(value,)]
        )
        
        # Test to_dict preserves value
        dict_result = result.to_dict()
        assert dict_result['rows'][0]['col1'] == value
        
        # Test to_list_of_dicts preserves value
        list_result = result.to_list_of_dicts()
        assert list_result[0]['col1'] == value
