"""Property-based tests for SMF Analyzer tool directory structure.

Feature: project-reorganization
"""

import pytest
import os
from pathlib import Path
from hypothesis import given, strategies as st, settings


class TestSMFAnalyzerStructureProperties:
    """Property-based tests for SMF Analyzer tool structure."""
    
    def test_property_1_tool_directory_structure_correctness(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 1.2**
        
        For any reorganized toolkit, all expected SMF analyzer tool directories should exist 
        with correct contents in their new locations under tools/smf_analyzer/.
        """
        # Define the expected structure for SMF analyzer tool
        expected_structure = {
            'tools/smf_analyzer': {
                'type': 'directory',
                'required_files': ['__init__.py', 'api.py', 'requirements.txt', 'README.md'],
                'required_subdirs': ['smf_doc_parser', 'smf_record_parser', 'smf_loader', 'smf_queries']
            },
            'tools/smf_analyzer/smf_doc_parser': {
                'type': 'directory',
                'required_files': ['README.md', 'requirements.txt', 'pyproject.toml'],
                'required_subdirs': ['smf_doc_parser', 'tests']
            },
            'tools/smf_analyzer/smf_record_parser': {
                'type': 'directory',
                'required_files': ['__init__.py', '__main__.py', 'cli.py', 'smf_file_parser.py'],
                'required_subdirs': ['parsers', 'models', 'utils']
            },
            'tools/smf_analyzer/smf_loader': {
                'type': 'directory',
                'required_files': ['__init__.py', '__main__.py', 'cli.py'],
                'required_subdirs': ['core', 'schemas', 'databases', 'examples']
            },
            'tools/smf_analyzer/smf_queries': {
                'type': 'directory',
                'required_files': ['__init__.py', '__main__.py', 'base_query.py', 'query_engine.py', 'cli.py'],
                'required_subdirs': ['queries', 'examples']
            }
        }
        
        # Verify each expected directory and its contents
        for path_str, expected in expected_structure.items():
            path = Path(path_str)
            
            # Directory should exist
            assert path.exists(), f"Directory {path_str} should exist"
            assert path.is_dir(), f"{path_str} should be a directory"
            
            # Check required files
            for required_file in expected['required_files']:
                file_path = path / required_file
                assert file_path.exists(), f"Required file {path_str}/{required_file} should exist"
                assert file_path.is_file(), f"{path_str}/{required_file} should be a file"
            
            # Check required subdirectories
            for required_subdir in expected['required_subdirs']:
                subdir_path = path / required_subdir
                assert subdir_path.exists(), f"Required subdirectory {path_str}/{required_subdir} should exist"
                assert subdir_path.is_dir(), f"{path_str}/{required_subdir} should be a directory"
        
        # Verify that old locations no longer exist (they should have been moved)
        old_locations = [
            'smf_doc_parser',
            'smf_record_parser', 
            'smf_loader',
            'smf_queries'
        ]
        
        for old_location in old_locations:
            old_path = Path(old_location)
            assert not old_path.exists(), f"Old location {old_location} should no longer exist after move"
    
    def test_property_1_smf_analyzer_api_structure(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 1.2**
        
        For any reorganized SMF analyzer tool, the main API files should contain the expected
        exports and structure to provide a unified interface.
        """
        # Check main __init__.py file
        init_file = Path('tools/smf_analyzer/__init__.py')
        assert init_file.exists(), "SMF analyzer __init__.py should exist"
        
        with open(init_file, 'r') as f:
            init_content = f.read()
        
        # Verify key imports are present
        expected_imports = [
            'from .smf_record_parser import SMFFileParser',
            'from .smf_loader import SMFLoader',
            'from .smf_queries import QueryEngine',
            'from .api import SMFAnalyzer'
        ]
        
        for expected_import in expected_imports:
            assert expected_import in init_content, f"Expected import '{expected_import}' should be in __init__.py"
        
        # Verify __all__ exports are present
        assert '__all__' in init_content, "__all__ should be defined in __init__.py"
        assert 'SMFAnalyzer' in init_content, "SMFAnalyzer should be exported"
        assert 'SMFFileParser' in init_content, "SMFFileParser should be exported"
        assert 'SMFLoader' in init_content, "SMFLoader should be exported"
        assert 'QueryEngine' in init_content, "QueryEngine should be exported"
        
        # Check API file
        api_file = Path('tools/smf_analyzer/api.py')
        assert api_file.exists(), "SMF analyzer api.py should exist"
        
        with open(api_file, 'r') as f:
            api_content = f.read()
        
        # Verify main API class is defined
        assert 'class SMFAnalyzer:' in api_content, "SMFAnalyzer class should be defined"
        
        # Verify key methods are present
        expected_methods = [
            'def parse_smf_file(',
            'def load_to_database(',
            'def run_analysis(',
            'def run_complete_analysis('
        ]
        
        for expected_method in expected_methods:
            assert expected_method in api_content, f"Expected method '{expected_method}' should be in api.py"
    
    def test_property_1_smf_analyzer_requirements_structure(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 1.2**
        
        For any reorganized SMF analyzer tool, the requirements.txt file should contain
        the appropriate dependencies for SMF analysis functionality.
        """
        requirements_file = Path('tools/smf_analyzer/requirements.txt')
        assert requirements_file.exists(), "SMF analyzer requirements.txt should exist"
        
        with open(requirements_file, 'r') as f:
            requirements_content = f.read()
        
        # Verify key dependencies are present
        expected_dependencies = [
            'requests>=2.31.0',
            'beautifulsoup4>=4.12.0',
            'lxml>=4.9.0',
            'markdownify>=0.11.0',
            'html2text>=2020.1.16',
            'PyYAML>=6.0',
            'pytest>=7.4.0',
            'hypothesis>=6.0.0'
        ]
        
        for expected_dep in expected_dependencies:
            assert expected_dep in requirements_content, f"Expected dependency '{expected_dep}' should be in requirements.txt"
    
    def test_property_1_smf_analyzer_readme_structure(self):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 1.2**
        
        For any reorganized SMF analyzer tool, the README.md file should contain
        comprehensive documentation for the tool.
        """
        readme_file = Path('tools/smf_analyzer/README.md')
        assert readme_file.exists(), "SMF analyzer README.md should exist"
        
        with open(readme_file, 'r') as f:
            readme_content = f.read()
        
        # Verify key sections are present
        expected_sections = [
            '# SMF Analyzer Tool',
            '## Overview',
            '## Quick Start',
            '## Command Line Usage',
            '## Components',
            '## Installation',
            '## API Reference'
        ]
        
        for expected_section in expected_sections:
            assert expected_section in readme_content, f"Expected section '{expected_section}' should be in README.md"
        
        # Verify component descriptions are present
        expected_components = [
            'SMF Record Parser',
            'SMF Loader',
            'SMF Queries',
            'SMF Doc Parser'
        ]
        
        for expected_component in expected_components:
            assert expected_component in readme_content, f"Component '{expected_component}' should be documented in README.md"
    
    @settings(max_examples=10)
    @given(
        component_name=st.sampled_from(['smf_doc_parser', 'smf_record_parser', 'smf_loader', 'smf_queries'])
    )
    def test_property_1_component_preservation(self, component_name):
        """
        **Feature: project-reorganization, Property 1: Tool directory structure correctness**
        **Validates: Requirements 1.2**
        
        For any SMF component that was moved to tools/smf_analyzer/, all original files
        and subdirectories should be preserved in the new location.
        """
        component_path = Path(f'tools/smf_analyzer/{component_name}')
        assert component_path.exists(), f"Component {component_name} should exist in new location"
        assert component_path.is_dir(), f"Component {component_name} should be a directory"
        
        # Verify the component has some content (not empty)
        contents = list(component_path.iterdir())
        assert len(contents) > 0, f"Component {component_name} should not be empty"
        
        # Check for expected files based on component type
        if component_name == 'smf_doc_parser':
            # This has a nested structure
            nested_dir = component_path / 'smf_doc_parser'
            assert nested_dir.exists(), f"{component_name} should have nested smf_doc_parser directory"
            
            expected_files = ['README.md', 'requirements.txt', 'pyproject.toml']
            for expected_file in expected_files:
                file_path = component_path / expected_file
                assert file_path.exists(), f"{component_name} should have {expected_file}"
        
        else:
            # Other components should have __init__.py
            init_file = component_path / '__init__.py'
            assert init_file.exists(), f"{component_name} should have __init__.py"
            
            # Should have some Python files
            python_files = list(component_path.glob('*.py'))
            assert len(python_files) > 0, f"{component_name} should have Python files"