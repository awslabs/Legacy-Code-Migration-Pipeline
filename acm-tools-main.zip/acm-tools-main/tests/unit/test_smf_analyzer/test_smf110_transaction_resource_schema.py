#!/usr/bin/env python3
"""Test script for SMF Type 110 transaction resource schema transformation."""

import pytest
from tools.smf_analyzer.smf_loader.schemas.smf110_schema import SMF110Schema


class TestSMF110TransactionResourceSchema:
    """Test transaction resource schema transformation for SMF Type 110."""
    
    @pytest.fixture
    def schema(self):
        """Create schema instance."""
        return SMF110Schema()
    
    def test_transform_file_operations_resource(self, schema):
        """Test transforming file operations resource record."""
        # Create a test JSON record with transaction resource data
        json_record = {
            'record_type': 110,
            'subtype': 1,
            'system_id': 'SYS1',
            'date': '2024-01-15',
            'timestamp': '10:30:45',
            'record_length': 1000,
            'header': {
                'subsystem_id': 'CICS'
            },
            'subsystem': {
                'data_class': 5,
                'product_name_generic': 'CICSTEST',
                'product_name_specific': 'CICSTEST',
                'record_version': 1,
                'data_record_count': 1
            },
            'identification': {
                'type': 'transaction_resource',
                'data_class': 5,
                'records': [
                    {
                        'record_number': 1,
                        'offset': 100,
                        'length': 40,
                        'transaction_id': 'TST1',
                        'resource_type': 1,
                        'resource_type_name': 'File Operations',
                        'resource_name': 'CUSTFILE',
                        'operation_count': 100,
                        'read_operations': 50,
                        'write_operations': 30,
                        'update_operations': 15,
                        'delete_operations': 5,
                        'io_wait_time': 1000
                    }
                ]
            }
        }
        
        # Transform the record
        result = schema.transform_record(json_record)
        
        # Verify main record
        assert 'smf_records' in result
        assert len(result['smf_records']) == 1
        assert result['smf_records'][0]['record_type'] == 110
        assert result['smf_records'][0]['system_id'] == 'SYS1'
        
        # Verify product section
        assert 'smf110_product' in result
        assert len(result['smf110_product']) == 1
        assert result['smf110_product'][0]['data_class'] == 5
        assert result['smf110_product'][0]['data_class_name'] == 'Transaction Resource'
        
        # Verify transaction resource data
        assert 'smf110_transaction_resource' in result
        assert len(result['smf110_transaction_resource']) == 1
        
        resource = result['smf110_transaction_resource'][0]
        assert resource['record_number'] == 1
        assert resource['record_offset'] == 100
        assert resource['record_length'] == 40
        assert resource['transaction_id'] == 'TST1'
        assert resource['resource_type'] == 1
        assert resource['resource_type_name'] == 'File Operations'
        assert resource['resource_name'] == 'CUSTFILE'
        assert resource['operation_count'] == 100
        assert resource['read_operations'] == 50
        assert resource['write_operations'] == 30
        assert resource['update_operations'] == 15
        assert resource['delete_operations'] == 5
        assert resource['io_wait_time'] == 1000
    
    def test_transform_database_operations_resource(self, schema):
        """Test transforming database operations resource record."""
        json_record = {
            'record_type': 110,
            'subtype': 1,
            'system_id': 'SYS1',
            'date': '2024-01-15',
            'timestamp': '10:30:45',
            'record_length': 1000,
            'header': {
                'subsystem_id': 'CICS'
            },
            'subsystem': {
                'data_class': 5,
                'product_name_generic': 'CICSTEST',
                'product_name_specific': 'CICSTEST',
                'record_version': 1,
                'data_record_count': 1
            },
            'identification': {
                'type': 'transaction_resource',
                'data_class': 5,
                'records': [
                    {
                        'record_number': 1,
                        'offset': 100,
                        'length': 44,
                        'transaction_id': 'DB01',
                        'resource_type': 2,
                        'resource_type_name': 'Database Calls',
                        'resource_name': 'ACCTTBL',
                        'operation_count': 200,
                        'select_operations': 150,
                        'insert_operations': 30,
                        'update_operations': 15,
                        'delete_operations': 5,
                        'database_wait_time': 5000,
                        'rows_processed': 1000
                    }
                ]
            }
        }
        
        # Transform the record
        result = schema.transform_record(json_record)
        
        # Verify transaction resource data
        assert 'smf110_transaction_resource' in result
        assert len(result['smf110_transaction_resource']) == 1
        
        resource = result['smf110_transaction_resource'][0]
        assert resource['transaction_id'] == 'DB01'
        assert resource['resource_type'] == 2
        assert resource['resource_type_name'] == 'Database Calls'
        assert resource['resource_name'] == 'ACCTTBL'
        assert resource['operation_count'] == 200
        assert resource['select_operations'] == 150
        assert resource['insert_operations'] == 30
        assert resource['update_operations'] == 15
        assert resource['delete_operations'] == 5
        assert resource['database_wait_time'] == 5000
        assert resource['rows_processed'] == 1000
    
    def test_transform_multiple_resource_records(self, schema):
        """Test transforming multiple transaction resource records."""
        json_record = {
            'record_type': 110,
            'subtype': 1,
            'system_id': 'SYS1',
            'date': '2024-01-15',
            'timestamp': '10:30:45',
            'record_length': 1000,
            'header': {
                'subsystem_id': 'CICS'
            },
            'subsystem': {
                'data_class': 5,
                'product_name_generic': 'CICSTEST',
                'product_name_specific': 'CICSTEST',
                'record_version': 1,
                'data_record_count': 3
            },
            'identification': {
                'type': 'transaction_resource',
                'data_class': 5,
                'records': [
                    {
                        'record_number': 1,
                        'offset': 100,
                        'length': 40,
                        'transaction_id': 'TST1',
                        'resource_type': 1,
                        'resource_type_name': 'File Operations',
                        'resource_name': 'CUSTFILE',
                        'operation_count': 100,
                        'read_operations': 50,
                        'write_operations': 30
                    },
                    {
                        'record_number': 2,
                        'offset': 140,
                        'length': 44,
                        'transaction_id': 'DB01',
                        'resource_type': 2,
                        'resource_type_name': 'Database Calls',
                        'resource_name': 'ACCTTBL',
                        'operation_count': 200,
                        'select_operations': 150
                    },
                    {
                        'record_number': 3,
                        'offset': 184,
                        'length': 32,
                        'transaction_id': 'PGM1',
                        'resource_type': 5,
                        'resource_type_name': 'Program Load',
                        'resource_name': 'CUSTPGM',
                        'operation_count': 10,
                        'program_loads': 10,
                        'program_size': 65536
                    }
                ]
            }
        }
        
        # Transform the record
        result = schema.transform_record(json_record)
        
        # Verify transaction resource data
        assert 'smf110_transaction_resource' in result
        assert len(result['smf110_transaction_resource']) == 3
        
        # Check first record (file operations)
        assert result['smf110_transaction_resource'][0]['transaction_id'] == 'TST1'
        assert result['smf110_transaction_resource'][0]['resource_type'] == 1
        assert result['smf110_transaction_resource'][0]['read_operations'] == 50
        
        # Check second record (database operations)
        assert result['smf110_transaction_resource'][1]['transaction_id'] == 'DB01'
        assert result['smf110_transaction_resource'][1]['resource_type'] == 2
        assert result['smf110_transaction_resource'][1]['select_operations'] == 150
        
        # Check third record (program load)
        assert result['smf110_transaction_resource'][2]['transaction_id'] == 'PGM1'
        assert result['smf110_transaction_resource'][2]['resource_type'] == 5
        assert result['smf110_transaction_resource'][2]['program_loads'] == 10
    
    def test_schema_has_all_resource_columns(self, schema):
        """Test that schema defines all expected resource columns."""
        table_defs = schema.get_table_definitions()
        
        assert 'smf110_transaction_resource' in table_defs
        
        resource_table = table_defs['smf110_transaction_resource']
        column_names = [col['name'] for col in resource_table['columns']]
        
        # Check for all expected columns
        expected_columns = [
            'resource_id', 'record_id', 'record_number', 'record_offset', 'record_length',
            'transaction_id', 'resource_type', 'resource_type_name', 'resource_name',
            'operation_count',
            # File operations
            'read_operations', 'write_operations', 'update_operations', 'delete_operations', 'io_wait_time',
            # Database operations
            'select_operations', 'insert_operations', 'database_wait_time', 'rows_processed',
            # Temporary storage
            'queue_read_operations', 'queue_write_operations', 'bytes_transferred',
            # Program load
            'program_loads', 'program_size', 'program_load_time',
            # Storage usage
            'storage_acquired', 'storage_released', 'peak_storage'
        ]
        
        for col in expected_columns:
            assert col in column_names, f"Column '{col}' not found in schema"
    
    def test_schema_has_indexes(self, schema):
        """Test that schema defines appropriate indexes."""
        table_defs = schema.get_table_definitions()
        resource_table = table_defs['smf110_transaction_resource']
        
        assert 'indexes' in resource_table
        assert len(resource_table['indexes']) > 0
        
        # Check for key indexes
        index_columns = [idx['columns'] for idx in resource_table['indexes']]
        assert ['record_id'] in index_columns
        assert ['transaction_id'] in index_columns
        assert ['resource_type'] in index_columns


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
