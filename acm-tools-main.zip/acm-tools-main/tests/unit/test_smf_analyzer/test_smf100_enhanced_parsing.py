"""Unit tests for SMF Type 100 enhanced field-level parsing.

Feature: db2-versioned-smf-parsers
Tests: Enhanced parsing for IFCID 1 and IFCID 2 data sections
"""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers.smf100_parser_v10 import SMF100ParserV10
from tools.smf_analyzer.smf_record_parser.parsers.smf100_parser_v11 import SMF100ParserV11
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser


def create_smf100_with_data_sections(
    ifcid: int = 1,
    db2_version: str = "V10"
) -> bytes:
    """Create SMF Type 100 record with populated data sections.
    
    Args:
        ifcid: IFCID value (1 or 2)
        db2_version: DB2 version ("V10" or "V11")
        
    Returns:
        Synthetic SMF Type 100 record with data sections
    """
    record_length = 1000
    record = bytearray(record_length)
    
    # SMF header
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('B', record, 5, 100)  # Record type
    struct.pack_into('>I', record, 6, 0x12345678)  # Timestamp
    struct.pack_into('>I', record, 10, 0x20240115)  # Date
    record[14:18] = b'SYS1'  # System ID
    record[18:22] = b'DB2P'  # Subsystem ID
    struct.pack_into('>H', record, 22, ifcid)  # Subtype
    
    # Product section triplet
    product_offset = 200
    struct.pack_into('>I', record, 28, product_offset)
    struct.pack_into('>H', record, 32, 100)
    struct.pack_into('>H', record, 34, 1)
    
    # QWHS header at product_offset
    struct.pack_into('>H', record, product_offset, 92)
    struct.pack_into('B', record, product_offset + 2, 1)
    struct.pack_into('B', record, product_offset + 3, 0xDB)
    struct.pack_into('>H', record, product_offset + 4, ifcid)
    
    # Set version
    if db2_version == "V10":
        struct.pack_into('>H', record, product_offset + 6, 0x0A00)
    else:  # V11
        struct.pack_into('>H', record, product_offset + 6, 0x0B00)
    
    record[product_offset + 14:product_offset + 18] = b'DB2P'
    
    if ifcid == 1:
        # IFCID 1: Create QWSA, QWSB, QWSD, QVLS sections
        
        # QWSA triplet (R1) at offset 36
        qwsa_offset = 300
        struct.pack_into('>I', record, 36, qwsa_offset)
        struct.pack_into('>H', record, 40, 44)
        struct.pack_into('>H', record, 42, 1)
        
        # QWSA data
        record[qwsa_offset:qwsa_offset + 4] = b'MSTR'  # Procedure name
        struct.pack_into('>Q', record, qwsa_offset + 4, 1234567890)  # Job step timer
        struct.pack_into('>Q', record, qwsa_offset + 12, 987654321)  # SRB timer
        struct.pack_into('>H', record, qwsa_offset + 20, 42)  # ASID
        struct.pack_into('>I', record, qwsa_offset + 24, 0xABCD)  # ASCB token
        struct.pack_into('>Q', record, qwsa_offset + 28, 555555)  # Preemptable SRB
        struct.pack_into('>Q', record, qwsa_offset + 36, 111111)  # Preemptable SRB zIIP
        
        # QWSB triplet (R2) at offset 44
        qwsb_offset = 350
        struct.pack_into('>I', record, 44, qwsb_offset)
        struct.pack_into('>H', record, 48, 28)
        struct.pack_into('>H', record, 50, 1)
        
        # QWSB data
        record[qwsb_offset:qwsb_offset + 4] = b'SMF '  # Destination name
        struct.pack_into('>I', record, qwsb_offset + 4, 12345)  # Sequence number
        struct.pack_into('>I', record, qwsb_offset + 8, 1000)  # Records written
        struct.pack_into('>I', record, qwsb_offset + 12, 5)  # Records not written
        struct.pack_into('>H', record, qwsb_offset + 16, 2)  # Buffer errors
        struct.pack_into('>H', record, qwsb_offset + 18, 1)  # Not active errors
        struct.pack_into('>H', record, qwsb_offset + 20, 0)  # Record not accepted
        struct.pack_into('>H', record, qwsb_offset + 22, 0)  # Writer failures
        
        # QWSC triplet (R3) at offset 52 - set to 0 (not present)
        struct.pack_into('>I', record, 52, 0)
        struct.pack_into('>H', record, 56, 0)
        struct.pack_into('>H', record, 58, 0)
        
        # Q3ST triplet (R4) at offset 60 - set to 0 (not present)
        struct.pack_into('>I', record, 60, 0)
        struct.pack_into('>H', record, 64, 0)
        struct.pack_into('>H', record, 66, 0)
        
        # Q9ST triplet (R5) at offset 68 - set to 0 (not present)
        struct.pack_into('>I', record, 68, 0)
        struct.pack_into('>H', record, 72, 0)
        struct.pack_into('>H', record, 74, 0)
        
        # QWSD triplet (R6) at offset 76
        qwsd_offset = 400
        struct.pack_into('>I', record, 76, qwsd_offset)
        struct.pack_into('>H', record, 80, 84)
        struct.pack_into('>H', record, 82, 1)
        
        # QWSD data
        struct.pack_into('>I', record, qwsd_offset, 50)  # Checkpoint count
        struct.pack_into('>I', record, qwsd_offset + 4, 0x10)  # Reason invoked
        struct.pack_into('>Q', record, qwsd_offset + 8, 0x123456789ABCDEF0)  # High RBA
        struct.pack_into('>I', record, qwsd_offset + 16, 0)  # IFI abends
        struct.pack_into('>I', record, qwsd_offset + 20, 0)  # IFI unrecognized
        struct.pack_into('>I', record, qwsd_offset + 24, 100)  # IFI command requests
        struct.pack_into('>I', record, qwsd_offset + 28, 50)  # IFI READA requests
        struct.pack_into('>I', record, qwsd_offset + 32, 200)  # IFI READS requests
        struct.pack_into('>I', record, qwsd_offset + 36, 10)  # IFI write requests
        struct.pack_into('>I', record, qwsd_offset + 40, 500)  # Data capture log records
        struct.pack_into('>I', record, qwsd_offset + 44, 250)  # Data capture log reads
        
        # QVLS triplet (R7) at offset 84
        qvls_offset = 500
        struct.pack_into('>I', record, 84, qvls_offset)
        struct.pack_into('>H', record, 88, 132)
        struct.pack_into('>H', record, 90, 1)
        
        # QVLS data - 32 latch classes
        for i in range(32):
            struct.pack_into('>I', record, qvls_offset + i * 4, i * 10)
        
        # Remaining triplets (R8-RD) - set to 0 (not present)
        for offset in range(92, 132, 8):
            struct.pack_into('>I', record, offset, 0)
            struct.pack_into('>H', record, offset + 4, 0)
            struct.pack_into('>H', record, offset + 6, 0)
        
    elif ifcid == 2:
        # IFCID 2: Create QXST, QBST, QTST, QIST, QTXA sections
        
        # QXST triplet (R1) at offset 36
        qxst_offset = 300
        struct.pack_into('>I', record, 36, qxst_offset)
        struct.pack_into('>H', record, 40, 1152)
        struct.pack_into('>H', record, 42, 1)
        
        # QXST data - SQL statement counts (parser reads at specific offsets)
        struct.pack_into('>Q', record, qxst_offset + 8, 5000)  # SELECT
        struct.pack_into('>Q', record, qxst_offset + 16, 1000)  # INSERT
        struct.pack_into('>Q', record, qxst_offset + 24, 800)  # UPDATE
        struct.pack_into('>Q', record, qxst_offset + 32, 200)  # DELETE
        struct.pack_into('>Q', record, qxst_offset + 40, 300)  # DESCRIBE
        struct.pack_into('>Q', record, qxst_offset + 48, 400)  # PREPARE
        struct.pack_into('>Q', record, qxst_offset + 56, 600)  # OPEN
        struct.pack_into('>Q', record, qxst_offset + 64, 600)  # CLOSE
        struct.pack_into('>Q', record, qxst_offset + 72, 10)  # CREATE TABLE
        struct.pack_into('>Q', record, qxst_offset + 80, 5)  # CREATE INDEX
        struct.pack_into('>Q', record, qxst_offset + 192, 10000)  # FETCH
        struct.pack_into('>Q', record, qxst_offset + 224, 500)  # COMMIT
        
        # QTST triplet (R2) at offset 44 - move after QXST (300 + 1152 = 1452, but record is only 1000)
        # Use offset 600 to avoid overlap
        qtst_offset = 600
        struct.pack_into('>I', record, 44, qtst_offset)
        struct.pack_into('>H', record, 48, 256)
        struct.pack_into('>H', record, 50, 1)
        
        # QTST data - Service controller statistics (parser reads at specific offsets)
        struct.pack_into('>I', record, qtst_offset + 8, 1000)  # Allocation attempts
        struct.pack_into('>I', record, qtst_offset + 12, 995)  # Successful allocations
        struct.pack_into('>I', record, qtst_offset + 16, 50)  # Autobind attempts
        struct.pack_into('>I', record, qtst_offset + 20, 48)  # Successful autobinds
        struct.pack_into('>I', record, qtst_offset + 28, 100)  # Bind add commands
        struct.pack_into('>I', record, qtst_offset + 32, 50)  # Bind replace commands
        struct.pack_into('>I', record, qtst_offset + 40, 150)  # Plans bound
        struct.pack_into('>I', record, qtst_offset + 44, 20)  # Rebind commands
        struct.pack_into('>I', record, qtst_offset + 52, 20)  # Plans rebound
        struct.pack_into('>I', record, qtst_offset + 56, 10)  # Free commands
        struct.pack_into('>I', record, qtst_offset + 64, 10)  # Plans freed
        struct.pack_into('>I', record, qtst_offset + 68, 5000)  # Authorization checks
        struct.pack_into('>I', record, qtst_offset + 72, 4995)  # Successful auth checks
        struct.pack_into('>I', record, qtst_offset + 76, 200)  # Datasets currently open
        struct.pack_into('>I', record, qtst_offset + 80, 250)  # Max datasets open
        
        # QBST triplet (R3) at offset 52 - needs to fit 456 bytes + up to offset 264
        # Total needed: 456 + 264 = 720, but we only use specific offsets
        # Use a larger record or just test the fields we care about
        # Set to 0 (not present) since we can't fit it in 1000 bytes
        struct.pack_into('>I', record, 52, 0)
        struct.pack_into('>H', record, 56, 0)
        struct.pack_into('>H', record, 58, 0)
        
        # QIST triplet (R4) at offset 60 - set to 0 (not present)
        struct.pack_into('>I', record, 60, 0)
        struct.pack_into('>H', record, 64, 0)
        struct.pack_into('>H', record, 66, 0)
        
        # QTXA triplet (R5) at offset 68 - set to 0 (not present)
        struct.pack_into('>I', record, 68, 0)
        struct.pack_into('>H', record, 72, 0)
        struct.pack_into('>H', record, 74, 0)
        
        # Remaining triplets (R6-RB) - set to 0 (not present)
        for offset in range(76, 116, 8):
            struct.pack_into('>I', record, offset, 0)
            struct.pack_into('>H', record, offset + 4, 0)
            struct.pack_into('>H', record, offset + 6, 0)
    
    return bytes(record[:record_length])


class TestSMF100EnhancedParsingIFCID1:
    """Tests for IFCID 1 (System Services) enhanced parsing."""
    
    def test_parse_qwsa_section(self):
        """Test QWSA (Control Address Spaces) section parsing."""
        record_data = create_smf100_with_data_sections(ifcid=1)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        assert 'data_sections' in result.header
        assert 'qwsa' in result.header['data_sections']
        
        qwsa = result.header['data_sections']['qwsa']
        assert 'procedure_name' in qwsa
        assert 'job_step_timer' in qwsa
        assert 'srb_timer' in qwsa
        assert 'asid' in qwsa
        assert qwsa['asid'] == 42
        assert 'preemptable_srb_timer' in qwsa
        assert 'preemptable_srb_ziip' in qwsa
    
    def test_parse_qwsb_section(self):
        """Test QWSB (IFC Destination Statistics) section parsing."""
        record_data = create_smf100_with_data_sections(ifcid=1)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        assert 'qwsb' in result.header['data_sections']
        
        qwsb = result.header['data_sections']['qwsb']
        assert 'destination_name' in qwsb
        assert 'records_written' in qwsb
        assert qwsb['records_written'] == 1000
        assert 'records_not_written' in qwsb
        assert qwsb['records_not_written'] == 5
        assert 'buffer_errors' in qwsb
        assert qwsb['buffer_errors'] == 2
        assert 'writer_failures' in qwsb
    
    def test_parse_qwsd_section(self):
        """Test QWSD (IFC Checkpoint Information) section parsing."""
        record_data = create_smf100_with_data_sections(ifcid=1)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        assert 'qwsd' in result.header['data_sections']
        
        qwsd = result.header['data_sections']['qwsd']
        assert 'checkpoint_count' in qwsd
        assert qwsd['checkpoint_count'] == 50
        assert 'reason_invoked' in qwsd
        assert 'high_used_rba' in qwsd
        assert 'ifi_command_requests' in qwsd
        assert qwsd['ifi_command_requests'] == 100
        assert 'ifi_reada_requests' in qwsd
        assert qwsd['ifi_reada_requests'] == 50
        assert 'data_capture_log_records' in qwsd
        assert qwsd['data_capture_log_records'] == 500
    
    def test_parse_qvls_section(self):
        """Test QVLS (Latch Statistics) section parsing."""
        record_data = create_smf100_with_data_sections(ifcid=1)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        assert 'qvls' in result.header['data_sections']
        
        qvls = result.header['data_sections']['qvls']
        assert 'latch_classes' in qvls
        assert 'total_suspends' in qvls
        
        # Verify all 32 latch classes are present
        latch_classes = qvls['latch_classes']
        assert len(latch_classes) == 32
        
        # Verify specific latch class values
        assert latch_classes['latch_class_01'] == 0
        assert latch_classes['latch_class_02'] == 10
        assert latch_classes['latch_class_32'] == 310
        
        # Verify total
        expected_total = sum(i * 10 for i in range(32))
        assert qvls['total_suspends'] == expected_total


class TestSMF100EnhancedParsingIFCID2:
    """Tests for IFCID 2 (Database Services) enhanced parsing."""
    
    def test_parse_qxst_section(self):
        """Test QXST (SQL Statistics) section parsing."""
        record_data = create_smf100_with_data_sections(ifcid=2)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        assert 'data_sections' in result.header
        assert 'qxst' in result.header['data_sections']
        
        qxst = result.header['data_sections']['qxst']
        assert 'select_count' in qxst
        assert qxst['select_count'] == 5000
        assert 'insert_count' in qxst
        assert qxst['insert_count'] == 1000
        assert 'update_count' in qxst
        assert qxst['update_count'] == 800
        assert 'delete_count' in qxst
        assert qxst['delete_count'] == 200
        assert 'prepare_count' in qxst
        assert qxst['prepare_count'] == 400
        assert 'fetch_count' in qxst
        assert qxst['fetch_count'] == 10000
        assert 'commit_count' in qxst
        assert qxst['commit_count'] == 500
    
    def test_parse_qtst_section(self):
        """Test QTST (Service Controller Statistics) section parsing."""
        record_data = create_smf100_with_data_sections(ifcid=2)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        assert 'qtst' in result.header['data_sections']
        
        qtst = result.header['data_sections']['qtst']
        assert 'allocation_attempts' in qtst
        assert qtst['allocation_attempts'] == 1000
        assert 'successful_allocations' in qtst
        assert qtst['successful_allocations'] == 995
        assert 'plans_bound' in qtst
        assert qtst['plans_bound'] == 150
        assert 'authorization_checks' in qtst
        assert qtst['authorization_checks'] == 5000
        assert 'successful_auth_checks' in qtst
        assert qtst['successful_auth_checks'] == 4995
        assert 'datasets_currently_open' in qtst
        assert qtst['datasets_currently_open'] == 200


class TestSMF100V11EnhancedParsing:
    """Tests for V11 parser with enhanced parsing."""
    
    def test_v11_parser_ifcid1(self):
        """Test V11 parser with IFCID 1 data sections."""
        record_data = create_smf100_with_data_sections(ifcid=1, db2_version="V11")
        parser = SMF100ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify version
        assert parser.db2_version == "V11"
        assert result.header['qwhs_header']['release_number'] == 0x0B00
        
        # Verify data sections are parsed
        assert 'data_sections' in result.header
        assert 'qwsa' in result.header['data_sections']
        assert 'qwsb' in result.header['data_sections']
        assert 'qwsd' in result.header['data_sections']
    
    def test_v11_parser_ifcid2(self):
        """Test V11 parser with IFCID 2 data sections."""
        record_data = create_smf100_with_data_sections(ifcid=2, db2_version="V11")
        parser = SMF100ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify version
        assert parser.db2_version == "V11"
        assert result.header['qwhs_header']['release_number'] == 0x0B00
        
        # Verify data sections are parsed (only QXST and QTST in test data)
        assert 'data_sections' in result.header
        assert 'qxst' in result.header['data_sections']
        assert 'qtst' in result.header['data_sections']
