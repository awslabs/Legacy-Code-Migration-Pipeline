"""Property-based tests for DB2 database schema field mapping and NULL handling.

This module contains property-based tests that verify:
- Property 14: Database Field Mapping
- Property 15: NULL Handling for Optional Fields

These tests ensure that parsed DB2 SMF records can be correctly mapped to database
schemas and that optional fields are properly handled with NULL values.
"""

import pytest
from hypothesis import given, strategies as st, assume
from typing import Dict, Any, Optional
import json

# Import schemas
from shared.database.schemas.smf_schemas import (
    SMF100Schema,
    SMF101Schema,
    SMF102Schema
)

# Import parsers and models
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


# Test data generators
@st.composite
def parsed_smf100_record(draw):
    """Generate a parsed SMF Type 100 record with random data."""
    # Generate required fields
    system_id = draw(st.text(min_size=1, max_size=8, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    subsystem_id = draw(st.text(min_size=0, max_size=4, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    db2_version = draw(st.sampled_from(['V10', 'V11', 'V12', 'V13']))
    record_date = draw(st.text(min_size=10, max_size=10, alphabet='0123456789-'))
    record_time = draw(st.text(min_size=8, max_size=8, alphabet='0123456789:'))
    record_length = draw(st.integers(min_value=100, max_value=32767))
    ifcid = draw(st.sampled_from([1, 2]))
    subsystem_name = draw(st.text(min_size=0, max_size=4, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    release_number = draw(st.integers(min_value=0, max_value=65535))
    
    # Generate optional fields (may be None)
    has_correlation = draw(st.booleans())
    has_trace = draw(st.booleans())
    has_cpu = draw(st.booleans())
    has_distributed = draw(st.booleans())
    has_data_sharing = draw(st.booleans())
    
    # Build sections
    sections = {
        'smf_header': {
            'system_id': system_id,
            'subsystem_id': subsystem_id,
            'record_length': record_length,
            'date': record_date,
            'timestamp': record_time,
        },
        'qwhs_header': {
            'ifcid': ifcid,
            'subsystem_name': subsystem_name,
            'release_number': release_number,
        },
        'product_section': {
            'offset': draw(st.integers(min_value=28, max_value=1000)),
            'length': draw(st.integers(min_value=100, max_value=5000)),
            'count': 1,
        },
        'self_defining_section': {
            'offset': 28,
            'ifcid': ifcid,
        },
    }
    
    # Add optional headers if present
    if has_correlation or has_trace or has_cpu or has_distributed or has_data_sharing:
        sections['optional_headers'] = {}
        if has_correlation:
            sections['optional_headers']['correlation'] = {'offset': 100, 'length': 20, 'type': 2}
        if has_trace:
            sections['optional_headers']['trace'] = {'offset': 120, 'length': 20, 'type': 4}
        if has_cpu:
            sections['optional_headers']['cpu'] = {'offset': 140, 'length': 20, 'type': 8}
        if has_distributed:
            sections['optional_headers']['distributed'] = {'offset': 160, 'length': 20, 'type': 16}
        if has_data_sharing:
            sections['optional_headers']['data_sharing'] = {'offset': 180, 'length': 20, 'type': 32}
    
    return ParsedRecord(
        record_type=100,
        subtype=ifcid,
        record_length=record_length,
        system_id=system_id,
        timestamp=f"{record_date} {record_time}",
        date=record_date,
        header=sections
    )


@st.composite
def parsed_smf101_record(draw):
    """Generate a parsed SMF Type 101 record with random data."""
    # Generate required fields
    system_id = draw(st.text(min_size=1, max_size=8, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    subsystem_id = draw(st.text(min_size=0, max_size=4, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    db2_version = draw(st.sampled_from(['V11', 'V12']))
    record_date = draw(st.text(min_size=10, max_size=10, alphabet='0123456789-'))
    record_time = draw(st.text(min_size=8, max_size=8, alphabet='0123456789:'))
    record_length = draw(st.integers(min_value=100, max_value=32767))
    ifcid = 3  # Type 101 is always IFCID 3
    subsystem_name = draw(st.text(min_size=0, max_size=4, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    release_number = draw(st.integers(min_value=0, max_value=65535))
    
    # Generate optional fields
    has_correlation = draw(st.booleans())
    has_trace = draw(st.booleans())
    has_cpu = draw(st.booleans())
    has_distributed = draw(st.booleans())
    has_data_sharing = draw(st.booleans())
    
    # Build sections
    sections = {
        'smf_header': {
            'system_id': system_id,
            'subsystem_id': subsystem_id,
            'record_length': record_length,
            'date': record_date,
            'timestamp': record_time,
        },
        'qwhs_header': {
            'ifcid': ifcid,
            'subsystem_name': subsystem_name,
            'release_number': release_number,
        },
        'product_section': {
            'offset': draw(st.integers(min_value=28, max_value=1000)),
            'length': draw(st.integers(min_value=100, max_value=5000)),
            'count': 1,
        },
        'self_defining_section': {
            'offset': 28,
            'ifcid': ifcid,
        },
    }
    
    # Add optional headers if present
    if has_correlation or has_trace or has_cpu or has_distributed or has_data_sharing:
        sections['optional_headers'] = {}
        if has_correlation:
            sections['optional_headers']['correlation'] = {'offset': 100, 'length': 20, 'type': 2}
        if has_trace:
            sections['optional_headers']['trace'] = {'offset': 120, 'length': 20, 'type': 4}
        if has_cpu:
            sections['optional_headers']['cpu'] = {'offset': 140, 'length': 20, 'type': 8}
        if has_distributed:
            sections['optional_headers']['distributed'] = {'offset': 160, 'length': 20, 'type': 16}
        if has_data_sharing:
            sections['optional_headers']['data_sharing'] = {'offset': 180, 'length': 20, 'type': 32}
    
    return ParsedRecord(
        record_type=101,
        subtype=ifcid,
        record_length=record_length,
        system_id=system_id,
        timestamp=f"{record_date} {record_time}",
        date=record_date,
        header=sections
    )


@st.composite
def parsed_smf102_record(draw):
    """Generate a parsed SMF Type 102 record with random data."""
    # Generate required fields
    system_id = draw(st.text(min_size=1, max_size=8, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    subsystem_id = draw(st.text(min_size=0, max_size=4, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    db2_version = draw(st.sampled_from(['V11', 'V12', 'V13']))
    record_date = draw(st.text(min_size=10, max_size=10, alphabet='0123456789-'))
    record_time = draw(st.text(min_size=8, max_size=8, alphabet='0123456789:'))
    record_length = draw(st.integers(min_value=100, max_value=32767))
    ifcid = draw(st.integers(min_value=0, max_value=65535))  # Type 102 has many IFCIDs
    subsystem_name = draw(st.text(min_size=0, max_size=4, alphabet=st.characters(
        whitelist_categories=('Lu', 'Nd'))))
    release_number = draw(st.integers(min_value=0, max_value=65535))
    
    # Generate optional fields
    has_correlation = draw(st.booleans())
    has_trace = draw(st.booleans())
    has_cpu = draw(st.booleans())
    has_distributed = draw(st.booleans())
    has_data_sharing = draw(st.booleans())
    
    # Build sections
    sections = {
        'smf_header': {
            'system_id': system_id,
            'subsystem_id': subsystem_id,
            'record_length': record_length,
            'date': record_date,
            'timestamp': record_time,
        },
        'qwhs_header': {
            'ifcid': ifcid,
            'subsystem_name': subsystem_name,
            'release_number': release_number,
        },
        'product_section': {
            'offset': draw(st.integers(min_value=28, max_value=1000)),
            'length': draw(st.integers(min_value=100, max_value=5000)),
            'count': 1,
        },
        'self_defining_section': {
            'offset': 28,
            'ifcid': ifcid,
        },
    }
    
    # Add optional headers if present
    if has_correlation or has_trace or has_cpu or has_distributed or has_data_sharing:
        sections['optional_headers'] = {}
        if has_correlation:
            sections['optional_headers']['correlation'] = {'offset': 100, 'length': 20, 'type': 2}
        if has_trace:
            sections['optional_headers']['trace'] = {'offset': 120, 'length': 20, 'type': 4}
        if has_cpu:
            sections['optional_headers']['cpu'] = {'offset': 140, 'length': 20, 'type': 8}
        if has_distributed:
            sections['optional_headers']['distributed'] = {'offset': 160, 'length': 20, 'type': 16}
        if has_data_sharing:
            sections['optional_headers']['data_sharing'] = {'offset': 180, 'length': 20, 'type': 32}
    
    return ParsedRecord(
        record_type=102,
        subtype=ifcid,
        record_length=record_length,
        system_id=system_id,
        timestamp=f"{record_date} {record_time}",
        date=record_date,
        header=sections
    )


# Helper function to extract database row from parsed record
def extract_header_row(parsed_record: ParsedRecord, record_type: int) -> Dict[str, Any]:
    """Extract header row data from parsed record for database insertion."""
    smf_header = parsed_record.header.get('smf_header', {})
    qwhs_header = parsed_record.header.get('qwhs_header', {})
    
    return {
        'system_id': parsed_record.system_id,
        'subsystem_id': smf_header.get('subsystem_id'),
        'db2_version': f"V{qwhs_header.get('release_number', 0) >> 8}",
        'record_date': parsed_record.date,
        'record_time': smf_header.get('timestamp'),
        'record_timestamp': parsed_record.timestamp,
        'record_length': parsed_record.record_length,
        'ifcid': qwhs_header.get('ifcid'),
        'subsystem_name': qwhs_header.get('subsystem_name'),
        'release_number': qwhs_header.get('release_number'),
    }


def extract_statistics_row(parsed_record: ParsedRecord) -> Dict[str, Any]:
    """Extract statistics/accounting/performance row from parsed record."""
    product_section = parsed_record.header.get('product_section', {})
    optional_headers = parsed_record.header.get('optional_headers', {})
    self_defining_section = parsed_record.header.get('self_defining_section', {})
    data_sections = parsed_record.header.get('data_sections', {})
    
    # Base fields common to all types
    result = {
        'product_section_offset': product_section.get('offset'),
        'product_section_length': product_section.get('length'),
        'product_section_count': product_section.get('count'),
        'has_correlation_header': 1 if 'correlation' in optional_headers else 0,
        'has_trace_header': 1 if 'trace' in optional_headers else 0,
        'has_cpu_header': 1 if 'cpu' in optional_headers else 0,
        'has_distributed_header': 1 if 'distributed' in optional_headers else 0,
        'has_data_sharing_header': 1 if 'data_sharing' in optional_headers else 0,
        'self_defining_section_offset': self_defining_section.get('offset'),
        'data_sections_json': json.dumps(data_sections) if data_sections else None,
    }
    
    # Add SMF101-specific accounting fields if this is a Type 101 record
    if parsed_record.record_type == 101:
        result.update({
            'begin_store_clock': None,
            'end_store_clock': None,
            'begin_cpu_time': None,
            'end_cpu_time': None,
            'accumulated_cpu_in_db2': None,
            'accumulated_elapsed_in_db2': None,
            'accumulated_wait_io': None,
            'accumulated_wait_lock': None,
            'commit_count': None,
            'abort_count': None,
            'db2_entry_exit_count': None,
            'is_rollup': 0,
            'class2_active': 0,
            'class3_active': 0,
            'package_count': None,
            'reason_invoked': None,
            'flags': None,
        })
    
    return result


# Feature: db2-versioned-smf-parsers, Property 14: Database Field Mapping
@given(parsed_record=parsed_smf100_record())
def test_smf100_database_field_mapping(parsed_record):
    """
    Property 14: Database Field Mapping for SMF Type 100.
    
    For any parsed SMF Type 100 record, all parsed fields should be mappable
    to their corresponding database columns according to SMF100Schema.
    
    **Validates: Requirements 8.5**
    """
    schema = SMF100Schema()
    table_defs = schema.get_table_definitions()
    
    # Extract header row
    header_row = extract_header_row(parsed_record, 100)
    
    # Verify all header columns can be populated
    header_columns = {col['name'] for col in table_defs['smf_records']['columns']
                     if col['name'] != 'record_id' and col['name'] != 'created_at'}
    
    for col_name in header_columns:
        assert col_name in header_row, f"Missing mapping for column {col_name}"
    
    # Extract statistics row
    stats_row = extract_statistics_row(parsed_record)
    
    # Verify all statistics columns can be populated
    stats_columns = {col['name'] for col in table_defs['smf100_statistics']['columns']
                    if col['name'] not in ('stat_id', 'record_id')}
    
    for col_name in stats_columns:
        assert col_name in stats_row, f"Missing mapping for column {col_name}"


@given(parsed_record=parsed_smf101_record())
def test_smf101_database_field_mapping(parsed_record):
    """
    Property 14: Database Field Mapping for SMF Type 101.
    
    For any parsed SMF Type 101 record, all parsed fields should be mappable
    to their corresponding database columns according to SMF101Schema.
    
    **Validates: Requirements 8.5**
    """
    schema = SMF101Schema()
    table_defs = schema.get_table_definitions()
    
    # Extract header row
    header_row = extract_header_row(parsed_record, 101)
    
    # Verify all header columns can be populated
    header_columns = {col['name'] for col in table_defs['smf_records']['columns']
                     if col['name'] != 'record_id' and col['name'] != 'created_at'}
    
    for col_name in header_columns:
        assert col_name in header_row, f"Missing mapping for column {col_name}"
    
    # Extract accounting row
    acct_row = extract_statistics_row(parsed_record)
    
    # Verify all accounting columns can be populated
    acct_columns = {col['name'] for col in table_defs['smf101_accounting']['columns']
                   if col['name'] not in ('acct_id', 'record_id')}
    
    for col_name in acct_columns:
        assert col_name in acct_row, f"Missing mapping for column {col_name}"


@given(parsed_record=parsed_smf102_record())
def test_smf102_database_field_mapping(parsed_record):
    """
    Property 14: Database Field Mapping for SMF Type 102.
    
    For any parsed SMF Type 102 record, all parsed fields should be mappable
    to their corresponding database columns according to SMF102Schema.
    
    **Validates: Requirements 8.5**
    """
    schema = SMF102Schema()
    table_defs = schema.get_table_definitions()
    
    # Extract header row
    header_row = extract_header_row(parsed_record, 102)
    
    # Verify all header columns can be populated
    header_columns = {col['name'] for col in table_defs['smf_records']['columns']
                     if col['name'] != 'record_id' and col['name'] != 'created_at'}
    
    for col_name in header_columns:
        assert col_name in header_row, f"Missing mapping for column {col_name}"
    
    # Extract performance row
    perf_row = extract_statistics_row(parsed_record)
    
    # Verify all performance columns can be populated
    perf_columns = {col['name'] for col in table_defs['smf102_performance']['columns']
                   if col['name'] not in ('perf_id', 'record_id')}
    
    for col_name in perf_columns:
        assert col_name in perf_row, f"Missing mapping for column {col_name}"


# Feature: db2-versioned-smf-parsers, Property 15: NULL Handling for Optional Fields
@given(parsed_record=parsed_smf100_record())
def test_smf100_null_handling_for_optional_fields(parsed_record):
    """
    Property 15: NULL Handling for Optional Fields in SMF Type 100.
    
    For any parsed SMF Type 100 record with missing optional fields,
    loading it into the database should store NULL values for those fields.
    
    **Validates: Requirements 8.6**
    """
    # Extract statistics row
    stats_row = extract_statistics_row(parsed_record)
    
    # Check optional header flags
    optional_headers = parsed_record.header.get('optional_headers', {})
    
    # If correlation header is missing, flag should be 0 (NULL equivalent)
    if 'correlation' not in optional_headers:
        assert stats_row['has_correlation_header'] == 0
    
    # If trace header is missing, flag should be 0
    if 'trace' not in optional_headers:
        assert stats_row['has_trace_header'] == 0
    
    # If CPU header is missing, flag should be 0
    if 'cpu' not in optional_headers:
        assert stats_row['has_cpu_header'] == 0
    
    # If distributed header is missing, flag should be 0
    if 'distributed' not in optional_headers:
        assert stats_row['has_distributed_header'] == 0
    
    # If data sharing header is missing, flag should be 0
    if 'data_sharing' not in optional_headers:
        assert stats_row['has_data_sharing_header'] == 0
    
    # If data sections are missing, JSON should be None
    if 'data_sections' not in parsed_record.header:
        assert stats_row['data_sections_json'] is None


@given(parsed_record=parsed_smf101_record())
def test_smf101_null_handling_for_optional_fields(parsed_record):
    """
    Property 15: NULL Handling for Optional Fields in SMF Type 101.
    
    For any parsed SMF Type 101 record with missing optional fields,
    loading it into the database should store NULL values for those fields.
    
    **Validates: Requirements 8.6**
    """
    # Extract accounting row
    acct_row = extract_statistics_row(parsed_record)
    
    # Check optional header flags
    optional_headers = parsed_record.header.get('optional_headers', {})
    
    # Verify NULL handling for missing optional headers
    if 'correlation' not in optional_headers:
        assert acct_row['has_correlation_header'] == 0
    
    if 'trace' not in optional_headers:
        assert acct_row['has_trace_header'] == 0
    
    if 'cpu' not in optional_headers:
        assert acct_row['has_cpu_header'] == 0
    
    if 'distributed' not in optional_headers:
        assert acct_row['has_distributed_header'] == 0
    
    if 'data_sharing' not in optional_headers:
        assert acct_row['has_data_sharing_header'] == 0
    
    # If data sections are missing, JSON should be None
    if 'data_sections' not in parsed_record.header:
        assert acct_row['data_sections_json'] is None


@given(parsed_record=parsed_smf102_record())
def test_smf102_null_handling_for_optional_fields(parsed_record):
    """
    Property 15: NULL Handling for Optional Fields in SMF Type 102.
    
    For any parsed SMF Type 102 record with missing optional fields,
    loading it into the database should store NULL values for those fields.
    
    **Validates: Requirements 8.6**
    """
    # Extract performance row
    perf_row = extract_statistics_row(parsed_record)
    
    # Check optional header flags
    optional_headers = parsed_record.header.get('optional_headers', {})
    
    # Verify NULL handling for missing optional headers
    if 'correlation' not in optional_headers:
        assert perf_row['has_correlation_header'] == 0
    
    if 'trace' not in optional_headers:
        assert perf_row['has_trace_header'] == 0
    
    if 'cpu' not in optional_headers:
        assert perf_row['has_cpu_header'] == 0
    
    if 'distributed' not in optional_headers:
        assert perf_row['has_distributed_header'] == 0
    
    if 'data_sharing' not in optional_headers:
        assert perf_row['has_data_sharing_header'] == 0
    
    # If data sections are missing, JSON should be None
    if 'data_sections' not in parsed_record.header:
        assert perf_row['data_sections_json'] is None
