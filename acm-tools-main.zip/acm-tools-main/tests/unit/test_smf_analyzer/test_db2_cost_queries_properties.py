"""Property-based tests for DB2 cost queries.

This module contains property-based tests for DB2 cost analysis queries
to validate correctness properties across all valid inputs.

Properties tested:
- Property 10: Cost Calculation Non-Negativity (Mainframe Costs)
"""

import pytest
from hypothesis import given, strategies as st, settings
from typing import List


class TestProperty10CostCalculationNonNegativityMainframe:
    """
    Property 10: Cost Calculation Non-Negativity (Mainframe Costs)
    
    For any valid input parameters, all cost calculations (mainframe costs, RDS costs, 
    migration costs) should produce non-negative values.
    
    Feature: db2-migration-queries
    Property 10: Cost Calculation Non-Negativity
    Validates: Requirements 10.1
    """
    
    @given(
        cpu_seconds=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        mips_cost_low=st.floats(min_value=1000.0, max_value=10000.0, allow_nan=False, allow_infinity=False),
        mips_cost_mid=st.floats(min_value=2000.0, max_value=15000.0, allow_nan=False, allow_infinity=False),
        mips_cost_high=st.floats(min_value=3000.0, max_value=20000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_mainframe_cost_non_negativity(
        self,
        cpu_seconds: float,
        mips_cost_low: float,
        mips_cost_mid: float,
        mips_cost_high: float
    ):
        """
        Property test: Mainframe cost calculations should always be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Convert CPU seconds to hours
        cpu_hours = cpu_seconds / 3600.0
        
        # Estimate MIPS-hours (simplified conversion: 1 CPU hour ≈ 0.001 MIPS-hour)
        mips_hours = cpu_hours * 0.001
        
        # Calculate monthly costs (assuming 730 hours per month)
        monthly_cost_low = (mips_hours / 730.0) * mips_cost_low
        monthly_cost_mid = (mips_hours / 730.0) * mips_cost_mid
        monthly_cost_high = (mips_hours / 730.0) * mips_cost_high
        
        # Verify non-negativity
        assert monthly_cost_low >= 0, f"Monthly cost (low) must be non-negative, got {monthly_cost_low}"
        assert monthly_cost_mid >= 0, f"Monthly cost (mid) must be non-negative, got {monthly_cost_mid}"
        assert monthly_cost_high >= 0, f"Monthly cost (high) must be non-negative, got {monthly_cost_high}"
        
        # Calculate annual costs
        annual_cost_low = monthly_cost_low * 12
        annual_cost_mid = monthly_cost_mid * 12
        annual_cost_high = monthly_cost_high * 12
        
        # Verify annual costs are non-negative
        assert annual_cost_low >= 0, f"Annual cost (low) must be non-negative, got {annual_cost_low}"
        assert annual_cost_mid >= 0, f"Annual cost (mid) must be non-negative, got {annual_cost_mid}"
        assert annual_cost_high >= 0, f"Annual cost (high) must be non-negative, got {annual_cost_high}"
    
    @given(
        cpu_seconds=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        mips_cost=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False),
        software_ratio=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        hardware_ratio=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        support_ratio=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_cost_breakdown_non_negativity(
        self,
        cpu_seconds: float,
        mips_cost: float,
        software_ratio: float,
        hardware_ratio: float,
        support_ratio: float
    ):
        """
        Property test: Cost breakdown components should be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Convert CPU seconds to MIPS-hours
        cpu_hours = cpu_seconds / 3600.0
        mips_hours = cpu_hours * 0.001
        
        # Calculate monthly cost
        monthly_cost = (mips_hours / 730.0) * mips_cost
        
        # Calculate cost breakdown
        software_cost = monthly_cost * software_ratio
        hardware_cost = monthly_cost * hardware_ratio
        support_cost = monthly_cost * support_ratio
        
        # Verify all components are non-negative
        assert software_cost >= 0, f"Software cost must be non-negative, got {software_cost}"
        assert hardware_cost >= 0, f"Hardware cost must be non-negative, got {hardware_cost}"
        assert support_cost >= 0, f"Support cost must be non-negative, got {support_cost}"
        
        # Verify total cost is non-negative
        assert monthly_cost >= 0, f"Total monthly cost must be non-negative, got {monthly_cost}"
    
    @given(
        cpu_seconds=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        mips_cost=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_zero_cpu_zero_cost(
        self,
        cpu_seconds: float,
        mips_cost: float
    ):
        """
        Property test: Zero CPU consumption should produce zero cost.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # If CPU is zero, cost should be zero
        if cpu_seconds == 0:
            cpu_hours = cpu_seconds / 3600.0
            mips_hours = cpu_hours * 0.001
            monthly_cost = (mips_hours / 730.0) * mips_cost
            
            assert monthly_cost == 0, f"Zero CPU should produce zero cost, got {monthly_cost}"
    
    @given(
        cpu_seconds_1=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        cpu_seconds_2=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        mips_cost=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_cost_monotonicity(
        self,
        cpu_seconds_1: float,
        cpu_seconds_2: float,
        mips_cost: float
    ):
        """
        Property test: More CPU consumption should produce higher or equal cost.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Calculate costs for both CPU values
        cpu_hours_1 = cpu_seconds_1 / 3600.0
        mips_hours_1 = cpu_hours_1 * 0.001
        monthly_cost_1 = (mips_hours_1 / 730.0) * mips_cost
        
        cpu_hours_2 = cpu_seconds_2 / 3600.0
        mips_hours_2 = cpu_hours_2 * 0.001
        monthly_cost_2 = (mips_hours_2 / 730.0) * mips_cost
        
        # Verify monotonicity: more CPU should produce higher or equal cost
        if cpu_seconds_1 > cpu_seconds_2:
            assert monthly_cost_1 >= monthly_cost_2, \
                f"Cost monotonicity violated: more CPU produced less cost"
        elif cpu_seconds_2 > cpu_seconds_1:
            assert monthly_cost_2 >= monthly_cost_1, \
                f"Cost monotonicity violated: more CPU produced less cost"
        else:
            # Equal CPU should produce equal cost
            assert abs(monthly_cost_1 - monthly_cost_2) < 0.01, \
                f"Equal CPU should produce equal cost"
    
    @given(
        cpu_seconds=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        mips_cost=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_cost_linear_scaling(
        self,
        cpu_seconds: float,
        mips_cost: float
    ):
        """
        Property test: Doubling CPU should double cost.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Calculate cost for original CPU
        cpu_hours = cpu_seconds / 3600.0
        mips_hours = cpu_hours * 0.001
        monthly_cost_1x = (mips_hours / 730.0) * mips_cost
        
        # Calculate cost for doubled CPU
        cpu_hours_2x = (cpu_seconds * 2) / 3600.0
        mips_hours_2x = cpu_hours_2x * 0.001
        monthly_cost_2x = (mips_hours_2x / 730.0) * mips_cost
        
        # Verify linear scaling
        expected_2x = monthly_cost_1x * 2
        
        # Use absolute tolerance for very small numbers
        if monthly_cost_1x > 1e-10:
            relative_error = abs(monthly_cost_2x - expected_2x) / monthly_cost_1x
            assert relative_error < 0.001, \
                f"Linear scaling violated: 2x CPU produced {monthly_cost_2x}, expected {expected_2x}"
        else:
            assert abs(monthly_cost_2x - expected_2x) < 1e-10, \
                f"Linear scaling violated for small values"
    
    @given(
        cpu_seconds=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        mips_cost_1=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False),
        mips_cost_2=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_cost_parameter_ordering(
        self,
        cpu_seconds: float,
        mips_cost_1: float,
        mips_cost_2: float
    ):
        """
        Property test: Higher MIPS cost should produce higher total cost.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Calculate costs with both MIPS cost parameters
        cpu_hours = cpu_seconds / 3600.0
        mips_hours = cpu_hours * 0.001
        
        monthly_cost_1 = (mips_hours / 730.0) * mips_cost_1
        monthly_cost_2 = (mips_hours / 730.0) * mips_cost_2
        
        # Verify ordering: higher MIPS cost produces higher total cost
        if mips_cost_1 > mips_cost_2:
            assert monthly_cost_1 >= monthly_cost_2, \
                f"Cost ordering violated: higher MIPS cost produced lower total cost"
        elif mips_cost_2 > mips_cost_1:
            assert monthly_cost_2 >= monthly_cost_1, \
                f"Cost ordering violated: higher MIPS cost produced lower total cost"
        else:
            # Equal MIPS cost should produce equal total cost
            assert abs(monthly_cost_1 - monthly_cost_2) < 0.01, \
                f"Equal MIPS cost should produce equal total cost"
    
    @given(
        cpu_seconds_list=st.lists(
            st.floats(min_value=0.0, max_value=100_000.0, allow_nan=False, allow_infinity=False),
            min_size=1,
            max_size=50
        ),
        mips_cost=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_aggregated_cost_non_negativity(
        self,
        cpu_seconds_list: List[float],
        mips_cost: float
    ):
        """
        Property test: Aggregated costs across plans should be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Calculate total cost across all plans
        total_monthly_cost = 0.0
        
        for cpu_seconds in cpu_seconds_list:
            cpu_hours = cpu_seconds / 3600.0
            mips_hours = cpu_hours * 0.001
            monthly_cost = (mips_hours / 730.0) * mips_cost
            total_monthly_cost += monthly_cost
        
        # Verify total cost is non-negative
        assert total_monthly_cost >= 0, \
            f"Total monthly cost must be non-negative, got {total_monthly_cost}"
        
        # Verify annual cost is non-negative
        total_annual_cost = total_monthly_cost * 12
        assert total_annual_cost >= 0, \
            f"Total annual cost must be non-negative, got {total_annual_cost}"
    
    @given(
        cpu_seconds=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        mips_cost=st.floats(min_value=1000.0, max_value=20000.0, allow_nan=False, allow_infinity=False),
        software_ratio=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        hardware_ratio=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        support_ratio=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_cost_breakdown_sum(
        self,
        cpu_seconds: float,
        mips_cost: float,
        software_ratio: float,
        hardware_ratio: float,
        support_ratio: float
    ):
        """
        Property test: Cost breakdown components should sum to total (if ratios sum to 1.0).
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Normalize ratios to sum to 1.0
        total_ratio = software_ratio + hardware_ratio + support_ratio
        if total_ratio > 0:
            software_ratio_norm = software_ratio / total_ratio
            hardware_ratio_norm = hardware_ratio / total_ratio
            support_ratio_norm = support_ratio / total_ratio
            
            # Calculate total cost
            cpu_hours = cpu_seconds / 3600.0
            mips_hours = cpu_hours * 0.001
            monthly_cost = (mips_hours / 730.0) * mips_cost
            
            # Calculate breakdown
            software_cost = monthly_cost * software_ratio_norm
            hardware_cost = monthly_cost * hardware_ratio_norm
            support_cost = monthly_cost * support_ratio_norm
            
            # Verify breakdown sums to total
            breakdown_sum = software_cost + hardware_cost + support_cost
            
            if monthly_cost > 1e-10:
                relative_error = abs(breakdown_sum - monthly_cost) / monthly_cost
                assert relative_error < 0.001, \
                    f"Cost breakdown sum {breakdown_sum} != total {monthly_cost}"
            else:
                assert abs(breakdown_sum - monthly_cost) < 1e-10, \
                    f"Cost breakdown sum {breakdown_sum} != total {monthly_cost}"
        else:
            # If all ratios are zero, skip this test case
            pass



class TestProperty10CostCalculationNonNegativityRDS:
    """
    Property 10: Cost Calculation Non-Negativity (RDS Costs)
    
    For any valid input parameters, all RDS cost calculations should produce non-negative values.
    
    Feature: db2-migration-queries
    Property 10: Cost Calculation Non-Negativity
    Validates: Requirements 10.2, 10.3, 10.4, 10.5, 10.6
    """
    
    @given(
        required_vcpus=st.floats(min_value=0.0, max_value=64.0, allow_nan=False, allow_infinity=False),
        instance_hourly_cost=st.floats(min_value=0.0, max_value=10.0, allow_nan=False, allow_infinity=False),
        hours_per_month=st.integers(min_value=672, max_value=744)
    )
    @settings(max_examples=100)
    def test_property_10_rds_instance_cost_non_negativity(
        self,
        required_vcpus: float,
        instance_hourly_cost: float,
        hours_per_month: int
    ):
        """
        Property test: RDS instance costs should always be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 10.2
        """
        # Calculate monthly instance cost
        monthly_instance_cost = instance_hourly_cost * hours_per_month
        
        # Verify non-negativity
        assert monthly_instance_cost >= 0, \
            f"Monthly instance cost must be non-negative, got {monthly_instance_cost}"
        
        # Calculate annual instance cost
        annual_instance_cost = monthly_instance_cost * 12
        
        # Verify annual cost is non-negative
        assert annual_instance_cost >= 0, \
            f"Annual instance cost must be non-negative, got {annual_instance_cost}"
    
    @given(
        required_storage_gb=st.floats(min_value=0.0, max_value=10000.0, allow_nan=False, allow_infinity=False),
        storage_cost_per_gb=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_rds_storage_cost_non_negativity(
        self,
        required_storage_gb: float,
        storage_cost_per_gb: float
    ):
        """
        Property test: RDS storage costs should always be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 10.3
        """
        # Calculate monthly storage cost
        monthly_storage_cost = required_storage_gb * storage_cost_per_gb
        
        # Verify non-negativity
        assert monthly_storage_cost >= 0, \
            f"Monthly storage cost must be non-negative, got {monthly_storage_cost}"
        
        # Calculate annual storage cost
        annual_storage_cost = monthly_storage_cost * 12
        
        # Verify annual cost is non-negative
        assert annual_storage_cost >= 0, \
            f"Annual storage cost must be non-negative, got {annual_storage_cost}"
    
    @given(
        required_iops=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        iops_cost_per_iops=st.floats(min_value=0.0, max_value=0.2, allow_nan=False, allow_infinity=False),
        baseline_iops=st.floats(min_value=0.0, max_value=5000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_rds_iops_cost_non_negativity(
        self,
        required_iops: float,
        iops_cost_per_iops: float,
        baseline_iops: float
    ):
        """
        Property test: RDS IOPS costs should always be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 10.4
        """
        # Calculate monthly IOPS cost (only charge for IOPS above baseline)
        billable_iops = max(0, required_iops - baseline_iops)
        monthly_iops_cost = billable_iops * iops_cost_per_iops
        
        # Verify non-negativity
        assert monthly_iops_cost >= 0, \
            f"Monthly IOPS cost must be non-negative, got {monthly_iops_cost}"
        
        # Calculate annual IOPS cost
        annual_iops_cost = monthly_iops_cost * 12
        
        # Verify annual cost is non-negative
        assert annual_iops_cost >= 0, \
            f"Annual IOPS cost must be non-negative, got {annual_iops_cost}"
    
    @given(
        required_storage_gb=st.floats(min_value=0.0, max_value=10000.0, allow_nan=False, allow_infinity=False),
        storage_cost_per_gb=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        backup_storage_ratio=st.floats(min_value=0.0, max_value=2.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_rds_backup_cost_non_negativity(
        self,
        required_storage_gb: float,
        storage_cost_per_gb: float,
        backup_storage_ratio: float
    ):
        """
        Property test: RDS backup storage costs should always be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 10.5
        """
        # Calculate backup storage size
        backup_storage_gb = required_storage_gb * backup_storage_ratio
        
        # Calculate monthly backup cost
        monthly_backup_cost = backup_storage_gb * storage_cost_per_gb
        
        # Verify non-negativity
        assert monthly_backup_cost >= 0, \
            f"Monthly backup cost must be non-negative, got {monthly_backup_cost}"
        
        # Calculate annual backup cost
        annual_backup_cost = monthly_backup_cost * 12
        
        # Verify annual cost is non-negative
        assert annual_backup_cost >= 0, \
            f"Annual backup cost must be non-negative, got {annual_backup_cost}"
    
    @given(
        avg_daily_data_transfer_gb=st.floats(min_value=0.0, max_value=10000.0, allow_nan=False, allow_infinity=False),
        data_transfer_cost_per_gb=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_rds_data_transfer_cost_non_negativity(
        self,
        avg_daily_data_transfer_gb: float,
        data_transfer_cost_per_gb: float
    ):
        """
        Property test: RDS data transfer costs should always be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 10.6
        """
        # Calculate monthly data transfer cost (30 days)
        monthly_data_transfer_cost = avg_daily_data_transfer_gb * 30 * data_transfer_cost_per_gb
        
        # Verify non-negativity
        assert monthly_data_transfer_cost >= 0, \
            f"Monthly data transfer cost must be non-negative, got {monthly_data_transfer_cost}"
        
        # Calculate annual data transfer cost (365 days)
        annual_data_transfer_cost = avg_daily_data_transfer_gb * 365 * data_transfer_cost_per_gb
        
        # Verify annual cost is non-negative
        assert annual_data_transfer_cost >= 0, \
            f"Annual data transfer cost must be non-negative, got {annual_data_transfer_cost}"
    
    @given(
        instance_cost=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        storage_cost=st.floats(min_value=0.0, max_value=50000.0, allow_nan=False, allow_infinity=False),
        iops_cost=st.floats(min_value=0.0, max_value=50000.0, allow_nan=False, allow_infinity=False),
        backup_cost=st.floats(min_value=0.0, max_value=25000.0, allow_nan=False, allow_infinity=False),
        data_transfer_cost=st.floats(min_value=0.0, max_value=10000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_rds_total_cost_non_negativity(
        self,
        instance_cost: float,
        storage_cost: float,
        iops_cost: float,
        backup_cost: float,
        data_transfer_cost: float
    ):
        """
        Property test: Total RDS costs should be non-negative and equal to sum of components.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 10.2, 10.3, 10.4, 10.5, 10.6
        """
        # Calculate total cost
        total_cost = instance_cost + storage_cost + iops_cost + backup_cost + data_transfer_cost
        
        # Verify non-negativity
        assert total_cost >= 0, f"Total cost must be non-negative, got {total_cost}"
        
        # Verify total is sum of components
        expected_total = instance_cost + storage_cost + iops_cost + backup_cost + data_transfer_cost
        assert abs(total_cost - expected_total) < 0.01, \
            f"Total cost {total_cost} != sum of components {expected_total}"
    
    @given(
        monthly_subtotal=st.floats(min_value=0.0, max_value=200000.0, allow_nan=False, allow_infinity=False),
        support_tier=st.floats(min_value=0.0, max_value=0.20, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_rds_support_cost_non_negativity(
        self,
        monthly_subtotal: float,
        support_tier: float
    ):
        """
        Property test: AWS Support costs should be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Calculate support cost
        monthly_support_cost = monthly_subtotal * support_tier
        
        # Verify non-negativity
        assert monthly_support_cost >= 0, \
            f"Monthly support cost must be non-negative, got {monthly_support_cost}"
        
        # Calculate total with support
        monthly_total_cost = monthly_subtotal * (1 + support_tier)
        
        # Verify total is non-negative
        assert monthly_total_cost >= 0, \
            f"Monthly total cost must be non-negative, got {monthly_total_cost}"
        
        # Verify total is greater than or equal to subtotal
        assert monthly_total_cost >= monthly_subtotal, \
            f"Total cost {monthly_total_cost} should be >= subtotal {monthly_subtotal}"
    
    @given(
        required_storage_gb=st.floats(min_value=0.0, max_value=10000.0, allow_nan=False, allow_infinity=False),
        gp3_cost=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        io2_cost=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_storage_type_cost_comparison(
        self,
        required_storage_gb: float,
        gp3_cost: float,
        io2_cost: float
    ):
        """
        Property test: Storage costs should be consistent regardless of storage type.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Calculate costs for both storage types
        monthly_gp3_cost = required_storage_gb * gp3_cost
        monthly_io2_cost = required_storage_gb * io2_cost
        
        # Verify both are non-negative
        assert monthly_gp3_cost >= 0, f"GP3 cost must be non-negative, got {monthly_gp3_cost}"
        assert monthly_io2_cost >= 0, f"IO2 cost must be non-negative, got {monthly_io2_cost}"
        
        # If IO2 cost per GB is higher, total IO2 cost should be higher or equal
        if io2_cost > gp3_cost and required_storage_gb > 0:
            assert monthly_io2_cost >= monthly_gp3_cost, \
                f"IO2 cost {monthly_io2_cost} should be >= GP3 cost {monthly_gp3_cost}"
        elif gp3_cost > io2_cost and required_storage_gb > 0:
            assert monthly_gp3_cost >= monthly_io2_cost, \
                f"GP3 cost {monthly_gp3_cost} should be >= IO2 cost {monthly_io2_cost}"
    
    @given(
        required_vcpus=st.floats(min_value=0.0, max_value=64.0, allow_nan=False, allow_infinity=False),
        m6i_large_hourly=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        m6i_xlarge_hourly=st.floats(min_value=0.0, max_value=2.0, allow_nan=False, allow_infinity=False),
        m6i_2xlarge_hourly=st.floats(min_value=0.0, max_value=4.0, allow_nan=False, allow_infinity=False),
        m6i_4xlarge_hourly=st.floats(min_value=0.0, max_value=8.0, allow_nan=False, allow_infinity=False),
        hours_per_month=st.integers(min_value=672, max_value=744)
    )
    @settings(max_examples=100)
    def test_property_10_instance_selection_cost_ordering(
        self,
        required_vcpus: float,
        m6i_large_hourly: float,
        m6i_xlarge_hourly: float,
        m6i_2xlarge_hourly: float,
        m6i_4xlarge_hourly: float,
        hours_per_month: int
    ):
        """
        Property test: Instance selection should produce non-negative costs.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Select instance type based on vCPU requirements
        if required_vcpus <= 2:
            instance_hourly_cost = m6i_large_hourly
        elif required_vcpus <= 4:
            instance_hourly_cost = m6i_xlarge_hourly
        elif required_vcpus <= 8:
            instance_hourly_cost = m6i_2xlarge_hourly
        else:
            instance_hourly_cost = m6i_4xlarge_hourly
        
        # Calculate monthly cost
        monthly_instance_cost = instance_hourly_cost * hours_per_month
        
        # Verify non-negativity
        assert monthly_instance_cost >= 0, \
            f"Monthly instance cost must be non-negative, got {monthly_instance_cost}"
    
    @given(
        instance_cost=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        storage_cost=st.floats(min_value=0.0, max_value=50000.0, allow_nan=False, allow_infinity=False),
        iops_cost=st.floats(min_value=0.0, max_value=50000.0, allow_nan=False, allow_infinity=False),
        backup_cost=st.floats(min_value=0.0, max_value=25000.0, allow_nan=False, allow_infinity=False),
        data_transfer_cost=st.floats(min_value=0.0, max_value=10000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_cost_percentage_breakdown(
        self,
        instance_cost: float,
        storage_cost: float,
        iops_cost: float,
        backup_cost: float,
        data_transfer_cost: float
    ):
        """
        Property test: Cost percentage breakdown should sum to 100%.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        """
        # Calculate total cost
        total_cost = instance_cost + storage_cost + iops_cost + backup_cost + data_transfer_cost
        
        if total_cost > 0:
            # Calculate percentages
            instance_pct = (instance_cost / total_cost) * 100
            storage_pct = (storage_cost / total_cost) * 100
            iops_pct = (iops_cost / total_cost) * 100
            backup_pct = (backup_cost / total_cost) * 100
            data_transfer_pct = (data_transfer_cost / total_cost) * 100
            
            # Verify all percentages are non-negative
            assert instance_pct >= 0, f"Instance percentage must be non-negative, got {instance_pct}"
            assert storage_pct >= 0, f"Storage percentage must be non-negative, got {storage_pct}"
            assert iops_pct >= 0, f"IOPS percentage must be non-negative, got {iops_pct}"
            assert backup_pct >= 0, f"Backup percentage must be non-negative, got {backup_pct}"
            assert data_transfer_pct >= 0, f"Data transfer percentage must be non-negative, got {data_transfer_pct}"
            
            # Verify percentages sum to 100%
            total_pct = instance_pct + storage_pct + iops_pct + backup_pct + data_transfer_pct
            assert abs(total_pct - 100.0) < 0.01, \
                f"Percentages should sum to 100%, got {total_pct}"



class TestProperty11ROIPaybackPeriodCalculation:
    """
    Property 11: ROI Payback Period Calculation
    
    For any migration cost and annual savings where annual_savings > 0, 
    the payback period should equal migration_cost / annual_savings.
    
    Feature: db2-migration-queries
    Property 11: ROI Payback Period Calculation
    Validates: Requirements 10.8
    """
    
    @given(
        migration_cost=st.floats(min_value=0.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_payback_period_calculation(
        self,
        migration_cost: float,
        annual_savings: float
    ):
        """
        Property test: Payback period should equal migration_cost / annual_savings.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate payback period
        payback_period_years = migration_cost / annual_savings
        
        # Verify payback period is non-negative
        assert payback_period_years >= 0, \
            f"Payback period must be non-negative, got {payback_period_years}"
        
        # Verify calculation correctness
        expected_payback = migration_cost / annual_savings
        assert abs(payback_period_years - expected_payback) < 0.001, \
            f"Payback period {payback_period_years} != expected {expected_payback}"
        
        # Verify inverse relationship: annual_savings * payback_period = migration_cost
        calculated_migration_cost = annual_savings * payback_period_years
        
        if migration_cost > 1e-10:
            relative_error = abs(calculated_migration_cost - migration_cost) / migration_cost
            assert relative_error < 0.001, \
                f"Inverse calculation failed: {calculated_migration_cost} != {migration_cost}"
        else:
            assert abs(calculated_migration_cost - migration_cost) < 1e-10, \
                f"Inverse calculation failed for small values"
    
    @given(
        migration_cost=st.floats(min_value=0.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_mainframe_cost=st.floats(min_value=100_000.0, max_value=5_000_000.0, allow_nan=False, allow_infinity=False),
        annual_rds_cost=st.floats(min_value=50_000.0, max_value=4_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_payback_period_from_costs(
        self,
        migration_cost: float,
        annual_mainframe_cost: float,
        annual_rds_cost: float
    ):
        """
        Property test: Payback period calculation from mainframe and RDS costs.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate annual savings
        annual_savings = annual_mainframe_cost - annual_rds_cost
        
        # Only test when there are positive savings
        if annual_savings > 0:
            # Calculate payback period
            payback_period_years = migration_cost / annual_savings
            
            # Verify payback period is non-negative
            assert payback_period_years >= 0, \
                f"Payback period must be non-negative, got {payback_period_years}"
            
            # Verify calculation correctness
            expected_payback = migration_cost / annual_savings
            assert abs(payback_period_years - expected_payback) < 0.001, \
                f"Payback period {payback_period_years} != expected {expected_payback}"
    
    @given(
        migration_cost=st.floats(min_value=100_000.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_five_year_roi_calculation(
        self,
        migration_cost: float,
        annual_savings: float
    ):
        """
        Property test: 5-year ROI calculation correctness.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate 5-year total savings
        five_year_total_savings = (5 * annual_savings) - migration_cost
        
        # Calculate 5-year ROI
        five_year_roi = five_year_total_savings / migration_cost
        
        # Verify ROI calculation
        expected_roi = ((5 * annual_savings) - migration_cost) / migration_cost
        
        if migration_cost > 1e-10:
            relative_error = abs(five_year_roi - expected_roi) / abs(expected_roi) if expected_roi != 0 else 0
            assert relative_error < 0.001, \
                f"5-year ROI {five_year_roi} != expected {expected_roi}"
        else:
            assert abs(five_year_roi - expected_roi) < 1e-10, \
                f"5-year ROI calculation failed for small values"
    
    @given(
        migration_cost=st.floats(min_value=0.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings_1=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings_2=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_payback_period_monotonicity(
        self,
        migration_cost: float,
        annual_savings_1: float,
        annual_savings_2: float
    ):
        """
        Property test: Higher annual savings should produce shorter payback period.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate payback periods
        payback_period_1 = migration_cost / annual_savings_1
        payback_period_2 = migration_cost / annual_savings_2
        
        # Verify monotonicity: higher savings produces shorter payback
        if annual_savings_1 > annual_savings_2:
            assert payback_period_1 <= payback_period_2, \
                f"Monotonicity violated: higher savings produced longer payback"
        elif annual_savings_2 > annual_savings_1:
            assert payback_period_2 <= payback_period_1, \
                f"Monotonicity violated: higher savings produced longer payback"
        else:
            # Equal savings should produce equal payback
            assert abs(payback_period_1 - payback_period_2) < 0.001, \
                f"Equal savings should produce equal payback"
    
    @given(
        migration_cost_1=st.floats(min_value=0.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        migration_cost_2=st.floats(min_value=0.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_payback_period_cost_monotonicity(
        self,
        migration_cost_1: float,
        migration_cost_2: float,
        annual_savings: float
    ):
        """
        Property test: Higher migration cost should produce longer payback period.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate payback periods
        payback_period_1 = migration_cost_1 / annual_savings
        payback_period_2 = migration_cost_2 / annual_savings
        
        # Verify monotonicity: higher cost produces longer payback
        if migration_cost_1 > migration_cost_2:
            assert payback_period_1 >= payback_period_2, \
                f"Monotonicity violated: higher cost produced shorter payback"
        elif migration_cost_2 > migration_cost_1:
            assert payback_period_2 >= payback_period_1, \
                f"Monotonicity violated: higher cost produced shorter payback"
        else:
            # Equal cost should produce equal payback
            assert abs(payback_period_1 - payback_period_2) < 0.001, \
                f"Equal cost should produce equal payback"
    
    @given(
        migration_cost=st.floats(min_value=100_000.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_roi_linear_scaling(
        self,
        migration_cost: float,
        annual_savings: float
    ):
        """
        Property test: Doubling annual savings should halve payback period.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate payback period for original savings
        payback_period_1x = migration_cost / annual_savings
        
        # Calculate payback period for doubled savings
        payback_period_2x = migration_cost / (annual_savings * 2)
        
        # Verify linear scaling: doubling savings halves payback
        expected_2x = payback_period_1x / 2
        
        if payback_period_1x > 1e-10:
            relative_error = abs(payback_period_2x - expected_2x) / payback_period_1x
            assert relative_error < 0.001, \
                f"Linear scaling violated: 2x savings produced {payback_period_2x}, expected {expected_2x}"
        else:
            assert abs(payback_period_2x - expected_2x) < 1e-10, \
                f"Linear scaling violated for small values"
    
    @given(
        assessment_cost=st.floats(min_value=0.0, max_value=500_000.0, allow_nan=False, allow_infinity=False),
        plan_conversion_cost=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        data_migration_cost=st.floats(min_value=0.0, max_value=500_000.0, allow_nan=False, allow_infinity=False),
        testing_cost=st.floats(min_value=0.0, max_value=1_000_000.0, allow_nan=False, allow_infinity=False),
        training_cost=st.floats(min_value=0.0, max_value=500_000.0, allow_nan=False, allow_infinity=False),
        contingency_ratio=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_migration_cost_breakdown(
        self,
        assessment_cost: float,
        plan_conversion_cost: float,
        data_migration_cost: float,
        testing_cost: float,
        training_cost: float,
        contingency_ratio: float
    ):
        """
        Property test: Total migration cost should equal sum of components plus contingency.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate migration subtotal
        migration_subtotal = (assessment_cost + plan_conversion_cost + data_migration_cost + 
                             testing_cost + training_cost)
        
        # Calculate contingency cost
        contingency_cost = migration_subtotal * contingency_ratio
        
        # Calculate total migration cost
        total_migration_cost = migration_subtotal + contingency_cost
        
        # Verify all components are non-negative
        assert assessment_cost >= 0, f"Assessment cost must be non-negative"
        assert plan_conversion_cost >= 0, f"Plan conversion cost must be non-negative"
        assert data_migration_cost >= 0, f"Data migration cost must be non-negative"
        assert testing_cost >= 0, f"Testing cost must be non-negative"
        assert training_cost >= 0, f"Training cost must be non-negative"
        assert contingency_cost >= 0, f"Contingency cost must be non-negative"
        assert total_migration_cost >= 0, f"Total migration cost must be non-negative"
        
        # Verify total equals sum of components
        expected_total = migration_subtotal * (1 + contingency_ratio)
        
        if total_migration_cost > 1e-10:
            relative_error = abs(total_migration_cost - expected_total) / total_migration_cost
            assert relative_error < 0.001, \
                f"Total migration cost {total_migration_cost} != expected {expected_total}"
        else:
            assert abs(total_migration_cost - expected_total) < 1e-10, \
                f"Total migration cost calculation failed for small values"
    
    @given(
        migration_cost=st.floats(min_value=100_000.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False),
        years=st.integers(min_value=1, max_value=10)
    )
    @settings(max_examples=100)
    def test_property_11_multi_year_roi_calculation(
        self,
        migration_cost: float,
        annual_savings: float,
        years: int
    ):
        """
        Property test: Multi-year ROI calculation correctness.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate multi-year total savings
        multi_year_total_savings = (years * annual_savings) - migration_cost
        
        # Calculate multi-year ROI
        multi_year_roi = multi_year_total_savings / migration_cost
        
        # Verify ROI calculation
        expected_roi = ((years * annual_savings) - migration_cost) / migration_cost
        
        if migration_cost > 1e-10:
            relative_error = abs(multi_year_roi - expected_roi) / abs(expected_roi) if expected_roi != 0 else 0
            assert relative_error < 0.001, \
                f"{years}-year ROI {multi_year_roi} != expected {expected_roi}"
        else:
            assert abs(multi_year_roi - expected_roi) < 1e-10, \
                f"{years}-year ROI calculation failed for small values"
    
    @given(
        migration_cost=st.floats(min_value=100_000.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_savings=st.floats(min_value=0.01, max_value=5_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_roi_percentage_calculation(
        self,
        migration_cost: float,
        annual_savings: float
    ):
        """
        Property test: ROI percentage should be consistent with ROI ratio.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate 5-year ROI ratio
        five_year_roi_ratio = ((5 * annual_savings) - migration_cost) / migration_cost
        
        # Calculate 5-year ROI percentage
        five_year_roi_percentage = five_year_roi_ratio * 100
        
        # Verify percentage is 100x the ratio
        expected_percentage = five_year_roi_ratio * 100
        
        if abs(five_year_roi_percentage) > 1e-10:
            relative_error = abs(five_year_roi_percentage - expected_percentage) / abs(five_year_roi_percentage)
            assert relative_error < 0.001, \
                f"ROI percentage {five_year_roi_percentage} != expected {expected_percentage}"
        else:
            assert abs(five_year_roi_percentage - expected_percentage) < 1e-10, \
                f"ROI percentage calculation failed for small values"
    
    @given(
        migration_cost=st.floats(min_value=0.0, max_value=10_000_000.0, allow_nan=False, allow_infinity=False),
        annual_mainframe_cost=st.floats(min_value=100_000.0, max_value=5_000_000.0, allow_nan=False, allow_infinity=False),
        annual_rds_cost=st.floats(min_value=50_000.0, max_value=4_000_000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_11_savings_percentage_calculation(
        self,
        migration_cost: float,
        annual_mainframe_cost: float,
        annual_rds_cost: float
    ):
        """
        Property test: Savings percentage calculation correctness.
        
        Feature: db2-migration-queries
        Property 11: ROI Payback Period Calculation
        """
        # Calculate annual savings
        annual_savings = annual_mainframe_cost - annual_rds_cost
        
        # Calculate savings percentage
        if annual_mainframe_cost > 0:
            savings_percentage = (annual_savings / annual_mainframe_cost) * 100
            
            # Verify calculation correctness
            expected_percentage = (annual_savings / annual_mainframe_cost) * 100
            
            if abs(savings_percentage) > 1e-10:
                relative_error = abs(savings_percentage - expected_percentage) / abs(savings_percentage)
                assert relative_error < 0.001, \
                    f"Savings percentage {savings_percentage} != expected {expected_percentage}"
            else:
                assert abs(savings_percentage - expected_percentage) < 1e-10, \
                    f"Savings percentage calculation failed for small values"
            
            # Verify positive savings means RDS is cheaper
            if annual_savings > 0:
                assert annual_rds_cost < annual_mainframe_cost, \
                    f"Positive savings should mean RDS is cheaper"
            # Verify negative savings means RDS is more expensive
            elif annual_savings < 0:
                assert annual_rds_cost > annual_mainframe_cost, \
                    f"Negative savings should mean RDS is more expensive"
