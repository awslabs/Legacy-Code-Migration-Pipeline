"""Unit tests for SMF Type 4 parser."""

import pytest
import struct
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF4ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type4_record_minimal() -> bytes:
    """Create a minimal valid Type 4 record (260 bytes)."""
    record = bytearray(260)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 260)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 4)  # Record type = 4
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Job identification
    job_name = "TESTJOB ".encode('cp037')
    record[18:26] = job_name
    struct.pack_into('>I', record, 26, 18000)  # Reader start time
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader start date
    
    user_id = "USER1   ".encode('cp037')
    record[34:42] = user_id
    
    # Step identification
    struct.pack_into('B', record, 42, 1)  # Step number
    struct.pack_into('>I', record, 43, 19000)  # Step init time
    record[47:51] = bytes([0x01, 0x25, 0x00, 0x1F])  # Step init date
    struct.pack_into('>I', record, 51, 100)  # Card image count
    struct.pack_into('>H', record, 55, 0)  # Completion code (normal)
    struct.pack_into('B', record, 57, 10)  # Dispatching priority
    
    program_name = "TESTPGM ".encode('cp037')
    record[58:66] = program_name
    
    step_name = "STEP1   ".encode('cp037')
    record[66:74] = step_name
    
    # Performance fields
    struct.pack_into('>H', record, 76, 1024)  # Storage top (1MB)
    struct.pack_into('>H', record, 78, 2048)  # Storage bottom (2MB)
    struct.pack_into('>I', record, 82, 8192)  # Region size (8MB)
    struct.pack_into('B', record, 86, 8)  # Storage protect key
    struct.pack_into('B', record, 87, 0)  # Step termination indicator (normal)
    struct.pack_into('>I', record, 90, 17000)  # Device allocation start time
    struct.pack_into('>I', record, 94, 18000)  # Problem program start time
    
    # SRB CPU time (3 bytes)
    srb_time = 100
    record[99] = (srb_time >> 16) & 0xFF
    record[100] = (srb_time >> 8) & 0xFF
    record[101] = srb_time & 0xFF
    
    # Record indicators
    struct.pack_into('>H', record, 102, 0)  # No special indicators
    
    # Relocate offset and device length
    struct.pack_into('>H', record, 104, 0)  # No relocate section
    struct.pack_into('>H', record, 106, 2)  # No device data
    
    return bytes(record)


def create_type4_record_with_abend() -> bytes:
    """Create a Type 4 record with ABEND."""
    record = bytearray(create_type4_record_minimal())
    
    # Set completion code to system ABEND 0C4
    struct.pack_into('>H', record, 55, 0x00C4)
    
    # Set ABEND bit in step termination indicator
    record[87] = 0x02  # Bit 6 = ABEND
    
    return bytes(record)


def create_type4_record_flushed() -> bytes:
    """Create a Type 4 record for a flushed step."""
    record = bytearray(create_type4_record_minimal())
    
    # Set completion code to 0 (flushed)
    struct.pack_into('>H', record, 55, 0)
    
    # Set flushed bit in step termination indicator
    record[87] = 0x01  # Bit 7 = flushed
    
    return bytes(record)


class TestSMF4ParserV3R2:
    """Unit tests for SMF Type 4 parser."""
    
    def test_parser_initialization(self):
        """Test that parser can be initialized."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        assert parser is not None
        assert parser.parser == base_parser
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal Type 4 record."""
        record_data = create_type4_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard fields
        assert parsed.record_type == 4
        assert parsed.subtype == 0  # Type 4 has no subtypes
        assert parsed.record_length == 260
        assert parsed.system_id == "SYS1"
        
        # Verify identification section
        assert parsed.identification is not None
        ident = parsed.identification
        assert ident['job_name'] == "TESTJOB"
        assert ident['step_name'] == "STEP1"
        assert ident['program_name'] == "TESTPGM"
        assert ident['step_number'] == 1
        assert ident['step_completion_code'] == 0
        assert ident['user_id'] == "USER1"
        
        # Verify performance section
        assert parsed.performance is not None
        perf = parsed.performance
        assert perf['storage_top'] == 1024
        assert perf['storage_bottom'] == 2048
        assert perf['region_size'] == 8192
        assert perf['storage_protect_key'] == 8
        assert perf['srb_cpu_time'] == 100
        assert perf['abend'] == False
        assert perf['flushed'] == False
    
    def test_parse_abend_record(self):
        """Test parsing a Type 4 record with ABEND."""
        record_data = create_type4_record_with_abend()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify ABEND indicators
        assert parsed.identification['step_completion_code'] == 0x00C4
        assert parsed.performance['abend'] == True
        assert parsed.performance['flushed'] == False
    
    def test_parse_flushed_record(self):
        """Test parsing a Type 4 record for a flushed step."""
        record_data = create_type4_record_flushed()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify flushed indicators
        assert parsed.identification['step_completion_code'] == 0
        assert parsed.performance['abend'] == False
        assert parsed.performance['flushed'] == True
    
    def test_parse_step_termination_flags(self):
        """Test parsing of step termination indicator flags."""
        record_data = bytearray(create_type4_record_minimal())
        
        # Set various termination flags
        record_data[87] = 0x40 | 0x20 | 0x04  # Canceled by IEFUJV, IEFUJI, and to be restarted
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(bytes(record_data))
        
        perf = parsed.performance
        assert perf['canceled_by_iefujv'] == True
        assert perf['canceled_by_iefuji'] == True
        assert perf['canceled_by_iefusi'] == False
        assert perf['canceled_by_iefactrt'] == False
        assert perf['step_to_be_restarted'] == True
        assert perf['abend'] == False
        assert perf['flushed'] == False
    
    def test_parse_record_indicators(self):
        """Test parsing of record indicator flags."""
        record_data = bytearray(create_type4_record_minimal())
        
        # Set record indicator flags
        struct.pack_into('>H', record_data, 102, 0x0800 | 0x0400 | 0x0200)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(bytes(record_data))
        
        perf = parsed.performance
        assert perf['cpu_time_overflow'] == True
        assert perf['device_data_not_recorded'] == True
        assert perf['excp_count_might_be_wrong'] == True
        assert perf['storage_is_central'] == False
    
    def test_parse_invalid_record_type(self):
        """Test that parser rejects records with wrong type."""
        record_data = bytearray(create_type4_record_minimal())
        record_data[5] = 30  # Change to Type 30
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(record_data))
    
    def test_parse_invalid_record_length(self):
        """Test that parser rejects records with invalid length."""
        record_data = bytearray(10)  # Too short
        struct.pack_into('>H', record_data, 0, 10)
        struct.pack_into('B', record_data, 5, 4)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(record_data))
    
    def test_parse_no_device_data(self):
        """Test parsing record with no device data."""
        record_data = create_type4_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Device data should be None when device_length <= 2
        assert parsed.excp_sections is None
    
    def test_parse_no_relocate_section(self):
        """Test parsing record with no relocate section."""
        record_data = create_type4_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Relocate section should be None when offset is 0
        assert parsed.storage is None
    
    def test_parse_to_dict(self):
        """Test converting parsed record to dictionary."""
        record_data = create_type4_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Convert to dict
        record_dict = parsed.to_dict()
        
        assert isinstance(record_dict, dict)
        assert record_dict['record_type'] == 4
        assert record_dict['subtype'] == 0
        assert 'identification' in record_dict
        assert 'performance' in record_dict
    
    def test_parse_to_json(self):
        """Test converting parsed record to JSON."""
        record_data = create_type4_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Convert to JSON
        json_str = parsed.to_json()
        
        assert isinstance(json_str, str)
        assert '"record_type": 4' in json_str
        assert '"job_name"' in json_str
        assert '"step_name"' in json_str
