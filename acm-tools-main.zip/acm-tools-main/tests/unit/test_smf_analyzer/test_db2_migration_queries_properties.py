"""Property-based tests for DB2 migration planning queries.

This module contains property-based tests for DB2 migration planning queries
to validate correctness properties across all valid inputs.

Properties tested:
- Property 10: Cost Calculation Non-Negativity (for DB2MigrationEffortQuery)
- Property 12: Priority Score Weighted Sum
- Property 13: Complexity Category Threshold Consistency
"""

import pytest
from hypothesis import given, strategies as st, settings, assume
from typing import List


class TestProperty12PriorityScoreWeightedSum:
    """
    Property 12: Priority Score Weighted Sum
    
    For any plan with calculated priority factors, the total priority score should equal 
    the weighted sum of individual factor scores using the configured weights.
    
    Feature: db2-migration-queries
    Property 12: Priority Score Weighted Sum
    Validates: Requirements 9.6
    """
    
    @given(
        volume_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        cpu_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        simplicity_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        no_ddf_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        performance_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        volume_weight=st.integers(min_value=0, max_value=100),
        cpu_weight=st.integers(min_value=0, max_value=100),
        simplicity_weight=st.integers(min_value=0, max_value=100),
        no_ddf_weight=st.integers(min_value=0, max_value=100),
        performance_weight=st.integers(min_value=0, max_value=100)
    )
    @settings(max_examples=100)
    def test_property_12_priority_score_weighted_sum(
        self,
        volume_score: float,
        cpu_score: float,
        simplicity_score: float,
        no_ddf_score: float,
        performance_score: float,
        volume_weight: int,
        cpu_weight: int,
        simplicity_weight: int,
        no_ddf_weight: int,
        performance_weight: int
    ):
        """
        Property test: Priority score should equal weighted sum of factor scores.
        
        Feature: db2-migration-queries
        Property 12: Priority Score Weighted Sum
        Validates: Requirements 9.6
        """
        # Calculate expected priority score using weighted sum
        expected_priority_score = (
            (volume_score * volume_weight / 100.0) +
            (cpu_score * cpu_weight / 100.0) +
            (simplicity_score * simplicity_weight / 100.0) +
            (no_ddf_score * no_ddf_weight / 100.0) +
            (performance_score * performance_weight / 100.0)
        )
        
        # Verify the priority score is non-negative
        assert expected_priority_score >= 0, \
            f"Priority score must be non-negative, got {expected_priority_score}"
        
        # Verify the priority score is within valid range
        # Maximum possible score is when all factors are 100 and all weights sum to 100
        max_possible_score = (
            (100.0 * volume_weight / 100.0) +
            (100.0 * cpu_weight / 100.0) +
            (100.0 * simplicity_weight / 100.0) +
            (100.0 * no_ddf_weight / 100.0) +
            (100.0 * performance_weight / 100.0)
        )
        
        assert expected_priority_score <= max_possible_score, \
            f"Priority score {expected_priority_score} exceeds maximum {max_possible_score}"
    
    @given(
        volume_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        cpu_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        simplicity_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        no_ddf_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        performance_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_12_default_weights_sum_to_100(
        self,
        volume_score: float,
        cpu_score: float,
        simplicity_score: float,
        no_ddf_score: float,
        performance_score: float
    ):
        """
        Property test: With default weights (30, 25, 20, 15, 10), priority score should be 
        between 0 and 100 when all factor scores are between 0 and 100.
        
        Feature: db2-migration-queries
        Property 12: Priority Score Weighted Sum
        Validates: Requirements 9.6
        """
        # Default weights from design document
        volume_weight = 30
        cpu_weight = 25
        simplicity_weight = 20
        no_ddf_weight = 15
        performance_weight = 10
        
        # Verify weights sum to 100
        total_weight = volume_weight + cpu_weight + simplicity_weight + no_ddf_weight + performance_weight
        assert total_weight == 100, f"Default weights should sum to 100, got {total_weight}"
        
        # Calculate priority score
        priority_score = (
            (volume_score * volume_weight / 100.0) +
            (cpu_score * cpu_weight / 100.0) +
            (simplicity_score * simplicity_weight / 100.0) +
            (no_ddf_score * no_ddf_weight / 100.0) +
            (performance_score * performance_weight / 100.0)
        )
        
        # With weights summing to 100, priority score should be between 0 and 100
        assert 0 <= priority_score <= 100, \
            f"Priority score should be between 0 and 100, got {priority_score}"
    
    @given(
        volume_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        cpu_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        simplicity_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        no_ddf_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        performance_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        weight_multiplier=st.floats(min_value=0.1, max_value=10.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_12_priority_score_scales_linearly_with_weights(
        self,
        volume_score: float,
        cpu_score: float,
        simplicity_score: float,
        no_ddf_score: float,
        performance_score: float,
        weight_multiplier: float
    ):
        """
        Property test: Priority score should scale linearly when all weights are multiplied 
        by the same factor.
        
        Feature: db2-migration-queries
        Property 12: Priority Score Weighted Sum
        Validates: Requirements 9.6
        """
        # Default weights
        volume_weight = 30
        cpu_weight = 25
        simplicity_weight = 20
        no_ddf_weight = 15
        performance_weight = 10
        
        # Calculate priority score with default weights
        priority_score_1 = (
            (volume_score * volume_weight / 100.0) +
            (cpu_score * cpu_weight / 100.0) +
            (simplicity_score * simplicity_weight / 100.0) +
            (no_ddf_score * no_ddf_weight / 100.0) +
            (performance_score * performance_weight / 100.0)
        )
        
        # Calculate priority score with scaled weights
        priority_score_2 = (
            (volume_score * (volume_weight * weight_multiplier) / 100.0) +
            (cpu_score * (cpu_weight * weight_multiplier) / 100.0) +
            (simplicity_score * (simplicity_weight * weight_multiplier) / 100.0) +
            (no_ddf_score * (no_ddf_weight * weight_multiplier) / 100.0) +
            (performance_score * (performance_weight * weight_multiplier) / 100.0)
        )
        
        # Verify linear scaling
        expected_score_2 = priority_score_1 * weight_multiplier
        
        # Allow small floating-point error
        tolerance = 0.01
        assert abs(priority_score_2 - expected_score_2) < tolerance, \
            f"Priority score should scale linearly: expected {expected_score_2}, got {priority_score_2}"
    
    @given(
        volume_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        cpu_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        simplicity_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        no_ddf_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        performance_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_12_zero_weights_produce_zero_score(
        self,
        volume_score: float,
        cpu_score: float,
        simplicity_score: float,
        no_ddf_score: float,
        performance_score: float
    ):
        """
        Property test: When all weights are zero, priority score should be zero.
        
        Feature: db2-migration-queries
        Property 12: Priority Score Weighted Sum
        Validates: Requirements 9.6
        """
        # All weights set to zero
        volume_weight = 0
        cpu_weight = 0
        simplicity_weight = 0
        no_ddf_weight = 0
        performance_weight = 0
        
        # Calculate priority score
        priority_score = (
            (volume_score * volume_weight / 100.0) +
            (cpu_score * cpu_weight / 100.0) +
            (simplicity_score * simplicity_weight / 100.0) +
            (no_ddf_score * no_ddf_weight / 100.0) +
            (performance_score * performance_weight / 100.0)
        )
        
        # Verify priority score is zero
        assert priority_score == 0.0, \
            f"Priority score should be zero when all weights are zero, got {priority_score}"
    
    @given(
        volume_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        cpu_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        simplicity_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        no_ddf_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        performance_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
        single_weight=st.integers(min_value=1, max_value=100)
    )
    @settings(max_examples=100)
    def test_property_12_single_factor_dominance(
        self,
        volume_score: float,
        cpu_score: float,
        simplicity_score: float,
        no_ddf_score: float,
        performance_score: float,
        single_weight: int
    ):
        """
        Property test: When only one weight is non-zero, priority score should equal 
        that factor's score multiplied by its weight percentage.
        
        Feature: db2-migration-queries
        Property 12: Priority Score Weighted Sum
        Validates: Requirements 9.6
        """
        # Test with only volume weight non-zero
        priority_score_volume = (volume_score * single_weight / 100.0)
        
        calculated_score = (
            (volume_score * single_weight / 100.0) +
            (cpu_score * 0 / 100.0) +
            (simplicity_score * 0 / 100.0) +
            (no_ddf_score * 0 / 100.0) +
            (performance_score * 0 / 100.0)
        )
        
        # Allow small floating-point error
        tolerance = 0.01
        assert abs(calculated_score - priority_score_volume) < tolerance, \
            f"Priority score should equal volume factor: expected {priority_score_volume}, got {calculated_score}"



class TestProperty13ComplexityCategoryThresholdConsistency:
    """
    Property 13: Complexity Category Threshold Consistency
    
    For any complexity score, the assigned category (Low, Medium, High, Very High) should be 
    consistent with the configured threshold boundaries and categories should not overlap.
    
    Feature: db2-migration-queries
    Property 13: Complexity Category Threshold Consistency
    Validates: Requirements 9.7
    """
    
    @given(
        complexity_score=st.floats(min_value=0.0, max_value=1000.0, allow_nan=False, allow_infinity=False),
        threshold_low=st.integers(min_value=1, max_value=100),
        threshold_medium=st.integers(min_value=101, max_value=200),
        threshold_high=st.integers(min_value=201, max_value=500)
    )
    @settings(max_examples=100)
    def test_property_13_category_assignment_consistency(
        self,
        complexity_score: float,
        threshold_low: int,
        threshold_medium: int,
        threshold_high: int
    ):
        """
        Property test: Complexity category should be assigned consistently based on thresholds.
        
        Feature: db2-migration-queries
        Property 13: Complexity Category Threshold Consistency
        Validates: Requirements 9.7
        """
        # Determine expected category based on thresholds
        if complexity_score < threshold_low:
            expected_category = 'Low'
        elif complexity_score < threshold_medium:
            expected_category = 'Medium'
        elif complexity_score < threshold_high:
            expected_category = 'High'
        else:
            expected_category = 'Very High'
        
        # Verify category assignment is deterministic
        # Re-calculate to ensure consistency
        if complexity_score < threshold_low:
            recalculated_category = 'Low'
        elif complexity_score < threshold_medium:
            recalculated_category = 'Medium'
        elif complexity_score < threshold_high:
            recalculated_category = 'High'
        else:
            recalculated_category = 'Very High'
        
        assert expected_category == recalculated_category, \
            f"Category assignment should be deterministic: {expected_category} != {recalculated_category}"
    
    @given(
        threshold_low=st.integers(min_value=1, max_value=100),
        threshold_medium=st.integers(min_value=101, max_value=200),
        threshold_high=st.integers(min_value=201, max_value=500)
    )
    @settings(max_examples=100)
    def test_property_13_threshold_boundaries_non_overlapping(
        self,
        threshold_low: int,
        threshold_medium: int,
        threshold_high: int
    ):
        """
        Property test: Threshold boundaries should not overlap and should be strictly ordered.
        
        Feature: db2-migration-queries
        Property 13: Complexity Category Threshold Consistency
        Validates: Requirements 9.7
        """
        # Verify thresholds are strictly ordered
        assert threshold_low < threshold_medium, \
            f"Low threshold {threshold_low} must be less than medium threshold {threshold_medium}"
        assert threshold_medium < threshold_high, \
            f"Medium threshold {threshold_medium} must be less than high threshold {threshold_high}"
        
        # Verify no overlap: a score cannot belong to multiple categories
        # Test boundary values
        score_at_low = float(threshold_low)
        score_at_medium = float(threshold_medium)
        score_at_high = float(threshold_high)
        
        # Score exactly at threshold_low should be in Medium category (not Low)
        if score_at_low < threshold_low:
            category_at_low = 'Low'
        elif score_at_low < threshold_medium:
            category_at_low = 'Medium'
        elif score_at_low < threshold_high:
            category_at_low = 'High'
        else:
            category_at_low = 'Very High'
        
        # Score exactly at threshold_medium should be in High category (not Medium)
        if score_at_medium < threshold_low:
            category_at_medium = 'Low'
        elif score_at_medium < threshold_medium:
            category_at_medium = 'Medium'
        elif score_at_medium < threshold_high:
            category_at_medium = 'High'
        else:
            category_at_medium = 'Very High'
        
        # Score exactly at threshold_high should be in Very High category (not High)
        if score_at_high < threshold_low:
            category_at_high = 'Low'
        elif score_at_high < threshold_medium:
            category_at_high = 'Medium'
        elif score_at_high < threshold_high:
            category_at_high = 'High'
        else:
            category_at_high = 'Very High'
        
        # Verify categories are different at boundaries
        assert category_at_low != category_at_medium or threshold_low == threshold_medium, \
            f"Categories at boundaries should differ: {category_at_low} vs {category_at_medium}"
    
    @given(
        complexity_score=st.floats(min_value=0.0, max_value=1000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_13_default_thresholds_produce_valid_categories(
        self,
        complexity_score: float
    ):
        """
        Property test: Default thresholds (60, 120, 240) should produce valid categories.
        
        Feature: db2-migration-queries
        Property 13: Complexity Category Threshold Consistency
        Validates: Requirements 9.7
        """
        # Default thresholds from design document
        threshold_low = 60
        threshold_medium = 120
        threshold_high = 240
        
        # Determine category
        if complexity_score < threshold_low:
            category = 'Low'
        elif complexity_score < threshold_medium:
            category = 'Medium'
        elif complexity_score < threshold_high:
            category = 'High'
        else:
            category = 'Very High'
        
        # Verify category is one of the valid values
        valid_categories = ['Low', 'Medium', 'High', 'Very High']
        assert category in valid_categories, \
            f"Category {category} must be one of {valid_categories}"
    
    @given(
        threshold_low=st.integers(min_value=1, max_value=100),
        threshold_medium=st.integers(min_value=101, max_value=200),
        threshold_high=st.integers(min_value=201, max_value=500)
    )
    @settings(max_examples=100)
    def test_property_13_all_scores_assigned_to_exactly_one_category(
        self,
        threshold_low: int,
        threshold_medium: int,
        threshold_high: int
    ):
        """
        Property test: Every complexity score should be assigned to exactly one category.
        
        Feature: db2-migration-queries
        Property 13: Complexity Category Threshold Consistency
        Validates: Requirements 9.7
        """
        # Test a range of scores
        test_scores = [0.0, float(threshold_low - 1), float(threshold_low), 
                      float(threshold_medium - 1), float(threshold_medium),
                      float(threshold_high - 1), float(threshold_high), 
                      float(threshold_high + 100)]
        
        for score in test_scores:
            # Count how many categories this score belongs to
            categories_matched = 0
            
            if score < threshold_low:
                categories_matched += 1
            if threshold_low <= score < threshold_medium:
                categories_matched += 1
            if threshold_medium <= score < threshold_high:
                categories_matched += 1
            if score >= threshold_high:
                categories_matched += 1
            
            # Each score should match exactly one category
            assert categories_matched == 1, \
                f"Score {score} matched {categories_matched} categories (should be exactly 1)"
    
    @given(
        complexity_score=st.floats(min_value=0.0, max_value=1000.0, allow_nan=False, allow_infinity=False),
        threshold_low=st.integers(min_value=1, max_value=100),
        threshold_medium=st.integers(min_value=101, max_value=200),
        threshold_high=st.integers(min_value=201, max_value=500)
    )
    @settings(max_examples=100)
    def test_property_13_category_monotonicity(
        self,
        complexity_score: float,
        threshold_low: int,
        threshold_medium: int,
        threshold_high: int
    ):
        """
        Property test: As complexity score increases, category should never decrease in severity.
        
        Feature: db2-migration-queries
        Property 13: Complexity Category Threshold Consistency
        Validates: Requirements 9.7
        """
        # Define category severity order
        category_order = {'Low': 0, 'Medium': 1, 'High': 2, 'Very High': 3}
        
        # Get category for current score
        if complexity_score < threshold_low:
            category1 = 'Low'
        elif complexity_score < threshold_medium:
            category1 = 'Medium'
        elif complexity_score < threshold_high:
            category1 = 'High'
        else:
            category1 = 'Very High'
        
        # Get category for slightly higher score
        higher_score = complexity_score + 10.0
        if higher_score < threshold_low:
            category2 = 'Low'
        elif higher_score < threshold_medium:
            category2 = 'Medium'
        elif higher_score < threshold_high:
            category2 = 'High'
        else:
            category2 = 'Very High'
        
        # Verify category severity is non-decreasing
        assert category_order[category2] >= category_order[category1], \
            f"Category should not decrease: {category1} (score {complexity_score}) -> {category2} (score {higher_score})"
    
    @given(
        base_effort=st.integers(min_value=1, max_value=500),
        volume_mult=st.floats(min_value=1.0, max_value=3.0, allow_nan=False, allow_infinity=False),
        sql_mult=st.floats(min_value=1.0, max_value=3.0, allow_nan=False, allow_infinity=False),
        ddf_mult=st.floats(min_value=1.0, max_value=3.0, allow_nan=False, allow_infinity=False),
        contention_mult=st.floats(min_value=1.0, max_value=3.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_13_complexity_score_calculation_non_negative(
        self,
        base_effort: int,
        volume_mult: float,
        sql_mult: float,
        ddf_mult: float,
        contention_mult: float
    ):
        """
        Property test: Complexity score calculation should always produce non-negative values.
        
        Feature: db2-migration-queries
        Property 13: Complexity Category Threshold Consistency
        Validates: Requirements 9.7
        """
        # Calculate complexity score
        complexity_score = base_effort * volume_mult * sql_mult * ddf_mult * contention_mult
        
        # Verify score is non-negative
        assert complexity_score >= 0, \
            f"Complexity score must be non-negative, got {complexity_score}"
        
        # Verify score is at least the base effort (since all multipliers >= 1.0)
        assert complexity_score >= base_effort, \
            f"Complexity score {complexity_score} should be at least base effort {base_effort}"
    
    @given(
        threshold_low=st.integers(min_value=10, max_value=100),
        threshold_medium=st.integers(min_value=101, max_value=200),
        threshold_high=st.integers(min_value=201, max_value=500)
    )
    @settings(max_examples=100)
    def test_property_13_base_effort_below_low_threshold_is_low_complexity(
        self,
        threshold_low: int,
        threshold_medium: int,
        threshold_high: int
    ):
        """
        Property test: When base effort (with no multipliers) is below low threshold, 
        category should be Low.
        
        Feature: db2-migration-queries
        Property 13: Complexity Category Threshold Consistency
        Validates: Requirements 9.7
        """
        # Generate base effort that is guaranteed to be below threshold_low
        # Use a value between 1 and threshold_low - 1
        base_effort = threshold_low - 1 if threshold_low > 1 else 1
        
        # With all multipliers at 1.0, complexity score equals base effort
        complexity_score = float(base_effort)
        
        # Determine category
        if complexity_score < threshold_low:
            category = 'Low'
        elif complexity_score < threshold_medium:
            category = 'Medium'
        elif complexity_score < threshold_high:
            category = 'High'
        else:
            category = 'Very High'
        
        # Verify category is Low
        assert category == 'Low', \
            f"Base effort {base_effort} below threshold {threshold_low} should be Low, got {category}"


class TestProperty10EffortCalculationNonNegativity:
    """
    Property 10: Cost Calculation Non-Negativity (for DB2MigrationEffortQuery)
    
    For any valid input parameters, all effort calculations (development hours, testing hours,
    documentation hours, project management hours, total effort) should produce non-negative values.
    
    Feature: db2-migration-queries
    Property 10: Cost Calculation Non-Negativity
    Validates: Requirements 9.8
    """
    
    @given(
        development_hours=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        testing_mult=st.floats(min_value=0.5, max_value=3.0, allow_nan=False, allow_infinity=False),
        documentation_mult=st.floats(min_value=0.1, max_value=1.0, allow_nan=False, allow_infinity=False),
        project_mgmt_mult=st.floats(min_value=0.05, max_value=0.5, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_effort_components_non_negative(
        self,
        development_hours: float,
        testing_mult: float,
        documentation_mult: float,
        project_mgmt_mult: float
    ):
        """
        Property test: All effort components should be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Calculate effort components
        testing_hours = development_hours * testing_mult
        documentation_hours = development_hours * documentation_mult
        subtotal_hours = development_hours + testing_hours + documentation_hours
        project_management_hours = subtotal_hours * project_mgmt_mult
        total_effort_hours = subtotal_hours + project_management_hours
        
        # Verify all components are non-negative
        assert development_hours >= 0, \
            f"Development hours must be non-negative, got {development_hours}"
        assert testing_hours >= 0, \
            f"Testing hours must be non-negative, got {testing_hours}"
        assert documentation_hours >= 0, \
            f"Documentation hours must be non-negative, got {documentation_hours}"
        assert project_management_hours >= 0, \
            f"Project management hours must be non-negative, got {project_management_hours}"
        assert total_effort_hours >= 0, \
            f"Total effort hours must be non-negative, got {total_effort_hours}"
    
    @given(
        development_hours=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        testing_mult=st.floats(min_value=0.5, max_value=3.0, allow_nan=False, allow_infinity=False),
        documentation_mult=st.floats(min_value=0.1, max_value=1.0, allow_nan=False, allow_infinity=False),
        project_mgmt_mult=st.floats(min_value=0.05, max_value=0.5, allow_nan=False, allow_infinity=False),
        hours_per_month=st.integers(min_value=100, max_value=200)
    )
    @settings(max_examples=100)
    def test_property_10_person_months_non_negative(
        self,
        development_hours: float,
        testing_mult: float,
        documentation_mult: float,
        project_mgmt_mult: float,
        hours_per_month: int
    ):
        """
        Property test: Person-months calculation should be non-negative.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Calculate total effort hours
        testing_hours = development_hours * testing_mult
        documentation_hours = development_hours * documentation_mult
        subtotal_hours = development_hours + testing_hours + documentation_hours
        project_management_hours = subtotal_hours * project_mgmt_mult
        total_effort_hours = subtotal_hours + project_management_hours
        
        # Convert to person-months
        person_months = total_effort_hours / hours_per_month
        
        # Verify person-months is non-negative
        assert person_months >= 0, \
            f"Person-months must be non-negative, got {person_months}"
    
    @given(
        development_hours=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        testing_mult=st.floats(min_value=0.5, max_value=3.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_testing_hours_proportional_to_development(
        self,
        development_hours: float,
        testing_mult: float
    ):
        """
        Property test: Testing hours should be proportional to development hours.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Calculate testing hours
        testing_hours = development_hours * testing_mult
        
        # Verify proportionality
        # Use a minimum threshold to avoid floating-point precision issues with very small numbers
        if development_hours > 1e-10:
            ratio = testing_hours / development_hours
            tolerance = 0.01
            assert abs(ratio - testing_mult) < tolerance, \
                f"Testing hours ratio should equal multiplier: expected {testing_mult}, got {ratio}"
        else:
            # For very small or zero development hours, just verify testing hours is non-negative
            assert testing_hours >= 0, \
                f"Testing hours should be non-negative, got {testing_hours}"
    
    @given(
        development_hours=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        testing_mult=st.floats(min_value=0.5, max_value=3.0, allow_nan=False, allow_infinity=False),
        documentation_mult=st.floats(min_value=0.1, max_value=1.0, allow_nan=False, allow_infinity=False),
        project_mgmt_mult=st.floats(min_value=0.05, max_value=0.5, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_total_effort_exceeds_development(
        self,
        development_hours: float,
        testing_mult: float,
        documentation_mult: float,
        project_mgmt_mult: float
    ):
        """
        Property test: Total effort should be greater than or equal to development hours
        (since testing, documentation, and PM are additive).
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Calculate total effort
        testing_hours = development_hours * testing_mult
        documentation_hours = development_hours * documentation_mult
        subtotal_hours = development_hours + testing_hours + documentation_hours
        project_management_hours = subtotal_hours * project_mgmt_mult
        total_effort_hours = subtotal_hours + project_management_hours
        
        # Verify total effort is at least development hours
        assert total_effort_hours >= development_hours, \
            f"Total effort {total_effort_hours} should be >= development hours {development_hours}"
    
    @given(
        plan_count=st.integers(min_value=0, max_value=1000),
        avg_complexity_hours=st.floats(min_value=0.0, max_value=500.0, allow_nan=False, allow_infinity=False),
        testing_mult=st.floats(min_value=0.5, max_value=3.0, allow_nan=False, allow_infinity=False),
        documentation_mult=st.floats(min_value=0.1, max_value=1.0, allow_nan=False, allow_infinity=False),
        project_mgmt_mult=st.floats(min_value=0.05, max_value=0.5, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_effort_scales_with_plan_count(
        self,
        plan_count: int,
        avg_complexity_hours: float,
        testing_mult: float,
        documentation_mult: float,
        project_mgmt_mult: float
    ):
        """
        Property test: Total effort should scale linearly with the number of plans.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Calculate effort for given plan count
        development_hours = plan_count * avg_complexity_hours
        testing_hours = development_hours * testing_mult
        documentation_hours = development_hours * documentation_mult
        subtotal_hours = development_hours + testing_hours + documentation_hours
        project_management_hours = subtotal_hours * project_mgmt_mult
        total_effort_1 = subtotal_hours + project_management_hours
        
        # Calculate effort for double the plan count
        development_hours_2 = (plan_count * 2) * avg_complexity_hours
        testing_hours_2 = development_hours_2 * testing_mult
        documentation_hours_2 = development_hours_2 * documentation_mult
        subtotal_hours_2 = development_hours_2 + testing_hours_2 + documentation_hours_2
        project_management_hours_2 = subtotal_hours_2 * project_mgmt_mult
        total_effort_2 = subtotal_hours_2 + project_management_hours_2
        
        # Verify linear scaling
        if plan_count > 0:
            tolerance = 0.01
            expected_effort_2 = total_effort_1 * 2
            assert abs(total_effort_2 - expected_effort_2) < tolerance, \
                f"Effort should scale linearly: expected {expected_effort_2}, got {total_effort_2}"
    
    @given(
        development_hours=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_default_multipliers_produce_valid_effort(
        self,
        development_hours: float
    ):
        """
        Property test: Default multipliers should produce valid effort estimates.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Default multipliers from design document
        testing_mult = 1.5
        documentation_mult = 0.2
        project_mgmt_mult = 0.15
        
        # Calculate effort with defaults
        testing_hours = development_hours * testing_mult
        documentation_hours = development_hours * documentation_mult
        subtotal_hours = development_hours + testing_hours + documentation_hours
        project_management_hours = subtotal_hours * project_mgmt_mult
        total_effort_hours = subtotal_hours + project_management_hours
        
        # Verify all components are non-negative
        assert development_hours >= 0
        assert testing_hours >= 0
        assert documentation_hours >= 0
        assert project_management_hours >= 0
        assert total_effort_hours >= 0
        
        # Verify testing hours is 1.5x development (only for non-trivial values to avoid floating-point issues)
        if development_hours > 1.0:
            tolerance = 0.01
            assert abs(testing_hours / development_hours - 1.5) < tolerance
    
    @given(
        development_hours=st.floats(min_value=0.0, max_value=100000.0, allow_nan=False, allow_infinity=False),
        testing_mult=st.floats(min_value=0.5, max_value=3.0, allow_nan=False, allow_infinity=False),
        documentation_mult=st.floats(min_value=0.1, max_value=1.0, allow_nan=False, allow_infinity=False),
        project_mgmt_mult=st.floats(min_value=0.05, max_value=0.5, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_effort_distribution_percentages_sum_to_100(
        self,
        development_hours: float,
        testing_mult: float,
        documentation_mult: float,
        project_mgmt_mult: float
    ):
        """
        Property test: Effort distribution percentages should sum to 100%.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Calculate effort components
        testing_hours = development_hours * testing_mult
        documentation_hours = development_hours * documentation_mult
        subtotal_hours = development_hours + testing_hours + documentation_hours
        project_management_hours = subtotal_hours * project_mgmt_mult
        total_effort_hours = subtotal_hours + project_management_hours
        
        # Calculate percentages
        if total_effort_hours > 0:
            development_pct = (development_hours * 100.0) / total_effort_hours
            testing_pct = (testing_hours * 100.0) / total_effort_hours
            documentation_pct = (documentation_hours * 100.0) / total_effort_hours
            project_management_pct = (project_management_hours * 100.0) / total_effort_hours
            
            # Sum of percentages should be 100
            total_pct = development_pct + testing_pct + documentation_pct + project_management_pct
            
            # Allow small floating-point error
            tolerance = 0.1
            assert abs(total_pct - 100.0) < tolerance, \
                f"Effort percentages should sum to 100%, got {total_pct}"
    
    @given(
        low_complexity_hours=st.floats(min_value=0.0, max_value=10000.0, allow_nan=False, allow_infinity=False),
        medium_complexity_hours=st.floats(min_value=0.0, max_value=20000.0, allow_nan=False, allow_infinity=False),
        high_complexity_hours=st.floats(min_value=0.0, max_value=30000.0, allow_nan=False, allow_infinity=False),
        very_high_complexity_hours=st.floats(min_value=0.0, max_value=40000.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_property_10_effort_breakdown_by_category_sums_to_total(
        self,
        low_complexity_hours: float,
        medium_complexity_hours: float,
        high_complexity_hours: float,
        very_high_complexity_hours: float
    ):
        """
        Property test: Sum of effort across all complexity categories should equal total development hours.
        
        Feature: db2-migration-queries
        Property 10: Cost Calculation Non-Negativity
        Validates: Requirements 9.8
        """
        # Calculate total development hours
        total_development_hours = (
            low_complexity_hours +
            medium_complexity_hours +
            high_complexity_hours +
            very_high_complexity_hours
        )
        
        # Verify sum equals total
        calculated_sum = (
            low_complexity_hours +
            medium_complexity_hours +
            high_complexity_hours +
            very_high_complexity_hours
        )
        
        # Allow small floating-point error
        tolerance = 0.01
        assert abs(calculated_sum - total_development_hours) < tolerance, \
            f"Category breakdown should sum to total: expected {total_development_hours}, got {calculated_sum}"
        
        # Verify all categories are non-negative
        assert low_complexity_hours >= 0
        assert medium_complexity_hours >= 0
        assert high_complexity_hours >= 0
        assert very_high_complexity_hours >= 0

