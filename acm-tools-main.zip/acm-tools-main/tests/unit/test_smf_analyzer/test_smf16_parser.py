"""Unit tests for SMF Type 16 parser."""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers import SMF16ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type16_record_minimal() -> bytes:
    """Create a minimal valid Type 16 record.
    
    This represents a basic DFSORT statistics record.
    """
    record = bytearray(144)  # Minimum size with expanded stats
    
    # Standard SMF header (offsets 0-17)
    struct.pack_into('>H', record, 0, 144)  # SMF16LEN - Record length
    struct.pack_into('>H', record, 2, 0)  # SMF16SEG - Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # ICESIND - System indicator
    struct.pack_into('B', record, 5, 16)  # ICERTYP - Record type = 16
    struct.pack_into('>I', record, 6, 36000)  # ICEBTIME - Timestamp (10:00:00.00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # ICEBDATE - Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id  # ICESID
    
    # Job identification (offsets 18-41)
    job_name = "SORTJOB ".encode('cp037')
    record[18:26] = job_name  # ICEJOBNM
    struct.pack_into('>I', record, 26, 3240000)  # ICERST - Reader timestamp
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # ICERDS - Reader date
    user_info = "USER001 ".encode('cp037')
    record[34:42] = user_info  # ICEUIF
    
    # Type 16 specific header fields
    struct.pack_into('B', record, 42, 1)  # ICESTN - Step number
    struct.pack_into('>H', record, 44, 7)  # ICETRN - Triplet count
    subsys_id = "DFSR".encode('cp037')
    record[46:50] = subsys_id  # ICESUBID
    struct.pack_into('>H', record, 50, 2)  # ICERSUB - Subtype (2 = full record, successful)
    
    # Triplet descriptors (offsets 52-135)
    # Product section triplet
    struct.pack_into('>I', record, 52, 0)  # ICEPROD - offset (0 = not present)
    struct.pack_into('>H', record, 56, 0)  # ICEPRODL - length
    struct.pack_into('>H', record, 58, 0)  # ICEPRODN - count
    
    # Common data section triplet
    struct.pack_into('>I', record, 60, 0)
    struct.pack_into('>H', record, 64, 0)
    struct.pack_into('>H', record, 66, 0)
    
    # Record-length distribution section triplet
    struct.pack_into('>I', record, 68, 0)
    struct.pack_into('>H', record, 72, 0)
    struct.pack_into('>H', record, 74, 0)
    
    # Input data set section triplet
    struct.pack_into('>I', record, 76, 0)
    struct.pack_into('>H', record, 80, 0)
    struct.pack_into('>H', record, 82, 0)
    
    # SORTOUT data set section triplet
    struct.pack_into('>I', record, 84, 0)
    struct.pack_into('>H', record, 88, 0)
    struct.pack_into('>H', record, 90, 0)
    
    # OUTFIL data set section triplet
    struct.pack_into('>I', record, 92, 0)
    struct.pack_into('>H', record, 96, 0)
    struct.pack_into('>H', record, 98, 0)
    
    # Header length and performance group
    struct.pack_into('>H', record, 100, 102)  # ICEHDRLN - Header length
    struct.pack_into('>H', record, 102, 1)  # ICESPGN - Performance group
    
    # User/Group IDs (offsets 104-119)
    user_id = "SORTUSER".encode('cp037')
    record[104:112] = user_id  # ICEUSER
    group_id = "SORTGRP ".encode('cp037')
    record[112:120] = group_id  # ICEGROUP
    
    # ZSORT section triplet (offsets 128-135)
    struct.pack_into('>I', record, 128, 0)  # ICEZSRT - offset
    struct.pack_into('>H', record, 132, 0)  # ICEZSRTL - length
    struct.pack_into('>H', record, 134, 0)  # ICEZSRTN - count
    
    return bytes(record)


class TestSMF16Parser:
    """Test suite for SMF Type 16 parser."""
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal Type 16 record."""
        record_data = create_type16_record_minimal()
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF16ParserV3R2(base_parser)
        
        result = parser.parse(record_data)
        
        # Verify basic fields
        assert result.record_type == 16
        assert result.subtype == 2  # Full record, successful
        assert result.system_id == "SYS1"
        assert result.record_length == 144
        
        # Verify job identification
        assert result.identification['job_name'] == "SORTJOB"
        assert result.identification['user_id'] == "SORTUSER"
        assert result.identification['group_id'] == "SORTGRP"
        
        # Verify header fields
        assert result.header['step_number'] == 1
        assert result.header['triplet_count'] == 7
        assert result.header['subsystem_id'] == "DFSR"
        assert result.header['subtype'] == 2
        assert result.header['performance_group'] == 1
    
    def test_parse_invalid_record_type(self):
        """Test that parser rejects wrong record type."""
        record_data = create_type16_record_minimal()
        # Change record type to 15
        record_data = bytearray(record_data)
        record_data[5] = 15
        record_data = bytes(record_data)
        
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF16ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(record_data)
    
    def test_parse_short_record(self):
        """Test that parser handles truncated records."""
        record_data = create_type16_record_minimal()[:50]  # Truncate
        
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF16ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(record_data)
