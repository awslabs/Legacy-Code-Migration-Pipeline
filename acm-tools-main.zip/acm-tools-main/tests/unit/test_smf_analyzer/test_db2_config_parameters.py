"""Unit tests for DB2 configuration parameter loading and validation."""

import pytest
import os
from tools.smf_analyzer.smf_queries.file_config_manager import FileConfigurationManager
from tools.smf_analyzer.smf_queries.queries.db2_infrastructure_queries import (
    DB2WorkloadCPUQuery,
    DB2StorageRequirementsQuery,
    DB2IOPSRequirementsQuery,
    DB2SQLWorkloadQuery,
    DB2TransactionPerformanceQuery,
    DB2DDFAnalysisQuery,
    DB2LatchContentionQuery,
    DB2BufferPoolOptimizationQuery
)
from tools.smf_analyzer.smf_queries.queries.db2_cost_queries import (
    DB2MainframeCostQuery,
    DB2RDSCostQuery,
    DB2MigrationROIQuery
)
from tools.smf_analyzer.smf_queries.queries.db2_migration_queries import (
    DB2PlanPrioritizationQuery,
    DB2MigrationComplexityQuery,
    DB2MigrationEffortQuery
)


class TestDB2ConfigurationParameterLoading:
    """Test that Configuration_Manager can load all DB2 parameters."""
    
    def test_config_file_exists(self):
        """Verify the configuration file exists."""
        config_path = 'config/query_config_defaults.yaml'
        assert os.path.exists(config_path), f"Configuration file not found: {config_path}"
    
    def test_load_db2_parameters_from_file(self):
        """Test that all DB2 parameters can be loaded from the configuration file."""
        config_path = 'config/query_config_defaults.yaml'
        config_manager = FileConfigurationManager(config_path, file_format='yaml')
        
        # Get all configuration
        all_config = config_manager.get_all()
        
        # Verify configuration is not empty
        assert len(all_config) > 0, "Configuration file is empty"
        
        # List of all DB2 parameters that should be in the config
        expected_db2_params = [
            # Conversion Ratios
            'DB2_CPU_CONVERSION_RATIO',
            'DB2_OVERHEAD_HEADROOM',
            
            # Thresholds
            'DB2_LOW_HIT_RATIO_THRESHOLD',
            'HIGH_IO_WAIT_THRESHOLD',
            'HIGH_LOCK_WAIT_THRESHOLD',
            'HIGH_ABORT_RATIO_THRESHOLD',
            'READ_HEAVY_THRESHOLD',
            'WRITE_HEAVY_THRESHOLD',
            'DYNAMIC_SQL_THRESHOLD',
            'LATCH_CONTENTION_THRESHOLD',
            'LATCH_HIGH_CONTENTION_THRESHOLD',
            'PREFETCH_INEFFECTIVE_THRESHOLD',
            'DDF_SIGNIFICANT_THRESHOLD',
            
            # Multipliers
            'DB2_LOW_HIT_RATIO_MULTIPLIER',
            'DB2_IOPS_HEADROOM',
            'DB2_STORAGE_GROWTH_HEADROOM',
            'LATCH_CPU_MULTIPLIER',
            
            # Sizing Parameters
            'DB2_MEMORY_PER_VCPU',
            'DB2_IOPS_PER_1000_GETPAGE',
            'DDF_BYTES_PER_REQUEST',
            
            # Cost Parameters (Mainframe)
            'DB2_MIPS_COST_PER_MONTH_LOW',
            'DB2_MIPS_COST_PER_MONTH_MID',
            'DB2_MIPS_COST_PER_MONTH_HIGH',
            'DB2_SOFTWARE_COST_RATIO',
            'DB2_HARDWARE_COST_RATIO',
            'DB2_SUPPORT_COST_RATIO',
            
            # Cost Parameters (AWS RDS)
            'RDS_GP3_IOPS_COST',
            'RDS_IO2_STORAGE_COST',
            'RDS_IO2_IOPS_COST',
            'RDS_BACKUP_STORAGE_RATIO',
            'RDS_IO_COST_PER_1000_OPS',
            'AWS_DATA_TRANSFER_COST_PER_GB',
            
            # Migration Parameters
            'DB2_MIGRATION_ASSESSMENT_COST',
            'DB2_MIGRATION_COST_PER_PLAN',
            'DB2_MIGRATION_DATA_COST_PER_GB',
            'DB2_MIGRATION_TESTING_COST',
            'DB2_MIGRATION_TRAINING_COST',
            'DB2_MIGRATION_CONTINGENCY_RATIO',
            
            # Migration Complexity Parameters
            'COMPLEXITY_BASE_EFFORT_HOURS',
            'COMPLEXITY_HIGH_VOLUME_MULTIPLIER',
            'COMPLEXITY_DYNAMIC_SQL_MULTIPLIER',
            'COMPLEXITY_DDF_MULTIPLIER',
            'COMPLEXITY_CONTENTION_MULTIPLIER',
            
            # Migration Priority Weights
            'PRIORITY_VOLUME_WEIGHT',
            'PRIORITY_CPU_WEIGHT',
            'PRIORITY_SIMPLICITY_WEIGHT',
            'PRIORITY_NO_DDF_WEIGHT',
            'PRIORITY_PERFORMANCE_WEIGHT',
        ]
        
        # Check that all expected parameters are present
        missing_params = []
        for param in expected_db2_params:
            if param not in all_config:
                missing_params.append(param)
        
        assert len(missing_params) == 0, \
            f"Missing DB2 parameters in configuration: {', '.join(missing_params)}"
    
    def test_retrieve_individual_db2_parameters(self):
        """Test that individual DB2 parameters can be retrieved with correct defaults."""
        config_path = 'config/query_config_defaults.yaml'
        config_manager = FileConfigurationManager(config_path, file_format='yaml')
        
        # Test a few key parameters with their expected defaults
        test_cases = [
            ('DB2_CPU_CONVERSION_RATIO', 0.8),  # Updated to match actual default
            ('DB2_OVERHEAD_HEADROOM', 1.4),
            ('DB2_LOW_HIT_RATIO_THRESHOLD', 0.9),
            ('DB2_MEMORY_PER_VCPU', 4),
            ('DB2_IOPS_HEADROOM', 1.2),
            ('DB2_MIPS_COST_PER_MONTH_LOW', 3000),
            ('COMPLEXITY_BASE_EFFORT_HOURS', 40),
            ('PRIORITY_VOLUME_WEIGHT', 30),
        ]
        
        for param_name, expected_value in test_cases:
            actual_value = config_manager.get(param_name)
            assert actual_value == expected_value, \
                f"Parameter {param_name}: expected {expected_value}, got {actual_value}"
    
    def test_validate_db2_query_parameters(self):
        """Test that all DB2 query configuration parameters can be validated."""
        config_path = 'config/query_config_defaults.yaml'
        config_manager = FileConfigurationManager(config_path, file_format='yaml')
        
        # Get all DB2 queries
        queries = [
            DB2WorkloadCPUQuery(),
            DB2StorageRequirementsQuery(),
            DB2IOPSRequirementsQuery(),
            DB2SQLWorkloadQuery(),
            DB2TransactionPerformanceQuery(),
            DB2DDFAnalysisQuery(),
            DB2LatchContentionQuery(),
            DB2BufferPoolOptimizationQuery(),
            DB2MainframeCostQuery(),
            DB2RDSCostQuery(),
            DB2MigrationROIQuery(),
            DB2PlanPrioritizationQuery(),
            DB2MigrationComplexityQuery(),
            DB2MigrationEffortQuery(),
        ]
        
        # Validate parameters for each query
        all_warnings = []
        for query in queries:
            param_defs = query.configuration_parameters
            warnings = config_manager.validate_all(param_defs)
            if warnings:
                all_warnings.extend([f"{query.name}: {w}" for w in warnings])
        
        assert len(all_warnings) == 0, \
            f"Configuration validation warnings:\n" + "\n".join(all_warnings)
    
    def test_parameter_types(self):
        """Test that DB2 parameters have correct types."""
        config_path = 'config/query_config_defaults.yaml'
        config_manager = FileConfigurationManager(config_path, file_format='yaml')
        
        # Test parameter types
        type_tests = [
            ('DB2_CPU_CONVERSION_RATIO', (int, float)),
            ('DB2_OVERHEAD_HEADROOM', (int, float)),
            ('DB2_MEMORY_PER_VCPU', int),
            ('DB2_IOPS_PER_1000_GETPAGE', int),
            ('DB2_MIPS_COST_PER_MONTH_LOW', (int, float)),
            ('COMPLEXITY_BASE_EFFORT_HOURS', int),
            ('PRIORITY_VOLUME_WEIGHT', int),
        ]
        
        for param_name, expected_type in type_tests:
            value = config_manager.get(param_name)
            assert isinstance(value, expected_type), \
                f"Parameter {param_name}: expected type {expected_type}, got {type(value)}"
    
    def test_parameter_ranges(self):
        """Test that DB2 parameters are within expected ranges."""
        config_path = 'config/query_config_defaults.yaml'
        config_manager = FileConfigurationManager(config_path, file_format='yaml')
        
        # Test parameter ranges (ratio parameters should be between 0 and 1 or reasonable multipliers)
        range_tests = [
            ('DB2_CPU_CONVERSION_RATIO', 0.1, 2.0),
            ('DB2_OVERHEAD_HEADROOM', 1.0, 3.0),
            ('DB2_LOW_HIT_RATIO_THRESHOLD', 0.0, 1.0),
            ('DB2_LOW_HIT_RATIO_MULTIPLIER', 1.0, 3.0),
            ('DB2_IOPS_HEADROOM', 1.0, 3.0),
            ('DB2_STORAGE_GROWTH_HEADROOM', 1.0, 3.0),
            ('DB2_SOFTWARE_COST_RATIO', 0.0, 1.0),
            ('DB2_HARDWARE_COST_RATIO', 0.0, 1.0),
            ('DB2_SUPPORT_COST_RATIO', 0.0, 1.0),
            ('RDS_BACKUP_STORAGE_RATIO', 0.0, 2.0),
        ]
        
        for param_name, min_val, max_val in range_tests:
            value = config_manager.get(param_name)
            assert min_val <= value <= max_val, \
                f"Parameter {param_name}: value {value} not in range [{min_val}, {max_val}]"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
