"""Property-based tests for DB2 version detection.

Feature: db2-versioned-smf-parsers
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers.db2_version_detector import (
    DB2VersionDetector,
    DB2_VERSION_MAP
)
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_db2_record_with_version(
    record_type: int,
    db2_version_code: int,
    record_length: int = 200
) -> bytes:
    """Create a synthetic DB2 SMF record with specified version.
    
    Args:
        record_type: SMF record type (100, 101, or 102)
        db2_version_code: 2-byte DB2 version code (e.g., 0x0A00 for V10)
        record_length: Total record length
        
    Returns:
        Binary SMF record with DB2 version in QWHSRELN field
    """
    record = bytearray(record_length)
    
    # Standard SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, record_type)  # Record type
    struct.pack_into('>I', record, 6, 36000)  # Timestamp
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Subsystem ID (EBCDIC)
    subsys_id = "DB2P".encode('cp037')
    record[18:22] = subsys_id
    
    # Subtype
    struct.pack_into('>H', record, 22, 0)
    
    # Triplet count
    struct.pack_into('>H', record, 24, 1)
    
    # Reserved
    struct.pack_into('>H', record, 26, 0)
    
    # Product section triplet (offset 28)
    product_offset = 44  # Start product section after header
    struct.pack_into('>I', record, 28, product_offset)  # Offset
    struct.pack_into('>H', record, 32, 100)  # Length
    struct.pack_into('>H', record, 34, 1)  # Count
    
    # Data section triplet (offset 36)
    struct.pack_into('>I', record, 36, 0)  # Offset (not used for version detection)
    struct.pack_into('>H', record, 40, 0)  # Length
    struct.pack_into('>H', record, 42, 0)  # Count
    
    # QWHS standard header in product section (starts at offset 44)
    # QWHSLEN - Header length
    struct.pack_into('>H', record, product_offset, 92)
    
    # QWHSTYPE - Header type
    struct.pack_into('B', record, product_offset + 2, 1)
    
    # QWHSRMID - Resource manager ID
    struct.pack_into('B', record, product_offset + 3, 0xDB)  # DB2 identifier
    
    # QWHSIFID - IFCID
    struct.pack_into('>H', record, product_offset + 4, 1)
    
    # QWHSRELN - Release number (THIS IS THE KEY FIELD)
    struct.pack_into('>H', record, product_offset + 6, db2_version_code)
    
    # Fill rest of QWHS header with zeros
    # (In real records, this would contain more fields)
    
    return bytes(record)


# Strategies for generating test data

# Valid DB2 version codes
valid_db2_versions = st.sampled_from([
    0x0A00,  # V10
    0x0B00,  # V11
    0x0C00,  # V12
    0x0D00,  # V13
])

# Valid DB2 record types
db2_record_types = st.sampled_from([100, 101, 102])

# Invalid DB2 version codes (for error testing)
# These are versions where even the major version is not supported
invalid_db2_versions = st.integers(min_value=0, max_value=0xFFFF).filter(
    lambda x: (x >> 8) not in [0x0A, 0x0B, 0x0C, 0x0D]  # Major versions not in map
)

# Invalid record types (not 100, 101, or 102)
invalid_record_types = st.integers(min_value=0, max_value=255).filter(
    lambda x: x not in {100, 101, 102}
)


class TestDB2VersionDetectorProperties:
    """Property-based tests for DB2 version detection."""
    
    @settings(max_examples=100)
    @given(
        record_type=st.sampled_from([101]),  # Only test Type 101 which has reliable version detection
        version_code=valid_db2_versions
    )
    def test_property_1_version_detection_consistency(self, record_type, version_code):
        """
        **Feature: db2-versioned-smf-parsers, Property 1: DB2 Version Detection Consistency**
        **Validates: Requirements 1.1, 1.2**
        
        For any SMF record of type 101 with a valid QWHSRELN field,
        parsing the record should extract a DB2 version that matches the version
        encoded in the QWHSRELN field.
        
        Note: Type 100 and 102 records don't reliably contain version information,
        so they use default versions (V10 and V13 respectively).
        """
        # Create test record with known version
        record_data = create_db2_record_with_version(record_type, version_code)
        
        # Detect version
        detected_version = DB2VersionDetector.detect_version(record_data, record_type)
        
        # Verify match
        expected_version = DB2_VERSION_MAP[version_code]
        assert detected_version == expected_version, \
            f"Detected version {detected_version} should match expected {expected_version} " \
            f"for version code 0x{version_code:04X}"
        
        # Verify parse_release_number extracts correct major/minor
        major = (version_code >> 8) & 0xFF
        minor = version_code & 0xFF
        release_bytes = struct.pack('>H', version_code)
        parsed_major, parsed_minor = DB2VersionDetector.parse_release_number(release_bytes)
        
        assert parsed_major == major, \
            f"Parsed major version {parsed_major} should match {major}"
        assert parsed_minor == minor, \
            f"Parsed minor version {parsed_minor} should match {minor}"
    
    @settings(max_examples=100)
    @given(
        record_type=st.sampled_from([101]),  # Only test Type 101 which has reliable version detection
        version_codes=st.lists(valid_db2_versions, min_size=2, max_size=10)
    )
    def test_property_2_version_detection_independence(self, record_type, version_codes):
        """
        **Feature: db2-versioned-smf-parsers, Property 2: Version Detection Independence**
        **Validates: Requirements 1.4**
        
        For any sequence of SMF records with different DB2 versions, parsing each
        record should detect the correct version independently without state leakage
        between parsing operations.
        """
        # Create multiple records with different versions
        records = [
            create_db2_record_with_version(record_type, version_code)
            for version_code in version_codes
        ]
        
        # Parse each record and verify version detection
        detected_versions = []
        for i, (record_data, version_code) in enumerate(zip(records, version_codes)):
            detected = DB2VersionDetector.detect_version(record_data, record_type)
            detected_versions.append(detected)
            
            expected = DB2_VERSION_MAP[version_code]
            assert detected == expected, \
                f"Record {i}: detected version {detected} should match expected {expected}"
        
        # Verify each detection was independent (no state leakage)
        # Re-parse in reverse order and verify same results
        for i, (record_data, version_code) in enumerate(zip(reversed(records), reversed(version_codes))):
            detected = DB2VersionDetector.detect_version(record_data, record_type)
            expected = DB2_VERSION_MAP[version_code]
            assert detected == expected, \
                f"Reverse parse {i}: detected version {detected} should match expected {expected}"
    
    @settings(max_examples=50)
    @given(
        record_type=st.sampled_from([101]),  # Only test Type 101 which validates versions
        version_code=invalid_db2_versions
    )
    def test_property_3_version_detection_error_handling(self, record_type, version_code):
        """
        **Feature: db2-versioned-smf-parsers, Property 3: Version Detection Error Handling**
        **Validates: Requirements 1.3**
        
        For any SMF Type 101 record with a corrupted or missing QWHSRELN field, attempting
        to detect the DB2 version should raise a descriptive error indicating the
        detection failure.
        
        Note: Type 100 and 102 use default versions and don't validate version codes.
        """
        # Create record with invalid version code
        record_data = create_db2_record_with_version(record_type, version_code)
        
        # Attempt to detect version - should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            DB2VersionDetector.detect_version(record_data, record_type)
        
        # Verify error message is descriptive
        error_msg = str(exc_info.value)
        assert "Unknown DB2 version" in error_msg or "version" in error_msg.lower(), \
            f"Error message should mention version: {error_msg}"
        
        # Verify error includes version code information
        assert f"0x{version_code:04X}" in error_msg or f"{version_code}" in error_msg, \
            f"Error message should include version code: {error_msg}"
    
    @settings(max_examples=50)
    @given(record_type=invalid_record_types)
    def test_property_3_invalid_record_type_error(self, record_type):
        """
        **Feature: db2-versioned-smf-parsers, Property 3: Version Detection Error Handling**
        **Validates: Requirements 1.3**
        
        For any SMF record with an invalid record type (not 100, 101, or 102),
        attempting to detect the DB2 version should raise a descriptive error.
        """
        # Create a minimal record with invalid type
        record_data = create_db2_record_with_version(record_type, 0x0A00)
        
        # Attempt to detect version - should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            DB2VersionDetector.detect_version(record_data, record_type)
        
        # Verify error message mentions invalid record type
        error_msg = str(exc_info.value)
        assert "Invalid record type" in error_msg or "record type" in error_msg.lower(), \
            f"Error message should mention invalid record type: {error_msg}"
        assert str(record_type) in error_msg, \
            f"Error message should include the invalid record type {record_type}: {error_msg}"
    
    @settings(max_examples=50)
    @given(
        record_type=st.sampled_from([101]),  # Only test Type 101 which validates record length
        record_length=st.integers(min_value=0, max_value=35)
    )
    def test_property_3_short_record_error(self, record_type, record_length):
        """
        **Feature: db2-versioned-smf-parsers, Property 3: Version Detection Error Handling**
        **Validates: Requirements 1.3**
        
        For any SMF Type 101 record that is too short to contain the required header fields,
        attempting to detect the DB2 version should raise a descriptive error.
        
        Note: Type 100 and 102 use default versions and don't validate record length.
        """
        # Create a record that's too short
        record_data = bytes(record_length)
        
        # Attempt to detect version - should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            DB2VersionDetector.detect_version(record_data, record_type)
        
        # Verify error message mentions short record
        error_msg = str(exc_info.value)
        assert "too short" in error_msg.lower() or "minimum" in error_msg.lower(), \
            f"Error message should mention short record: {error_msg}"
    
    @settings(max_examples=50)
    @given(record_type=st.sampled_from([101]))  # Only test Type 101 which validates product section
    def test_property_3_missing_product_section_error(self, record_type):
        """
        **Feature: db2-versioned-smf-parsers, Property 3: Version Detection Error Handling**
        **Validates: Requirements 1.3**
        
        For any SMF Type 101 record with a zero product section offset, attempting to detect
        the DB2 version should raise a descriptive error.
        
        Note: Type 100 and 102 use default versions and don't validate product section.
        """
        # Create a record with zero product section offset
        record_length = 100
        record = bytearray(record_length)
        
        # Standard SMF header
        struct.pack_into('>H', record, 0, record_length)
        struct.pack_into('B', record, 5, record_type)
        
        # Product section triplet with zero offset
        struct.pack_into('>I', record, 28, 0)  # Zero offset
        struct.pack_into('>H', record, 32, 0)  # Zero length
        struct.pack_into('>H', record, 34, 0)  # Zero count
        
        record_data = bytes(record)
        
        # Attempt to detect version - should raise ValidationError
        with pytest.raises(ValidationError) as exc_info:
            DB2VersionDetector.detect_version(record_data, record_type)
        
        # Verify error message mentions missing product section
        error_msg = str(exc_info.value)
        assert "product section" in error_msg.lower() or "offset is 0" in error_msg.lower(), \
            f"Error message should mention missing product section: {error_msg}"
    
    def test_parse_release_number_invalid_length(self):
        """
        **Feature: db2-versioned-smf-parsers, Property 3: Version Detection Error Handling**
        **Validates: Requirements 1.3**
        
        For any release number field that is not exactly 2 bytes, parsing should
        raise a descriptive error.
        """
        # Test with 1 byte
        with pytest.raises(ValidationError) as exc_info:
            DB2VersionDetector.parse_release_number(bytes([0x0A]))
        
        error_msg = str(exc_info.value)
        assert "Invalid release number length" in error_msg or "2 bytes" in error_msg, \
            f"Error message should mention invalid length: {error_msg}"
        
        # Test with 3 bytes
        with pytest.raises(ValidationError) as exc_info:
            DB2VersionDetector.parse_release_number(bytes([0x0A, 0x00, 0x00]))
        
        error_msg = str(exc_info.value)
        assert "Invalid release number length" in error_msg or "2 bytes" in error_msg, \
            f"Error message should mention invalid length: {error_msg}"
