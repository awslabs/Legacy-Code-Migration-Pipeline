#!/usr/bin/env python3
"""Test script for SMF Type 110 transaction resource parsing."""

import pytest
from tools.smf_analyzer.smf_record_parser.parsers.smf110_parser_v3r2 import SMF110ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser


class TestSMF110TransactionResourceParsing:
    """Test transaction resource parsing for SMF Type 110."""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        return SMF110ParserV3R2(base_parser)
    
    def test_parse_file_operations_resource(self, parser):
        """Test parsing file operations resource record."""
        # Create a minimal transaction resource record for file operations
        # Structure: length(2) + transaction_id(4) + resource_type(2) + operation_count(4) + 
        #            resource_name(8) + read(4) + write(4) + update(4) + delete(4) + io_wait(4)
        
        # Build test data
        record_length = 40  # Total length
        transaction_id = b'\xE3\xE2\xE3\xF1'  # "TST1" in EBCDIC
        resource_type = 1  # File operations
        operation_count = 100
        resource_name = b'\xC3\xE4\xE2\xE3\xC6\xC9\xD3\xC5'  # "CUSTFILE" in EBCDIC
        read_ops = 50
        write_ops = 30
        update_ops = 15
        delete_ops = 5
        io_wait = 1000  # microseconds
        
        # Construct binary data
        data = (
            record_length.to_bytes(2, 'big') +
            transaction_id +
            resource_type.to_bytes(2, 'big') +
            operation_count.to_bytes(4, 'big') +
            resource_name +
            read_ops.to_bytes(4, 'big') +
            write_ops.to_bytes(4, 'big') +
            update_ops.to_bytes(4, 'big') +
            delete_ops.to_bytes(4, 'big') +
            io_wait.to_bytes(4, 'big')
        )
        
        # Parse the record
        records = parser.parse_transaction_resource_records(data, 0, 0, 1)
        
        # Verify results
        assert len(records) == 1
        record = records[0]
        
        assert record['record_number'] == 1
        assert record['length'] == record_length
        assert record['transaction_id'] == 'TST1'
        assert record['resource_type'] == 1
        assert record['resource_type_name'] == 'File Operations'
        assert record['resource_name'] == 'CUSTFILE'
        assert record['operation_count'] == 100
        assert record['read_operations'] == 50
        assert record['write_operations'] == 30
        assert record['update_operations'] == 15
        assert record['delete_operations'] == 5
        assert record['io_wait_time'] == 1000
    
    def test_parse_database_operations_resource(self, parser):
        """Test parsing database operations resource record."""
        # Create a minimal transaction resource record for database operations
        # Structure: length(2) + transaction_id(4) + resource_type(2) + operation_count(4) + 
        #            resource_name(8) + select(4) + insert(4) + update(4) + delete(4) + 
        #            db_wait(4) + rows(4)
        
        # Build test data
        record_length = 44  # Total length
        transaction_id = b'\xC4\xC2\xF0\xF1'  # "DB01" in EBCDIC
        resource_type = 2  # Database operations
        operation_count = 200
        resource_name = b'\xC1\xC3\xC3\xE3\xE3\xC2\xD3\x40'  # "ACCTTBL " in EBCDIC
        select_ops = 150
        insert_ops = 30
        update_ops = 15
        delete_ops = 5
        db_wait = 5000  # microseconds
        rows_processed = 1000
        
        # Construct binary data
        data = (
            record_length.to_bytes(2, 'big') +
            transaction_id +
            resource_type.to_bytes(2, 'big') +
            operation_count.to_bytes(4, 'big') +
            resource_name +
            select_ops.to_bytes(4, 'big') +
            insert_ops.to_bytes(4, 'big') +
            update_ops.to_bytes(4, 'big') +
            delete_ops.to_bytes(4, 'big') +
            db_wait.to_bytes(4, 'big') +
            rows_processed.to_bytes(4, 'big')
        )
        
        # Parse the record
        records = parser.parse_transaction_resource_records(data, 0, 0, 1)
        
        # Verify results
        assert len(records) == 1
        record = records[0]
        
        assert record['record_number'] == 1
        assert record['length'] == record_length
        assert record['transaction_id'] == 'DB01'
        assert record['resource_type'] == 2
        assert record['resource_type_name'] == 'Database Calls'
        assert record['resource_name'] == 'ACCTTBL'
        assert record['operation_count'] == 200
        assert record['select_operations'] == 150
        assert record['insert_operations'] == 30
        assert record['update_operations'] == 15
        assert record['delete_operations'] == 5
        assert record['database_wait_time'] == 5000
        assert record['rows_processed'] == 1000
    
    def test_parse_temporary_storage_resource(self, parser):
        """Test parsing temporary storage resource record."""
        # Create a minimal transaction resource record for temporary storage
        # Structure: length(2) + transaction_id(4) + resource_type(2) + operation_count(4) + 
        #            resource_name(8) + queue_reads(4) + queue_writes(4) + bytes(4)
        
        # Build test data
        record_length = 32  # Total length
        transaction_id = b'\xE3\xE2\xF0\xF1'  # "TS01" in EBCDIC
        resource_type = 3  # Temporary storage
        operation_count = 50
        resource_name = b'\xE3\xC5\xD4\xD7\xD8\xE4\xC5\x40'  # "TEMPQUE " in EBCDIC
        queue_reads = 30
        queue_writes = 20
        bytes_transferred = 10240  # 10KB
        
        # Construct binary data
        data = (
            record_length.to_bytes(2, 'big') +
            transaction_id +
            resource_type.to_bytes(2, 'big') +
            operation_count.to_bytes(4, 'big') +
            resource_name +
            queue_reads.to_bytes(4, 'big') +
            queue_writes.to_bytes(4, 'big') +
            bytes_transferred.to_bytes(4, 'big')
        )
        
        # Parse the record
        records = parser.parse_transaction_resource_records(data, 0, 0, 1)
        
        # Verify results
        assert len(records) == 1
        record = records[0]
        
        assert record['record_number'] == 1
        assert record['length'] == record_length
        assert record['transaction_id'] == 'TS01'
        assert record['resource_type'] == 3
        assert record['resource_type_name'] == 'Temporary Storage'
        assert record['resource_name'] == 'TEMPQUE'
        assert record['operation_count'] == 50
        assert record['queue_read_operations'] == 30
        assert record['queue_write_operations'] == 20
        assert record['bytes_transferred'] == 10240
    
    def test_parse_program_load_resource(self, parser):
        """Test parsing program load resource record."""
        # Create a minimal transaction resource record for program loads
        # Structure: length(2) + transaction_id(4) + resource_type(2) + operation_count(4) + 
        #            resource_name(8) + program_loads(4) + program_size(4) + load_time(4)
        
        # Build test data
        record_length = 32  # Total length
        transaction_id = b'\xD7\xC7\xD4\xF1'  # "PGM1" in EBCDIC
        resource_type = 5  # Program load
        operation_count = 10
        resource_name = b'\xC3\xE4\xE2\xE3\xD7\xC7\xD4\x40'  # "CUSTPGM " in EBCDIC
        program_loads = 10
        program_size = 65536  # 64KB
        load_time = 500  # microseconds
        
        # Construct binary data
        data = (
            record_length.to_bytes(2, 'big') +
            transaction_id +
            resource_type.to_bytes(2, 'big') +
            operation_count.to_bytes(4, 'big') +
            resource_name +
            program_loads.to_bytes(4, 'big') +
            program_size.to_bytes(4, 'big') +
            load_time.to_bytes(4, 'big')
        )
        
        # Parse the record
        records = parser.parse_transaction_resource_records(data, 0, 0, 1)
        
        # Verify results
        assert len(records) == 1
        record = records[0]
        
        assert record['record_number'] == 1
        assert record['length'] == record_length
        assert record['transaction_id'] == 'PGM1'
        assert record['resource_type'] == 5
        assert record['resource_type_name'] == 'Program Load'
        assert record['resource_name'] == 'CUSTPGM'
        assert record['operation_count'] == 10
        assert record['program_loads'] == 10
        assert record['program_size'] == 65536
        assert record['program_load_time'] == 500
    
    def test_parse_storage_usage_resource(self, parser):
        """Test parsing storage usage resource record."""
        # Create a minimal transaction resource record for storage usage
        # Structure: length(2) + transaction_id(4) + resource_type(2) + operation_count(4) + 
        #            resource_name(8) + storage_acquired(4) + storage_released(4) + peak_storage(4)
        
        # Build test data
        record_length = 32  # Total length
        transaction_id = b'\xE2\xE3\xD6\xF1'  # "STO1" in EBCDIC
        resource_type = 6  # Storage usage
        operation_count = 100
        resource_name = b'\xE3\xD9\xC1\xD5\xE2\xC1\xC3\xE3'  # "TRANSACT" in EBCDIC
        storage_acquired = 1048576  # 1MB
        storage_released = 524288  # 512KB
        peak_storage = 786432  # 768KB
        
        # Construct binary data
        data = (
            record_length.to_bytes(2, 'big') +
            transaction_id +
            resource_type.to_bytes(2, 'big') +
            operation_count.to_bytes(4, 'big') +
            resource_name +
            storage_acquired.to_bytes(4, 'big') +
            storage_released.to_bytes(4, 'big') +
            peak_storage.to_bytes(4, 'big')
        )
        
        # Parse the record
        records = parser.parse_transaction_resource_records(data, 0, 0, 1)
        
        # Verify results
        assert len(records) == 1
        record = records[0]
        
        assert record['record_number'] == 1
        assert record['length'] == record_length
        assert record['transaction_id'] == 'STO1'
        assert record['resource_type'] == 6
        assert record['resource_type_name'] == 'Storage Usage'
        assert record['resource_name'] == 'TRANSACT'
        assert record['operation_count'] == 100
        assert record['storage_acquired'] == 1048576
        assert record['storage_released'] == 524288
        assert record['peak_storage'] == 786432
    
    def test_parse_multiple_resource_records(self, parser):
        """Test parsing multiple transaction resource records."""
        # Create two resource records
        
        # Record 1: File operations
        record1_length = 40
        record1_data = (
            record1_length.to_bytes(2, 'big') +
            b'\xE3\xE2\xE3\xF1' +  # "TST1"
            (1).to_bytes(2, 'big') +  # File operations
            (100).to_bytes(4, 'big') +
            b'\xC3\xE4\xE2\xE3\xC6\xC9\xD3\xC5' +  # "CUSTFILE"
            (50).to_bytes(4, 'big') +
            (30).to_bytes(4, 'big') +
            (15).to_bytes(4, 'big') +
            (5).to_bytes(4, 'big') +
            (1000).to_bytes(4, 'big')
        )
        
        # Record 2: Database operations
        record2_length = 44
        record2_data = (
            record2_length.to_bytes(2, 'big') +
            b'\xC4\xC2\xF0\xF1' +  # "DB01"
            (2).to_bytes(2, 'big') +  # Database operations
            (200).to_bytes(4, 'big') +
            b'\xC1\xC3\xC3\xE3\xE3\xC2\xD3\x40' +  # "ACCTTBL "
            (150).to_bytes(4, 'big') +
            (30).to_bytes(4, 'big') +
            (15).to_bytes(4, 'big') +
            (5).to_bytes(4, 'big') +
            (5000).to_bytes(4, 'big') +
            (1000).to_bytes(4, 'big')
        )
        
        # Combine records
        data = record1_data + record2_data
        
        # Parse the records
        records = parser.parse_transaction_resource_records(data, 0, 0, 2)
        
        # Verify results
        assert len(records) == 2
        
        # Check first record
        assert records[0]['transaction_id'] == 'TST1'
        assert records[0]['resource_type'] == 1
        assert records[0]['read_operations'] == 50
        
        # Check second record
        assert records[1]['transaction_id'] == 'DB01'
        assert records[1]['resource_type'] == 2
        assert records[1]['select_operations'] == 150
    
    def test_parse_short_resource_record(self, parser):
        """Test parsing a resource record that's too short for detailed parsing."""
        # Create a minimal record with only length and transaction ID
        record_length = 6
        data = (
            record_length.to_bytes(2, 'big') +
            b'\xE3\xE2\xE3\xF1'  # "TST1"
        )
        
        # Parse the record
        records = parser.parse_transaction_resource_records(data, 0, 0, 1)
        
        # Verify results
        assert len(records) == 1
        record = records[0]
        
        assert record['record_number'] == 1
        assert record['length'] == record_length
        assert 'note' in record
        assert 'too short' in record['note'].lower()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
