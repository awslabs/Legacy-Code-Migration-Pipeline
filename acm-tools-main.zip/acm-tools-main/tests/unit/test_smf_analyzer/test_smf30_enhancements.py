"""Unit tests for SMF Type 30 enhancements - specialty engines, subsystem, and storage."""

import pytest
import sqlite3
import json
from pathlib import Path
from tools.smf_analyzer.smf_loader.core.loader import SMFLoader
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas.smf30_schema import SMF30Schema


class TestSMF30SpecialtyEngineMetrics:
    """Test specialty engine metrics storage (zIIP/zAAP service units and normalization factors)."""
    
    @pytest.fixture
    def temp_db(self, tmp_path):
        """Create a temporary database for testing."""
        db_path = tmp_path / "test_smf30.db"
        return str(db_path)
    
    @pytest.fixture
    def sample_record_with_specialty_engines(self):
        """Create a sample SMF Type 30 record with specialty engine metrics."""
        return {
            "record_type": 30,
            "subtype": 1,
            "system_id": "SYS1",
            "date": "2024-01-01",
            "timestamp": "12:00:00",
            "record_length": 1000,
            "identification": {
                "job_name": "TESTJOB",
                "step_name": "STEP1",
                "program_name": "TESTPGM"
            },
            "processor": {
                "tcb_cpu_time": 100000,
                "srb_cpu_time": 50000,
                "total_cpu_time": 150000,
                "service_units": 1500,
                "ziip_cpu_time": 75000,
                "ziip_service_units": 750,
                "ziip_normalization_factor": 120,
                "zaap_cpu_time": 60000,
                "zaap_service_units": 600,
                "zaap_normalization_factor": 110,
                "cpu_normalization_factor": 100
            }
        }
    
    def test_ziip_service_units_stored(self, temp_db, sample_record_with_specialty_engines):
        """Test that zIIP service units are correctly stored in the database."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_specialty_engines)
        adapter.commit()  # Commit the transaction
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT ziip_service_units FROM smf_processor")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No processor record found"
        assert result[0] == 750, f"Expected zIIP service units 750, got {result[0]}"
    
    def test_ziip_normalization_factor_stored(self, temp_db, sample_record_with_specialty_engines):
        """Test that zIIP normalization factor is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_specialty_engines)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT ziip_normalization_factor FROM smf_processor")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No processor record found"
        assert result[0] == 120, f"Expected zIIP normalization factor 120, got {result[0]}"
    
    def test_zaap_service_units_stored(self, temp_db, sample_record_with_specialty_engines):
        """Test that zAAP service units are correctly stored in the database."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_specialty_engines)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT zaap_service_units FROM smf_processor")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No processor record found"
        assert result[0] == 600, f"Expected zAAP service units 600, got {result[0]}"
    
    def test_zaap_normalization_factor_stored(self, temp_db, sample_record_with_specialty_engines):
        """Test that zAAP normalization factor is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_specialty_engines)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT zaap_normalization_factor FROM smf_processor")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No processor record found"
        assert result[0] == 110, f"Expected zAAP normalization factor 110, got {result[0]}"
    
    def test_cpu_normalization_factor_stored(self, temp_db, sample_record_with_specialty_engines):
        """Test that CPU normalization factor is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_specialty_engines)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT cpu_normalization_factor FROM smf_processor")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No processor record found"
        assert result[0] == 100, f"Expected CPU normalization factor 100, got {result[0]}"
    
    def test_all_specialty_engine_metrics_together(self, temp_db, sample_record_with_specialty_engines):
        """Test that all specialty engine metrics are stored correctly together."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_specialty_engines)
        adapter.commit()  # Commit the transaction
        
        # Verify all fields at once
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT ziip_service_units, ziip_normalization_factor,
                   zaap_service_units, zaap_normalization_factor,
                   cpu_normalization_factor
            FROM smf_processor
        """)
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No processor record found"
        assert result[0] == 750, "zIIP service units mismatch"
        assert result[1] == 120, "zIIP normalization factor mismatch"
        assert result[2] == 600, "zAAP service units mismatch"
        assert result[3] == 110, "zAAP normalization factor mismatch"
        assert result[4] == 100, "CPU normalization factor mismatch"


class TestSMF30SubsystemSection:
    """Test subsystem section storage (OS level, sysplex name, system name)."""
    
    @pytest.fixture
    def temp_db(self, tmp_path):
        """Create a temporary database for testing."""
        db_path = tmp_path / "test_smf30_subsystem.db"
        return str(db_path)
    
    @pytest.fixture
    def sample_record_with_subsystem(self):
        """Create a sample SMF Type 30 record with subsystem information."""
        return {
            "record_type": 30,
            "subtype": 1,
            "system_id": "SYS1",
            "date": "2024-01-01",
            "timestamp": "12:00:00",
            "record_length": 1000,
            "identification": {
                "job_name": "TESTJOB"
            },
            "subsystem": {
                "os_level": "z/OS 2.5",
                "sysplex_name": "PLEXTEST",
                "system_name": "SYSNAME1",
                "product_name": "JES2",
                "record_version": "V3R2"
            }
        }
    
    def test_os_level_stored(self, temp_db, sample_record_with_subsystem):
        """Test that OS level is correctly stored in the database."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_subsystem)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT os_level FROM smf30_subsystem")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No subsystem record found"
        assert result[0] == "z/OS 2.5", f"Expected OS level 'z/OS 2.5', got {result[0]}"
    
    def test_sysplex_name_stored(self, temp_db, sample_record_with_subsystem):
        """Test that sysplex name is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_subsystem)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT sysplex_name FROM smf30_subsystem")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No subsystem record found"
        assert result[0] == "PLEXTEST", f"Expected sysplex name 'PLEXTEST', got {result[0]}"
    
    def test_system_name_stored(self, temp_db, sample_record_with_subsystem):
        """Test that system name is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_subsystem)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT system_name FROM smf30_subsystem")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No subsystem record found"
        assert result[0] == "SYSNAME1", f"Expected system name 'SYSNAME1', got {result[0]}"
    
    def test_product_name_stored(self, temp_db, sample_record_with_subsystem):
        """Test that product name is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_subsystem)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT product_name FROM smf30_subsystem")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No subsystem record found"
        assert result[0] == "JES2", f"Expected product name 'JES2', got {result[0]}"
    
    def test_record_version_stored(self, temp_db, sample_record_with_subsystem):
        """Test that record version is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_subsystem)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT record_version FROM smf30_subsystem")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No subsystem record found"
        assert result[0] == "V3R2", f"Expected record version 'V3R2', got {result[0]}"
    
    def test_all_subsystem_fields_together(self, temp_db, sample_record_with_subsystem):
        """Test that all subsystem fields are stored correctly together."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_subsystem)
        adapter.commit()  # Commit the transaction
        
        # Verify all fields at once
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT os_level, sysplex_name, system_name, product_name, record_version
            FROM smf30_subsystem
        """)
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No subsystem record found"
        assert result[0] == "z/OS 2.5", "OS level mismatch"
        assert result[1] == "PLEXTEST", "Sysplex name mismatch"
        assert result[2] == "SYSNAME1", "System name mismatch"
        assert result[3] == "JES2", "Product name mismatch"
        assert result[4] == "V3R2", "Record version mismatch"


class TestSMF30EnhancedStorage:
    """Test enhanced storage section (64-bit fields, MEMLIMIT, VIO, hiperspace)."""
    
    @pytest.fixture
    def temp_db(self, tmp_path):
        """Create a temporary database for testing."""
        db_path = tmp_path / "test_smf30_storage.db"
        return str(db_path)
    
    @pytest.fixture
    def sample_record_with_enhanced_storage(self):
        """Create a sample SMF Type 30 record with enhanced storage metrics."""
        return {
            "record_type": 30,
            "subtype": 1,
            "system_id": "SYS1",
            "date": "2024-01-01",
            "timestamp": "12:00:00",
            "record_length": 1000,
            "identification": {
                "job_name": "TESTJOB"
            },
            "storage": {
                "region_size": 10485760,
                "private_area_size": 8388608,
                "page_in_count": 100,
                "page_out_count": 50,
                "swap_in_count": 10,
                "swap_out_count": 5,
                "region_size_64bit": 17179869184,
                "private_area_size_64bit": 8589934592,
                "common_area_size_64bit": 4294967296,
                "memlimit": 34359738368,
                "vio_page_in_count": 25,
                "vio_page_out_count": 15,
                "hiperspace_page_in_count": 5,
                "hiperspace_page_out_count": 3
            }
        }
    
    def test_64bit_region_size_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that 64-bit region size is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT region_size_64bit FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 17179869184, f"Expected 64-bit region size 17179869184, got {result[0]}"
    
    def test_64bit_private_area_size_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that 64-bit private area size is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT private_area_size_64bit FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 8589934592, f"Expected 64-bit private area size 8589934592, got {result[0]}"
    
    def test_64bit_common_area_size_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that 64-bit common area size is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT common_area_size_64bit FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 4294967296, f"Expected 64-bit common area size 4294967296, got {result[0]}"
    
    def test_memlimit_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that MEMLIMIT is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT memlimit FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 34359738368, f"Expected MEMLIMIT 34359738368, got {result[0]}"
    
    def test_vio_page_in_count_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that VIO page-in count is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT vio_page_in_count FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 25, f"Expected VIO page-in count 25, got {result[0]}"
    
    def test_vio_page_out_count_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that VIO page-out count is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT vio_page_out_count FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 15, f"Expected VIO page-out count 15, got {result[0]}"
    
    def test_hiperspace_page_in_count_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that hiperspace page-in count is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT hiperspace_page_in_count FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 5, f"Expected hiperspace page-in count 5, got {result[0]}"
    
    def test_hiperspace_page_out_count_stored(self, temp_db, sample_record_with_enhanced_storage):
        """Test that hiperspace page-out count is correctly stored."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT hiperspace_page_out_count FROM smf_storage")
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 3, f"Expected hiperspace page-out count 3, got {result[0]}"
    
    def test_all_enhanced_storage_fields_together(self, temp_db, sample_record_with_enhanced_storage):
        """Test that all enhanced storage fields are stored correctly together."""
        # Setup
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        # Create schema
        adapter.connect()
        loader.create_schema()
        
        # Load record
        loader.load_record(sample_record_with_enhanced_storage)
        adapter.commit()  # Commit the transaction
        
        # Verify all fields at once
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT region_size_64bit, private_area_size_64bit, common_area_size_64bit,
                   memlimit, vio_page_in_count, vio_page_out_count,
                   hiperspace_page_in_count, hiperspace_page_out_count
            FROM smf_storage
        """)
        result = cursor.fetchone()
        conn.close()
        
        assert result is not None, "No storage record found"
        assert result[0] == 17179869184, "64-bit region size mismatch"
        assert result[1] == 8589934592, "64-bit private area size mismatch"
        assert result[2] == 4294967296, "64-bit common area size mismatch"
        assert result[3] == 34359738368, "MEMLIMIT mismatch"
        assert result[4] == 25, "VIO page-in count mismatch"
        assert result[5] == 15, "VIO page-out count mismatch"
        assert result[6] == 5, "Hiperspace page-in count mismatch"
        assert result[7] == 3, "Hiperspace page-out count mismatch"
