"""Tests for SMF multi-record file parser."""

import pytest
from pathlib import Path
from tools.smf_analyzer.smf_record_parser import SMFFileParser
from tools.smf_analyzer.smf_record_parser.exceptions import UnsupportedRecordTypeError


class TestSMFFileParser:
    """Test suite for SMF multi-record file parser."""
    
    @pytest.fixture
    def smf_file_path(self):
        """Return path to the SMF data file."""
        return Path("examples/SMF30_1.Dat")
    
    def test_get_record_type_summary(self, smf_file_path):
        """Test getting summary of record types in file."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        parser = SMFFileParser(os_version="V3R2")
        summary = parser.get_record_type_summary(str(smf_file_path))
        
        # Should have at least Type 2 and Type 30
        assert 2 in summary
        assert 30 in summary
        
        # Type 2 should have at least 1 record (dump header)
        assert summary[2] >= 1
        
        # Type 30 should have multiple records
        assert summary[30] > 0
        
        # Total should be sum of all types
        total = sum(summary.values())
        assert total > 0
    
    def test_get_supported_types_in_file(self, smf_file_path):
        """Test getting list of supported record types."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        parser = SMFFileParser(os_version="V3R2")
        supported = parser.get_supported_types_in_file(str(smf_file_path))
        
        # Should include Type 2, Type 3, and Type 30 (all are supported)
        assert 2 in supported
        assert 3 in supported
        assert 30 in supported
        
        # Should be sorted
        assert supported == sorted(supported)
    
    def test_parse_file_all_types(self, smf_file_path):
        """Test parsing all supported record types from file."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC")
        
        records = []
        type_2_count = 0
        type_30_count = 0
        
        for record in parser.parse_file(str(smf_file_path)):
            records.append(record)
            
            if record.record_type == 2:
                type_2_count += 1
            elif record.record_type == 30:
                type_30_count += 1
        
        # Should have parsed some records
        assert len(records) > 0
        
        # Should have at least one Type 2 record
        assert type_2_count >= 1
        
        # Should have some Type 30 records
        assert type_30_count > 0
        
        # All records should have required fields
        for record in records:
            assert record.record_type in [2, 3, 30]
            assert record.system_id is not None
            assert record.date is not None
    
    def test_parse_file_specific_types(self, smf_file_path):
        """Test parsing only specific record types."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        # Parse only Type 2 records
        parser = SMFFileParser(
            os_version="V3R2",
            encoding="EBCDIC",
            record_types=[2]
        )
        
        records = list(parser.parse_file(str(smf_file_path)))
        
        # Should have at least one Type 2 record
        assert len(records) >= 1
        
        # All records should be Type 2
        for record in records:
            assert record.record_type == 2
    
    def test_parse_file_to_list(self, smf_file_path):
        """Test parsing file to list."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        parser = SMFFileParser(
            os_version="V3R2",
            record_types=[2]
        )
        
        records = parser.parse_file_to_list(str(smf_file_path))
        
        # Should return a list
        assert isinstance(records, list)
        
        # Should have at least one record
        assert len(records) >= 1
        
        # All should be Type 2
        for record in records:
            assert record.record_type == 2
    
    def test_skip_unsupported_true(self, smf_file_path):
        """Test that unsupported types are skipped when skip_unsupported=True."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        # Parse with skip_unsupported=True (default)
        parser = SMFFileParser(
            os_version="V3R2",
            skip_unsupported=True
        )
        
        # Should not raise any exceptions
        records = list(parser.parse_file(str(smf_file_path)))
        
        # Should have parsed some records
        assert len(records) > 0
        
        # All records should be supported types (2, 3, or 30)
        for record in records:
            assert record.record_type in [2, 3, 30]
    
    def test_parser_caching(self, smf_file_path):
        """Test that parsers are cached and reused."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        parser = SMFFileParser(os_version="V3R2")
        
        # Parse some records
        records = []
        for i, record in enumerate(parser.parse_file(str(smf_file_path))):
            records.append(record)
            if i >= 10:  # Just parse first 10
                break
        
        # Check that parsers were cached
        assert len(parser._parsers) > 0
        
        # Should have cached Type 2 and Type 30 parsers
        if any(r.record_type == 2 for r in records):
            assert 2 in parser._parsers
        if any(r.record_type == 30 for r in records):
            assert 30 in parser._parsers
    
    def test_file_not_found(self):
        """Test error handling for non-existent file."""
        parser = SMFFileParser(os_version="V3R2")
        
        with pytest.raises(FileNotFoundError):
            list(parser.parse_file("nonexistent_file.dat"))
        
        with pytest.raises(FileNotFoundError):
            parser.get_record_type_summary("nonexistent_file.dat")
    
    def test_multiple_record_types_filter(self, smf_file_path):
        """Test filtering multiple specific record types."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        # Parse both Type 2 and Type 30
        parser = SMFFileParser(
            os_version="V3R2",
            record_types=[2, 30]
        )
        
        records = list(parser.parse_file(str(smf_file_path)))
        
        # Should have records
        assert len(records) > 0
        
        # All should be Type 2 or Type 30
        for record in records:
            assert record.record_type in [2, 30]
        
        # Should have both types
        types_found = set(r.record_type for r in records)
        assert 2 in types_found
        assert 30 in types_found
    
    def test_empty_record_types_list(self, smf_file_path):
        """Test that empty record_types list results in no records."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        parser = SMFFileParser(
            os_version="V3R2",
            record_types=[]  # Empty list
        )
        
        records = list(parser.parse_file(str(smf_file_path)))
        
        # Should have no records
        assert len(records) == 0
    
    def test_record_type_summary_counts(self, smf_file_path):
        """Test that record type summary counts match actual parsing."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        parser = SMFFileParser(os_version="V3R2")
        
        # Get summary
        summary = parser.get_record_type_summary(str(smf_file_path))
        
        # Parse only Type 2 records
        type2_parser = SMFFileParser(os_version="V3R2", record_types=[2])
        type2_records = list(type2_parser.parse_file(str(smf_file_path)))
        
        # Count should match
        assert len(type2_records) == summary[2]
