"""Unit tests for SMF Type 100 V10 parser.

Feature: db2-versioned-smf-parsers
Tests: Requirements 3.1, 3.5, 9.1
"""

import pytest
import struct
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf100_parser_v10 import SMF100ParserV10
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_smf100_v10_record(
    ifcid: int = 1,
    record_length: int = 300,
    system_id: str = "SYS1",
    subsystem_id: str = "DB2P"
) -> bytes:
    """Create a synthetic SMF Type 100 V10 record for testing.
    
    Args:
        ifcid: IFCID value (1 for system stats, 2 for database stats)
        record_length: Total record length
        system_id: System identifier (4 chars)
        subsystem_id: Subsystem identifier (4 chars)
        
    Returns:
        Synthetic SMF Type 100 record as bytes
    """
    # Ensure record length matches actual size
    record = bytearray(record_length + 1)  # Add 1 to account for indexing
    
    # SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0)  # System indicator
    struct.pack_into('B', record, 5, 100)  # Record type
    
    # Timestamp (4 bytes at offset 6) - packed decimal time
    struct.pack_into('>I', record, 6, 0x12345678)
    
    # Date (4 bytes at offset 10) - packed decimal date
    struct.pack_into('>I', record, 10, 0x20240115)
    
    # System ID (4 bytes at offset 14)
    record[14:18] = system_id.ljust(4).encode('cp037')
    
    # Subsystem ID (4 bytes at offset 18)
    record[18:22] = subsystem_id.ljust(4).encode('cp037')
    
    # Subtype (2 bytes at offset 22)
    struct.pack_into('>H', record, 22, ifcid)
    
    # Product section triplet (at offset 28)
    product_offset = 136  # After self-defining section
    struct.pack_into('>I', record, 28, product_offset)  # Offset
    struct.pack_into('>H', record, 32, 100)  # Length
    struct.pack_into('>H', record, 34, 1)  # Count
    
    # Self-defining section triplets (starting at offset 36)
    # For IFCID 1 (QWS0 structure)
    if ifcid == 1:
        # QWSA triplet (R1)
        struct.pack_into('>I', record, 36, 240)  # Offset
        struct.pack_into('>H', record, 40, 44)  # Length
        struct.pack_into('>H', record, 42, 1)  # Number
        
        # QWSB triplet (R2)
        struct.pack_into('>I', record, 44, 284)  # Offset
        struct.pack_into('>H', record, 48, 28)  # Length
        struct.pack_into('>H', record, 50, 1)  # Number
    
    # QWHS standard header (at product_offset)
    struct.pack_into('>H', record, product_offset, 92)  # Header length
    struct.pack_into('B', record, product_offset + 2, 1)  # Header type (QWHS)
    struct.pack_into('B', record, product_offset + 3, 0xDB)  # Resource manager ID (DB2)
    struct.pack_into('>H', record, product_offset + 4, ifcid)  # IFCID
    struct.pack_into('>H', record, product_offset + 6, 0x0A00)  # Release number (V10)
    struct.pack_into('B', record, product_offset + 8, 0)  # Num self-defining areas
    struct.pack_into('B', record, product_offset + 9, 0)  # Release indicator
    struct.pack_into('>I', record, product_offset + 10, 0)  # ACE address
    
    # Subsystem name (4 bytes at product_offset + 14)
    record[product_offset + 14:product_offset + 18] = subsystem_id.ljust(4).encode('cp037')
    
    # Store clock (8 bytes at product_offset + 18)
    struct.pack_into('>Q', record, product_offset + 18, 0x1234567890ABCDEF)
    
    # IFCID sequence (4 bytes at product_offset + 26)
    struct.pack_into('>I', record, product_offset + 26, 12345)
    
    # Destination sequence (4 bytes at product_offset + 30)
    struct.pack_into('>I', record, product_offset + 30, 67890)
    
    # Trace number mask (4 bytes at product_offset + 34)
    struct.pack_into('>I', record, product_offset + 34, 0xFFFFFFFF)
    
    # Local location name (16 bytes at product_offset + 38)
    record[product_offset + 38:product_offset + 54] = b'LOCATION1       '
    
    # LUWID (24 bytes at product_offset + 54)
    record[product_offset + 54:product_offset + 78] = b'LUWID123456789012345678'
    
    # Network ID (8 bytes at product_offset + 78)
    record[product_offset + 78:product_offset + 86] = b'NETID123'
    
    # LUNAME (8 bytes at product_offset + 86)
    record[product_offset + 86:product_offset + 94] = b'LUNAME12'
    
    # Trim to exact length
    return bytes(record[:record_length])


class TestSMF100ParserV10:
    """Unit tests for SMF Type 100 V10 parser."""
    
    def test_parse_basic_structure(self):
        """
        Test parsing basic Type 100 V10 record structure.
        
        Requirements: 3.1, 3.5
        """
        # Create test record
        record_data = create_smf100_v10_record(ifcid=1)
        
        # Parse record
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify basic structure
        assert result.record_type == 100
        assert result.subtype == 1  # IFCID
        assert result.system_id.strip() == "SYS1"
        assert 'smf_header' in result.header
        assert 'qwhs_header' in result.header
        assert 'self_defining_section' in result.header
    
    def test_parse_smf_header_fields(self):
        """
        Test that all SMF header fields are extracted.
        
        Requirements: 3.1, 3.5
        """
        record_data = create_smf100_v10_record()
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        smf_header = result.header['smf_header']
        
        # Verify all expected fields are present
        assert 'record_length' in smf_header
        assert 'record_type' in smf_header
        assert 'system_id' in smf_header
        assert 'subsystem_id' in smf_header
        assert 'timestamp' in smf_header
        assert 'date' in smf_header
        
        # Verify values
        assert smf_header['record_type'] == 100
        assert smf_header['system_id'].strip() == "SYS1"
        assert smf_header['subsystem_id'].strip() == "DB2P"
    
    def test_parse_qwhs_header_fields(self):
        """
        Test that all QWHS header fields are extracted.
        
        Requirements: 3.1, 3.5
        """
        record_data = create_smf100_v10_record(ifcid=1)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        qwhs = result.header['qwhs_header']
        
        # Verify all expected fields are present
        assert 'header_length' in qwhs
        assert 'header_type' in qwhs
        assert 'resource_manager_id' in qwhs
        assert 'ifcid' in qwhs
        assert 'release_number' in qwhs
        assert 'subsystem_name' in qwhs
        assert 'store_clock' in qwhs
        assert 'ifcid_sequence' in qwhs
        
        # Verify values
        assert qwhs['header_type'] == 1  # QWHS
        assert qwhs['resource_manager_id'] == 0xDB  # DB2
        assert qwhs['ifcid'] == 1
        assert qwhs['release_number'] == 0x0A00  # V10
        assert qwhs['subsystem_name'].strip() == "DB2P"
    
    def test_parse_self_defining_section_ifcid1(self):
        """
        Test parsing self-defining section for IFCID 1 (System Services).
        
        Requirements: 3.1, 3.5
        """
        record_data = create_smf100_v10_record(ifcid=1)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        sds = result.header['self_defining_section']
        
        # Verify structure
        assert sds['ifcid'] == 1
        assert 'triplets' in sds
        
        # Verify QWS0 triplets are present
        triplets = sds['triplets']
        assert 'product_section' in triplets
        assert 'qwsa' in triplets  # Control address spaces
        assert 'qwsb' in triplets  # IFC destination
        assert 'qwsc' in triplets  # IFCID statistics
        assert 'q3st' in triplets  # Subsystem support
        assert 'q9st' in triplets  # Command statistics
    
    def test_parse_self_defining_section_ifcid2(self):
        """
        Test parsing self-defining section for IFCID 2 (Database Services).
        
        Requirements: 3.1, 3.5
        """
        record_data = create_smf100_v10_record(ifcid=2)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        sds = result.header['self_defining_section']
        
        # Verify structure
        assert sds['ifcid'] == 2
        assert 'triplets' in sds
        
        # Verify QWS1 triplets are present
        triplets = sds['triplets']
        assert 'product_section' in triplets
        assert 'qxst' in triplets  # SQL statistics
        assert 'qtst' in triplets  # Service controller
        assert 'qbst' in triplets  # Buffer manager
        assert 'qist' in triplets  # Data manager
        assert 'qtxa' in triplets  # Locking
    
    def test_parse_data_sections(self):
        """
        Test that data sections are identified when present.
        
        Requirements: 3.1, 3.5
        """
        record_data = create_smf100_v10_record(ifcid=1)
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify data sections are captured
        if 'data_sections' in result.header:
            data_sections = result.header['data_sections']
            
            # Check that sections are present
            # Note: Sections may be either:
            # 1. Parsed with field-level data (e.g., qwsa, qwsb, qwsd, qvls for IFCID 1)
            # 2. Basic metadata only (offset, length, count, exists)
            for section_name, section_data in data_sections.items():
                # Parsed sections have field-level data
                if 'offset' in section_data and 'length' in section_data:
                    # Basic metadata format
                    assert 'count' in section_data
                    assert 'exists' in section_data
                    assert section_data['exists'] is True
                else:
                    # Field-level parsed format - just verify it's a dict with data
                    assert isinstance(section_data, dict)
                    assert len(section_data) > 0
    
    def test_error_handling_invalid_record_type(self):
        """
        Test error handling for invalid record type.
        
        Requirements: 3.1, 9.1
        """
        # Create record with wrong type
        record_data = create_smf100_v10_record()
        record_data = bytearray(record_data)
        record_data[5] = 101  # Change to Type 101
        record_data = bytes(record_data)
        
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        # Verify error message mentions record type
        assert "record type" in str(exc_info.value).lower()
    
    def test_error_handling_missing_product_section(self):
        """
        Test error handling when product section is missing.
        
        Requirements: 3.1, 9.1
        """
        # Create record with no product section
        record_data = create_smf100_v10_record()
        record_data = bytearray(record_data)
        
        # Set product section count to 0
        struct.pack_into('>H', record_data, 34, 0)
        record_data = bytes(record_data)
        
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        # Verify error message mentions product section
        assert "product section" in str(exc_info.value).lower()
    
    def test_error_handling_short_record(self):
        """
        Test error handling for record that is too short.
        
        Requirements: 3.1, 9.1
        """
        # Create very short record
        record_data = b'\x00' * 50
        
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises((ValidationError, IndexError, struct.error)):
            parser.parse(record_data)
    
    def test_parse_with_different_system_ids(self):
        """
        Test parsing records with different system identifiers.
        
        Requirements: 3.1, 3.5
        """
        system_ids = ["SYS1", "PROD", "TEST", "DEV1"]
        
        for sys_id in system_ids:
            record_data = create_smf100_v10_record(system_id=sys_id)
            parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
            result = parser.parse(record_data)
            
            assert result.system_id.strip() == sys_id
            assert result.header['smf_header']['system_id'].strip() == sys_id
    
    def test_parse_with_different_subsystem_ids(self):
        """
        Test parsing records with different subsystem identifiers.
        
        Requirements: 3.1, 3.5
        """
        subsystem_ids = ["DB2P", "DB2T", "DSN1", "DSN2"]
        
        for subsys_id in subsystem_ids:
            record_data = create_smf100_v10_record(subsystem_id=subsys_id)
            parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
            result = parser.parse(record_data)
            
            qwhs = result.header['qwhs_header']
            assert qwhs['subsystem_name'].strip() == subsys_id
    
    def test_db2_version_attribute(self):
        """
        Test that parser has correct DB2 version attribute.
        
        Requirements: 3.1
        """
        parser = SMF100ParserV10(BaseRecordParser(encoding='EBCDIC'))
        assert parser.db2_version == "V10"
