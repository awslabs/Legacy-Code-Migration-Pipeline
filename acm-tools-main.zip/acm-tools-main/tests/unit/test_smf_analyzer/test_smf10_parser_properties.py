"""Property-based tests for SMF Type 10 parser.

Feature: smf-parser-expansion
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers import SMF10ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_type10_record(
    system_id: str = "SYS1",
    job_name: str = "TESTJOB",
    user_id: str = "USER001",
    is_system_task: bool = False,
    num_devices: int = 3,
    device_classes: list = None,
    unit_types: list = None,
    device_numbers: list = None
) -> bytes:
    """Create a synthetic Type 10 record for testing.
    
    Args:
        system_id: 4-character system ID
        job_name: 8-character job name (blank for system tasks)
        user_id: 8-character user ID (blank for system tasks)
        is_system_task: If True, create record for system task
        num_devices: Number of devices to include
        device_classes: List of device classes (0-255)
        unit_types: List of unit types (0-255)
        device_numbers: List of device numbers (0-65535)
        
    Returns:
        Binary SMF Type 10 record
    """
    # Calculate record length: header (44 bytes) + devices (4 bytes each)
    record_length = 44 + (num_devices * 4)
    record = bytearray(record_length)
    
    # Standard SMF header (18 bytes)
    struct.pack_into('>H', record, 0, record_length)  # SMF10LEN - Record length
    struct.pack_into('>H', record, 2, 0)  # SMF10SEG - Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # SMF10FLG - System indicator
    struct.pack_into('B', record, 5, 10)  # SMF10RTY - Record type = 10
    struct.pack_into('>I', record, 6, 36000)  # SMF10TME - Timestamp (10:00:00.00)
    
    # Date (packed decimal 0cyydddF) - 2025001F (Jan 1, 2025)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF10DTE
    
    # System ID (EBCDIC)
    sys_id_bytes = system_id.ljust(4).encode('cp037')[:4]
    record[14:18] = sys_id_bytes  # SMF10SID
    
    # Job identification fields (offsets 18-41)
    if is_system_task:
        # For system tasks: blank job name, zero timestamps
        # EBCDIC space is 0x40, not ASCII 0x20
        record[18:26] = bytes([0x40] * 8)  # SMF10JBN - blank job name (EBCDIC spaces)
        struct.pack_into('>I', record, 26, 0)  # SMF10RST - zero timestamp
        record[30:34] = bytes([0x00, 0x00, 0x00, 0x0F])  # SMF10RSD - zero date
        record[34:42] = bytes([0x40] * 8)  # SMF10UIF - blank user ID (EBCDIC spaces)
    else:
        # For regular jobs: actual job name and timestamps
        job_name_bytes = job_name.ljust(8).encode('cp037')[:8]
        record[18:26] = job_name_bytes  # SMF10JBN
        struct.pack_into('>I', record, 26, 32400)  # SMF10RST - 09:00:00.00
        record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF10RSD - 2025001F
        user_id_bytes = user_id.ljust(8).encode('cp037')[:8]
        record[34:42] = user_id_bytes  # SMF10UIF
    
    # Length of rest of record (including this field)
    rest_length = 2 + (num_devices * 4)
    struct.pack_into('>H', record, 42, rest_length)  # SMF10LN
    
    # Device data section (starts at offset 44)
    # Each device is 4 bytes: 2 bytes device type, 2 bytes device number
    for i in range(num_devices):
        offset = 44 + (i * 4)
        
        # Get device class and unit type
        device_class = device_classes[i] if device_classes and i < len(device_classes) else (i % 256)
        unit_type = unit_types[i] if unit_types and i < len(unit_types) else ((i * 10) % 256)
        device_number = device_numbers[i] if device_numbers and i < len(device_numbers) else (i + 100)
        
        # Pack device class and unit type into 2 bytes (SMF10DUT)
        device_type_raw = (device_class << 8) | unit_type
        struct.pack_into('>H', record, offset, device_type_raw)
        
        # Pack device number (SMF10CUA)
        struct.pack_into('>H', record, offset + 2, device_number)
    
    return bytes(record)


# Strategies for generating test data
ebcdic_chars = st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

system_ids = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=4
).map(lambda x: x.ljust(4)[:4])

job_names = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=8
).map(lambda x: x.ljust(8)[:8])

user_ids = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=8
).map(lambda x: x.ljust(8)[:8])

# Generate device counts (1-50 devices is reasonable for testing)
device_counts = st.integers(min_value=1, max_value=50)

# Generate device classes, unit types, and device numbers
device_classes_list = st.lists(
    st.integers(min_value=0, max_value=255),
    min_size=1,
    max_size=50
)

unit_types_list = st.lists(
    st.integers(min_value=0, max_value=255),
    min_size=1,
    max_size=50
)

device_numbers_list = st.lists(
    st.integers(min_value=0, max_value=65535),
    min_size=1,
    max_size=50
)


class TestSMF10ParserProperties:
    """Property-based tests for SMF Type 10 parser."""
    
    @settings(max_examples=100)
    @given(
        system_id=system_ids,
        job_name=job_names,
        user_id=user_ids,
        num_devices=device_counts,
        device_classes=device_classes_list,
        unit_types=unit_types_list,
        device_numbers=device_numbers_list
    )
    def test_property_1_field_extraction_completeness(
        self, system_id, job_name, user_id, num_devices, device_classes, unit_types, device_numbers
    ):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.9**
        
        For any SMF Type 10 record, parsing should extract all standard header fields
        (record_type, subtype, system_id, timestamp, date, record_length) and all
        documented type-specific fields including job identification and device data.
        """
        # Ensure lists are long enough
        device_classes = device_classes[:num_devices] + [0] * max(0, num_devices - len(device_classes))
        unit_types = unit_types[:num_devices] + [0] * max(0, num_devices - len(unit_types))
        device_numbers = device_numbers[:num_devices] + [100] * max(0, num_devices - len(device_numbers))
        
        # Create test record
        record_data = create_type10_record(
            system_id=system_id,
            job_name=job_name,
            user_id=user_id,
            is_system_task=False,
            num_devices=num_devices,
            device_classes=device_classes,
            unit_types=unit_types,
            device_numbers=device_numbers
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header fields are present
        assert parsed.record_type == 10, "record_type should be 10"
        assert parsed.subtype == 0, "subtype should be 0 (Type 10 has no subtypes)"
        assert parsed.system_id is not None, "system_id should be extracted"
        assert parsed.timestamp is not None, "timestamp should be extracted"
        assert parsed.date is not None, "date should be extracted"
        assert parsed.record_length == 44 + (num_devices * 4), "record_length should match"
        
        # Verify header section contains Type 10 specific fields
        assert parsed.header is not None, "header section should be present"
        header = parsed.header
        
        assert 'record_length' in header, "record_length should be extracted"
        assert 'segment_descriptor' in header, "segment_descriptor should be extracted"
        assert 'system_indicator' in header, "system_indicator should be extracted"
        assert 'record_type' in header, "record_type should be extracted"
        assert 'timestamp' in header, "timestamp should be extracted"
        assert 'date' in header, "date should be extracted"
        assert 'system_id' in header, "system_id should be extracted"
        assert 'rest_of_record_length' in header, "rest_of_record_length should be extracted"
        
        # Verify identification section contains job information
        assert parsed.identification is not None, "identification section should be present"
        job_info = parsed.identification
        
        assert 'job_name' in job_info, "job_name should be present"
        assert 'reader_timestamp' in job_info, "reader_timestamp should be present"
        assert 'reader_date' in job_info, "reader_date should be present"
        assert 'user_id' in job_info, "user_id should be present"
        assert 'is_system_task' in job_info, "is_system_task flag should be present"
        
        # For regular jobs, verify job info is not blank
        assert job_info['is_system_task'] is False, "should not be a system task"
        assert job_info['job_name'].strip() != '', "job_name should not be blank"
        
        # Verify I/O activity section contains device data
        assert parsed.io_activity is not None, "io_activity section should be present"
        io_data = parsed.io_activity
        
        assert 'devices' in io_data, "devices list should be present"
        assert 'device_count' in io_data, "device_count should be present"
        
        devices = io_data['devices']
        assert len(devices) == num_devices, f"should have {num_devices} devices"
        
        # Verify each device has required fields
        for i, device in enumerate(devices):
            assert 'device_class' in device, f"device {i} should have device_class"
            assert 'unit_type' in device, f"device {i} should have unit_type"
            assert 'device_number' in device, f"device {i} should have device_number"
            assert 'device_number_hex' in device, f"device {i} should have device_number_hex"
            assert 'is_virtual_io' in device, f"device {i} should have is_virtual_io flag"
            
            # Verify values match input
            assert device['device_class'] == device_classes[i], \
                f"device {i} class should match input"
            assert device['unit_type'] == unit_types[i], \
                f"device {i} unit_type should match input"
            assert device['device_number'] == device_numbers[i], \
                f"device {i} device_number should match input"
            
            # Verify hex format
            expected_hex = f"0x{device_numbers[i]:04X}"
            assert device['device_number_hex'] == expected_hex, \
                f"device {i} hex format should be correct"
            
            # Verify VIO detection
            is_vio = (device_classes[i] == 0 and unit_types[i] == 0 and device_numbers[i] == 0x7FFF)
            assert device['is_virtual_io'] == is_vio, \
                f"device {i} VIO detection should be correct"
    
    @settings(max_examples=50)
    @given(system_id=system_ids)
    def test_property_1_system_task_detection(self, system_id):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.9**
        
        For any SMF Type 10 record for a system task (blank job name, zero timestamps),
        the parser should correctly identify it with the is_system_task flag.
        """
        # Create a record for a system task
        num_devices = 2
        device_classes = [1, 2]
        unit_types = [10, 20]
        device_numbers = [100, 200]
        
        record_data = create_type10_record(
            system_id=system_id,
            is_system_task=True,
            num_devices=num_devices,
            device_classes=device_classes,
            unit_types=unit_types,
            device_numbers=device_numbers
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify system task detection
        job_info = parsed.identification
        assert job_info['is_system_task'] is True, "should be identified as system task"
        assert job_info['job_name'].strip() == '', "job_name should be blank"
        assert job_info['reader_timestamp'] == '00:00:00.00', "reader_timestamp should be zero"
        # Note: Zero date (0x0000000F) parses to 1899-12-31
        from datetime import date
        assert job_info['reader_date'] == date(1899, 12, 31), "reader_date should be zero date"
    
    @settings(max_examples=50)
    @given(system_id=system_ids)
    def test_property_1_virtual_io_detection(self, system_id):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.9**
        
        For any SMF Type 10 record containing Virtual I/O devices (device class=0,
        unit type=0, device number=0x7FFF), the parser should correctly identify
        them with the is_virtual_io flag.
        """
        # Create a record with one VIO device and one regular device
        num_devices = 2
        device_classes = [0, 5]  # VIO, then regular
        unit_types = [0, 10]  # VIO, then regular
        device_numbers = [0x7FFF, 0x0100]  # VIO marker, then regular
        
        record_data = create_type10_record(
            system_id=system_id,
            job_name="TESTJOB",
            user_id="USER001",
            is_system_task=False,
            num_devices=num_devices,
            device_classes=device_classes,
            unit_types=unit_types,
            device_numbers=device_numbers
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify device data
        devices = parsed.io_activity['devices']
        assert len(devices) == 2, "should have 2 devices"
        
        # First device should be VIO
        assert devices[0]['is_virtual_io'] is True, "first device should be VIO"
        assert devices[0]['device_class'] == 0, "VIO device class should be 0"
        assert devices[0]['unit_type'] == 0, "VIO unit type should be 0"
        assert devices[0]['device_number'] == 0x7FFF, "VIO device number should be 0x7FFF"
        
        # Second device should not be VIO
        assert devices[1]['is_virtual_io'] is False, "second device should not be VIO"
        assert devices[1]['device_class'] == 5, "regular device class should match"
        assert devices[1]['unit_type'] == 10, "regular unit type should match"
        assert devices[1]['device_number'] == 0x0100, "regular device number should match"
