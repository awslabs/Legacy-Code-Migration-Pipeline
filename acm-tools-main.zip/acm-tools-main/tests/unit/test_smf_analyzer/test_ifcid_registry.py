"""Unit tests for IFCID102Registry.

Feature: db2-versioned-smf-parsers (Phase 2)
Tests: IFCID registry functionality for Type 102 parsers
Reference: TYPE_102_PARSING_REQUIREMENTS.md Section 9
"""

import pytest
from tools.smf_analyzer.smf_record_parser.parsers.ifcid_registry import IFCID102Registry


# Mock parser functions for testing
def mock_parser_365_v11(record_data, self_defining_section):
    """Mock parser for IFCID 365 V11."""
    return {'ifcid': 365, 'version': 'V11', 'data': 'mock_v11'}


def mock_parser_365_v12(record_data, self_defining_section):
    """Mock parser for IFCID 365 V12."""
    return {'ifcid': 365, 'version': 'V12', 'data': 'mock_v12'}


def mock_parser_365_generic(record_data, self_defining_section):
    """Mock version-agnostic parser for IFCID 365."""
    return {'ifcid': 365, 'version': 'ALL', 'data': 'mock_generic'}


def mock_parser_370(record_data, self_defining_section):
    """Mock parser for IFCID 370."""
    return {'ifcid': 370, 'data': 'mock_370'}


class TestIFCIDRegistryBasics:
    """Test basic registry operations."""
    
    def test_registry_initialization(self):
        """Test registry initializes empty."""
        registry = IFCID102Registry()
        assert len(registry) == 0
        assert registry.list_registered_ifcids() == []
    
    def test_registry_repr(self):
        """Test string representation."""
        registry = IFCID102Registry()
        assert "IFCID102Registry" in repr(registry)
        assert "parsers=0" in repr(registry)


class TestVersionSpecificRegistration:
    """Test registration of version-specific parsers."""
    
    def test_register_version_specific_parser(self):
        """Test registration of version-specific IFCID parser."""
        registry = IFCID102Registry()
        
        # Register V11 parser
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Verify registration
        assert len(registry) == 1
        assert (365, "V11") in registry.list_registered_ifcids()
    
    def test_register_multiple_versions_same_ifcid(self):
        """Test registering multiple versions for same IFCID."""
        registry = IFCID102Registry()
        
        # Register V11 and V12 parsers for IFCID 365
        registry.register(365, "V11", mock_parser_365_v11)
        registry.register(365, "V12", mock_parser_365_v12)
        
        # Verify both registered
        assert len(registry) == 2
        registered = registry.list_registered_ifcids()
        assert (365, "V11") in registered
        assert (365, "V12") in registered
    
    def test_register_multiple_ifcids(self):
        """Test registering multiple different IFCIDs."""
        registry = IFCID102Registry()
        
        # Register different IFCIDs
        registry.register(365, "V11", mock_parser_365_v11)
        registry.register(370, "V11", mock_parser_370)
        
        # Verify both registered
        assert len(registry) == 2
        registered = registry.list_registered_ifcids()
        assert (365, "V11") in registered
        assert (370, "V11") in registered
    
    def test_overwrite_existing_parser_logs_warning(self, caplog):
        """Test overwriting existing parser logs warning."""
        import logging
        registry = IFCID102Registry()
        
        # Register initial parser
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Overwrite with new parser
        with caplog.at_level(logging.WARNING):
            registry.register(365, "V11", mock_parser_365_v12)
        
        # Verify warning logged
        assert any("Overwriting" in record.message for record in caplog.records)
        assert any("365" in record.message for record in caplog.records)
        
        # Verify new parser is registered
        parser = registry.get_parser(365, "V11")
        assert parser == mock_parser_365_v12


class TestVersionAgnosticRegistration:
    """Test registration of version-agnostic parsers."""
    
    def test_register_version_agnostic_parser(self):
        """Test registration of version-agnostic IFCID parser."""
        registry = IFCID102Registry()
        
        # Register version-agnostic parser
        registry.register(365, "ALL", mock_parser_365_generic)
        
        # Verify registration
        assert len(registry) == 1
        assert (365, "ALL") in registry.list_registered_ifcids()
    
    def test_version_agnostic_and_specific_coexist(self):
        """Test version-agnostic and version-specific parsers can coexist."""
        registry = IFCID102Registry()
        
        # Register both types
        registry.register(365, "ALL", mock_parser_365_generic)
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Verify both registered
        assert len(registry) == 2
        registered = registry.list_registered_ifcids()
        assert (365, "ALL") in registered
        assert (365, "V11") in registered


class TestParserLookup:
    """Test parser lookup with exact match and fallback."""
    
    def test_lookup_exact_version_match(self):
        """Test parser lookup with exact version match."""
        registry = IFCID102Registry()
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Lookup exact match
        parser = registry.get_parser(365, "V11")
        
        # Verify correct parser returned
        assert parser == mock_parser_365_v11
        assert parser is not None
    
    def test_lookup_version_agnostic_fallback(self):
        """Test parser lookup falls back to version-agnostic."""
        registry = IFCID102Registry()
        
        # Register only version-agnostic parser
        registry.register(365, "ALL", mock_parser_365_generic)
        
        # Lookup V12 (not registered, should fallback to ALL)
        parser = registry.get_parser(365, "V12")
        
        # Verify fallback to version-agnostic
        assert parser == mock_parser_365_generic
    
    def test_lookup_prefers_exact_over_agnostic(self):
        """Test exact version match preferred over version-agnostic."""
        registry = IFCID102Registry()
        
        # Register both
        registry.register(365, "ALL", mock_parser_365_generic)
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Lookup V11 should return exact match
        parser = registry.get_parser(365, "V11")
        assert parser == mock_parser_365_v11
        
        # Lookup V12 should fallback to ALL
        parser = registry.get_parser(365, "V12")
        assert parser == mock_parser_365_generic
    
    def test_lookup_unsupported_ifcid_returns_none(self):
        """Test parser lookup for unsupported IFCID returns None."""
        registry = IFCID102Registry()
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Lookup unsupported IFCID
        parser = registry.get_parser(999, "V11")
        
        # Verify None returned
        assert parser is None
    
    def test_lookup_unsupported_version_no_fallback_returns_none(self):
        """Test lookup for unsupported version with no fallback returns None."""
        registry = IFCID102Registry()
        
        # Register only V11
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Lookup V12 (no fallback available)
        parser = registry.get_parser(365, "V12")
        
        # Verify None returned
        assert parser is None


class TestIsSupportedMethod:
    """Test is_supported() method."""
    
    def test_is_supported_exact_match(self):
        """Test is_supported returns True for exact match."""
        registry = IFCID102Registry()
        registry.register(365, "V11", mock_parser_365_v11)
        
        assert registry.is_supported(365, "V11") is True
    
    def test_is_supported_with_fallback(self):
        """Test is_supported returns True when fallback available."""
        registry = IFCID102Registry()
        registry.register(365, "ALL", mock_parser_365_generic)
        
        # V12 not registered but ALL is available
        assert registry.is_supported(365, "V12") is True
    
    def test_is_supported_unsupported_ifcid(self):
        """Test is_supported returns False for unsupported IFCID."""
        registry = IFCID102Registry()
        registry.register(365, "V11", mock_parser_365_v11)
        
        assert registry.is_supported(999, "V11") is False
    
    def test_is_supported_unsupported_version(self):
        """Test is_supported returns False when no fallback available."""
        registry = IFCID102Registry()
        registry.register(365, "V11", mock_parser_365_v11)
        
        # V12 not registered and no ALL fallback
        assert registry.is_supported(365, "V12") is False


class TestListRegisteredIFCIDs:
    """Test list_registered_ifcids() method."""
    
    def test_list_all_registered_ifcids(self):
        """Test listing all registered IFCIDs."""
        registry = IFCID102Registry()
        
        # Register multiple IFCIDs and versions
        registry.register(365, "V11", mock_parser_365_v11)
        registry.register(365, "V12", mock_parser_365_v12)
        registry.register(370, "V11", mock_parser_370)
        
        # Get all registered
        registered = registry.list_registered_ifcids()
        
        # Verify all present and sorted
        assert len(registered) == 3
        assert registered == [(365, "V11"), (365, "V12"), (370, "V11")]
    
    def test_list_registered_ifcids_filtered_by_version(self):
        """Test listing IFCIDs filtered by version."""
        registry = IFCID102Registry()
        
        # Register multiple versions
        registry.register(365, "V11", mock_parser_365_v11)
        registry.register(365, "V12", mock_parser_365_v12)
        registry.register(365, "ALL", mock_parser_365_generic)
        registry.register(370, "V11", mock_parser_370)
        
        # Get V11 IFCIDs (should include V11 and ALL)
        v11_registered = registry.list_registered_ifcids("V11")
        
        # Verify correct filtering
        assert (365, "V11") in v11_registered
        assert (365, "ALL") in v11_registered
        assert (370, "V11") in v11_registered
        assert (365, "V12") not in v11_registered
    
    def test_list_empty_registry(self):
        """Test listing from empty registry."""
        registry = IFCID102Registry()
        
        assert registry.list_registered_ifcids() == []
        assert registry.list_registered_ifcids("V11") == []


class TestGetSupportedIFCIDs:
    """Test get_supported_ifcids() method."""
    
    def test_get_supported_ifcids_for_version(self):
        """Test getting unique IFCID numbers for a version."""
        registry = IFCID102Registry()
        
        # Register multiple IFCIDs
        registry.register(365, "V11", mock_parser_365_v11)
        registry.register(370, "V11", mock_parser_370)
        registry.register(365, "V12", mock_parser_365_v12)
        
        # Get V11 IFCIDs
        v11_ifcids = registry.get_supported_ifcids("V11")
        
        # Verify unique IFCIDs
        assert v11_ifcids == [365, 370]
    
    def test_get_supported_ifcids_includes_version_agnostic(self):
        """Test supported IFCIDs includes version-agnostic parsers."""
        registry = IFCID102Registry()
        
        # Register version-agnostic and specific
        registry.register(365, "ALL", mock_parser_365_generic)
        registry.register(370, "V11", mock_parser_370)
        
        # Get V11 IFCIDs (should include 365 from ALL)
        v11_ifcids = registry.get_supported_ifcids("V11")
        
        assert 365 in v11_ifcids
        assert 370 in v11_ifcids
    
    def test_get_supported_ifcids_empty(self):
        """Test getting supported IFCIDs from empty registry."""
        registry = IFCID102Registry()
        
        assert registry.get_supported_ifcids("V11") == []


class TestGetVersionsForIFCID:
    """Test get_versions_for_ifcid() method."""
    
    def test_get_versions_for_ifcid(self):
        """Test getting versions that support a specific IFCID."""
        registry = IFCID102Registry()
        
        # Register multiple versions for IFCID 365
        registry.register(365, "V11", mock_parser_365_v11)
        registry.register(365, "V12", mock_parser_365_v12)
        registry.register(365, "ALL", mock_parser_365_generic)
        
        # Get versions
        versions = registry.get_versions_for_ifcid(365)
        
        # Verify all versions present and sorted
        assert versions == ["ALL", "V11", "V12"]
    
    def test_get_versions_for_unsupported_ifcid(self):
        """Test getting versions for unsupported IFCID."""
        registry = IFCID102Registry()
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Get versions for unsupported IFCID
        versions = registry.get_versions_for_ifcid(999)
        
        assert versions == []


class TestClearMethod:
    """Test clear() method."""
    
    def test_clear_registry(self):
        """Test clearing all registered parsers."""
        registry = IFCID102Registry()
        
        # Register parsers
        registry.register(365, "V11", mock_parser_365_v11)
        registry.register(370, "V11", mock_parser_370)
        
        # Verify registered
        assert len(registry) == 2
        
        # Clear
        registry.clear()
        
        # Verify empty
        assert len(registry) == 0
        assert registry.list_registered_ifcids() == []


class TestInputValidation:
    """Test input validation for registry methods."""
    
    def test_register_invalid_ifcid_type(self):
        """Test registering with invalid IFCID type raises error."""
        registry = IFCID102Registry()
        
        with pytest.raises(ValueError, match="IFCID must be a non-negative integer"):
            registry.register("365", "V11", mock_parser_365_v11)
    
    def test_register_negative_ifcid(self):
        """Test registering with negative IFCID raises error."""
        registry = IFCID102Registry()
        
        with pytest.raises(ValueError, match="IFCID must be a non-negative integer"):
            registry.register(-1, "V11", mock_parser_365_v11)
    
    def test_register_invalid_version_type(self):
        """Test registering with invalid version type raises error."""
        registry = IFCID102Registry()
        
        with pytest.raises(ValueError, match="Version must be a non-empty string"):
            registry.register(365, 11, mock_parser_365_v11)
    
    def test_register_empty_version(self):
        """Test registering with empty version raises error."""
        registry = IFCID102Registry()
        
        with pytest.raises(ValueError, match="Version must be a non-empty string"):
            registry.register(365, "", mock_parser_365_v11)
    
    def test_register_non_callable_parser(self):
        """Test registering non-callable parser raises error."""
        registry = IFCID102Registry()
        
        with pytest.raises(ValueError, match="Parser function must be callable"):
            registry.register(365, "V11", "not_a_function")


class TestParserFunctionExecution:
    """Test that registered parser functions can be executed."""
    
    def test_execute_registered_parser(self):
        """Test executing a registered parser function."""
        registry = IFCID102Registry()
        registry.register(365, "V11", mock_parser_365_v11)
        
        # Get parser
        parser = registry.get_parser(365, "V11")
        
        # Execute parser
        result = parser(b"mock_data", {'triplets': {}})
        
        # Verify result
        assert result['ifcid'] == 365
        assert result['version'] == 'V11'
        assert result['data'] == 'mock_v11'
    
    def test_execute_version_agnostic_parser(self):
        """Test executing version-agnostic parser."""
        registry = IFCID102Registry()
        registry.register(365, "ALL", mock_parser_365_generic)
        
        # Get parser for V12 (should fallback to ALL)
        parser = registry.get_parser(365, "V12")
        
        # Execute parser
        result = parser(b"mock_data", {'triplets': {}})
        
        # Verify result
        assert result['ifcid'] == 365
        assert result['version'] == 'ALL'
        assert result['data'] == 'mock_generic'
