"""Unit tests for cost analysis queries."""

import pytest
from tools.smf_analyzer.smf_queries.queries.cost_queries import (
    MIPSCostQuery,
    MSUCostQuery,
    AWSCostQuery,
    MigrationROIQuery
)


class TestMIPSCostQuery:
    """Test MIPSCostQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = MIPSCostQuery()
        
        assert query.name == "mips_cost"
        assert query.description
        assert query.category == "Cost Analysis"
        assert query.purpose
        assert query.record_types == [30]
        assert query.migration_impact
        assert query.requires_inventory is False
    
    def test_configuration_parameters(self):
        """Test that query defines all required configuration parameters."""
        query = MIPSCostQuery()
        params = query.configuration_parameters
        
        assert 'SERVICE_UNITS_PER_MIPS_HOUR' in params
        assert 'MIPS_COST_PER_MONTH_LOW' in params
        assert 'MIPS_COST_PER_MONTH_MID' in params
        assert 'MIPS_COST_PER_MONTH_HIGH' in params
        assert 'SOFTWARE_COST_RATIO' in params
        assert 'HARDWARE_COST_RATIO' in params
        assert 'SUPPORT_COST_RATIO' in params
        
        # Verify default values
        assert params['SERVICE_UNITS_PER_MIPS_HOUR'].default_value == 3600000
        assert params['MIPS_COST_PER_MONTH_MID'].default_value == 4000
    
    def test_get_sql_returns_valid_query(self):
        """Test that get_sql returns a valid SQL query."""
        query = MIPSCostQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'SELECT' in sql
        assert 'FROM' in sql
        assert 'smf30_identification' in sql
        assert 'smf30_processor' in sql
        assert 'total_mips_hours_annual' in sql
        assert 'estimated_annual_cost_mid' in sql
    
    def test_get_sql_with_custom_parameters(self):
        """Test that get_sql uses custom configuration parameters."""
        query = MIPSCostQuery()
        sql = query.get_sql(
            analysis_days=180,
            SERVICE_UNITS_PER_MIPS_HOUR=4000000,
            MIPS_COST_PER_MONTH_MID=5000
        )
        
        assert '180 days' in sql
        assert '4000000' in sql
        assert '5000' in sql
    
    def test_runtime_parameters(self):
        """Test that query defines runtime parameters."""
        query = MIPSCostQuery()
        params = query.get_parameters()
        
        assert 'analysis_days' in params
        assert params['analysis_days']['type'] == 'int'
        assert params['analysis_days']['default'] == 365


class TestMSUCostQuery:
    """Test MSUCostQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = MSUCostQuery()
        
        assert query.name == "msu_cost"
        assert query.description
        assert query.category == "Cost Analysis"
        assert query.purpose
        assert query.record_types == [30]
        assert query.migration_impact
        assert query.requires_inventory is False
    
    def test_configuration_parameters(self):
        """Test that query defines all required configuration parameters."""
        query = MSUCostQuery()
        params = query.configuration_parameters
        
        assert 'MSU_COST_PER_MONTH_TIER1' in params
        assert 'MSU_COST_PER_MONTH_TIER2' in params
        assert 'MSU_COST_PER_MONTH_TIER3' in params
        assert 'MSU_COST_PER_MONTH_TIER4' in params
        assert 'MSU_TIER1_THRESHOLD' in params
        assert 'MSU_TIER2_THRESHOLD' in params
        assert 'MSU_TIER3_THRESHOLD' in params
        assert 'SOFTWARE_MULTIPLIER' in params
        
        # Verify default values
        assert params['MSU_COST_PER_MONTH_TIER1'].default_value == 4000
        assert params['MSU_TIER1_THRESHOLD'].default_value == 3
    
    def test_get_sql_returns_valid_query(self):
        """Test that get_sql returns a valid SQL query."""
        query = MSUCostQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'SELECT' in sql
        assert 'FROM' in sql
        assert 'smf30_processor' in sql
        assert 'msu_4hour_window' in sql
        assert 'peak_4hour_msu' in sql
        assert 'estimated_annual_cost_mid' in sql
    
    def test_tiered_pricing_logic(self):
        """Test that SQL includes tiered pricing logic."""
        query = MSUCostQuery()
        sql = query.get_sql(
            MSU_COST_PER_MONTH_TIER1=4000,
            MSU_COST_PER_MONTH_TIER2=3500,
            MSU_COST_PER_MONTH_TIER3=3000,
            MSU_COST_PER_MONTH_TIER4=2500,
            MSU_TIER1_THRESHOLD=3,
            MSU_TIER2_THRESHOLD=10,
            MSU_TIER3_THRESHOLD=50
        )
        
        # Verify tiered pricing is in SQL
        assert 'CASE' in sql
        assert '4000' in sql
        assert '3500' in sql
        assert '3000' in sql
        assert '2500' in sql
    
    def test_rolling_window_calculation(self):
        """Test that SQL includes 4-hour rolling window calculation."""
        query = MSUCostQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'ROWS BETWEEN 3 PRECEDING AND CURRENT ROW' in sql


class TestAWSCostQuery:
    """Test AWSCostQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = AWSCostQuery()
        
        assert query.name == "aws_cost"
        assert query.description
        assert query.category == "Cost Analysis"
        assert query.purpose
        assert query.record_types == [14, 15, 30, 64, 100, 101, 110]
        assert query.migration_impact
        assert query.requires_inventory is False
    
    def test_configuration_parameters(self):
        """Test that query defines all required configuration parameters."""
        query = AWSCostQuery()
        params = query.configuration_parameters
        
        # EC2 pricing
        assert 'EC2_C6I_LARGE_HOURLY' in params
        assert 'EC2_C6I_XLARGE_HOURLY' in params
        assert 'EC2_C6I_2XLARGE_HOURLY' in params
        assert 'EC2_C6I_4XLARGE_HOURLY' in params
        
        # EBS pricing
        assert 'EBS_GP3_STORAGE_COST' in params
        assert 'EBS_GP3_IOPS_COST' in params
        
        # RDS pricing
        assert 'RDS_M6I_LARGE_HOURLY' in params
        assert 'RDS_M6I_XLARGE_HOURLY' in params
        assert 'RDS_GP3_STORAGE_COST' in params
        
        # Support
        assert 'AWS_SUPPORT_BUSINESS_TIER' in params
        assert 'HOURS_PER_MONTH' in params
        
        # Verify default values
        assert params['EC2_C6I_XLARGE_HOURLY'].default_value == 0.17
        assert params['AWS_SUPPORT_BUSINESS_TIER'].default_value == 0.10
    
    def test_get_sql_returns_valid_query(self):
        """Test that get_sql returns a valid SQL query."""
        query = AWSCostQuery()
        sql = query.get_sql(
            ec2_instance_count=10,
            ec2_instance_type='c6i.xlarge',
            ebs_storage_gb=10000,
            ebs_iops=5000,
            rds_instance_count=2,
            rds_instance_type='db.m6i.large',
            rds_storage_gb=5000
        )
        
        assert 'SELECT' in sql
        assert 'ec2_instance_count' in sql
        assert 'monthly_ec2_cost' in sql
        assert 'monthly_ebs_cost' in sql
        assert 'monthly_rds_cost' in sql
        assert 'annual_cost_with_support' in sql
    
    def test_runtime_parameters(self):
        """Test that query defines runtime parameters."""
        query = AWSCostQuery()
        params = query.get_parameters()
        
        assert 'ec2_instance_count' in params
        assert 'ec2_instance_type' in params
        assert 'ebs_storage_gb' in params
        assert 'ebs_iops' in params
        assert 'rds_instance_count' in params
        assert 'rds_instance_type' in params
        assert 'rds_storage_gb' in params
    
    def test_cost_calculation_with_different_instance_types(self):
        """Test that different instance types produce different costs."""
        query = AWSCostQuery()
        
        sql_large = query.get_sql(
            ec2_instance_type='c6i.large',
            EC2_C6I_LARGE_HOURLY=0.085
        )
        sql_xlarge = query.get_sql(
            ec2_instance_type='c6i.xlarge',
            EC2_C6I_XLARGE_HOURLY=0.17
        )
        
        # Different instance types should produce different SQL
        assert sql_large != sql_xlarge


class TestMigrationROIQuery:
    """Test MigrationROIQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = MigrationROIQuery()
        
        assert query.name == "migration_roi"
        assert query.description
        assert query.category == "Cost Analysis"
        assert query.purpose
        assert query.record_types == []  # Uses inventory, not SMF records
        assert query.migration_impact
        assert query.requires_inventory is True
    
    def test_configuration_parameters(self):
        """Test that query defines all required configuration parameters."""
        query = MigrationROIQuery()
        params = query.configuration_parameters
        
        assert 'MIGRATION_ASSESSMENT_COST' in params
        assert 'MIGRATION_COST_PER_PROGRAM' in params
        assert 'MIGRATION_COST_PER_GB_DATA' in params
        assert 'MIGRATION_TESTING_COST' in params
        assert 'MIGRATION_TRAINING_COST' in params
        assert 'MIGRATION_CONTINGENCY_RATIO' in params
        
        # Verify default values
        assert params['MIGRATION_ASSESSMENT_COST'].default_value == 50000
        assert params['MIGRATION_COST_PER_PROGRAM'].default_value == 500
        assert params['MIGRATION_CONTINGENCY_RATIO'].default_value == 0.20
    
    def test_get_sql_returns_valid_query(self):
        """Test that get_sql returns a valid SQL query."""
        query = MigrationROIQuery()
        sql = query.get_sql(
            mainframe_annual_cost=1000000,
            aws_annual_cost=500000
        )
        
        assert 'SELECT' in sql
        assert 'FROM' in sql
        assert 'inventory_programs' in sql
        assert 'inventory_datasets' in sql
        assert 'total_migration_cost' in sql
        assert 'annual_savings' in sql
        assert 'payback_period_years' in sql
        assert 'roi_percentage_5year' in sql
    
    def test_runtime_parameters(self):
        """Test that query defines runtime parameters."""
        query = MigrationROIQuery()
        params = query.get_parameters()
        
        assert 'mainframe_annual_cost' in params
        assert 'aws_annual_cost' in params
        assert params['mainframe_annual_cost']['type'] == 'float'
        assert params['aws_annual_cost']['type'] == 'float'
    
    def test_roi_calculation_components(self):
        """Test that SQL includes all ROI calculation components."""
        query = MigrationROIQuery()
        sql = query.get_sql(
            mainframe_annual_cost=1000000,
            aws_annual_cost=500000,
            MIGRATION_ASSESSMENT_COST=50000,
            MIGRATION_COST_PER_PROGRAM=500,
            MIGRATION_CONTINGENCY_RATIO=0.20
        )
        
        # Verify all cost components are in SQL
        assert 'assessment_cost' in sql
        assert 'code_conversion_cost' in sql
        assert 'data_migration_cost' in sql
        assert 'testing_cost' in sql
        assert 'training_cost' in sql
        assert 'contingency_cost' in sql
        
        # Verify ROI calculations
        assert 'mainframe_5year_tco' in sql
        assert 'aws_5year_tco' in sql
        assert 'total_5year_savings' in sql
    
    def test_handles_zero_savings(self):
        """Test that query handles case where AWS cost >= mainframe cost."""
        query = MigrationROIQuery()
        sql = query.get_sql(
            mainframe_annual_cost=500000,
            aws_annual_cost=600000  # AWS more expensive
        )
        
        # Should still generate valid SQL with NULL for payback period
        assert 'SELECT' in sql
        assert 'CASE' in sql
        assert 'NULL' in sql


class TestCostQueriesEdgeCases:
    """Test edge cases for cost queries."""
    
    def test_mips_query_handles_zero_values(self):
        """Test MIPS query handles zero service units."""
        query = MIPSCostQuery()
        sql = query.get_sql(analysis_days=365)
        
        # Should handle division by zero
        assert 'NULLIF' in sql or '/' in sql
    
    def test_msu_query_handles_missing_data(self):
        """Test MSU query handles missing SMF data."""
        query = MSUCostQuery()
        sql = query.get_sql(analysis_days=1)
        
        # Should still generate valid SQL
        assert 'SELECT' in sql
        assert 'FROM' in sql
    
    def test_aws_query_handles_zero_instances(self):
        """Test AWS query handles zero instances."""
        query = AWSCostQuery()
        sql = query.get_sql(
            ec2_instance_count=0,
            rds_instance_count=0
        )
        
        # Should still calculate costs (will be zero)
        assert 'SELECT' in sql
    
    def test_roi_query_handles_empty_inventory(self):
        """Test ROI query handles empty inventory."""
        query = MigrationROIQuery()
        sql = query.get_sql(
            mainframe_annual_cost=1000000,
            aws_annual_cost=500000
        )
        
        # Should use COALESCE for missing data
        assert 'COALESCE' in sql
