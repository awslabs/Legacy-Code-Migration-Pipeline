"""Property-based tests for DB2 parser factory.

Feature: db2-versioned-smf-parsers
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
from tools.smf_analyzer.smf_record_parser.parsers.version_strategy import RecordVersionStrategy
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import UnsupportedVersionError


def create_db2_record_with_version(
    record_type: int,
    db2_version_code: int,
    record_length: int = 200
) -> bytes:
    """Create a synthetic DB2 SMF record with specified version.
    
    Args:
        record_type: SMF record type (100, 101, or 102)
        db2_version_code: 2-byte DB2 version code (e.g., 0x0A00 for V10)
        record_length: Total record length
        
    Returns:
        Binary SMF record with DB2 version in QWHSRELN field
    """
    record = bytearray(record_length)
    
    # Standard SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, record_type)  # Record type
    struct.pack_into('>I', record, 6, 36000)  # Timestamp
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Subsystem ID (EBCDIC)
    subsys_id = "DB2P".encode('cp037')
    record[18:22] = subsys_id
    
    # Subtype
    struct.pack_into('>H', record, 22, 0)
    
    # Triplet count
    struct.pack_into('>H', record, 24, 1)
    
    # Reserved
    struct.pack_into('>H', record, 26, 0)
    
    # Product section triplet (offset 28)
    product_offset = 44  # Start product section after header
    struct.pack_into('>I', record, 28, product_offset)  # Offset
    struct.pack_into('>H', record, 32, 100)  # Length
    struct.pack_into('>H', record, 34, 1)  # Count
    
    # Data section triplet (offset 36)
    struct.pack_into('>I', record, 36, 0)  # Offset (not used for version detection)
    struct.pack_into('>H', record, 40, 0)  # Length
    struct.pack_into('>H', record, 42, 0)  # Count
    
    # QWHS standard header in product section (starts at offset 44)
    # QWHSLEN - Header length
    struct.pack_into('>H', record, product_offset, 92)
    
    # QWHSTYPE - Header type
    struct.pack_into('B', record, product_offset + 2, 1)
    
    # QWHSRMID - Resource manager ID
    struct.pack_into('B', record, product_offset + 3, 0xDB)  # DB2 identifier
    
    # QWHSIFID - IFCID
    struct.pack_into('>H', record, product_offset + 4, 1)
    
    # QWHSRELN - Release number (THIS IS THE KEY FIELD)
    struct.pack_into('>H', record, product_offset + 6, db2_version_code)
    
    # Fill rest of QWHS header with zeros
    # (In real records, this would contain more fields)
    
    return bytes(record)


# Mock parser class for testing dynamic registration
class MockDB2Parser(RecordVersionStrategy):
    """Mock DB2 parser for testing."""
    
    def __init__(self, base_parser: BaseRecordParser):
        super().__init__(base_parser)
    
    def parse(self, record_data: bytes):
        """Mock parse method."""
        return {"mock": True}


# Strategies for generating test data

# Valid DB2 version codes
valid_db2_versions = st.sampled_from([
    (0x0A00, "V10"),
    (0x0B00, "V11"),
    (0x0C00, "V12"),
    (0x0D00, "V13"),
])

# Valid DB2 record types
db2_record_types = st.sampled_from([100, 101, 102])

# Valid registered combinations (record_type, version_code, version_str)
# Based on actual registrations in factory.py
valid_registered_combinations = st.sampled_from([
    (100, 0x0A00, "V10"),  # Type 100 only has V10
    (101, 0x0B00, "V11"),  # Type 101 has V11 and V12
    (101, 0x0C00, "V12"),
    (102, 0x0B00, "V11"),  # Type 102 has V11, V12, V13
    (102, 0x0C00, "V12"),
    (102, 0x0D00, "V13"),
])

# Unregistered combinations for error testing (only Type 101 which validates versions)
unregistered_combinations = st.sampled_from([
    (101, 0x0A00, "V10"),  # V10 not registered for Type 101
    (101, 0x0D00, "V13"),  # V13 not registered for Type 101
])


class TestDB2ParserFactoryProperties:
    """Property-based tests for DB2 parser factory."""
    
    @settings(max_examples=100)
    @given(combination=valid_registered_combinations)
    def test_property_4_registry_lookup_correctness(self, combination):
        """
        **Feature: db2-versioned-smf-parsers, Property 4: Registry Lookup Correctness**
        **Validates: Requirements 2.2**
        
        For any registered (record_type, db2_version) combination, requesting a parser
        from the registry should return a parser instance of the correct type.
        
        Note: Type 100 defaults to V10 and Type 102 defaults to V13, so version detection
        may not match the version code in the record.
        """
        record_type, version_code, version_str = combination
        
        # Register a mock parser for this combination
        registry_key = (record_type, version_str)
        original_parser = SMFParserFactory._db2_registry.get(registry_key)
        
        try:
            # Register mock parser
            SMFParserFactory._db2_registry[registry_key] = MockDB2Parser
            
            # Create test record
            record_data = create_db2_record_with_version(record_type, version_code)
            
            # Request parser from factory
            parser = SMFParserFactory.create_parser(
                record_type=record_type,
                record_data=record_data,
                allow_fallback=True  # Allow fallback since Type 100/102 use defaults
            )
            
            # Verify parser was created
            assert parser is not None, "Parser should be created"
            assert parser.record_type == record_type, \
                f"Parser record type {parser.record_type} should match {record_type}"
            
            # For Type 101, verify the exact version strategy exists
            # For Type 100 and 102, just verify a strategy was selected
            if record_type == 101:
                strategy = parser.version_strategies.get(version_str)
                assert strategy is not None, f"Strategy for {version_str} should exist"
                assert isinstance(strategy, MockDB2Parser), \
                    f"Strategy should be MockDB2Parser, got {type(strategy)}"
            else:
                # Type 100 and 102 use default versions, so just verify a strategy exists
                assert len(parser.version_strategies) > 0, "At least one strategy should exist"
            
        finally:
            # Restore original parser or remove mock
            if original_parser is not None:
                SMFParserFactory._db2_registry[registry_key] = original_parser
            else:
                SMFParserFactory._db2_registry.pop(registry_key, None)
    
    @settings(max_examples=50)
    @given(combination=unregistered_combinations)
    def test_property_5_registry_error_handling(self, combination):
        """
        **Feature: db2-versioned-smf-parsers, Property 5: Registry Error Handling**
        **Validates: Requirements 2.3**
        
        For any unregistered (record_type, db2_version) combination, requesting a parser
        from the registry should raise UnsupportedVersionError with details about the
        unsupported combination.
        """
        record_type, version_code, version_str = combination
        
        # Ensure this combination is NOT registered
        registry_key = (record_type, version_str)
        original_parser = SMFParserFactory._db2_registry.get(registry_key)
        
        try:
            # Remove from registry if present
            if registry_key in SMFParserFactory._db2_registry:
                del SMFParserFactory._db2_registry[registry_key]
            
            # Create test record
            record_data = create_db2_record_with_version(record_type, version_code)
            
            # Request parser with fallback disabled - should raise error
            with pytest.raises(UnsupportedVersionError) as exc_info:
                SMFParserFactory.create_parser(
                    record_type=record_type,
                    record_data=record_data,
                    allow_fallback=False
                )
            
            # Verify error message contains details
            error_msg = str(exc_info.value)
            assert str(record_type) in error_msg, \
                f"Error should mention record type {record_type}: {error_msg}"
            assert version_str in error_msg, \
                f"Error should mention version {version_str}: {error_msg}"
            
            # Verify error attributes
            assert exc_info.value.record_type == record_type, \
                f"Error record_type should be {record_type}"
            assert exc_info.value.version == version_str, \
                f"Error version should be {version_str}"
            
        finally:
            # Restore original parser if it existed
            if original_parser is not None:
                SMFParserFactory._db2_registry[registry_key] = original_parser
    
    @settings(max_examples=100)
    @given(
        record_type=db2_record_types,
        version_data=valid_db2_versions
    )
    def test_property_6_dynamic_registration(self, record_type, version_data):
        """
        **Feature: db2-versioned-smf-parsers, Property 6: Dynamic Registration**
        **Validates: Requirements 2.4**
        
        For any new parser strategy class, registering it with a (record_type, db2_version)
        key should make it retrievable via that key in subsequent lookups.
        """
        version_code, version_str = version_data
        
        # Use a unique version string to avoid conflicts
        test_version = f"{version_str}_TEST"
        registry_key = (record_type, test_version)
        
        # Ensure key doesn't exist initially
        assert registry_key not in SMFParserFactory._db2_registry, \
            f"Registry should not contain {registry_key} initially"
        
        try:
            # Register new parser
            SMFParserFactory._db2_registry[registry_key] = MockDB2Parser
            
            # Verify registration
            assert registry_key in SMFParserFactory._db2_registry, \
                f"Registry should contain {registry_key} after registration"
            
            retrieved_class = SMFParserFactory._db2_registry[registry_key]
            assert retrieved_class is MockDB2Parser, \
                f"Retrieved class should be MockDB2Parser, got {retrieved_class}"
            
            # Verify it appears in list_db2_parsers
            db2_parsers = SMFParserFactory.list_db2_parsers()
            if record_type in db2_parsers:
                assert test_version in db2_parsers[record_type], \
                    f"Version {test_version} should appear in list for type {record_type}"
            
        finally:
            # Clean up test registration
            SMFParserFactory._db2_registry.pop(registry_key, None)
    
    @settings(max_examples=50)
    @given(
        record_type=db2_record_types,
        target_version=st.sampled_from(["V10", "V11", "V12", "V13"])
    )
    def test_property_16_fallback_parser_selection(self, record_type, target_version):
        """
        **Feature: db2-versioned-smf-parsers, Property 16: Fallback Parser Selection**
        **Validates: Requirements 11.2, 11.3**
        
        For any DB2 record with an unsupported version, when fallback parsing is enabled,
        the system should select the nearest available parser version (preferring older
        versions for compatibility).
        """
        # Create a version code for the target version
        version_map = {
            "V10": 0x0A00,
            "V11": 0x0B00,
            "V12": 0x0C00,
            "V13": 0x0D00,
        }
        
        # Use a slightly different version code (e.g., V10.1 instead of V10.0)
        base_code = version_map[target_version]
        modified_code = base_code | 0x01  # Add minor version
        
        # Register mock parsers for some versions
        test_parsers = {}
        for version in ["V10", "V11", "V12"]:
            key = (record_type, version)
            original = SMFParserFactory._db2_registry.get(key)
            test_parsers[key] = original
            SMFParserFactory._db2_registry[key] = MockDB2Parser
        
        try:
            # Create test record with modified version
            record_data = create_db2_record_with_version(record_type, modified_code)
            
            # Request parser with fallback enabled
            # Note: This will fail if the exact version doesn't exist, but fallback should work
            # We need to handle the case where version detection returns the base version
            
            # Get available versions for this record type
            available = SMFParserFactory._get_available_versions(record_type)
            
            if available:
                # Find fallback version
                fallback = SMFParserFactory._find_fallback_parser(record_type, target_version)
                
                if fallback:
                    # Verify fallback is older or equal to target
                    target_num = int(target_version.replace("V", ""))
                    fallback_num = int(fallback.replace("V", ""))
                    
                    # Fallback should prefer older versions
                    assert fallback_num <= target_num, \
                        f"Fallback {fallback} should be <= target {target_version}"
                    
                    # Verify fallback is in available versions
                    assert fallback in available, \
                        f"Fallback {fallback} should be in available versions {available}"
        
        finally:
            # Restore original parsers
            for key, original in test_parsers.items():
                if original is not None:
                    SMFParserFactory._db2_registry[key] = original
                else:
                    SMFParserFactory._db2_registry.pop(key, None)
    
    def test_list_db2_parsers_structure(self):
        """
        Test that list_db2_parsers returns the correct structure.
        
        This is not a property test but validates the basic functionality.
        """
        # Get DB2 parsers list
        db2_parsers = SMFParserFactory.list_db2_parsers()
        
        # Verify it's a dictionary
        assert isinstance(db2_parsers, dict), "list_db2_parsers should return a dict"
        
        # Verify all keys are integers (record types)
        for record_type in db2_parsers.keys():
            assert isinstance(record_type, int), \
                f"Record type {record_type} should be an integer"
            assert record_type in {100, 101, 102}, \
                f"Record type {record_type} should be a DB2 type"
        
        # Verify all values are lists of version strings
        for record_type, versions in db2_parsers.items():
            assert isinstance(versions, list), \
                f"Versions for type {record_type} should be a list"
            for version in versions:
                assert isinstance(version, str), \
                    f"Version {version} should be a string"
                assert version.startswith("V"), \
                    f"Version {version} should start with 'V'"
    
    def test_list_available_parsers_includes_db2(self):
        """
        Test that list_available_parsers includes DB2 parsers.
        
        This is not a property test but validates the integration.
        """
        # Register a test DB2 parser
        test_key = (100, "V10")
        original = SMFParserFactory._db2_registry.get(test_key)
        
        try:
            SMFParserFactory._db2_registry[test_key] = MockDB2Parser
            
            # Get all parsers
            all_parsers = SMFParserFactory.list_available_parsers()
            
            # Verify DB2 parsers are included
            if 100 in all_parsers:
                assert "V10" in all_parsers[100], \
                    "DB2 V10 parser should be in available parsers"
        
        finally:
            if original is not None:
                SMFParserFactory._db2_registry[test_key] = original
            else:
                SMFParserFactory._db2_registry.pop(test_key, None)
