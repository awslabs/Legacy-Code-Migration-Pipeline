"""Unit tests for SMF62ParserV3R2."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf62_parser_v3r2 import SMF62ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF62ParserV3R2:
    """Test suite for SMF62ParserV3R2 class."""
    
    def create_minimal_smf62_record(self, open_status=0x80, macrf_flags=0x01, num_volumes=1):
        """Create minimal valid SMF Type 62 record with synthetic data.
        
        This creates a basic Type 62 record structure with:
        - Valid header
        - Component/cluster name (44 chars)
        - Catalog name (44 chars)
        - Job identification (job name, job ID, user ID)
        - Open status indicator
        - Timestamps
        - MACRF flags for access mode
        - Volume information
        - SMS classes (management, storage, data)
        
        Args:
            open_status: Open status indicator byte (default 0x80 = SUCCESS)
            macrf_flags: MACRF flags for access mode (default 0x01 = SEQ_INPUT)
            num_volumes: Number of volumes (default 1)
        
        Returns:
            bytes: Synthetic SMF Type 62 record
        """
        # Calculate record length based on volumes and SMS classes
        # Base: 184 + (num_volumes * 6) + (3 * 8) for SMS classes
        record_length = 184 + (num_volumes * 6) + 24
        data = bytearray(record_length)
        
        # === HEADER SECTION (offsets 0-17) ===
        # Record length (offset 0, 2 bytes)
        data[0:2] = record_length.to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes)
        data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte)
        data[4] = 0x00
        
        # Record type (offset 5, 1 byte) - 62
        data[5] = 62
        
        # Timestamp (offset 6, 4 bytes) - 36000 hundredths = 10:00:00.00
        data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes) - 0x01250001F = 2025-001 (Jan 1, 2025)
        data[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes) - "SYS1" in EBCDIC
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # === COMPONENT/CLUSTER NAME (offset 18, 44 bytes) - SMF62DNM ===
        component_name = "VSAM.CLUSTER.DATA"
        component_name_ebcdic = component_name.encode('cp037')
        data[18:62] = component_name_ebcdic + bytes([0x40] * (44 - len(component_name_ebcdic)))
        
        # === CATALOG NAME (offset 106, 44 bytes) - SMF62CNM ===
        # Note: There's a gap from 62-106 (44 bytes) for other fields
        catalog_name = "CATALOG.MASTER"
        catalog_name_ebcdic = catalog_name.encode('cp037')
        data[106:150] = catalog_name_ebcdic + bytes([0x40] * (44 - len(catalog_name_ebcdic)))
        
        # === JOB NAME (offset 150, 8 bytes) - SMF62JBN ===
        job_name = "VSAMJOB1"
        job_name_ebcdic = job_name.encode('cp037')
        data[150:158] = job_name_ebcdic
        
        # === JOB ID (offset 158, 8 bytes) - SMF62JobID ===
        job_id = "JOB12345"
        job_id_ebcdic = job_id.encode('cp037')
        data[158:166] = job_id_ebcdic
        
        # === USER ID (offset 166, 8 bytes) - SMF62UIF ===
        user_id = "VSAMUSR1"
        user_id_ebcdic = user_id.encode('cp037')
        data[166:174] = user_id_ebcdic
        
        # === OPEN STATUS INDICATOR (offset 174, 1 byte) - SMF62IND ===
        data[174] = open_status
        
        # === OPEN TIME (offset 175, 4 bytes) - SMF62TIM ===
        data[175:179] = (32400).to_bytes(4, 'big')  # 09:00:00.00
        
        # === MACRF FLAGS (offsets 179-182, 4 bytes) - SMF62MC1-4 ===
        data[179:183] = macrf_flags.to_bytes(4, 'big')
        
        # === VOLUME COUNT (offset 183, 1 byte) - SMF62VCT ===
        data[183] = num_volumes
        
        # === VOLUME SERIAL NUMBERS (starting at offset 184, 6 bytes each) - SMF62VSR ===
        volume_offset = 184
        for i in range(num_volumes):
            volume_serial = f"VOL{i+1:03d}"
            volume_serial_ebcdic = volume_serial.encode('cp037')
            data[volume_offset:volume_offset+6] = volume_serial_ebcdic
            volume_offset += 6
        
        # === SMS CLASSES (after volumes) ===
        sms_offset = 184 + (num_volumes * 6)
        
        # Management class (8 bytes) - SMF62MGT
        management_class = "MGMTCLS1"
        data[sms_offset:sms_offset+8] = management_class.encode('cp037')
        sms_offset += 8
        
        # Storage class (8 bytes) - SMF62STR
        storage_class = "STORCLS1"
        data[sms_offset:sms_offset+8] = storage_class.encode('cp037')
        sms_offset += 8
        
        # Data class (8 bytes) - SMF62DAT
        data_class = "DATACLS1"
        data[sms_offset:sms_offset+8] = data_class.encode('cp037')
        
        return bytes(data)
    
    def test_parser_initialization(self):
        """Test creating SMF62ParserV3R2 instance."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        assert parser.parser == base_parser
    
    def test_parse_validates_record_type(self):
        """Test that parsing validates record type."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record with wrong type
        data = self.create_minimal_smf62_record()
        data_array = bytearray(data)
        data_array[5] = 30  # Wrong record type
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "type mismatch" in str(exc_info.value).lower()
    
    def test_parse_validates_record_length(self):
        """Test that parsing validates record length."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record with mismatched length
        data = self.create_minimal_smf62_record()
        data_array = bytearray(data)
        data_array[0:2] = (500).to_bytes(2, 'big')  # Wrong length
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "length mismatch" in str(exc_info.value).lower()
    
    def test_parse_extracts_component_name(self):
        """Test that parse extracts component name correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.record_type == 62
        assert result.identification['component_name'] == "VSAM.CLUSTER.DATA"
    
    def test_parse_extracts_catalog_name(self):
        """Test that parse extracts catalog name correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.identification['catalog_name'] == "CATALOG.MASTER"
    
    def test_parse_extracts_job_identification(self):
        """Test that parse extracts job identification correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.identification['job_name'] == "VSAMJOB1"
        assert result.identification['job_id'] == "JOB12345"
        assert result.identification['user_id'] == "VSAMUSR1"
    
    def test_parse_extracts_open_time(self):
        """Test that parse extracts open time correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.identification['open_time'] is not None
        assert isinstance(result.identification['open_time'], str)
    
    def test_parse_extracts_system_id(self):
        """Test that parse extracts system ID correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.system_id == "SYS1"
    
    def test_parse_extracts_record_length(self):
        """Test that parse extracts record length correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.record_length == len(data)


class TestSMF62OpenStatus:
    """Test open status indicator decoding for SMF Type 62 records."""
    
    def create_record_with_status(self, status_byte):
        """Helper to create record with specific open status."""
        record_length = 214
        data = bytearray(record_length)
        
        # Basic header
        data[0:2] = record_length.to_bytes(2, 'big')
        data[5] = 62
        data[6:10] = (36000).to_bytes(4, 'big')
        data[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # Component name
        component_name = "TEST.VSAM.CLUSTER"
        data[18:62] = component_name.encode('cp037') + bytes([0x40] * (44 - len(component_name)))
        
        # Catalog name
        catalog_name = "CATALOG"
        data[106:150] = catalog_name.encode('cp037') + bytes([0x40] * (44 - len(catalog_name)))
        
        # Job identification
        data[150:158] = "TESTJOB1".encode('cp037')
        data[158:166] = "JOB00001".encode('cp037')
        data[166:174] = "TESTUSER".encode('cp037')
        
        # Open status
        data[174] = status_byte
        
        # Open time
        data[175:179] = (32400).to_bytes(4, 'big')
        
        # MACRF flags
        data[179:183] = (0x01).to_bytes(4, 'big')
        
        # Volume count and serial
        data[183] = 1
        data[184:190] = "VOL001".encode('cp037')
        
        # SMS classes
        data[190:198] = "MGMTCLS1".encode('cp037')
        data[198:206] = "STORCLS1".encode('cp037')
        data[206:214] = "DATACLS1".encode('cp037')
        
        return bytes(data)
    
    def test_decode_open_status_success(self):
        """Test decoding SUCCESS open status."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_record_with_status(0x80)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "SUCCESS"
    
    def test_decode_open_status_failed(self):
        """Test decoding FAILED open status."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_record_with_status(0x40)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "FAILED"
    
    def test_decode_open_status_catalog(self):
        """Test decoding CATALOG open status."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_record_with_status(0x20)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "CATALOG"
    
    def test_decode_open_status_vvds(self):
        """Test decoding VVDS open status."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_record_with_status(0x10)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "VVDS"
    
    def test_decode_open_status_unknown(self):
        """Test decoding unknown open status."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = self.create_record_with_status(0x08)
        result = parser.parse(data)
        
        assert "UNKNOWN" in result.identification['open_status']


class TestSMF62VolumeExtraction:
    """Test volume extraction for SMF Type 62 records."""
    
    def test_parse_single_volume(self):
        """Test parsing record with single volume."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(num_volumes=1)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 1
        assert len(result.identification['volume_serials']) == 1
        assert result.identification['volume_serials'][0] == "VOL001"
    
    def test_parse_multiple_volumes(self):
        """Test parsing record with multiple volumes."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(num_volumes=3)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 3
        assert len(result.identification['volume_serials']) == 3
        assert result.identification['volume_serials'][0] == "VOL001"
        assert result.identification['volume_serials'][1] == "VOL002"
        assert result.identification['volume_serials'][2] == "VOL003"
    
    def test_parse_zero_volumes(self):
        """Test parsing record with zero volumes."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(num_volumes=0)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 0
        assert len(result.identification['volume_serials']) == 0


class TestSMF62SMSClassParsing:
    """Test SMS class parsing for SMF Type 62 records."""
    
    def test_parse_extracts_management_class(self):
        """Test that parse extracts management class correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.identification['management_class'] == "MGMTCLS1"
    
    def test_parse_extracts_storage_class(self):
        """Test that parse extracts storage class correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.identification['storage_class'] == "STORCLS1"
    
    def test_parse_extracts_data_class(self):
        """Test that parse extracts data class correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.identification['data_class'] == "DATACLS1"
    
    def test_parse_all_sms_classes(self):
        """Test that parse extracts all SMS classes correctly."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record()
        result = parser.parse(data)
        
        assert result.identification['management_class'] == "MGMTCLS1"
        assert result.identification['storage_class'] == "STORCLS1"
        assert result.identification['data_class'] == "DATACLS1"


class TestSMF62AccessModeDerivation:
    """Test access mode derivation from MACRF flags for SMF Type 62 records."""
    
    def test_decode_access_mode_seq_input(self):
        """Test decoding SEQ_INPUT access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x01)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "SEQ_INPUT"
    
    def test_decode_access_mode_seq_output(self):
        """Test decoding SEQ_OUTPUT access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x02)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "SEQ_OUTPUT"
    
    def test_decode_access_mode_random_key(self):
        """Test decoding RANDOM_KEY access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x04)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "RANDOM_KEY"
    
    def test_decode_access_mode_random_rba(self):
        """Test decoding RANDOM_RBA access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x08)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "RANDOM_RBA"
    
    def test_decode_access_mode_update(self):
        """Test decoding UPDATE access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x10)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "UPDATE"
    
    def test_decode_access_mode_backward(self):
        """Test decoding BACKWARD access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x20)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "BACKWARD"
    
    def test_decode_access_mode_skip_seq(self):
        """Test decoding SKIP_SEQ access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x40)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "SKIP_SEQ"
    
    def test_decode_access_mode_multiple_flags(self):
        """Test decoding access mode with multiple flags."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # SEQ_INPUT + UPDATE
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x11)
        result = parser.parse(data)
        
        assert "SEQ_INPUT" in result.identification['access_mode']
        assert "UPDATE" in result.identification['access_mode']
    
    def test_decode_access_mode_random_key_update(self):
        """Test decoding RANDOM_KEY + UPDATE access mode."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # RANDOM_KEY + UPDATE
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x14)
        result = parser.parse(data)
        
        assert "RANDOM_KEY" in result.identification['access_mode']
        assert "UPDATE" in result.identification['access_mode']
    
    def test_decode_access_mode_none(self):
        """Test decoding access mode with no flags set."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x00)
        result = parser.parse(data)
        
        assert result.identification['access_mode'] == "NONE"
    
    def test_decode_access_mode_unknown(self):
        """Test decoding access mode with unknown flags."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Use a flag combination that's not defined
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(macrf_flags=0x80)
        result = parser.parse(data)
        
        assert "UNKNOWN" in result.identification['access_mode']


class TestSMF62EncodingHandling:
    """Test EBCDIC encoding handling for SMF Type 62 records."""
    
    def test_ebcdic_component_name_with_special_chars(self):
        """Test handling of component names with special characters."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with component name containing special chars
        data = bytearray(100)
        
        # Component name with special chars: "VSAM.CLUSTER(DATA)"
        component_name = "VSAM.CLUSTER(DATA)"
        data[0:44] = component_name.encode('cp037') + bytes([0x40] * (44 - len(component_name)))
        
        # Test EBCDIC decoding
        decoded = base_parser.read_string(bytes(data), 0, 44, "component_name")
        assert decoded == "VSAM.CLUSTER(DATA)"
    
    def test_ebcdic_catalog_name_padding(self):
        """Test handling of catalog names with EBCDIC padding."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with short catalog name with EBCDIC space padding (0x40)
        data = bytearray(100)
        catalog_name = "CATALOG"
        data[0:44] = catalog_name.encode('cp037') + bytes([0x40] * 37)
        
        # Test EBCDIC decoding with padding
        decoded = base_parser.read_string(bytes(data), 0, 44, "catalog_name")
        
        # Should strip trailing spaces
        assert decoded == "CATALOG"
    
    def test_ebcdic_volume_serial_extraction(self):
        """Test handling of volume serials with EBCDIC encoding."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with volume serial
        data = bytearray(20)
        volume_serial = "VOL123"
        data[0:6] = volume_serial.encode('cp037')
        
        # Test EBCDIC decoding
        decoded = base_parser.read_string(bytes(data), 0, 6, "volume_serial")
        assert decoded == "VOL123"


class TestSMF62ErrorConditions:
    """Test error handling for SMF Type 62 parser."""
    
    def test_parse_with_insufficient_data(self):
        """Test parsing with record too short for basic fields."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record that's too short
        data = bytearray(100)
        data[0:2] = (100).to_bytes(2, 'big')
        data[5] = 62
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(data))
    
    def test_parse_with_zero_length_record(self):
        """Test parsing with zero-length record."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        data = bytes()
        
        with pytest.raises(ValidationError):
            parser.parse(data)
    
    def test_parse_with_truncated_volume_data(self):
        """Test parsing with truncated volume data."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record that claims 3 volumes but only has space for 1
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(num_volumes=1)
        data_array = bytearray(data)
        data_array[183] = 3  # Claim 3 volumes
        
        # Should handle gracefully without crashing
        result = parser.parse(bytes(data_array))
        assert result.identification['num_volumes'] == 3
        # Should only extract volumes that fit in the record
        assert len(result.identification['volume_serials']) <= 3



class TestSMF62SuccessfulAndFailedOpens:
    """Test successful and failed open event handling for SMF Type 62 records."""
    
    def test_parse_successful_open_event(self):
        """Test parsing successful VSAM open event."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record with SUCCESS status
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(open_status=0x80)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "SUCCESS"
        assert result.identification['component_name'] == "VSAM.CLUSTER.DATA"
        assert result.identification['job_name'] == "VSAMJOB1"
    
    def test_parse_failed_open_event(self):
        """Test parsing failed VSAM open event."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record with FAILED status
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(open_status=0x40)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "FAILED"
        assert result.identification['component_name'] == "VSAM.CLUSTER.DATA"
        assert result.identification['job_name'] == "VSAMJOB1"
    
    def test_parse_catalog_open_event(self):
        """Test parsing catalog-related open event."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record with CATALOG status
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(open_status=0x20)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "CATALOG"
        assert result.identification['catalog_name'] == "CATALOG.MASTER"
    
    def test_parse_vvds_open_event(self):
        """Test parsing VVDS-related open event."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record with VVDS status
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(open_status=0x10)
        result = parser.parse(data)
        
        assert result.identification['open_status'] == "VVDS"
    
    def test_failed_open_has_all_identification_fields(self):
        """Test that failed open events still have all identification fields."""
        base_parser = BaseRecordParser()
        parser = SMF62ParserV3R2(base_parser)
        
        # Create record with FAILED status
        data = TestSMF62ParserV3R2().create_minimal_smf62_record(open_status=0x40)
        result = parser.parse(data)
        
        # Even failed opens should have complete identification
        assert result.identification['open_status'] == "FAILED"
        assert result.identification['component_name'] is not None
        assert result.identification['catalog_name'] is not None
        assert result.identification['job_name'] is not None
        assert result.identification['job_id'] is not None
        assert result.identification['user_id'] is not None
        assert result.identification['open_time'] is not None
