"""Unit tests for artifact analysis queries."""

import pytest
from tools.smf_analyzer.smf_queries.queries.artifact_queries import (
    UnreferencedJCLQuery,
    UnreferencedProgramsQuery,
    UnreferencedDatasetsQuery,
    UnreferencedCopybooksQuery,
    UnreferencedCICSTransactionsQuery,
    MissingJCLQuery,
    MissingProgramsQuery,
    MissingDatasetsQuery,
    ArtifactRiskAssessmentQuery,
)


class TestUnreferencedJCLQuery:
    """Test UnreferencedJCLQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = UnreferencedJCLQuery()
        
        assert query.name == "unreferenced_jcl"
        assert query.description
        assert query.category == "Code Artifact Analysis"
        assert query.purpose
        assert query.migration_impact
        assert query.requires_inventory is True
        assert 30 in query.record_types
    
    def test_configuration_parameters(self):
        """Test query has configuration parameters."""
        query = UnreferencedJCLQuery()
        
        config_params = query.configuration_parameters
        assert 'analysis_days' in config_params
        assert config_params['analysis_days'].default_value == 365
        assert config_params['analysis_days'].parameter_type == 'int'
    
    def test_sql_generation_default_params(self):
        """Test SQL generation with default parameters."""
        query = UnreferencedJCLQuery()
        
        sql = query.get_sql()
        assert 'inventory_jcl' in sql
        assert 'smf30_identification' in sql
        assert '365 days' in sql
    
    def test_sql_generation_custom_params(self):
        """Test SQL generation with custom parameters."""
        query = UnreferencedJCLQuery()
        
        sql = query.get_sql(analysis_days=180, library_pattern='PROD.JCL%')
        assert '180 days' in sql
        assert 'PROD.JCL%' in sql


class TestUnreferencedProgramsQuery:
    """Test UnreferencedProgramsQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = UnreferencedProgramsQuery()
        
        assert query.name == "unreferenced_programs"
        assert query.description
        assert query.category == "Code Artifact Analysis"
        assert query.purpose
        assert query.migration_impact
        assert query.requires_inventory is True
        assert set([14, 15, 30, 110]).issubset(set(query.record_types))
    
    def test_configuration_parameters(self):
        """Test query has configuration parameters."""
        query = UnreferencedProgramsQuery()
        
        config_params = query.configuration_parameters
        assert 'analysis_days' in config_params
    
    def test_sql_generation(self):
        """Test SQL generation."""
        query = UnreferencedProgramsQuery()
        
        sql = query.get_sql(analysis_days=90, min_size_kb=10)
        assert 'inventory_programs' in sql
        assert '90 days' in sql
        assert '>= 10' in sql


class TestUnreferencedDatasetsQuery:
    """Test UnreferencedDatasetsQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = UnreferencedDatasetsQuery()
        
        assert query.name == "unreferenced_datasets"
        assert query.category == "Code Artifact Analysis"
        assert query.requires_inventory is True
        assert set([14, 15, 17, 62, 64]).issubset(set(query.record_types))
    
    def test_sql_generation(self):
        """Test SQL generation."""
        query = UnreferencedDatasetsQuery()
        
        sql = query.get_sql(analysis_days=365)
        assert 'inventory_datasets' in sql
        assert 'smf14_records' in sql
        assert 'smf15_records' in sql


class TestUnreferencedCopybooksQuery:
    """Test UnreferencedCopybooksQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = UnreferencedCopybooksQuery()
        
        assert query.name == "unreferenced_copybooks"
        assert query.category == "Code Artifact Analysis"
        assert query.requires_inventory is True
        assert len(query.record_types) == 0  # Uses only inventory data
    
    def test_sql_generation(self):
        """Test SQL generation."""
        query = UnreferencedCopybooksQuery()
        
        sql = query.get_sql(library_pattern='%')
        assert 'inventory_copybooks' in sql
        assert 'artifact_dependencies' in sql
        assert "dependency_type = 'COPY'" in sql


class TestUnreferencedCICSTransactionsQuery:
    """Test UnreferencedCICSTransactionsQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = UnreferencedCICSTransactionsQuery()
        
        assert query.name == "unreferenced_cics_transactions"
        assert query.category == "Code Artifact Analysis"
        assert query.requires_inventory is True
        assert 110 in query.record_types
    
    def test_configuration_parameters(self):
        """Test query has configuration parameters."""
        query = UnreferencedCICSTransactionsQuery()
        
        config_params = query.configuration_parameters
        assert 'analysis_days' in config_params
    
    def test_sql_generation(self):
        """Test SQL generation."""
        query = UnreferencedCICSTransactionsQuery()
        
        sql = query.get_sql(analysis_days=365)
        assert 'inventory_transactions' in sql
        assert 'smf110_performance' in sql


class TestMissingJCLQuery:
    """Test MissingJCLQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = MissingJCLQuery()
        
        assert query.name == "missing_jcl"
        assert query.category == "Code Artifact Analysis"
        assert query.requires_inventory is False  # Finds what's missing FROM inventory
        assert 30 in query.record_types
    
    def test_sql_generation(self):
        """Test SQL generation."""
        query = MissingJCLQuery()
        
        sql = query.get_sql(analysis_days=180, min_executions=5)
        assert 'smf30_identification' in sql
        assert 'inventory_jcl' in sql
        assert '180 days' in sql
        assert '>= 5' in sql


class TestMissingProgramsQuery:
    """Test MissingProgramsQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = MissingProgramsQuery()
        
        assert query.name == "missing_programs"
        assert query.category == "Code Artifact Analysis"
        assert query.requires_inventory is False
        assert set([14, 15, 30, 110]).issubset(set(query.record_types))
    
    def test_sql_generation(self):
        """Test SQL generation."""
        query = MissingProgramsQuery()
        
        sql = query.get_sql(analysis_days=90)
        assert 'inventory_programs' in sql
        assert 'smf30_identification' in sql
        assert '90 days' in sql


class TestMissingDatasetsQuery:
    """Test MissingDatasetsQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = MissingDatasetsQuery()
        
        assert query.name == "missing_datasets"
        assert query.category == "Code Artifact Analysis"
        assert query.requires_inventory is False
        assert set([14, 15, 17, 62, 64]).issubset(set(query.record_types))
    
    def test_sql_generation(self):
        """Test SQL generation."""
        query = MissingDatasetsQuery()
        
        sql = query.get_sql(analysis_days=365, min_accesses=10)
        assert 'inventory_datasets' in sql
        assert 'smf14_records' in sql
        assert '>= 10' in sql


class TestArtifactRiskAssessmentQuery:
    """Test ArtifactRiskAssessmentQuery implementation."""
    
    def test_query_metadata(self):
        """Test query has all required metadata."""
        query = ArtifactRiskAssessmentQuery()
        
        assert query.name == "artifact_risk_assessment"
        assert query.category == "Code Artifact Analysis"
        assert query.requires_inventory is True
        assert query.purpose
        assert query.migration_impact
    
    def test_configuration_parameters(self):
        """Test query has configuration parameters."""
        query = ArtifactRiskAssessmentQuery()
        
        config_params = query.configuration_parameters
        assert 'analysis_days' in config_params
    
    def test_sql_generation_all_types(self):
        """Test SQL generation for all artifact types."""
        query = ArtifactRiskAssessmentQuery()
        
        sql = query.get_sql(artifact_type='ALL', analysis_days=365)
        assert 'unreferenced_artifacts' in sql
        assert 'risk_patterns' in sql
        assert 'HIGH' in sql
        assert 'MEDIUM' in sql
        assert 'LOW' in sql
    
    def test_sql_generation_specific_type(self):
        """Test SQL generation for specific artifact type."""
        query = ArtifactRiskAssessmentQuery()
        
        sql = query.get_sql(artifact_type='PROGRAM', analysis_days=180)
        assert 'PROGRAM' in sql
        assert '180 days' in sql


class TestQueryParameterValidation:
    """Test parameter validation across all queries."""
    
    def test_unreferenced_jcl_parameters(self):
        """Test UnreferencedJCLQuery parameter definitions."""
        query = UnreferencedJCLQuery()
        params = query.get_parameters()
        
        assert 'analysis_days' in params
        assert params['analysis_days']['type'] == 'int'
        assert params['analysis_days']['required'] is False
        assert params['library_pattern']['type'] == 'str'
    
    def test_missing_jcl_parameters(self):
        """Test MissingJCLQuery parameter definitions."""
        query = MissingJCLQuery()
        params = query.get_parameters()
        
        assert 'analysis_days' in params
        assert 'min_executions' in params
        assert params['min_executions']['type'] == 'int'


class TestQueryCategories:
    """Test that all queries have correct category."""
    
    def test_all_queries_have_correct_category(self):
        """Test all artifact queries have 'Code Artifact Analysis' category."""
        queries = [
            UnreferencedJCLQuery(),
            UnreferencedProgramsQuery(),
            UnreferencedDatasetsQuery(),
            UnreferencedCopybooksQuery(),
            UnreferencedCICSTransactionsQuery(),
            MissingJCLQuery(),
            MissingProgramsQuery(),
            MissingDatasetsQuery(),
            ArtifactRiskAssessmentQuery(),
        ]
        
        for query in queries:
            assert query.category == "Code Artifact Analysis", \
                f"{query.name} has incorrect category: {query.category}"


class TestQueryMigrationImpact:
    """Test that all queries have migration impact information."""
    
    def test_all_queries_have_migration_impact(self):
        """Test all artifact queries have migration_impact property."""
        queries = [
            UnreferencedJCLQuery(),
            UnreferencedProgramsQuery(),
            UnreferencedDatasetsQuery(),
            UnreferencedCopybooksQuery(),
            UnreferencedCICSTransactionsQuery(),
            MissingJCLQuery(),
            MissingProgramsQuery(),
            MissingDatasetsQuery(),
            ArtifactRiskAssessmentQuery(),
        ]
        
        for query in queries:
            assert query.migration_impact, \
                f"{query.name} missing migration_impact"
            assert len(query.migration_impact) > 0, \
                f"{query.name} has empty migration_impact"


class TestQueryPurpose:
    """Test that all queries have purpose information."""
    
    def test_all_queries_have_purpose(self):
        """Test all artifact queries have purpose property."""
        queries = [
            UnreferencedJCLQuery(),
            UnreferencedProgramsQuery(),
            UnreferencedDatasetsQuery(),
            UnreferencedCopybooksQuery(),
            UnreferencedCICSTransactionsQuery(),
            MissingJCLQuery(),
            MissingProgramsQuery(),
            MissingDatasetsQuery(),
            ArtifactRiskAssessmentQuery(),
        ]
        
        for query in queries:
            assert query.purpose, \
                f"{query.name} missing purpose"
            assert len(query.purpose) > 0, \
                f"{query.name} has empty purpose"
