"""Property-based tests for ParsedRecord structure consistency.

Feature: db2-versioned-smf-parsers
"""

import pytest
import struct
from datetime import datetime, date
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_db2_record_with_version(
    record_type: int,
    db2_version_code: int,
    record_length: int = 200
) -> bytes:
    """Create a synthetic DB2 SMF record with specified version.
    
    Args:
        record_type: SMF record type (100, 101, or 102)
        db2_version_code: 2-byte DB2 version code (e.g., 0x0A00 for V10)
        record_length: Total record length
        
    Returns:
        Binary SMF record with DB2 version in QWHSRELN field
    """
    record = bytearray(record_length)
    
    # Standard SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, record_type)  # Record type
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date (2025-01-31)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Subsystem ID (EBCDIC)
    subsys_id = "DB2P".encode('cp037')
    record[18:22] = subsys_id
    
    # Subtype
    struct.pack_into('>H', record, 22, 1)  # IFCID 1
    
    # Triplet count
    struct.pack_into('>H', record, 24, 1)
    
    # Reserved
    struct.pack_into('>H', record, 26, 0)
    
    # Product section triplet (offset 28)
    product_offset = 44  # Start product section after header
    struct.pack_into('>I', record, 28, product_offset)  # Offset
    struct.pack_into('>H', record, 32, 100)  # Length
    struct.pack_into('>H', record, 34, 1)  # Count
    
    # Data section triplet (offset 36)
    struct.pack_into('>I', record, 36, 0)  # Offset (not used for version detection)
    struct.pack_into('>H', record, 40, 0)  # Length
    struct.pack_into('>H', record, 42, 0)  # Count
    
    # QWHS standard header in product section (starts at offset 44)
    # QWHSLEN - Header length
    struct.pack_into('>H', record, product_offset, 92)
    
    # QWHSTYPE - Header type
    struct.pack_into('B', record, product_offset + 2, 1)
    
    # QWHSRMID - Resource manager ID
    struct.pack_into('B', record, product_offset + 3, 0xDB)  # DB2 identifier
    
    # QWHSIFID - IFCID
    struct.pack_into('>H', record, product_offset + 4, 1)
    
    # QWHSRELN - Release number (THIS IS THE KEY FIELD)
    struct.pack_into('>H', record, product_offset + 6, db2_version_code)
    
    # QWHSNSDA - Number of self-defining areas
    struct.pack_into('B', record, product_offset + 8, 0)
    
    # QWHSRELI - Release indicator
    struct.pack_into('B', record, product_offset + 9, 0)
    
    # QWHSACEA - ACE address
    struct.pack_into('>I', record, product_offset + 10, 0)
    
    # QWHSSSID - Subsystem name (EBCDIC)
    subsys_name = "DB2P".encode('cp037')
    record[product_offset + 14:product_offset + 18] = subsys_name
    
    # QWHSSTCK - Store clock
    struct.pack_into('>Q', record, product_offset + 18, 0)
    
    # QWHSISEQ - IFCID sequence
    struct.pack_into('>I', record, product_offset + 26, 1)
    
    # QWHSDSEQ - Destination sequence
    struct.pack_into('>I', record, product_offset + 30, 1)
    
    # QWHSTNUM - Trace number mask
    struct.pack_into('>I', record, product_offset + 34, 0)
    
    # QWHSLCNM - Local location name (EBCDIC)
    loc_name = "LOCDB2".encode('cp037')
    record[product_offset + 38:product_offset + 44] = loc_name
    record[product_offset + 44:product_offset + 54] = b'\x40' * 10  # Pad with EBCDIC spaces
    
    # QWHSLUWI - LUWID (24 bytes)
    record[product_offset + 54:product_offset + 78] = b'\x00' * 24
    
    # QWHSNETW - Network ID (EBCDIC, 8 bytes)
    record[product_offset + 78:product_offset + 86] = b'\x40' * 8
    
    # QWHSLUNM - LU name (EBCDIC, 8 bytes)
    record[product_offset + 86:product_offset + 94] = b'\x40' * 8
    
    return bytes(record)


# Strategies for generating test data

# Valid DB2 version codes and their string representations
valid_db2_versions = st.sampled_from([
    (0x0A00, "V10"),
    (0x0B00, "V11"),
    (0x0C00, "V12"),
    (0x0D00, "V13"),
])

# Valid DB2 record types
db2_record_types = st.sampled_from([100, 101, 102])

# Strategy for generating valid (record_type, version) combinations
# This ensures we only test combinations that are actually registered
@st.composite
def valid_db2_parser_combinations(draw):
    """Generate valid (record_type, version_code, version_str) combinations."""
    # Get registered parsers
    db2_parsers = SMFParserFactory.list_db2_parsers()
    
    if not db2_parsers:
        # Return a dummy value that will be skipped
        return (100, 0x0A00, "V10")
    
    # Choose a random record type from registered parsers
    record_type = draw(st.sampled_from(list(db2_parsers.keys())))
    
    # Choose a random version for that record type
    version_str = draw(st.sampled_from(db2_parsers[record_type]))
    
    # Map version string to code
    version_map = {
        "V10": 0x0A00,
        "V11": 0x0B00,
        "V12": 0x0C00,
        "V13": 0x0D00,
    }
    version_code = version_map.get(version_str, 0x0A00)
    
    return (record_type, version_code, version_str)


class TestParsedRecordStructureProperties:
    """Property-based tests for ParsedRecord structure consistency."""
    
    @settings(max_examples=100)
    @given(
        combination=valid_db2_parser_combinations()
    )
    def test_property_11_parsed_record_structure_consistency(
        self,
        combination
    ):
        """
        **Feature: db2-versioned-smf-parsers, Property 11: ParsedRecord Structure Consistency**
        **Validates: Requirements 6.4**
        
        For any DB2 SMF record (type 100, 101, or 102), the parsed result should be a
        ParsedRecord object with the same structure as other SMF record types (containing
        record_type, version, system_id, timestamp, date, and sections fields).
        """
        record_type, version_code, version_str = combination
        
        # Get all registered DB2 parsers
        db2_parsers = SMFParserFactory.list_db2_parsers()
        
        # Skip if no parsers registered at all
        if not db2_parsers:
            pytest.skip("No DB2 parsers registered")
        
        # Skip if this specific combination is not registered
        if record_type not in db2_parsers:
            pytest.skip(f"No parsers registered for record type {record_type}")
        
        if version_str not in db2_parsers[record_type]:
            pytest.skip(f"Parser not registered for {record_type} {version_str}")
        
        # Create test record
        record_data = create_db2_record_with_version(record_type, version_code)
        
        # Parse the record
        parser = SMFParserFactory.create_parser(
            record_type=record_type,
            record_data=record_data,
            allow_fallback=False
        )
        
        parsed = parser.parse(record_data, os_version=version_str)
        
        # Verify it's a ParsedRecord instance
        assert isinstance(parsed, ParsedRecord), \
            f"Parsed result should be ParsedRecord, got {type(parsed)}"
        
        # Verify required fields exist and have correct types
        assert hasattr(parsed, 'record_type'), "ParsedRecord should have record_type"
        assert isinstance(parsed.record_type, int), \
            f"record_type should be int, got {type(parsed.record_type)}"
        assert parsed.record_type == record_type, \
            f"record_type should be {record_type}, got {parsed.record_type}"
        
        assert hasattr(parsed, 'subtype'), "ParsedRecord should have subtype"
        assert isinstance(parsed.subtype, int), \
            f"subtype should be int, got {type(parsed.subtype)}"
        
        assert hasattr(parsed, 'record_length'), "ParsedRecord should have record_length"
        assert isinstance(parsed.record_length, int), \
            f"record_length should be int, got {type(parsed.record_length)}"
        assert parsed.record_length > 0, \
            f"record_length should be positive, got {parsed.record_length}"
        
        assert hasattr(parsed, 'system_id'), "ParsedRecord should have system_id"
        assert isinstance(parsed.system_id, str), \
            f"system_id should be str, got {type(parsed.system_id)}"
        assert len(parsed.system_id) > 0, "system_id should not be empty"
        
        assert hasattr(parsed, 'timestamp'), "ParsedRecord should have timestamp"
        assert isinstance(parsed.timestamp, datetime), \
            f"timestamp should be datetime, got {type(parsed.timestamp)}"
        
        assert hasattr(parsed, 'date'), "ParsedRecord should have date"
        assert isinstance(parsed.date, date), \
            f"date should be date, got {type(parsed.date)}"
        
        assert hasattr(parsed, 'header'), "ParsedRecord should have header"
        assert isinstance(parsed.header, dict), \
            f"header should be dict, got {type(parsed.header)}"
        
        # Verify header contains expected DB2 sections
        assert 'smf_header' in parsed.header, \
            "header should contain smf_header section"
        assert 'qwhs_header' in parsed.header, \
            "header should contain qwhs_header section (DB2 standard header)"
        
        # Verify the header sections are dictionaries
        assert isinstance(parsed.header['smf_header'], dict), \
            "smf_header should be a dict"
        assert isinstance(parsed.header['qwhs_header'], dict), \
            "qwhs_header should be a dict"
        
        # Verify ParsedRecord has to_dict method
        assert hasattr(parsed, 'to_dict'), "ParsedRecord should have to_dict method"
        assert callable(parsed.to_dict), "to_dict should be callable"
        
        # Verify to_dict returns a dictionary
        parsed_dict = parsed.to_dict()
        assert isinstance(parsed_dict, dict), \
            f"to_dict should return dict, got {type(parsed_dict)}"
        
        # Verify to_dict contains all required fields
        required_fields = [
            'record_type', 'subtype', 'record_length',
            'system_id', 'timestamp', 'date', 'header'
        ]
        for field in required_fields:
            assert field in parsed_dict, \
                f"to_dict result should contain {field}"
        
        # Verify ParsedRecord has to_json method
        assert hasattr(parsed, 'to_json'), "ParsedRecord should have to_json method"
        assert callable(parsed.to_json), "to_json should be callable"
        
        # Verify to_json returns a string
        parsed_json = parsed.to_json()
        assert isinstance(parsed_json, str), \
            f"to_json should return str, got {type(parsed_json)}"
        
        # Verify JSON is valid (can be parsed)
        import json
        try:
            json_data = json.loads(parsed_json)
            assert isinstance(json_data, dict), "Parsed JSON should be a dict"
        except json.JSONDecodeError as e:
            pytest.fail(f"to_json should produce valid JSON: {e}")
    
    def test_parsed_record_optional_fields(self):
        """
        Test that ParsedRecord has optional fields defined.
        
        This is not a property test but validates the model structure.
        """
        # Create a minimal ParsedRecord
        parsed = ParsedRecord(
            record_type=100,
            subtype=1,
            record_length=200,
            system_id="SYS1",
            timestamp=datetime.now(),
            date=date.today(),
            header={'test': 'data'}
        )
        
        # Verify optional fields exist and default to None
        optional_fields = [
            'subsystem', 'identification', 'io_activity',
            'completion', 'processor', 'excp_sections',
            'storage', 'accounting', 'performance', 'operator'
        ]
        
        for field in optional_fields:
            assert hasattr(parsed, field), \
                f"ParsedRecord should have optional field {field}"
            assert getattr(parsed, field) is None, \
                f"Optional field {field} should default to None"
        
        # Verify continuation fields exist
        assert hasattr(parsed, 'is_continuation'), \
            "ParsedRecord should have is_continuation field"
        assert parsed.is_continuation is False, \
            "is_continuation should default to False"
        
        assert hasattr(parsed, 'continuation_count'), \
            "ParsedRecord should have continuation_count field"
        assert parsed.continuation_count == 0, \
            "continuation_count should default to 0"
    
    def test_parsed_record_consistency_across_types(self):
        """
        Test that all registered DB2 parsers return consistent ParsedRecord structures.
        
        This test verifies that different DB2 record types and versions all produce
        ParsedRecord objects with the same basic structure.
        """
        # Get all registered DB2 parsers
        db2_parsers = SMFParserFactory.list_db2_parsers()
        
        if not db2_parsers:
            pytest.skip("No DB2 parsers registered")
        
        version_map = {
            "V10": 0x0A00,
            "V11": 0x0B00,
            "V12": 0x0C00,
            "V13": 0x0D00,
        }
        
        parsed_records = []
        
        # Parse a record for each registered parser
        for record_type, versions in db2_parsers.items():
            for version_str in versions:
                version_code = version_map.get(version_str)
                if version_code is None:
                    continue
                
                # Create and parse record
                record_data = create_db2_record_with_version(record_type, version_code)
                parser = SMFParserFactory.create_parser(
                    record_type=record_type,
                    record_data=record_data,
                    allow_fallback=False
                )
                
                parsed = parser.parse(record_data, os_version=version_str)
                parsed_records.append((record_type, version_str, parsed))
        
        # Verify all parsed records have the same structure
        if len(parsed_records) < 2:
            pytest.skip("Need at least 2 parsers to test consistency")
        
        # Get field names from first record
        first_record = parsed_records[0][2]
        expected_fields = set(vars(first_record).keys())
        
        # Verify all other records have the same fields
        for record_type, version_str, parsed in parsed_records[1:]:
            actual_fields = set(vars(parsed).keys())
            
            assert actual_fields == expected_fields, \
                f"Type {record_type} {version_str} has different fields: " \
                f"expected {expected_fields}, got {actual_fields}"
            
            # Verify field types match
            for field in expected_fields:
                first_type = type(getattr(first_record, field))
                actual_type = type(getattr(parsed, field))
                
                # Allow None to match any type (optional fields)
                if getattr(first_record, field) is None or getattr(parsed, field) is None:
                    continue
                
                assert first_type == actual_type, \
                    f"Type {record_type} {version_str} field {field} has different type: " \
                    f"expected {first_type}, got {actual_type}"
