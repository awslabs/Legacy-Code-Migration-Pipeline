"""Unit tests for SMF Type 18 parser."""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers import SMF18ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type18_record() -> bytes:
    """Create a valid Type 18 record with 2 volumes."""
    record = bytearray(152)  # 136 bytes header + 16 bytes for 2 volumes
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 152)  # SMF18LEN
    struct.pack_into('>H', record, 2, 0)  # SMF18SEG
    struct.pack_into('B', record, 4, 0x01)  # SMF18FLG
    struct.pack_into('B', record, 5, 18)  # SMF18RTY - Record type = 18
    struct.pack_into('>I', record, 6, 36000)  # SMF18TME
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF18DTE
    
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id  # SMF18SID
    
    # Job identification
    job_name = "RENAMEJ ".encode('cp037')
    record[18:26] = job_name  # SMF18JBN
    struct.pack_into('>I', record, 26, 3240000)  # SMF18RST
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF18RSD
    user_id = "RENUSER ".encode('cp037')
    record[34:42] = user_id  # SMF18UID
    
    # Record indicators
    struct.pack_into('B', record, 42, 0x00)  # SMF18IN1 - not continuation
    struct.pack_into('B', record, 43, 0x00)  # SMF18IN2
    
    # Data set names
    old_ds = "OLD.DATASET.NAME".ljust(44).encode('cp037')
    record[44:88] = old_ds  # SMF180DS
    new_ds = "NEW.DATASET.NAME".ljust(44).encode('cp037')
    record[88:132] = new_ds  # SMF18NDS
    
    # Number of volumes
    struct.pack_into('B', record, 135, 2)  # SMF18NVL
    
    # Volume information (2 volumes)
    vol1 = "VOL001".encode('cp037')
    record[138:144] = vol1  # SMF18FVL
    vol2 = "VOL002".encode('cp037')
    record[146:152] = vol2  # SMF18FVL
    
    return bytes(record)


class TestSMF18Parser:
    """Test suite for SMF Type 18 parser."""
    
    def test_parse_record(self):
        """Test parsing a Type 18 record."""
        record_data = create_type18_record()
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF18ParserV3R2(base_parser)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 18
        assert result.system_id == "SYS1"
        assert result.identification['job_name'] == "RENAMEJ"
        
        rename_info = result.io_activity['rename_info']
        assert "OLD.DATASET.NAME" in rename_info['old_dataset_name']
        assert "NEW.DATASET.NAME" in rename_info['new_dataset_name']
        assert rename_info['volume_count'] == 2
        assert not rename_info['is_continuation']
        
        volumes = result.io_activity['volumes']
        assert len(volumes) == 2
        assert volumes[0]['volume_serial'] == "VOL001"
        assert volumes[1]['volume_serial'] == "VOL002"
    
    def test_parse_invalid_record_type(self):
        """Test that parser rejects wrong record type."""
        record_data = bytearray(create_type18_record())
        record_data[5] = 17
        
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF18ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(record_data))
