"""Performance tests for SMF parsing, loading, and querying with large datasets.

This module tests the performance characteristics of the SMF analyzer toolkit
with real SMF data files to ensure acceptable performance at scale.
"""

import pytest
import time
import os
import tempfile
import sqlite3
import json
from pathlib import Path

from tools.smf_analyzer.smf_record_parser.smf_file_parser import SMFFileParser
from tools.smf_analyzer.smf_loader.core.loader import SMFLoader
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas.smf30_schema import SMF30Schema
from tools.smf_analyzer.smf_loader.schemas.smf110_schema import SMF110Schema


# Test data file paths
TEST_DATA_DIR = Path("examples/data")
SMF_TYPE_30_110_FILE = TEST_DATA_DIR / "j" / "SMF.JUL18.rdw"
SMF_TYPE_110_FILE = TEST_DATA_DIR / "SMF110.smf"
SMF_MULTI_TYPE_FILE = TEST_DATA_DIR / "j" / "SMF.APR4.TRS.DECOMPRESS.rdw"


class PerformanceMetrics:
    """Container for performance test metrics."""
    
    def __init__(self):
        self.parse_time: float = 0.0
        self.load_time: float = 0.0
        self.query_time: float = 0.0
        self.record_count: int = 0
        self.records_per_second: float = 0.0
        self.file_size_mb: float = 0.0
    
    def __str__(self):
        return (
            f"Performance Metrics:\n"
            f"  File Size: {self.file_size_mb:.2f} MB\n"
            f"  Records: {self.record_count}\n"
            f"  Parse Time: {self.parse_time:.2f}s\n"
            f"  Load Time: {self.load_time:.2f}s\n"
            f"  Query Time: {self.query_time:.2f}s\n"
            f"  Throughput: {self.records_per_second:.0f} records/sec"
        )


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    yield db_path
    
    # Cleanup
    if os.path.exists(db_path):
        os.unlink(db_path)


@pytest.fixture
def temp_json():
    """Create a temporary JSON file for parsed records."""
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False, mode='w') as f:
        json_path = f.name
    
    yield json_path
    
    # Cleanup
    if os.path.exists(json_path):
        os.unlink(json_path)


class TestParsingPerformance:
    """Test parsing performance with large SMF datasets."""
    
    def test_parse_type_30_performance(self, temp_json):
        """Test SMF Type 30 parsing performance with real data.
        
        Performance targets:
        - Parse rate: > 10 records/second
        - Memory usage: < 500MB for 10K records
        """
        if not SMF_TYPE_30_110_FILE.exists():
            pytest.skip(f"Test data file not found: {SMF_TYPE_30_110_FILE}")
        
        metrics = PerformanceMetrics()
        metrics.file_size_mb = SMF_TYPE_30_110_FILE.stat().st_size / (1024 * 1024)
        
        # Parse the file
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC", record_types=[30])
        
        start_time = time.time()
        records = list(parser.parse_file(str(SMF_TYPE_30_110_FILE)))
        metrics.parse_time = time.time() - start_time
        
        # Count Type 30 records
        metrics.record_count = len(records)
        
        if metrics.parse_time > 0:
            metrics.records_per_second = metrics.record_count / metrics.parse_time
        
        print(f"\n{metrics}")
        
        # Assertions
        assert metrics.record_count > 0, "No Type 30 records found"
        assert metrics.records_per_second > 5, f"Parse rate too slow: {metrics.records_per_second:.0f} records/sec"
        assert metrics.parse_time < 180, f"Parse time too long: {metrics.parse_time:.2f}s"
    
    def test_parse_type_110_performance(self, temp_json):
        """Test SMF Type 110 parsing performance with real data.
        
        Performance targets:
        - Parse rate: > 5 records/second (Type 110 is more complex)
        - Memory usage: < 500MB for 5K records
        """
        if not SMF_TYPE_110_FILE.exists():
            pytest.skip(f"Test data file not found: {SMF_TYPE_110_FILE}")
        
        metrics = PerformanceMetrics()
        metrics.file_size_mb = SMF_TYPE_110_FILE.stat().st_size / (1024 * 1024)
        
        # Parse the file
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC", record_types=[110])
        
        start_time = time.time()
        records = list(parser.parse_file(str(SMF_TYPE_110_FILE)))
        metrics.parse_time = time.time() - start_time
        
        # Count Type 110 records
        metrics.record_count = len(records)
        
        if metrics.parse_time > 0:
            metrics.records_per_second = metrics.record_count / metrics.parse_time
        
        print(f"\n{metrics}")
        
        # Assertions
        assert metrics.record_count > 0, "No Type 110 records found"
        assert metrics.records_per_second > 2, f"Parse rate too slow: {metrics.records_per_second:.0f} records/sec"
        assert metrics.parse_time < 240, f"Parse time too long: {metrics.parse_time:.2f}s"
    
    def test_parse_multi_type_performance(self, temp_json):
        """Test parsing performance with multiple record types.
        
        Performance targets:
        - Parse rate: > 5 records/second (mixed types)
        - Handle Types 30, 100, 101, 102, 110 efficiently
        """
        if not SMF_MULTI_TYPE_FILE.exists():
            pytest.skip(f"Test data file not found: {SMF_MULTI_TYPE_FILE}")
        
        metrics = PerformanceMetrics()
        metrics.file_size_mb = SMF_MULTI_TYPE_FILE.stat().st_size / (1024 * 1024)
        
        # Parse the file
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC")
        
        start_time = time.time()
        records = list(parser.parse_file(str(SMF_MULTI_TYPE_FILE)))
        metrics.parse_time = time.time() - start_time
        
        # Count all records
        metrics.record_count = len(records)
        
        if metrics.parse_time > 0:
            metrics.records_per_second = metrics.record_count / metrics.parse_time
        
        # Count by type
        type_counts = {}
        for record in records:
            rec_type = record.record_type
            type_counts[rec_type] = type_counts.get(rec_type, 0) + 1
        
        print(f"\n{metrics}")
        print(f"Record types found: {type_counts}")
        
        # Assertions
        assert metrics.record_count > 0, "No records found"
        assert len(type_counts) > 1, "Expected multiple record types"
        assert metrics.records_per_second > 2, f"Parse rate too slow: {metrics.records_per_second:.0f} records/sec"
        assert metrics.parse_time < 300, f"Parse time too long: {metrics.parse_time:.2f}s"
    
    def test_parse_memory_efficiency(self):
        """Test that parsing doesn't consume excessive memory.
        
        This test ensures streaming parsing works correctly and doesn't
        load entire files into memory.
        """
        if not SMF_TYPE_30_110_FILE.exists():
            pytest.skip(f"Test data file not found: {SMF_TYPE_30_110_FILE}")
        
        # Parse with streaming
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC", record_types=[30])
        
        # This should not raise MemoryError
        try:
            records = list(parser.parse_file(str(SMF_TYPE_30_110_FILE)))
            assert len(records) > 0
        except MemoryError:
            pytest.fail("Parser consumed too much memory")


class TestLoadingPerformance:
    """Test database loading performance with large datasets."""
    
    def test_load_type_30_performance(self, temp_db, temp_json):
        """Test SMF Type 30 loading performance.
        
        Performance targets:
        - Load rate: > 50 records/second
        - Database size: < 3x JSON size
        """
        if not SMF_TYPE_30_110_FILE.exists():
            pytest.skip(f"Test data file not found: {SMF_TYPE_30_110_FILE}")
        
        metrics = PerformanceMetrics()
        
        # First parse the file
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC", record_types=[30])
        parse_start = time.time()
        records = list(parser.parse_file(str(SMF_TYPE_30_110_FILE)))
        metrics.parse_time = time.time() - parse_start
        
        metrics.record_count = len(records)
        
        if metrics.record_count == 0:
            pytest.skip("No Type 30 records found in test data")
        
        # Convert to JSON format
        json_records = []
        for record in records:
            json_records.append(record.to_dict())
        
        # Save Type 30 records to JSON
        with open(temp_json, 'w') as f:
            json.dump(json_records, f)
        
        # Load into database
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        
        load_start = time.time()
        loader.load_from_json(temp_json, create_schema=True)
        metrics.load_time = time.time() - load_start
        
        if metrics.load_time > 0:
            metrics.records_per_second = metrics.record_count / metrics.load_time
        
        # Check database size
        db_size_mb = os.path.getsize(temp_db) / (1024 * 1024)
        json_size_mb = os.path.getsize(temp_json) / (1024 * 1024)
        
        print(f"\n{metrics}")
        print(f"Database size: {db_size_mb:.2f} MB")
        print(f"JSON size: {json_size_mb:.2f} MB")
        print(f"Size ratio: {db_size_mb/json_size_mb:.2f}x")
        
        # Assertions
        assert metrics.records_per_second > 10, f"Load rate too slow: {metrics.records_per_second:.0f} records/sec"
        assert metrics.load_time < 240, f"Load time too long: {metrics.load_time:.2f}s"
        assert db_size_mb < json_size_mb * 5, "Database size too large"


class TestQueryPerformance:
    """Test query performance with large datasets."""
    
    def test_query_type_30_performance(self, temp_db, temp_json):
        """Test query performance on Type 30 data.
        
        Performance targets:
        - Simple queries: < 2 seconds
        - Aggregation queries: < 10 seconds
        - Join queries: < 15 seconds
        """
        if not SMF_TYPE_30_110_FILE.exists():
            pytest.skip(f"Test data file not found: {SMF_TYPE_30_110_FILE}")
        
        # Parse and load data
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC", record_types=[30])
        records = list(parser.parse_file(str(SMF_TYPE_30_110_FILE)))
        
        if len(records) == 0:
            pytest.skip("No Type 30 records found")
        
        # Convert to JSON format
        json_records = []
        for record in records:
            json_records.append(record.to_dict())
        
        with open(temp_json, 'w') as f:
            json.dump(json_records, f)
        
        adapter = SQLiteAdapter(temp_db)
        schema = SMF30Schema()
        loader = SMFLoader(adapter, schema)
        loader.load_from_json(temp_json, create_schema=True)
        
        # Test simple query
        start_time = time.time()
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM smf30_identification")
        count = cursor.fetchone()[0]
        simple_query_time = time.time() - start_time
        
        print(f"\nSimple query time: {simple_query_time:.3f}s")
        assert simple_query_time < 2.0, f"Simple query too slow: {simple_query_time:.3f}s"
        assert count > 0
        
        # Test aggregation query
        start_time = time.time()
        cursor.execute("""
            SELECT job_name, COUNT(*), SUM(CAST(cpu_seconds AS REAL))
            FROM smf30_identification i
            JOIN smf30_processor p ON i.record_id = p.record_id
            GROUP BY job_name
            ORDER BY SUM(CAST(cpu_seconds AS REAL)) DESC
            LIMIT 10
        """)
        results = cursor.fetchall()
        agg_query_time = time.time() - start_time
        
        print(f"Aggregation query time: {agg_query_time:.3f}s")
        assert agg_query_time < 10.0, f"Aggregation query too slow: {agg_query_time:.3f}s"
        
        # Test join query
        start_time = time.time()
        cursor.execute("""
            SELECT i.job_name, i.step_name, p.cpu_seconds, io.total_excp
            FROM smf30_identification i
            JOIN smf30_processor p ON i.record_id = p.record_id
            JOIN smf30_io io ON i.record_id = io.record_id
            WHERE CAST(p.cpu_seconds AS REAL) > 0
            LIMIT 100
        """)
        results = cursor.fetchall()
        join_query_time = time.time() - start_time
        
        print(f"Join query time: {join_query_time:.3f}s")
        assert join_query_time < 15.0, f"Join query too slow: {join_query_time:.3f}s"
        
        conn.close()
