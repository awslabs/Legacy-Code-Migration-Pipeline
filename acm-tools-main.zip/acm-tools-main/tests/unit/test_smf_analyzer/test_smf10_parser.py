"""Unit tests for SMF Type 10 parser."""

import pytest
import struct
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF10ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type10_record_minimal() -> bytes:
    """Create a minimal valid Type 10 record with 1 device.
    
    This represents a basic allocation recovery for one device.
    """
    record = bytearray(48)  # 44 bytes header + 4 bytes for 1 device
    
    # Standard SMF header (offsets 0-17)
    struct.pack_into('>H', record, 0, 48)  # SMF10LEN - Record length
    struct.pack_into('>H', record, 2, 0)  # SMF10SEG - Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # SMF10FLG - System indicator
    struct.pack_into('B', record, 5, 10)  # SMF10RTY - Record type = 10
    struct.pack_into('>I', record, 6, 36000)  # SMF10TME - Timestamp (10:00:00.00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF10DTE - Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id  # SMF10SID
    
    # Job identification (offsets 18-41)
    job_name = "TESTJOB ".encode('cp037')
    record[18:26] = job_name  # SMF10JBN
    struct.pack_into('>I', record, 26, 3240000)  # SMF10RST - Reader timestamp (09:00:00.00)
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF10RSD - Reader date (2025-001)
    user_id = "USER001 ".encode('cp037')
    record[34:42] = user_id  # SMF10UIF
    
    # Length of rest of record (2 bytes for length field + 4 bytes for device)
    struct.pack_into('>H', record, 42, 6)  # SMF10LN
    
    # Device data (1 device at offset 44)
    # Device class = 5, Unit type = 10
    device_type = (5 << 8) | 10  # SMF10DUT
    struct.pack_into('>H', record, 44, device_type)
    struct.pack_into('>H', record, 46, 0x0100)  # SMF10CUA - Device number
    
    return bytes(record)


def create_type10_record_system_task() -> bytes:
    """Create a Type 10 record for a system task.
    
    System tasks have blank job name and zero timestamps.
    """
    record = bytearray(48)  # 44 bytes header + 4 bytes for 1 device
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 48)
    struct.pack_into('>H', record, 2, 0)
    struct.pack_into('B', record, 4, 0x01)
    struct.pack_into('B', record, 5, 10)
    struct.pack_into('>I', record, 6, 36000)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Job identification for system task (blank/zero)
    record[18:26] = bytes([0x40] * 8)  # SMF10JBN - blank job name (EBCDIC spaces)
    struct.pack_into('>I', record, 26, 0)  # SMF10RST - zero timestamp
    record[30:34] = bytes([0x00, 0x00, 0x00, 0x0F])  # SMF10RSD - zero date
    record[34:42] = bytes([0x40] * 8)  # SMF10UIF - blank user ID (EBCDIC spaces)
    
    # Length of rest of record
    struct.pack_into('>H', record, 42, 6)
    
    # Device data
    device_type = (5 << 8) | 10
    struct.pack_into('>H', record, 44, device_type)
    struct.pack_into('>H', record, 46, 0x0100)
    
    return bytes(record)


def create_type10_record_multiple_devices() -> bytes:
    """Create a Type 10 record with multiple devices (5 devices)."""
    num_devices = 5
    record_length = 44 + (num_devices * 4)
    record = bytearray(record_length)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('>H', record, 2, 0)
    struct.pack_into('B', record, 4, 0x01)
    struct.pack_into('B', record, 5, 10)
    struct.pack_into('>I', record, 6, 36000)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    sys_id = "PROD".encode('cp037')
    record[14:18] = sys_id
    
    # Job identification
    job_name = "BATCHJOB".encode('cp037')
    record[18:26] = job_name
    struct.pack_into('>I', record, 26, 3240000)
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])
    user_id = "ADMIN   ".encode('cp037')
    record[34:42] = user_id
    
    # Length of rest of record
    rest_length = 2 + (num_devices * 4)
    struct.pack_into('>H', record, 42, rest_length)
    
    # Device data (5 devices)
    devices = [
        (5, 10, 0x0100),   # DASD
        (10, 20, 0x0200),  # Tape
        (15, 30, 0x0300),  # Communications
        (20, 40, 0x0400),  # Display
        (25, 50, 0x0500),  # Unit record
    ]
    
    for i, (dev_class, unit_type, dev_num) in enumerate(devices):
        offset = 44 + (i * 4)
        device_type = (dev_class << 8) | unit_type
        struct.pack_into('>H', record, offset, device_type)
        struct.pack_into('>H', record, offset + 2, dev_num)
    
    return bytes(record)


def create_type10_record_with_vio() -> bytes:
    """Create a Type 10 record with Virtual I/O device.
    
    Virtual I/O devices have:
    - Device class: 0
    - Unit type: 0
    - Device number: 0x7FFF
    """
    num_devices = 3
    record_length = 44 + (num_devices * 4)
    record = bytearray(record_length)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('>H', record, 2, 0)
    struct.pack_into('B', record, 4, 0x01)
    struct.pack_into('B', record, 5, 10)
    struct.pack_into('>I', record, 6, 36000)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Job identification
    job_name = "VIOJOB  ".encode('cp037')
    record[18:26] = job_name
    struct.pack_into('>I', record, 26, 3240000)
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])
    user_id = "USER001 ".encode('cp037')
    record[34:42] = user_id
    
    # Length of rest of record
    rest_length = 2 + (num_devices * 4)
    struct.pack_into('>H', record, 42, rest_length)
    
    # Device data: 1 regular device, 1 VIO device, 1 regular device
    devices = [
        (5, 10, 0x0100),    # Regular DASD
        (0, 0, 0x7FFF),     # Virtual I/O
        (10, 20, 0x0200),   # Regular Tape
    ]
    
    for i, (dev_class, unit_type, dev_num) in enumerate(devices):
        offset = 44 + (i * 4)
        device_type = (dev_class << 8) | unit_type
        struct.pack_into('>H', record, offset, device_type)
        struct.pack_into('>H', record, offset + 2, dev_num)
    
    return bytes(record)


def create_type10_record_no_devices() -> bytes:
    """Create a Type 10 record with no devices (edge case)."""
    record = bytearray(44)  # Just the header, no device data
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 44)
    struct.pack_into('>H', record, 2, 0)
    struct.pack_into('B', record, 4, 0x01)
    struct.pack_into('B', record, 5, 10)
    struct.pack_into('>I', record, 6, 36000)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Job identification
    job_name = "TESTJOB ".encode('cp037')
    record[18:26] = job_name
    struct.pack_into('>I', record, 26, 3240000)
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])
    user_id = "USER001 ".encode('cp037')
    record[34:42] = user_id
    
    # Length of rest of record (just the length field itself)
    struct.pack_into('>H', record, 42, 2)
    
    return bytes(record)


def create_type10_record_invalid_type() -> bytes:
    """Create a record with wrong record type."""
    record = bytearray(create_type10_record_minimal())
    struct.pack_into('B', record, 5, 9)  # Wrong type (9 instead of 10)
    return bytes(record)


def create_type10_record_truncated() -> bytes:
    """Create a truncated Type 10 record."""
    record = create_type10_record_minimal()
    return record[:20]  # Truncate to 20 bytes (incomplete header)


class TestSMF10ParserV3R2:
    """Unit tests for SMF Type 10 parser."""
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal valid Type 10 record with 1 device."""
        record_data = create_type10_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header
        assert parsed.record_type == 10
        assert parsed.subtype == 0  # Type 10 has no subtypes
        assert parsed.record_length == 48
        assert parsed.system_id == "SYS1"
        assert parsed.date is not None
        
        # Verify job identification
        assert parsed.identification is not None
        job_info = parsed.identification
        assert job_info['job_name'] == "TESTJOB"
        assert job_info['user_id'] == "USER001"
        assert job_info['is_system_task'] is False
        
        # Verify device data
        assert parsed.io_activity is not None
        assert 'devices' in parsed.io_activity
        assert 'device_count' in parsed.io_activity
        
        devices = parsed.io_activity['devices']
        assert len(devices) == 1
        assert parsed.io_activity['device_count'] == 1
        
        # Verify device fields
        device = devices[0]
        assert device['device_class'] == 5
        assert device['unit_type'] == 10
        assert device['device_number'] == 0x0100
        assert device['device_number_hex'] == "0x0100"
        assert device['is_virtual_io'] is False
    
    def test_parse_system_task(self):
        """Test parsing Type 10 record for a system task."""
        record_data = create_type10_record_system_task()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify system task detection
        job_info = parsed.identification
        assert job_info['is_system_task'] is True
        assert job_info['job_name'] == ""
        assert job_info['user_id'] == ""
        assert job_info['reader_timestamp'] == "00:00:00.00"
    
    def test_parse_multiple_devices(self):
        """Test parsing Type 10 record with multiple devices."""
        record_data = create_type10_record_multiple_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify device count
        devices = parsed.io_activity['devices']
        assert len(devices) == 5
        assert parsed.io_activity['device_count'] == 5
        
        # Verify each device
        expected_devices = [
            (5, 10, 0x0100),
            (10, 20, 0x0200),
            (15, 30, 0x0300),
            (20, 40, 0x0400),
            (25, 50, 0x0500),
        ]
        
        for i, (exp_class, exp_type, exp_num) in enumerate(expected_devices):
            device = devices[i]
            assert device['device_class'] == exp_class, f"Device {i} class mismatch"
            assert device['unit_type'] == exp_type, f"Device {i} unit type mismatch"
            assert device['device_number'] == exp_num, f"Device {i} number mismatch"
            assert device['is_virtual_io'] is False, f"Device {i} should not be VIO"
    
    def test_parse_virtual_io_device(self):
        """Test parsing Type 10 record with Virtual I/O device."""
        record_data = create_type10_record_with_vio()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify device count
        devices = parsed.io_activity['devices']
        assert len(devices) == 3
        
        # First device: regular
        assert devices[0]['is_virtual_io'] is False
        assert devices[0]['device_class'] == 5
        assert devices[0]['unit_type'] == 10
        assert devices[0]['device_number'] == 0x0100
        
        # Second device: VIO
        assert devices[1]['is_virtual_io'] is True
        assert devices[1]['device_class'] == 0
        assert devices[1]['unit_type'] == 0
        assert devices[1]['device_number'] == 0x7FFF
        assert devices[1]['device_number_hex'] == "0x7FFF"
        
        # Third device: regular
        assert devices[2]['is_virtual_io'] is False
        assert devices[2]['device_class'] == 10
        assert devices[2]['unit_type'] == 20
        assert devices[2]['device_number'] == 0x0200
    
    def test_parse_no_devices(self):
        """Test parsing Type 10 record with no devices (edge case)."""
        record_data = create_type10_record_no_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify no devices
        devices = parsed.io_activity['devices']
        assert len(devices) == 0
        assert parsed.io_activity['device_count'] == 0
    
    def test_parse_invalid_record_type(self):
        """Test error handling for invalid record type."""
        record_data = create_type10_record_invalid_type()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "expected 10" in str(exc_info.value)
    
    def test_parse_truncated_record(self):
        """Test error handling for truncated record."""
        record_data = create_type10_record_truncated()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "Record length mismatch" in str(exc_info.value)
    
    def test_header_fields_extraction(self):
        """Test that all header fields are correctly extracted."""
        record_data = create_type10_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify all header fields are present
        header = parsed.header
        assert 'record_length' in header
        assert 'segment_descriptor' in header
        assert 'system_indicator' in header
        assert 'record_type' in header
        assert 'timestamp' in header
        assert 'date' in header
        assert 'system_id' in header
        assert 'rest_of_record_length' in header
        
        # Verify header values
        assert header['record_type'] == 10
        assert header['record_length'] == 48
        assert header['rest_of_record_length'] == 6
    
    def test_job_identification_fields(self):
        """Test that all job identification fields are correctly extracted."""
        record_data = create_type10_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify all job identification fields are present
        job_info = parsed.identification
        assert 'job_name' in job_info
        assert 'reader_timestamp' in job_info
        assert 'reader_date' in job_info
        assert 'user_id' in job_info
        assert 'is_system_task' in job_info
        
        # Verify values
        assert job_info['job_name'] == "TESTJOB"
        assert job_info['user_id'] == "USER001"
        assert job_info['reader_timestamp'] == "09:00:00.00"
        assert isinstance(job_info['reader_date'], date)
    
    def test_device_hex_format(self):
        """Test that device numbers are correctly formatted as hex."""
        record_data = create_type10_record_multiple_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        devices = parsed.io_activity['devices']
        
        # Verify hex formatting
        assert devices[0]['device_number_hex'] == "0x0100"
        assert devices[1]['device_number_hex'] == "0x0200"
        assert devices[2]['device_number_hex'] == "0x0300"
        assert devices[3]['device_number_hex'] == "0x0400"
        assert devices[4]['device_number_hex'] == "0x0500"
    
    def test_to_dict_conversion(self):
        """Test conversion of parsed record to dictionary."""
        record_data = create_type10_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Convert to dictionary
        record_dict = parsed.to_dict()
        
        # Verify dictionary structure
        assert isinstance(record_dict, dict)
        assert record_dict['record_type'] == 10
        assert record_dict['subtype'] == 0
        assert 'header' in record_dict
        assert 'identification' in record_dict
        assert 'io_activity' in record_dict
        assert 'devices' in record_dict['io_activity']
    
    def test_device_class_unit_type_extraction(self):
        """Test that device class and unit type are correctly extracted from 2-byte field."""
        record_data = create_type10_record_multiple_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF10ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        devices = parsed.io_activity['devices']
        
        # Verify device class (high byte) and unit type (low byte) extraction
        assert devices[0]['device_class'] == 5
        assert devices[0]['unit_type'] == 10
        
        assert devices[1]['device_class'] == 10
        assert devices[1]['unit_type'] == 20
        
        assert devices[2]['device_class'] == 15
        assert devices[2]['unit_type'] == 30
