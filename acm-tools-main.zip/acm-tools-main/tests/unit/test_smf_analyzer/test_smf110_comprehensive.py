#!/usr/bin/env python3
"""Comprehensive test script for SMF Type 110 parser - parses multiple records."""

import json
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory


def parse_all_smf110_records(filename, max_records=10):
    """Parse multiple SMF Type 110 records from a file.
    
    Args:
        filename: Path to SMF file
        max_records: Maximum number of records to parse
        
    Returns:
        List of parsed records
    """
    with open(filename, 'rb') as f:
        all_data = f.read()
    
    print(f"Read {len(all_data)} bytes from {filename}")
    
    # Create parser for SMF Type 110
    parser = SMFParserFactory.create_parser(110, "V3R2", encoding="EBCDIC")
    
    parsed_records = []
    offset = 0
    record_num = 0
    
    while offset < len(all_data) and record_num < max_records:
        # Read record length
        if offset + 2 > len(all_data):
            break
        
        record_length = int.from_bytes(all_data[offset:offset+2], byteorder='big')
        
        # Check if we have enough data for the full record
        if offset + record_length > len(all_data):
            print(f"Warning: Incomplete record at offset {offset}")
            break
        
        # Extract record data
        record_data = all_data[offset:offset+record_length]
        
        # Check if this is an SMF Type 110 record
        record_type = record_data[5] if len(record_data) > 5 else 0
        
        if record_type == 110:
            try:
                # Parse the record
                parsed_record = parser.parse(record_data, "V3R2")
                parsed_records.append(parsed_record)
                record_num += 1
                
                print(f"\nRecord {record_num}:")
                print(f"  Offset: {offset}")
                print(f"  Length: {record_length}")
                print(f"  Subtype: {parsed_record.subtype}")
                print(f"  System ID: {parsed_record.system_id}")
                print(f"  Timestamp: {parsed_record.timestamp}")
                print(f"  Date: {parsed_record.date}")
                
                if parsed_record.subsystem:
                    print(f"  Product: {parsed_record.subsystem.get('product_name_generic', 'N/A')}")
                    print(f"  Data Class: {parsed_record.subsystem.get('data_class', 'N/A')}")
                
                if parsed_record.identification:
                    data_type = parsed_record.identification.get('type', 'unknown')
                    print(f"  CICS Data Type: {data_type}")
                    
                    if data_type == 'dictionary':
                        entries = parsed_record.identification.get('entries', [])
                        print(f"  Dictionary Entries: {len(entries)}")
                    elif data_type == 'performance':
                        records = parsed_record.identification.get('records', [])
                        print(f"  Performance Records: {len(records)}")
                
            except Exception as e:
                print(f"\nError parsing record at offset {offset}: {e}")
        else:
            print(f"\nSkipping non-110 record at offset {offset} (type {record_type})")
        
        # Move to next record
        offset += record_length
    
    print(f"\n{'='*80}")
    print(f"Parsed {len(parsed_records)} SMF Type 110 records")
    print(f"{'='*80}")
    
    return parsed_records


def analyze_records(records):
    """Analyze parsed records and print statistics."""
    if not records:
        print("No records to analyze")
        return
    
    print("\nRecord Statistics:")
    print("-" * 80)
    
    # Count by subtype
    subtype_counts = {}
    for record in records:
        subtype = record.subtype
        subtype_counts[subtype] = subtype_counts.get(subtype, 0) + 1
    
    print("\nSubtype Distribution:")
    subtype_names = {
        0: "CICS journaling",
        1: "CICS monitoring",
        2: "CICS statistics",
        3: "Shared temporary storage queue server statistics",
        4: "Coupling facility data table server statistics",
        5: "Named counter sequence number server statistics"
    }
    
    for subtype in sorted(subtype_counts.keys()):
        name = subtype_names.get(subtype, "Unknown")
        count = subtype_counts[subtype]
        print(f"  Subtype {subtype} ({name}): {count} records")
    
    # Count by data class
    data_class_counts = {}
    for record in records:
        if record.subsystem:
            data_class = record.subsystem.get('data_class', 'N/A')
            data_class_counts[data_class] = data_class_counts.get(data_class, 0) + 1
    
    print("\nData Class Distribution:")
    data_class_names = {
        1: "Dictionary",
        3: "Performance",
        4: "Exception",
        5: "Transaction Resource",
        6: "Identity"
    }
    
    for data_class in sorted(data_class_counts.keys()):
        if isinstance(data_class, int):
            name = data_class_names.get(data_class, "Unknown")
            count = data_class_counts[data_class]
            print(f"  Class {data_class} ({name}): {count} records")


if __name__ == '__main__':
    try:
        # Parse up to 10 records
        records = parse_all_smf110_records('examples/data/SMF110.smf', max_records=10)
        
        # Analyze the records
        analyze_records(records)
        
        # Save first record to JSON
        if records:
            output_file = 'smf110_first_record.json'
            with open(output_file, 'w') as f:
                f.write(records[0].to_json())
            print(f"\nFirst record saved to: {output_file}")
        
        print("\n" + "="*80)
        print("TEST COMPLETED SUCCESSFULLY")
        print("="*80)
        
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
