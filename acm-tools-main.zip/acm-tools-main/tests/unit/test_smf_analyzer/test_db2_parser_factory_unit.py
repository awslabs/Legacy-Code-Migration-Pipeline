"""Unit tests for DB2 parser factory unsupported version handling.

Feature: db2-versioned-smf-parsers
Tests: Requirements 11.1, 11.2, 11.3, 11.4, 11.5, 11.6
"""

import pytest
import struct
import logging
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
from tools.smf_analyzer.smf_record_parser.parsers.version_strategy import RecordVersionStrategy
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import UnsupportedVersionError


def create_db2_record_with_version(
    record_type: int,
    db2_version_code: int,
    record_length: int = 200
) -> bytes:
    """Create a synthetic DB2 SMF record with specified version."""
    record = bytearray(record_length)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('B', record, 5, record_type)
    
    # Product section triplet
    product_offset = 44
    struct.pack_into('>I', record, 28, product_offset)
    struct.pack_into('>H', record, 32, 100)
    struct.pack_into('>H', record, 34, 1)
    
    # QWHS header with version
    struct.pack_into('>H', record, product_offset, 92)
    struct.pack_into('B', record, product_offset + 2, 1)
    struct.pack_into('B', record, product_offset + 3, 0xDB)
    struct.pack_into('>H', record, product_offset + 4, 1)
    struct.pack_into('>H', record, product_offset + 6, db2_version_code)
    
    return bytes(record)


class MockDB2Parser(RecordVersionStrategy):
    """Mock DB2 parser for testing."""
    
    def __init__(self, base_parser: BaseRecordParser):
        super().__init__(base_parser)
    
    def parse(self, record_data: bytes):
        return {"mock": True}


class TestDB2UnsupportedVersionHandling:
    """Unit tests for unsupported version handling."""
    
    def test_warning_log_for_unsupported_version_with_fallback(self, caplog):
        """
        Test warning logs for unsupported versions when fallback is enabled.
        
        Requirements: 11.1, 11.3, 11.6
        """
        # Register V10 and V11 parsers
        SMFParserFactory._db2_registry[(100, "V10")] = MockDB2Parser
        SMFParserFactory._db2_registry[(100, "V11")] = MockDB2Parser
        
        try:
            # Create record with V12 (unsupported, will fallback to V11)
            record_data = create_db2_record_with_version(100, 0x0C00)
            
            # Enable logging capture
            with caplog.at_level(logging.WARNING):
                # Request parser with fallback enabled
                parser = SMFParserFactory.create_parser(
                    record_type=100,
                    record_data=record_data,
                    allow_fallback=True
                )
            
            # Verify warning was logged
            assert any("No exact parser" in record.message for record in caplog.records), \
                "Should log warning about missing exact parser"
            assert any("fallback" in record.message.lower() for record in caplog.records), \
                "Should mention fallback in warning"
            assert any("V11" in record.message for record in caplog.records), \
                "Should mention fallback version V11"
            
            # Verify parser was created
            assert parser is not None
            
        finally:
            SMFParserFactory._db2_registry.pop((100, "V10"), None)
            SMFParserFactory._db2_registry.pop((100, "V11"), None)
    
    def test_fallback_parser_selection_logic(self):
        """
        Test fallback parser selection logic.
        
        Requirements: 11.2, 11.3
        """
        # Register parsers for V10, V11, V12
        for version in ["V10", "V11", "V12"]:
            SMFParserFactory._db2_registry[(101, version)] = MockDB2Parser
        
        try:
            # Test fallback for V11 (exact match available)
            fallback = SMFParserFactory._find_fallback_parser(101, "V11")
            assert fallback == "V11", "Should use V11 for V11 (exact match)"
            
            # Test fallback for V12 (exact match available)
            fallback = SMFParserFactory._find_fallback_parser(101, "V12")
            assert fallback == "V12", "Should use V12 for V12 (exact match)"
            
            # Test fallback for V13 (should use V12 - closest older)
            fallback = SMFParserFactory._find_fallback_parser(101, "V13")
            assert fallback == "V12", "Should use V12 for V13 (closest older)"
            
            # Test fallback for V9 (should use V10 - no older, use newest)
            # Note: When no older version exists, we use the newest available
            fallback = SMFParserFactory._find_fallback_parser(101, "V9")
            # The logic returns the first in the sorted list (newest to oldest)
            # Since V9 < V10, there are no older versions, so it returns V12 (newest)
            assert fallback in ["V10", "V11", "V12"], \
                "Should return an available version for V9"
            
        finally:
            for version in ["V10", "V11", "V12"]:
                SMFParserFactory._db2_registry.pop((101, version), None)
    
    def test_error_when_no_fallback_available(self):
        """
        Test error when no fallback parser is available.
        
        Requirements: 11.4
        """
        # Ensure no parsers are registered for type 102
        original_parsers = {}
        for key in list(SMFParserFactory._db2_registry.keys()):
            if key[0] == 102:
                original_parsers[key] = SMFParserFactory._db2_registry.pop(key)
        
        try:
            # Create record with V11
            record_data = create_db2_record_with_version(102, 0x0B00)
            
            # Request parser with fallback enabled - should raise error
            with pytest.raises(UnsupportedVersionError) as exc_info:
                SMFParserFactory.create_parser(
                    record_type=102,
                    record_data=record_data,
                    allow_fallback=True
                )
            
            # Verify error message
            error_msg = str(exc_info.value)
            assert "No parser available" in error_msg, \
                "Error should mention no parser available"
            assert "102" in error_msg, \
                "Error should mention record type 102"
            assert "V11" in error_msg, \
                "Error should mention version V11"
            
        finally:
            # Restore original parsers
            SMFParserFactory._db2_registry.update(original_parsers)
    
    def test_allow_fallback_false_behavior(self):
        """
        Test allow_fallback=False behavior.
        
        Requirements: 11.5
        """
        # Register only V10 parser
        SMFParserFactory._db2_registry[(100, "V10")] = MockDB2Parser
        
        try:
            # Create record with V11 (not registered)
            record_data = create_db2_record_with_version(100, 0x0B00)
            
            # Request parser with fallback disabled - should raise error
            with pytest.raises(UnsupportedVersionError) as exc_info:
                SMFParserFactory.create_parser(
                    record_type=100,
                    record_data=record_data,
                    allow_fallback=False
                )
            
            # Verify error message mentions fallback is disabled
            error_msg = str(exc_info.value)
            assert "No exact parser" in error_msg or "not supported" in error_msg.lower(), \
                "Error should mention no exact parser"
            assert "Fallback parsing is disabled" in error_msg or "allow_fallback" in error_msg, \
                "Error should mention fallback is disabled"
            
        finally:
            SMFParserFactory._db2_registry.pop((100, "V10"), None)
    
    def test_warning_message_includes_detected_version(self, caplog):
        """
        Test warning messages include detected version.
        
        Requirements: 11.6
        """
        # Register V11 parser
        SMFParserFactory._db2_registry[(101, "V11")] = MockDB2Parser
        
        try:
            # Create record with V12 (will fallback to V11)
            record_data = create_db2_record_with_version(101, 0x0C00)
            
            with caplog.at_level(logging.WARNING):
                parser = SMFParserFactory.create_parser(
                    record_type=101,
                    record_data=record_data,
                    allow_fallback=True
                )
            
            # Verify warning includes detected version
            warning_messages = [record.message for record in caplog.records 
                              if record.levelname == "WARNING"]
            assert len(warning_messages) > 0, "Should have warning messages"
            
            warning_text = " ".join(warning_messages)
            assert "V12" in warning_text, "Warning should include detected version V12"
            assert "V11" in warning_text, "Warning should include fallback version V11"
            assert "101" in warning_text, "Warning should include record type 101"
            
        finally:
            SMFParserFactory._db2_registry.pop((101, "V11"), None)
    
    def test_warning_message_includes_compatibility_risk(self, caplog):
        """
        Test warning messages include compatibility risk information.
        
        Requirements: 11.6
        """
        # Register V10 parser
        SMFParserFactory._db2_registry[(100, "V10")] = MockDB2Parser
        
        try:
            # Create record with V11 (will fallback to V10)
            record_data = create_db2_record_with_version(100, 0x0B00)
            
            with caplog.at_level(logging.WARNING):
                parser = SMFParserFactory.create_parser(
                    record_type=100,
                    record_data=record_data,
                    allow_fallback=True
                )
            
            # Verify warning includes compatibility risk
            warning_messages = [record.message for record in caplog.records 
                              if record.levelname == "WARNING"]
            assert len(warning_messages) > 0, "Should have warning messages"
            
            warning_text = " ".join(warning_messages).lower()
            assert "compatibility" in warning_text or "verify" in warning_text, \
                "Warning should mention compatibility risks"
            
        finally:
            SMFParserFactory._db2_registry.pop((100, "V10"), None)
    
    def test_exact_match_no_warning(self, caplog):
        """
        Test that exact version match does not produce warnings.
        
        Requirements: 11.1
        """
        # Register V10 parser
        SMFParserFactory._db2_registry[(100, "V10")] = MockDB2Parser
        
        try:
            # Create record with exact V10
            record_data = create_db2_record_with_version(100, 0x0A00)
            
            with caplog.at_level(logging.WARNING):
                parser = SMFParserFactory.create_parser(
                    record_type=100,
                    record_data=record_data,
                    allow_fallback=True
                )
            
            # Verify no warnings for exact match
            warning_messages = [record.message for record in caplog.records 
                              if record.levelname == "WARNING"]
            assert len(warning_messages) == 0, \
                "Should not have warnings for exact version match"
            
        finally:
            SMFParserFactory._db2_registry.pop((100, "V10"), None)
    
    def test_get_available_versions_sorted(self):
        """
        Test that _get_available_versions returns versions sorted newest to oldest.
        
        Requirements: 11.2
        """
        # Register parsers in random order
        SMFParserFactory._db2_registry[(102, "V11")] = MockDB2Parser
        SMFParserFactory._db2_registry[(102, "V13")] = MockDB2Parser
        SMFParserFactory._db2_registry[(102, "V12")] = MockDB2Parser
        
        try:
            # Get available versions
            versions = SMFParserFactory._get_available_versions(102)
            
            # Verify sorted newest to oldest
            assert versions == ["V13", "V12", "V11"], \
                f"Versions should be sorted newest to oldest, got {versions}"
            
        finally:
            for version in ["V11", "V12", "V13"]:
                SMFParserFactory._db2_registry.pop((102, version), None)
    
    def test_fallback_prefers_older_version(self):
        """
        Test that fallback logic prefers older versions for compatibility.
        
        Requirements: 11.2, 11.3
        """
        # Register V10 and V12 (skip V11)
        SMFParserFactory._db2_registry[(101, "V10")] = MockDB2Parser
        SMFParserFactory._db2_registry[(101, "V12")] = MockDB2Parser
        
        try:
            # Request V11 - should fallback to V10 (older, more compatible)
            fallback = SMFParserFactory._find_fallback_parser(101, "V11")
            assert fallback == "V10", \
                "Should prefer older version V10 over newer V12 for V11"
            
        finally:
            SMFParserFactory._db2_registry.pop((101, "V10"), None)
            SMFParserFactory._db2_registry.pop((101, "V12"), None)
