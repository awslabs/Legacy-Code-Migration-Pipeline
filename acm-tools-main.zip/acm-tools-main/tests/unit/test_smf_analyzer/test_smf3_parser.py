"""Tests for SMF Type 3 parser."""

import pytest
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF3ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF3ParserV3R2:
    """Test suite for SMF Type 3 parser."""
    
    def test_parse_standard_type3_record(self):
        """Test parsing standard SMF Type 3 dump trailer record."""
        # Create a minimal SMF Type 3 record (18 bytes - standard header only)
        record_data = bytearray(18)
        
        # Record length (offset 0, 2 bytes) = 18
        record_data[0:2] = (18).to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes) = 0
        record_data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte) = 0x78 (version indicators)
        record_data[4] = 0x78
        
        # Record type (offset 5, 1 byte) = 3
        record_data[5] = 3
        
        # Time (offset 6, 4 bytes) = 7200000 (20:00:00.00 in hundredths)
        record_data[6:10] = (7200000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes packed) = 0x0124365F (2024-365)
        # Packed decimal: 01 24 365 F = century 0, year 24, day 365
        record_data[10:14] = bytes([0x01, 0x24, 0x36, 0x5F])
        
        # System ID (offset 14, 4 bytes EBCDIC) = "SYS1"
        sys_id_ebcdic = "SYS1".encode('cp037')
        record_data[14:18] = sys_id_ebcdic
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF3ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Verify basic fields
        assert result.record_type == 3
        assert result.subtype == 0  # Type 3 has no subtypes
        assert result.record_length == 18
        assert result.system_id == "SYS1"
        assert result.date == date(2024, 12, 30)  # Day 365 of 2024 (leap year, so Dec 30)
        assert result.timestamp == "20:00:00.00"
        
        # Verify header structure
        assert result.header is not None
        assert result.header['record_length'] == 18
        assert result.header['record_type'] == 3
        assert result.header['system_id'] == "SYS1"
        
        # Type 3 has no additional sections
        assert result.subsystem is None
        assert result.identification is None
        assert result.io_activity is None
        assert result.completion is None
        assert result.processor is None
    
    def test_parse_type3_different_system(self):
        """Test parsing Type 3 record with different system ID."""
        record_data = bytearray(18)
        
        # Record length
        record_data[0:2] = (18).to_bytes(2, 'big')
        
        # Record type = 3
        record_data[5] = 3
        
        # Time = 4320000 (12:00:00.00 - noon in hundredths)
        record_data[6:10] = (4320000).to_bytes(4, 'big')
        
        # Date = 0x0125001F (2025-001)
        # Packed decimal: 01 25 001 F = century 0, year 25, day 001
        record_data[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
        
        # System ID = "PROD"
        sys_id_ebcdic = "PROD".encode('cp037')
        record_data[14:18] = sys_id_ebcdic
        
        # Parse
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF3ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 3
        assert result.system_id == "PROD"
        assert result.date == date(2025, 1, 1)
        assert result.timestamp == "12:00:00.00"
    
    def test_parse_type3_utf8_encoding(self):
        """Test parsing Type 3 record with UTF-8 encoding."""
        record_data = bytearray(18)
        
        # Record length
        record_data[0:2] = (18).to_bytes(2, 'big')
        
        # Record type = 3
        record_data[5] = 3
        
        # Time
        record_data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date
        record_data[10:14] = bytes([0x01, 0x24, 0x18, 0x0F])
        
        # System ID = "TEST" (UTF-8)
        sys_id_utf8 = "TEST".encode('utf-8')
        record_data[14:18] = sys_id_utf8
        
        # Parse with UTF-8 encoding
        base_parser = BaseRecordParser(encoding="UTF-8")
        parser = SMF3ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 3
        assert result.system_id == "TEST"
    
    def test_invalid_record_type(self):
        """Test that parser rejects records with wrong record type."""
        record_data = bytearray(18)
        record_data[0:2] = (18).to_bytes(2, 'big')
        record_data[5] = 30  # Wrong type (should be 3)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF3ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(record_data))
        
        assert "Record type mismatch" in str(exc_info.value)
        assert "expected 3" in str(exc_info.value)
    
    def test_invalid_record_length(self):
        """Test that parser rejects records with mismatched length."""
        record_data = bytearray(18)
        record_data[0:2] = (100).to_bytes(2, 'big')  # Wrong length
        record_data[5] = 3
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF3ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(record_data))
        
        assert "Record length mismatch" in str(exc_info.value)
    
    def test_to_dict_conversion(self):
        """Test converting parsed Type 3 record to dictionary."""
        record_data = bytearray(18)
        record_data[0:2] = (18).to_bytes(2, 'big')
        record_data[5] = 3
        record_data[6:10] = (36000).to_bytes(4, 'big')
        record_data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        record_data[14:18] = "SYS1".encode('cp037')
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF3ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Convert to dict
        result_dict = result.to_dict()
        
        # Verify dict structure
        assert isinstance(result_dict, dict)
        assert result_dict['record_type'] == 3
        assert result_dict['subtype'] == 0
        assert result_dict['system_id'] == "SYS1"
        assert 'header' in result_dict
    
    def test_to_json_conversion(self):
        """Test converting parsed Type 3 record to JSON."""
        record_data = bytearray(18)
        record_data[0:2] = (18).to_bytes(2, 'big')
        record_data[5] = 3
        record_data[6:10] = (36000).to_bytes(4, 'big')
        record_data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        record_data[14:18] = "SYS1".encode('cp037')
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF3ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Convert to JSON
        json_output = result.to_json()
        
        # Verify JSON is valid
        assert isinstance(json_output, str)
        assert '"record_type": 3' in json_output
        assert '"system_id": "SYS1"' in json_output
    
    def test_parse_end_of_day_dump(self):
        """Test parsing Type 3 record at end of day (23:59:59.99)."""
        record_data = bytearray(18)
        
        # Record length
        record_data[0:2] = (18).to_bytes(2, 'big')
        
        # Record type = 3
        record_data[5] = 3
        
        # Time = 8639999 (23:59:59.99 in hundredths)
        record_data[6:10] = (8639999).to_bytes(4, 'big')
        
        # Date = 0x0124366F (2024-366 - last day of leap year)
        # Packed decimal: 01 24 366 F = century 0, year 24, day 366
        record_data[10:14] = bytes([0x01, 0x24, 0x36, 0x6F])
        
        # System ID = "PROD"
        record_data[14:18] = "PROD".encode('cp037')
        
        # Parse
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF3ParserV3R2(base_parser)
        
        result = parser.parse(bytes(record_data))
        
        # Verify end-of-day timestamp
        assert result.timestamp == "23:59:59.99"
        assert result.date == date(2024, 12, 31)  # Day 366 of 2024 (leap year)
        assert result.system_id == "PROD"
