"""Unit tests for SMF Type 9 parser."""

import pytest
import struct
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF9ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type9_record_minimal() -> bytes:
    """Create a minimal valid Type 9 record with 1 device.
    
    This represents a basic VARY ONLINE command for one device.
    """
    record = bytearray(28)  # 20 bytes header + 8 bytes for 1 device
    
    # Standard SMF header (offsets 0-17)
    struct.pack_into('>H', record, 0, 28)  # SMF9LEN - Record length
    struct.pack_into('>H', record, 2, 0)  # SMF9SEG - Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # SMF9FLG - System indicator
    struct.pack_into('B', record, 5, 9)  # SMF9RTY - Record type = 9
    struct.pack_into('>I', record, 6, 36000)  # SMF9TME - Timestamp (10:00:00.00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF9DTE - Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id  # SMF9SID
    
    # Length of rest of record (2 bytes for length field + 8 bytes for device)
    struct.pack_into('>H', record, 18, 10)  # SMF9LENN
    
    # Device data (1 device at offset 20)
    # Device class = 5, Unit type = 10
    device_type = (5 << 8) | 10  # SMF9DUT
    struct.pack_into('>H', record, 20, device_type)
    struct.pack_into('>H', record, 22, 0x0100)  # SMF9CUA - Device number
    struct.pack_into('B', record, 24, 0)  # SMF9VPC - Vary issuer (Operator)
    record[25:28] = bytes([0, 0, 0])  # SMF9RSV - Reserved
    
    return bytes(record)


def create_type9_record_multiple_devices() -> bytes:
    """Create a Type 9 record with multiple devices (5 devices).
    
    This represents multiple devices being varied online.
    """
    num_devices = 5
    record_length = 20 + (num_devices * 8)
    record = bytearray(record_length)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('>H', record, 2, 0)
    struct.pack_into('B', record, 4, 0x01)
    struct.pack_into('B', record, 5, 9)
    struct.pack_into('>I', record, 6, 36000)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    sys_id = "PROD".encode('cp037')
    record[14:18] = sys_id
    
    # Length of rest of record
    rest_length = 2 + (num_devices * 8)
    struct.pack_into('>H', record, 18, rest_length)
    
    # Device data (5 devices)
    devices = [
        (5, 10, 0x0100, 0),   # DASD, Operator
        (10, 20, 0x0200, 0),  # Tape, Operator
        (15, 30, 0x0300, 2),  # Communications, ESCM
        (20, 40, 0x0400, 0),  # Display, Operator
        (25, 50, 0x0500, 5),  # Unit record, Reserved
    ]
    
    for i, (dev_class, unit_type, dev_num, issuer) in enumerate(devices):
        offset = 20 + (i * 8)
        device_type = (dev_class << 8) | unit_type
        struct.pack_into('>H', record, offset, device_type)
        struct.pack_into('>H', record, offset + 2, dev_num)
        struct.pack_into('B', record, offset + 4, issuer)
        record[offset + 5:offset + 8] = bytes([0, 0, 0])
    
    return bytes(record)


def create_type9_record_with_vio() -> bytes:
    """Create a Type 9 record with Virtual I/O device.
    
    Virtual I/O devices have:
    - Device class: 0
    - Unit type: 0
    - Device number: 0x7FFF
    """
    num_devices = 3
    record_length = 20 + (num_devices * 8)
    record = bytearray(record_length)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, record_length)
    struct.pack_into('>H', record, 2, 0)
    struct.pack_into('B', record, 4, 0x01)
    struct.pack_into('B', record, 5, 9)
    struct.pack_into('>I', record, 6, 36000)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Length of rest of record
    rest_length = 2 + (num_devices * 8)
    struct.pack_into('>H', record, 18, rest_length)
    
    # Device data: 1 regular device, 1 VIO device, 1 regular device
    devices = [
        (5, 10, 0x0100, 0),    # Regular DASD, Operator
        (0, 0, 0x7FFF, 0),     # Virtual I/O, Operator
        (10, 20, 0x0200, 2),   # Regular Tape, ESCM
    ]
    
    for i, (dev_class, unit_type, dev_num, issuer) in enumerate(devices):
        offset = 20 + (i * 8)
        device_type = (dev_class << 8) | unit_type
        struct.pack_into('>H', record, offset, device_type)
        struct.pack_into('>H', record, offset + 2, dev_num)
        struct.pack_into('B', record, offset + 4, issuer)
        record[offset + 5:offset + 8] = bytes([0, 0, 0])
    
    return bytes(record)


def create_type9_record_no_devices() -> bytes:
    """Create a Type 9 record with no devices (edge case).
    
    This is an unusual but valid case.
    """
    record = bytearray(20)  # Just the header, no device data
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 20)
    struct.pack_into('>H', record, 2, 0)
    struct.pack_into('B', record, 4, 0x01)
    struct.pack_into('B', record, 5, 9)
    struct.pack_into('>I', record, 6, 36000)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Length of rest of record (just the length field itself)
    struct.pack_into('>H', record, 18, 2)
    
    return bytes(record)


def create_type9_record_invalid_type() -> bytes:
    """Create a record with wrong record type."""
    record = bytearray(create_type9_record_minimal())
    struct.pack_into('B', record, 5, 8)  # Wrong type (8 instead of 9)
    return bytes(record)


def create_type9_record_truncated() -> bytes:
    """Create a truncated Type 9 record."""
    record = create_type9_record_minimal()
    return record[:15]  # Truncate to 15 bytes (incomplete header)


class TestSMF9ParserV3R2:
    """Unit tests for SMF Type 9 parser."""
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal valid Type 9 record with 1 device."""
        record_data = create_type9_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header
        assert parsed.record_type == 9
        assert parsed.subtype == 0  # Type 9 has no subtypes
        assert parsed.record_length == 28
        assert parsed.system_id == "SYS1"
        assert parsed.date is not None
        
        # Verify device data
        assert parsed.io_activity is not None
        assert 'devices' in parsed.io_activity
        assert 'device_count' in parsed.io_activity
        
        devices = parsed.io_activity['devices']
        assert len(devices) == 1
        assert parsed.io_activity['device_count'] == 1
        
        # Verify device fields
        device = devices[0]
        assert device['device_class'] == 5
        assert device['unit_type'] == 10
        assert device['device_number'] == 0x0100
        assert device['device_number_hex'] == "0x0100"
        assert device['vary_issuer'] == 0
        assert device['vary_issuer_description'] == "Operator"
        assert device['is_virtual_io'] is False
    
    def test_parse_multiple_devices(self):
        """Test parsing Type 9 record with multiple devices."""
        record_data = create_type9_record_multiple_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify device count
        devices = parsed.io_activity['devices']
        assert len(devices) == 5
        assert parsed.io_activity['device_count'] == 5
        
        # Verify each device
        expected_devices = [
            (5, 10, 0x0100, 0, "Operator"),
            (10, 20, 0x0200, 0, "Operator"),
            (15, 30, 0x0300, 2, "Enterprise Systems Connection Manager Program Product (5688-008)"),
            (20, 40, 0x0400, 0, "Operator"),
            (25, 50, 0x0500, 5, "Reserved"),
        ]
        
        for i, (exp_class, exp_type, exp_num, exp_issuer, exp_desc) in enumerate(expected_devices):
            device = devices[i]
            assert device['device_class'] == exp_class, f"Device {i} class mismatch"
            assert device['unit_type'] == exp_type, f"Device {i} unit type mismatch"
            assert device['device_number'] == exp_num, f"Device {i} number mismatch"
            assert device['vary_issuer'] == exp_issuer, f"Device {i} issuer mismatch"
            assert device['vary_issuer_description'] == exp_desc, f"Device {i} issuer description mismatch"
            assert device['is_virtual_io'] is False, f"Device {i} should not be VIO"
    
    def test_parse_virtual_io_device(self):
        """Test parsing Type 9 record with Virtual I/O device."""
        record_data = create_type9_record_with_vio()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify device count
        devices = parsed.io_activity['devices']
        assert len(devices) == 3
        
        # First device: regular
        assert devices[0]['is_virtual_io'] is False
        assert devices[0]['device_class'] == 5
        assert devices[0]['unit_type'] == 10
        assert devices[0]['device_number'] == 0x0100
        assert devices[0]['vary_issuer'] == 0
        assert devices[0]['vary_issuer_description'] == "Operator"
        
        # Second device: VIO
        assert devices[1]['is_virtual_io'] is True
        assert devices[1]['device_class'] == 0
        assert devices[1]['unit_type'] == 0
        assert devices[1]['device_number'] == 0x7FFF
        assert devices[1]['device_number_hex'] == "0x7FFF"
        assert devices[1]['vary_issuer'] == 0
        
        # Third device: regular
        assert devices[2]['is_virtual_io'] is False
        assert devices[2]['device_class'] == 10
        assert devices[2]['unit_type'] == 20
        assert devices[2]['device_number'] == 0x0200
        assert devices[2]['vary_issuer'] == 2
        assert devices[2]['vary_issuer_description'] == "Enterprise Systems Connection Manager Program Product (5688-008)"
    
    def test_parse_no_devices(self):
        """Test parsing Type 9 record with no devices (edge case)."""
        record_data = create_type9_record_no_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify no devices
        devices = parsed.io_activity['devices']
        assert len(devices) == 0
        assert parsed.io_activity['device_count'] == 0
    
    def test_parse_invalid_record_type(self):
        """Test error handling for invalid record type."""
        record_data = create_type9_record_invalid_type()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "expected 9" in str(exc_info.value)
    
    def test_parse_truncated_record(self):
        """Test error handling for truncated record."""
        record_data = create_type9_record_truncated()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "Record length mismatch" in str(exc_info.value)
    
    def test_header_fields_extraction(self):
        """Test that all header fields are correctly extracted."""
        record_data = create_type9_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify all header fields are present
        header = parsed.header
        assert 'record_length' in header
        assert 'segment_descriptor' in header
        assert 'system_indicator' in header
        assert 'record_type' in header
        assert 'timestamp' in header
        assert 'date' in header
        assert 'system_id' in header
        assert 'rest_of_record_length' in header
        
        # Verify header values
        assert header['record_type'] == 9
        assert header['record_length'] == 28
        assert header['rest_of_record_length'] == 10
    
    def test_device_hex_format(self):
        """Test that device numbers are correctly formatted as hex."""
        record_data = create_type9_record_multiple_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        devices = parsed.io_activity['devices']
        
        # Verify hex formatting
        assert devices[0]['device_number_hex'] == "0x0100"
        assert devices[1]['device_number_hex'] == "0x0200"
        assert devices[2]['device_number_hex'] == "0x0300"
        assert devices[3]['device_number_hex'] == "0x0400"
        assert devices[4]['device_number_hex'] == "0x0500"
    
    def test_to_dict_conversion(self):
        """Test conversion of parsed record to dictionary."""
        record_data = create_type9_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Convert to dictionary
        record_dict = parsed.to_dict()
        
        # Verify dictionary structure
        assert isinstance(record_dict, dict)
        assert record_dict['record_type'] == 9
        assert record_dict['subtype'] == 0
        assert 'header' in record_dict
        assert 'io_activity' in record_dict
        assert 'devices' in record_dict['io_activity']
    
    def test_device_class_unit_type_extraction(self):
        """Test that device class and unit type are correctly extracted from 2-byte field."""
        record_data = create_type9_record_multiple_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        devices = parsed.io_activity['devices']
        
        # Verify device class (high byte) and unit type (low byte) extraction
        assert devices[0]['device_class'] == 5
        assert devices[0]['unit_type'] == 10
        
        assert devices[1]['device_class'] == 10
        assert devices[1]['unit_type'] == 20
        
        assert devices[2]['device_class'] == 15
        assert devices[2]['unit_type'] == 30
    
    def test_vary_issuer_descriptions(self):
        """Test that vary issuer codes are correctly mapped to descriptions."""
        record_data = create_type9_record_multiple_devices()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        devices = parsed.io_activity['devices']
        
        # Verify issuer descriptions
        assert devices[0]['vary_issuer'] == 0
        assert devices[0]['vary_issuer_description'] == "Operator"
        
        assert devices[2]['vary_issuer'] == 2
        assert devices[2]['vary_issuer_description'] == "Enterprise Systems Connection Manager Program Product (5688-008)"
        
        assert devices[4]['vary_issuer'] == 5
        assert devices[4]['vary_issuer_description'] == "Reserved"
    
    def test_vio_detection_specificity(self):
        """Test that VIO detection is specific to exact values."""
        # Create a record with devices that are close to VIO but not exact
        num_devices = 4
        record_length = 20 + (num_devices * 8)
        record = bytearray(record_length)
        
        # Standard SMF header
        struct.pack_into('>H', record, 0, record_length)
        struct.pack_into('>H', record, 2, 0)
        struct.pack_into('B', record, 4, 0x01)
        struct.pack_into('B', record, 5, 9)
        struct.pack_into('>I', record, 6, 36000)
        record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
        
        sys_id = "SYS1".encode('cp037')
        record[14:18] = sys_id
        
        rest_length = 2 + (num_devices * 8)
        struct.pack_into('>H', record, 18, rest_length)
        
        # Devices that are close to VIO but not exact
        devices = [
            (0, 0, 0x7FFF, 0),    # VIO - exact match
            (0, 0, 0x7FFE, 0),    # Not VIO - wrong device number
            (0, 1, 0x7FFF, 0),    # Not VIO - wrong unit type
            (1, 0, 0x7FFF, 0),    # Not VIO - wrong device class
        ]
        
        for i, (dev_class, unit_type, dev_num, issuer) in enumerate(devices):
            offset = 20 + (i * 8)
            device_type = (dev_class << 8) | unit_type
            struct.pack_into('>H', record, offset, device_type)
            struct.pack_into('>H', record, offset + 2, dev_num)
            struct.pack_into('B', record, offset + 4, issuer)
            record[offset + 5:offset + 8] = bytes([0, 0, 0])
        
        record_data = bytes(record)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF9ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        devices_parsed = parsed.io_activity['devices']
        
        # Only the first device should be VIO
        assert devices_parsed[0]['is_virtual_io'] is True
        assert devices_parsed[1]['is_virtual_io'] is False
        assert devices_parsed[2]['is_virtual_io'] is False
        assert devices_parsed[3]['is_virtual_io'] is False
