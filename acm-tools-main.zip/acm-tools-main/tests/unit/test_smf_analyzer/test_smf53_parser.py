"""Unit tests for SMF Type 53 parser."""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers.smf53_parser_v3r2 import SMF53ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF53Parser:
    """Test suite for SMF Type 53 parser."""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        return SMF53ParserV3R2(base_parser)
    
    def create_test_record(self, subtype=1, remote_name="REMOTE01", 
                          line_name="LINE0001", line_password="PASSWORD",
                          vtam_requests=100, exception_responses=5,
                          lustats_received=10, bid_rejects=2, temporary_errors=3):
        """Create a test Type 53 record.
        
        Args:
            subtype: Subtype ID (1=LOGOFF, 2=$P LNEn)
            remote_name: Remote name (8 bytes)
            line_name: Line name (8 bytes)
            line_password: Line password (8 bytes)
            vtam_requests: Number of VTAM requests processed
            exception_responses: Number of exception responses
            lustats_received: Number of LUSTATs received
            bid_rejects: Number of bid rejects
            temporary_errors: Number of temporary errors
            
        Returns:
            bytes: Binary record data
        """
        record = bytearray()
        
        # Standard header (18 bytes)
        record.extend(struct.pack('>H', 85))  # Record length (will be updated)
        record.extend(struct.pack('>H', 0))   # Segment descriptor
        record.extend(struct.pack('B', 0))    # System indicator
        record.extend(struct.pack('B', 53))   # Record type
        record.extend(struct.pack('>I', 360000))  # Time (10:00:00)
        record.extend(struct.pack('>I', 0x0124001F))  # Date (2024-001)
        record.extend('SYS1'.encode('cp037'))  # System ID (EBCDIC)
        
        # Triplet for product section (6 bytes)
        record.extend(struct.pack('>H', 30))  # Product offset
        record.extend(struct.pack('>H', 8))   # Product length
        record.extend(struct.pack('>H', 1))   # Product number
        
        # Triplet for identification section (6 bytes)
        record.extend(struct.pack('>H', 38))  # Identification offset
        record.extend(struct.pack('>H', 47))  # Identification length
        record.extend(struct.pack('>H', 1))   # Identification number
        
        # Product section (8 bytes, offset 30)
        record.extend(struct.pack('>H', subtype))  # Subtype ID
        record.extend(b'\xF0\xF1')  # Record version "01" (EBCDIC)
        record.extend(b'\xD1\xC5\xE2\xF2')  # Subsystem "JES2" (EBCDIC)
        
        # Identification section (47 bytes, offset 38)
        # Remote name (8 bytes)
        record.extend(remote_name.ljust(8).encode('cp037'))
        
        # Line name (8 bytes)
        record.extend(line_name.ljust(8).encode('cp037'))
        
        # Line password (8 bytes)
        record.extend(line_password.ljust(8).encode('cp037'))
        
        # VTAM counters (5 counters, 4 bytes each = 20 bytes)
        record.extend(struct.pack('>I', vtam_requests))
        record.extend(struct.pack('>I', exception_responses))
        record.extend(struct.pack('>I', lustats_received))
        record.extend(struct.pack('>I', bid_rejects))
        record.extend(struct.pack('>I', temporary_errors))
        
        # Line identifier (3 bytes) - "SNA"
        record.extend(b'\xE2\xD5\xC1')  # "SNA" in EBCDIC
        
        # Update record length
        struct.pack_into('>H', record, 0, len(record))
        
        return bytes(record)
    
    def test_parse_valid_subtype1_record(self, parser):
        """Test parsing a valid Type 53 subtype 1 (LOGOFF) record."""
        record_data = self.create_test_record(
            subtype=1,
            remote_name="REMOTE01",
            line_name="LINE0001",
            line_password="PASS1234",
            vtam_requests=150,
            exception_responses=8,
            lustats_received=12,
            bid_rejects=3,
            temporary_errors=5
        )
        
        result = parser.parse(record_data)
        
        # Verify standard fields
        assert result.record_type == 53
        assert result.subtype == 1
        assert result.system_id == "SYS1"
        assert result.record_length == len(record_data)
        
        # Verify product section
        assert result.subsystem is not None
        assert result.subsystem['subtype_id'] == 1
        assert result.subsystem['subsystem_name'] == "JES2"
        
        # Verify identification section
        assert result.identification is not None
        assert result.identification['remote_name'] == "REMOTE01"
        assert result.identification['line_name'] == "LINE0001"
        assert result.identification['line_password'] == "PASS1234"
        assert result.identification['vtam_requests_processed'] == 150
        assert result.identification['exception_responses'] == 8
        assert result.identification['lustats_received'] == 12
        assert result.identification['bid_rejects'] == 3
        assert result.identification['temporary_errors'] == 5
        assert result.identification['line_identifier'] == "SNA"
    
    def test_parse_valid_subtype2_record(self, parser):
        """Test parsing a valid Type 53 subtype 2 ($P LNEn) record."""
        record_data = self.create_test_record(
            subtype=2,
            remote_name="REMOTE02",
            line_name="LINE0002",
            line_password="PASS5678",
            vtam_requests=200,
            exception_responses=10,
            lustats_received=15,
            bid_rejects=4,
            temporary_errors=6
        )
        
        result = parser.parse(record_data)
        
        # Verify standard fields
        assert result.record_type == 53
        assert result.subtype == 2
        assert result.system_id == "SYS1"
        
        # Verify product section
        assert result.subsystem is not None
        assert result.subsystem['subtype_id'] == 2
        assert result.subsystem['subsystem_name'] == "JES2"
        
        # Verify identification section
        assert result.identification is not None
        assert result.identification['remote_name'] == "REMOTE02"
        assert result.identification['line_name'] == "LINE0002"
        assert result.identification['line_password'] == "PASS5678"
        assert result.identification['vtam_requests_processed'] == 200
        assert result.identification['exception_responses'] == 10
        assert result.identification['lustats_received'] == 15
        assert result.identification['bid_rejects'] == 4
        assert result.identification['temporary_errors'] == 6
        assert result.identification['line_identifier'] == "SNA"
    
    def test_parse_with_zero_counters(self, parser):
        """Test parsing a Type 53 record with zero VTAM counters."""
        record_data = self.create_test_record(
            subtype=1,
            vtam_requests=0,
            exception_responses=0,
            lustats_received=0,
            bid_rejects=0,
            temporary_errors=0
        )
        
        result = parser.parse(record_data)
        
        # Verify counters are zero
        assert result.identification['vtam_requests_processed'] == 0
        assert result.identification['exception_responses'] == 0
        assert result.identification['lustats_received'] == 0
        assert result.identification['bid_rejects'] == 0
        assert result.identification['temporary_errors'] == 0
    
    def test_parse_with_high_counters(self, parser):
        """Test parsing a Type 53 record with high VTAM counter values."""
        record_data = self.create_test_record(
            subtype=1,
            vtam_requests=999999,
            exception_responses=50000,
            lustats_received=75000,
            bid_rejects=10000,
            temporary_errors=25000
        )
        
        result = parser.parse(record_data)
        
        # Verify high counter values
        assert result.identification['vtam_requests_processed'] == 999999
        assert result.identification['exception_responses'] == 50000
        assert result.identification['lustats_received'] == 75000
        assert result.identification['bid_rejects'] == 10000
        assert result.identification['temporary_errors'] == 25000
    
    def test_parse_invalid_record_type(self, parser):
        """Test that parser rejects records with wrong type."""
        record_data = self.create_test_record()
        
        # Change record type to 30
        record_data = bytearray(record_data)
        record_data[5] = 30
        record_data = bytes(record_data)
        
        with pytest.raises(ValidationError):
            parser.parse(record_data)
    
    def test_parse_truncated_record(self, parser):
        """Test handling of truncated record."""
        record_data = self.create_test_record()
        
        # Truncate the record
        truncated = record_data[:30]
        
        # Should raise ValidationError for truncated record
        with pytest.raises(ValidationError):
            parser.parse(truncated)
    
    def test_parse_empty_fields(self, parser):
        """Test parsing record with empty/blank fields."""
        record_data = self.create_test_record(
            subtype=1,
            remote_name="",
            line_name="",
            line_password=""
        )
        
        result = parser.parse(record_data)
        
        # Should parse successfully with empty strings
        assert result.record_type == 53
        assert result.identification is not None
    
    def test_header_triplet_parsing(self, parser):
        """Test that triplet fields are correctly parsed."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        
        # Verify header contains triplet information
        assert result.header is not None
        assert 'product_offset' in result.header
        assert 'product_length' in result.header
        assert 'product_number' in result.header
        assert 'identification_offset' in result.header
        assert 'identification_length' in result.header
        assert 'identification_number' in result.header
    
    def test_timestamp_parsing(self, parser):
        """Test that timestamp is correctly parsed."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        
        # Verify timestamp is present and formatted
        assert result.timestamp is not None
        assert isinstance(result.timestamp, str)
        assert ':' in result.timestamp  # Should be formatted as HH:MM:SS
    
    def test_date_parsing(self, parser):
        """Test that date is correctly parsed."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        
        # Verify date is present
        assert result.date is not None
        # Date can be either string or date object depending on parser implementation
        if isinstance(result.date, str):
            assert '-' in result.date  # Should be formatted as YYYY-MM-DD
    
    def test_to_dict_conversion(self, parser):
        """Test conversion of parsed record to dictionary."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        result_dict = result.to_dict()
        
        # Verify dictionary contains expected keys
        assert 'record_type' in result_dict
        assert 'subtype' in result_dict
        assert 'system_id' in result_dict
        assert 'timestamp' in result_dict
        assert 'date' in result_dict
        assert 'header' in result_dict
        assert 'identification' in result_dict
        assert 'subsystem' in result_dict


class TestSMF53ParserRealData:
    """Test suite for SMF Type 53 parser with real data."""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        return SMF53ParserV3R2(base_parser)
    
    def test_parse_real_records_ebcdic(self, parser):
        """Test parsing real Type 53 records from EBCDIC production file."""
        import os
        from tools.smf_analyzer.smf_record_parser import SMFFileParser
        
        test_file = './examples/data/aviva/SMF_records_binary.txt'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        # Parse file and look for Type 53 records
        file_parser = SMFFileParser(
            os_version="V3R2",
            encoding="EBCDIC",
            record_types=[53],
            skip_unsupported=True
        )
        
        type_53_count = 0
        for record in file_parser.parse_file(test_file):
            if record.record_type == 53:
                type_53_count += 1
                
                # Verify basic structure
                assert record.system_id is not None
                assert record.timestamp is not None
                assert record.date is not None
                
                # Verify sections exist (may be empty for some records)
                assert record.subsystem is not None
                assert record.identification is not None
                
                # If subsystem data is present, verify it
                if record.subsystem and 'subsystem_name' in record.subsystem:
                    assert record.subsystem['subsystem_name'] in ['JES2', '']
                
                # If identification data is present, verify line identifier
                if record.identification and 'line_identifier' in record.identification:
                    # Line identifier should be 'SNA' for Type 53
                    line_id = record.identification['line_identifier']
                    if line_id and line_id.strip():
                        assert line_id.strip() == 'SNA'
        
        # Note: Type 53 records may not be present in all test files
        # This is expected for SNA-only records
        print(f"Found {type_53_count} Type 53 records in EBCDIC test file")
    
    def test_parse_real_records_ascii(self, parser):
        """Test parsing real Type 53 records from ASCII production file."""
        import os
        from tools.smf_analyzer.smf_record_parser import SMFFileParser
        
        test_file = './examples/data/aviva/SMF_records_ascii.txt'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        # Parse file and look for Type 53 records
        file_parser = SMFFileParser(
            os_version="V3R2",
            encoding="UTF-8",
            record_types=[53],
            skip_unsupported=True
        )
        
        type_53_count = 0
        for record in file_parser.parse_file(test_file):
            if record.record_type == 53:
                type_53_count += 1
                
                # Verify basic structure
                assert record.system_id is not None
                assert record.timestamp is not None
                assert record.date is not None
                
                # Verify sections exist
                assert record.subsystem is not None
                assert record.identification is not None
        
        print(f"Found {type_53_count} Type 53 records in ASCII test file")


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
