"""Unit tests for SMF64ParserV3R2."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf64_parser_v3r2 import SMF64ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF64ParserV3R2:
    """Test suite for SMF64ParserV3R2 class."""
    
    def create_minimal_smf64_record(self, situation=0x80, component_type=0x01):
        """Create minimal valid SMF Type 64 record with synthetic data.
        
        This creates a basic Type 64 record structure with:
        - Valid header
        - Component/cluster name (44 chars)
        - Catalog name (44 chars)
        - Job identification (job name, job ID, user ID, DD name)
        - Situation indicator
        - Component type
        - Timestamps (open/close)
        - Statistics (retrieved, inserted, updated, deleted, splits, EXCPs)
        - Dataset characteristics (CI size, max record size)
        
        Args:
            situation: Situation indicator byte (default 0x80 = CLOSE)
            component_type: Component type byte (default 0x01 = DATA)
        
        Returns:
            bytes: Synthetic SMF Type 64 record
        """
        # Record length: 224 bytes (minimum for Type 64)
        record_length = 224
        data = bytearray(record_length)
        
        # === HEADER SECTION (offsets 0-17) ===
        # Record length (offset 0, 2 bytes)
        data[0:2] = record_length.to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes)
        data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte)
        data[4] = 0x00
        
        # Record type (offset 5, 1 byte) - 64
        data[5] = 64
        
        # Timestamp (offset 6, 4 bytes) - 36000 hundredths = 10:00:00.00
        data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes) - 0x01240001F = 2024-001 (Jan 1, 2024)
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes) - "SYS1" in EBCDIC
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # === COMPONENT/CLUSTER NAME (offset 18, 44 bytes) - SMF64DNM ===
        component_name = "VSAM.CLUSTER.DATA"
        component_name_ebcdic = component_name.encode('cp037')
        data[18:62] = component_name_ebcdic + bytes([0x40] * (44 - len(component_name_ebcdic)))
        
        # === CATALOG NAME (offset 106, 44 bytes) - SMF64CNM ===
        # Note: There's a gap from 62-106 (44 bytes) for other fields
        catalog_name = "CATALOG.MASTER"
        catalog_name_ebcdic = catalog_name.encode('cp037')
        data[106:150] = catalog_name_ebcdic + bytes([0x40] * (44 - len(catalog_name_ebcdic)))
        
        # === JOB NAME (offset 150, 8 bytes) - SMF64JBN ===
        job_name = "VSAMJOB1"
        job_name_ebcdic = job_name.encode('cp037')
        data[150:158] = job_name_ebcdic
        
        # === JOB ID (offset 158, 8 bytes) - SMF64JobID ===
        job_id = "JOB12345"
        job_id_ebcdic = job_id.encode('cp037')
        data[158:166] = job_id_ebcdic
        
        # === USER ID (offset 166, 8 bytes) - SMF64UIF ===
        user_id = "VSAMUSR1"
        user_id_ebcdic = user_id.encode('cp037')
        data[166:174] = user_id_ebcdic
        
        # === DD NAME (offset 174, 8 bytes) - SMF64DDN ===
        dd_name = "VSAMDD01"
        dd_name_ebcdic = dd_name.encode('cp037')
        data[174:182] = dd_name_ebcdic
        
        # === SITUATION INDICATOR (offset 182, 1 byte) - SMF64RIN ===
        data[182] = situation
        
        # === COMPONENT TYPE (offset 183, 1 byte) - SMF64DTY ===
        data[183] = component_type
        
        # === OPEN TIME (offset 184, 4 bytes) - SMF64TIM ===
        data[184:188] = (32400).to_bytes(4, 'big')  # 09:00:00.00
        
        # === CLOSE TIME (offset 188, 4 bytes) - SMF64TME ===
        data[188:192] = (36000).to_bytes(4, 'big')  # 10:00:00.00
        
        # === STATISTICS (offsets 192-220) ===
        # Records retrieved (offset 192, 4 bytes) - SMF64DRE
        data[192:196] = (1000).to_bytes(4, 'big')
        
        # Records inserted (offset 196, 4 bytes) - SMF64DIN
        data[196:200] = (500).to_bytes(4, 'big')
        
        # Records updated (offset 200, 4 bytes) - SMF64DUP
        data[200:204] = (250).to_bytes(4, 'big')
        
        # Records deleted (offset 204, 4 bytes) - SMF64DDE
        data[204:208] = (100).to_bytes(4, 'big')
        
        # CI splits (offset 208, 4 bytes) - SMF64DCS
        data[208:212] = (10).to_bytes(4, 'big')
        
        # CA splits (offset 212, 4 bytes) - SMF64DAS
        data[212:216] = (2).to_bytes(4, 'big')
        
        # EXCPs (offset 216, 4 bytes) - SMF64DEP
        data[216:220] = (5000).to_bytes(4, 'big')
        
        # === DATASET CHARACTERISTICS (offsets 220-224) ===
        # CI size (offset 220, 2 bytes) - SMF64DCI
        data[220:222] = (4096).to_bytes(2, 'big')
        
        # Max record size (offset 222, 2 bytes) - SMF64DLS
        data[222:224] = (1024).to_bytes(2, 'big')
        
        return bytes(data)
    
    def test_parser_initialization(self):
        """Test creating SMF64ParserV3R2 instance."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        assert parser.parser == base_parser
    
    def test_parse_validates_record_type(self):
        """Test that parsing validates record type."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        # Create record with wrong type
        data = self.create_minimal_smf64_record()
        data_array = bytearray(data)
        data_array[5] = 30  # Wrong record type
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "type mismatch" in str(exc_info.value).lower()
    
    def test_parse_validates_record_length(self):
        """Test that parsing validates record length."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        # Create record with mismatched length
        data = self.create_minimal_smf64_record()
        data_array = bytearray(data)
        data_array[0:2] = (500).to_bytes(2, 'big')  # Wrong length
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "length mismatch" in str(exc_info.value).lower()
    
    def test_parse_extracts_component_name(self):
        """Test that parse extracts component name correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        assert result.record_type == 64
        assert result.identification['component_name'] == "VSAM.CLUSTER.DATA"
    
    def test_parse_extracts_catalog_name(self):
        """Test that parse extracts catalog name correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        assert result.identification['catalog_name'] == "CATALOG.MASTER"
    
    def test_parse_extracts_job_identification(self):
        """Test that parse extracts job identification correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        assert result.identification['job_name'] == "VSAMJOB1"
        assert result.identification['job_id'] == "JOB12345"
        assert result.identification['user_id'] == "VSAMUSR1"
        assert result.identification['dd_name'] == "VSAMDD01"
    
    def test_parse_extracts_timestamps(self):
        """Test that parse extracts timestamps correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        assert result.identification['open_time'] is not None
        assert result.identification['close_time'] is not None
        assert isinstance(result.identification['open_time'], str)
        assert isinstance(result.identification['close_time'], str)
    
    def test_parse_extracts_statistics(self):
        """Test that parse extracts statistics correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        stats = result.performance
        assert stats['records_retrieved'] == 1000
        assert stats['records_inserted'] == 500
        assert stats['records_updated'] == 250
        assert stats['records_deleted'] == 100
        assert stats['ci_splits'] == 10
        assert stats['ca_splits'] == 2
        assert stats['excps'] == 5000
    
    def test_parse_extracts_dataset_characteristics(self):
        """Test that parse extracts dataset characteristics correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        stats = result.performance
        assert stats['ci_size'] == 4096
        assert stats['max_record_size'] == 1024
    
    def test_decode_situation_close(self):
        """Test decoding CLOSE situation indicator."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(situation=0x80)
        result = parser.parse(data)
        
        assert result.identification['situation'] == "CLOSE"
    
    def test_decode_situation_vol_switch(self):
        """Test decoding VOL_SWITCH situation indicator."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(situation=0x40)
        result = parser.parse(data)
        
        assert result.identification['situation'] == "VOL_SWITCH"
    
    def test_decode_situation_no_space(self):
        """Test decoding NO_SPACE situation indicator."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(situation=0x20)
        result = parser.parse(data)
        
        assert result.identification['situation'] == "NO_SPACE"
    
    def test_decode_situation_eov(self):
        """Test decoding EOV situation indicator."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(situation=0x10)
        result = parser.parse(data)
        
        assert result.identification['situation'] == "EOV"
    
    def test_decode_component_type_data(self):
        """Test decoding DATA component type."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(component_type=0x01)
        result = parser.parse(data)
        
        assert result.identification['component_type'] == "DATA"
    
    def test_decode_component_type_index(self):
        """Test decoding INDEX component type."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(component_type=0x02)
        result = parser.parse(data)
        
        assert result.identification['component_type'] == "INDEX"
    
    def test_decode_component_type_extended(self):
        """Test decoding EXTENDED component type."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(component_type=0x04)
        result = parser.parse(data)
        
        assert result.identification['component_type'] == "EXTENDED"
    
    def test_decode_component_type_compressed(self):
        """Test decoding COMPRESSED component type."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(component_type=0x08)
        result = parser.parse(data)
        
        assert result.identification['component_type'] == "COMPRESSED"
    
    def test_decode_component_type_rls(self):
        """Test decoding RLS component type."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record(component_type=0x10)
        result = parser.parse(data)
        
        assert result.identification['component_type'] == "RLS"
    
    def test_decode_component_type_multiple_flags(self):
        """Test decoding component type with multiple flags."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        # DATA + COMPRESSED
        data = self.create_minimal_smf64_record(component_type=0x09)
        result = parser.parse(data)
        
        assert "DATA" in result.identification['component_type']
        assert "COMPRESSED" in result.identification['component_type']
    
    def test_parse_extracts_system_id(self):
        """Test that parse extracts system ID correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        assert result.system_id == "SYS1"
    
    def test_parse_extracts_record_length(self):
        """Test that parse extracts record length correctly."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_minimal_smf64_record()
        result = parser.parse(data)
        
        assert result.record_length == 224


class TestSMF64EncodingHandling:
    """Test EBCDIC encoding handling for SMF Type 64 records."""
    
    def test_ebcdic_component_name_with_special_chars(self):
        """Test handling of component names with special characters."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with component name containing special chars
        data = bytearray(100)
        
        # Component name with special chars: "VSAM.CLUSTER(DATA)"
        component_name = "VSAM.CLUSTER(DATA)"
        data[0:44] = component_name.encode('cp037') + bytes([0x40] * (44 - len(component_name)))
        
        # Test EBCDIC decoding
        decoded = base_parser.read_string(bytes(data), 0, 44, "component_name")
        assert decoded == "VSAM.CLUSTER(DATA)"
    
    def test_ebcdic_catalog_name_padding(self):
        """Test handling of catalog names with EBCDIC padding."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with short catalog name with EBCDIC space padding (0x40)
        data = bytearray(100)
        catalog_name = "CATALOG"
        data[0:44] = catalog_name.encode('cp037') + bytes([0x40] * 37)
        
        # Test EBCDIC decoding with padding
        decoded = base_parser.read_string(bytes(data), 0, 44, "catalog_name")
        
        # Should strip trailing spaces
        assert decoded == "CATALOG"


class TestSMF64ErrorConditions:
    """Test error handling for SMF Type 64 parser."""
    
    def test_parse_with_insufficient_data(self):
        """Test parsing with record too short for basic fields."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        # Create record that's too short
        data = bytearray(100)
        data[0:2] = (100).to_bytes(2, 'big')
        data[5] = 64
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(data))
    
    def test_parse_with_zero_length_record(self):
        """Test parsing with zero-length record."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = bytes()
        
        with pytest.raises(ValidationError):
            parser.parse(data)


class TestSMF64StatisticsExtraction:
    """Test statistics extraction for SMF Type 64 records."""
    
    def create_record_with_stats(self, retrieved, inserted, updated, deleted, ci_splits, ca_splits):
        """Helper to create record with specific statistics."""
        record_length = 224
        data = bytearray(record_length)
        
        # Basic header
        data[0:2] = record_length.to_bytes(2, 'big')
        data[5] = 64
        data[6:10] = (36000).to_bytes(4, 'big')
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # Component name
        component_name = "TEST.VSAM.CLUSTER"
        data[18:62] = component_name.encode('cp037') + bytes([0x40] * (44 - len(component_name)))
        
        # Catalog name
        catalog_name = "CATALOG"
        data[106:150] = catalog_name.encode('cp037') + bytes([0x40] * (44 - len(catalog_name)))
        
        # Job identification
        data[150:158] = "TESTJOB1".encode('cp037')
        data[158:166] = "JOB00001".encode('cp037')
        data[166:174] = "TESTUSER".encode('cp037')
        data[174:182] = "TESTDD01".encode('cp037')
        
        # Situation and type
        data[182] = 0x80  # CLOSE
        data[183] = 0x01  # DATA
        
        # Timestamps
        data[184:188] = (32400).to_bytes(4, 'big')
        data[188:192] = (36000).to_bytes(4, 'big')
        
        # Statistics
        data[192:196] = retrieved.to_bytes(4, 'big')
        data[196:200] = inserted.to_bytes(4, 'big')
        data[200:204] = updated.to_bytes(4, 'big')
        data[204:208] = deleted.to_bytes(4, 'big')
        data[208:212] = ci_splits.to_bytes(4, 'big')
        data[212:216] = ca_splits.to_bytes(4, 'big')
        data[216:220] = (1000).to_bytes(4, 'big')  # EXCPs
        
        # Characteristics
        data[220:222] = (4096).to_bytes(2, 'big')
        data[222:224] = (1024).to_bytes(2, 'big')
        
        return bytes(data)
    
    def test_parse_zero_statistics(self):
        """Test parsing record with zero statistics."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_stats(0, 0, 0, 0, 0, 0)
        result = parser.parse(data)
        
        stats = result.performance
        assert stats['records_retrieved'] == 0
        assert stats['records_inserted'] == 0
        assert stats['records_updated'] == 0
        assert stats['records_deleted'] == 0
        assert stats['ci_splits'] == 0
        assert stats['ca_splits'] == 0
    
    def test_parse_large_statistics(self):
        """Test parsing record with large statistics values."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_stats(1000000, 500000, 250000, 100000, 1000, 100)
        result = parser.parse(data)
        
        stats = result.performance
        assert stats['records_retrieved'] == 1000000
        assert stats['records_inserted'] == 500000
        assert stats['records_updated'] == 250000
        assert stats['records_deleted'] == 100000
        assert stats['ci_splits'] == 1000
        assert stats['ca_splits'] == 100
    
    def test_parse_read_only_statistics(self):
        """Test parsing record with only read operations."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_stats(50000, 0, 0, 0, 0, 0)
        result = parser.parse(data)
        
        stats = result.performance
        assert stats['records_retrieved'] == 50000
        assert stats['records_inserted'] == 0
        assert stats['records_updated'] == 0
        assert stats['records_deleted'] == 0
    
    def test_parse_write_only_statistics(self):
        """Test parsing record with only write operations."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_stats(0, 25000, 0, 0, 50, 5)
        result = parser.parse(data)
        
        stats = result.performance
        assert stats['records_retrieved'] == 0
        assert stats['records_inserted'] == 25000
        assert stats['ci_splits'] == 50
        assert stats['ca_splits'] == 5



class TestSMF64RecordCountingFields:
    """Test record counting fields extraction for SMF Type 64 records (Task 4.2)."""
    
    def create_record_with_record_counts(self, total_logical=5000, change_logical=250):
        """Helper to create record with specific record counting values."""
        record_length = 244  # Extended to include record counting fields
        data = bytearray(record_length)
        
        # Basic header
        data[0:2] = record_length.to_bytes(2, 'big')
        data[5] = 64
        data[6:10] = (36000).to_bytes(4, 'big')
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # Component name
        component_name = "VSAM.TEST.DATA"
        data[18:62] = component_name.encode('cp037') + bytes([0x40] * (44 - len(component_name)))
        
        # Catalog name
        catalog_name = "CATALOG"
        data[106:150] = catalog_name.encode('cp037') + bytes([0x40] * (44 - len(catalog_name)))
        
        # Job identification
        data[150:158] = "TESTJOB1".encode('cp037')
        data[158:166] = "JOB00001".encode('cp037')
        data[166:174] = "TESTUSER".encode('cp037')
        data[174:182] = "TESTDD01".encode('cp037')
        
        # Situation and type
        data[182] = 0x80  # CLOSE
        data[183] = 0x01  # DATA
        
        # Timestamps
        data[184:188] = (32400).to_bytes(4, 'big')
        data[188:192] = (36000).to_bytes(4, 'big')
        
        # Record counting fields
        # Total logical records at offset 132 (SMF64NLR)
        data[132:136] = total_logical.to_bytes(4, 'big')
        
        # Change in logical records at offset 176 (SMF64DLR)
        # Handle negative values
        if change_logical < 0:
            change_logical_unsigned = (2**32 + change_logical)
        else:
            change_logical_unsigned = change_logical
        data[176:180] = change_logical_unsigned.to_bytes(4, 'big')
        
        # Statistics
        data[192:196] = (1000).to_bytes(4, 'big')  # Records retrieved
        data[196:200] = (500).to_bytes(4, 'big')   # Records inserted
        data[200:204] = (250).to_bytes(4, 'big')   # Records updated
        data[204:208] = (100).to_bytes(4, 'big')   # Records deleted
        data[208:212] = (10).to_bytes(4, 'big')    # CI splits
        data[212:216] = (2).to_bytes(4, 'big')     # CA splits
        data[216:220] = (1000).to_bytes(4, 'big')  # EXCPs
        
        # Characteristics
        data[220:222] = (4096).to_bytes(2, 'big')
        data[222:224] = (1024).to_bytes(2, 'big')
        
        return bytes(data)
    
    def test_parse_total_logical_records(self):
        """Test parsing total logical records field (SMF64NLR)."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_record_counts(total_logical=5000, change_logical=250)
        result = parser.parse(data)
        
        assert 'total_logical_records' in result.performance
        assert result.performance['total_logical_records'] == 5000
    
    def test_parse_change_in_logical_records_positive(self):
        """Test parsing positive change in logical records field (SMF64DLR)."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_record_counts(total_logical=5000, change_logical=250)
        result = parser.parse(data)
        
        assert 'change_in_logical_records' in result.performance
        assert result.performance['change_in_logical_records'] == 250
    
    def test_parse_change_in_logical_records_negative(self):
        """Test parsing negative change in logical records field (SMF64DLR)."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_record_counts(total_logical=5000, change_logical=-100)
        result = parser.parse(data)
        
        assert 'change_in_logical_records' in result.performance
        assert result.performance['change_in_logical_records'] == -100
    
    def test_parse_change_in_logical_records_zero(self):
        """Test parsing zero change in logical records field (SMF64DLR)."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_record_counts(total_logical=1000, change_logical=0)
        result = parser.parse(data)
        
        assert 'change_in_logical_records' in result.performance
        assert result.performance['change_in_logical_records'] == 0
    
    def test_parse_large_record_counts(self):
        """Test parsing large record counting values."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_record_counts(total_logical=10000000, change_logical=500000)
        result = parser.parse(data)
        
        assert result.performance['total_logical_records'] == 10000000
        assert result.performance['change_in_logical_records'] == 500000
    
    def test_record_counting_validation_positive_change(self):
        """Test validation: total >= change when change is positive."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_record_counts(total_logical=5000, change_logical=250)
        result = parser.parse(data)
        
        total = result.performance['total_logical_records']
        change = result.performance['change_in_logical_records']
        
        # When change is positive, total should be >= change
        assert total >= change, f"Total ({total}) should be >= change ({change})"
    
    def test_record_counting_validation_negative_change(self):
        """Test validation: negative change is allowed."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        data = self.create_record_with_record_counts(total_logical=5000, change_logical=-100)
        result = parser.parse(data)
        
        total = result.performance['total_logical_records']
        change = result.performance['change_in_logical_records']
        
        # Negative change is valid (records deleted)
        assert change < 0, f"Change ({change}) should be negative"
        assert total >= 0, f"Total ({total}) should be non-negative"
    
    def test_record_counting_fields_non_negative_total(self):
        """Test that total logical records is always non-negative."""
        base_parser = BaseRecordParser()
        parser = SMF64ParserV3R2(base_parser)
        
        # Test with various values
        test_cases = [
            (0, 0),
            (1, 1),
            (1000, 500),
            (10000, -500),
        ]
        
        for total, change in test_cases:
            data = self.create_record_with_record_counts(total_logical=total, change_logical=change)
            result = parser.parse(data)
            
            assert result.performance['total_logical_records'] >= 0, \
                f"Total logical records should be non-negative, got {result.performance['total_logical_records']}"
