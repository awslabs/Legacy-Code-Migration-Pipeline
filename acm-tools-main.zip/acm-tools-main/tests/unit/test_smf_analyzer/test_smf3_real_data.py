"""Integration test for SMF Type 3 parser with real data."""

import pytest
from datetime import date
from pathlib import Path
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory
from tools.smf_analyzer.smf_record_parser import SMFFileParser


class TestSMF3RealData:
    """Test SMF Type 3 parser with real data from SMF30_1.Dat."""
    
    @pytest.fixture
    def smf_file_path(self):
        """Return path to the SMF data file."""
        return Path("examples/SMF30_1.Dat")
    
    def test_parse_real_smf3_record(self, smf_file_path):
        """Test parsing real SMF Type 3 record from SMF30_1.Dat."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        # Use file parser to find Type 3 record
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC", record_types=[3])
        records = list(parser.parse_file(str(smf_file_path)))
        
        # Should have at least one Type 3 record
        assert len(records) >= 1
        
        # Get first Type 3 record
        record = records[0]
        
        # Verify it's a Type 3 record
        assert record.record_type == 3
        
        # Verify basic structure
        assert record.record_length == 18
        assert record.subtype == 0
        
        # Verify system ID is present
        assert record.system_id
        assert len(record.system_id) > 0
        
        # Verify date and timestamp
        assert isinstance(record.date, date)
        assert isinstance(record.timestamp, str)
        
        # Verify header
        assert record.header is not None
        assert 'record_type' in record.header
        assert record.header['record_type'] == 3

    def test_factory_lists_type3_parser(self):
        """Test that factory lists Type 3 parser as available."""
        available = SMFParserFactory.list_available_parsers()
        
        # Type 3 should be in the list
        assert 3 in available
        
        # V3R2 should be a supported version
        assert "V3R2" in available[3]
    
    def test_create_type3_parser_via_factory(self):
        """Test creating Type 3 parser through factory."""
        parser = SMFParserFactory.create_parser(3, "V3R2", encoding="EBCDIC")
        
        # Verify parser is created
        assert parser is not None
        assert parser.record_type == 3
        
        # Verify strategy is registered
        assert "V3R2" in parser.version_strategies
    
    def test_type3_marks_end_of_dump(self, smf_file_path):
        """Test that Type 3 record appears at end of dump."""
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        # Parse all records and track positions
        parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC")
        
        all_records = []
        for record in parser.parse_file(str(smf_file_path)):
            all_records.append(record)
        
        # Find Type 3 records
        type3_indices = [i for i, r in enumerate(all_records) if r.record_type == 3]
        
        # Type 3 should be near the end (it's a dump trailer)
        if type3_indices:
            last_type3_index = type3_indices[-1]
            # Should be in last 10% of records
            assert last_type3_index >= len(all_records) * 0.9
