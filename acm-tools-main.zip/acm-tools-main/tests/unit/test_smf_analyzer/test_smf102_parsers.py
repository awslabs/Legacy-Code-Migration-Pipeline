"""Unit tests for SMF Type 102 V11, V12, and V13 parsers.

Feature: db2-versioned-smf-parsers
Tests: Requirements 5.1, 5.2, 5.3, 5.5, 9.1
"""

import pytest
import struct
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf102_parser_v11 import SMF102ParserV11
from tools.smf_analyzer.smf_record_parser.parsers.smf102_parser_v12 import SMF102ParserV12
from tools.smf_analyzer.smf_record_parser.parsers.smf102_parser_v13 import SMF102ParserV13
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_smf102_record(
    db2_version: str = "V11",
    ifcid: int = 1,
    record_length: int = 500,
    system_id: str = "SYS1",
    subsystem_id: str = "DB2P",
    include_optional_headers: bool = True
) -> bytes:
    """Create a synthetic SMF Type 102 record for testing.
    
    Args:
        db2_version: DB2 version ("V11", "V12", or "V13")
        ifcid: IFCID value (various performance IFCIDs)
        record_length: Total record length
        system_id: System identifier (4 chars)
        subsystem_id: Subsystem identifier (4 chars)
        include_optional_headers: Whether to include optional headers
        
    Returns:
        Synthetic SMF Type 102 record as bytes
    """
    record = bytearray(record_length + 1)
    
    # SMF header (first 28 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0)  # System indicator
    struct.pack_into('B', record, 5, 102)  # Record type
    
    # Timestamp (4 bytes at offset 6)
    struct.pack_into('>I', record, 6, 0x12345678)
    
    # Date (4 bytes at offset 10)
    struct.pack_into('>I', record, 10, 0x20240115)
    
    # System ID (4 bytes at offset 14)
    record[14:18] = system_id.ljust(4).encode('cp037')
    
    # Subsystem ID (4 bytes at offset 18)
    record[18:22] = subsystem_id.ljust(4).encode('cp037')
    
    # Subtype (2 bytes at offset 22)
    struct.pack_into('>H', record, 22, ifcid)
    
    # Product section triplet (at offset 28)
    product_offset = 172  # After self-defining section (QWT0 has 18 triplets)
    product_length = 94  # QWHS header length
    
    if include_optional_headers:
        # Add space for optional headers
        product_length += 160  # Space for 4 optional headers
    
    struct.pack_into('>I', record, 28, product_offset)  # Offset
    struct.pack_into('>H', record, 32, product_length)  # Length
    struct.pack_into('>H', record, 34, 1)  # Count
    
    # Self-defining section triplets (QWT0 structure starting at offset 36)
    # R1 triplet
    struct.pack_into('>I', record, 36, 300)  # Offset
    struct.pack_into('>H', record, 40, 50)  # Length
    struct.pack_into('>H', record, 42, 1)  # Number
    
    # R2 triplet
    struct.pack_into('>I', record, 44, 350)  # Offset
    struct.pack_into('>H', record, 48, 40)  # Length
    struct.pack_into('>H', record, 50, 1)  # Number
    
    # R3-RH triplets (all empty for this test)
    for i in range(3, 19):  # R3 through RH (16 more triplets)
        offset_pos = 36 + (i - 1) * 8
        struct.pack_into('>I', record, offset_pos, 0)  # Offset
        struct.pack_into('>H', record, offset_pos + 4, 0)  # Length
        struct.pack_into('>H', record, offset_pos + 6, 0)  # Number
    
    # QWHS standard header (at product_offset)
    if db2_version == "V11":
        release_number = 0x0B00
    elif db2_version == "V12":
        release_number = 0x0C00
    else:  # V13
        release_number = 0x0D00
    
    struct.pack_into('>H', record, product_offset, 94)  # Header length
    struct.pack_into('B', record, product_offset + 2, 1)  # Header type (QWHS)
    struct.pack_into('B', record, product_offset + 3, 0xDB)  # Resource manager ID (DB2)
    struct.pack_into('>H', record, product_offset + 4, ifcid)  # IFCID
    struct.pack_into('>H', record, product_offset + 6, release_number)  # Release number
    struct.pack_into('B', record, product_offset + 8, 0)  # Num self-defining areas
    struct.pack_into('B', record, product_offset + 9, 0)  # Release indicator
    struct.pack_into('>I', record, product_offset + 10, 0)  # ACE address
    
    # Subsystem name (4 bytes at product_offset + 14)
    record[product_offset + 14:product_offset + 18] = subsystem_id.ljust(4).encode('cp037')
    
    # Store clock (8 bytes at product_offset + 18)
    struct.pack_into('>Q', record, product_offset + 18, 0x1234567890ABCDEF)
    
    # IFCID sequence (4 bytes at product_offset + 26)
    struct.pack_into('>I', record, product_offset + 26, 12345)
    
    # Destination sequence (4 bytes at product_offset + 30)
    struct.pack_into('>I', record, product_offset + 30, 67890)
    
    # Trace number mask (4 bytes at product_offset + 34)
    struct.pack_into('>I', record, product_offset + 34, 0xFFFFFFFF)
    
    # Local location name (16 bytes at product_offset + 38)
    record[product_offset + 38:product_offset + 54] = b'LOCATION1       '
    
    # LUWID (24 bytes at product_offset + 54)
    record[product_offset + 54:product_offset + 78] = b'LUWID123456789012345678'
    
    # Network ID (8 bytes at product_offset + 78)
    record[product_offset + 78:product_offset + 86] = b'NETID123'
    
    # LUNAME (8 bytes at product_offset + 86)
    record[product_offset + 86:product_offset + 94] = b'LUNAME12'
    
    # Add optional headers if requested
    if include_optional_headers:
        current_offset = product_offset + 94
        
        # Correlation header (type 2)
        struct.pack_into('>H', record, current_offset, 40)  # Length
        struct.pack_into('B', record, current_offset + 2, 2)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 40
        
        # Trace header (type 4)
        struct.pack_into('>H', record, current_offset, 36)  # Length
        struct.pack_into('B', record, current_offset + 2, 4)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 36
        
        # CPU header (type 8)
        struct.pack_into('>H', record, current_offset, 32)  # Length
        struct.pack_into('B', record, current_offset + 2, 8)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 32
        
        # Distributed header (type 16)
        struct.pack_into('>H', record, current_offset, 44)  # Length
        struct.pack_into('B', record, current_offset + 2, 16)  # Type
        struct.pack_into('B', record, current_offset + 3, 0xDB)  # RM ID
        current_offset += 44
    
    return bytes(record[:record_length])


class TestSMF102ParserV11:
    """Unit tests for SMF Type 102 V11 parser."""
    
    def test_parse_basic_structure(self):
        """
        Test parsing basic Type 102 V11 record structure.
        
        Requirements: 5.1, 5.5
        """
        record_data = create_smf102_record(db2_version="V11")
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify basic structure
        assert result.record_type == 102
        assert result.subtype == 1  # IFCID 1
        assert result.system_id.strip() == "SYS1"
        assert 'smf_header' in result.header
        assert 'qwhs_header' in result.header
        assert 'self_defining_section' in result.header
    
    def test_parse_smf_header_fields(self):
        """
        Test that all SMF header fields are extracted.
        
        Requirements: 5.1, 5.5
        """
        record_data = create_smf102_record(db2_version="V11")
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        smf_header = result.header['smf_header']
        
        # Verify all expected fields are present
        assert 'record_length' in smf_header
        assert 'record_type' in smf_header
        assert 'system_id' in smf_header
        assert 'subsystem_id' in smf_header
        assert 'timestamp' in smf_header
        assert 'date' in smf_header
        
        # Verify values
        assert smf_header['record_type'] == 102
        assert smf_header['system_id'].strip() == "SYS1"
        assert smf_header['subsystem_id'].strip() == "DB2P"
    
    def test_parse_qwhs_header_fields(self):
        """
        Test that all QWHS header fields are extracted.
        
        Requirements: 5.1, 5.5
        """
        record_data = create_smf102_record(db2_version="V11")
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        qwhs = result.header['qwhs_header']
        
        # Verify all expected fields are present
        assert 'header_length' in qwhs
        assert 'header_type' in qwhs
        assert 'resource_manager_id' in qwhs
        assert 'ifcid' in qwhs
        assert 'release_number' in qwhs
        assert 'subsystem_name' in qwhs
        
        # Verify values
        assert qwhs['header_type'] == 1  # QWHS
        assert qwhs['resource_manager_id'] == 0xDB  # DB2
        assert qwhs['ifcid'] == 1  # Performance
        assert qwhs['release_number'] == 0x0B00  # V11
        assert qwhs['subsystem_name'].strip() == "DB2P"
    
    def test_parse_self_defining_section(self):
        """
        Test parsing self-defining section (QWT0).
        
        Requirements: 5.1, 5.5
        """
        record_data = create_smf102_record(db2_version="V11")
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        sds = result.header['self_defining_section']
        
        # Verify structure
        assert 'triplets' in sds
        
        # Verify QWT0 triplets are present (R1-RH)
        triplets = sds['triplets']
        assert 'product_section' in triplets
        assert 'r1' in triplets
        assert 'r2' in triplets
        assert 'r3' in triplets
        assert 'r4' in triplets
        assert 'r5' in triplets
        assert 'r6' in triplets
        assert 'r7' in triplets
        assert 'r8' in triplets
        assert 'r9' in triplets
        assert 'ra' in triplets
        assert 'rb' in triplets
        assert 'rc' in triplets
        assert 'rd' in triplets
        assert 're' in triplets
        assert 'rf' in triplets
        assert 'rg' in triplets
        assert 'rh' in triplets
    
    def test_parse_optional_headers(self):
        """
        Test parsing optional headers in product section.
        
        Requirements: 5.1, 5.5
        """
        record_data = create_smf102_record(db2_version="V11", include_optional_headers=True)
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify optional headers are present
        assert 'optional_headers' in result.header
        optional_headers = result.header['optional_headers']
        
        # Check for expected optional headers
        assert 'correlation' in optional_headers
        assert 'trace' in optional_headers
        assert 'cpu' in optional_headers
        assert 'distributed' in optional_headers
        
        # Verify each header has required fields
        for header_name, header_data in optional_headers.items():
            assert 'offset' in header_data
            assert 'length' in header_data
            assert 'type' in header_data
    
    def test_parse_without_optional_headers(self):
        """
        Test parsing record without optional headers.
        
        Requirements: 5.1, 5.5
        """
        record_data = create_smf102_record(db2_version="V11", include_optional_headers=False)
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify record parses successfully
        assert result.record_type == 102
        
        # Optional headers should be empty or not present
        if 'optional_headers' in result.header:
            assert len(result.header['optional_headers']) == 0
    
    def test_db2_version_attribute(self):
        """
        Test that parser has correct DB2 version attribute.
        
        Requirements: 5.1
        """
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        assert parser.db2_version == "V11"
    
    def test_error_handling_invalid_record_type(self):
        """
        Test error handling for invalid record type.
        
        Requirements: 5.1, 9.1
        """
        record_data = create_smf102_record(db2_version="V11")
        record_data = bytearray(record_data)
        record_data[5] = 101  # Change to Type 101
        record_data = bytes(record_data)
        
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "record type" in str(exc_info.value).lower()
    
    def test_error_handling_missing_product_section(self):
        """
        Test error handling when product section is missing.
        
        Requirements: 5.1, 9.1
        """
        record_data = create_smf102_record(db2_version="V11")
        record_data = bytearray(record_data)
        
        # Set product section count to 0
        struct.pack_into('>H', record_data, 34, 0)
        record_data = bytes(record_data)
        
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "product section" in str(exc_info.value).lower()



class TestSMF102ParserV12:
    """Unit tests for SMF Type 102 V12 parser."""
    
    def test_parse_basic_structure(self):
        """
        Test parsing basic Type 102 V12 record structure.
        
        Requirements: 5.2, 5.5
        """
        record_data = create_smf102_record(db2_version="V12")
        parser = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify basic structure
        assert result.record_type == 102
        assert result.subtype == 1  # IFCID 1
        assert result.system_id.strip() == "SYS1"
        assert 'smf_header' in result.header
        assert 'qwhs_header' in result.header
        assert 'self_defining_section' in result.header
    
    def test_parse_qwhs_header_v12_release_number(self):
        """
        Test that QWHS header has V12 release number.
        
        Requirements: 5.2, 5.5
        """
        record_data = create_smf102_record(db2_version="V12")
        parser = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        qwhs = result.header['qwhs_header']
        
        # Verify V12 release number
        assert qwhs['release_number'] == 0x0C00  # V12
    
    def test_db2_version_attribute(self):
        """
        Test that parser has correct DB2 version attribute.
        
        Requirements: 5.2
        """
        parser = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        assert parser.db2_version == "V12"
    
    def test_error_handling_invalid_record_type(self):
        """
        Test error handling for invalid record type.
        
        Requirements: 5.2, 9.1
        """
        record_data = create_smf102_record(db2_version="V12")
        record_data = bytearray(record_data)
        record_data[5] = 100  # Change to Type 100
        record_data = bytes(record_data)
        
        parser = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "record type" in str(exc_info.value).lower()



class TestSMF102ParserV13:
    """Unit tests for SMF Type 102 V13 parser."""
    
    def test_parse_basic_structure(self):
        """
        Test parsing basic Type 102 V13 record structure.
        
        Requirements: 5.3, 5.5
        """
        record_data = create_smf102_record(db2_version="V13")
        parser = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify basic structure
        assert result.record_type == 102
        assert result.subtype == 1  # IFCID 1
        assert result.system_id.strip() == "SYS1"
        assert 'smf_header' in result.header
        assert 'qwhs_header' in result.header
        assert 'self_defining_section' in result.header
    
    def test_parse_qwhs_header_v13_release_number(self):
        """
        Test that QWHS header has V13 release number.
        
        Requirements: 5.3, 5.5
        """
        record_data = create_smf102_record(db2_version="V13")
        parser = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        qwhs = result.header['qwhs_header']
        
        # Verify V13 release number
        assert qwhs['release_number'] == 0x0D00  # V13
    
    def test_db2_version_attribute(self):
        """
        Test that parser has correct DB2 version attribute.
        
        Requirements: 5.3
        """
        parser = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        assert parser.db2_version == "V13"
    
    def test_error_handling_invalid_record_type(self):
        """
        Test error handling for invalid record type.
        
        Requirements: 5.3, 9.1
        """
        record_data = create_smf102_record(db2_version="V13")
        record_data = bytearray(record_data)
        record_data[5] = 101  # Change to Type 101
        record_data = bytes(record_data)
        
        parser = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "record type" in str(exc_info.value).lower()



class TestVersionDifferences:
    """Test version-specific differences between V11, V12, and V13 parsers."""
    
    def test_v11_vs_v12_vs_v13_release_numbers(self):
        """
        Test that V11, V12, and V13 parsers handle version-specific release numbers.
        
        Requirements: 5.1, 5.2, 5.3, 5.5
        """
        # Parse records with different versions
        record_v11 = create_smf102_record(db2_version="V11")
        record_v12 = create_smf102_record(db2_version="V12")
        record_v13 = create_smf102_record(db2_version="V13")
        
        parser_v11 = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        parser_v12 = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        parser_v13 = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        
        result_v11 = parser_v11.parse(record_v11)
        result_v12 = parser_v12.parse(record_v12)
        result_v13 = parser_v13.parse(record_v13)
        
        # Verify version attributes
        assert parser_v11.db2_version == "V11"
        assert parser_v12.db2_version == "V12"
        assert parser_v13.db2_version == "V13"
        
        # Verify release numbers
        assert result_v11.header['qwhs_header']['release_number'] == 0x0B00
        assert result_v12.header['qwhs_header']['release_number'] == 0x0C00
        assert result_v13.header['qwhs_header']['release_number'] == 0x0D00
    
    def test_all_versions_parse_same_structure(self):
        """
        Test that all versions parse the same basic structure.
        
        Requirements: 5.1, 5.2, 5.3, 5.5
        """
        # Create records for each version
        record_v11 = create_smf102_record(db2_version="V11")
        record_v12 = create_smf102_record(db2_version="V12")
        record_v13 = create_smf102_record(db2_version="V13")
        
        # Parse with appropriate parsers
        parser_v11 = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        parser_v12 = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        parser_v13 = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        
        result_v11 = parser_v11.parse(record_v11)
        result_v12 = parser_v12.parse(record_v12)
        result_v13 = parser_v13.parse(record_v13)
        
        # Verify all have same basic structure
        for result in [result_v11, result_v12, result_v13]:
            assert result.record_type == 102
            assert 'smf_header' in result.header
            assert 'qwhs_header' in result.header
            assert 'self_defining_section' in result.header
            
            # Verify triplets structure
            triplets = result.header['self_defining_section']['triplets']
            assert 'product_section' in triplets
            assert 'r1' in triplets
            assert 'r2' in triplets
            assert 'rh' in triplets  # Last triplet



class TestIFCIDRegistryIntegration:
    """Test IFCID registry integration in Type 102 parsers.
    
    Feature: db2-versioned-smf-parsers
    Tests: Task 16.4 - Registry integration
    Reference: TYPE_102_PARSING_REQUIREMENTS.md Section 11
    """
    
    def test_parser_initialization_creates_registry(self):
        """
        Test that parser initialization creates an IFCID registry.
        
        Verifies that each parser has an ifcid_registry instance variable
        and calls _register_ifcid_parsers() during initialization.
        """
        # Test V11 parser
        parser_v11 = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        assert hasattr(parser_v11, 'ifcid_registry')
        assert parser_v11.ifcid_registry is not None
        assert parser_v11.db2_version == "V11"
        
        # Test V12 parser
        parser_v12 = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        assert hasattr(parser_v12, 'ifcid_registry')
        assert parser_v12.ifcid_registry is not None
        assert parser_v12.db2_version == "V12"
        
        # Test V13 parser
        parser_v13 = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        assert hasattr(parser_v13, 'ifcid_registry')
        assert parser_v13.ifcid_registry is not None
        assert parser_v13.db2_version == "V13"
    
    def test_current_ifcid_stored_during_parsing(self):
        """
        Test that current IFCID is stored during QWHS parsing.
        
        Verifies that the parser stores the IFCID from the QWHS header
        in the current_ifcid attribute for use in data section parsing.
        """
        # Create record with specific IFCID
        ifcid = 365  # DDF location statistics
        record_data = create_smf102_record(db2_version="V11", ifcid=ifcid)
        
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify IFCID was stored
        assert parser.current_ifcid == ifcid
        assert result.subtype == ifcid
    
    def test_generic_parsing_fallback_for_unsupported_ifcid(self):
        """
        Test that parser falls back to generic parsing for unsupported IFCIDs.
        
        When no IFCID-specific parser is registered, the parser should
        fall back to generic parsing that captures section structure only.
        """
        # Create record with unsupported IFCID
        ifcid = 999  # Unsupported IFCID
        record_data = create_smf102_record(db2_version="V11", ifcid=ifcid)
        
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        result = parser.parse(record_data)
        
        # Verify parsing succeeded with generic fallback
        assert result.record_type == 102
        assert result.subtype == ifcid
        
        # Verify data sections were parsed generically
        if 'data_sections' in result.header:
            data_sections = result.header['data_sections']
            # Generic parsing should capture section presence
            if 'r1' in data_sections:
                assert 'offset' in data_sections['r1']
                assert 'length' in data_sections['r1']
                assert 'count' in data_sections['r1']
                assert 'exists' in data_sections['r1']
    
    def test_logging_for_unsupported_ifcid(self, caplog):
        """
        Test that parser logs debug message for unsupported IFCIDs.
        
        When no IFCID-specific parser is found, the parser should log
        a debug message indicating generic parsing is being used.
        """
        import logging
        
        # Create record with unsupported IFCID
        ifcid = 888  # Unsupported IFCID
        record_data = create_smf102_record(db2_version="V12", ifcid=ifcid)
        
        parser = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        
        with caplog.at_level(logging.DEBUG):
            result = parser.parse(record_data)
        
        # Verify debug log message was generated
        assert any(
            "No IFCID-specific parser found" in record.message
            for record in caplog.records
        )
        assert any(
            "generic parsing" in record.message.lower()
            for record in caplog.records
        )
    
    def test_ifcid_specific_parser_invocation(self):
        """
        Test that IFCID-specific parser is invoked when registered.
        
        This test registers a mock IFCID parser and verifies it is called
        during data section parsing.
        """
        # Create a mock IFCID parser function
        mock_called = {'called': False, 'ifcid': None}
        
        def mock_ifcid_parser(record_data, self_defining_section):
            mock_called['called'] = True
            return {
                'mock_data': 'test',
                'r1': {'parsed': True}
            }
        
        # Create record with specific IFCID
        ifcid = 365
        record_data = create_smf102_record(db2_version="V11", ifcid=ifcid)
        
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        
        # Register mock parser
        parser.ifcid_registry.register(ifcid, "V11", mock_ifcid_parser)
        
        # Parse record
        result = parser.parse(record_data)
        
        # Verify mock parser was called
        assert mock_called['called']
        
        # Verify mock parser result was used
        if 'data_sections' in result.header:
            data_sections = result.header['data_sections']
            assert 'mock_data' in data_sections
            assert data_sections['mock_data'] == 'test'
    
    def test_ifcid_parser_error_fallback(self, caplog):
        """
        Test that parser falls back to generic parsing if IFCID parser fails.
        
        If an IFCID-specific parser raises an exception, the parser should
        log a warning and fall back to generic parsing.
        """
        import logging
        
        # Create a failing IFCID parser function
        def failing_ifcid_parser(record_data, self_defining_section):
            raise ValueError("Mock parser failure")
        
        # Create record with specific IFCID
        ifcid = 370
        record_data = create_smf102_record(db2_version="V12", ifcid=ifcid)
        
        parser = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        
        # Register failing parser
        parser.ifcid_registry.register(ifcid, "V12", failing_ifcid_parser)
        
        # Parse record - should not raise exception
        with caplog.at_level(logging.WARNING):
            result = parser.parse(record_data)
        
        # Verify parsing succeeded with fallback
        assert result.record_type == 102
        assert result.subtype == ifcid
        
        # Verify warning was logged
        assert any(
            "IFCID-specific parser failed" in record.message
            for record in caplog.records
        )
        assert any(
            "Falling back to generic parsing" in record.message
            for record in caplog.records
        )
    
    def test_version_specific_ifcid_parser_selection(self):
        """
        Test that correct version-specific IFCID parser is selected.
        
        Verifies that V11, V12, and V13 parsers use their respective
        version-specific IFCID parsers from the registry.
        """
        # Create mock parsers for different versions
        v11_called = {'called': False}
        v12_called = {'called': False}
        v13_called = {'called': False}
        
        def mock_v11_parser(record_data, self_defining_section):
            v11_called['called'] = True
            return {'version': 'V11'}
        
        def mock_v12_parser(record_data, self_defining_section):
            v12_called['called'] = True
            return {'version': 'V12'}
        
        def mock_v13_parser(record_data, self_defining_section):
            v13_called['called'] = True
            return {'version': 'V13'}
        
        ifcid = 365
        
        # Test V11 parser
        record_v11 = create_smf102_record(db2_version="V11", ifcid=ifcid)
        parser_v11 = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        parser_v11.ifcid_registry.register(ifcid, "V11", mock_v11_parser)
        result_v11 = parser_v11.parse(record_v11)
        assert v11_called['called']
        assert not v12_called['called']
        assert not v13_called['called']
        
        # Reset flags
        v11_called['called'] = False
        
        # Test V12 parser
        record_v12 = create_smf102_record(db2_version="V12", ifcid=ifcid)
        parser_v12 = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        parser_v12.ifcid_registry.register(ifcid, "V12", mock_v12_parser)
        result_v12 = parser_v12.parse(record_v12)
        assert not v11_called['called']
        assert v12_called['called']
        assert not v13_called['called']
        
        # Reset flags
        v12_called['called'] = False
        
        # Test V13 parser
        record_v13 = create_smf102_record(db2_version="V13", ifcid=ifcid)
        parser_v13 = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        parser_v13.ifcid_registry.register(ifcid, "V13", mock_v13_parser)
        result_v13 = parser_v13.parse(record_v13)
        assert not v11_called['called']
        assert not v12_called['called']
        assert v13_called['called']
    
    def test_register_ifcid_parsers_method_exists(self):
        """
        Test that _register_ifcid_parsers() method exists and is callable.
        
        Verifies that each parser has the _register_ifcid_parsers() method
        for registering IFCID-specific parsers.
        """
        parser_v11 = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        parser_v12 = SMF102ParserV12(BaseRecordParser(encoding='EBCDIC'))
        parser_v13 = SMF102ParserV13(BaseRecordParser(encoding='EBCDIC'))
        
        # Verify method exists
        assert hasattr(parser_v11, '_register_ifcid_parsers')
        assert hasattr(parser_v12, '_register_ifcid_parsers')
        assert hasattr(parser_v13, '_register_ifcid_parsers')
        
        # Verify method is callable
        assert callable(parser_v11._register_ifcid_parsers)
        assert callable(parser_v12._register_ifcid_parsers)
        assert callable(parser_v13._register_ifcid_parsers)
    
    def test_multiple_ifcids_in_sequence(self):
        """
        Test parsing multiple records with different IFCIDs in sequence.
        
        Verifies that the parser correctly handles different IFCIDs
        in consecutive parsing operations.
        """
        parser = SMF102ParserV11(BaseRecordParser(encoding='EBCDIC'))
        
        # Parse records with different IFCIDs
        ifcids = [1, 365, 370, 999]
        
        for ifcid in ifcids:
            record_data = create_smf102_record(db2_version="V11", ifcid=ifcid)
            result = parser.parse(record_data)
            
            # Verify correct IFCID was parsed
            assert result.subtype == ifcid
            assert parser.current_ifcid == ifcid
            
            # Verify parsing succeeded
            assert result.record_type == 102
            assert 'smf_header' in result.header
            assert 'qwhs_header' in result.header
