"""Property-based tests for SMF Type 7 parser.

Feature: smf-parser-expansion
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers import SMF7ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_type7_record(
    record_length: int = 72,
    system_id: str = "SYS1",
    num_records_lost: int = 100,
    start_time: int = 18000,
    flag_byte: int = 0x00,
    dropped_record_type: int = 0,
    num_records_lost_extended: int = 100,
    log_stream_name: str = "",
    bytes_lost_init: int = 0,
    dropped_record_type_extended: int = 0
) -> bytes:
    """Create a synthetic Type 7 record for testing.
    
    Args:
        record_length: Total record length (minimum 72 bytes)
        system_id: 4-character system ID
        num_records_lost: Number of records lost (2-byte field)
        start_time: Start time of data loss period (hundredths of a second)
        flag_byte: Flag byte (SMF7FL1)
        dropped_record_type: Type of record dropped (1-byte field)
        num_records_lost_extended: Extended number of records lost (4-byte field)
        log_stream_name: Log stream name (26 characters)
        bytes_lost_init: Bytes lost during initialization (8-byte field)
        dropped_record_type_extended: Extended dropped record type (2-byte field)
        
    Returns:
        Binary SMF Type 7 record
    """
    record = bytearray(record_length)
    
    # Standard SMF header (18 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 7)  # Record type = 7
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    
    # Date (packed decimal 0cyydddF) - 2025001F (Jan 1, 2025)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    # System ID (EBCDIC)
    sys_id_bytes = system_id.ljust(4).encode('cp037')[:4]
    record[14:18] = sys_id_bytes
    
    # Type 7 specific fields
    struct.pack_into('>H', record, 18, num_records_lost)  # Number of records lost
    struct.pack_into('>I', record, 20, start_time)  # Start time
    
    # Start date (packed decimal)
    record[24:28] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    struct.pack_into('B', record, 28, flag_byte)  # Flag byte
    struct.pack_into('B', record, 29, 0x00)  # Reserved
    struct.pack_into('B', record, 30, 0x00)  # Reserved
    struct.pack_into('B', record, 31, dropped_record_type)  # Dropped record type
    
    struct.pack_into('>I', record, 32, num_records_lost_extended)  # Extended count
    
    # Log stream name (26 bytes, EBCDIC)
    if log_stream_name:
        log_stream_bytes = log_stream_name.ljust(26).encode('cp037')[:26]
        record[36:62] = log_stream_bytes
    else:
        record[36:62] = b' ' * 26
    
    struct.pack_into('>Q', record, 62, bytes_lost_init)  # Bytes lost during init
    struct.pack_into('>H', record, 70, dropped_record_type_extended)  # Extended dropped type
    
    return bytes(record)


# Strategies for generating test data
ebcdic_chars = st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.')

system_ids = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=4
).map(lambda x: x.ljust(4)[:4])

log_stream_names = st.text(
    alphabet=ebcdic_chars,
    min_size=0,
    max_size=26
).map(lambda x: x.ljust(26)[:26] if x else "")

# Flag byte combinations
flag_bytes = st.sampled_from([
    0x00,  # No flags
    0x80,  # SMF7NRF (overflow)
    0x40,  # SMF7LSD (log stream full)
    0x20,  # SMF7DRP (flood policy)
    0xC0,  # SMF7NRF + SMF7LSD
    0xA0,  # SMF7NRF + SMF7DRP
    0x60,  # SMF7LSD + SMF7DRP
    0xE0,  # All three flags
])


class TestSMF7ParserProperties:
    """Property-based tests for SMF Type 7 parser."""
    
    @settings(max_examples=100)
    @given(
        system_id=system_ids,
        num_records_lost=st.integers(min_value=0, max_value=65535),
        start_time=st.integers(min_value=0, max_value=8640000),  # 0-24 hours in hundredths
        flag_byte=flag_bytes,
        dropped_record_type=st.integers(min_value=0, max_value=255),
        num_records_lost_extended=st.integers(min_value=0, max_value=4294967295),
        log_stream_name=log_stream_names,
        bytes_lost_init=st.integers(min_value=0, max_value=1099511627776),  # Up to 1TB
        dropped_record_type_extended=st.integers(min_value=0, max_value=2047)
    )
    def test_property_1_field_extraction_completeness(
        self, system_id, num_records_lost, start_time, flag_byte,
        dropped_record_type, num_records_lost_extended, log_stream_name,
        bytes_lost_init, dropped_record_type_extended
    ):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.6**
        
        For any SMF Type 7 record, parsing should extract all standard header fields
        (record_type, subtype, system_id, timestamp, date, record_length) and all
        documented type-specific fields.
        """
        # Create test record
        record_data = create_type7_record(
            system_id=system_id,
            num_records_lost=num_records_lost,
            start_time=start_time,
            flag_byte=flag_byte,
            dropped_record_type=dropped_record_type,
            num_records_lost_extended=num_records_lost_extended,
            log_stream_name=log_stream_name,
            bytes_lost_init=bytes_lost_init,
            dropped_record_type_extended=dropped_record_type_extended
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header fields are present
        assert parsed.record_type == 7, "record_type should be 7"
        assert parsed.subtype == 0, "subtype should be 0 (Type 7 has no subtypes)"
        assert parsed.system_id is not None, "system_id should be extracted"
        assert parsed.timestamp is not None, "timestamp should be extracted"
        assert parsed.date is not None, "date should be extracted"
        assert parsed.record_length == 72, "record_length should match"
        
        # Verify header section is present
        assert parsed.header is not None, "header section should be present"
        header = parsed.header
        
        assert 'record_length' in header, "record_length should be in header"
        assert 'segment_descriptor' in header, "segment_descriptor should be in header"
        assert 'system_indicator' in header, "system_indicator should be in header"
        assert 'record_type' in header, "record_type should be in header"
        assert 'timestamp' in header, "timestamp should be in header"
        assert 'date' in header, "date should be in header"
        assert 'system_id' in header, "system_id should be in header"
        
        # Verify performance (data loss info) section is present
        assert parsed.performance is not None, "performance section should be present"
        data_loss = parsed.performance
        
        # Verify all data loss fields are extracted
        assert 'num_records_lost' in data_loss, "num_records_lost should be extracted"
        assert 'start_time' in data_loss, "start_time should be extracted"
        assert 'start_date' in data_loss, "start_date should be extracted"
        assert 'flag_byte' in data_loss, "flag_byte should be extracted"
        assert 'num_records_overflow' in data_loss, "num_records_overflow flag should be extracted"
        assert 'log_stream_full' in data_loss, "log_stream_full flag should be extracted"
        assert 'flood_policy_active' in data_loss, "flood_policy_active flag should be extracted"
        assert 'dropped_record_type' in data_loss, "dropped_record_type should be extracted"
        assert 'num_records_lost_extended' in data_loss, "num_records_lost_extended should be extracted"
        assert 'log_stream_name' in data_loss, "log_stream_name should be extracted"
        assert 'bytes_lost_init' in data_loss, "bytes_lost_init should be extracted"
        assert 'dropped_record_type_extended' in data_loss, "dropped_record_type_extended should be extracted"
        
        # Verify extracted values match input
        assert data_loss['num_records_lost'] == num_records_lost, \
            "num_records_lost value should match input"
        assert data_loss['start_time'] is not None, \
            "start_time should be parsed"
        assert data_loss['flag_byte'] == flag_byte, \
            "flag_byte value should match input"
        assert data_loss['dropped_record_type'] == dropped_record_type, \
            "dropped_record_type value should match input"
        assert data_loss['num_records_lost_extended'] == num_records_lost_extended, \
            "num_records_lost_extended value should match input"
        assert data_loss['bytes_lost_init'] == bytes_lost_init, \
            "bytes_lost_init value should match input"
        assert data_loss['dropped_record_type_extended'] == dropped_record_type_extended, \
            "dropped_record_type_extended value should match input"
        
        # Verify flag parsing
        assert data_loss['num_records_overflow'] == bool(flag_byte & 0x80), \
            "num_records_overflow flag should match bit 0 of flag_byte"
        assert data_loss['log_stream_full'] == bool(flag_byte & 0x40), \
            "log_stream_full flag should match bit 1 of flag_byte"
        assert data_loss['flood_policy_active'] == bool(flag_byte & 0x20), \
            "flood_policy_active flag should match bit 2 of flag_byte"
        
        # Verify log stream name is extracted (may be empty/spaces)
        if log_stream_name.strip():
            assert data_loss['log_stream_name'].strip() == log_stream_name.strip(), \
                "log_stream_name value should match input when non-empty"
    
    @settings(max_examples=50)
    @given(
        system_id=system_ids,
        num_records_lost_extended=st.integers(min_value=65536, max_value=4294967295)
    )
    def test_property_overflow_flag_consistency(self, system_id, num_records_lost_extended):
        """
        **Feature: smf-parser-expansion, Property: Overflow Flag Consistency**
        **Validates: Requirements 1.6**
        
        For any Type 7 record with overflow flag set, the extended count field
        should be used instead of the 2-byte count field.
        """
        # Create record with overflow flag
        record_data = create_type7_record(
            system_id=system_id,
            num_records_lost=65535,  # Max value for 2-byte field
            flag_byte=0x80,  # Overflow flag set
            num_records_lost_extended=num_records_lost_extended
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify overflow flag is set
        assert parsed.performance['num_records_overflow'] is True, \
            "overflow flag should be set"
        
        # Verify extended count is available
        assert parsed.performance['num_records_lost_extended'] == num_records_lost_extended, \
            "extended count should match input"
    
    @settings(max_examples=50)
    @given(
        system_id=system_ids,
        log_stream_name=st.text(
            alphabet=ebcdic_chars,
            min_size=1,
            max_size=26
        ).map(lambda x: x.ljust(26)[:26])
    )
    def test_property_log_stream_flag_consistency(self, system_id, log_stream_name):
        """
        **Feature: smf-parser-expansion, Property: Log Stream Flag Consistency**
        **Validates: Requirements 1.6**
        
        For any Type 7 record with log stream full flag set, the log stream name
        field should be populated.
        """
        # Create record with log stream full flag
        record_data = create_type7_record(
            system_id=system_id,
            flag_byte=0x40,  # Log stream full flag set
            log_stream_name=log_stream_name
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify log stream full flag is set
        assert parsed.performance['log_stream_full'] is True, \
            "log stream full flag should be set"
        
        # Verify log stream name is extracted
        assert 'log_stream_name' in parsed.performance, \
            "log_stream_name should be present"
        assert parsed.performance['log_stream_name'].strip() == log_stream_name.strip(), \
            "log_stream_name should match input"
    
    @settings(max_examples=50)
    @given(
        system_id=system_ids,
        dropped_record_type=st.integers(min_value=0, max_value=255),
        dropped_record_type_extended=st.integers(min_value=0, max_value=2047)
    )
    def test_property_flood_policy_flag_consistency(
        self, system_id, dropped_record_type, dropped_record_type_extended
    ):
        """
        **Feature: smf-parser-expansion, Property: Flood Policy Flag Consistency**
        **Validates: Requirements 1.6**
        
        For any Type 7 record with flood policy flag set, the dropped record type
        fields should be populated.
        """
        # Create record with flood policy flag
        record_data = create_type7_record(
            system_id=system_id,
            flag_byte=0x20,  # Flood policy flag set
            dropped_record_type=dropped_record_type,
            dropped_record_type_extended=dropped_record_type_extended
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify flood policy flag is set
        assert parsed.performance['flood_policy_active'] is True, \
            "flood policy flag should be set"
        
        # Verify dropped record type fields are extracted
        assert parsed.performance['dropped_record_type'] == dropped_record_type, \
            "dropped_record_type should match input"
        assert parsed.performance['dropped_record_type_extended'] == dropped_record_type_extended, \
            "dropped_record_type_extended should match input"

