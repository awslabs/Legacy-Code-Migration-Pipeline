"""Property-based tests for SMF Type 4 parser.

Feature: smf-parser-expansion
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers import SMF4ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_type4_record(
    record_length: int = 260,
    system_id: str = "SYS1",
    job_name: str = "TESTJOB",
    step_name: str = "STEP1",
    program_name: str = "TESTPGM",
    step_number: int = 1,
    completion_code: int = 0,
    region_size: int = 8192,
    storage_top: int = 1024,
    storage_bottom: int = 2048
) -> bytes:
    """Create a synthetic Type 4 record for testing.
    
    Args:
        record_length: Total record length
        system_id: 4-character system ID
        job_name: 8-character job name
        step_name: 8-character step name
        program_name: 8-character program name
        step_number: Step number (1-255)
        completion_code: Step completion code
        region_size: Region size in 1K units
        storage_top: Storage from top in 1K units
        storage_bottom: Storage from bottom in 1K units
        
    Returns:
        Binary SMF Type 4 record
    """
    record = bytearray(record_length)
    
    # Standard SMF header (18 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 4)  # Record type = 4
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    
    # Date (packed decimal 0cyydddF) - 2025001F (Jan 1, 2025)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    # System ID (EBCDIC)
    sys_id_bytes = system_id.ljust(4).encode('cp037')[:4]
    record[14:18] = sys_id_bytes
    
    # Job identification (offsets 18-41)
    job_name_bytes = job_name.ljust(8).encode('cp037')[:8]
    record[18:26] = job_name_bytes
    
    struct.pack_into('>I', record, 26, 18000)  # Reader start time
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader start date
    
    user_id_bytes = "USER1".ljust(8).encode('cp037')[:8]
    record[34:42] = user_id_bytes
    
    # Step identification (offsets 42-73)
    struct.pack_into('B', record, 42, step_number)  # Step number
    struct.pack_into('>I', record, 43, 19000)  # Step init time
    record[47:51] = bytes([0x01, 0x25, 0x00, 0x1F])  # Step init date
    struct.pack_into('>I', record, 51, 100)  # Card image count
    struct.pack_into('>H', record, 55, completion_code)  # Completion code
    struct.pack_into('B', record, 57, 10)  # Dispatching priority
    
    program_name_bytes = program_name.ljust(8).encode('cp037')[:8]
    record[58:66] = program_name_bytes
    
    step_name_bytes = step_name.ljust(8).encode('cp037')[:8]
    record[66:74] = step_name_bytes
    
    # Performance fields (offsets 76-103)
    struct.pack_into('>H', record, 76, storage_top)  # Storage top
    struct.pack_into('>H', record, 78, storage_bottom)  # Storage bottom
    struct.pack_into('>I', record, 82, region_size)  # Region size
    struct.pack_into('B', record, 86, 8)  # Storage protect key
    struct.pack_into('B', record, 87, 0)  # Step termination indicator
    struct.pack_into('>I', record, 90, 17000)  # Device allocation start time
    struct.pack_into('>I', record, 94, 18000)  # Problem program start time
    
    # SRB CPU time (3 bytes at offset 99)
    srb_time = 100
    record[99] = (srb_time >> 16) & 0xFF
    record[100] = (srb_time >> 8) & 0xFF
    record[101] = srb_time & 0xFF
    
    # Record indicators (offset 102)
    struct.pack_into('>H', record, 102, 0)  # No special indicators
    
    # Relocate offset and device length (offsets 104-107)
    # Set to 0 to indicate no device data or relocate section
    struct.pack_into('>H', record, 104, 0)  # Relocate offset = 0 (not present)
    struct.pack_into('>H', record, 106, 2)  # Device length = 2 (no devices)
    
    return bytes(record)


# Strategies for generating test data
ebcdic_chars = st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

system_ids = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=4
).map(lambda x: x.ljust(4)[:4])

names_8char = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=8
).map(lambda x: x.ljust(8)[:8])


class TestSMF4ParserProperties:
    """Property-based tests for SMF Type 4 parser."""
    
    @settings(max_examples=100)
    @given(
        system_id=system_ids,
        job_name=names_8char,
        step_name=names_8char,
        program_name=names_8char,
        step_number=st.integers(min_value=1, max_value=255),
        completion_code=st.integers(min_value=0, max_value=65535),
        region_size=st.integers(min_value=1024, max_value=1000000),
        storage_top=st.integers(min_value=100, max_value=10000),
        storage_bottom=st.integers(min_value=100, max_value=10000)
    )
    def test_property_1_field_extraction_completeness(
        self, system_id, job_name, step_name, program_name, step_number,
        completion_code, region_size, storage_top, storage_bottom
    ):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.3**
        
        For any SMF Type 4 record, parsing should extract all standard header fields
        (record_type, subtype, system_id, timestamp, date, record_length) and all
        documented type-specific fields.
        """
        # Create test record
        record_data = create_type4_record(
            system_id=system_id,
            job_name=job_name,
            step_name=step_name,
            program_name=program_name,
            step_number=step_number,
            completion_code=completion_code,
            region_size=region_size,
            storage_top=storage_top,
            storage_bottom=storage_bottom
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF4ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header fields are present
        assert parsed.record_type == 4, "record_type should be 4"
        assert parsed.subtype == 0, "subtype should be 0 (Type 4 has no subtypes)"
        assert parsed.system_id is not None, "system_id should be extracted"
        assert parsed.timestamp is not None, "timestamp should be extracted"
        assert parsed.date is not None, "date should be extracted"
        assert parsed.record_length == 260, "record_length should match"
        
        # Verify identification section is present
        assert parsed.identification is not None, "identification section should be present"
        ident = parsed.identification
        
        assert 'job_name' in ident, "job_name should be extracted"
        assert 'step_name' in ident, "step_name should be extracted"
        assert 'program_name' in ident, "program_name should be extracted"
        assert 'step_number' in ident, "step_number should be extracted"
        assert 'step_completion_code' in ident, "step_completion_code should be extracted"
        assert 'user_id' in ident, "user_id should be extracted"
        assert 'reader_start_time' in ident, "reader_start_time should be extracted"
        assert 'reader_start_date' in ident, "reader_start_date should be extracted"
        assert 'step_init_time' in ident, "step_init_time should be extracted"
        assert 'step_init_date' in ident, "step_init_date should be extracted"
        assert 'card_image_count' in ident, "card_image_count should be extracted"
        assert 'dispatching_priority' in ident, "dispatching_priority should be extracted"
        
        # Verify performance section is present
        assert parsed.performance is not None, "performance section should be present"
        perf = parsed.performance
        
        assert 'storage_top' in perf, "storage_top should be extracted"
        assert 'storage_bottom' in perf, "storage_bottom should be extracted"
        assert 'region_size' in perf, "region_size should be extracted"
        assert 'storage_protect_key' in perf, "storage_protect_key should be extracted"
        assert 'step_termination_indicator' in perf, "step_termination_indicator should be extracted"
        assert 'device_allocation_start_time' in perf, "device_allocation_start_time should be extracted"
        assert 'problem_program_start_time' in perf, "problem_program_start_time should be extracted"
        assert 'srb_cpu_time' in perf, "srb_cpu_time should be extracted"
        assert 'record_indicator' in perf, "record_indicator should be extracted"
        assert 'abend' in perf, "abend flag should be extracted"
        assert 'flushed' in perf, "flushed flag should be extracted"
        
        # Verify extracted values match input
        assert ident['job_name'].strip() == job_name.strip(), \
            "job_name value should match input"
        assert ident['step_name'].strip() == step_name.strip(), \
            "step_name value should match input"
        assert ident['program_name'].strip() == program_name.strip(), \
            "program_name value should match input"
        assert ident['step_number'] == step_number, \
            "step_number value should match input"
        assert ident['step_completion_code'] == completion_code, \
            "step_completion_code value should match input"
        assert perf['region_size'] == region_size, \
            "region_size value should match input"
        assert perf['storage_top'] == storage_top, \
            "storage_top value should match input"
        assert perf['storage_bottom'] == storage_bottom, \
            "storage_bottom value should match input"
