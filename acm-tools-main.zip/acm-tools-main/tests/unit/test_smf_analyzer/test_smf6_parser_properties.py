"""Property-based tests for SMF Type 6 parser.

Feature: smf-parser-expansion
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers import SMF6ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_type6_record(
    record_length: int = 300,
    system_id: str = "SYS1",
    job_name: str = "TESTJOB",
    user_id: str = "USER1",
    sysout_class: str = "A",
    num_logical_records: int = 1000,
    num_datasets: int = 1,
    form_number: str = "STD1",
    subsystem_id: int = 0x0002,  # JES2
    section_indicator: int = 0x40  # Common section present
) -> bytes:
    """Create a synthetic Type 6 record for testing.
    
    Args:
        record_length: Total record length
        system_id: 4-character system ID
        job_name: 8-character job name
        user_id: 8-character user ID
        sysout_class: 1-character SYSOUT class
        num_logical_records: Number of logical records written
        num_datasets: Number of datasets processed
        form_number: 4-character form number
        subsystem_id: Subsystem identifier (0x0000=External, 0x0002=JES2, 0x0005=JES3, 0x0007=PSF, 0x0009=IP PrintWay)
        section_indicator: Section indicator byte
        
    Returns:
        Binary SMF Type 6 record
    """
    record = bytearray(record_length)
    
    # Standard SMF header (18 bytes)
    struct.pack_into('>H', record, 0, record_length)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 6)  # Record type = 6
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    
    # Date (packed decimal 0cyydddF) - 2025001F (Jan 1, 2025)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])
    
    # System ID (EBCDIC)
    sys_id_bytes = system_id.ljust(4).encode('cp037')[:4]
    record[14:18] = sys_id_bytes
    
    # Type 6 specific header fields (offsets 18-63)
    job_name_bytes = job_name.ljust(8).encode('cp037')[:8]
    record[18:26] = job_name_bytes
    
    struct.pack_into('>I', record, 26, 18000)  # Reader start time
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader start date
    
    user_id_bytes = user_id.ljust(8).encode('cp037')[:8]
    record[34:42] = user_id_bytes
    
    sysout_class_bytes = sysout_class.ljust(1).encode('cp037')[:1]
    record[42:43] = sysout_class_bytes
    
    struct.pack_into('>I', record, 43, 19000)  # Writer start time
    record[47:51] = bytes([0x01, 0x25, 0x00, 0x1F])  # Writer start date
    
    struct.pack_into('>I', record, 51, num_logical_records)  # Number of logical records
    struct.pack_into('B', record, 55, 0)  # I/O status
    struct.pack_into('B', record, 56, num_datasets)  # Number of datasets
    
    form_number_bytes = form_number.ljust(4).encode('cp037')[:4]
    record[57:61] = form_number_bytes
    
    struct.pack_into('B', record, 61, section_indicator)  # Section indicator
    struct.pack_into('>H', record, 62, subsystem_id)  # Subsystem ID
    
    # I/O data section (starts at offset 64)
    io_section_length = 30
    struct.pack_into('>H', record, 64, io_section_length)  # Section length
    struct.pack_into('B', record, 66, 0)  # Data control indicators
    struct.pack_into('B', record, 67, 1)  # Record level indicator
    
    job_number_bytes = "0001".encode('cp037')
    record[68:72] = job_number_bytes
    
    output_device_bytes = "PRINTER1".ljust(8).encode('cp037')[:8]
    record[72:80] = output_device_bytes
    
    fcb_image_bytes = "FCB1".ljust(4).encode('cp037')[:4]
    record[80:84] = fcb_image_bytes
    
    ucs_image_bytes = "UCS1".ljust(4).encode('cp037')[:4]
    record[84:88] = ucs_image_bytes
    
    # For JES2/JES3, add page count
    if subsystem_id in [0x0002, 0x0005]:
        struct.pack_into('>I', record, 88, 100)  # Page count
    
    # Common section (if section_indicator bit 1 is set)
    if section_indicator & 0x40:
        common_offset = 64 + io_section_length
        common_length = 38
        
        if common_offset + common_length <= record_length:
            struct.pack_into('>H', record, common_offset, common_length)  # Section length
            struct.pack_into('>I', record, common_offset + 2, 0x00010000)  # Route code
            
            form_num_bytes = form_number.ljust(8).encode('cp037')[:8]
            record[common_offset + 6:common_offset + 14] = form_num_bytes
            
            job_id_bytes = "JOB00001".ljust(8).encode('cp037')[:8]
            record[common_offset + 30:common_offset + 38] = job_id_bytes
    
    return bytes(record)


# Strategies for generating test data
ebcdic_chars = st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

system_ids = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=4
).map(lambda x: x.ljust(4)[:4])

names_8char = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=8
).map(lambda x: x.ljust(8)[:8])

names_4char = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=4
).map(lambda x: x.ljust(4)[:4])

sysout_classes = st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ')

# Subsystem IDs: 0x0000=External, 0x0002=JES2, 0x0005=JES3, 0x0007=PSF, 0x0009=IP PrintWay
subsystem_ids = st.sampled_from([0x0000, 0x0002, 0x0005, 0x0007, 0x0009])


class TestSMF6ParserProperties:
    """Property-based tests for SMF Type 6 parser."""
    
    @settings(max_examples=100)
    @given(
        system_id=system_ids,
        job_name=names_8char,
        user_id=names_8char,
        sysout_class=sysout_classes,
        num_logical_records=st.integers(min_value=0, max_value=1000000),
        num_datasets=st.integers(min_value=1, max_value=255),
        form_number=names_4char,
        subsystem_id=subsystem_ids
    )
    def test_property_1_field_extraction_completeness(
        self, system_id, job_name, user_id, sysout_class,
        num_logical_records, num_datasets, form_number, subsystem_id
    ):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.5**
        
        For any SMF Type 6 record, parsing should extract all standard header fields
        (record_type, subtype, system_id, timestamp, date, record_length) and all
        documented type-specific fields.
        """
        # Create test record
        record_data = create_type6_record(
            system_id=system_id,
            job_name=job_name,
            user_id=user_id,
            sysout_class=sysout_class,
            num_logical_records=num_logical_records,
            num_datasets=num_datasets,
            form_number=form_number,
            subsystem_id=subsystem_id
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header fields are present
        assert parsed.record_type == 6, "record_type should be 6"
        assert parsed.subtype == subsystem_id, "subtype should match subsystem_id"
        assert parsed.system_id is not None, "system_id should be extracted"
        assert parsed.timestamp is not None, "timestamp should be extracted"
        assert parsed.date is not None, "date should be extracted"
        assert parsed.record_length == 300, "record_length should match"
        
        # Verify header section contains Type 6 specific fields
        assert parsed.header is not None, "header section should be present"
        header = parsed.header
        
        assert 'job_name' in header, "job_name should be extracted"
        assert 'reader_start_time' in header, "reader_start_time should be extracted"
        assert 'reader_start_date' in header, "reader_start_date should be extracted"
        assert 'user_id' in header, "user_id should be extracted"
        assert 'sysout_class' in header, "sysout_class should be extracted"
        assert 'writer_start_time' in header, "writer_start_time should be extracted"
        assert 'writer_start_date' in header, "writer_start_date should be extracted"
        assert 'num_logical_records' in header, "num_logical_records should be extracted"
        assert 'io_status' in header, "io_status should be extracted"
        assert 'num_datasets' in header, "num_datasets should be extracted"
        assert 'form_number' in header, "form_number should be extracted"
        assert 'section_indicator' in header, "section_indicator should be extracted"
        assert 'subsystem_id' in header, "subsystem_id should be extracted"
        
        # Verify identification section is present
        assert parsed.identification is not None, "identification section should be present"
        ident = parsed.identification
        
        assert 'job_name' in ident, "job_name should be in identification"
        assert 'user_id' in ident, "user_id should be in identification"
        assert 'reader_start_time' in ident, "reader_start_time should be in identification"
        assert 'reader_start_date' in ident, "reader_start_date should be in identification"
        
        # Verify performance (writer info) section is present
        assert parsed.performance is not None, "performance section should be present"
        writer = parsed.performance
        
        assert 'sysout_class' in writer, "sysout_class should be in writer info"
        assert 'writer_start_time' in writer, "writer_start_time should be in writer info"
        assert 'writer_start_date' in writer, "writer_start_date should be in writer info"
        assert 'num_logical_records' in writer, "num_logical_records should be in writer info"
        assert 'io_status' in writer, "io_status should be in writer info"
        assert 'num_datasets' in writer, "num_datasets should be in writer info"
        assert 'form_number' in writer, "form_number should be in writer info"
        
        # Verify I/O activity section is present
        assert parsed.io_activity is not None, "io_activity section should be present"
        io_data = parsed.io_activity
        
        assert 'section_length' in io_data, "section_length should be extracted"
        assert 'data_control_indicators' in io_data, "data_control_indicators should be extracted"
        assert 'record_level_indicator' in io_data, "record_level_indicator should be extracted"
        assert 'job_number' in io_data, "job_number should be extracted"
        assert 'output_device' in io_data, "output_device should be extracted"
        assert 'fcb_image' in io_data, "fcb_image should be extracted"
        assert 'ucs_image' in io_data, "ucs_image should be extracted"
        
        # Verify extracted values match input
        assert header['job_name'].strip() == job_name.strip(), \
            "job_name value should match input"
        assert header['user_id'].strip() == user_id.strip(), \
            "user_id value should match input"
        assert header['sysout_class'].strip() == sysout_class.strip(), \
            "sysout_class value should match input"
        assert header['num_logical_records'] == num_logical_records, \
            "num_logical_records value should match input"
        assert header['num_datasets'] == num_datasets, \
            "num_datasets value should match input"
        assert header['form_number'].strip() == form_number.strip(), \
            "form_number value should match input"
        assert header['subsystem_id'] == subsystem_id, \
            "subsystem_id value should match input"
