"""Unit tests for SMF Type 19 parser."""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers import SMF19ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type19_record() -> bytes:
    """Create a valid Type 19 record with expanded statistics."""
    record = bytearray(144)  # Full record with expanded stats
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 144)  # SMF19LEN
    struct.pack_into('>H', record, 2, 0)  # SMF19SEG
    struct.pack_into('B', record, 4, 0x01)  # SMF19FLG
    struct.pack_into('B', record, 5, 19)  # SMF19RTY - Record type = 19
    struct.pack_into('>I', record, 6, 36000)  # SMF19TME
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF19DTE
    
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id  # SMF19SID
    
    # Volume identification
    vol_serial = "DASD01".encode('cp037')
    record[20:26] = vol_serial  # SMF19VOL
    owner_id = "OWNER12345".encode('cp037')
    record[26:36] = owner_id  # SMF19OID
    struct.pack_into('>I', record, 36, 0x3390)  # SMF19DEV - Device type
    
    # VTOC address (CCHHR format)
    record[40:45] = bytes([0x00, 0x00, 0x00, 0x01, 0x00])  # SMF19VTC
    struct.pack_into('B', record, 45, 0x01)  # SMF19VTI - Indexed VTOC
    
    # Free space statistics
    struct.pack_into('>H', record, 46, 1000)  # SMF19NDS - Total DSCBs
    struct.pack_into('>H', record, 48, 500)  # SMF19DSR - Available DSCBs
    struct.pack_into('>H', record, 50, 10)  # SMF19NAT - Unused alternate tracks
    struct.pack_into('>H', record, 52, 100)  # SMF19SPC - Unallocated cylinders
    struct.pack_into('>H', record, 54, 5)  # Unallocated tracks
    struct.pack_into('>H', record, 56, 50)  # SMF19LEX - Largest extent cylinders
    struct.pack_into('>H', record, 58, 0)  # Largest extent tracks
    struct.pack_into('>H', record, 60, 25)  # SMF19NUE - Unallocated extents
    
    # Flags
    struct.pack_into('B', record, 62, 0x80)  # SMF19FL1 - CYL-managed
    struct.pack_into('B', record, 63, 0x00)  # SMF19FL2
    
    # Device information
    struct.pack_into('>H', record, 64, 0x0100)  # SMF19CUU - Device number
    struct.pack_into('>H', record, 66, 0x0001)  # SMF19IND - Module ID
    
    # Expanded statistics
    struct.pack_into('>I', record, 72, 1000)  # SMF19SDS - Total DSCBs
    struct.pack_into('>I', record, 76, 500)  # SMF19SL0 - Format 0 DSCBs
    struct.pack_into('B', record, 80, 50)  # SMF19PUV - VTOC used %
    struct.pack_into('B', record, 81, 30)  # SMF19PUI - INDEX used %
    
    # Total volume free space
    struct.pack_into('>I', record, 84, 100)  # SMF19SUC - Free cylinders
    struct.pack_into('>I', record, 88, 5)  # SMF19SUT - Free tracks
    struct.pack_into('>I', record, 92, 50)  # SMF19SNC - Largest extent cyls
    struct.pack_into('>I', record, 96, 0)  # SMF19SNT - Largest extent tracks
    struct.pack_into('>I', record, 100, 25)  # SMF19SNE - Free extents
    
    # Track-managed free space
    struct.pack_into('>I', record, 104, 50)  # SMF19BUC
    struct.pack_into('>I', record, 108, 3)  # SMF19BUT
    struct.pack_into('>I', record, 112, 25)  # SMF19BNC
    struct.pack_into('>I', record, 116, 0)  # SMF19BNT
    struct.pack_into('>I', record, 120, 15)  # SMF19BNE
    
    # Volume size information
    struct.pack_into('>I', record, 124, 10000)  # SMF19TRK - Total tracks
    struct.pack_into('>I', record, 128, 5000)  # SMF19TRM - Track-managed tracks
    struct.pack_into('>I', record, 132, 100)  # SMF19DCT - VTOC size
    
    # VTOC/INDEX information
    struct.pack_into('>I', record, 136, 100)  # SMF19VTS - VTOC tracks
    struct.pack_into('>I', record, 140, 50)  # SMF19IXS - INDEX tracks
    
    return bytes(record)


class TestSMF19Parser:
    """Test suite for SMF Type 19 parser."""
    
    def test_parse_record(self):
        """Test parsing a Type 19 record."""
        record_data = create_type19_record()
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF19ParserV3R2(base_parser)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 19
        assert result.system_id == "SYS1"
        
        volume_info = result.storage['volume_info']
        assert volume_info['volume_serial'] == "DASD01"
        assert volume_info['owner_id'] == "OWNER12345"
        assert volume_info['device_type'] == 0x3390
        
        vtoc_info = result.storage['vtoc_info']
        assert vtoc_info['indexed_vtoc']
        
        free_space = result.storage['free_space']
        assert free_space['total_dscbs'] == 1000
        assert free_space['available_dscbs'] == 500
        assert free_space['is_cyl_managed']
        
        expanded = result.storage['expanded_stats']
        assert expanded['present']
        assert expanded['total_tracks'] == 10000
        assert expanded['vtoc_used_percent'] == 50
    
    def test_parse_invalid_record_type(self):
        """Test that parser rejects wrong record type."""
        record_data = bytearray(create_type19_record())
        record_data[5] = 18
        
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF19ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(record_data))
