"""Unit tests for SMF Type 5 parser."""

import pytest
import struct
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF5ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type5_record_minimal() -> bytes:
    """Create a minimal valid Type 5 record (200 bytes)."""
    record = bytearray(200)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 200)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 5)  # Record type = 5
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Job identification
    job_name = "TESTJOB ".encode('cp037')
    record[18:26] = job_name
    struct.pack_into('>I', record, 26, 18000)  # Reader start time
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader start date
    
    user_id = "USER1   ".encode('cp037')
    record[34:42] = user_id
    
    # Job statistics
    struct.pack_into('B', record, 42, 1)  # Number of steps
    struct.pack_into('>I', record, 43, 19000)  # Initiator select time
    record[47:51] = bytes([0x01, 0x25, 0x00, 0x1F])  # Initiator select date
    struct.pack_into('>I', record, 51, 100)  # Card image count
    struct.pack_into('>H', record, 55, 0)  # Job completion code (normal)
    struct.pack_into('B', record, 57, 10)  # Job priority
    struct.pack_into('>I', record, 58, 20000)  # Reader end time
    record[62:66] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader end date
    
    # Job termination indicator
    struct.pack_into('B', record, 66, 0)  # Normal termination
    struct.pack_into('B', record, 67, 0)  # Reserved
    
    # Transaction and timing data
    struct.pack_into('>I', record, 68, 1000)  # Transaction residency time
    struct.pack_into('B', record, 73, 1)  # Reader device class
    struct.pack_into('B', record, 74, 1)  # Reader unit type
    
    job_input_class = "A".encode('cp037')
    record[75:76] = job_input_class
    
    struct.pack_into('B', record, 76, 8)  # Storage protect key
    
    # SRB CPU time (3 bytes)
    srb_time = 100
    record[77] = (srb_time >> 16) & 0xFF
    record[78] = (srb_time >> 8) & 0xFF
    record[79] = srb_time & 0xFF
    
    struct.pack_into('>I', record, 80, 5000)  # Job service
    struct.pack_into('>I', record, 84, 2000)  # Transaction active time
    struct.pack_into('>H', record, 92, 1)  # Performance group
    
    # Fixed portion length and programmer name
    struct.pack_into('B', record, 96, 21)  # Fixed length
    
    programmer_name = "PROGRAMMER          ".encode('cp037')
    record[97:117] = programmer_name
    
    # Accounting section
    struct.pack_into('B', record, 120, 0)  # Number of accounting fields = 0
    
    return bytes(record)


def create_type5_record_with_abend() -> bytes:
    """Create a Type 5 record with ABEND."""
    record = bytearray(create_type5_record_minimal())
    
    # Set completion code to system ABEND 0C4
    struct.pack_into('>H', record, 55, 0x00C4)
    
    # Set ABEND bit in job termination indicator
    record[66] = 0x02  # Bit 6 = ABEND
    
    return bytes(record)


def create_type5_record_with_accounting() -> bytes:
    """Create a Type 5 record with accounting fields."""
    # Start with minimal record
    base_record = bytearray(create_type5_record_minimal())
    
    # Extend record to accommodate accounting fields
    record = bytearray(250)
    record[:200] = base_record
    
    # Update record length
    struct.pack_into('>H', record, 0, 250)
    
    # Add accounting fields at offset 120
    struct.pack_into('B', record, 120, 3)  # 3 accounting fields
    
    # Field 1: "ACCT1" (5 bytes)
    struct.pack_into('B', record, 121, 5)  # Length
    acct1 = "ACCT1".encode('cp037')
    record[122:127] = acct1
    
    # Field 2: Omitted (0 length)
    struct.pack_into('B', record, 127, 0)  # Length = 0 (omitted)
    
    # Field 3: "ACCT3" (5 bytes)
    struct.pack_into('B', record, 128, 5)  # Length
    acct3 = "ACCT3".encode('cp037')
    record[129:134] = acct3
    
    return bytes(record)


class TestSMF5ParserV3R2:
    """Unit tests for SMF Type 5 parser."""
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal valid Type 5 record."""
        record_data = create_type5_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header
        assert parsed.record_type == 5
        assert parsed.subtype == 0
        assert parsed.record_length == 200
        assert parsed.system_id == "SYS1"
        assert parsed.date is not None
        
        # Verify identification section
        assert parsed.identification is not None
        assert parsed.identification['job_name'].strip() == "TESTJOB"
        assert parsed.identification['user_id'].strip() == "USER1"
        
        # Verify performance section
        assert parsed.performance is not None
        assert parsed.performance['num_steps'] == 1
        assert parsed.performance['job_completion_code'] == 0
        assert parsed.performance['job_priority'] == 10
        assert parsed.performance['programmer_name'].strip() == "PROGRAMMER"
        assert parsed.performance['abend'] is False
        
        # Verify accounting section
        assert parsed.accounting is not None
        assert parsed.accounting['num_fields'] == 0
    
    def test_parse_record_with_abend(self):
        """Test parsing a Type 5 record with ABEND."""
        record_data = create_type5_record_with_abend()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify ABEND indicators
        assert parsed.performance['job_completion_code'] == 0x00C4
        assert parsed.performance['abend'] is True
        assert parsed.performance['job_termination_indicator'] == 0x02
    
    def test_parse_record_with_accounting_fields(self):
        """Test parsing a Type 5 record with accounting fields."""
        record_data = create_type5_record_with_accounting()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify accounting section
        assert parsed.accounting is not None
        assert parsed.accounting['num_fields'] == 3
        assert parsed.accounting['fields'] is not None
        assert len(parsed.accounting['fields']) == 3
        assert parsed.accounting['fields'][0] == "ACCT1"
        assert parsed.accounting['fields'][1] is None  # Omitted field
        assert parsed.accounting['fields'][2] == "ACCT3"
    
    def test_parse_record_with_cancellation_flags(self):
        """Test parsing a Type 5 record with cancellation flags."""
        record_data = bytearray(create_type5_record_minimal())
        
        # Set cancellation flags
        record_data[66] = 0x40 | 0x20 | 0x10  # Canceled by IEFUJV, IEFUJI, IEFUSI
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(bytes(record_data))
        
        # Verify cancellation flags
        assert parsed.performance['canceled_by_iefujv'] is True
        assert parsed.performance['canceled_by_iefuji'] is True
        assert parsed.performance['canceled_by_iefusi'] is True
        assert parsed.performance['canceled_by_iefactrt'] is False
    
    def test_invalid_record_length(self):
        """Test error handling for invalid record length."""
        record_data = bytearray(10)  # Too short
        struct.pack_into('>H', record_data, 0, 10)
        struct.pack_into('B', record_data, 5, 5)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(record_data))
    
    def test_wrong_record_type(self):
        """Test error handling for wrong record type."""
        record_data = bytearray(create_type5_record_minimal())
        record_data[5] = 4  # Change to Type 4
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(record_data))
    
    def test_edge_case_max_steps(self):
        """Test parsing with maximum number of steps."""
        record_data = bytearray(create_type5_record_minimal())
        struct.pack_into('B', record_data, 42, 255)  # Max steps
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(bytes(record_data))
        
        assert parsed.performance['num_steps'] == 255
    
    def test_edge_case_max_priority(self):
        """Test parsing with maximum priority."""
        record_data = bytearray(create_type5_record_minimal())
        struct.pack_into('B', record_data, 57, 13)  # Max priority
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(bytes(record_data))
        
        assert parsed.performance['job_priority'] == 13
    
    def test_edge_case_user_abend(self):
        """Test parsing with user ABEND code."""
        record_data = bytearray(create_type5_record_minimal())
        struct.pack_into('>H', record_data, 55, 0x8FFF)  # User ABEND 0xFFF
        record_data[66] = 0x02  # Set ABEND bit
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF5ParserV3R2(base_parser)
        parsed = parser.parse(bytes(record_data))
        
        assert parsed.performance['job_completion_code'] == 0x8FFF
        assert parsed.performance['abend'] is True
