"""Unit tests for SMF Type 7 parser."""

import pytest
import struct
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF7ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type7_record_minimal() -> bytes:
    """Create a minimal valid Type 7 record (72 bytes).
    
    This represents a basic data loss event with no special flags.
    """
    record = bytearray(72)
    
    # Standard SMF header (offsets 0-17)
    struct.pack_into('>H', record, 0, 72)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 7)  # Record type = 7
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Type 7 specific fields
    struct.pack_into('>H', record, 18, 100)  # Number of records lost
    struct.pack_into('>I', record, 20, 18000)  # Start time (05:00:00.00)
    record[24:28] = bytes([0x01, 0x25, 0x00, 0x1F])  # Start date (2025-001)
    
    struct.pack_into('B', record, 28, 0x00)  # Flag byte (no flags set)
    struct.pack_into('B', record, 29, 0x00)  # Reserved
    struct.pack_into('B', record, 30, 0x00)  # Reserved
    struct.pack_into('B', record, 31, 0)  # Dropped record type
    
    struct.pack_into('>I', record, 32, 100)  # Extended number of records lost
    
    # Log stream name (26 bytes, empty)
    record[36:62] = b' ' * 26
    
    struct.pack_into('>Q', record, 62, 0)  # Bytes lost during init
    struct.pack_into('>H', record, 70, 0)  # Extended dropped record type
    
    return bytes(record)


def create_type7_record_overflow() -> bytes:
    """Create a Type 7 record with overflow flag set.
    
    This indicates that the 2-byte record count exceeded 65535.
    """
    record = bytearray(create_type7_record_minimal())
    
    # Set overflow flag (bit 0 of flag byte)
    struct.pack_into('B', record, 28, 0x80)  # SMF7NRF flag
    
    # Set extended count to a large value
    struct.pack_into('>I', record, 32, 100000)
    
    return bytes(record)


def create_type7_record_log_stream_full() -> bytes:
    """Create a Type 7 record for log stream full condition.
    
    This indicates data loss due to log stream becoming full.
    """
    record = bytearray(create_type7_record_minimal())
    
    # Set log stream full flag (bit 1 of flag byte)
    struct.pack_into('B', record, 28, 0x40)  # SMF7LSD flag
    
    # Set log stream name (EBCDIC)
    log_stream_name = "IFASMF.LOGSTREAM.NAME     ".encode('cp037')
    record[36:62] = log_stream_name[:26]
    
    return bytes(record)


def create_type7_record_flood_policy() -> bytes:
    """Create a Type 7 record for flood policy dropping records.
    
    This indicates data loss due to SMF record flood policy.
    """
    record = bytearray(create_type7_record_minimal())
    
    # Set flood policy flag (bit 2 of flag byte)
    struct.pack_into('B', record, 28, 0x20)  # SMF7DRP flag
    
    # Set dropped record type
    struct.pack_into('B', record, 31, 30)  # Type 30 records dropped
    struct.pack_into('>H', record, 70, 30)  # Extended dropped record type
    
    return bytes(record)


def create_type7_record_extended_type() -> bytes:
    """Create a Type 7 record with extended record type (>255).
    
    This tests the extended record type field for types 0-2047.
    """
    record = bytearray(create_type7_record_minimal())
    
    # Set flood policy flag
    struct.pack_into('B', record, 28, 0x20)  # SMF7DRP flag
    
    # Set dropped record type to extended indicator
    struct.pack_into('B', record, 31, 126)  # Extended type indicator
    struct.pack_into('>H', record, 70, 512)  # Actual extended type
    
    return bytes(record)


def create_type7_record_init_loss() -> bytes:
    """Create a Type 7 record with initialization data loss.
    
    This indicates bytes lost during SMF initialization.
    """
    record = bytearray(create_type7_record_minimal())
    
    # Set bytes lost during initialization
    struct.pack_into('>Q', record, 62, 1048576)  # 1 MB lost
    
    return bytes(record)


def create_type7_record_invalid_type() -> bytes:
    """Create a record with wrong record type."""
    record = bytearray(create_type7_record_minimal())
    struct.pack_into('B', record, 5, 6)  # Wrong type (6 instead of 7)
    return bytes(record)


def create_type7_record_truncated() -> bytes:
    """Create a truncated Type 7 record."""
    record = create_type7_record_minimal()
    return record[:30]  # Truncate to 30 bytes


class TestSMF7ParserV3R2:
    """Unit tests for SMF Type 7 parser."""
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal valid Type 7 record."""
        record_data = create_type7_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header
        assert parsed.record_type == 7
        assert parsed.subtype == 0  # Type 7 has no subtypes
        assert parsed.record_length == 72
        assert parsed.system_id == "SYS1"
        assert parsed.date is not None
        
        # Verify data loss information
        assert parsed.performance is not None
        assert parsed.performance['num_records_lost'] == 100
        assert parsed.performance['num_records_lost_extended'] == 100
        assert parsed.performance['start_time'] is not None
        assert parsed.performance['start_date'] is not None
        assert parsed.performance['flag_byte'] == 0x00
        assert parsed.performance['num_records_overflow'] is False
        assert parsed.performance['log_stream_full'] is False
        assert parsed.performance['flood_policy_active'] is False
    
    def test_parse_overflow_flag(self):
        """Test parsing Type 7 record with overflow flag."""
        record_data = create_type7_record_overflow()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify overflow flag is set
        assert parsed.performance['num_records_overflow'] is True
        assert parsed.performance['flag_byte'] & 0x80 == 0x80
        
        # When overflow flag is set, use extended count
        assert parsed.performance['num_records_lost_extended'] == 100000
    
    def test_parse_log_stream_full(self):
        """Test parsing Type 7 record for log stream full."""
        record_data = create_type7_record_log_stream_full()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify log stream full flag is set
        assert parsed.performance['log_stream_full'] is True
        assert parsed.performance['flag_byte'] & 0x40 == 0x40
        
        # Verify log stream name is present
        assert 'log_stream_name' in parsed.performance
        assert parsed.performance['log_stream_name'].strip().startswith("IFASMF")
    
    def test_parse_flood_policy(self):
        """Test parsing Type 7 record for flood policy."""
        record_data = create_type7_record_flood_policy()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify flood policy flag is set
        assert parsed.performance['flood_policy_active'] is True
        assert parsed.performance['flag_byte'] & 0x20 == 0x20
        
        # Verify dropped record type is present
        assert parsed.performance['dropped_record_type'] == 30
        assert parsed.performance['dropped_record_type_extended'] == 30
    
    def test_parse_extended_record_type(self):
        """Test parsing Type 7 record with extended record type."""
        record_data = create_type7_record_extended_type()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify extended record type
        assert parsed.performance['dropped_record_type'] == 126  # Extended indicator
        assert parsed.performance['dropped_record_type_extended'] == 512  # Actual type
    
    def test_parse_init_loss(self):
        """Test parsing Type 7 record with initialization data loss."""
        record_data = create_type7_record_init_loss()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify bytes lost during initialization
        assert parsed.performance['bytes_lost_init'] == 1048576
    
    def test_parse_invalid_record_type(self):
        """Test error handling for invalid record type."""
        record_data = create_type7_record_invalid_type()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "expected 7" in str(exc_info.value)
    
    def test_parse_truncated_record(self):
        """Test error handling for truncated record."""
        record_data = create_type7_record_truncated()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "Record length mismatch" in str(exc_info.value)
    
    def test_header_fields_extraction(self):
        """Test that all header fields are correctly extracted."""
        record_data = create_type7_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify all header fields are present
        header = parsed.header
        assert 'record_length' in header
        assert 'segment_descriptor' in header
        assert 'system_indicator' in header
        assert 'record_type' in header
        assert 'timestamp' in header
        assert 'date' in header
        assert 'system_id' in header
    
    def test_data_loss_fields_extraction(self):
        """Test that all data loss fields are correctly extracted."""
        record_data = create_type7_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify all data loss fields are present
        data_loss = parsed.performance
        assert 'num_records_lost' in data_loss
        assert 'start_time' in data_loss
        assert 'start_date' in data_loss
        assert 'flag_byte' in data_loss
        assert 'num_records_overflow' in data_loss
        assert 'log_stream_full' in data_loss
        assert 'flood_policy_active' in data_loss
        assert 'dropped_record_type' in data_loss
        assert 'num_records_lost_extended' in data_loss
    
    def test_to_dict_conversion(self):
        """Test conversion of parsed record to dictionary."""
        record_data = create_type7_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Convert to dictionary
        record_dict = parsed.to_dict()
        
        # Verify dictionary structure
        assert isinstance(record_dict, dict)
        assert record_dict['record_type'] == 7
        assert record_dict['subtype'] == 0
        assert 'header' in record_dict
        assert 'performance' in record_dict
    
    def test_multiple_flags_set(self):
        """Test parsing Type 7 record with multiple flags set."""
        record = bytearray(create_type7_record_minimal())
        
        # Set multiple flags: overflow + log stream full
        struct.pack_into('B', record, 28, 0x80 | 0x40)  # SMF7NRF + SMF7LSD
        
        # Set log stream name
        log_stream_name = "TEST.LOGSTREAM            ".encode('cp037')
        record[36:62] = log_stream_name[:26]
        
        # Set extended count
        struct.pack_into('>I', record, 32, 200000)
        
        record_data = bytes(record)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF7ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify both flags are set
        assert parsed.performance['num_records_overflow'] is True
        assert parsed.performance['log_stream_full'] is True
        assert parsed.performance['flood_policy_active'] is False
        
        # Verify both flag-specific fields are present
        assert parsed.performance['num_records_lost_extended'] == 200000
        assert 'log_stream_name' in parsed.performance

