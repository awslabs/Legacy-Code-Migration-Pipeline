"""Property-based tests for SMF Type 11 parser.

Feature: smf-parser-expansion
"""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers import SMF11ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.models.data_models import ParsedRecord


def create_type11_record(
    system_id: str = "SYS1",
    num_devices: int = 3,
    device_classes: list = None,
    unit_types: list = None,
    device_numbers: list = None,
    vary_issuers: list = None
) -> bytes:
    """Create a synthetic Type 11 record for testing.
    
    Args:
        system_id: 4-character system ID
        num_devices: Number of devices to include
        device_classes: List of device classes (0-255)
        unit_types: List of unit types (0-255)
        device_numbers: List of device numbers (0-65535)
        vary_issuers: List of vary issuer codes (0=Operator, 2=ESCM)
        
    Returns:
        Binary SMF Type 11 record
    """
    # Calculate record length: header (20 bytes) + devices (8 bytes each)
    record_length = 20 + (num_devices * 8)
    record = bytearray(record_length)
    
    # Standard SMF header (18 bytes)
    struct.pack_into('>H', record, 0, record_length)  # SMF11LEN - Record length
    struct.pack_into('>H', record, 2, 0)  # SMF11SEG - Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # SMF11FLG - System indicator
    struct.pack_into('B', record, 5, 11)  # SMF11RTY - Record type = 11
    struct.pack_into('>I', record, 6, 36000)  # SMF11TME - Timestamp (10:00:00.00)
    
    # Date (packed decimal 0cyydddF) - 2025001F (Jan 1, 2025)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # SMF11DTE
    
    # System ID (EBCDIC)
    sys_id_bytes = system_id.ljust(4).encode('cp037')[:4]
    record[14:18] = sys_id_bytes  # SMF11SID
    
    # Length of rest of record (including this field)
    rest_length = 2 + (num_devices * 8)
    struct.pack_into('>H', record, 18, rest_length)  # SMF11LN
    
    # Device data section (starts at offset 20)
    # Each device is 8 bytes: 2 bytes device type, 2 bytes device number, 1 byte issuer, 3 bytes reserved
    for i in range(num_devices):
        offset = 20 + (i * 8)
        
        # Get device class and unit type
        device_class = device_classes[i] if device_classes and i < len(device_classes) else (i % 256)
        unit_type = unit_types[i] if unit_types and i < len(unit_types) else ((i * 10) % 256)
        device_number = device_numbers[i] if device_numbers and i < len(device_numbers) else (i + 100)
        vary_issuer = vary_issuers[i] if vary_issuers and i < len(vary_issuers) else 0
        
        # Pack device class and unit type into 2 bytes (SMF11DUT)
        device_type_raw = (device_class << 8) | unit_type
        struct.pack_into('>H', record, offset, device_type_raw)
        
        # Pack device number (SMF11CUA)
        struct.pack_into('>H', record, offset + 2, device_number)
        
        # Pack vary issuer (SMF11VPC)
        struct.pack_into('B', record, offset + 4, vary_issuer)
        
        # Reserved bytes (SMF11RSV) - already zero from bytearray initialization
    
    return bytes(record)


# Strategies for generating test data
ebcdic_chars = st.sampled_from('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

system_ids = st.text(
    alphabet=ebcdic_chars,
    min_size=1,
    max_size=4
).map(lambda x: x.ljust(4)[:4])

# Generate device counts (1-50 devices is reasonable for testing)
device_counts = st.integers(min_value=1, max_value=50)

# Generate device classes, unit types, and device numbers
device_classes_list = st.lists(
    st.integers(min_value=0, max_value=255),
    min_size=1,
    max_size=50
)

unit_types_list = st.lists(
    st.integers(min_value=0, max_value=255),
    min_size=1,
    max_size=50
)

device_numbers_list = st.lists(
    st.integers(min_value=0, max_value=65535),
    min_size=1,
    max_size=50
)

# Vary issuer codes: 0 (Operator) or 2 (ESCM)
vary_issuers_list = st.lists(
    st.sampled_from([0, 2]),
    min_size=1,
    max_size=50
)


class TestSMF11ParserProperties:
    """Property-based tests for SMF Type 11 parser."""
    
    @settings(max_examples=100)
    @given(
        system_id=system_ids,
        num_devices=device_counts,
        device_classes=device_classes_list,
        unit_types=unit_types_list,
        device_numbers=device_numbers_list,
        vary_issuers=vary_issuers_list
    )
    def test_property_1_field_extraction_completeness(
        self, system_id, num_devices, device_classes, unit_types, device_numbers, vary_issuers
    ):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.10**
        
        For any SMF Type 11 record, parsing should extract all standard header fields
        (record_type, subtype, system_id, timestamp, date, record_length) and all
        documented type-specific fields including device data with vary issuer information.
        """
        # Ensure lists are long enough
        device_classes = device_classes[:num_devices] + [0] * max(0, num_devices - len(device_classes))
        unit_types = unit_types[:num_devices] + [0] * max(0, num_devices - len(unit_types))
        device_numbers = device_numbers[:num_devices] + [100] * max(0, num_devices - len(device_numbers))
        vary_issuers = vary_issuers[:num_devices] + [0] * max(0, num_devices - len(vary_issuers))
        
        # Create test record
        record_data = create_type11_record(
            system_id=system_id,
            num_devices=num_devices,
            device_classes=device_classes,
            unit_types=unit_types,
            device_numbers=device_numbers,
            vary_issuers=vary_issuers
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF11ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header fields are present
        assert parsed.record_type == 11, "record_type should be 11"
        assert parsed.subtype == 0, "subtype should be 0 (Type 11 has no subtypes)"
        assert parsed.system_id is not None, "system_id should be extracted"
        assert parsed.timestamp is not None, "timestamp should be extracted"
        assert parsed.date is not None, "date should be extracted"
        assert parsed.record_length == 20 + (num_devices * 8), "record_length should match"
        
        # Verify header section contains Type 11 specific fields
        assert parsed.header is not None, "header section should be present"
        header = parsed.header
        
        assert 'record_length' in header, "record_length should be extracted"
        assert 'segment_descriptor' in header, "segment_descriptor should be extracted"
        assert 'system_indicator' in header, "system_indicator should be extracted"
        assert 'record_type' in header, "record_type should be extracted"
        assert 'timestamp' in header, "timestamp should be extracted"
        assert 'date' in header, "date should be extracted"
        assert 'system_id' in header, "system_id should be extracted"
        assert 'rest_of_record_length' in header, "rest_of_record_length should be extracted"
        
        # Verify I/O activity section contains device data
        assert parsed.io_activity is not None, "io_activity section should be present"
        io_data = parsed.io_activity
        
        assert 'devices' in io_data, "devices list should be present"
        assert 'device_count' in io_data, "device_count should be present"
        
        devices = io_data['devices']
        assert len(devices) == num_devices, f"should have {num_devices} devices"
        
        # Verify each device has required fields
        for i, device in enumerate(devices):
            assert 'device_class' in device, f"device {i} should have device_class"
            assert 'unit_type' in device, f"device {i} should have unit_type"
            assert 'device_number' in device, f"device {i} should have device_number"
            assert 'device_number_hex' in device, f"device {i} should have device_number_hex"
            assert 'vary_issuer_code' in device, f"device {i} should have vary_issuer_code"
            assert 'vary_issuer' in device, f"device {i} should have vary_issuer description"
            assert 'is_virtual_io' in device, f"device {i} should have is_virtual_io flag"
            
            # Verify values match input
            assert device['device_class'] == device_classes[i], \
                f"device {i} class should match input"
            assert device['unit_type'] == unit_types[i], \
                f"device {i} unit_type should match input"
            assert device['device_number'] == device_numbers[i], \
                f"device {i} device_number should match input"
            assert device['vary_issuer_code'] == vary_issuers[i], \
                f"device {i} vary_issuer_code should match input"
            
            # Verify hex format
            expected_hex = f"0x{device_numbers[i]:04X}"
            assert device['device_number_hex'] == expected_hex, \
                f"device {i} hex format should be correct"
            
            # Verify vary issuer description
            if vary_issuers[i] == 0:
                assert device['vary_issuer'] == 'Operator', \
                    f"device {i} vary_issuer should be 'Operator' for code 0"
            elif vary_issuers[i] == 2:
                assert device['vary_issuer'] == 'Enterprise Systems Connection Manager (5688-008)', \
                    f"device {i} vary_issuer should be 'ESCM' for code 2"
            
            # Verify VIO detection
            is_vio = (device_classes[i] == 0 and unit_types[i] == 0 and device_numbers[i] == 0x7FFF)
            assert device['is_virtual_io'] == is_vio, \
                f"device {i} VIO detection should be correct"
    
    @settings(max_examples=50)
    @given(system_id=system_ids)
    def test_property_1_virtual_io_detection(self, system_id):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.10**
        
        For any SMF Type 11 record containing Virtual I/O devices (device class=0,
        unit type=0, device number=0x7FFF), the parser should correctly identify
        them with the is_virtual_io flag.
        """
        # Create a record with one VIO device and one regular device
        num_devices = 2
        device_classes = [0, 5]  # VIO, then regular
        unit_types = [0, 10]  # VIO, then regular
        device_numbers = [0x7FFF, 0x0100]  # VIO marker, then regular
        vary_issuers = [0, 2]  # Operator, then ESCM
        
        record_data = create_type11_record(
            system_id=system_id,
            num_devices=num_devices,
            device_classes=device_classes,
            unit_types=unit_types,
            device_numbers=device_numbers,
            vary_issuers=vary_issuers
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF11ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify device data
        devices = parsed.io_activity['devices']
        assert len(devices) == 2, "should have 2 devices"
        
        # First device should be VIO
        assert devices[0]['is_virtual_io'] is True, "first device should be VIO"
        assert devices[0]['device_class'] == 0, "VIO device class should be 0"
        assert devices[0]['unit_type'] == 0, "VIO unit type should be 0"
        assert devices[0]['device_number'] == 0x7FFF, "VIO device number should be 0x7FFF"
        assert devices[0]['vary_issuer_code'] == 0, "VIO vary issuer should be 0"
        assert devices[0]['vary_issuer'] == 'Operator', "VIO vary issuer should be 'Operator'"
        
        # Second device should not be VIO
        assert devices[1]['is_virtual_io'] is False, "second device should not be VIO"
        assert devices[1]['device_class'] == 5, "regular device class should match"
        assert devices[1]['unit_type'] == 10, "regular unit type should match"
        assert devices[1]['device_number'] == 0x0100, "regular device number should match"
        assert devices[1]['vary_issuer_code'] == 2, "regular vary issuer should be 2"
        assert devices[1]['vary_issuer'] == 'Enterprise Systems Connection Manager (5688-008)', \
            "regular vary issuer should be 'ESCM'"
    
    @settings(max_examples=50)
    @given(
        system_id=system_ids,
        num_devices=st.integers(min_value=1, max_value=10)
    )
    def test_property_1_vary_issuer_mapping(self, system_id, num_devices):
        """
        **Feature: smf-parser-expansion, Property 1: Field Extraction Completeness**
        **Validates: Requirements 1.10**
        
        For any SMF Type 11 record, the parser should correctly map vary issuer codes
        to their descriptions (0=Operator, 2=ESCM).
        """
        # Create devices with known vary issuer codes
        device_classes = [i % 256 for i in range(num_devices)]
        unit_types = [(i * 10) % 256 for i in range(num_devices)]
        device_numbers = [100 + i for i in range(num_devices)]
        vary_issuers = [0 if i % 2 == 0 else 2 for i in range(num_devices)]
        
        record_data = create_type11_record(
            system_id=system_id,
            num_devices=num_devices,
            device_classes=device_classes,
            unit_types=unit_types,
            device_numbers=device_numbers,
            vary_issuers=vary_issuers
        )
        
        # Parse the record
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF11ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify vary issuer mapping for each device
        devices = parsed.io_activity['devices']
        for i, device in enumerate(devices):
            if vary_issuers[i] == 0:
                assert device['vary_issuer'] == 'Operator', \
                    f"device {i} with code 0 should map to 'Operator'"
            elif vary_issuers[i] == 2:
                assert device['vary_issuer'] == 'Enterprise Systems Connection Manager (5688-008)', \
                    f"device {i} with code 2 should map to 'ESCM'"
