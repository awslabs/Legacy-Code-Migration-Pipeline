"""Integration test for SMF Type 2 parser with real data."""

import pytest
from datetime import date
from pathlib import Path
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory


class TestSMF2RealData:
    """Test SMF Type 2 parser with real data from SMF30_1.Dat."""
    
    @pytest.fixture
    def smf_file_path(self):
        """Return path to the SMF data file."""
        return Path("examples/SMF30_1.Dat")
    
    def test_parse_real_smf2_record(self, smf_file_path):
        """Test parsing real SMF Type 2 record from SMF30_1.Dat."""
        # Skip if file doesn't exist
        if not smf_file_path.exists():
            pytest.skip(f"Test data file not found: {smf_file_path}")
        
        # Read the first record (Type 2 dump header)
        with open(smf_file_path, 'rb') as f:
            # Read record length
            length_bytes = f.read(2)
            record_length = int.from_bytes(length_bytes, byteorder='big')
            
            # Read rest of record
            remaining = f.read(record_length - 2)
            record_data = length_bytes + remaining
        
        # Create parser
        parser = SMFParserFactory.create_parser(2, "V3R2", encoding="EBCDIC")
        
        # Parse the record
        result = parser.parse(record_data, "V3R2")
        
        # Verify it's a Type 2 record
        assert result.record_type == 2
        
        # Verify basic structure
        assert result.record_length == 18
        assert result.subtype == 0  # Standard header only
        
        # Verify system ID is present and non-empty
        assert result.system_id
        assert len(result.system_id) > 0
        
        # Verify date and timestamp are valid
        assert isinstance(result.date, date)
        assert isinstance(result.timestamp, str)
        
        # Verify header structure
        assert result.header is not None
        assert 'record_length' in result.header
        assert 'record_type' in result.header
        assert 'system_id' in result.header
        assert 'subtypes_supported' in result.header
        
        # For standard header, subtypes should not be supported
        assert result.header['subtypes_supported'] is False
        
        # Subsystem should be None for standard header
        assert result.subsystem is None
        
        # Verify JSON conversion works
        json_output = result.to_json()
        assert json_output is not None
        assert len(json_output) > 0
        assert '"record_type": 2' in json_output
        
        # Verify dict conversion works
        dict_output = result.to_dict()
        assert dict_output is not None
        assert dict_output['record_type'] == 2
        assert dict_output['subtype'] == 0
    
    def test_factory_lists_type2_parser(self):
        """Test that factory lists Type 2 parser as available."""
        available = SMFParserFactory.list_available_parsers()
        
        # Type 2 should be in the list
        assert 2 in available
        
        # V3R2 should be a supported version
        assert "V3R2" in available[2]
    
    def test_create_type2_parser_via_factory(self):
        """Test creating Type 2 parser through factory."""
        # Should not raise any exceptions
        parser = SMFParserFactory.create_parser(2, "V3R2", encoding="EBCDIC")
        
        # Verify parser is created
        assert parser is not None
        assert parser.record_type == 2
        
        # Verify strategy is registered
        assert "V3R2" in parser.version_strategies
