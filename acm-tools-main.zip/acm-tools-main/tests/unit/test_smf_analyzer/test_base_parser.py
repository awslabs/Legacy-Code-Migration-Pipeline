"""Unit tests for BaseRecordParser."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError, EncodingError


class TestBaseRecordParser:
    """Test suite for BaseRecordParser class."""
    
    def test_read_binary_1_byte(self):
        """Test reading 1-byte binary integer."""
        parser = BaseRecordParser()
        data = b'\x00\x42\xFF'
        
        assert parser.read_binary(data, 0, 1) == 0
        assert parser.read_binary(data, 1, 1) == 66
        assert parser.read_binary(data, 2, 1) == 255
    
    def test_read_binary_2_bytes(self):
        """Test reading 2-byte binary integer."""
        parser = BaseRecordParser()
        data = b'\x00\x00\x01\x00\xFF\xFF'
        
        assert parser.read_binary(data, 0, 2) == 0
        assert parser.read_binary(data, 2, 2) == 256
        assert parser.read_binary(data, 4, 2) == 65535
    
    def test_read_binary_4_bytes(self):
        """Test reading 4-byte binary integer."""
        parser = BaseRecordParser()
        data = b'\x00\x00\x00\x00\x00\x00\x01\x00\xFF\xFF\xFF\xFF'
        
        assert parser.read_binary(data, 0, 4) == 0
        assert parser.read_binary(data, 4, 4) == 256
        assert parser.read_binary(data, 8, 4) == 4294967295
    
    def test_read_binary_8_bytes(self):
        """Test reading 8-byte binary integer."""
        parser = BaseRecordParser()
        data = b'\x00\x00\x00\x00\x00\x00\x00\x01\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
        
        assert parser.read_binary(data, 0, 8) == 1
        assert parser.read_binary(data, 8, 8) == 18446744073709551615
    
    def test_read_packed_decimal_positive(self):
        """Test reading positive packed decimal values."""
        parser = BaseRecordParser()
        # 0123C = 123 positive (3 bytes: 01 23 0C)
        data = b'\x01\x23\x0C'
        assert parser.read_packed_decimal(data, 0, 3) == 1230
        
        # 0456F = 456 unsigned (3 bytes: 04 56 0F)
        data = b'\x04\x56\x0F'
        assert parser.read_packed_decimal(data, 0, 3) == 4560
    
    def test_read_packed_decimal_negative(self):
        """Test reading negative packed decimal values."""
        parser = BaseRecordParser()
        # 0789D = -7890 (3 bytes: 07 89 0D)
        data = b'\x07\x89\x0D'
        assert parser.read_packed_decimal(data, 0, 3) == -7890
    
    def test_read_packed_decimal_date_format(self):
        """Test reading packed decimal in date format (0cyydddF)."""
        parser = BaseRecordParser()
        # 0cyydddF format: 01240001F = 124001 (4 bytes: 01 24 00 1F)
        data = b'\x01\x24\x00\x1F'
        result = parser.read_packed_decimal(data, 0, 4)
        assert result == 124001
    
    def test_read_string_ebcdic(self):
        """Test reading EBCDIC encoded strings."""
        parser = BaseRecordParser(encoding="EBCDIC")
        # "TEST" in EBCDIC (cp037)
        data = b'\xE3\xC5\xE2\xE3\x40\x40'  # "TEST  "
        result = parser.read_string(data, 0, 6, "test_field")
        assert result == "TEST"
    
    def test_read_string_utf8(self):
        """Test reading UTF-8 encoded strings."""
        parser = BaseRecordParser(encoding="UTF-8")
        data = b'TEST  '
        result = parser.read_string(data, 0, 6, "test_field")
        assert result == "TEST"
    
    def test_read_string_strips_trailing_spaces(self):
        """Test that read_string strips trailing spaces."""
        parser = BaseRecordParser(encoding="UTF-8")
        data = b'HELLO     '
        result = parser.read_string(data, 0, 10, "test_field")
        assert result == "HELLO"
    
    def test_read_string_encoding_error(self):
        """Test that invalid encoding raises EncodingError."""
        parser = BaseRecordParser(encoding="UTF-8")
        # Invalid UTF-8 sequence
        data = b'\xFF\xFE\xFD'
        
        with pytest.raises(EncodingError) as exc_info:
            parser.read_string(data, 0, 3, "bad_field")
        
        assert exc_info.value.field_name == "bad_field"
        assert exc_info.value.offset == 0
        assert exc_info.value.encoding == "UTF-8"
    
    def test_read_timestamp(self):
        """Test reading SMF timestamp (hundredths of second since midnight)."""
        parser = BaseRecordParser()
        # 360000 hundredths = 3600 seconds = 1 hour
        data = b'\x00\x05\x7E\x40'
        result = parser.read_timestamp(data, 0)
        
        assert result == "01:00:00.00"
    
    def test_read_timestamp_midnight(self):
        """Test reading timestamp at midnight."""
        parser = BaseRecordParser()
        data = b'\x00\x00\x00\x00'
        result = parser.read_timestamp(data, 0)
        
        assert result == "00:00:00.00"
    
    def test_read_date_2024(self):
        """Test reading SMF date for 2024."""
        parser = BaseRecordParser()
        # 1240001F = 2024, day 1 (January 1, 2024)
        data = b'\x01\x24\x00\x1F'
        result = parser.read_date(data, 0)
        
        assert result == date(2024, 1, 1)
    
    def test_read_date_1999(self):
        """Test reading SMF date for 1999."""
        parser = BaseRecordParser()
        # 0990365F = 1999, day 365 (December 31, 1999)
        data = b'\x00\x99\x36\x5F'
        result = parser.read_date(data, 0)
        
        assert result == date(1999, 12, 31)
    
    def test_read_date_leap_year(self):
        """Test reading SMF date for leap year."""
        parser = BaseRecordParser()
        # 1240060F = 2024, day 60 (February 29, 2024)
        data = b'\x01\x24\x06\x0F'
        result = parser.read_date(data, 0)
        
        assert result == date(2024, 2, 29)
    
    def test_validate_offset_valid(self):
        """Test that valid offsets pass validation."""
        parser = BaseRecordParser()
        data = b'\x00' * 100
        
        # Should not raise
        parser.validate_offset(data, 0, 10)
        parser.validate_offset(data, 50, 50)
        parser.validate_offset(data, 99, 1)
    
    def test_validate_offset_exceeds_boundary(self):
        """Test that offset exceeding boundary raises ValidationError."""
        parser = BaseRecordParser()
        data = b'\x00' * 100
        
        with pytest.raises(ValidationError) as exc_info:
            parser.validate_offset(data, 95, 10)
        
        assert "exceeds record size" in str(exc_info.value)
        assert exc_info.value.offset == 95
    
    def test_validate_offset_negative_offset(self):
        """Test that negative offset raises ValidationError."""
        parser = BaseRecordParser()
        data = b'\x00' * 100
        
        with pytest.raises(ValidationError) as exc_info:
            parser.validate_offset(data, -1, 10)
        
        assert "Negative offset" in str(exc_info.value)
    
    def test_validate_offset_negative_length(self):
        """Test that negative length raises ValidationError."""
        parser = BaseRecordParser()
        data = b'\x00' * 100
        
        with pytest.raises(ValidationError) as exc_info:
            parser.validate_offset(data, 0, -1)
        
        assert "Negative length" in str(exc_info.value)
