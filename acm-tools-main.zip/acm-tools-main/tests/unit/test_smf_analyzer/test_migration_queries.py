"""Unit tests for migration planning queries."""

import pytest
from tools.smf_analyzer.smf_queries.queries.migration_queries import (
    WorkloadPrioritizationQuery,
    MigrationComplexityQuery,
    MigrationEffortQuery
)


class TestWorkloadPrioritizationQuery:
    """Test WorkloadPrioritizationQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = WorkloadPrioritizationQuery()
        
        assert query.name == "workload_prioritization"
        assert query.description
        assert query.category == "Migration Planning"
        assert query.purpose
        assert query.record_types == [30, 110]
        assert query.migration_impact
        assert query.requires_inventory is True
    
    def test_configuration_parameters(self):
        """Test that query defines all required configuration parameters."""
        query = WorkloadPrioritizationQuery()
        params = query.configuration_parameters
        
        assert 'PRIORITY_USAGE_WEIGHT' in params
        assert 'PRIORITY_COMPLEXITY_WEIGHT' in params
        assert 'PRIORITY_DEPENDENCY_WEIGHT' in params
        assert 'PRIORITY_RESOURCE_WEIGHT' in params
        assert 'PRIORITY_RELIABILITY_WEIGHT' in params
        
        # Verify default values
        assert params['PRIORITY_USAGE_WEIGHT'].default_value == 30
        assert params['PRIORITY_COMPLEXITY_WEIGHT'].default_value == 25
        assert params['PRIORITY_DEPENDENCY_WEIGHT'].default_value == 20
        assert params['PRIORITY_RESOURCE_WEIGHT'].default_value == 15
        assert params['PRIORITY_RELIABILITY_WEIGHT'].default_value == 10
    
    def test_get_sql_returns_valid_query(self):
        """Test that get_sql returns a valid SQL query."""
        query = WorkloadPrioritizationQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'SELECT' in sql
        assert 'FROM' in sql
        assert 'smf30_identification' in sql
        assert 'smf30_processor' in sql
        assert 'complexity_metrics' in sql
        assert 'artifact_dependencies' in sql
        assert 'migration_priority_score' in sql
        assert 'recommended_wave' in sql
    
    def test_priority_scoring_logic(self):
        """Test that priority scoring uses configured weights."""
        query = WorkloadPrioritizationQuery()
        sql = query.get_sql(
            analysis_days=365,
            PRIORITY_USAGE_WEIGHT=40,
            PRIORITY_COMPLEXITY_WEIGHT=30,
            PRIORITY_DEPENDENCY_WEIGHT=15,
            PRIORITY_RESOURCE_WEIGHT=10,
            PRIORITY_RELIABILITY_WEIGHT=5
        )
        
        # Verify weights are used in SQL
        assert '40' in sql  # usage weight
        assert '30' in sql  # complexity weight
        assert '15' in sql  # dependency weight
        assert '10' in sql  # resource weight
        assert '5' in sql   # reliability weight
    
    def test_wave_recommendations(self):
        """Test that query includes wave recommendations."""
        query = WorkloadPrioritizationQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'Wave 1 - Quick Wins' in sql
        assert 'Wave 2 - Standard' in sql
        assert 'Wave 3 - Complex' in sql
        assert 'Wave 4 - Deferred' in sql
    
    def test_runtime_parameters(self):
        """Test that query defines runtime parameters."""
        query = WorkloadPrioritizationQuery()
        params = query.get_parameters()
        
        assert 'analysis_days' in params
        assert params['analysis_days']['type'] == 'int'
        assert params['analysis_days']['default'] == 365


class TestMigrationComplexityQuery:
    """Test MigrationComplexityQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = MigrationComplexityQuery()
        
        assert query.name == "migration_complexity"
        assert query.description
        assert query.category == "Migration Planning"
        assert query.purpose
        assert query.record_types == [30, 110]
        assert query.migration_impact
        assert query.requires_inventory is True
    
    def test_configuration_parameters(self):
        """Test that query defines all required configuration parameters."""
        query = MigrationComplexityQuery()
        params = query.configuration_parameters
        
        assert 'COMPLEXITY_EFFORT_PER_PROGRAM' in params
        assert 'COMPLEXITY_EFFORT_PER_CICS_PROGRAM' in params
        assert 'COMPLEXITY_EFFORT_PER_1000_LOC' in params
        assert 'COMPLEXITY_EFFORT_PER_COMPLEXITY_POINT' in params
        assert 'COMPLEXITY_THRESHOLD_LOW' in params
        assert 'COMPLEXITY_THRESHOLD_MEDIUM' in params
        assert 'COMPLEXITY_THRESHOLD_HIGH' in params
        
        # Verify default values
        assert params['COMPLEXITY_EFFORT_PER_PROGRAM'].default_value == 8
        assert params['COMPLEXITY_EFFORT_PER_CICS_PROGRAM'].default_value == 16
        assert params['COMPLEXITY_EFFORT_PER_1000_LOC'].default_value == 4
        assert params['COMPLEXITY_EFFORT_PER_COMPLEXITY_POINT'].default_value == 0.5
    
    def test_get_sql_returns_valid_query(self):
        """Test that get_sql returns a valid SQL query."""
        query = MigrationComplexityQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'SELECT' in sql
        assert 'FROM' in sql
        assert 'smf30_identification' in sql
        assert 'complexity_metrics' in sql
        assert 'artifact_dependencies' in sql
        assert 'complexity_score' in sql
        assert 'complexity_category' in sql
        assert 'estimated_effort_hours' in sql
    
    def test_complexity_scoring_logic(self):
        """Test that complexity scoring uses configured parameters."""
        query = MigrationComplexityQuery()
        sql = query.get_sql(
            analysis_days=365,
            COMPLEXITY_EFFORT_PER_PROGRAM=10,
            COMPLEXITY_EFFORT_PER_CICS_PROGRAM=20,
            COMPLEXITY_EFFORT_PER_1000_LOC=5,
            COMPLEXITY_EFFORT_PER_COMPLEXITY_POINT=1.0
        )
        
        # Verify parameters are used in SQL
        assert '10' in sql  # base effort
        assert '20' in sql  # CICS effort
        assert '5' in sql   # LOC effort
        assert '1.0' in sql # complexity point effort
    
    def test_complexity_categories(self):
        """Test that query includes complexity categories."""
        query = MigrationComplexityQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'Low' in sql
        assert 'Medium' in sql
        assert 'High' in sql
        assert 'Very High' in sql
    
    def test_cics_detection(self):
        """Test that query detects CICS programs."""
        query = MigrationComplexityQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'is_cics_program' in sql
        assert 'smf110_transaction' in sql
    
    def test_risk_factors(self):
        """Test that query identifies risk factors."""
        query = MigrationComplexityQuery()
        sql = query.get_sql(analysis_days=365)
        
        assert 'risk_factor_1' in sql
        assert 'risk_factor_2' in sql
        assert 'risk_factor_3' in sql
        assert 'CICS transaction processing' in sql
        assert 'High cyclomatic complexity' in sql
        assert 'Many dependencies' in sql


class TestMigrationEffortQuery:
    """Test MigrationEffortQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = MigrationEffortQuery()
        
        assert query.name == "migration_effort"
        assert query.description
        assert query.category == "Migration Planning"
        assert query.purpose
        assert query.record_types == []  # Uses inventory only
        assert query.migration_impact
        assert query.requires_inventory is True
    
    def test_configuration_parameters(self):
        """Test that query defines all required configuration parameters."""
        query = MigrationEffortQuery()
        params = query.configuration_parameters
        
        assert 'COMPLEXITY_EFFORT_PER_PROGRAM' in params
        assert 'COMPLEXITY_EFFORT_PER_CICS_PROGRAM' in params
        assert 'COMPLEXITY_EFFORT_PER_1000_LOC' in params
        assert 'COMPLEXITY_EFFORT_PER_COMPLEXITY_POINT' in params
        assert 'EFFORT_JCL_HOURS' in params
        assert 'EFFORT_COPYBOOK_HOURS' in params
        assert 'EFFORT_TESTING_MULTIPLIER' in params
        assert 'EFFORT_DOCUMENTATION_MULTIPLIER' in params
        assert 'EFFORT_PROJECT_MGMT_MULTIPLIER' in params
        assert 'HOURS_PER_PERSON_MONTH' in params
        
        # Verify default values
        assert params['EFFORT_JCL_HOURS'].default_value == 2
        assert params['EFFORT_COPYBOOK_HOURS'].default_value == 1
        assert params['EFFORT_TESTING_MULTIPLIER'].default_value == 1.5
        assert params['EFFORT_DOCUMENTATION_MULTIPLIER'].default_value == 0.2
        assert params['EFFORT_PROJECT_MGMT_MULTIPLIER'].default_value == 0.15
        assert params['HOURS_PER_PERSON_MONTH'].default_value == 160
    
    def test_get_sql_returns_valid_query(self):
        """Test that get_sql returns a valid SQL query."""
        query = MigrationEffortQuery()
        sql = query.get_sql()
        
        assert 'SELECT' in sql
        assert 'FROM' in sql
        assert 'inventory_programs' in sql
        assert 'inventory_jcl' in sql
        assert 'inventory_copybooks' in sql
        assert 'complexity_metrics' in sql
        assert 'total_effort_person_months' in sql
        assert 'team_size_12_months' in sql
    
    def test_effort_calculation_components(self):
        """Test that effort calculation includes all components."""
        query = MigrationEffortQuery()
        sql = query.get_sql()
        
        # Development effort
        assert 'program_hours' in sql
        assert 'jcl_hours' in sql
        assert 'copybook_hours' in sql
        assert 'total_development_hours' in sql
        
        # Additional effort
        assert 'testing_hours' in sql
        assert 'documentation_hours' in sql
        assert 'project_mgmt_hours' in sql
        
        # Total effort
        assert 'total_effort_hours' in sql
        assert 'total_effort_person_months' in sql
    
    def test_team_size_estimates(self):
        """Test that query provides team size estimates."""
        query = MigrationEffortQuery()
        sql = query.get_sql()
        
        assert 'team_size_12_months' in sql
        assert 'team_size_18_months' in sql
        assert 'team_size_24_months' in sql
    
    def test_effort_multipliers(self):
        """Test that effort calculation uses configured multipliers."""
        query = MigrationEffortQuery()
        sql = query.get_sql(
            EFFORT_TESTING_MULTIPLIER=2.0,
            EFFORT_DOCUMENTATION_MULTIPLIER=0.3,
            EFFORT_PROJECT_MGMT_MULTIPLIER=0.2
        )
        
        # Verify multipliers are used in SQL
        assert '2.0' in sql  # testing multiplier
        assert '0.3' in sql  # documentation multiplier
        assert '0.2' in sql  # project mgmt multiplier
    
    def test_artifact_counts(self):
        """Test that query includes artifact counts."""
        query = MigrationEffortQuery()
        sql = query.get_sql()
        
        assert 'program_count' in sql
        assert 'jcl_count' in sql
        assert 'copybook_count' in sql
        assert 'total_artifacts' in sql
    
    def test_phase_breakdown(self):
        """Test that query provides effort breakdown by phase."""
        query = MigrationEffortQuery()
        sql = query.get_sql()
        
        assert 'development_person_months' in sql
        assert 'testing_person_months' in sql
        assert 'documentation_person_months' in sql
        assert 'project_mgmt_person_months' in sql
