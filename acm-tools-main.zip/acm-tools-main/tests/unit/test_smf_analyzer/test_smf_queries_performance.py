"""Performance tests for SMF queries modernization.

This module tests the performance characteristics of the modernized query system
including configuration caching, query execution, metadata retrieval, and serialization.
"""

import pytest
import time
import tempfile
import os
import sqlite3
from typing import List, Dict, Any

from tools.smf_analyzer.smf_queries.configuration_manager import ConfigurationManager
from tools.smf_analyzer.smf_queries.file_config_manager import FileConfigurationManager
from tools.smf_analyzer.smf_queries.database_config_manager import DatabaseConfigurationManager
from tools.smf_analyzer.smf_queries.query_engine import QueryEngine
from tools.smf_analyzer.smf_queries.base_query import BaseQuery, QueryResult
from tools.smf_analyzer.smf_queries.config_parameter import ConfigParameter
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    # Create a simple database with some data
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create test tables
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS query_config (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            value_type TEXT NOT NULL,
            description TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS test_data (
            id INTEGER PRIMARY KEY,
            name TEXT,
            value INTEGER,
            category TEXT
        )
    """)
    
    # Insert test data
    for i in range(1000):
        cursor.execute(
            "INSERT INTO test_data (name, value, category) VALUES (?, ?, ?)",
            (f"item_{i}", i * 10, f"category_{i % 10}")
        )
    
    conn.commit()
    conn.close()
    
    yield db_path
    
    # Cleanup
    if os.path.exists(db_path):
        os.unlink(db_path)


@pytest.fixture
def temp_yaml():
    """Create a temporary YAML file for testing."""
    with tempfile.NamedTemporaryFile(suffix='.yaml', delete=False, mode='w') as f:
        yaml_path = f.name
    
    yield yaml_path
    
    # Cleanup
    if os.path.exists(yaml_path):
        os.unlink(yaml_path)


class MockQuery(BaseQuery):
    """Mock query for testing."""
    
    @property
    def name(self) -> str:
        return "mock_query"
    
    @property
    def description(self) -> str:
        return "Mock query for testing"
    
    @property
    def category(self) -> str:
        return "Test"
    
    @property
    def purpose(self) -> str:
        return "Test query for performance testing"
    
    @property
    def record_types(self) -> List[int]:
        return [30]
    
    @property
    def migration_impact(self) -> str:
        return "No impact - test query"
    
    @property
    def requires_inventory(self) -> bool:
        return False
    
    @property
    def configuration_parameters(self) -> Dict[str, ConfigParameter]:
        return {
            'test_param': ConfigParameter(
                name='test_param',
                description='Test parameter',
                default_value=100,
                parameter_type='int',
                unit='count',
                min_value=1,
                max_value=1000,
                examples=[50, 100, 200]
            )
        }
    
    def get_sql(self, **params) -> str:
        test_param = params.get('test_param', 100)
        return f"SELECT * FROM test_data LIMIT {test_param}"


# ============================================================================
# Task 13.1: Configuration Cache Performance Tests
# ============================================================================

class TestConfigurationCachePerformance:
    """Test configuration cache performance.
    
    Requirements: 3.7, 14.1, 14.2
    - Measure cache hit rate and response time improvement
    - Verify cache hit rate > 95%
    - Verify cached retrieval time < 10ms
    """
    
    def test_file_config_cache_hit_rate(self, temp_yaml):
        """Test that file configuration manager achieves > 95% cache hit rate."""
        # Create configuration manager
        config_manager = FileConfigurationManager(temp_yaml, file_format='yaml')
        
        # Set initial configuration
        test_params = {
            'param1': 100,
            'param2': 200,
            'param3': 'test',
            'param4': True,
            'param5': 3.14
        }
        
        for key, value in test_params.items():
            config_manager.set(key, value)
        
        # Warm up cache
        config_manager.get('param1')
        
        # Measure cache hits
        num_requests = 1000
        cache_hits = 0
        
        start_time = time.time()
        for i in range(num_requests):
            # Access different parameters to test cache
            param_key = f'param{(i % 5) + 1}'
            value = config_manager.get(param_key)
            
            # If we got a value, it was a cache hit
            if value is not None:
                cache_hits += 1
        
        total_time = time.time() - start_time
        
        # Calculate hit rate
        hit_rate = (cache_hits / num_requests) * 100
        avg_time_ms = (total_time / num_requests) * 1000
        
        print(f"\nFile Config Cache Performance:")
        print(f"  Total requests: {num_requests}")
        print(f"  Cache hits: {cache_hits}")
        print(f"  Hit rate: {hit_rate:.2f}%")
        print(f"  Average retrieval time: {avg_time_ms:.3f}ms")
        
        # Assertions
        assert hit_rate > 95.0, f"Cache hit rate too low: {hit_rate:.2f}%"
        assert avg_time_ms < 10.0, f"Cached retrieval too slow: {avg_time_ms:.3f}ms"
    
    def test_database_config_cache_hit_rate(self, temp_db):
        """Test that database configuration manager achieves > 95% cache hit rate."""
        # Create database adapter
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        
        # Create configuration manager
        config_manager = DatabaseConfigurationManager(adapter)
        
        # Set initial configuration
        test_params = {
            'param1': 100,
            'param2': 200,
            'param3': 'test',
            'param4': True,
            'param5': 3.14
        }
        
        for key, value in test_params.items():
            config_manager.set(key, value)
        
        # Warm up cache
        config_manager.get('param1')
        
        # Measure cache hits
        num_requests = 1000
        cache_hits = 0
        
        start_time = time.time()
        for i in range(num_requests):
            # Access different parameters to test cache
            param_key = f'param{(i % 5) + 1}'
            value = config_manager.get(param_key)
            
            # If we got a value, it was a cache hit
            if value is not None:
                cache_hits += 1
        
        total_time = time.time() - start_time
        
        # Calculate hit rate
        hit_rate = (cache_hits / num_requests) * 100
        avg_time_ms = (total_time / num_requests) * 1000
        
        print(f"\nDatabase Config Cache Performance:")
        print(f"  Total requests: {num_requests}")
        print(f"  Cache hits: {cache_hits}")
        print(f"  Hit rate: {hit_rate:.2f}%")
        print(f"  Average retrieval time: {avg_time_ms:.3f}ms")
        
        # Assertions
        assert hit_rate > 95.0, f"Cache hit rate too low: {hit_rate:.2f}%"
        assert avg_time_ms < 10.0, f"Cached retrieval too slow: {avg_time_ms:.3f}ms"
    
    def test_cache_vs_uncached_performance(self, temp_yaml):
        """Test that cached retrieval is significantly faster than uncached."""
        config_manager = FileConfigurationManager(temp_yaml, file_format='yaml')
        
        # Set configuration
        config_manager.set('test_param', 12345)
        
        # Measure uncached retrieval (force cache invalidation)
        uncached_times = []
        for _ in range(10):
            config_manager._invalidate_cache()
            start = time.time()
            value = config_manager.get('test_param')
            uncached_times.append((time.time() - start) * 1000)
        
        avg_uncached_ms = sum(uncached_times) / len(uncached_times)
        
        # Measure cached retrieval
        cached_times = []
        for _ in range(100):
            start = time.time()
            value = config_manager.get('test_param')
            cached_times.append((time.time() - start) * 1000)
        
        avg_cached_ms = sum(cached_times) / len(cached_times)
        
        speedup = avg_uncached_ms / avg_cached_ms if avg_cached_ms > 0 else 0
        
        print(f"\nCache Performance Comparison:")
        print(f"  Uncached average: {avg_uncached_ms:.3f}ms")
        print(f"  Cached average: {avg_cached_ms:.3f}ms")
        print(f"  Speedup: {speedup:.1f}x")
        
        # Assertions
        assert avg_cached_ms < 10.0, f"Cached retrieval too slow: {avg_cached_ms:.3f}ms"
        assert speedup > 2.0, f"Cache speedup too low: {speedup:.1f}x"
    
    def test_cache_invalidation_performance(self, temp_yaml):
        """Test that cache invalidation and refresh is efficient."""
        config_manager = FileConfigurationManager(temp_yaml, file_format='yaml')
        
        # Set multiple parameters
        for i in range(50):
            config_manager.set(f'param_{i}', i * 10)
        
        # Measure cache refresh time
        refresh_times = []
        for _ in range(20):
            config_manager._invalidate_cache()
            start = time.time()
            config_manager.get('param_0')  # This triggers cache refresh
            refresh_times.append((time.time() - start) * 1000)
        
        avg_refresh_ms = sum(refresh_times) / len(refresh_times)
        
        print(f"\nCache Refresh Performance:")
        print(f"  Average refresh time: {avg_refresh_ms:.3f}ms")
        print(f"  Parameters in cache: 50")
        
        # Assertion - refresh should be reasonably fast
        assert avg_refresh_ms < 100.0, f"Cache refresh too slow: {avg_refresh_ms:.3f}ms"



# ============================================================================
# Task 13.2: Query Execution Performance Tests
# ============================================================================

class TestQueryExecutionPerformance:
    """Test query execution performance with large datasets.
    
    Requirements: 14.3, 14.4
    - Measure query execution time for large datasets
    - Verify queries complete in < 30 seconds for 1 year of SMF data
    """
    
    def test_simple_query_execution_time(self, temp_db):
        """Test that simple queries execute quickly."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        config_manager = DatabaseConfigurationManager(adapter)
        engine = QueryEngine(adapter, config_manager)
        
        # Register mock query
        query = MockQuery()
        engine.register_query(query)
        
        # Execute query multiple times and measure
        execution_times = []
        for _ in range(10):
            start = time.time()
            result = engine.execute('mock_query', test_param=100)
            execution_times.append((time.time() - start) * 1000)
        
        avg_time_ms = sum(execution_times) / len(execution_times)
        
        print(f"\nSimple Query Execution Performance:")
        print(f"  Average execution time: {avg_time_ms:.3f}ms")
        print(f"  Rows returned: {len(result.rows)}")
        
        # Assertion - simple queries should be very fast
        assert avg_time_ms < 1000.0, f"Simple query too slow: {avg_time_ms:.3f}ms"
    
    def test_aggregation_query_performance(self, temp_db):
        """Test aggregation query performance."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        engine = QueryEngine(adapter)
        
        # Execute aggregation query
        start = time.time()
        result = engine.execute_sql("""
            SELECT category, COUNT(*) as count, AVG(value) as avg_value
            FROM test_data
            GROUP BY category
            ORDER BY count DESC
        """, description="Aggregation test")
        execution_time_ms = (time.time() - start) * 1000
        
        print(f"\nAggregation Query Performance:")
        print(f"  Execution time: {execution_time_ms:.3f}ms")
        print(f"  Groups returned: {len(result.rows)}")
        
        # Assertion
        assert execution_time_ms < 5000.0, f"Aggregation query too slow: {execution_time_ms:.3f}ms"
    
    def test_large_result_set_performance(self, temp_db):
        """Test query performance with large result sets."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        engine = QueryEngine(adapter)
        
        # Execute query returning all rows
        start = time.time()
        result = engine.execute_sql(
            "SELECT * FROM test_data ORDER BY id",
            description="Large result set test"
        )
        execution_time_ms = (time.time() - start) * 1000
        
        print(f"\nLarge Result Set Performance:")
        print(f"  Execution time: {execution_time_ms:.3f}ms")
        print(f"  Rows returned: {len(result.rows)}")
        
        # Assertion - should handle 1000 rows efficiently
        assert execution_time_ms < 10000.0, f"Large result query too slow: {execution_time_ms:.3f}ms"
        assert len(result.rows) == 1000, "Expected 1000 rows"
    
    def test_query_with_configuration_injection(self, temp_db):
        """Test that configuration injection doesn't significantly impact performance."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        config_manager = DatabaseConfigurationManager(adapter)
        
        # Set configuration
        config_manager.set('test_param', 50)
        
        engine = QueryEngine(adapter, config_manager)
        query = MockQuery()
        engine.register_query(query)
        
        # Measure execution time with config injection
        execution_times = []
        for _ in range(20):
            start = time.time()
            result = engine.execute('mock_query')  # Uses config value
            execution_times.append((time.time() - start) * 1000)
        
        avg_time_ms = sum(execution_times) / len(execution_times)
        
        print(f"\nQuery with Configuration Injection:")
        print(f"  Average execution time: {avg_time_ms:.3f}ms")
        
        # Assertion - config injection should add minimal overhead
        assert avg_time_ms < 1000.0, f"Query with config injection too slow: {avg_time_ms:.3f}ms"
    
    def test_concurrent_query_execution(self, temp_db):
        """Test that multiple queries can execute efficiently."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        engine = QueryEngine(adapter)
        
        # Execute multiple different queries
        queries = [
            "SELECT * FROM test_data WHERE category = 'category_0' LIMIT 10",
            "SELECT COUNT(*) FROM test_data",
            "SELECT AVG(value) FROM test_data",
            "SELECT * FROM test_data ORDER BY value DESC LIMIT 5",
            "SELECT category, COUNT(*) FROM test_data GROUP BY category"
        ]
        
        start = time.time()
        results = []
        for sql in queries:
            result = engine.execute_sql(sql, description="Concurrent test")
            results.append(result)
        total_time_ms = (time.time() - start) * 1000
        
        avg_time_ms = total_time_ms / len(queries)
        
        print(f"\nConcurrent Query Execution:")
        print(f"  Total time: {total_time_ms:.3f}ms")
        print(f"  Average per query: {avg_time_ms:.3f}ms")
        print(f"  Queries executed: {len(queries)}")
        
        # Assertion
        assert total_time_ms < 30000.0, f"Concurrent queries too slow: {total_time_ms:.3f}ms"


# ============================================================================
# Task 13.3: Metadata Retrieval Performance Tests
# ============================================================================

class TestMetadataRetrievalPerformance:
    """Test metadata retrieval performance.
    
    Requirements: 11.1, 14.3
    - Measure time to retrieve metadata for all queries
    - Verify metadata retrieval time < 100ms
    """
    
    def test_single_query_metadata_retrieval(self, temp_db):
        """Test metadata retrieval for a single query."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        engine = QueryEngine(adapter)
        
        # Register query
        query = MockQuery()
        engine.register_query(query)
        
        # Measure metadata retrieval time
        retrieval_times = []
        for _ in range(100):
            start = time.time()
            metadata = engine.get_query_metadata('mock_query')
            retrieval_times.append((time.time() - start) * 1000)
        
        avg_time_ms = sum(retrieval_times) / len(retrieval_times)
        
        print(f"\nSingle Query Metadata Retrieval:")
        print(f"  Average retrieval time: {avg_time_ms:.3f}ms")
        
        # Assertion
        assert avg_time_ms < 10.0, f"Metadata retrieval too slow: {avg_time_ms:.3f}ms"
        assert 'name' in metadata
        assert 'configuration_parameters' in metadata
    
    def test_all_queries_metadata_retrieval(self, temp_db):
        """Test metadata retrieval for all registered queries."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        engine = QueryEngine(adapter)
        
        # Register multiple queries
        num_queries = 20
        for i in range(num_queries):
            query_name = f"test_query_{i}"
            
            # Create a factory function to capture variables properly
            def make_query(name):
                class TestQuery(MockQuery):
                    @property
                    def name(self) -> str:
                        return name
                
                return TestQuery()
            
            engine.register_query(make_query(query_name))
        
        # Measure time to retrieve all metadata
        start = time.time()
        all_metadata = {}
        for query_name in engine._queries.keys():
            all_metadata[query_name] = engine.get_query_metadata(query_name)
        total_time_ms = (time.time() - start) * 1000
        
        avg_time_ms = total_time_ms / num_queries
        
        print(f"\nAll Queries Metadata Retrieval:")
        print(f"  Total time: {total_time_ms:.3f}ms")
        print(f"  Average per query: {avg_time_ms:.3f}ms")
        print(f"  Queries processed: {num_queries}")
        
        # Assertions
        assert total_time_ms < 100.0, f"All metadata retrieval too slow: {total_time_ms:.3f}ms"
        assert len(all_metadata) == num_queries
    
    def test_list_queries_by_category_performance(self, temp_db):
        """Test performance of listing queries by category."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        engine = QueryEngine(adapter)
        
        # Register queries in different categories
        categories = ['Code Artifact Analysis', 'Infrastructure Sizing', 
                     'Cost Analysis', 'Migration Planning']
        
        for i in range(40):  # 10 queries per category
            category_idx = i % len(categories)
            category_name = categories[category_idx]
            query_name = f"query_{i}"
            
            # Create a factory function to capture variables properly
            def make_query(name, cat):
                class TestQuery(MockQuery):
                    @property
                    def name(self) -> str:
                        return name
                    
                    @property
                    def category(self) -> str:
                        return cat
                
                return TestQuery()
            
            engine.register_query(make_query(query_name, category_name))
        
        # Measure time to list by category
        start = time.time()
        queries_by_category = engine.list_queries_by_category()
        retrieval_time_ms = (time.time() - start) * 1000
        
        print(f"\nList Queries by Category Performance:")
        print(f"  Retrieval time: {retrieval_time_ms:.3f}ms")
        print(f"  Categories: {len(queries_by_category)}")
        print(f"  Total queries: {sum(len(q) for q in queries_by_category.values())}")
        
        # Assertions
        assert retrieval_time_ms < 50.0, f"Category listing too slow: {retrieval_time_ms:.3f}ms"
        assert len(queries_by_category) == len(categories)
    
    def test_configuration_parameters_retrieval(self, temp_db):
        """Test performance of retrieving all configuration parameters."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        config_manager = DatabaseConfigurationManager(adapter)
        engine = QueryEngine(adapter, config_manager)
        
        # Register queries with configuration parameters
        for i in range(30):
            query_name = f"query_{i}"
            param_name = f"param_{i}"
            param_value = i * 10
            
            # Create a factory function to capture variables properly
            def make_query(name, pname, pvalue):
                class TestQuery(MockQuery):
                    @property
                    def name(self) -> str:
                        return name
                    
                    @property
                    def configuration_parameters(self) -> Dict[str, ConfigParameter]:
                        return {
                            pname: ConfigParameter(
                                name=pname,
                                description=f'Parameter {pname}',
                                default_value=pvalue,
                                parameter_type='int'
                            )
                        }
                
                return TestQuery()
            
            engine.register_query(make_query(query_name, param_name, param_value))
        
        # Measure time to get all configuration parameters
        start = time.time()
        all_params = engine.get_configuration_parameters()
        retrieval_time_ms = (time.time() - start) * 1000
        
        print(f"\nConfiguration Parameters Retrieval:")
        print(f"  Retrieval time: {retrieval_time_ms:.3f}ms")
        print(f"  Parameters retrieved: {len(all_params)}")
        
        # Assertions
        assert retrieval_time_ms < 100.0, f"Config params retrieval too slow: {retrieval_time_ms:.3f}ms"
        assert len(all_params) >= 30


# ============================================================================
# Task 13.4: Serialization Performance Tests
# ============================================================================

class TestSerializationPerformance:
    """Test query result serialization performance.
    
    Requirements: 12.1, 12.2, 12.3, 12.4, 14.3
    - Measure time to serialize large QueryResults to different formats
    - Verify serialization time < 1 second for 10,000 row results
    """
    
    def _create_large_result(self, num_rows: int = 10000) -> QueryResult:
        """Create a large QueryResult for testing."""
        columns = ['id', 'name', 'value', 'category', 'timestamp']
        rows = []
        
        for i in range(num_rows):
            rows.append((
                i,
                f'item_{i}',
                i * 10,
                f'category_{i % 10}',
                f'2024-01-{(i % 28) + 1:02d}'
            ))
        
        return QueryResult(
            query_name='performance_test',
            description='Performance test query',
            columns=columns,
            rows=rows
        )
    
    def test_to_dict_serialization_performance(self):
        """Test to_dict() serialization performance."""
        result = self._create_large_result(10000)
        
        # Measure serialization time
        start = time.time()
        dict_result = result.to_dict()
        serialization_time_ms = (time.time() - start) * 1000
        
        print(f"\nto_dict() Serialization Performance:")
        print(f"  Rows: {len(result.rows)}")
        print(f"  Serialization time: {serialization_time_ms:.3f}ms")
        print(f"  Rows per second: {len(result.rows) / (serialization_time_ms / 1000):.0f}")
        
        # Assertions
        assert serialization_time_ms < 1000.0, f"to_dict() too slow: {serialization_time_ms:.3f}ms"
        assert dict_result['row_count'] == 10000
        assert len(dict_result['rows']) == 10000
    
    def test_to_csv_serialization_performance(self):
        """Test to_csv() serialization performance."""
        result = self._create_large_result(10000)
        
        # Measure serialization time
        start = time.time()
        csv_result = result.to_csv()
        serialization_time_ms = (time.time() - start) * 1000
        
        # Count lines
        line_count = len(csv_result.split('\n'))
        
        print(f"\nto_csv() Serialization Performance:")
        print(f"  Rows: {len(result.rows)}")
        print(f"  Serialization time: {serialization_time_ms:.3f}ms")
        print(f"  CSV size: {len(csv_result) / 1024:.2f} KB")
        print(f"  Lines: {line_count}")
        
        # Assertions
        assert serialization_time_ms < 1000.0, f"to_csv() too slow: {serialization_time_ms:.3f}ms"
        assert line_count > 10000  # Header + data rows
    
    def test_to_json_serialization_performance(self):
        """Test to_json() serialization performance."""
        result = self._create_large_result(10000)
        
        # Measure serialization time
        start = time.time()
        json_result = result.to_json()
        serialization_time_ms = (time.time() - start) * 1000
        
        print(f"\nto_json() Serialization Performance:")
        print(f"  Rows: {len(result.rows)}")
        print(f"  Serialization time: {serialization_time_ms:.3f}ms")
        print(f"  JSON size: {len(json_result) / 1024:.2f} KB")
        
        # Assertions
        assert serialization_time_ms < 1000.0, f"to_json() too slow: {serialization_time_ms:.3f}ms"
        assert '"row_count": 10000' in json_result
    
    def test_to_markdown_serialization_performance(self):
        """Test to_markdown() serialization performance."""
        # Use smaller dataset for markdown (it's more verbose)
        result = self._create_large_result(1000)
        
        # Measure serialization time
        start = time.time()
        markdown_result = result.to_markdown()
        serialization_time_ms = (time.time() - start) * 1000
        
        # Count lines
        line_count = len(markdown_result.split('\n'))
        
        print(f"\nto_markdown() Serialization Performance:")
        print(f"  Rows: {len(result.rows)}")
        print(f"  Serialization time: {serialization_time_ms:.3f}ms")
        print(f"  Markdown size: {len(markdown_result) / 1024:.2f} KB")
        print(f"  Lines: {line_count}")
        
        # Assertions - markdown is slower due to formatting
        assert serialization_time_ms < 2000.0, f"to_markdown() too slow: {serialization_time_ms:.3f}ms"
        assert '|' in markdown_result  # Should have table formatting
    
    def test_all_formats_serialization(self):
        """Test serialization to all formats in sequence."""
        result = self._create_large_result(10000)
        
        formats = ['dict', 'csv', 'json']
        times = {}
        
        for fmt in formats:
            start = time.time()
            if fmt == 'dict':
                _ = result.to_dict()
            elif fmt == 'csv':
                _ = result.to_csv()
            elif fmt == 'json':
                _ = result.to_json()
            times[fmt] = (time.time() - start) * 1000
        
        total_time_ms = sum(times.values())
        
        print(f"\nAll Formats Serialization:")
        print(f"  Rows: {len(result.rows)}")
        for fmt, time_ms in times.items():
            print(f"  {fmt}: {time_ms:.3f}ms")
        print(f"  Total: {total_time_ms:.3f}ms")
        
        # Assertions
        assert total_time_ms < 3000.0, f"All formats serialization too slow: {total_time_ms:.3f}ms"
        for fmt, time_ms in times.items():
            assert time_ms < 1000.0, f"{fmt} serialization too slow: {time_ms:.3f}ms"
    
    def test_serialization_memory_efficiency(self):
        """Test that serialization doesn't consume excessive memory."""
        result = self._create_large_result(10000)
        
        # This should not raise MemoryError
        try:
            dict_result = result.to_dict()
            csv_result = result.to_csv()
            json_result = result.to_json()
            
            # Verify results are valid
            assert len(dict_result['rows']) == 10000
            assert len(csv_result) > 0
            assert len(json_result) > 0
            
            print(f"\nSerialization Memory Efficiency:")
            print(f"  Successfully serialized 10,000 rows to all formats")
            print(f"  Dict size: {len(str(dict_result)) / 1024:.2f} KB")
            print(f"  CSV size: {len(csv_result) / 1024:.2f} KB")
            print(f"  JSON size: {len(json_result) / 1024:.2f} KB")
            
        except MemoryError:
            pytest.fail("Serialization consumed too much memory")


# ============================================================================
# Summary Performance Test
# ============================================================================

class TestOverallPerformance:
    """Test overall system performance with realistic workflow."""
    
    def test_end_to_end_query_workflow(self, temp_db):
        """Test complete workflow: register → configure → execute → serialize."""
        adapter = SQLiteAdapter(temp_db)
        adapter.connect()
        config_manager = DatabaseConfigurationManager(adapter)
        engine = QueryEngine(adapter, config_manager)
        
        # Register query
        query = MockQuery()
        engine.register_query(query)
        
        # Set configuration
        config_manager.set('test_param', 100)
        
        # Measure complete workflow
        start = time.time()
        
        # 1. Get metadata
        metadata = engine.get_query_metadata('mock_query')
        
        # 2. Execute query
        result = engine.execute('mock_query')
        
        # 3. Serialize to multiple formats
        dict_result = result.to_dict()
        csv_result = result.to_csv()
        json_result = result.to_json()
        
        total_time_ms = (time.time() - start) * 1000
        
        print(f"\nEnd-to-End Workflow Performance:")
        print(f"  Total time: {total_time_ms:.3f}ms")
        print(f"  Rows processed: {len(result.rows)}")
        
        # Assertions
        assert total_time_ms < 2000.0, f"End-to-end workflow too slow: {total_time_ms:.3f}ms"
        assert len(result.rows) > 0
        assert len(dict_result['rows']) == len(result.rows)
