"""Unit tests for DB2 infrastructure sizing queries."""

import pytest
from tools.smf_analyzer.smf_queries.queries.db2_infrastructure_queries import (
    DB2WorkloadCPUQuery,
)


class TestDB2WorkloadCPUQuery:
    """Test DB2WorkloadCPUQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = DB2WorkloadCPUQuery()
        
        assert query.name == "db2_workload_cpu"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [100, 101]
        assert query.requires_inventory is False
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = DB2WorkloadCPUQuery()
        config_params = query.configuration_parameters
        
        assert 'DB2_CPU_CONVERSION_RATIO' in config_params
        assert 'DB2_OVERHEAD_HEADROOM' in config_params
        assert 'DB2_MEMORY_PER_VCPU' in config_params
        
        # Verify parameter metadata
        cpu_ratio = config_params['DB2_CPU_CONVERSION_RATIO']
        assert cpu_ratio.default_value == 0.6
        assert cpu_ratio.parameter_type == 'float'
        assert cpu_ratio.unit == 'ratio'
        assert cpu_ratio.min_value == 0.1
        assert cpu_ratio.max_value == 2.0
        
        overhead = config_params['DB2_OVERHEAD_HEADROOM']
        assert overhead.default_value == 1.4
        assert overhead.parameter_type == 'float'
        assert overhead.unit == 'multiplier'
        assert overhead.min_value == 1.0
        assert overhead.max_value == 3.0
        
        memory = config_params['DB2_MEMORY_PER_VCPU']
        assert memory.default_value == 4
        assert memory.parameter_type == 'int'
        assert memory.unit == 'GB'
        assert memory.min_value == 2
        assert memory.max_value == 16
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = DB2WorkloadCPUQuery()
        sql = query.get_sql()
        
        # Verify key tables are referenced
        assert 'smf_records' in sql
        assert 'smf101_accounting' in sql
        assert 'smf101_correlation' in sql
        
        # Verify key fields are referenced
        assert 'accumulated_cpu_in_db2' in sql
        assert 'plan_name' in sql
        assert 'authorization_id' in sql
        assert 'db2_entry_exit_count' in sql
        
        # Verify CPU conversion is applied
        assert 'cpu_seconds' in sql
        
        # Verify aggregations are present
        assert 'AVG' in sql or 'avg' in sql.lower()
        assert 'SUM' in sql or 'sum' in sql.lower()
        assert 'MAX' in sql or 'max' in sql.lower()
        
        # Verify grouping
        assert 'GROUP BY' in sql or 'group by' in sql.lower()
    
    def test_get_sql_with_custom_analysis_days(self):
        """Test SQL generation with custom analysis_days parameter."""
        query = DB2WorkloadCPUQuery()
        sql = query.get_sql(analysis_days=180)
        
        assert '-180 days' in sql
    
    def test_get_sql_with_custom_conversion_parameters(self):
        """Test SQL generation with custom conversion parameters."""
        query = DB2WorkloadCPUQuery()
        sql = query.get_sql(
            DB2_CPU_CONVERSION_RATIO=0.7,
            DB2_OVERHEAD_HEADROOM=1.5,
            DB2_MEMORY_PER_VCPU=8
        )
        
        # Verify parameters are used in SQL
        assert '0.7' in sql
        assert '1.5' in sql
        assert '8' in sql
    
    def test_runtime_parameters(self):
        """Test that query defines runtime parameters."""
        query = DB2WorkloadCPUQuery()
        params = query.get_parameters()
        
        assert 'analysis_days' in params
        assert params['analysis_days']['type'] == 'int'
        assert params['analysis_days']['default'] == 365
        assert params['analysis_days']['required'] is False
    
    def test_query_validates_parameters(self):
        """Test that query validates parameters correctly."""
        query = DB2WorkloadCPUQuery()
        
        # Valid parameters should pass
        assert query.validate_parameters(analysis_days=180)
        
        # Configuration parameters should be allowed
        assert query.validate_parameters(
            analysis_days=180,
            DB2_CPU_CONVERSION_RATIO=0.7,
            DB2_OVERHEAD_HEADROOM=1.5
        )
