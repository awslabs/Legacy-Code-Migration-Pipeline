"""Unit tests for SMF Type 6 parser."""

import pytest
import struct
from datetime import date
from tools.smf_analyzer.smf_record_parser.parsers import SMF6ParserV3R2, BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


def create_type6_record_minimal(subsystem_id: int = 0x0002) -> bytes:
    """Create a minimal valid Type 6 record (300 bytes).
    
    Args:
        subsystem_id: Subsystem identifier (0x0000=External, 0x0002=JES2, 0x0005=JES3, 0x0007=PSF, 0x0009=IP PrintWay)
    """
    record = bytearray(300)
    
    # Standard SMF header
    struct.pack_into('>H', record, 0, 300)  # Record length
    struct.pack_into('>H', record, 2, 0)  # Segment descriptor
    struct.pack_into('B', record, 4, 0x01)  # System indicator
    struct.pack_into('B', record, 5, 6)  # Record type = 6
    struct.pack_into('>I', record, 6, 36000)  # Timestamp (10:00:00.00)
    record[10:14] = bytes([0x01, 0x25, 0x00, 0x1F])  # Date (2025-001)
    
    # System ID (EBCDIC)
    sys_id = "SYS1".encode('cp037')
    record[14:18] = sys_id
    
    # Type 6 specific header fields
    job_name = "TESTJOB ".encode('cp037')
    record[18:26] = job_name
    
    struct.pack_into('>I', record, 26, 18000)  # Reader start time
    record[30:34] = bytes([0x01, 0x25, 0x00, 0x1F])  # Reader start date
    
    user_id = "USER1   ".encode('cp037')
    record[34:42] = user_id
    
    sysout_class = "A".encode('cp037')
    record[42:43] = sysout_class
    
    struct.pack_into('>I', record, 43, 19000)  # Writer start time
    record[47:51] = bytes([0x01, 0x25, 0x00, 0x1F])  # Writer start date
    
    struct.pack_into('>I', record, 51, 1000)  # Number of logical records
    struct.pack_into('B', record, 55, 0)  # I/O status
    struct.pack_into('B', record, 56, 1)  # Number of datasets
    
    form_number = "STD1".encode('cp037')
    record[57:61] = form_number
    
    struct.pack_into('B', record, 61, 0x40)  # Section indicator (common section present)
    struct.pack_into('>H', record, 62, subsystem_id)  # Subsystem ID
    
    # I/O data section (starts at offset 64)
    io_section_length = 30
    struct.pack_into('>H', record, 64, io_section_length)  # Section length
    struct.pack_into('B', record, 66, 0)  # Data control indicators
    struct.pack_into('B', record, 67, 1)  # Record level indicator
    
    job_number = "0001".encode('cp037')
    record[68:72] = job_number
    
    output_device = "PRINTER1".encode('cp037')
    record[72:80] = output_device
    
    fcb_image = "FCB1".encode('cp037')
    record[80:84] = fcb_image
    
    ucs_image = "UCS1".encode('cp037')
    record[84:88] = ucs_image
    
    # For JES2/JES3, add page count
    if subsystem_id in [0x0002, 0x0005]:
        struct.pack_into('>I', record, 88, 100)  # Page count
    
    # Common section (offset 94)
    common_offset = 94
    common_length = 38
    struct.pack_into('>H', record, common_offset, common_length)  # Section length
    struct.pack_into('>I', record, common_offset + 2, 0x00010000)  # Route code
    
    form_num = "STD1    ".encode('cp037')
    record[common_offset + 6:common_offset + 14] = form_num
    
    job_id = "JOB00001".encode('cp037')
    record[common_offset + 30:common_offset + 38] = job_id
    
    return bytes(record)


def create_type6_record_external_writer() -> bytes:
    """Create a Type 6 record for external writer (subsystem 0x0000)."""
    return create_type6_record_minimal(subsystem_id=0x0000)


def create_type6_record_jes3() -> bytes:
    """Create a Type 6 record for JES3 (subsystem 0x0005)."""
    return create_type6_record_minimal(subsystem_id=0x0005)


def create_type6_record_psf() -> bytes:
    """Create a Type 6 record for PSF (subsystem 0x0007)."""
    return create_type6_record_minimal(subsystem_id=0x0007)


def create_type6_record_ip_printway() -> bytes:
    """Create a Type 6 record for IP PrintWay (subsystem 0x0009)."""
    return create_type6_record_minimal(subsystem_id=0x0009)


def create_type6_record_invalid_type() -> bytes:
    """Create a record with wrong record type."""
    record = bytearray(create_type6_record_minimal())
    struct.pack_into('B', record, 5, 5)  # Wrong type (5 instead of 6)
    return bytes(record)


def create_type6_record_truncated() -> bytes:
    """Create a truncated Type 6 record."""
    record = create_type6_record_minimal()
    return record[:50]  # Truncate to 50 bytes


class TestSMF6ParserV3R2:
    """Unit tests for SMF Type 6 parser."""
    
    def test_parse_minimal_record_jes2(self):
        """Test parsing a minimal valid Type 6 record (JES2)."""
        record_data = create_type6_record_minimal(subsystem_id=0x0002)
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify standard header
        assert parsed.record_type == 6
        assert parsed.subtype == 0x0002  # JES2
        assert parsed.record_length == 300
        assert parsed.system_id == "SYS1"
        assert parsed.date is not None
        
        # Verify identification section
        assert parsed.identification is not None
        assert parsed.identification['job_name'].strip() == "TESTJOB"
        assert parsed.identification['user_id'].strip() == "USER1"
        
        # Verify performance (writer info) section
        assert parsed.performance is not None
        assert parsed.performance['sysout_class'].strip() == "A"
        assert parsed.performance['num_logical_records'] == 1000
        assert parsed.performance['num_datasets'] == 1
        assert parsed.performance['form_number'].strip() == "STD1"
        
        # Verify I/O activity section
        assert parsed.io_activity is not None
        assert parsed.io_activity['section_length'] == 30
        assert parsed.io_activity['job_number'].strip() == "0001"
        assert parsed.io_activity['output_device'].strip() == "PRINTER1"
        assert parsed.io_activity['fcb_image'].strip() == "FCB1"
        assert parsed.io_activity['ucs_image'].strip() == "UCS1"
        assert parsed.io_activity['page_count'] == 100  # JES2 has page count
        
        # Verify subsystem (common) section
        assert parsed.subsystem is not None
        assert parsed.subsystem['section_length'] == 38
        assert parsed.subsystem['route_code'] == 0x00010000
        assert parsed.subsystem['form_number'].strip() == "STD1"
        assert parsed.subsystem['job_id'].strip() == "JOB00001"
    
    def test_parse_external_writer(self):
        """Test parsing Type 6 record for external writer."""
        record_data = create_type6_record_external_writer()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify subsystem is external writer
        assert parsed.subtype == 0x0000
        
        # External writer should not have page count
        assert 'page_count' not in parsed.io_activity or parsed.io_activity.get('page_count') is None
    
    def test_parse_jes3(self):
        """Test parsing Type 6 record for JES3."""
        record_data = create_type6_record_jes3()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify subsystem is JES3
        assert parsed.subtype == 0x0005
        
        # JES3 should have page count
        assert parsed.io_activity['page_count'] == 100
    
    def test_parse_psf(self):
        """Test parsing Type 6 record for PSF."""
        record_data = create_type6_record_psf()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify subsystem is PSF
        assert parsed.subtype == 0x0007
    
    def test_parse_ip_printway(self):
        """Test parsing Type 6 record for IP PrintWay."""
        record_data = create_type6_record_ip_printway()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify subsystem is IP PrintWay
        assert parsed.subtype == 0x0009
    
    def test_parse_invalid_record_type(self):
        """Test error handling for invalid record type."""
        record_data = create_type6_record_invalid_type()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "expected 6" in str(exc_info.value)
    
    def test_parse_truncated_record(self):
        """Test error handling for truncated record."""
        record_data = create_type6_record_truncated()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(record_data)
        
        assert "Record length mismatch" in str(exc_info.value)
    
    def test_header_fields_extraction(self):
        """Test that all header fields are correctly extracted."""
        record_data = create_type6_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify all header fields are present
        header = parsed.header
        assert 'record_length' in header
        assert 'segment_descriptor' in header
        assert 'system_indicator' in header
        assert 'record_type' in header
        assert 'timestamp' in header
        assert 'date' in header
        assert 'system_id' in header
        assert 'job_name' in header
        assert 'reader_start_time' in header
        assert 'reader_start_date' in header
        assert 'user_id' in header
        assert 'sysout_class' in header
        assert 'writer_start_time' in header
        assert 'writer_start_date' in header
        assert 'num_logical_records' in header
        assert 'io_status' in header
        assert 'num_datasets' in header
        assert 'form_number' in header
        assert 'section_indicator' in header
        assert 'subsystem_id' in header
    
    def test_io_data_section_extraction(self):
        """Test that I/O data section fields are correctly extracted."""
        record_data = create_type6_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify all I/O data fields are present
        io_data = parsed.io_activity
        assert 'section_length' in io_data
        assert 'data_control_indicators' in io_data
        assert 'record_level_indicator' in io_data
        assert 'job_number' in io_data
        assert 'output_device' in io_data
        assert 'fcb_image' in io_data
        assert 'ucs_image' in io_data
    
    def test_common_section_extraction(self):
        """Test that common section fields are correctly extracted."""
        record_data = create_type6_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Verify common section is present
        assert parsed.subsystem is not None
        common = parsed.subsystem
        
        assert 'section_length' in common
        assert 'route_code' in common
        assert 'form_number' in common
        assert 'job_id' in common
    
    def test_to_dict_conversion(self):
        """Test conversion of parsed record to dictionary."""
        record_data = create_type6_record_minimal()
        
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF6ParserV3R2(base_parser)
        parsed = parser.parse(record_data)
        
        # Convert to dictionary
        record_dict = parsed.to_dict()
        
        # Verify dictionary structure
        assert isinstance(record_dict, dict)
        assert record_dict['record_type'] == 6
        assert record_dict['subtype'] == 0x0002
        assert 'header' in record_dict
        assert 'identification' in record_dict
        assert 'io_activity' in record_dict
        assert 'performance' in record_dict
        assert 'subsystem' in record_dict
