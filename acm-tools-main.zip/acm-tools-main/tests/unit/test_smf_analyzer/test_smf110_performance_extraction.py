#!/usr/bin/env python3
"""
Test cases for SMF Type 110 performance extraction.

This module tests the dictionary-based field extraction mechanism for CICS
performance monitoring data, including:
- Dictionary lookup mechanism
- Field connector interpretation
- Transaction ID extraction
- CPU time extraction
- Response time extraction
"""

import pytest
from tools.smf_analyzer.smf_record_parser.parsers.smf110_parser_v3r2 import SMF110ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser


class TestDictionaryLookup:
    """Test cases for dictionary lookup mechanism (Task 7.1.1)."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.base_parser = BaseRecordParser(encoding="EBCDIC")
        self.parser = SMF110ParserV3R2(self.base_parser)
    
    def test_build_dictionary_lookup_creates_mapping(self):
        """Test that build_dictionary_lookup creates correct connector-to-metadata mapping."""
        # Arrange: Create sample dictionary entries
        dictionary_entries = [
            {
                'field_owner': 'DFHTASK',
                'field_type': 'C',
                'field_id': '001',
                'field_length': 4,
                'field_connector': 100,
                'field_offset': 0,
                'field_title': 'TRAN'
            },
            {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '002',
                'field_length': 4,
                'field_connector': 101,
                'field_offset': 4,
                'field_title': 'CPU'
            }
        ]
        
        # Act: Build dictionary lookup
        lookup = self.parser.build_dictionary_lookup(dictionary_entries)
        
        # Assert: Verify lookup structure
        assert len(lookup) == 2
        assert 100 in lookup
        assert 101 in lookup
        
        # Verify first entry
        assert lookup[100]['field_owner'] == 'DFHTASK'
        assert lookup[100]['field_type'] == 'C'
        assert lookup[100]['field_id'] == '001'
        assert lookup[100]['field_length'] == 4
        assert lookup[100]['field_offset'] == 0
        assert lookup[100]['field_title'] == 'TRAN'
        assert lookup[100]['field_full_name'] == 'DFHTASK.C001'
        
        # Verify second entry
        assert lookup[101]['field_owner'] == 'DFHTASK'
        assert lookup[101]['field_type'] == 'B'
        assert lookup[101]['field_length'] == 4
        assert lookup[101]['field_full_name'] == 'DFHTASK.B002'
    
    def test_build_dictionary_lookup_handles_empty_entries(self):
        """Test that build_dictionary_lookup handles empty dictionary entries."""
        # Arrange: Empty dictionary
        dictionary_entries = []
        
        # Act: Build dictionary lookup
        lookup = self.parser.build_dictionary_lookup(dictionary_entries)
        
        # Assert: Verify empty lookup
        assert len(lookup) == 0
        assert isinstance(lookup, dict)
    
    def test_build_dictionary_lookup_handles_missing_connector(self):
        """Test that build_dictionary_lookup handles entries with missing connector."""
        # Arrange: Entry without field_connector
        dictionary_entries = [
            {
                'field_owner': 'DFHTASK',
                'field_type': 'C',
                'field_id': '001',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'TRAN'
                # Missing field_connector
            }
        ]
        
        # Act: Build dictionary lookup
        lookup = self.parser.build_dictionary_lookup(dictionary_entries)
        
        # Assert: Entry should not be in lookup
        assert len(lookup) == 0
    
    def test_build_dictionary_lookup_handles_duplicate_connectors(self):
        """Test that build_dictionary_lookup handles duplicate connectors (last wins)."""
        # Arrange: Entries with duplicate connectors
        dictionary_entries = [
            {
                'field_owner': 'DFHTASK',
                'field_type': 'C',
                'field_id': '001',
                'field_length': 4,
                'field_connector': 100,
                'field_offset': 0,
                'field_title': 'TRAN'
            },
            {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '002',
                'field_length': 8,
                'field_connector': 100,  # Duplicate
                'field_offset': 4,
                'field_title': 'CPU'
            }
        ]
        
        # Act: Build dictionary lookup
        lookup = self.parser.build_dictionary_lookup(dictionary_entries)
        
        # Assert: Last entry should win
        assert len(lookup) == 1
        assert lookup[100]['field_title'] == 'CPU'
        assert lookup[100]['field_length'] == 8


class TestFieldConnectorInterpretation:
    """Test cases for field connector interpretation (Task 7.1.2)."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.base_parser = BaseRecordParser(encoding="EBCDIC")
        self.parser = SMF110ParserV3R2(self.base_parser)
    
    def test_parse_field_connectors_extracts_values(self):
        """Test that parse_field_connectors extracts connector values correctly."""
        # Arrange: Create binary data with field connectors (2 bytes each)
        # Connectors: 100, 101, 102
        data = bytes([
            0x00, 0x64,  # 100
            0x00, 0x65,  # 101
            0x00, 0x66   # 102
        ])
        offset = 0
        length = 2
        count = 3
        
        # Act: Parse field connectors
        connectors = self.parser.parse_field_connectors(data, offset, length, count)
        
        # Assert: Verify connectors
        assert len(connectors) == 3
        assert connectors[0] == 100
        assert connectors[1] == 101
        assert connectors[2] == 102
    
    def test_parse_field_connectors_handles_single_byte_length(self):
        """Test that parse_field_connectors handles single-byte connectors."""
        # Arrange: Create binary data with single-byte connectors
        data = bytes([0x64, 0x65, 0x66])  # 100, 101, 102
        offset = 0
        length = 1
        count = 3
        
        # Act: Parse field connectors
        connectors = self.parser.parse_field_connectors(data, offset, length, count)
        
        # Assert: Verify connectors
        assert len(connectors) == 3
        assert connectors[0] == 100
        assert connectors[1] == 101
        assert connectors[2] == 102
    
    def test_parse_field_connectors_handles_four_byte_length(self):
        """Test that parse_field_connectors handles 4-byte connectors."""
        # Arrange: Create binary data with 4-byte connectors
        data = bytes([
            0x00, 0x00, 0x00, 0x64,  # 100
            0x00, 0x00, 0x00, 0x65   # 101
        ])
        offset = 0
        length = 4
        count = 2
        
        # Act: Parse field connectors
        connectors = self.parser.parse_field_connectors(data, offset, length, count)
        
        # Assert: Verify connectors
        assert len(connectors) == 2
        assert connectors[0] == 100
        assert connectors[1] == 101
    
    def test_interpret_field_value_at_offset_handles_character_type(self):
        """Test that interpret_field_value_at_offset correctly interprets character fields."""
        # Arrange: Create EBCDIC string "TEST" (4 bytes)
        # EBCDIC: T=0xE3, E=0xC5, S=0xE2, T=0xE3
        data = bytes([0xE3, 0xC5, 0xE2, 0xE3])
        absolute_offset = 0
        field_metadata = {
            'field_type': 'C',
            'field_length': 4,
            'field_title': 'TRAN'
        }
        
        # Act: Interpret field value
        value = self.parser.interpret_field_value_at_offset(data, absolute_offset, field_metadata)
        
        # Assert: Verify value
        assert value == 'TEST'
    
    def test_interpret_field_value_at_offset_handles_binary_type(self):
        """Test that interpret_field_value_at_offset correctly interprets binary fields."""
        # Arrange: Create binary value 1000 (4 bytes, big-endian)
        data = bytes([0x00, 0x00, 0x03, 0xE8])
        absolute_offset = 0
        field_metadata = {
            'field_type': 'B',
            'field_length': 4,
            'field_title': 'CPU'
        }
        
        # Act: Interpret field value
        value = self.parser.interpret_field_value_at_offset(data, absolute_offset, field_metadata)
        
        # Assert: Verify value
        assert value == 1000
    
    def test_interpret_field_value_at_offset_handles_signed_integer(self):
        """Test that interpret_field_value_at_offset correctly interprets signed integers."""
        # Arrange: Create signed integer -100 (4 bytes, two's complement)
        # -100 = 0xFFFFFF9C
        data = bytes([0xFF, 0xFF, 0xFF, 0x9C])
        absolute_offset = 0
        field_metadata = {
            'field_type': 'F',
            'field_length': 4,
            'field_title': 'DELTA'
        }
        
        # Act: Interpret field value
        value = self.parser.interpret_field_value_at_offset(data, absolute_offset, field_metadata)
        
        # Assert: Verify value
        assert value == -100


class TestTransactionIDExtraction:
    """Test cases for transaction ID extraction (Task 7.1.3)."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.base_parser = BaseRecordParser(encoding="EBCDIC")
        self.parser = SMF110ParserV3R2(self.base_parser)
    
    def test_extract_performance_fields_extracts_transaction_id(self):
        """Test that extract_performance_fields correctly extracts transaction ID."""
        # Arrange: Create test data with transaction ID "ACCT"
        # EBCDIC: A=0xC1, C=0xC3, C=0xC3, T=0xE3
        data = bytes([0xC1, 0xC3, 0xC3, 0xE3])
        record_offset = 0
        record_length = 4
        
        # Create field connectors and dictionary
        field_connectors = [100]
        dictionary_lookup = {
            100: {
                'field_owner': 'DFHTASK',
                'field_type': 'C',
                'field_id': '001',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'TRAN',
                'field_full_name': 'DFHTASK.C001'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify transaction ID is extracted
        assert 'tran_name' in fields
        assert fields['tran_name'] == 'ACCT'
    
    def test_extract_performance_fields_handles_tranid_field_title(self):
        """Test that extract_performance_fields recognizes TRANID as transaction ID."""
        # Arrange: Create test data
        data = bytes([0xC1, 0xC3, 0xC3, 0xE3])  # "ACCT"
        record_offset = 0
        record_length = 4
        
        # Create field connectors and dictionary with TRANID title
        field_connectors = [100]
        dictionary_lookup = {
            100: {
                'field_owner': 'DFHTASK',
                'field_type': 'C',
                'field_id': '001',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'TRANID',
                'field_full_name': 'DFHTASK.C001'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify transaction ID is extracted
        assert 'tran_name' in fields
        assert fields['tran_name'] == 'ACCT'


class TestCPUTimeExtraction:
    """Test cases for CPU time extraction (Task 7.1.4)."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.base_parser = BaseRecordParser(encoding="EBCDIC")
        self.parser = SMF110ParserV3R2(self.base_parser)
    
    def test_extract_performance_fields_extracts_cpu_time(self):
        """Test that extract_performance_fields correctly extracts CPU time."""
        # Arrange: Create test data with CPU time 50000 microseconds (4 bytes)
        data = bytes([0x00, 0x00, 0xC3, 0x50])  # 50000
        record_offset = 0
        record_length = 4
        
        # Create field connectors and dictionary
        field_connectors = [101]
        dictionary_lookup = {
            101: {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '002',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'CPU',
                'field_full_name': 'DFHTASK.B002'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify CPU time is extracted
        assert 'cpu_time' in fields
        assert fields['cpu_time'] == 50000
    
    def test_extract_performance_fields_handles_cputime_field_title(self):
        """Test that extract_performance_fields recognizes CPUTIME as CPU time."""
        # Arrange: Create test data
        data = bytes([0x00, 0x00, 0xC3, 0x50])  # 50000
        record_offset = 0
        record_length = 4
        
        # Create field connectors and dictionary with CPUTIME title
        field_connectors = [101]
        dictionary_lookup = {
            101: {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '002',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'CPUTIME',
                'field_full_name': 'DFHTASK.B002'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify CPU time is extracted
        assert 'cpu_time' in fields
        assert fields['cpu_time'] == 50000


class TestResponseTimeExtraction:
    """Test cases for response time extraction (Task 7.1.5)."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.base_parser = BaseRecordParser(encoding="EBCDIC")
        self.parser = SMF110ParserV3R2(self.base_parser)
    
    def test_extract_performance_fields_extracts_response_time(self):
        """Test that extract_performance_fields correctly extracts response time."""
        # Arrange: Create test data with response time 100000 microseconds (4 bytes)
        data = bytes([0x00, 0x01, 0x86, 0xA0])  # 100000
        record_offset = 0
        record_length = 4
        
        # Create field connectors and dictionary
        field_connectors = [102]
        dictionary_lookup = {
            102: {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '003',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'ELAPSED',
                'field_full_name': 'DFHTASK.B003'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify response time is extracted
        assert 'response_time' in fields
        assert fields['response_time'] == 100000
    
    def test_extract_performance_fields_handles_resptime_field_title(self):
        """Test that extract_performance_fields recognizes RESPTIME as response time."""
        # Arrange: Create test data
        data = bytes([0x00, 0x01, 0x86, 0xA0])  # 100000
        record_offset = 0
        record_length = 4
        
        # Create field connectors and dictionary with RESPTIME title
        field_connectors = [102]
        dictionary_lookup = {
            102: {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '003',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'RESPTIME',
                'field_full_name': 'DFHTASK.B003'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify response time is extracted
        assert 'response_time' in fields
        assert fields['response_time'] == 100000


class TestIntegratedPerformanceExtraction:
    """Integration tests for complete performance field extraction."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.base_parser = BaseRecordParser(encoding="EBCDIC")
        self.parser = SMF110ParserV3R2(self.base_parser)
    
    def test_extract_multiple_performance_fields(self):
        """Test extraction of multiple performance fields in sequence."""
        # Arrange: Create test data with transaction ID, CPU time, and response time
        # Transaction ID "ACCT" (4 bytes) + CPU time 50000 (4 bytes) + Response time 100000 (4 bytes)
        data = bytes([
            0xC1, 0xC3, 0xC3, 0xE3,  # "ACCT"
            0x00, 0x00, 0xC3, 0x50,  # 50000
            0x00, 0x01, 0x86, 0xA0   # 100000
        ])
        record_offset = 0
        record_length = 12
        
        # Create field connectors and dictionary
        field_connectors = [100, 101, 102]
        dictionary_lookup = {
            100: {
                'field_owner': 'DFHTASK',
                'field_type': 'C',
                'field_id': '001',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'TRAN',
                'field_full_name': 'DFHTASK.C001'
            },
            101: {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '002',
                'field_length': 4,
                'field_offset': 4,
                'field_title': 'CPU',
                'field_full_name': 'DFHTASK.B002'
            },
            102: {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '003',
                'field_length': 4,
                'field_offset': 8,
                'field_title': 'ELAPSED',
                'field_full_name': 'DFHTASK.B003'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify all fields are extracted
        assert 'tran_name' in fields
        assert fields['tran_name'] == 'ACCT'
        assert 'cpu_time' in fields
        assert fields['cpu_time'] == 50000
        assert 'response_time' in fields
        assert fields['response_time'] == 100000
    
    def test_extract_performance_fields_with_unmapped_fields(self):
        """Test that unmapped fields are stored with full name."""
        # Arrange: Create test data
        data = bytes([0x00, 0x00, 0x00, 0x64])  # 100
        record_offset = 0
        record_length = 4
        
        # Create field connectors and dictionary with unmapped field
        field_connectors = [999]
        dictionary_lookup = {
            999: {
                'field_owner': 'DFHCUST',
                'field_type': 'B',
                'field_id': '999',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'CUSTOM',
                'field_full_name': 'DFHCUST.B999'
            }
        }
        
        # Act: Extract performance fields
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify unmapped field is stored with full name
        assert 'DFHCUST.B999' in fields
        assert fields['DFHCUST.B999'] == 100
    
    def test_extract_performance_fields_handles_missing_dictionary_entry(self):
        """Test that missing dictionary entries are handled gracefully."""
        # Arrange: Create test data
        data = bytes([0x00, 0x00, 0x00, 0x64])  # 100
        record_offset = 0
        record_length = 4
        
        # Create field connectors with missing dictionary entry
        field_connectors = [100, 999]  # 999 not in dictionary
        dictionary_lookup = {
            100: {
                'field_owner': 'DFHTASK',
                'field_type': 'B',
                'field_id': '001',
                'field_length': 4,
                'field_offset': 0,
                'field_title': 'CPU',
                'field_full_name': 'DFHTASK.B001'
            }
        }
        
        # Act: Extract performance fields (should not raise exception)
        fields = self.parser.extract_performance_fields(
            data, record_offset, record_length, field_connectors, dictionary_lookup
        )
        
        # Assert: Verify only mapped field is extracted
        assert 'cpu_time' in fields
        assert fields['cpu_time'] == 100


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
