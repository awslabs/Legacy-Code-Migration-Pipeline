"""Unit tests for DB2 query helper functions.

This module tests the helper functions used in DB2 queries for time conversions,
ratio calculations, and classification logic. These functions are typically embedded
in SQL queries but are tested here with Python equivalents to ensure correctness.

Test Coverage:
- Time conversion functions (microseconds to seconds, hours)
- Ratio calculation functions (hit ratio, abort ratio, suspension ratio)
- Classification logic (read-heavy vs write-heavy, complexity categorization)
- NULL value handling
- Division by zero handling
- Negative value handling
"""

import pytest
from typing import Optional


# ============================================================================
# Time Conversion Helper Functions
# ============================================================================

def microseconds_to_seconds(microseconds: Optional[int]) -> Optional[float]:
    """Convert microseconds to seconds.
    
    This function mimics the SQL conversion: accumulated_cpu_in_db2 / 1000000.0
    
    Args:
        microseconds: Time value in microseconds (can be None)
        
    Returns:
        Time value in seconds, or None if input is None
    """
    if microseconds is None:
        return None
    return microseconds / 1000000.0


def microseconds_to_hours(microseconds: Optional[int]) -> Optional[float]:
    """Convert microseconds to hours.
    
    This function mimics the SQL conversion: accumulated_cpu_in_db2 / 1000000.0 / 3600.0
    
    Args:
        microseconds: Time value in microseconds (can be None)
        
    Returns:
        Time value in hours, or None if input is None
    """
    if microseconds is None:
        return None
    return microseconds / 1000000.0 / 3600.0


def seconds_to_hours(seconds: Optional[float]) -> Optional[float]:
    """Convert seconds to hours.
    
    This function mimics the SQL conversion: cpu_seconds / 3600.0
    
    Args:
        seconds: Time value in seconds (can be None)
        
    Returns:
        Time value in hours, or None if input is None
    """
    if seconds is None:
        return None
    return seconds / 3600.0


# ============================================================================
# Time Conversion Tests
# ============================================================================

class TestTimeConversionFunctions:
    """Test time conversion helper functions."""
    
    def test_microseconds_to_seconds_positive_value(self):
        """Test microseconds to seconds conversion with positive value."""
        # 1,000,000 microseconds = 1 second
        assert microseconds_to_seconds(1000000) == 1.0
        
        # 5,000,000 microseconds = 5 seconds
        assert microseconds_to_seconds(5000000) == 5.0
        
        # 500,000 microseconds = 0.5 seconds
        assert microseconds_to_seconds(500000) == 0.5
    
    def test_microseconds_to_seconds_zero(self):
        """Test microseconds to seconds conversion with zero."""
        assert microseconds_to_seconds(0) == 0.0
    
    def test_microseconds_to_seconds_null_value(self):
        """Test microseconds to seconds conversion with NULL value."""
        assert microseconds_to_seconds(None) is None
    
    def test_microseconds_to_seconds_negative_value(self):
        """Test microseconds to seconds conversion with negative value.
        
        Negative values should be handled (converted) even though they may
        indicate data quality issues. The conversion logic itself is valid.
        """
        # -1,000,000 microseconds = -1 second
        assert microseconds_to_seconds(-1000000) == -1.0
    
    def test_microseconds_to_seconds_large_value(self):
        """Test microseconds to seconds conversion with large value."""
        # 1 hour = 3,600,000,000 microseconds = 3,600 seconds
        assert microseconds_to_seconds(3600000000) == 3600.0
    
    def test_microseconds_to_hours_positive_value(self):
        """Test microseconds to hours conversion with positive value."""
        # 3,600,000,000 microseconds = 1 hour
        assert microseconds_to_hours(3600000000) == 1.0
        
        # 7,200,000,000 microseconds = 2 hours
        assert microseconds_to_hours(7200000000) == 2.0
        
        # 1,800,000,000 microseconds = 0.5 hours
        assert microseconds_to_hours(1800000000) == 0.5
    
    def test_microseconds_to_hours_zero(self):
        """Test microseconds to hours conversion with zero."""
        assert microseconds_to_hours(0) == 0.0
    
    def test_microseconds_to_hours_null_value(self):
        """Test microseconds to hours conversion with NULL value."""
        assert microseconds_to_hours(None) is None
    
    def test_microseconds_to_hours_negative_value(self):
        """Test microseconds to hours conversion with negative value."""
        # -3,600,000,000 microseconds = -1 hour
        assert microseconds_to_hours(-3600000000) == -1.0
    
    def test_seconds_to_hours_positive_value(self):
        """Test seconds to hours conversion with positive value."""
        # 3,600 seconds = 1 hour
        assert seconds_to_hours(3600.0) == 1.0
        
        # 7,200 seconds = 2 hours
        assert seconds_to_hours(7200.0) == 2.0
        
        # 1,800 seconds = 0.5 hours
        assert seconds_to_hours(1800.0) == 0.5
    
    def test_seconds_to_hours_zero(self):
        """Test seconds to hours conversion with zero."""
        assert seconds_to_hours(0.0) == 0.0
    
    def test_seconds_to_hours_null_value(self):
        """Test seconds to hours conversion with NULL value."""
        assert seconds_to_hours(None) is None
    
    def test_seconds_to_hours_negative_value(self):
        """Test seconds to hours conversion with negative value."""
        # -3,600 seconds = -1 hour
        assert seconds_to_hours(-3600.0) == -1.0
    
    def test_time_conversion_precision(self):
        """Test time conversion maintains precision."""
        # Test with fractional microseconds
        microseconds = 1234567
        seconds = microseconds_to_seconds(microseconds)
        assert abs(seconds - 1.234567) < 1e-9
        
        # Test with fractional seconds
        seconds = 1234.567
        hours = seconds_to_hours(seconds)
        assert abs(hours - 0.34293527777777777) < 1e-9
    
    def test_time_conversion_chain(self):
        """Test chaining time conversions."""
        # Convert microseconds -> seconds -> hours
        microseconds = 3600000000  # 1 hour
        seconds = microseconds_to_seconds(microseconds)
        hours = seconds_to_hours(seconds)
        assert hours == 1.0
        
        # Should equal direct conversion
        direct_hours = microseconds_to_hours(microseconds)
        assert hours == direct_hours



# ============================================================================
# Ratio Calculation Helper Functions
# ============================================================================

def calculate_hit_ratio(getpage_requests: Optional[int], sync_read_io: Optional[int]) -> Optional[float]:
    """Calculate buffer pool hit ratio.
    
    This function mimics the SQL calculation:
    (getpage_requests - sync_read_io) * 100.0 / NULLIF(getpage_requests, 0)
    
    Hit ratio represents the percentage of page requests satisfied from buffer pool
    without requiring disk I/O. Higher is better (less disk I/O).
    
    Args:
        getpage_requests: Total getpage requests
        sync_read_io: Synchronous read I/O operations
        
    Returns:
        Hit ratio as percentage (0-100), or None if calculation is not possible
    """
    if getpage_requests is None or sync_read_io is None:
        return None
    if getpage_requests == 0:
        return None
    
    # Hit ratio = (requests satisfied from cache) / total requests * 100
    hit_ratio = (getpage_requests - sync_read_io) * 100.0 / getpage_requests
    
    # Clamp to valid range [0, 100]
    return max(0.0, min(100.0, hit_ratio))


def calculate_abort_ratio(commit_count: Optional[int], abort_count: Optional[int]) -> Optional[float]:
    """Calculate transaction abort ratio.
    
    This function mimics the SQL calculation:
    abort_count * 1.0 / NULLIF(commit_count + abort_count, 0)
    
    Abort ratio represents the percentage of transactions that were aborted
    (rolled back) rather than committed. Lower is better.
    
    Args:
        commit_count: Number of committed transactions
        abort_count: Number of aborted transactions
        
    Returns:
        Abort ratio as decimal (0-1), or None if calculation is not possible
    """
    if commit_count is None or abort_count is None:
        return None
    
    total_transactions = commit_count + abort_count
    if total_transactions == 0:
        return None
    
    abort_ratio = abort_count * 1.0 / total_transactions
    
    # Clamp to valid range [0, 1]
    return max(0.0, min(1.0, abort_ratio))


def calculate_suspension_ratio(latch_requests: Optional[int], latch_suspensions: Optional[int]) -> Optional[float]:
    """Calculate latch suspension ratio.
    
    This function mimics the SQL calculation:
    latch_suspensions * 1.0 / NULLIF(latch_requests, 0)
    
    Suspension ratio represents the percentage of latch requests that resulted
    in suspensions (contention). Lower is better.
    
    Args:
        latch_requests: Total latch requests
        latch_suspensions: Number of latch suspensions
        
    Returns:
        Suspension ratio as decimal (0-1), or None if calculation is not possible
    """
    if latch_requests is None or latch_suspensions is None:
        return None
    if latch_requests == 0:
        return None
    
    suspension_ratio = latch_suspensions * 1.0 / latch_requests
    
    # Clamp to valid range [0, 1]
    return max(0.0, min(1.0, suspension_ratio))


def calculate_read_write_percentages(sync_read_io: Optional[int], sync_write_io: Optional[int]) -> tuple[Optional[float], Optional[float]]:
    """Calculate read and write percentages.
    
    This function mimics the SQL calculations:
    read_pct = sync_read_io * 100.0 / NULLIF(sync_read_io + sync_write_io, 0)
    write_pct = sync_write_io * 100.0 / NULLIF(sync_read_io + sync_write_io, 0)
    
    Args:
        sync_read_io: Synchronous read I/O operations
        sync_write_io: Synchronous write I/O operations
        
    Returns:
        Tuple of (read_percentage, write_percentage), or (None, None) if calculation is not possible
    """
    if sync_read_io is None or sync_write_io is None:
        return (None, None)
    
    total_io = sync_read_io + sync_write_io
    if total_io == 0:
        return (None, None)
    
    read_pct = sync_read_io * 100.0 / total_io
    write_pct = sync_write_io * 100.0 / total_io
    
    return (read_pct, write_pct)


# ============================================================================
# Ratio Calculation Tests
# ============================================================================

class TestRatioCalculationFunctions:
    """Test ratio calculation helper functions."""
    
    # Hit Ratio Tests
    def test_hit_ratio_perfect_cache(self):
        """Test hit ratio with perfect cache (no disk reads)."""
        # All requests satisfied from cache
        assert calculate_hit_ratio(1000, 0) == 100.0
    
    def test_hit_ratio_no_cache(self):
        """Test hit ratio with no cache hits (all disk reads)."""
        # All requests require disk I/O
        assert calculate_hit_ratio(1000, 1000) == 0.0
    
    def test_hit_ratio_partial_cache(self):
        """Test hit ratio with partial cache hits."""
        # 90% hit ratio: 1000 requests, 100 disk reads
        assert calculate_hit_ratio(1000, 100) == 90.0
        
        # 50% hit ratio: 1000 requests, 500 disk reads
        assert calculate_hit_ratio(1000, 500) == 50.0
    
    def test_hit_ratio_division_by_zero(self):
        """Test hit ratio with zero getpage requests."""
        # Division by zero should return None
        assert calculate_hit_ratio(0, 0) is None
        assert calculate_hit_ratio(0, 100) is None
    
    def test_hit_ratio_null_values(self):
        """Test hit ratio with NULL values."""
        assert calculate_hit_ratio(None, 100) is None
        assert calculate_hit_ratio(1000, None) is None
        assert calculate_hit_ratio(None, None) is None
    
    def test_hit_ratio_bounds(self):
        """Test hit ratio stays within valid bounds [0, 100]."""
        # Normal case
        ratio = calculate_hit_ratio(1000, 200)
        assert 0.0 <= ratio <= 100.0
        
        # Edge case: more reads than requests (data quality issue)
        # Should clamp to 0
        ratio = calculate_hit_ratio(100, 200)
        assert ratio == 0.0
    
    # Abort Ratio Tests
    def test_abort_ratio_no_aborts(self):
        """Test abort ratio with no aborts."""
        # All transactions committed
        assert calculate_abort_ratio(1000, 0) == 0.0
    
    def test_abort_ratio_all_aborts(self):
        """Test abort ratio with all aborts."""
        # All transactions aborted
        assert calculate_abort_ratio(0, 1000) == 1.0
    
    def test_abort_ratio_partial_aborts(self):
        """Test abort ratio with partial aborts."""
        # 10% abort ratio: 900 commits, 100 aborts
        assert calculate_abort_ratio(900, 100) == 0.1
        
        # 50% abort ratio: 500 commits, 500 aborts
        assert calculate_abort_ratio(500, 500) == 0.5
    
    def test_abort_ratio_division_by_zero(self):
        """Test abort ratio with zero transactions."""
        # Division by zero should return None
        assert calculate_abort_ratio(0, 0) is None
    
    def test_abort_ratio_null_values(self):
        """Test abort ratio with NULL values."""
        assert calculate_abort_ratio(None, 100) is None
        assert calculate_abort_ratio(1000, None) is None
        assert calculate_abort_ratio(None, None) is None
    
    def test_abort_ratio_bounds(self):
        """Test abort ratio stays within valid bounds [0, 1]."""
        # Normal case
        ratio = calculate_abort_ratio(900, 100)
        assert 0.0 <= ratio <= 1.0
        
        # Edge cases
        ratio = calculate_abort_ratio(1000, 0)
        assert ratio == 0.0
        
        ratio = calculate_abort_ratio(0, 1000)
        assert ratio == 1.0
    
    # Suspension Ratio Tests
    def test_suspension_ratio_no_suspensions(self):
        """Test suspension ratio with no suspensions."""
        # All latch requests granted immediately
        assert calculate_suspension_ratio(1000, 0) == 0.0
    
    def test_suspension_ratio_all_suspensions(self):
        """Test suspension ratio with all suspensions."""
        # All latch requests suspended
        assert calculate_suspension_ratio(1000, 1000) == 1.0
    
    def test_suspension_ratio_partial_suspensions(self):
        """Test suspension ratio with partial suspensions."""
        # 10% suspension ratio: 1000 requests, 100 suspensions
        assert calculate_suspension_ratio(1000, 100) == 0.1
        
        # 25% suspension ratio: 1000 requests, 250 suspensions
        assert calculate_suspension_ratio(1000, 250) == 0.25
    
    def test_suspension_ratio_division_by_zero(self):
        """Test suspension ratio with zero requests."""
        # Division by zero should return None
        assert calculate_suspension_ratio(0, 0) is None
        assert calculate_suspension_ratio(0, 100) is None
    
    def test_suspension_ratio_null_values(self):
        """Test suspension ratio with NULL values."""
        assert calculate_suspension_ratio(None, 100) is None
        assert calculate_suspension_ratio(1000, None) is None
        assert calculate_suspension_ratio(None, None) is None
    
    def test_suspension_ratio_bounds(self):
        """Test suspension ratio stays within valid bounds [0, 1]."""
        # Normal case
        ratio = calculate_suspension_ratio(1000, 100)
        assert 0.0 <= ratio <= 1.0
        
        # Edge case: more suspensions than requests (data quality issue)
        # Should clamp to 1.0
        ratio = calculate_suspension_ratio(100, 200)
        assert ratio == 1.0
    
    # Read/Write Percentage Tests
    def test_read_write_percentages_read_only(self):
        """Test read/write percentages with read-only workload."""
        read_pct, write_pct = calculate_read_write_percentages(1000, 0)
        assert read_pct == 100.0
        assert write_pct == 0.0
    
    def test_read_write_percentages_write_only(self):
        """Test read/write percentages with write-only workload."""
        read_pct, write_pct = calculate_read_write_percentages(0, 1000)
        assert read_pct == 0.0
        assert write_pct == 100.0
    
    def test_read_write_percentages_balanced(self):
        """Test read/write percentages with balanced workload."""
        read_pct, write_pct = calculate_read_write_percentages(500, 500)
        assert read_pct == 50.0
        assert write_pct == 50.0
    
    def test_read_write_percentages_read_heavy(self):
        """Test read/write percentages with read-heavy workload."""
        read_pct, write_pct = calculate_read_write_percentages(700, 300)
        assert read_pct == 70.0
        assert write_pct == 30.0
    
    def test_read_write_percentages_write_heavy(self):
        """Test read/write percentages with write-heavy workload."""
        read_pct, write_pct = calculate_read_write_percentages(300, 700)
        assert read_pct == 30.0
        assert write_pct == 70.0
    
    def test_read_write_percentages_division_by_zero(self):
        """Test read/write percentages with zero I/O."""
        read_pct, write_pct = calculate_read_write_percentages(0, 0)
        assert read_pct is None
        assert write_pct is None
    
    def test_read_write_percentages_null_values(self):
        """Test read/write percentages with NULL values."""
        read_pct, write_pct = calculate_read_write_percentages(None, 100)
        assert read_pct is None
        assert write_pct is None
        
        read_pct, write_pct = calculate_read_write_percentages(100, None)
        assert read_pct is None
        assert write_pct is None
        
        read_pct, write_pct = calculate_read_write_percentages(None, None)
        assert read_pct is None
        assert write_pct is None
    
    def test_read_write_percentages_sum_to_100(self):
        """Test read/write percentages sum to 100%."""
        read_pct, write_pct = calculate_read_write_percentages(700, 300)
        assert abs((read_pct + write_pct) - 100.0) < 1e-9
        
        read_pct, write_pct = calculate_read_write_percentages(123, 456)
        assert abs((read_pct + write_pct) - 100.0) < 1e-9



# ============================================================================
# Classification Helper Functions
# ============================================================================

def classify_workload_type(read_percentage: Optional[float], 
                          read_heavy_threshold: float = 70.0,
                          write_heavy_threshold: float = 30.0) -> Optional[str]:
    """Classify workload as read-heavy, write-heavy, or balanced.
    
    This function mimics the SQL classification:
    CASE 
        WHEN read_percentage >= 70 THEN 'Read-Heavy'
        WHEN write_percentage >= 30 THEN 'Write-Heavy'
        ELSE 'Balanced'
    END
    
    Note: The write_heavy_threshold is the minimum write percentage (not read percentage).
    For example, if write_heavy_threshold=30, then write percentage >= 30% is write-heavy,
    which means read percentage <= 70%.
    
    Args:
        read_percentage: Percentage of read operations (0-100)
        read_heavy_threshold: Threshold for read-heavy classification (default: 70.0)
        write_heavy_threshold: Minimum write percentage for write-heavy classification (default: 30.0)
        
    Returns:
        Workload classification: 'Read-Heavy', 'Write-Heavy', or 'Balanced'
    """
    if read_percentage is None:
        return None
    
    write_percentage = 100.0 - read_percentage
    
    # Check read-heavy first (higher priority)
    if read_percentage >= read_heavy_threshold:
        return 'Read-Heavy'
    # Check write-heavy (write percentage >= threshold)
    elif write_percentage >= write_heavy_threshold:
        return 'Write-Heavy'
    else:
        return 'Balanced'


def classify_complexity_category(complexity_score: Optional[float],
                                threshold_low: float = 60.0,
                                threshold_medium: float = 120.0,
                                threshold_high: float = 240.0) -> Optional[str]:
    """Classify migration complexity based on score.
    
    This function mimics the SQL classification:
    CASE 
        WHEN complexity_score < 60 THEN 'Low'
        WHEN complexity_score < 120 THEN 'Medium'
        WHEN complexity_score < 240 THEN 'High'
        ELSE 'Very High'
    END
    
    Args:
        complexity_score: Complexity score in hours
        threshold_low: Threshold for Low complexity (default: 60.0)
        threshold_medium: Threshold for Medium complexity (default: 120.0)
        threshold_high: Threshold for High complexity (default: 240.0)
        
    Returns:
        Complexity category: 'Low', 'Medium', 'High', or 'Very High'
    """
    if complexity_score is None:
        return None
    
    if complexity_score < threshold_low:
        return 'Low'
    elif complexity_score < threshold_medium:
        return 'Medium'
    elif complexity_score < threshold_high:
        return 'High'
    else:
        return 'Very High'


def classify_migration_wave(priority_score: Optional[float]) -> Optional[str]:
    """Classify migration wave based on priority score.
    
    This function mimics the SQL classification:
    CASE 
        WHEN priority_score >= 75 THEN 'Wave 1 - High Priority'
        WHEN priority_score >= 50 THEN 'Wave 2 - Medium Priority'
        WHEN priority_score >= 25 THEN 'Wave 3 - Low Priority'
        ELSE 'Wave 4 - Very Low Priority'
    END
    
    Args:
        priority_score: Priority score (0-100)
        
    Returns:
        Migration wave classification
    """
    if priority_score is None:
        return None
    
    if priority_score >= 75:
        return 'Wave 1 - High Priority'
    elif priority_score >= 50:
        return 'Wave 2 - Medium Priority'
    elif priority_score >= 25:
        return 'Wave 3 - Low Priority'
    else:
        return 'Wave 4 - Very Low Priority'


def classify_storage_type(read_percentage: Optional[float],
                         write_percentage: Optional[float]) -> Optional[str]:
    """Recommend storage type based on access patterns.
    
    This function mimics the SQL classification:
    CASE 
        WHEN read_percentage >= 70 THEN 'GP3'
        WHEN write_percentage >= 40 THEN 'IO2'
        ELSE 'GP3'
    END
    
    Args:
        read_percentage: Percentage of read operations (0-100)
        write_percentage: Percentage of write operations (0-100)
        
    Returns:
        Recommended storage type: 'GP3' or 'IO2'
    """
    if read_percentage is None or write_percentage is None:
        return None
    
    if read_percentage >= 70:
        return 'GP3'
    elif write_percentage >= 40:
        return 'IO2'
    else:
        return 'GP3'


def classify_instance_type(required_vcpus: Optional[float]) -> Optional[str]:
    """Recommend RDS instance type based on vCPU requirements.
    
    This function mimics the SQL classification:
    CASE 
        WHEN required_vcpus <= 2 THEN 'm6i.large'
        WHEN required_vcpus <= 4 THEN 'm6i.xlarge'
        WHEN required_vcpus <= 8 THEN 'm6i.2xlarge'
        ELSE 'm6i.4xlarge'
    END
    
    Args:
        required_vcpus: Required vCPU count
        
    Returns:
        Recommended RDS instance type
    """
    if required_vcpus is None:
        return None
    
    if required_vcpus <= 2:
        return 'm6i.large'
    elif required_vcpus <= 4:
        return 'm6i.xlarge'
    elif required_vcpus <= 8:
        return 'm6i.2xlarge'
    else:
        return 'm6i.4xlarge'


# ============================================================================
# Classification Logic Tests
# ============================================================================

class TestClassificationLogic:
    """Test classification helper functions."""
    
    # Workload Type Classification Tests
    def test_classify_workload_read_heavy(self):
        """Test workload classification for read-heavy workloads."""
        # 70% read = read-heavy (threshold)
        assert classify_workload_type(70.0) == 'Read-Heavy'
        
        # 80% read = read-heavy
        assert classify_workload_type(80.0) == 'Read-Heavy'
        
        # 100% read = read-heavy
        assert classify_workload_type(100.0) == 'Read-Heavy'
    
    def test_classify_workload_write_heavy(self):
        """Test workload classification for write-heavy workloads."""
        # 30% read = 70% write = write-heavy (threshold)
        assert classify_workload_type(30.0) == 'Write-Heavy'
        
        # 20% read = 80% write = write-heavy
        assert classify_workload_type(20.0) == 'Write-Heavy'
        
        # 0% read = 100% write = write-heavy
        assert classify_workload_type(0.0) == 'Write-Heavy'
    
    def test_classify_workload_balanced(self):
        """Test workload classification for balanced workloads."""
        # For a workload to be balanced, it must have:
        # - read_percentage < read_heavy_threshold (not read-heavy)
        # - write_percentage < write_heavy_threshold (not write-heavy)
        # With default thresholds (read_heavy=70, write_heavy=30):
        # - read >= 70: Read-Heavy
        # - read < 70 means write > 30: Write-Heavy
        # There is no "Balanced" range with these thresholds.
        
        # To get balanced, we need custom thresholds with a gap
        # For example: read_heavy=80, write_heavy=40
        # - read >= 80: Read-Heavy
        # - write >= 40 (read <= 60): Write-Heavy
        # - 60 < read < 80: Balanced
        assert classify_workload_type(65.0, read_heavy_threshold=80.0, write_heavy_threshold=40.0) == 'Balanced'
        assert classify_workload_type(70.0, read_heavy_threshold=80.0, write_heavy_threshold=40.0) == 'Balanced'
        assert classify_workload_type(75.0, read_heavy_threshold=80.0, write_heavy_threshold=40.0) == 'Balanced'
    
    def test_classify_workload_boundary_conditions(self):
        """Test workload classification at boundary conditions."""
        # With default thresholds (read_heavy=70, write_heavy=30):
        # read >= 70: Read-Heavy
        # read < 70 (write > 30): Write-Heavy
        
        # Just below read-heavy threshold (69.9% read = 30.1% write)
        # Since write > 30%, this is Write-Heavy
        assert classify_workload_type(69.9) == 'Write-Heavy'
        
        # Just at read-heavy threshold
        assert classify_workload_type(70.0) == 'Read-Heavy'
        
        # Just at write-heavy threshold (70% read = 30% write)
        # Read-heavy takes precedence (checked first)
        assert classify_workload_type(70.0) == 'Read-Heavy'
        
        # Just above write-heavy threshold (69% read = 31% write)
        assert classify_workload_type(69.0) == 'Write-Heavy'
    
    def test_classify_workload_null_value(self):
        """Test workload classification with NULL value."""
        assert classify_workload_type(None) is None
    
    def test_classify_workload_custom_thresholds(self):
        """Test workload classification with custom thresholds."""
        # Custom thresholds: read_heavy=80, write_heavy=20
        # read >= 80: Read-Heavy
        # read < 80 and write >= 20 (read <= 80): Write-Heavy
        # This still has no balanced range!
        
        assert classify_workload_type(85.0, read_heavy_threshold=80.0, write_heavy_threshold=20.0) == 'Read-Heavy'
        assert classify_workload_type(75.0, read_heavy_threshold=80.0, write_heavy_threshold=20.0) == 'Write-Heavy'
        assert classify_workload_type(15.0, read_heavy_threshold=80.0, write_heavy_threshold=20.0) == 'Write-Heavy'
        
        # To get a balanced range, we need thresholds that create a gap
        # For example: read_heavy=70, write_heavy=50 (which means read <= 50)
        # Then 50 < read < 70 would be balanced
        assert classify_workload_type(60.0, read_heavy_threshold=70.0, write_heavy_threshold=50.0) == 'Balanced'
        assert classify_workload_type(55.0, read_heavy_threshold=70.0, write_heavy_threshold=50.0) == 'Balanced'
    
    # Complexity Category Classification Tests
    def test_classify_complexity_low(self):
        """Test complexity classification for low complexity."""
        # Below threshold
        assert classify_complexity_category(30.0) == 'Low'
        assert classify_complexity_category(59.9) == 'Low'
    
    def test_classify_complexity_medium(self):
        """Test complexity classification for medium complexity."""
        # At or above low threshold, below medium threshold
        assert classify_complexity_category(60.0) == 'Medium'
        assert classify_complexity_category(90.0) == 'Medium'
        assert classify_complexity_category(119.9) == 'Medium'
    
    def test_classify_complexity_high(self):
        """Test complexity classification for high complexity."""
        # At or above medium threshold, below high threshold
        assert classify_complexity_category(120.0) == 'High'
        assert classify_complexity_category(180.0) == 'High'
        assert classify_complexity_category(239.9) == 'High'
    
    def test_classify_complexity_very_high(self):
        """Test complexity classification for very high complexity."""
        # At or above high threshold
        assert classify_complexity_category(240.0) == 'Very High'
        assert classify_complexity_category(500.0) == 'Very High'
    
    def test_classify_complexity_boundary_conditions(self):
        """Test complexity classification at boundary conditions."""
        # Just below low threshold
        assert classify_complexity_category(59.9) == 'Low'
        
        # Just at low threshold
        assert classify_complexity_category(60.0) == 'Medium'
        
        # Just below medium threshold
        assert classify_complexity_category(119.9) == 'Medium'
        
        # Just at medium threshold
        assert classify_complexity_category(120.0) == 'High'
        
        # Just below high threshold
        assert classify_complexity_category(239.9) == 'High'
        
        # Just at high threshold
        assert classify_complexity_category(240.0) == 'Very High'
    
    def test_classify_complexity_null_value(self):
        """Test complexity classification with NULL value."""
        assert classify_complexity_category(None) is None
    
    def test_classify_complexity_custom_thresholds(self):
        """Test complexity classification with custom thresholds."""
        # Custom thresholds: low=40, medium=80, high=160
        assert classify_complexity_category(30.0, threshold_low=40.0, threshold_medium=80.0, threshold_high=160.0) == 'Low'
        assert classify_complexity_category(50.0, threshold_low=40.0, threshold_medium=80.0, threshold_high=160.0) == 'Medium'
        assert classify_complexity_category(100.0, threshold_low=40.0, threshold_medium=80.0, threshold_high=160.0) == 'High'
        assert classify_complexity_category(200.0, threshold_low=40.0, threshold_medium=80.0, threshold_high=160.0) == 'Very High'
    
    # Migration Wave Classification Tests
    def test_classify_migration_wave_1(self):
        """Test migration wave classification for Wave 1."""
        # High priority (>= 75)
        assert classify_migration_wave(75.0) == 'Wave 1 - High Priority'
        assert classify_migration_wave(85.0) == 'Wave 1 - High Priority'
        assert classify_migration_wave(100.0) == 'Wave 1 - High Priority'
    
    def test_classify_migration_wave_2(self):
        """Test migration wave classification for Wave 2."""
        # Medium priority (>= 50, < 75)
        assert classify_migration_wave(50.0) == 'Wave 2 - Medium Priority'
        assert classify_migration_wave(60.0) == 'Wave 2 - Medium Priority'
        assert classify_migration_wave(74.9) == 'Wave 2 - Medium Priority'
    
    def test_classify_migration_wave_3(self):
        """Test migration wave classification for Wave 3."""
        # Low priority (>= 25, < 50)
        assert classify_migration_wave(25.0) == 'Wave 3 - Low Priority'
        assert classify_migration_wave(35.0) == 'Wave 3 - Low Priority'
        assert classify_migration_wave(49.9) == 'Wave 3 - Low Priority'
    
    def test_classify_migration_wave_4(self):
        """Test migration wave classification for Wave 4."""
        # Very low priority (< 25)
        assert classify_migration_wave(0.0) == 'Wave 4 - Very Low Priority'
        assert classify_migration_wave(10.0) == 'Wave 4 - Very Low Priority'
        assert classify_migration_wave(24.9) == 'Wave 4 - Very Low Priority'
    
    def test_classify_migration_wave_boundary_conditions(self):
        """Test migration wave classification at boundary conditions."""
        # Just below Wave 1 threshold
        assert classify_migration_wave(74.9) == 'Wave 2 - Medium Priority'
        
        # Just at Wave 1 threshold
        assert classify_migration_wave(75.0) == 'Wave 1 - High Priority'
        
        # Just below Wave 2 threshold
        assert classify_migration_wave(49.9) == 'Wave 3 - Low Priority'
        
        # Just at Wave 2 threshold
        assert classify_migration_wave(50.0) == 'Wave 2 - Medium Priority'
        
        # Just below Wave 3 threshold
        assert classify_migration_wave(24.9) == 'Wave 4 - Very Low Priority'
        
        # Just at Wave 3 threshold
        assert classify_migration_wave(25.0) == 'Wave 3 - Low Priority'
    
    def test_classify_migration_wave_null_value(self):
        """Test migration wave classification with NULL value."""
        assert classify_migration_wave(None) is None
    
    # Storage Type Classification Tests
    def test_classify_storage_type_gp3_read_heavy(self):
        """Test storage type classification for read-heavy workloads."""
        # Read-heavy workloads use GP3
        assert classify_storage_type(70.0, 30.0) == 'GP3'
        assert classify_storage_type(80.0, 20.0) == 'GP3'
        assert classify_storage_type(100.0, 0.0) == 'GP3'
    
    def test_classify_storage_type_io2_write_heavy(self):
        """Test storage type classification for write-heavy workloads."""
        # Write-heavy workloads (>= 40% write) use IO2
        assert classify_storage_type(60.0, 40.0) == 'IO2'
        assert classify_storage_type(50.0, 50.0) == 'IO2'
        assert classify_storage_type(20.0, 80.0) == 'IO2'
    
    def test_classify_storage_type_gp3_balanced(self):
        """Test storage type classification for balanced workloads."""
        # Balanced workloads default to GP3
        assert classify_storage_type(65.0, 35.0) == 'GP3'
        assert classify_storage_type(62.0, 38.0) == 'GP3'
    
    def test_classify_storage_type_boundary_conditions(self):
        """Test storage type classification at boundary conditions."""
        # Just below write-heavy threshold (40% write)
        assert classify_storage_type(60.1, 39.9) == 'GP3'
        
        # Just at write-heavy threshold
        assert classify_storage_type(60.0, 40.0) == 'IO2'
        
        # Just at read-heavy threshold
        assert classify_storage_type(70.0, 30.0) == 'GP3'
    
    def test_classify_storage_type_null_values(self):
        """Test storage type classification with NULL values."""
        assert classify_storage_type(None, 40.0) is None
        assert classify_storage_type(60.0, None) is None
        assert classify_storage_type(None, None) is None
    
    # Instance Type Classification Tests
    def test_classify_instance_type_large(self):
        """Test instance type classification for m6i.large."""
        # <= 2 vCPUs
        assert classify_instance_type(1.0) == 'm6i.large'
        assert classify_instance_type(2.0) == 'm6i.large'
    
    def test_classify_instance_type_xlarge(self):
        """Test instance type classification for m6i.xlarge."""
        # > 2 and <= 4 vCPUs
        assert classify_instance_type(2.1) == 'm6i.xlarge'
        assert classify_instance_type(3.0) == 'm6i.xlarge'
        assert classify_instance_type(4.0) == 'm6i.xlarge'
    
    def test_classify_instance_type_2xlarge(self):
        """Test instance type classification for m6i.2xlarge."""
        # > 4 and <= 8 vCPUs
        assert classify_instance_type(4.1) == 'm6i.2xlarge'
        assert classify_instance_type(6.0) == 'm6i.2xlarge'
        assert classify_instance_type(8.0) == 'm6i.2xlarge'
    
    def test_classify_instance_type_4xlarge(self):
        """Test instance type classification for m6i.4xlarge."""
        # > 8 vCPUs
        assert classify_instance_type(8.1) == 'm6i.4xlarge'
        assert classify_instance_type(12.0) == 'm6i.4xlarge'
        assert classify_instance_type(16.0) == 'm6i.4xlarge'
    
    def test_classify_instance_type_boundary_conditions(self):
        """Test instance type classification at boundary conditions."""
        # Just at 2 vCPU threshold
        assert classify_instance_type(2.0) == 'm6i.large'
        assert classify_instance_type(2.1) == 'm6i.xlarge'
        
        # Just at 4 vCPU threshold
        assert classify_instance_type(4.0) == 'm6i.xlarge'
        assert classify_instance_type(4.1) == 'm6i.2xlarge'
        
        # Just at 8 vCPU threshold
        assert classify_instance_type(8.0) == 'm6i.2xlarge'
        assert classify_instance_type(8.1) == 'm6i.4xlarge'
    
    def test_classify_instance_type_null_value(self):
        """Test instance type classification with NULL value."""
        assert classify_instance_type(None) is None
    
    def test_classify_instance_type_zero_vcpus(self):
        """Test instance type classification with zero vCPUs."""
        # Zero vCPUs should still classify to smallest instance
        assert classify_instance_type(0.0) == 'm6i.large'
    
    # Cross-Classification Consistency Tests
    def test_workload_and_storage_consistency(self):
        """Test consistency between workload and storage classification."""
        # Read-heavy workload should recommend GP3
        workload = classify_workload_type(80.0)
        storage = classify_storage_type(80.0, 20.0)
        assert workload == 'Read-Heavy'
        assert storage == 'GP3'
        
        # Write-heavy workload should recommend IO2
        workload = classify_workload_type(20.0)
        storage = classify_storage_type(20.0, 80.0)
        assert workload == 'Write-Heavy'
        assert storage == 'IO2'
    
    def test_complexity_and_wave_consistency(self):
        """Test that complexity and wave classifications are independent."""
        # High complexity doesn't necessarily mean low priority
        # (They measure different things)
        complexity = classify_complexity_category(250.0)  # Very High
        wave = classify_migration_wave(80.0)  # Wave 1 - High Priority
        assert complexity == 'Very High'
        assert wave == 'Wave 1 - High Priority'
        
        # Low complexity can have low priority
        complexity = classify_complexity_category(40.0)  # Low
        wave = classify_migration_wave(20.0)  # Wave 4 - Very Low Priority
        assert complexity == 'Low'
        assert wave == 'Wave 4 - Very Low Priority'
