"""Unit tests for SMF Types 41-49 parsers."""

import pytest
import struct
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers import (
    SMF41ParserV3R2, SMF42ParserV3R2, SMF43ParserV3R2,
    SMF45ParserV3R2, SMF47ParserV3R2, SMF48ParserV3R2, SMF49ParserV3R2
)
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser


def create_smf_header(record_type: int, record_length: int = 100, subtype: int = 0) -> bytes:
    """Create a minimal SMF record header for testing."""
    header = bytearray(100)
    
    # RDW (Record Descriptor Word)
    struct.pack_into('>H', header, 0, record_length)  # Record length
    struct.pack_into('>H', header, 2, 0)  # Segment descriptor
    
    # System indicator
    header[4] = 0x01
    
    # Record type
    header[5] = record_type
    
    # Timestamp (hundredths of second since midnight)
    struct.pack_into('>I', header, 6, 3661234)  # 10:10:12.34
    
    # Date (packed decimal 0cyydddF)
    # 2024365 = December 30, 2024
    header[10:14] = bytes([0x00, 0x24, 0x36, 0x5F])
    
    # System ID (EBCDIC)
    header[14:18] = b'SYS1'
    
    # Subsystem ID (for types 43, 45, 47, 48, 49)
    if record_type in [43, 45, 47, 48, 49]:
        struct.pack_into('>H', header, 18, 2)  # JES2 = 0x0002
    
    # Subtype (for type 41, 42)
    if record_type in [41, 42]:
        struct.pack_into('>H', header, 22, subtype)
    
    return bytes(header)


class TestSMF41Parser:
    """Tests for SMF Type 41 parser."""
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal Type 41 record."""
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF41ParserV3R2(base_parser)
        
        # Create minimal record (subtype 1 - ACCESS)
        record_data = create_smf_header(41, subtype=1)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 41
        assert result.subtype == 1
        assert result.system_id is not None


class TestSMF42Parser:
    """Tests for SMF Type 42 parser (minimal implementation)."""
    
    def test_parse_minimal_record(self):
        """Test parsing a minimal Type 42 record."""
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF42ParserV3R2(base_parser)
        
        # Create minimal record (subtype 1)
        record_data = create_smf_header(42, subtype=1)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 42
        assert result.subtype == 1
        assert 'implementation_note' in result.header
        assert 'MINIMAL' in result.header['implementation_note']


class TestSMF43Parser:
    """Tests for SMF Type 43 parser."""
    
    def test_parse_jes2_record(self):
        """Test parsing a JES2 Type 43 record."""
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF43ParserV3R2(base_parser)
        
        record_data = create_smf_header(43)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 43
        assert result.header['subsystem_id'] == 2
        assert result.header['subsystem_name'] == 'JES2'


class TestSMF45Parser:
    """Tests for SMF Type 45 parser."""
    
    def test_parse_jes2_record(self):
        """Test parsing a JES2 Type 45 record."""
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF45ParserV3R2(base_parser)
        
        record_data = create_smf_header(45)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 45
        assert result.header['subsystem_id'] == 2
        assert result.header['subsystem_name'] == 'JES2'


class TestSMF47Parser:
    """Tests for SMF Type 47 parser."""
    
    def test_parse_jes2_record(self):
        """Test parsing a JES2 Type 47 record."""
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF47ParserV3R2(base_parser)
        
        record_data = create_smf_header(47)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 47
        assert result.header['subsystem_id'] == 2


class TestSMF48Parser:
    """Tests for SMF Type 48 parser."""
    
    def test_parse_jes2_record(self):
        """Test parsing a JES2 Type 48 record."""
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF48ParserV3R2(base_parser)
        
        record_data = create_smf_header(48)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 48
        assert result.header['subsystem_id'] == 2


class TestSMF49Parser:
    """Tests for SMF Type 49 parser."""
    
    def test_parse_jes2_record(self):
        """Test parsing a JES2 Type 49 record."""
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF49ParserV3R2(base_parser)
        
        record_data = create_smf_header(49)
        
        result = parser.parse(record_data)
        
        assert result.record_type == 49
        assert result.header['subsystem_id'] == 2


class TestParserIntegration:
    """Integration tests for all new parsers."""
    
    def test_all_parsers_registered(self):
        """Test that all parsers are registered in the factory."""
        from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
        
        available = SMFParserFactory.list_available_parsers()
        
        # Check that our new types are registered
        assert 41 in available
        assert 42 in available
        assert 43 in available
        assert 45 in available
        assert 47 in available
        assert 48 in available
        assert 49 in available
    
    def test_factory_creates_parsers(self):
        """Test that factory can create all new parsers."""
        from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
        
        for record_type in [41, 42, 43, 45, 47, 48, 49]:
            parser = SMFParserFactory.create_parser(record_type, "V3R2", "EBCDIC")
            assert parser is not None
            assert parser.record_type == record_type
