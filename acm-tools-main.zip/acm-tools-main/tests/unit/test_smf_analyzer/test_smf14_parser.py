"""Unit tests for SMF14ParserV3R2."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf14_parser_v3r2 import SMF14ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF14ParserV3R2:
    """Test suite for SMF14ParserV3R2 class."""
    
    def create_minimal_smf14_record(self):
        """Create minimal valid SMF Type 14 record with synthetic data.
        
        This creates a basic Type 14 record structure with:
        - Valid header
        - TIOT section (DD name)
        - JFCB section (dataset name)
        - DCB/DEB section (dataset characteristics)
        - Extended information section (program name, step name, job ID)
        
        Total size: 310 bytes
        """
        record_length = 310
        data = bytearray(record_length)
        
        # === HEADER SECTION (offsets 0-51) ===
        # Record length (offset 0, 2 bytes)
        data[0:2] = record_length.to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes) - not used in Type 14
        data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte)
        data[4] = 0x00
        
        # Record type (offset 5, 1 byte) - 14
        data[5] = 14
        
        # Timestamp (offset 6, 4 bytes) - 36000 hundredths = 10:00:00.00
        data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes) - 0x01240001F = 2024-001 (Jan 1, 2024)
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes) - "SYS1" in EBCDIC
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # Job name (offset 18, 8 bytes) - "TESTJOB1" in EBCDIC
        job_name_ebcdic = "TESTJOB1".encode('cp037')
        data[18:26] = job_name_ebcdic
        
        # Reserved (offset 26-33)
        
        # User ID (offset 34, 8 bytes) - "TESTUSER" in EBCDIC
        user_id_ebcdic = "TESTUSER".encode('cp037')
        data[34:42] = user_id_ebcdic
        
        # Reserved (offset 42-43)
        
        # DCB/DEB section size (offset 44, 1 byte) - 20 bytes
        data[44] = 20
        
        # Number of UCB sections (offset 45, 1 byte) - 1
        data[45] = 1
        
        # UCB section size (offset 46, 1 byte) - 16 bytes
        data[46] = 16
        
        # Reserved (offset 47)
        
        # Open time (offset 48, 4 bytes) - 32400 hundredths = 09:00:00.00
        data[48:52] = (32400).to_bytes(4, 'big')
        
        # === TIOT SECTION (offsets 52-67, 16 bytes) ===
        # DD name at offset 56 (8 bytes) - "SYSUT1" in EBCDIC
        dd_name_ebcdic = "SYSUT1".encode('cp037')
        data[56:64] = dd_name_ebcdic + bytes([0x40] * (8 - len(dd_name_ebcdic)))
        
        # === JFCB SECTION (offsets 68-243, 176 bytes) ===
        # Dataset name at offset 68 (44 bytes) - "TEST.INPUT.DATASET" in EBCDIC
        dataset_name = "TEST.INPUT.DATASET"
        dataset_name_ebcdic = dataset_name.encode('cp037')
        data[68:112] = dataset_name_ebcdic + bytes([0x40] * (44 - len(dataset_name_ebcdic)))
        
        # === DCB/DEB SECTION (offsets 244-263, 20 bytes) ===
        # Dataset organization (offset 244, 2 bytes) - 0x4000 = PS
        data[244:246] = (0x4000).to_bytes(2, 'big')
        
        # Record format (offset 246, 1 byte) - 0x90 = FB (Fixed Blocked)
        data[246] = 0x90
        
        # === UCB SECTION (offsets 264-279, 16 bytes) ===
        # Volume serial at offset 264 (6 bytes) - "VOL001" in EBCDIC
        volume_serial = "VOL001".encode('cp037')
        data[264:270] = volume_serial
        
        # === EXTENDED INFORMATION SECTION (starts at offset 280) ===
        # Calculate base offset for extended info
        base_offset = 52 + 16 + 176 + 20 + 16  # = 280
        
        # Extended segment length (2 bytes) - 40 bytes total
        ext_seg_length = 40
        data[base_offset:base_offset+2] = ext_seg_length.to_bytes(2, 'big')
        
        # Step Information Section (Type 3)
        ext_section_offset = base_offset + 2
        
        # Section length (2 bytes) - 32 bytes
        data[ext_section_offset:ext_section_offset+2] = (32).to_bytes(2, 'big')
        
        # Reserved (1 byte)
        data[ext_section_offset+2] = 0
        
        # Section type (1 byte) - 3 = Step Information
        data[ext_section_offset+3] = 3
        
        # Step name (8 bytes at offset 4) - "STEP01" in EBCDIC
        step_name = "STEP01".encode('cp037')
        data[ext_section_offset+4:ext_section_offset+12] = step_name + bytes([0x40] * (8 - len(step_name)))
        
        # Program name (8 bytes at offset 12) - "TESTPGM1" in EBCDIC
        program_name = "TESTPGM1".encode('cp037')
        data[ext_section_offset+12:ext_section_offset+20] = program_name
        
        # Job ID (8 bytes at offset 20) - "JOB12345" in EBCDIC
        job_id = "JOB12345".encode('cp037')
        data[ext_section_offset+20:ext_section_offset+28] = job_id
        
        return bytes(data)
    
    def test_parser_initialization(self):
        """Test creating SMF14ParserV3R2 instance."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        assert parser.parser == base_parser
    
    def test_parse_validates_record_type(self):
        """Test that parsing validates record type."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        # Create record with wrong type
        data = self.create_minimal_smf14_record()
        data_array = bytearray(data)
        data_array[5] = 30  # Wrong record type
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "type mismatch" in str(exc_info.value).lower()
    
    def test_parse_validates_record_length(self):
        """Test that parsing validates record length."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        # Create record with mismatched length
        data = self.create_minimal_smf14_record()
        data_array = bytearray(data)
        data_array[0:2] = (400).to_bytes(2, 'big')  # Wrong length (declared 400 but actual 310)
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "length mismatch" in str(exc_info.value).lower()
    
    def test_parse_extracts_basic_fields(self):
        """Test that parse extracts basic record fields."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        data = self.create_minimal_smf14_record()
        
        result = parser.parse(data)
        
        # Verify basic record fields
        assert result.record_type == 14
        assert result.subtype == 0
        assert result.record_length == 310
        assert result.system_id == "SYS1"
        
        # Verify fields are in identification section
        assert result.identification is not None
        assert result.identification['job_name'] == "TESTJOB1"
        assert result.identification['user_id'] == "TESTUSER"
        assert result.identification['dd_name'] == "SYSUT1"
        assert result.identification['dataset_name'] == "TEST.INPUT.DATASET"
        assert result.identification['dataset_org'] == "PS"
        assert result.identification['record_format'] == "FB"
    
    def test_parse_field_extraction_logic(self):
        """Test field extraction logic using base parser directly."""
        base_parser = BaseRecordParser()
        data = self.create_minimal_smf14_record()
        
        # Test that we can extract fields correctly
        record_length = base_parser.read_binary(data, 0, 2)
        assert record_length == 310
        
        record_type = base_parser.read_binary(data, 5, 1)
        assert record_type == 14
        
        system_id = base_parser.read_string(data, 14, 4, "system_id")
        assert system_id == "SYS1"
        
        job_name = base_parser.read_string(data, 18, 8, "job_name")
        assert job_name == "TESTJOB1"
        
        user_id = base_parser.read_string(data, 34, 8, "user_id")
        assert user_id == "TESTUSER"
        
        dd_name = base_parser.read_string(data, 56, 8, "dd_name")
        assert dd_name == "SYSUT1"
        
        dataset_name = base_parser.read_string(data, 68, 44, "dataset_name")
        assert dataset_name == "TEST.INPUT.DATASET"
    
    def test_decode_dataset_org_ps(self):
        """Test decoding of PS (Physical Sequential) dataset organization."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        assert parser._decode_dataset_org(0x4000) == "PS"
    
    def test_decode_dataset_org_po(self):
        """Test decoding of PO (Partitioned) dataset organization."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        assert parser._decode_dataset_org(0x0200) == "PO"
    
    def test_decode_dataset_org_vsam(self):
        """Test decoding of VSAM dataset organization."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        assert parser._decode_dataset_org(0x0100) == "VS"
    
    def test_decode_record_format_fb(self):
        """Test decoding of FB (Fixed Blocked) record format."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        # 0x90 = 0x80 (F) + 0x10 (B)
        assert parser._decode_record_format(0x90) == "FB"
    
    def test_decode_record_format_vb(self):
        """Test decoding of VB (Variable Blocked) record format."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        # 0x50 = 0x40 (V) + 0x10 (B)
        assert parser._decode_record_format(0x50) == "VB"
    
    def test_decode_record_format_f(self):
        """Test decoding of F (Fixed) record format."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        assert parser._decode_record_format(0x80) == "F"
    
    def test_parse_handles_missing_extended_info(self):
        """Test parsing when extended information section is missing."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        # Create minimal record without extended info
        data = bytearray(280)  # Just enough for base sections
        
        # Set up basic header
        data[0:2] = (280).to_bytes(2, 'big')
        data[5] = 14  # Record type
        data[6:10] = (36000).to_bytes(4, 'big')  # Timestamp
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])  # Date
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])  # System ID
        
        # Job name
        data[18:26] = "TESTJOB2".encode('cp037')
        
        # User ID
        data[34:42] = "USER0002".encode('cp037')
        
        # Section sizes
        data[44] = 20  # DCB/DEB size
        data[45] = 1   # UCB count
        data[46] = 16  # UCB size
        
        # Open time
        data[48:52] = (32400).to_bytes(4, 'big')
        
        # DD name
        data[56:64] = "SYSUT2".encode('cp037') + bytes([0x40, 0x40])
        
        # Dataset name
        dataset_name = "TEST.DATASET.TWO"
        data[68:112] = dataset_name.encode('cp037') + bytes([0x40] * (44 - len(dataset_name)))
        
        # Dataset org and recfm
        data[244:246] = (0x0200).to_bytes(2, 'big')  # PO
        data[246] = 0x80  # F
        
        # Test field extraction directly
        job_name = base_parser.read_string(bytes(data), 18, 8, "job_name")
        assert job_name == "TESTJOB2"
        
        dataset_name_parsed = base_parser.read_string(bytes(data), 68, 44, "dataset_name")
        assert dataset_name_parsed == "TEST.DATASET.TWO"


class TestSMF14EncodingHandling:
    """Test EBCDIC encoding handling for SMF Type 14 records."""
    
    def test_ebcdic_dataset_name_with_special_chars(self):
        """Test handling of dataset names with special characters."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create record with dataset name containing special chars
        data = bytearray(300)
        data[0:2] = (300).to_bytes(2, 'big')
        data[5] = 14
        
        # Dataset name with special chars: "SYS1.PARMLIB(MEMBER)"
        dataset_name = "SYS1.PARMLIB(MEMBER)"
        data[68:112] = dataset_name.encode('cp037') + bytes([0x40] * (44 - len(dataset_name)))
        
        # Test EBCDIC decoding
        decoded = base_parser.read_string(bytes(data), 68, 44, "dataset_name")
        assert decoded == "SYS1.PARMLIB(MEMBER)"
    
    def test_ebcdic_program_name_padding(self):
        """Test handling of program names with EBCDIC padding."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with short program name "PGM" with EBCDIC space padding (0x40)
        data = bytearray(100)
        program_name = "PGM"
        data[0:8] = program_name.encode('cp037') + bytes([0x40] * 5)
        
        # Test EBCDIC decoding with padding
        decoded = base_parser.read_string(bytes(data), 0, 8, "program_name")
        
        # Should strip trailing spaces
        assert decoded == "PGM"
    
    def test_ebcdic_job_name_full_length(self):
        """Test handling of full 8-character job names."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with full 8-char job name
        data = bytearray(100)
        job_name = "TESTJOB1"
        data[0:8] = job_name.encode('cp037')
        
        decoded = base_parser.read_string(bytes(data), 0, 8, "job_name")
        assert decoded == "TESTJOB1"


class TestSMF14ErrorConditions:
    """Test error handling for SMF Type 14 parser."""
    
    def test_parse_with_insufficient_data(self):
        """Test parsing with record too short for basic sections."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        # Create record that's too short
        data = bytearray(100)
        data[0:2] = (100).to_bytes(2, 'big')
        data[5] = 14
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(data))
    
    def test_parse_with_invalid_offset(self):
        """Test parsing with invalid section offset."""
        base_parser = BaseRecordParser()
        
        # Test that validation catches offset overflow
        data = bytearray(300)
        
        # Try to read beyond record boundary
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(bytes(data), 250, 100)
        
        assert "exceeds" in str(exc_info.value).lower()
    
    def test_parse_with_zero_length_record(self):
        """Test parsing with zero-length record."""
        base_parser = BaseRecordParser()
        parser = SMF14ParserV3R2(base_parser)
        
        data = bytes()
        
        with pytest.raises(ValidationError):
            parser.parse(data)
    
    def test_parse_with_negative_offset(self):
        """Test validation of negative offsets."""
        base_parser = BaseRecordParser()
        data = bytes(100)
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(data, -1, 10)
        
        assert "negative offset" in str(exc_info.value).lower()
    
    def test_parse_with_negative_length(self):
        """Test validation of negative lengths."""
        base_parser = BaseRecordParser()
        data = bytes(100)
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(data, 0, -1)
        
        assert "negative length" in str(exc_info.value).lower()


class TestSMF14SectionLocation:
    """Test triplet-based section location logic."""
    
    def test_section_offset_calculation(self):
        """Test calculation of section offsets based on sizes."""
        # Base sections layout:
        # Header: 52 bytes
        # TIOT: 16 bytes
        # JFCB: 176 bytes
        # DCB/DEB: variable (e.g., 20 bytes)
        # UCB: variable (e.g., 1 section * 16 bytes = 16 bytes)
        # Extended: starts after UCB
        
        header_size = 52
        tiot_size = 16
        jfcb_size = 176
        dcb_deb_size = 20
        ucb_count = 1
        ucb_size = 16
        
        expected_extended_offset = (
            header_size + tiot_size + jfcb_size + 
            dcb_deb_size + (ucb_count * ucb_size)
        )
        
        assert expected_extended_offset == 280
    
    def test_multi_ucb_section_offset(self):
        """Test offset calculation with multiple UCB sections."""
        header_size = 52
        tiot_size = 16
        jfcb_size = 176
        dcb_deb_size = 20
        ucb_count = 3  # Multiple volumes
        ucb_size = 16
        
        expected_extended_offset = (
            header_size + tiot_size + jfcb_size + 
            dcb_deb_size + (ucb_count * ucb_size)
        )
        
        assert expected_extended_offset == 312
