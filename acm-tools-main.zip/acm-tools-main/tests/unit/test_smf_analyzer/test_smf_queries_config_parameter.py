"""Unit tests for ConfigParameter data class."""

import pytest
from tools.smf_analyzer.smf_queries.config_parameter import ConfigParameter


class TestConfigParameterValidation:
    """Test ConfigParameter validation logic."""
    
    def test_integer_type_validation_valid(self):
        """Test integer type validation with valid value."""
        param = ConfigParameter(
            name='test_int',
            description='Test integer parameter',
            default_value=10,
            parameter_type='int'
        )
        assert param.validate(42) is True
    
    def test_integer_type_validation_invalid(self):
        """Test integer type validation with invalid value."""
        param = ConfigParameter(
            name='test_int',
            description='Test integer parameter',
            default_value=10,
            parameter_type='int'
        )
        with pytest.raises(ValueError, match="test_int must be an integer"):
            param.validate("not an int")
    
    def test_float_type_validation_valid(self):
        """Test float type validation with valid values."""
        param = ConfigParameter(
            name='test_float',
            description='Test float parameter',
            default_value=1.5,
            parameter_type='float'
        )
        assert param.validate(3.14) is True
        assert param.validate(42) is True  # int is acceptable for float
    
    def test_float_type_validation_invalid(self):
        """Test float type validation with invalid value."""
        param = ConfigParameter(
            name='test_float',
            description='Test float parameter',
            default_value=1.5,
            parameter_type='float'
        )
        with pytest.raises(ValueError, match="test_float must be a number"):
            param.validate("not a number")
    
    def test_bool_type_validation_valid(self):
        """Test boolean type validation with valid values."""
        param = ConfigParameter(
            name='test_bool',
            description='Test boolean parameter',
            default_value=True,
            parameter_type='bool'
        )
        assert param.validate(True) is True
        assert param.validate(False) is True
    
    def test_bool_type_validation_invalid(self):
        """Test boolean type validation with invalid value."""
        param = ConfigParameter(
            name='test_bool',
            description='Test boolean parameter',
            default_value=True,
            parameter_type='bool'
        )
        with pytest.raises(ValueError, match="test_bool must be a boolean"):
            param.validate(1)  # int is not bool
    
    def test_string_type_validation_valid(self):
        """Test string type validation with valid value."""
        param = ConfigParameter(
            name='test_str',
            description='Test string parameter',
            default_value='default',
            parameter_type='str'
        )
        assert param.validate("hello") is True
    
    def test_string_type_validation_invalid(self):
        """Test string type validation with invalid value."""
        param = ConfigParameter(
            name='test_str',
            description='Test string parameter',
            default_value='default',
            parameter_type='str'
        )
        with pytest.raises(ValueError, match="test_str must be a string"):
            param.validate(123)
    
    def test_min_value_validation_valid(self):
        """Test minimum value validation with valid value."""
        param = ConfigParameter(
            name='test_min',
            description='Test min value',
            default_value=10,
            parameter_type='int',
            min_value=5
        )
        assert param.validate(10) is True
        assert param.validate(5) is True  # boundary
    
    def test_min_value_validation_invalid(self):
        """Test minimum value validation with invalid value."""
        param = ConfigParameter(
            name='test_min',
            description='Test min value',
            default_value=10,
            parameter_type='int',
            min_value=5
        )
        with pytest.raises(ValueError, match="test_min must be >= 5"):
            param.validate(4)
    
    def test_max_value_validation_valid(self):
        """Test maximum value validation with valid value."""
        param = ConfigParameter(
            name='test_max',
            description='Test max value',
            default_value=10,
            parameter_type='int',
            max_value=100
        )
        assert param.validate(50) is True
        assert param.validate(100) is True  # boundary
    
    def test_max_value_validation_invalid(self):
        """Test maximum value validation with invalid value."""
        param = ConfigParameter(
            name='test_max',
            description='Test max value',
            default_value=10,
            parameter_type='int',
            max_value=100
        )
        with pytest.raises(ValueError, match="test_max must be <= 100"):
            param.validate(101)
    
    def test_range_validation_valid(self):
        """Test range validation with valid value."""
        param = ConfigParameter(
            name='test_range',
            description='Test range',
            default_value=50,
            parameter_type='int',
            min_value=1,
            max_value=100
        )
        assert param.validate(50) is True
        assert param.validate(1) is True  # lower boundary
        assert param.validate(100) is True  # upper boundary
    
    def test_pattern_validation_valid(self):
        """Test pattern validation with valid value."""
        param = ConfigParameter(
            name='test_pattern',
            description='Test pattern',
            default_value='ABC123',
            parameter_type='str',
            pattern=r'^[A-Z]{3}\d{3}$'
        )
        assert param.validate('ABC123') is True
        assert param.validate('XYZ999') is True
    
    def test_pattern_validation_invalid(self):
        """Test pattern validation with invalid value."""
        param = ConfigParameter(
            name='test_pattern',
            description='Test pattern',
            default_value='ABC123',
            parameter_type='str',
            pattern=r'^[A-Z]{3}\d{3}$'
        )
        with pytest.raises(ValueError, match=r"test_pattern must match pattern \^"):
            param.validate('abc123')  # lowercase not allowed
    
    def test_float_range_validation(self):
        """Test range validation with float values."""
        param = ConfigParameter(
            name='test_float_range',
            description='Test float range',
            default_value=0.5,
            parameter_type='float',
            min_value=0.0,
            max_value=1.0
        )
        assert param.validate(0.5) is True
        assert param.validate(0.0) is True
        assert param.validate(1.0) is True
        
        with pytest.raises(ValueError, match="test_float_range must be >= 0.0"):
            param.validate(-0.1)
        
        with pytest.raises(ValueError, match="test_float_range must be <= 1.0"):
            param.validate(1.1)
    
    def test_examples_field(self):
        """Test that examples field is properly stored."""
        param = ConfigParameter(
            name='test_examples',
            description='Test with examples',
            default_value=365,
            parameter_type='int',
            examples=[90, 180, 365, 730]
        )
        assert param.examples == [90, 180, 365, 730]
    
    def test_unit_field(self):
        """Test that unit field is properly stored."""
        param = ConfigParameter(
            name='test_unit',
            description='Test with unit',
            default_value=365,
            parameter_type='int',
            unit='days'
        )
        assert param.unit == 'days'
    
    def test_optional_fields_default_to_none(self):
        """Test that optional fields default to None."""
        param = ConfigParameter(
            name='test_optional',
            description='Test optional fields',
            default_value=10,
            parameter_type='int'
        )
        assert param.unit is None
        assert param.min_value is None
        assert param.max_value is None
        assert param.pattern is None
        assert param.examples == []
