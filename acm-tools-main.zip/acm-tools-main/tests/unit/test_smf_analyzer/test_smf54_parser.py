"""Unit tests for SMF Type 54 parser."""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers.smf54_parser_v3r2 import SMF54ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF54Parser:
    """Test suite for SMF Type 54 parser."""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        return SMF54ParserV3R2(base_parser)
    
    def create_test_record(self, subtype=1, remote_name="REMOTE01", 
                          remote_password="REMPWD01", line_password="LINEPWD1"):
        """Create a test Type 54 record.
        
        Args:
            subtype: Subtype ID (1=LOGON)
            remote_name: Remote name (8 bytes)
            remote_password: Remote password (8 bytes)
            line_password: Line password (8 bytes)
            
        Returns:
            bytes: Binary record data
        """
        record = bytearray()
        
        # Standard header (18 bytes)
        record.extend(struct.pack('>H', 62))  # Record length (will be updated)
        record.extend(struct.pack('>H', 0))   # Segment descriptor
        record.extend(struct.pack('B', 0))    # System indicator
        record.extend(struct.pack('B', 54))   # Record type
        record.extend(struct.pack('>I', 360000))  # Time (10:00:00)
        record.extend(struct.pack('>I', 0x0124001F))  # Date (2024-001)
        record.extend('SYS1'.encode('cp037'))  # System ID (EBCDIC)
        
        # Triplet for product section (6 bytes)
        record.extend(struct.pack('>H', 30))  # Product offset
        record.extend(struct.pack('>H', 8))   # Product length
        record.extend(struct.pack('>H', 1))   # Product number
        
        # Triplet for identification section (6 bytes)
        record.extend(struct.pack('>H', 38))  # Identification offset
        record.extend(struct.pack('>H', 24))  # Identification length
        record.extend(struct.pack('>H', 1))   # Identification number
        
        # Product section (8 bytes, offset 30)
        record.extend(struct.pack('>H', subtype))  # Subtype ID
        record.extend(b'\xF0\xF1')  # Record version "01" (EBCDIC)
        record.extend(b'\xD1\xC5\xE2\xF2')  # Subsystem "JES2" (EBCDIC)
        
        # Identification section (24 bytes, offset 38)
        # Remote name (8 bytes)
        record.extend(remote_name.ljust(8).encode('cp037'))
        
        # Remote password (8 bytes)
        record.extend(remote_password.ljust(8).encode('cp037'))
        
        # Line password (8 bytes)
        record.extend(line_password.ljust(8).encode('cp037'))
        
        # Update record length
        struct.pack_into('>H', record, 0, len(record))
        
        return bytes(record)
    
    def test_parse_valid_record(self, parser):
        """Test parsing a valid Type 54 record."""
        record_data = self.create_test_record(
            subtype=1,
            remote_name="REMOTE01",
            remote_password="BADPWD01",
            line_password="LINEPWD1"
        )
        
        result = parser.parse(record_data)
        
        # Verify standard fields
        assert result.record_type == 54
        assert result.subtype == 1
        assert result.system_id == "SYS1"
        assert result.record_length == len(record_data)
        
        # Verify product section
        assert result.subsystem is not None
        assert result.subsystem['subtype_id'] == 1
        assert result.subsystem['subsystem_name'] == "JES2"
        
        # Verify identification section
        assert result.identification is not None
        assert result.identification['remote_name'] == "REMOTE01"
        assert result.identification['remote_password'] == "BADPWD01"
        assert result.identification['line_password'] == "LINEPWD1"
    
    def test_parse_with_different_passwords(self, parser):
        """Test parsing Type 54 record with different password values."""
        record_data = self.create_test_record(
            subtype=1,
            remote_name="REMOTE02",
            remote_password="WRONGPWD",
            line_password="CORRECT1"
        )
        
        result = parser.parse(record_data)
        
        # Verify standard fields
        assert result.record_type == 54
        assert result.subtype == 1
        
        # Verify identification section
        assert result.identification is not None
        assert result.identification['remote_name'] == "REMOTE02"
        assert result.identification['remote_password'] == "WRONGPWD"
        assert result.identification['line_password'] == "CORRECT1"
    
    def test_parse_with_empty_fields(self, parser):
        """Test parsing record with empty/blank fields."""
        record_data = self.create_test_record(
            subtype=1,
            remote_name="",
            remote_password="",
            line_password=""
        )
        
        result = parser.parse(record_data)
        
        # Should parse successfully with empty strings
        assert result.record_type == 54
        assert result.identification is not None
    
    def test_parse_with_special_characters(self, parser):
        """Test parsing record with special characters in names."""
        record_data = self.create_test_record(
            subtype=1,
            remote_name="REM@01#",
            remote_password="P@SS$123",
            line_password="L!NE#PWD"
        )
        
        result = parser.parse(record_data)
        
        # Verify fields are parsed (special chars may be converted by EBCDIC)
        assert result.record_type == 54
        assert result.identification is not None
        assert result.identification['remote_name'] is not None
        assert result.identification['remote_password'] is not None
        assert result.identification['line_password'] is not None
    
    def test_parse_invalid_record_type(self, parser):
        """Test that parser rejects records with wrong type."""
        record_data = self.create_test_record()
        
        # Change record type to 30
        record_data = bytearray(record_data)
        record_data[5] = 30
        record_data = bytes(record_data)
        
        with pytest.raises(ValidationError):
            parser.parse(record_data)
    
    def test_parse_truncated_record(self, parser):
        """Test handling of truncated record."""
        record_data = self.create_test_record()
        
        # Truncate the record
        truncated = record_data[:30]
        
        # Should raise ValidationError for truncated record
        with pytest.raises(ValidationError):
            parser.parse(truncated)
    
    def test_header_triplet_parsing(self, parser):
        """Test that triplet fields are correctly parsed."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        
        # Verify header contains triplet information
        assert result.header is not None
        assert 'product_offset' in result.header
        assert 'product_length' in result.header
        assert 'product_number' in result.header
        assert 'identification_offset' in result.header
        assert 'identification_length' in result.header
        assert 'identification_number' in result.header
    
    def test_timestamp_parsing(self, parser):
        """Test that timestamp is correctly parsed."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        
        # Verify timestamp is present and formatted
        assert result.timestamp is not None
        assert isinstance(result.timestamp, str)
        assert ':' in result.timestamp  # Should be formatted as HH:MM:SS
    
    def test_date_parsing(self, parser):
        """Test that date is correctly parsed."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        
        # Verify date is present
        assert result.date is not None
        # Date can be either string or date object depending on parser implementation
        if isinstance(result.date, str):
            assert '-' in result.date  # Should be formatted as YYYY-MM-DD
    
    def test_to_dict_conversion(self, parser):
        """Test conversion of parsed record to dictionary."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        result_dict = result.to_dict()
        
        # Verify dictionary contains expected keys
        assert 'record_type' in result_dict
        assert 'subtype' in result_dict
        assert 'system_id' in result_dict
        assert 'timestamp' in result_dict
        assert 'date' in result_dict
        assert 'header' in result_dict
        assert 'identification' in result_dict
        assert 'subsystem' in result_dict
    
    def test_subsystem_name_is_jes2(self, parser):
        """Test that subsystem name is always JES2 for Type 54."""
        record_data = self.create_test_record()
        
        result = parser.parse(record_data)
        
        # Type 54 is JES2-specific
        assert result.subsystem is not None
        assert result.subsystem['subsystem_name'] == "JES2"
    
    def test_subtype_is_always_1(self, parser):
        """Test that Type 54 only has subtype 1 (LOGON)."""
        record_data = self.create_test_record(subtype=1)
        
        result = parser.parse(record_data)
        
        # Type 54 only has subtype 1
        assert result.subtype == 1


class TestSMF54ParserRealData:
    """Test suite for SMF Type 54 parser with real data."""
    
    @pytest.fixture
    def parser(self):
        """Create parser instance."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        return SMF54ParserV3R2(base_parser)
    
    def test_parse_real_records_ebcdic(self, parser):
        """Test parsing real Type 54 records from EBCDIC production file."""
        import os
        from tools.smf_analyzer.smf_record_parser import SMFFileParser
        
        test_file = './examples/data/aviva/SMF_records_binary.txt'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        # Parse file and look for Type 54 records
        file_parser = SMFFileParser(
            os_version="V3R2",
            encoding="EBCDIC",
            record_types=[54],
            skip_unsupported=True
        )
        
        type_54_count = 0
        for record in file_parser.parse_file(test_file):
            if record.record_type == 54:
                type_54_count += 1
                
                # Verify basic structure
                assert record.system_id is not None
                assert record.timestamp is not None
                assert record.date is not None
                
                # Verify sections exist (may be empty for some records)
                assert record.subsystem is not None
                assert record.identification is not None
                
                # If subsystem data is present, verify it
                if record.subsystem and 'subsystem_name' in record.subsystem:
                    subsystem_name = record.subsystem['subsystem_name']
                    # Allow for EBCDIC decoding issues or empty values
                    if subsystem_name and subsystem_name.strip():
                        # Only check if it's a valid ASCII string
                        if subsystem_name.isascii():
                            assert subsystem_name in ['JES2', '']
                
                # Verify subtype is 1 (only valid subtype for Type 54)
                # Note: Due to file format issues, we may get false positives
                # Only validate if the record looks legitimate
                if record.subtype and record.subtype == 1:
                    # This is a legitimate Type 54 record
                    pass
                elif record.subtype and record.subtype != 1:
                    # This is likely a false positive from file format issues
                    # Skip validation for this record
                    continue
        
        # Note: Type 54 records may not be present in all test files
        # This is expected for SNA-only integrity records
        print(f"Found {type_54_count} Type 54 records in EBCDIC test file")
    
    def test_parse_real_records_ascii(self, parser):
        """Test parsing real Type 54 records from ASCII production file."""
        import os
        from tools.smf_analyzer.smf_record_parser import SMFFileParser
        
        test_file = './examples/data/aviva/SMF_records_ascii.txt'
        
        if not os.path.exists(test_file):
            pytest.skip(f"Test file not found: {test_file}")
        
        # Parse file and look for Type 54 records
        file_parser = SMFFileParser(
            os_version="V3R2",
            encoding="UTF-8",
            record_types=[54],
            skip_unsupported=True
        )
        
        type_54_count = 0
        for record in file_parser.parse_file(test_file):
            if record.record_type == 54:
                type_54_count += 1
                
                # Verify basic structure
                assert record.system_id is not None
                assert record.timestamp is not None
                assert record.date is not None
                
                # Verify sections exist
                assert record.subsystem is not None
                assert record.identification is not None
        
        print(f"Found {type_54_count} Type 54 records in ASCII test file")


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
