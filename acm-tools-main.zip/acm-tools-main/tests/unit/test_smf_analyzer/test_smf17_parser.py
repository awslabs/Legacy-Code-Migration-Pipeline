"""Unit tests for SMF17ParserV3R2."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf17_parser_v3r2 import SMF17ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF17ParserV3R2:
    """Test suite for SMF17ParserV3R2 class."""
    
    def create_minimal_smf17_record(self, num_volumes=1):
        """Create minimal valid SMF Type 17 record with synthetic data.
        
        This creates a basic Type 17 record structure with:
        - Valid header
        - Dataset name (44 chars)
        - Job name (8 chars)
        - User ID (8 chars)
        - Number of volumes
        - Volume serial numbers (6 chars each)
        
        Args:
            num_volumes: Number of volumes to include (default 1)
        
        Returns:
            bytes: Synthetic SMF Type 17 record
        """
        # Calculate record length: header(79) + volumes(6 * num_volumes)
        record_length = 79 + (6 * num_volumes)
        data = bytearray(record_length)
        
        # === HEADER SECTION (offsets 0-17) ===
        # Record length (offset 0, 2 bytes)
        data[0:2] = record_length.to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes) - not used in Type 17
        data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte)
        data[4] = 0x00
        
        # Record type (offset 5, 1 byte) - 17
        data[5] = 17
        
        # Timestamp (offset 6, 4 bytes) - 36000 hundredths = 10:00:00.00
        data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes) - 0x01240001F = 2024-001 (Jan 1, 2024)
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes) - "SYS1" in EBCDIC
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # === DATASET NAME (offset 18, 44 bytes) - SMF17DSN ===
        dataset_name = "TEST.DELETED.DATASET"
        dataset_name_ebcdic = dataset_name.encode('cp037')
        data[18:62] = dataset_name_ebcdic + bytes([0x40] * (44 - len(dataset_name_ebcdic)))
        
        # === JOB NAME (offset 62, 8 bytes) - SMF17JBN ===
        job_name = "DELJOB01"
        job_name_ebcdic = job_name.encode('cp037')
        data[62:70] = job_name_ebcdic
        
        # === USER ID (offset 70, 8 bytes) - SMF17UID ===
        user_id = "DELUSER1"
        user_id_ebcdic = user_id.encode('cp037')
        data[70:78] = user_id_ebcdic
        
        # === NUMBER OF VOLUMES (offset 78, 1 byte) - SMF17NVL ===
        data[78] = num_volumes
        
        # === VOLUME SERIAL NUMBERS (starting at offset 79, 6 bytes each) - SMF17FVL ===
        volume_offset = 79
        for i in range(num_volumes):
            volume_serial = f"VOL{i+1:03d}"
            volume_serial_ebcdic = volume_serial.encode('cp037')
            data[volume_offset:volume_offset+6] = volume_serial_ebcdic
            volume_offset += 6
        
        return bytes(data)
    
    def test_parser_initialization(self):
        """Test creating SMF17ParserV3R2 instance."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        assert parser.parser == base_parser
    
    def test_parse_validates_record_type(self):
        """Test that parsing validates record type."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        # Create record with wrong type
        data = self.create_minimal_smf17_record()
        data_array = bytearray(data)
        data_array[5] = 30  # Wrong record type
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "type mismatch" in str(exc_info.value).lower()
    
    def test_parse_validates_record_length(self):
        """Test that parsing validates record length."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        # Create record with mismatched length
        data = self.create_minimal_smf17_record()
        data_array = bytearray(data)
        data_array[0:2] = (200).to_bytes(2, 'big')  # Wrong length
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "length mismatch" in str(exc_info.value).lower()
    
    def test_parse_extracts_dataset_name(self):
        """Test that parse extracts dataset name correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record()
        result = parser.parse(data)
        
        assert result.record_type == 17
        assert result.identification['dataset_name'] == "TEST.DELETED.DATASET"
    
    def test_parse_extracts_job_name(self):
        """Test that parse extracts job name correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record()
        result = parser.parse(data)
        
        assert result.identification['job_name'] == "DELJOB01"
    
    def test_parse_extracts_user_id(self):
        """Test that parse extracts user ID correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record()
        result = parser.parse(data)
        
        assert result.identification['user_id'] == "DELUSER1"
    
    def test_parse_extracts_timestamp(self):
        """Test that parse extracts timestamp correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record()
        result = parser.parse(data)
        
        # Timestamp should be parsed from offset 6
        assert result.timestamp is not None
        assert isinstance(result.timestamp, str)
    
    def test_parse_extracts_single_volume(self):
        """Test that parse extracts single volume serial correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record(num_volumes=1)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 1
        assert len(result.identification['volume_serials']) == 1
        assert result.identification['volume_serials'][0] == "VOL001"
    
    def test_parse_extracts_multiple_volumes(self):
        """Test that parse extracts multiple volume serials correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record(num_volumes=3)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 3
        assert len(result.identification['volume_serials']) == 3
        assert result.identification['volume_serials'][0] == "VOL001"
        assert result.identification['volume_serials'][1] == "VOL002"
        assert result.identification['volume_serials'][2] == "VOL003"
    
    def test_parse_handles_zero_volumes(self):
        """Test that parse handles datasets with zero volumes."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record(num_volumes=0)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 0
        assert len(result.identification['volume_serials']) == 0
    
    def test_parse_extracts_system_id(self):
        """Test that parse extracts system ID correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record()
        result = parser.parse(data)
        
        assert result.system_id == "SYS1"
    
    def test_parse_extracts_record_length(self):
        """Test that parse extracts record length correctly."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_minimal_smf17_record(num_volumes=1)
        result = parser.parse(data)
        
        # Record length should be 79 + (6 * 1) = 85
        assert result.record_length == 85
    
    def test_field_extraction_logic(self):
        """Test field extraction logic using base parser directly."""
        base_parser = BaseRecordParser()
        data = self.create_minimal_smf17_record()
        
        # Test that we can extract fields correctly
        record_length = base_parser.read_binary(data, 0, 2)
        assert record_length == 85  # 79 + 6
        
        record_type = base_parser.read_binary(data, 5, 1)
        assert record_type == 17
        
        system_id = base_parser.read_string(data, 14, 4, "system_id")
        assert system_id == "SYS1"
        
        dataset_name = base_parser.read_string(data, 18, 44, "dataset_name")
        assert dataset_name == "TEST.DELETED.DATASET"
        
        job_name = base_parser.read_string(data, 62, 8, "job_name")
        assert job_name == "DELJOB01"
        
        user_id = base_parser.read_string(data, 70, 8, "user_id")
        assert user_id == "DELUSER1"
        
        num_volumes = base_parser.read_binary(data, 78, 1)
        assert num_volumes == 1


class TestSMF17EncodingHandling:
    """Test EBCDIC encoding handling for SMF Type 17 records."""
    
    def test_ebcdic_dataset_name_with_special_chars(self):
        """Test handling of dataset names with special characters."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create record with dataset name containing special chars
        data = bytearray(100)
        data[0:2] = (100).to_bytes(2, 'big')
        data[5] = 17
        
        # Dataset name with special chars: "SYS1.PARMLIB(MEMBER)"
        dataset_name = "SYS1.PARMLIB(MEMBER)"
        data[18:62] = dataset_name.encode('cp037') + bytes([0x40] * (44 - len(dataset_name)))
        
        # Test EBCDIC decoding
        decoded = base_parser.read_string(bytes(data), 18, 44, "dataset_name")
        assert decoded == "SYS1.PARMLIB(MEMBER)"
    
    def test_ebcdic_job_name_padding(self):
        """Test handling of job names with EBCDIC padding."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with short job name "DEL" with EBCDIC space padding (0x40)
        data = bytearray(100)
        job_name = "DEL"
        data[0:8] = job_name.encode('cp037') + bytes([0x40] * 5)
        
        # Test EBCDIC decoding with padding
        decoded = base_parser.read_string(bytes(data), 0, 8, "job_name")
        
        # Should strip trailing spaces
        assert decoded == "DEL"
    
    def test_ebcdic_volume_serial_full_length(self):
        """Test handling of full 6-character volume serials."""
        base_parser = BaseRecordParser(encoding="EBCDIC")
        
        # Create data with full 6-char volume serial
        data = bytearray(100)
        volume_serial = "VOL123"
        data[0:6] = volume_serial.encode('cp037')
        
        decoded = base_parser.read_string(bytes(data), 0, 6, "volume_serial")
        assert decoded == "VOL123"


class TestSMF17ErrorConditions:
    """Test error handling for SMF Type 17 parser."""
    
    def test_parse_with_insufficient_data(self):
        """Test parsing with record too short for basic fields."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        # Create record that's too short
        data = bytearray(50)
        data[0:2] = (50).to_bytes(2, 'big')
        data[5] = 17
        
        with pytest.raises(ValidationError):
            parser.parse(bytes(data))
    
    def test_parse_with_invalid_offset(self):
        """Test parsing with invalid section offset."""
        base_parser = BaseRecordParser()
        
        # Test that validation catches offset overflow
        data = bytearray(100)
        
        # Try to read beyond record boundary
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(bytes(data), 90, 20)
        
        assert "exceeds" in str(exc_info.value).lower()
    
    def test_parse_with_zero_length_record(self):
        """Test parsing with zero-length record."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = bytes()
        
        with pytest.raises(ValidationError):
            parser.parse(data)
    
    def test_parse_with_negative_offset(self):
        """Test validation of negative offsets."""
        base_parser = BaseRecordParser()
        data = bytes(100)
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(data, -1, 10)
        
        assert "negative offset" in str(exc_info.value).lower()
    
    def test_parse_with_negative_length(self):
        """Test validation of negative lengths."""
        base_parser = BaseRecordParser()
        data = bytes(100)
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(data, 0, -1)
        
        assert "negative length" in str(exc_info.value).lower()
    
    def test_parse_with_truncated_volume_data(self):
        """Test parsing when volume data is truncated."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        # Create record that claims 3 volumes but only has space for 1
        data = bytearray(85)  # Only enough for 1 volume
        data[0:2] = (85).to_bytes(2, 'big')
        data[5] = 17
        data[6:10] = (36000).to_bytes(4, 'big')
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        dataset_name = "TEST.DATASET"
        data[18:62] = dataset_name.encode('cp037') + bytes([0x40] * (44 - len(dataset_name)))
        data[62:70] = "TESTJOB1".encode('cp037')
        data[70:78] = "TESTUSER".encode('cp037')
        data[78] = 3  # Claims 3 volumes but not enough space
        data[79:85] = "VOL001".encode('cp037')
        
        # Should handle gracefully and only extract available volumes
        result = parser.parse(bytes(data))
        assert result.identification['num_volumes'] == 3  # Claims 3
        assert len(result.identification['volume_serials']) == 1  # But only 1 extracted


class TestSMF17MultiVolumeHandling:
    """Test multi-volume dataset handling for SMF Type 17 records."""
    
    def create_multi_volume_record(self, num_volumes):
        """Helper to create record with specified number of volumes."""
        record_length = 79 + (6 * num_volumes)
        data = bytearray(record_length)
        
        # Basic header
        data[0:2] = record_length.to_bytes(2, 'big')
        data[5] = 17
        data[6:10] = (36000).to_bytes(4, 'big')
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # Dataset name
        dataset_name = "MULTI.VOLUME.DATASET"
        data[18:62] = dataset_name.encode('cp037') + bytes([0x40] * (44 - len(dataset_name)))
        
        # Job name and user ID
        data[62:70] = "MVJOB001".encode('cp037')
        data[70:78] = "MVUSER01".encode('cp037')
        
        # Number of volumes
        data[78] = num_volumes
        
        # Volume serials
        volume_offset = 79
        for i in range(num_volumes):
            volume_serial = f"MV{i+1:04d}"
            data[volume_offset:volume_offset+6] = volume_serial.encode('cp037')
            volume_offset += 6
        
        return bytes(data)
    
    def test_parse_five_volume_dataset(self):
        """Test parsing dataset with 5 volumes."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_multi_volume_record(5)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 5
        assert len(result.identification['volume_serials']) == 5
        assert result.identification['volume_serials'][0] == "MV0001"
        assert result.identification['volume_serials'][4] == "MV0005"
    
    def test_parse_ten_volume_dataset(self):
        """Test parsing dataset with 10 volumes."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_multi_volume_record(10)
        result = parser.parse(data)
        
        assert result.identification['num_volumes'] == 10
        assert len(result.identification['volume_serials']) == 10
        assert result.identification['volume_serials'][0] == "MV0001"
        assert result.identification['volume_serials'][9] == "MV0010"
    
    def test_volume_sequence_order(self):
        """Test that volumes are extracted in correct sequence."""
        base_parser = BaseRecordParser()
        parser = SMF17ParserV3R2(base_parser)
        
        data = self.create_multi_volume_record(3)
        result = parser.parse(data)
        
        # Verify order is preserved
        assert result.identification['volume_serials'] == ["MV0001", "MV0002", "MV0003"]
