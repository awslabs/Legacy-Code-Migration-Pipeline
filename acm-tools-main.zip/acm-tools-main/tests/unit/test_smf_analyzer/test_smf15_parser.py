"""Unit tests for SMF15ParserV3R2."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.parsers.smf15_parser_v3r2 import SMF15ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError


class TestSMF15ParserV3R2:
    """Test suite for SMF15ParserV3R2 class."""
    
    def create_minimal_smf15_record(self):
        """Create minimal valid SMF Type 15 record with synthetic data.
        
        This creates a basic Type 15 record structure with:
        - Valid header
        - TIOT section (DD name)
        - JFCB section (dataset name)
        - DCB/DEB section (dataset characteristics)
        - Extended information section (program name, step name, job ID)
        
        Total size: 310 bytes
        """
        record_length = 310
        data = bytearray(record_length)
        
        # === HEADER SECTION (offsets 0-51) ===
        # Record length (offset 0, 2 bytes)
        data[0:2] = record_length.to_bytes(2, 'big')
        
        # Segment descriptor (offset 2, 2 bytes) - not used in Type 15
        data[2:4] = (0).to_bytes(2, 'big')
        
        # System indicator (offset 4, 1 byte)
        data[4] = 0x00
        
        # Record type (offset 5, 1 byte) - 15
        data[5] = 15
        
        # Timestamp (offset 6, 4 bytes) - 36000 hundredths = 10:00:00.00
        data[6:10] = (36000).to_bytes(4, 'big')
        
        # Date (offset 10, 4 bytes) - 0x01240001F = 2024-001 (Jan 1, 2024)
        data[10:14] = bytes([0x01, 0x24, 0x00, 0x1F])
        
        # System ID (offset 14, 4 bytes) - "SYS1" in EBCDIC
        data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
        
        # Job name (offset 18, 8 bytes) - "OUTJOB01" in EBCDIC
        job_name_ebcdic = "OUTJOB01".encode('cp037')
        data[18:26] = job_name_ebcdic
        
        # Reserved (offset 26-33)
        
        # User ID (offset 34, 8 bytes) - "OUTUSER1" in EBCDIC
        user_id_ebcdic = "OUTUSER1".encode('cp037')
        data[34:42] = user_id_ebcdic
        
        # Reserved (offset 42-43)
        
        # DCB/DEB section size (offset 44, 1 byte) - 20 bytes
        data[44] = 20
        
        # Number of UCB sections (offset 45, 1 byte) - 1
        data[45] = 1
        
        # UCB section size (offset 46, 1 byte) - 16 bytes
        data[46] = 16
        
        # Reserved (offset 47)
        
        # Open time (offset 48, 4 bytes) - 32400 hundredths = 09:00:00.00
        data[48:52] = (32400).to_bytes(4, 'big')
        
        # === TIOT SECTION (offsets 52-67, 16 bytes) ===
        # DD name at offset 56 (8 bytes) - "SYSOUT" in EBCDIC
        dd_name_ebcdic = "SYSOUT".encode('cp037')
        data[56:64] = dd_name_ebcdic + bytes([0x40] * (8 - len(dd_name_ebcdic)))
        
        # === JFCB SECTION (offsets 68-243, 176 bytes) ===
        # Dataset name at offset 68 (44 bytes) - "TEST.OUTPUT.DATASET" in EBCDIC
        dataset_name = "TEST.OUTPUT.DATASET"
        dataset_name_ebcdic = dataset_name.encode('cp037')
        data[68:112] = dataset_name_ebcdic + bytes([0x40] * (44 - len(dataset_name_ebcdic)))
        
        # === DCB/DEB SECTION (offsets 244-263, 20 bytes) ===
        # Dataset organization (offset 244, 2 bytes) - 0x4000 = PS
        data[244:246] = (0x4000).to_bytes(2, 'big')
        
        # Record format (offset 246, 1 byte) - 0x90 = FB (Fixed Blocked)
        data[246] = 0x90
        
        # === UCB SECTION (offsets 264-279, 16 bytes) ===
        # Volume serial at offset 264 (6 bytes) - "VOL002" in EBCDIC
        volume_serial = "VOL002".encode('cp037')
        data[264:270] = volume_serial
        
        # === EXTENDED INFORMATION SECTION (starts at offset 280) ===
        # Calculate base offset for extended info
        base_offset = 52 + 16 + 176 + 20 + 16  # = 280
        
        # Extended segment length (2 bytes) - 40 bytes total
        ext_seg_length = 40
        data[base_offset:base_offset+2] = ext_seg_length.to_bytes(2, 'big')
        
        # Step Information Section (Type 3)
        ext_section_offset = base_offset + 2
        
        # Section length (2 bytes) - 32 bytes
        data[ext_section_offset:ext_section_offset+2] = (32).to_bytes(2, 'big')
        
        # Reserved (1 byte)
        data[ext_section_offset+2] = 0
        
        # Section type (1 byte) - 3 = Step Information
        data[ext_section_offset+3] = 3
        
        # Step name (8 bytes at offset 4) - "OUTSTEP1" in EBCDIC
        step_name = "OUTSTEP1".encode('cp037')
        data[ext_section_offset+4:ext_section_offset+12] = step_name
        
        # Program name (8 bytes at offset 12) - "OUTPGM01" in EBCDIC
        program_name = "OUTPGM01".encode('cp037')
        data[ext_section_offset+12:ext_section_offset+20] = program_name
        
        # Job ID (8 bytes at offset 20) - "JOB67890" in EBCDIC
        job_id = "JOB67890".encode('cp037')
        data[ext_section_offset+20:ext_section_offset+28] = job_id
        
        return bytes(data)
    
    def test_parser_initialization(self):
        """Test creating SMF15ParserV3R2 instance."""
        base_parser = BaseRecordParser()
        parser = SMF15ParserV3R2(base_parser)
        
        assert parser.parser == base_parser
    
    def test_parse_validates_record_type(self):
        """Test that parsing validates record type."""
        base_parser = BaseRecordParser()
        parser = SMF15ParserV3R2(base_parser)
        
        # Create record with wrong type
        data = self.create_minimal_smf15_record()
        data_array = bytearray(data)
        data_array[5] = 30  # Wrong record type
        
        with pytest.raises(ValidationError) as exc_info:
            parser.parse(bytes(data_array))
        
        assert "type mismatch" in str(exc_info.value).lower()
    
    def test_parse_field_extraction_logic(self):
        """Test field extraction logic using base parser directly."""
        base_parser = BaseRecordParser()
        data = self.create_minimal_smf15_record()
        
        # Test that we can extract fields correctly
        record_length = base_parser.read_binary(data, 0, 2)
        assert record_length == 310
        
        record_type = base_parser.read_binary(data, 5, 1)
        assert record_type == 15
        
        system_id = base_parser.read_string(data, 14, 4, "system_id")
        assert system_id == "SYS1"
        
        job_name = base_parser.read_string(data, 18, 8, "job_name")
        assert job_name == "OUTJOB01"
        
        user_id = base_parser.read_string(data, 34, 8, "user_id")
        assert user_id == "OUTUSER1"
        
        dd_name = base_parser.read_string(data, 56, 8, "dd_name")
        assert dd_name == "SYSOUT"
        
        dataset_name = base_parser.read_string(data, 68, 44, "dataset_name")
        assert dataset_name == "TEST.OUTPUT.DATASET"
    
    def test_decode_dataset_org_ps(self):
        """Test decoding of PS (Physical Sequential) dataset organization."""
        base_parser = BaseRecordParser()
        parser = SMF15ParserV3R2(base_parser)
        
        assert parser._decode_dataset_org(0x4000) == "PS"
    
    def test_decode_dataset_org_po(self):
        """Test decoding of PO (Partitioned) dataset organization."""
        base_parser = BaseRecordParser()
        parser = SMF15ParserV3R2(base_parser)
        
        assert parser._decode_dataset_org(0x0200) == "PO"
    
    def test_decode_record_format_fb(self):
        """Test decoding of FB (Fixed Blocked) record format."""
        base_parser = BaseRecordParser()
        parser = SMF15ParserV3R2(base_parser)
        
        # 0x90 = 0x80 (F) + 0x10 (B)
        assert parser._decode_record_format(0x90) == "FB"
    
    def test_decode_record_format_vb(self):
        """Test decoding of VB (Variable Blocked) record format."""
        base_parser = BaseRecordParser()
        parser = SMF15ParserV3R2(base_parser)
        
        # 0x50 = 0x40 (V) + 0x10 (B)
        assert parser._decode_record_format(0x50) == "VB"
