"""
Unit tests for SMF Type 21-26 parsers
"""

import pytest
import struct
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.parsers.smf21_parser_v3r2 import SMF21ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.smf22_parser_v3r2 import SMF22ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.smf23_parser_v3r2 import SMF23ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.smf24_parser_v3r2 import SMF24ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.smf25_parser_v3r2 import SMF25ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.smf26_parser_v3r2 import SMF26ParserV3R2


def create_smf_header(record_type: int, record_length: int) -> bytes:
    """Create a minimal SMF header for testing."""
    header = bytearray(record_length)
    
    # RDW (2 bytes)
    struct.pack_into('>H', header, 0, record_length)
    
    # Segment descriptor (2 bytes)
    struct.pack_into('>H', header, 2, 0)
    
    # System indicator (1 byte)
    header[4] = 0
    
    # Record type (1 byte)
    header[5] = record_type
    
    # Timestamp (4 bytes) - 12:00:00 = 43200 * 100 = 4320000
    struct.pack_into('>I', header, 6, 4320000)
    
    # Date (4 bytes packed) - 2024001F
    header[10:14] = bytes([0x20, 0x24, 0x00, 0x1F])
    
    # System ID (4 bytes EBCDIC) - "SYS1"
    header[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])
    
    return bytes(header)


class TestSMF21Parser:
    """Tests for SMF Type 21 parser."""
    
    def test_parse_basic_record(self):
        """Test parsing a basic Type 21 record."""
        # Create test record (104 bytes minimum)
        record_data = create_smf_header(21, 104)
        record_data = bytearray(record_data)
        
        # Add Type 21 specific fields
        # Rest of record length (offset 18)
        struct.pack_into('>H', record_data, 18, 84)
        
        # Volume serial (offset 20, 6 bytes EBCDIC) - "VOL001"
        record_data[20:26] = bytes([0xE5, 0xD6, 0xD3, 0xF0, 0xF0, 0xF1])
        
        # Device number (offset 26, 2 bytes)
        struct.pack_into('>H', record_data, 26, 0x0100)
        
        # UCBTYP (offset 28, 4 bytes)
        struct.pack_into('>I', record_data, 28, 0x30000000)
        
        # Device type (offset 31, 1 byte) - cartridge (>= 0x80)
        record_data[31] = 0x80
        
        # Error counts
        record_data[32] = 5   # temp read errors
        record_data[33] = 2   # temp write errors
        struct.pack_into('>H', record_data, 34, 100)  # SSCH count
        record_data[36] = 0   # perm read errors
        record_data[37] = 0   # perm write errors
        
        # Parse
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF21ParserV3R2(base_parser)
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 21
        assert result.system_id == "SYS1"
        assert result.subsystem['device_category'] == 'cartridge'
        assert result.subsystem['temp_read_errors'] == 5
        assert result.subsystem['temp_write_errors'] == 2
        assert result.subsystem['ssch_count'] == 100


class TestSMF22Parser:
    """Tests for SMF Type 22 parser."""
    
    def test_parse_basic_record(self):
        """Test parsing a basic Type 22 record."""
        # Create test record (40 bytes minimum)
        record_data = create_smf_header(22, 40)
        record_data = bytearray(record_data)
        
        # Creator indicator (offset 18) - IPL
        struct.pack_into('>H', record_data, 18, 1)
        
        # Section count (offset 20)
        struct.pack_into('>H', record_data, 20, 0)
        
        # Parse
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF22ParserV3R2(base_parser)
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 22
        assert result.system_id == "SYS1"
        assert result.header['creator_indicator'] == 1
        assert result.header['creator_description'] == 'IPL'


class TestSMF23Parser:
    """Tests for SMF Type 23 parser."""
    
    def test_parse_basic_record(self):
        """Test parsing a basic Type 23 record."""
        # Create test record (122 bytes to fit all sections)
        record_data = create_smf_header(23, 122)
        record_data = bytearray(record_data)
        
        # Triplets (starting at offset 20)
        # Product section triplet
        struct.pack_into('>I', record_data, 20, 68)  # offset
        struct.pack_into('>H', record_data, 24, 12)  # length
        struct.pack_into('>H', record_data, 26, 1)   # count
        
        # System section triplet
        struct.pack_into('>I', record_data, 28, 80)  # offset
        struct.pack_into('>H', record_data, 32, 42)  # length
        struct.pack_into('>H', record_data, 34, 1)   # count
        
        # SMF stats triplet
        struct.pack_into('>I', record_data, 36, 0)   # offset (not present)
        struct.pack_into('>H', record_data, 40, 0)   # length
        struct.pack_into('>H', record_data, 42, 0)   # count
        
        # Logstream triplet
        struct.pack_into('>I', record_data, 44, 0)   # offset (not present)
        struct.pack_into('>H', record_data, 48, 0)   # length
        struct.pack_into('>H', record_data, 50, 0)   # count
        
        # Product section at offset 68
        struct.pack_into('>H', record_data, 68, 0)   # subtype
        record_data[70:72] = b'02'                    # version
        record_data[72:80] = b'SMF     '             # product name (ASCII for test)
        
        # System section at offset 80
        record_data[80:86] = b'000100'               # interval
        record_data[86:90] = b'0322'                 # OS release
        record_data[90:98] = b'MVS/ESA '            # MVS product
        
        # Parse
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF23ParserV3R2(base_parser)
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 23
        assert result.system_id == "SYS1"
        assert 'product' in result.subsystem
        assert 'system' in result.subsystem


class TestSMF24Parser:
    """Tests for SMF Type 24 parser."""
    
    def test_parse_basic_record(self):
        """Test parsing a basic Type 24 record."""
        # Create test record (80 bytes minimum for header with triplets)
        record_data = create_smf_header(24, 80)
        record_data = bytearray(record_data)
        
        # Subsystem ID (offset 18) - "JES2"
        record_data[18:22] = b'JES2'
        
        # Subtype (offset 22) - 1 = Job transmitted
        struct.pack_into('>H', record_data, 22, 1)
        
        # Triplet count (offset 24)
        struct.pack_into('>H', record_data, 24, 5)
        
        # Product section triplet
        struct.pack_into('>I', record_data, 28, 68)  # offset
        struct.pack_into('>H', record_data, 32, 12)  # length
        struct.pack_into('>H', record_data, 34, 1)   # count
        
        # Product section at offset 68
        record_data[68:70] = b'02'  # version
        record_data[70:78] = b'JES2    '  # product name
        
        # Parse
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF24ParserV3R2(base_parser)
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 24
        assert result.system_id == "SYS1"
        assert result.subtype == 1
        assert result.header['subtype_description'] == 'Job transmitted'


class TestSMF25Parser:
    """Tests for SMF Type 25 parser."""
    
    def test_parse_basic_record(self):
        """Test parsing a basic Type 25 record."""
        # Create test record (96 bytes minimum for full descriptor)
        record_data = bytearray(96)
        
        # Standard header
        struct.pack_into('>H', record_data, 0, 96)  # RDW
        struct.pack_into('>H', record_data, 2, 0)   # Segment descriptor
        record_data[4] = 0                           # System indicator
        record_data[5] = 25                          # Record type
        struct.pack_into('>I', record_data, 6, 4320000)  # Timestamp
        record_data[10:14] = bytes([0x20, 0x24, 0x00, 0x1F])  # Date
        record_data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])  # System ID "SYS1"
        
        # Job name (offset 18, 8 bytes EBCDIC) - "TESTJOB "
        record_data[18:26] = bytes([0xE3, 0xC5, 0xE2, 0xE3, 0xD1, 0xD6, 0xC2, 0x40])
        
        # Reader time/date
        struct.pack_into('>I', record_data, 26, 4320000)
        record_data[30:34] = bytes([0x20, 0x24, 0x00, 0x1F])
        
        # User ID (offset 34, 8 bytes EBCDIC) - "USER001 "
        record_data[34:42] = bytes([0xE4, 0xE2, 0xC5, 0xD9, 0xF0, 0xF0, 0xF1, 0x40])
        
        # Allocation indicators (offset 42, 2 bytes)
        struct.pack_into('>H', record_data, 42, 0x2000)  # automatic allocation
        
        # Volume counts
        struct.pack_into('>I', record_data, 44, 5)   # scratch volumes
        struct.pack_into('>I', record_data, 68, 10)  # tape volumes mounted
        struct.pack_into('>I', record_data, 72, 3)   # disk volumes mounted
        
        # Parse
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF25ParserV3R2(base_parser)
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 25
        assert result.system_id == "SYS1"
        assert result.subsystem['automatic_allocation'] == True
        assert result.subsystem['tape_volumes_mounted'] == 10
        assert result.subsystem['disk_volumes_mounted'] == 3


class TestSMF26Parser:
    """Tests for SMF Type 26 parser."""
    
    def test_parse_jes2_record(self):
        """Test parsing a JES2 Type 26 record."""
        # Create test record (100 bytes for descriptor section)
        record_data = bytearray(100)
        
        # Standard header
        struct.pack_into('>H', record_data, 0, 100)  # RDW
        struct.pack_into('>H', record_data, 2, 0)    # Segment descriptor
        record_data[4] = 0                            # System indicator
        record_data[5] = 26                           # Record type
        struct.pack_into('>I', record_data, 6, 4320000)  # Timestamp
        record_data[10:14] = bytes([0x20, 0x24, 0x00, 0x1F])  # Date
        record_data[14:18] = bytes([0xE2, 0xE8, 0xE2, 0xF1])  # System ID "SYS1"
        
        # Job name (offset 18, 8 bytes EBCDIC) - "TESTJOB "
        record_data[18:26] = bytes([0xE3, 0xC5, 0xE2, 0xE3, 0xD1, 0xD6, 0xC2, 0x40])
        
        # Reader time/date
        struct.pack_into('>I', record_data, 26, 4320000)
        record_data[30:34] = bytes([0x20, 0x24, 0x00, 0x1F])
        
        # User ID (offset 34, 8 bytes EBCDIC) - "USER001 "
        record_data[34:42] = bytes([0xE4, 0xE2, 0xC5, 0xD9, 0xF0, 0xF0, 0xF1, 0x40])
        
        # Subsystem ID (offset 46, 2 bytes) - 0x0002 = JES2
        struct.pack_into('>H', record_data, 46, 0x0002)
        
        # Indicators (offset 48, 2 bytes) - descriptor present
        struct.pack_into('>H', record_data, 48, 0x8000)
        
        # Descriptor section (offset 50)
        struct.pack_into('>H', record_data, 50, 50)  # section length
        
        # Parse
        base_parser = BaseRecordParser("EBCDIC")
        parser = SMF26ParserV3R2(base_parser)
        result = parser.parse(bytes(record_data))
        
        # Verify
        assert result.record_type == 26
        assert result.system_id == "SYS1"
        assert result.subsystem['variant'] == 'JES2'
        assert 'descriptor' in result.subsystem
