"""Property-based tests for configuration validation.

Feature: smf-queries-modernization
Property 11: Configuration Validation Rejection

This module tests that configuration parameters properly reject invalid values
according to their constraints (type, min_value, max_value, pattern).
"""

import pytest
from hypothesis import given, strategies as st, assume
from tools.smf_analyzer.smf_queries.config_parameter import ConfigParameter


class TestConfigurationValidationRejection:
    """Property 11: Configuration Validation Rejection
    
    Validates: Requirements 13.1, 13.2, 13.3, 13.4
    
    For any configuration parameter with defined constraints (min_value, max_value, pattern),
    attempting to set a value that violates those constraints should raise a ValueError
    with a descriptive message.
    """
    
    @given(
        min_val=st.integers(min_value=1, max_value=100),
        invalid_val=st.integers(min_value=-1000, max_value=0)
    )
    def test_integer_below_minimum_rejected(self, min_val, invalid_val):
        """Property: Integer values below min_value are rejected."""
        assume(invalid_val < min_val)
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=min_val,
            parameter_type='int',
            min_value=min_val
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(invalid_val)
        
        assert 'must be >=' in str(exc_info.value)
        assert str(min_val) in str(exc_info.value)
    
    @given(
        max_val=st.integers(min_value=100, max_value=1000),
        invalid_val=st.integers(min_value=1001, max_value=10000)
    )
    def test_integer_above_maximum_rejected(self, max_val, invalid_val):
        """Property: Integer values above max_value are rejected."""
        assume(invalid_val > max_val)
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=max_val,
            parameter_type='int',
            max_value=max_val
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(invalid_val)
        
        assert 'must be <=' in str(exc_info.value)
        assert str(max_val) in str(exc_info.value)

    @given(
        min_val=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
        invalid_val=st.floats(min_value=-10.0, max_value=-0.01, allow_nan=False, allow_infinity=False)
    )
    def test_float_below_minimum_rejected(self, min_val, invalid_val):
        """Property: Float values below min_value are rejected."""
        assume(invalid_val < min_val)
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=min_val,
            parameter_type='float',
            min_value=min_val
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(invalid_val)
        
        assert 'must be >=' in str(exc_info.value)
    
    @given(
        max_val=st.floats(min_value=1.0, max_value=10.0, allow_nan=False, allow_infinity=False),
        invalid_val=st.floats(min_value=10.01, max_value=100.0, allow_nan=False, allow_infinity=False)
    )
    def test_float_above_maximum_rejected(self, max_val, invalid_val):
        """Property: Float values above max_value are rejected."""
        assume(invalid_val > max_val)
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=max_val,
            parameter_type='float',
            max_value=max_val
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(invalid_val)
        
        assert 'must be <=' in str(exc_info.value)
    
    @given(
        wrong_type=st.one_of(
            st.text(min_size=1),
            st.booleans(),
            st.lists(st.integers())
        )
    )
    def test_integer_type_mismatch_rejected(self, wrong_type):
        """Property: Non-integer values are rejected for integer parameters."""
        assume(not isinstance(wrong_type, int))
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=10,
            parameter_type='int'
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(wrong_type)
        
        assert 'must be an integer' in str(exc_info.value)
    
    @given(
        wrong_type=st.one_of(
            st.text(min_size=1),
            st.booleans(),
            st.lists(st.integers())
        )
    )
    def test_float_type_mismatch_rejected(self, wrong_type):
        """Property: Non-numeric values are rejected for float parameters."""
        assume(not isinstance(wrong_type, (int, float)))
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=1.5,
            parameter_type='float'
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(wrong_type)
        
        assert 'must be a number' in str(exc_info.value)

    @given(
        wrong_type=st.one_of(
            st.integers(),
            st.floats(allow_nan=False, allow_infinity=False),
            st.lists(st.integers())
        )
    )
    def test_string_type_mismatch_rejected(self, wrong_type):
        """Property: Non-string values are rejected for string parameters."""
        assume(not isinstance(wrong_type, str))
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value='default',
            parameter_type='str'
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(wrong_type)
        
        assert 'must be a string' in str(exc_info.value)
    
    @given(
        wrong_type=st.one_of(
            st.integers(),
            st.floats(allow_nan=False, allow_infinity=False),
            st.text(min_size=1),
            st.lists(st.integers())
        )
    )
    def test_bool_type_mismatch_rejected(self, wrong_type):
        """Property: Non-boolean values are rejected for boolean parameters."""
        assume(not isinstance(wrong_type, bool))
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=True,
            parameter_type='bool'
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(wrong_type)
        
        assert 'must be a boolean' in str(exc_info.value)
    
    @given(
        invalid_string=st.text(min_size=1).filter(lambda s: not s.isdigit())
    )
    def test_pattern_mismatch_rejected(self, invalid_string):
        """Property: Strings not matching pattern are rejected."""
        # Pattern requires all digits
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value='123',
            parameter_type='str',
            pattern=r'^\d+$'
        )
        
        with pytest.raises(ValueError) as exc_info:
            param.validate(invalid_string)
        
        assert 'must match pattern' in str(exc_info.value)
    
    @given(
        min_val=st.integers(min_value=1, max_value=50),
        max_val=st.integers(min_value=51, max_value=100),
        valid_val=st.integers(min_value=1, max_value=100)
    )
    def test_range_validation_consistency(self, min_val, max_val, valid_val):
        """Property: Values within range are accepted, outside are rejected."""
        assume(min_val < max_val)
        
        param = ConfigParameter(
            name='test_param',
            description='Test parameter',
            default_value=min_val,
            parameter_type='int',
            min_value=min_val,
            max_value=max_val
        )
        
        if min_val <= valid_val <= max_val:
            # Should accept
            assert param.validate(valid_val) is True
        else:
            # Should reject
            with pytest.raises(ValueError):
                param.validate(valid_val)

    def test_registry_parameters_have_valid_defaults(self):
        """Property: All parameters in registry have defaults that pass their own validation."""
        from tools.smf_analyzer.smf_queries.config_registry import CONFIGURATION_PARAMETERS
        
        for param_name, param in CONFIGURATION_PARAMETERS.items():
            # Each parameter's default value should pass its own validation
            try:
                assert param.validate(param.default_value) is True
            except Exception as e:
                pytest.fail(
                    f"Parameter {param_name} has invalid default value "
                    f"{param.default_value}: {e}"
                )
    
    def test_registry_parameters_have_required_fields(self):
        """Property: All parameters in registry have required metadata fields."""
        from tools.smf_analyzer.smf_queries.config_registry import CONFIGURATION_PARAMETERS
        
        for param_name, param in CONFIGURATION_PARAMETERS.items():
            assert param.name is not None, f"{param_name} missing name"
            assert param.description is not None, f"{param_name} missing description"
            assert param.default_value is not None, f"{param_name} missing default_value"
            assert param.parameter_type is not None, f"{param_name} missing parameter_type"
            assert param.parameter_type in ['int', 'float', 'str', 'bool'], \
                f"{param_name} has invalid parameter_type: {param.parameter_type}"
    
    def test_registry_numeric_parameters_have_reasonable_ranges(self):
        """Property: Numeric parameters in registry have min <= default <= max."""
        from tools.smf_analyzer.smf_queries.config_registry import CONFIGURATION_PARAMETERS
        
        for param_name, param in CONFIGURATION_PARAMETERS.items():
            if param.parameter_type in ['int', 'float']:
                if param.min_value is not None:
                    assert param.default_value >= param.min_value, \
                        f"{param_name} default {param.default_value} < min {param.min_value}"
                
                if param.max_value is not None:
                    assert param.default_value <= param.max_value, \
                        f"{param_name} default {param.default_value} > max {param.max_value}"
                
                if param.min_value is not None and param.max_value is not None:
                    assert param.min_value <= param.max_value, \
                        f"{param_name} min {param.min_value} > max {param.max_value}"
    
    def test_registry_examples_are_valid(self):
        """Property: All example values in registry pass validation."""
        from tools.smf_analyzer.smf_queries.config_registry import CONFIGURATION_PARAMETERS
        
        for param_name, param in CONFIGURATION_PARAMETERS.items():
            for example in param.examples:
                try:
                    assert param.validate(example) is True
                except Exception as e:
                    pytest.fail(
                        f"Parameter {param_name} has invalid example value "
                        f"{example}: {e}"
                    )
