#!/usr/bin/env python3
"""Test script for SMF Type 110 parser."""

import json
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory


def test_smf110_parser():
    """Test parsing SMF Type 110 record."""
    
    # Read the SMF110 test file
    with open('examples/data/SMF110.smf', 'rb') as f:
        all_data = f.read()
    
    print(f"Read {len(all_data)} bytes from examples/data/SMF110.smf")
    print(f"First 20 bytes (hex): {all_data[:20].hex()}")
    
    # Extract first record (record length is in first 2 bytes)
    record_length = int.from_bytes(all_data[0:2], byteorder='big')
    print(f"\nFirst record length: {record_length} bytes")
    
    record_data = all_data[:record_length]
    
    # Create parser for SMF Type 110
    parser = SMFParserFactory.create_parser(110, "V3R2", encoding="EBCDIC")
    
    # Parse the record
    print("\nParsing SMF Type 110 record...")
    parsed_record = parser.parse(record_data, "V3R2")
    
    # Display results
    print("\n" + "="*80)
    print("PARSED SMF TYPE 110 RECORD")
    print("="*80)
    
    print(f"\nRecord Type: {parsed_record.record_type}")
    print(f"Subtype: {parsed_record.subtype}")
    print(f"Record Length: {parsed_record.record_length}")
    print(f"System ID: {parsed_record.system_id}")
    print(f"Timestamp: {parsed_record.timestamp}")
    print(f"Date: {parsed_record.date}")
    
    print("\n" + "-"*80)
    print("SMF HEADER")
    print("-"*80)
    for key, value in parsed_record.header.items():
        print(f"  {key}: {value}")
    
    if parsed_record.subsystem:
        print("\n" + "-"*80)
        print("SMF PRODUCT SECTION")
        print("-"*80)
        for key, value in parsed_record.subsystem.items():
            print(f"  {key}: {value}")
    
    if parsed_record.identification:
        print("\n" + "-"*80)
        print("CICS DATA SECTION")
        print("-"*80)
        for key, value in parsed_record.identification.items():
            if key == 'entries' and isinstance(value, list):
                print(f"  {key}: [{len(value)} entries]")
                for i, entry in enumerate(value[:5]):  # Show first 5 entries
                    print(f"    Entry {i+1}:")
                    for ek, ev in entry.items():
                        print(f"      {ek}: {ev}")
                if len(value) > 5:
                    print(f"    ... and {len(value) - 5} more entries")
            elif key == 'records' and isinstance(value, list):
                print(f"  {key}: [{len(value)} records]")
                for i, record in enumerate(value[:3]):  # Show first 3 records
                    print(f"    Record {i+1}: {record}")
                if len(value) > 3:
                    print(f"    ... and {len(value) - 3} more records")
            elif key == 'field_connectors' and isinstance(value, list):
                print(f"  {key}: [{len(value)} connectors]")
                print(f"    First 10: {value[:10]}")
            else:
                print(f"  {key}: {value}")
    
    # Convert to JSON
    print("\n" + "="*80)
    print("JSON OUTPUT")
    print("="*80)
    json_output = parsed_record.to_json()
    print(json_output[:1000] + "..." if len(json_output) > 1000 else json_output)
    
    # Save to file
    output_file = 'smf110_parsed_output.json'
    with open(output_file, 'w') as f:
        f.write(json_output)
    print(f"\nFull JSON output saved to: {output_file}")
    
    print("\n" + "="*80)
    print("TEST COMPLETED SUCCESSFULLY")
    print("="*80)


if __name__ == '__main__':
    try:
        test_smf110_parser()
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
