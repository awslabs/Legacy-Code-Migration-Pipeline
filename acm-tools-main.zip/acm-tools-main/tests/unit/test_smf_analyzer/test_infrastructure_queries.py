"""Unit tests for infrastructure sizing queries."""

import pytest
from tools.smf_analyzer.smf_queries.queries.infrastructure_queries import (
    BatchWorkloadCPUQuery,
    CICSWorkloadCPUQuery,
    DatasetStorageRequirementsQuery,
    DatasetIOPSQuery,
    NetworkBandwidthQuery,
    DB2WorkloadQuery,
    VSAMToRDSQuery
)


class TestBatchWorkloadCPUQuery:
    """Test BatchWorkloadCPUQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = BatchWorkloadCPUQuery()
        
        assert query.name == "batch_workload_cpu"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [30]
        assert query.requires_inventory is False
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = BatchWorkloadCPUQuery()
        config_params = query.configuration_parameters
        
        assert 'BATCH_CPU_CONVERSION_RATIO' in config_params
        assert 'BATCH_PEAK_HEADROOM' in config_params
        
        # Verify parameter metadata
        cpu_ratio = config_params['BATCH_CPU_CONVERSION_RATIO']
        assert cpu_ratio.default_value == 0.5
        assert cpu_ratio.parameter_type == 'float'
        assert cpu_ratio.unit == 'ratio'
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = BatchWorkloadCPUQuery()
        sql = query.get_sql()
        
        assert 'smf30_identification' in sql
        assert 'smf30_processor' in sql
        assert 'smf30_completion' in sql
        assert 'smf30_storage' in sql
        assert 'cpu_time_seconds' in sql
        assert 'service_units' in sql
    
    def test_get_sql_with_custom_analysis_days(self):
        """Test SQL generation with custom analysis_days parameter."""
        query = BatchWorkloadCPUQuery()
        sql = query.get_sql(analysis_days=180)
        
        assert '-180 days' in sql


class TestCICSWorkloadCPUQuery:
    """Test CICSWorkloadCPUQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = CICSWorkloadCPUQuery()
        
        assert query.name == "cics_workload_cpu"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [110]
        assert query.requires_inventory is False
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = CICSWorkloadCPUQuery()
        config_params = query.configuration_parameters
        
        assert 'CICS_CPU_CONVERSION_RATIO' in config_params
        assert 'CICS_PEAK_HEADROOM' in config_params
        assert 'CICS_RESPONSE_TIME_HEADROOM' in config_params
        
        # Verify parameter metadata
        response_time = config_params['CICS_RESPONSE_TIME_HEADROOM']
        assert response_time.default_value == 1.5
        assert response_time.parameter_type == 'float'
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = CICSWorkloadCPUQuery()
        sql = query.get_sql()
        
        assert 'smf110_performance' in sql
        assert 'transaction_id' in sql
        assert 'cpu_time_seconds' in sql
        assert 'elapsed_time_seconds' in sql
        assert 'transactions_per_hour' in sql


class TestDatasetStorageRequirementsQuery:
    """Test DatasetStorageRequirementsQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = DatasetStorageRequirementsQuery()
        
        assert query.name == "dataset_storage_requirements"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [14, 15, 64]
        assert query.requires_inventory is True
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = DatasetStorageRequirementsQuery()
        config_params = query.configuration_parameters
        
        assert 'STORAGE_GROWTH_HEADROOM' in config_params
        
        # Verify parameter metadata
        headroom = config_params['STORAGE_GROWTH_HEADROOM']
        assert headroom.default_value == 1.3
        assert headroom.parameter_type == 'float'
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = DatasetStorageRequirementsQuery()
        sql = query.get_sql()
        
        assert 'smf14_records' in sql
        assert 'smf15_records' in sql
        assert 'smf64_records' in sql
        assert 'inventory_datasets' in sql
        assert 'compressed_size_mb' in sql
        assert 'recommended_storage_type' in sql


class TestDatasetIOPSQuery:
    """Test DatasetIOPSQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = DatasetIOPSQuery()
        
        assert query.name == "dataset_iops"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [14, 15, 64]
        assert query.requires_inventory is False
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = DatasetIOPSQuery()
        config_params = query.configuration_parameters
        
        assert 'EBS_GP3_BASELINE_IOPS' in config_params
        assert 'EBS_GP3_MAX_IOPS' in config_params
        assert 'EBS_GP3_ADDITIONAL_IOPS_COST' in config_params
        assert 'EBS_IO2_IOPS_COST' in config_params
        
        # Verify parameter metadata
        baseline = config_params['EBS_GP3_BASELINE_IOPS']
        assert baseline.default_value == 3000
        assert baseline.parameter_type == 'int'
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = DatasetIOPSQuery()
        sql = query.get_sql()
        
        assert 'excp_count' in sql
        assert 'avg_read_iops' in sql
        assert 'peak_read_iops' in sql
        assert 'avg_write_iops' in sql
        assert 'recommended_iops' in sql
    
    def test_handles_zero_values(self):
        """Test that query handles zero IOPS values gracefully."""
        query = DatasetIOPSQuery()
        sql = query.get_sql()
        
        # Check for COALESCE to handle NULL values
        assert 'COALESCE' in sql


class TestNetworkBandwidthQuery:
    """Test NetworkBandwidthQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = NetworkBandwidthQuery()
        
        assert query.name == "network_bandwidth"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [14, 15]
        assert query.requires_inventory is False
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = NetworkBandwidthQuery()
        config_params = query.configuration_parameters
        
        assert 'NETWORK_PEAK_HEADROOM' in config_params
        
        # Verify parameter metadata
        headroom = config_params['NETWORK_PEAK_HEADROOM']
        assert headroom.default_value == 1.5
        assert headroom.parameter_type == 'float'
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = NetworkBandwidthQuery()
        sql = query.get_sql()
        
        assert 'bytes_read' in sql
        assert 'bytes_written' in sql
        assert 'avg_bandwidth_mbps' in sql
        assert 'peak_bandwidth_mbps' in sql
        assert 'avg_hourly_transfer_mb' in sql


class TestDB2WorkloadQuery:
    """Test DB2WorkloadQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = DB2WorkloadQuery()
        
        assert query.name == "db2_workload"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [100, 101]
        assert query.requires_inventory is False
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = DB2WorkloadQuery()
        config_params = query.configuration_parameters
        
        assert 'DB2_CPU_CONVERSION_RATIO' in config_params
        assert 'DB2_OVERHEAD_HEADROOM' in config_params
        assert 'DB2_MEMORY_PER_VCPU' in config_params
        assert 'DB2_LOW_HIT_RATIO_THRESHOLD' in config_params
        assert 'DB2_LOW_HIT_RATIO_MULTIPLIER' in config_params
        assert 'DB2_STORAGE_GROWTH_HEADROOM' in config_params
        assert 'DB2_IOPS_PER_1000_GETPAGE' in config_params
        assert 'DB2_IOPS_HEADROOM' in config_params
        
        # Verify parameter metadata
        cpu_ratio = config_params['DB2_CPU_CONVERSION_RATIO']
        assert cpu_ratio.default_value == 0.6
        assert cpu_ratio.parameter_type == 'float'
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = DB2WorkloadQuery()
        sql = query.get_sql()
        
        assert 'smf101_accounting' in sql
        assert 'smf100_statistics' in sql
        assert 'getpage_requests' in sql
        assert 'buffer_pool_hit_ratio' in sql
        assert 'total_cpu_seconds' in sql


class TestVSAMToRDSQuery:
    """Test VSAMToRDSQuery implementation."""
    
    def test_query_metadata(self):
        """Test that query has all required metadata."""
        query = VSAMToRDSQuery()
        
        assert query.name == "vsam_to_rds"
        assert query.category == "Infrastructure Sizing"
        assert query.record_types == [62, 64]
        assert query.requires_inventory is False
        assert len(query.description) > 0
        assert len(query.purpose) > 0
        assert len(query.migration_impact) > 0
    
    def test_configuration_parameters(self):
        """Test that query defines required configuration parameters."""
        query = VSAMToRDSQuery()
        config_params = query.configuration_parameters
        
        assert 'VSAM_STORAGE_GROWTH_HEADROOM' in config_params
        assert 'VSAM_IOPS_HEADROOM' in config_params
        assert 'RDS_VCPU_PER_1000_IOPS' in config_params
        assert 'RDS_MEMORY_PER_VCPU' in config_params
        assert 'DYNAMODB_RCU_BLOCK_SIZE_KB' in config_params
        assert 'DYNAMODB_WCU_BLOCK_SIZE_KB' in config_params
        assert 'DYNAMODB_CAPACITY_HEADROOM' in config_params
        assert 'DYNAMODB_STORAGE_COST_PER_GB' in config_params
        assert 'DYNAMODB_PROVISIONED_WCU_COST' in config_params
        assert 'DYNAMODB_PROVISIONED_RCU_COST' in config_params
        
        # Verify parameter metadata
        storage_headroom = config_params['VSAM_STORAGE_GROWTH_HEADROOM']
        assert storage_headroom.default_value == 1.5
        assert storage_headroom.parameter_type == 'float'
    
    def test_get_sql_with_defaults(self):
        """Test SQL generation with default parameters."""
        query = VSAMToRDSQuery()
        sql = query.get_sql()
        
        assert 'smf64_records' in sql
        assert 'component_name' in sql
        assert 'total_requests' in sql
        assert 'get_requests' in sql
        assert 'put_requests' in sql
        assert 'browse_requests' in sql
        assert 'recommended_database' in sql
    
    def test_database_recommendation_logic(self):
        """Test that query includes database recommendation logic."""
        query = VSAMToRDSQuery()
        sql = query.get_sql()
        
        # Check for CASE statement with recommendation logic
        assert 'CASE' in sql
        assert 'RDS' in sql
        assert 'DynamoDB' in sql


class TestInfrastructureQueriesEdgeCases:
    """Test edge cases for infrastructure sizing queries."""
    
    def test_queries_handle_missing_data(self):
        """Test that queries use NULLIF to handle missing data."""
        queries = [
            BatchWorkloadCPUQuery(),
            CICSWorkloadCPUQuery(),
            DatasetStorageRequirementsQuery(),
            DatasetIOPSQuery(),
            NetworkBandwidthQuery(),
            DB2WorkloadQuery(),
            VSAMToRDSQuery()
        ]
        
        for query in queries:
            sql = query.get_sql()
            # Check for NULL handling
            assert 'NULLIF' in sql or 'COALESCE' in sql, \
                f"{query.name} should handle NULL values"
    
    def test_queries_use_configuration_parameters(self):
        """Test that queries reference their configuration parameters."""
        # Note: Configuration parameters are injected at execution time by QueryEngine
        # The SQL itself doesn't contain the parameter values
        queries = [
            (BatchWorkloadCPUQuery(), ['BATCH_CPU_CONVERSION_RATIO', 'BATCH_PEAK_HEADROOM']),
            (CICSWorkloadCPUQuery(), ['CICS_CPU_CONVERSION_RATIO', 'CICS_PEAK_HEADROOM']),
            (DatasetStorageRequirementsQuery(), ['STORAGE_GROWTH_HEADROOM']),
            (DatasetIOPSQuery(), ['EBS_GP3_BASELINE_IOPS', 'EBS_GP3_MAX_IOPS']),
            (NetworkBandwidthQuery(), ['NETWORK_PEAK_HEADROOM']),
            (DB2WorkloadQuery(), ['DB2_CPU_CONVERSION_RATIO', 'DB2_OVERHEAD_HEADROOM']),
            (VSAMToRDSQuery(), ['VSAM_STORAGE_GROWTH_HEADROOM', 'VSAM_IOPS_HEADROOM'])
        ]
        
        for query, expected_params in queries:
            config_params = query.configuration_parameters
            for param_name in expected_params:
                assert param_name in config_params, \
                    f"{query.name} should define {param_name}"
    
    def test_all_queries_have_category(self):
        """Test that all infrastructure queries have correct category."""
        queries = [
            BatchWorkloadCPUQuery(),
            CICSWorkloadCPUQuery(),
            DatasetStorageRequirementsQuery(),
            DatasetIOPSQuery(),
            NetworkBandwidthQuery(),
            DB2WorkloadQuery(),
            VSAMToRDSQuery()
        ]
        
        for query in queries:
            assert query.category == "Infrastructure Sizing", \
                f"{query.name} should have category 'Infrastructure Sizing'"
