"""Property-based tests for SMF Type 53 parser."""

import pytest
import struct
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_record_parser.parsers.smf53_parser_v3r2 import SMF53ParserV3R2
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser


def create_smf53_record(subtype, remote_name, line_name, line_password,
                       vtam_requests, exception_responses, lustats_received,
                       bid_rejects, temporary_errors):
    """Create a valid SMF Type 53 record with given parameters."""
    record = bytearray()
    
    # Standard header (18 bytes)
    record.extend(struct.pack('>H', 85))  # Record length (will be updated)
    record.extend(struct.pack('>H', 0))   # Segment descriptor
    record.extend(struct.pack('B', 0))    # System indicator
    record.extend(struct.pack('B', 53))   # Record type
    record.extend(struct.pack('>I', 360000))  # Time (10:00:00)
    record.extend(struct.pack('>I', 0x0124001F))  # Date (2024-001)
    record.extend('SYS1'.encode('cp037'))  # System ID (EBCDIC)
    
    # Triplet for product section (6 bytes)
    record.extend(struct.pack('>H', 30))  # Product offset
    record.extend(struct.pack('>H', 8))   # Product length
    record.extend(struct.pack('>H', 1))   # Product number
    
    # Triplet for identification section (6 bytes)
    record.extend(struct.pack('>H', 38))  # Identification offset
    record.extend(struct.pack('>H', 47))  # Identification length
    record.extend(struct.pack('>H', 1))   # Identification number
    
    # Product section (8 bytes, offset 30)
    record.extend(struct.pack('>H', subtype))  # Subtype ID
    record.extend(b'\xF0\xF1')  # Record version "01" (EBCDIC)
    record.extend(b'\xD1\xC5\xE2\xF2')  # Subsystem "JES2" (EBCDIC)
    
    # Identification section (47 bytes, offset 38)
    # Remote name (8 bytes)
    record.extend(remote_name.ljust(8)[:8].encode('cp037'))
    
    # Line name (8 bytes)
    record.extend(line_name.ljust(8)[:8].encode('cp037'))
    
    # Line password (8 bytes)
    record.extend(line_password.ljust(8)[:8].encode('cp037'))
    
    # VTAM counters (5 counters, 4 bytes each = 20 bytes)
    record.extend(struct.pack('>I', vtam_requests))
    record.extend(struct.pack('>I', exception_responses))
    record.extend(struct.pack('>I', lustats_received))
    record.extend(struct.pack('>I', bid_rejects))
    record.extend(struct.pack('>I', temporary_errors))
    
    # Line identifier (3 bytes) - "SNA"
    record.extend(b'\xE2\xD5\xC1')  # "SNA" in EBCDIC
    
    # Update record length
    struct.pack_into('>H', record, 0, len(record))
    
    return bytes(record)


# Strategy for generating valid SMF Type 53 records
smf53_record_strategy = st.builds(
    create_smf53_record,
    subtype=st.integers(min_value=1, max_value=2),
    remote_name=st.text(alphabet=st.characters(min_codepoint=65, max_codepoint=90), min_size=0, max_size=8),
    line_name=st.text(alphabet=st.characters(min_codepoint=65, max_codepoint=90), min_size=0, max_size=8),
    line_password=st.text(alphabet=st.characters(min_codepoint=65, max_codepoint=90), min_size=0, max_size=8),
    vtam_requests=st.integers(min_value=0, max_value=999999),
    exception_responses=st.integers(min_value=0, max_value=999999),
    lustats_received=st.integers(min_value=0, max_value=999999),
    bid_rejects=st.integers(min_value=0, max_value=999999),
    temporary_errors=st.integers(min_value=0, max_value=999999)
)


class TestSMF53ParserProperties:
    """Property-based tests for SMF Type 53 parser."""
    
    @given(record_data=smf53_record_strategy)
    @settings(max_examples=100)
    def test_property_field_extraction_completeness(self, record_data):
        """
        Property 1: Field Extraction Completeness
        
        For any valid SMF Type 53 record, parsing should extract all standard
        header fields and all type-specific fields.
        
        Feature: smf-parser-expansion, Property 1: Field Extraction Completeness
        Validates: Requirements 2.3, 3.1, 3.2
        """
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF53ParserV3R2(base_parser)
        result = parser.parse(record_data)
        
        # Verify standard header fields are extracted
        assert result.record_type == 53
        assert result.subtype in [1, 2]
        assert result.system_id is not None
        assert result.timestamp is not None
        assert result.date is not None
        assert result.record_length > 0
        
        # Verify product section fields are extracted
        assert result.subsystem is not None
        assert 'subtype_id' in result.subsystem
        assert 'record_version' in result.subsystem
        assert 'subsystem_name' in result.subsystem
        
        # Verify identification section fields are extracted
        assert result.identification is not None
        assert 'remote_name' in result.identification
        assert 'line_name' in result.identification
        assert 'line_password' in result.identification
        assert 'vtam_requests_processed' in result.identification
        assert 'exception_responses' in result.identification
        assert 'lustats_received' in result.identification
        assert 'bid_rejects' in result.identification
        assert 'temporary_errors' in result.identification
        assert 'line_identifier' in result.identification
    
    @given(record_data=smf53_record_strategy)
    @settings(max_examples=100)
    def test_property_subtype_identification(self, record_data):
        """
        Property 2: Subtype Identification
        
        For any SMF Type 53 record, parsing should correctly identify and store
        the subtype value from the record header.
        
        Feature: smf-parser-expansion, Property 2: Subtype Identification
        Validates: Requirements 3.1, 3.3
        """
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF53ParserV3R2(base_parser)
        result = parser.parse(record_data)
        
        # Extract subtype from raw record data
        # Subtype is at offset 30 (product section start)
        expected_subtype = struct.unpack('>H', record_data[30:32])[0]
        
        # Verify subtype is correctly identified
        assert result.subtype == expected_subtype
        assert result.subsystem['subtype_id'] == expected_subtype
        assert result.subtype in [1, 2]
    
    @given(record_data=smf53_record_strategy)
    @settings(max_examples=100)
    def test_property_vtam_counter_extraction(self, record_data):
        """
        Property 3: VTAM Counter Extraction
        
        For any SMF Type 53 record, parsing should correctly extract all VTAM
        counter values from the identification section.
        
        Feature: smf-parser-expansion, Property 3: VTAM Counter Extraction
        Validates: Requirements 3.2
        """
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF53ParserV3R2(base_parser)
        result = parser.parse(record_data)
        
        # Extract counters from raw record data
        # Counters start at offset 62 (38 + 24) in identification section
        expected_vtam_requests = struct.unpack('>I', record_data[62:66])[0]
        expected_exception_responses = struct.unpack('>I', record_data[66:70])[0]
        expected_lustats_received = struct.unpack('>I', record_data[70:74])[0]
        expected_bid_rejects = struct.unpack('>I', record_data[74:78])[0]
        expected_temporary_errors = struct.unpack('>I', record_data[78:82])[0]
        
        # Verify counters are correctly extracted
        assert result.identification['vtam_requests_processed'] == expected_vtam_requests
        assert result.identification['exception_responses'] == expected_exception_responses
        assert result.identification['lustats_received'] == expected_lustats_received
        assert result.identification['bid_rejects'] == expected_bid_rejects
        assert result.identification['temporary_errors'] == expected_temporary_errors
    
    @given(record_data=smf53_record_strategy)
    @settings(max_examples=100)
    def test_property_line_identifier_extraction(self, record_data):
        """
        Property 4: Line Identifier Extraction
        
        For any SMF Type 53 record, parsing should correctly extract the line
        identifier field, which should be 'SNA' for Type 53 records.
        
        Feature: smf-parser-expansion, Property 4: Line Identifier Extraction
        Validates: Requirements 3.2
        """
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF53ParserV3R2(base_parser)
        result = parser.parse(record_data)
        
        # Verify line identifier is extracted
        assert 'line_identifier' in result.identification
        assert result.identification['line_identifier'] == 'SNA'
    
    @given(record_data=smf53_record_strategy)
    @settings(max_examples=100)
    def test_property_to_dict_roundtrip(self, record_data):
        """
        Property 5: Dictionary Conversion Preserves Data
        
        For any SMF Type 53 record, converting the parsed result to a dictionary
        and back should preserve all extracted fields.
        
        Feature: smf-parser-expansion, Property 5: Dictionary Conversion
        Validates: Requirements 7.1
        """
        base_parser = BaseRecordParser(encoding="EBCDIC")
        parser = SMF53ParserV3R2(base_parser)
        result = parser.parse(record_data)
        result_dict = result.to_dict()
        
        # Verify all standard fields are in dictionary
        assert result_dict['record_type'] == 53
        assert result_dict['subtype'] == result.subtype
        assert result_dict['system_id'] == result.system_id
        assert result_dict['timestamp'] == result.timestamp
        # Date may be converted to string in dictionary
        if isinstance(result.date, str):
            assert result_dict['date'] == result.date
        else:
            assert result_dict['date'] == str(result.date)
        assert result_dict['record_length'] == result.record_length
        
        # Verify sections are in dictionary
        assert 'header' in result_dict
        assert 'subsystem' in result_dict
        assert 'identification' in result_dict
        
        # Verify identification fields are preserved
        assert result_dict['identification']['vtam_requests_processed'] == result.identification['vtam_requests_processed']
        assert result_dict['identification']['exception_responses'] == result.identification['exception_responses']
        assert result_dict['identification']['lustats_received'] == result.identification['lustats_received']
        assert result_dict['identification']['bid_rejects'] == result.identification['bid_rejects']
        assert result_dict['identification']['temporary_errors'] == result.identification['temporary_errors']
        assert result_dict['identification']['line_identifier'] == result.identification['line_identifier']


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
