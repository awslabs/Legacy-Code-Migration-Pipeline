"""
Performance tests for Legacy Analyzer.

Tests system performance with large datasets:
- 1000+ programs
- 10,000+ artifacts
- Measures and validates performance requirements
"""

import pytest
import time
import tempfile
import os
from pathlib import Path
from typing import List, Dict
import sqlite3

from tools.legacy_analyzer.parsers.cobol_parser import COBOLDependencyParser
from tools.legacy_analyzer.parsers.jcl_parser import JCLDependencyParser
from tools.legacy_analyzer.parsers.pli_parser import PLIDependencyParser
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer
from tools.legacy_analyzer.analysis.missing_code_detector import MissingCodeDetector
from tools.legacy_analyzer.migration.package_builder import PackageBuilder
from tools.legacy_analyzer.inventory.inventory_loader import InventoryLoader
import sqlite3


class TestPerformance:
    """Performance tests for large-scale analysis."""
    
    @pytest.fixture
    def temp_db(self):
        """Create temporary database for testing."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        yield db_path
        
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    @pytest.fixture
    def large_program_set(self, temp_db):
        """Generate 1000+ test programs in database."""
        from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
        
        # Create database adapter
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        # Create dependencies table
        db_adapter.execute("""
            CREATE TABLE IF NOT EXISTS dependencies (
                source_name TEXT,
                target_name TEXT,
                dependency_type TEXT,
                source_type TEXT,
                target_type TEXT,
                line_number INTEGER
            )
        """)
        
        # Create artifact_dependencies table (new format for PackageBuilder)
        db_adapter.execute("""
            CREATE TABLE IF NOT EXISTS artifact_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_artifact_name TEXT NOT NULL,
                source_artifact_type TEXT NOT NULL,
                target_artifact_name TEXT NOT NULL,
                target_artifact_type TEXT NOT NULL,
                dependency_type TEXT NOT NULL,
                source_file_path TEXT,
                target_file_path TEXT,
                line_number INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create programs table
        db_adapter.execute("""
            CREATE TABLE IF NOT EXISTS programs (
                program_name TEXT PRIMARY KEY,
                library_name TEXT,
                link_date TEXT,
                size_bytes INTEGER,
                entry_point TEXT
            )
        """)
        
        # Generate 1000 programs with dependencies
        programs = []
        dependencies = []
        artifact_dependencies = []
        
        for i in range(1000):
            prog_name = f"PROG{i:04d}"
            programs.append((prog_name, "PRODLIB", "2024-01-01", 10000, prog_name))
            
            # Each program calls 2-5 other programs
            num_calls = min(5, (i % 5) + 2)
            for j in range(num_calls):
                target_idx = (i + j + 1) % 1000
                target_name = f"PROG{target_idx:04d}"
                dependencies.append((
                    prog_name, target_name, "CALL", "PROGRAM", "PROGRAM", 100 + j
                ))
                # Also add to artifact_dependencies table
                artifact_dependencies.append((
                    prog_name, "PROGRAM", target_name, "PROGRAM", "CALL", 
                    f"{prog_name}.cbl", f"{target_name}.cbl", 100 + j
                ))
        
        # Insert programs
        db_adapter.executemany(
            "INSERT INTO programs VALUES (?, ?, ?, ?, ?)",
            programs
        )
        
        # Insert dependencies
        db_adapter.executemany(
            "INSERT INTO dependencies VALUES (?, ?, ?, ?, ?, ?)",
            dependencies
        )
        
        # Insert artifact_dependencies
        db_adapter.executemany(
            "INSERT INTO artifact_dependencies (source_artifact_name, source_artifact_type, target_artifact_name, target_artifact_type, dependency_type, source_file_path, target_file_path, line_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            artifact_dependencies
        )
        
        db_adapter.commit()
        return db_adapter
    
    @pytest.fixture
    def large_artifact_set(self, temp_db):
        """Generate 10,000+ test artifacts in database."""
        from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
        
        # Create database adapter
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        # Create all necessary tables
        db_adapter.execute("""
            CREATE TABLE IF NOT EXISTS programs (
                program_name TEXT PRIMARY KEY,
                library_name TEXT,
                link_date TEXT,
                size_bytes INTEGER,
                entry_point TEXT
            )
        """)
        
        db_adapter.execute("""
            CREATE TABLE IF NOT EXISTS copybooks (
                copybook_name TEXT PRIMARY KEY,
                library_name TEXT,
                last_modified TEXT
            )
        """)
        
        db_adapter.execute("""
            CREATE TABLE IF NOT EXISTS datasets (
                dataset_name TEXT PRIMARY KEY,
                creation_date TEXT,
                size_mb REAL,
                volume TEXT,
                dataset_type TEXT
            )
        """)
        
        db_adapter.execute("""
            CREATE TABLE IF NOT EXISTS dependencies (
                source_name TEXT,
                target_name TEXT,
                dependency_type TEXT,
                source_type TEXT,
                target_type TEXT,
                line_number INTEGER
            )
        """)
        
        # Generate 3000 programs
        programs = [(f"PROG{i:05d}", "PRODLIB", "2024-01-01", 10000, f"PROG{i:05d}") 
                    for i in range(3000)]
        db_adapter.executemany("INSERT INTO programs VALUES (?, ?, ?, ?, ?)", programs)
        
        # Generate 4000 copybooks
        copybooks = [(f"COPY{i:05d}", "COPYLIB", "2024-01-01") 
                     for i in range(4000)]
        db_adapter.executemany("INSERT INTO copybooks VALUES (?, ?, ?)", copybooks)
        
        # Generate 3000 datasets
        datasets = [(f"DATA.SET{i:05d}", "2024-01-01", 100.0, "VOL001", "PS") 
                    for i in range(3000)]
        db_adapter.executemany("INSERT INTO datasets VALUES (?, ?, ?, ?, ?)", datasets)
        
        # Generate dependencies (each program uses 3 copybooks and 2 datasets)
        dependencies = []
        for i in range(3000):
            prog_name = f"PROG{i:05d}"
            
            # Copybook dependencies
            for j in range(3):
                copy_idx = (i * 3 + j) % 4000
                dependencies.append((
                    prog_name, f"COPY{copy_idx:05d}", "COPY", "PROGRAM", "COPYBOOK", 10 + j
                ))
            
            # Dataset dependencies
            for j in range(2):
                data_idx = (i * 2 + j) % 3000
                dependencies.append((
                    prog_name, f"DATA.SET{data_idx:05d}", "DATASET_REF", "PROGRAM", "DATASET", 50 + j
                ))
        
        db_adapter.executemany(
            "INSERT INTO dependencies VALUES (?, ?, ?, ?, ?, ?)",
            dependencies
        )
        
        db_adapter.commit()
        return db_adapter
    
    def test_parse_1000_programs_performance(self, tmp_path):
        """Test parsing 1000+ programs meets performance requirements."""
        # Create 1000 simple COBOL programs
        cobol_dir = tmp_path / "cobol"
        cobol_dir.mkdir()
        
        for i in range(1000):
            prog_file = cobol_dir / f"PROG{i:04d}.cbl"
            prog_file.write_text(f"""
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PROG{i:04d}.
       
       PROCEDURE DIVISION.
           CALL 'SUBPROG{(i+1) % 1000:04d}'.
           STOP RUN.
""")
        
        # Parse all programs and measure time
        parser = COBOLDependencyParser()
        start_time = time.time()
        
        all_deps = []
        for cobol_file in cobol_dir.glob("*.cbl"):
            deps = parser.parse_file(str(cobol_file))
            all_deps.extend(deps)
        
        elapsed_time = time.time() - start_time
        
        # Should process at least 1000 programs per minute (16.67 per second)
        # So 1000 programs should take less than 60 seconds
        assert elapsed_time < 60, f"Parsing took {elapsed_time:.2f}s, expected < 60s"
        
        # Verify we got dependencies
        assert len(all_deps) >= 1000, "Should have at least 1000 dependencies"
        
        # Calculate throughput
        throughput = 1000 / elapsed_time * 60  # programs per minute
        print(f"\nParsing throughput: {throughput:.0f} programs/minute")
        assert throughput >= 1000, f"Throughput {throughput:.0f} < 1000 programs/minute"
    
    def test_flow_analysis_1000_programs_performance(self, large_program_set):
        """Test flow analysis with 1000+ programs."""
        # Load dependencies from database
        from tools.legacy_analyzer.models.dependency import Dependency, DependencyType
        
        cursor = large_program_set.cursor()
        cursor.execute("SELECT source_name, target_name, dependency_type, source_type, target_type, line_number FROM dependencies")
        
        dependencies = []
        for row in cursor.fetchall():
            source_name, target_name, dep_type, source_type, target_type, line_num = row
            dep = Dependency(
                source_artifact=source_name,
                target_artifact=target_name,
                dependency_type=getattr(DependencyType, dep_type, dep_type),
                source_type=source_type,
                target_type=target_type,
                source_file="",
                line_number=line_num
            )
            dependencies.append(dep)
        
        analyzer = FlowAnalyzer(dependencies)
        
        # Analyze flow for 10 different starting programs
        start_time = time.time()
        
        for i in range(0, 100, 10):  # Test 10 programs
            start_prog = f"PROG{i:04d}"
            flow = analyzer.analyze_flow(start_prog, max_depth=5)
            assert flow is not None
            assert flow.start_program == start_prog
        
        elapsed_time = time.time() - start_time
        
        # Should complete in reasonable time (< 10 seconds for 10 flows)
        assert elapsed_time < 10, f"Flow analysis took {elapsed_time:.2f}s, expected < 10s"
        print(f"\nFlow analysis time: {elapsed_time:.2f}s for 10 programs")
    
    def test_complexity_analysis_large_scale(self, large_artifact_set, tmp_path):
        """Test complexity analysis with large codebase."""
        # Create source files for complexity analysis
        source_dir = tmp_path / "source"
        source_dir.mkdir()
        
        # Create 100 programs with varying complexity
        for i in range(100):
            prog_file = source_dir / f"PROG{i:05d}.cbl"
            # Generate program with varying complexity
            num_ifs = (i % 10) + 1
            if_statements = "\n           ".join([f"IF CONDITION-{j} THEN" for j in range(num_ifs)])
            
            prog_file.write_text(f"""
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PROG{i:05d}.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 CONDITION-{i} PIC 9.
       
       PROCEDURE DIVISION.
           {if_statements}
               DISPLAY 'TEST'
           END-IF.
           STOP RUN.
""")
        
        analyzer = ComplexityAnalyzer()
        
        start_time = time.time()
        
        # Analyze complexity for all programs
        results = {}
        for prog_file in source_dir.glob("*.cbl"):
            prog_name = prog_file.stem
            source_code = prog_file.read_text()
            metrics = analyzer.analyze_program(prog_name, source_code, "COBOL")
            results[prog_name] = metrics
        
        elapsed_time = time.time() - start_time
        
        # Should complete in reasonable time
        assert elapsed_time < 5, f"Complexity analysis took {elapsed_time:.2f}s, expected < 5s"
        assert len(results) == 100
        print(f"\nComplexity analysis time: {elapsed_time:.2f}s for 100 programs")
    
    def test_missing_code_detection_10k_artifacts(self, large_artifact_set):
        """Test missing code detection with 10,000+ artifacts."""
        # Load dependencies from database
        from tools.legacy_analyzer.models.dependency import Dependency, DependencyType
        
        cursor = large_artifact_set.cursor()
        cursor.execute("SELECT source_name, target_name, dependency_type, source_type, target_type, line_number FROM dependencies")
        
        dependencies = []
        for row in cursor.fetchall():
            source_name, target_name, dep_type, source_type, target_type, line_num = row
            dep = Dependency(
                source_artifact=source_name,
                target_artifact=target_name,
                dependency_type=getattr(DependencyType, dep_type, dep_type),
                source_type=source_type,
                target_type=target_type,
                source_file="",
                line_number=line_num
            )
            dependencies.append(dep)
        
        # Pass the connection object (not the adapter)
        detector = MissingCodeDetector(dependencies, large_artifact_set.conn)
        
        start_time = time.time()
        
        # Detect missing artifacts
        missing_programs = detector.detect_missing_programs()
        missing_copybooks = detector.detect_missing_copybooks()
        missing_datasets = detector.detect_missing_datasets()
        
        elapsed_time = time.time() - start_time
        
        # Should complete in reasonable time (< 5 seconds)
        assert elapsed_time < 5, f"Missing code detection took {elapsed_time:.2f}s, expected < 5s"
        
        # Verify detection works (should find no missing since we created complete inventory)
        assert len(missing_programs) == 0
        assert len(missing_copybooks) == 0
        assert len(missing_datasets) == 0
        
        print(f"\nMissing code detection time: {elapsed_time:.2f}s for 10,000+ artifacts")
    
    def test_package_builder_performance(self, large_program_set):
        """Test package builder with large program set."""
        builder = PackageBuilder(large_program_set)
        
        start_time = time.time()
        
        # Create 10 packages with different seed programs
        packages = []
        for i in range(0, 100, 10):
            seed_prog = f"PROG{i:04d}"
            package = builder.create_package(
                f"Package{i}",
                [seed_prog],
                max_depth=3
            )
            packages.append(package)
        
        elapsed_time = time.time() - start_time
        
        # Should complete in reasonable time (< 10 seconds for 10 packages)
        assert elapsed_time < 10, f"Package building took {elapsed_time:.2f}s, expected < 10s"
        assert len(packages) == 10
        
        print(f"\nPackage building time: {elapsed_time:.2f}s for 10 packages")
    
    def test_database_query_performance(self, large_artifact_set):
        """Test database query performance with large dataset."""
        start_time = time.time()
        
        # Run multiple queries
        for i in range(100):
            prog_name = f"PROG{i % 3000:05d}"
            
            # Query dependencies
            result = large_artifact_set.execute(
                "SELECT * FROM dependencies WHERE source_name = ?",
                (prog_name,)
            )
            deps = result.fetchall()
            assert len(deps) >= 0
        
        elapsed_time = time.time() - start_time
        
        # Should complete quickly (< 1 second for 100 queries)
        assert elapsed_time < 1, f"Database queries took {elapsed_time:.2f}s, expected < 1s"
        print(f"\nDatabase query time: {elapsed_time:.2f}s for 100 queries")
    
    def test_memory_usage_large_dataset(self, large_artifact_set):
        """Test memory usage remains reasonable with large dataset."""
        import sys
        
        # Get initial memory usage
        initial_size = sys.getsizeof(large_artifact_set)
        
        # Load large result set
        result = large_artifact_set.execute("SELECT * FROM dependencies")
        all_deps = result.fetchall()
        
        # Memory should be reasonable (< 100MB for result set)
        result_size = sys.getsizeof(all_deps)
        assert result_size < 100 * 1024 * 1024, f"Result set too large: {result_size / 1024 / 1024:.2f}MB"
        
        print(f"\nMemory usage: {result_size / 1024 / 1024:.2f}MB for {len(all_deps)} dependencies")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
