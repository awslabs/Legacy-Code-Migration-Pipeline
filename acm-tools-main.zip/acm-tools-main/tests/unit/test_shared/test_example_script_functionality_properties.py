"""
Property-based tests for example script functionality.

**Feature: project-reorganization, Property 8: Example script functionality**
**Validates: Requirements 8.3**

These tests verify that all existing example scripts continue to work
after the reorganization using property-based testing.
"""

import pytest
from hypothesis import given, strategies as st, settings
import subprocess
import sys
import tempfile
import os
from pathlib import Path


class TestExampleScriptFunctionalityProperties:
    """Property-based tests for example script functionality."""

    @given(st.sampled_from(['--help', '-h']))
    @settings(max_examples=100, deadline=5000)  # 5 second deadline for script execution
    def test_format_detection_example_help(self, help_flag):
        """
        **Feature: project-reorganization, Property 8: Example script functionality**
        
        For any help flag, the format detection example should display help
        information without errors.
        """
        try:
            # Test the format detection example with help flag
            result = subprocess.run([
                sys.executable, "examples/format_detection_example.py", help_flag
            ], capture_output=True, text=True, timeout=10, env={"PYTHONPATH": "."})
            
            # Help should either work (return 0) or show usage (return 2)
            # Both are acceptable for help commands
            assert result.returncode in [0, 2], f"Help command failed with code {result.returncode}: {result.stderr}"
            
        except subprocess.TimeoutExpired:
            pytest.fail("Format detection example help command timed out")
        except Exception as e:
            pytest.fail(f"Format detection example help failed: {e}")

    @given(st.sampled_from(['--help', '-h']))
    @settings(max_examples=100, deadline=5000)
    def test_smf_analysis_pipeline_help(self, help_flag):
        """
        **Feature: project-reorganization, Property 8: Example script functionality**
        
        For any help flag, the SMF analysis pipeline should display help
        information without errors.
        """
        try:
            # Test the SMF analysis pipeline with help flag
            result = subprocess.run([
                sys.executable, "examples/smf_analysis_pipeline.py", help_flag
            ], capture_output=True, text=True, timeout=10, env={"PYTHONPATH": "."})
            
            # Help should work and return 0
            assert result.returncode == 0, f"Help command failed with code {result.returncode}: {result.stderr}"
            
            # Help output should contain expected information
            assert "SMF Analysis Pipeline" in result.stdout
            assert "usage:" in result.stdout or "Usage:" in result.stdout
            
        except subprocess.TimeoutExpired:
            pytest.fail("SMF analysis pipeline help command timed out")
        except Exception as e:
            pytest.fail(f"SMF analysis pipeline help failed: {e}")

    @given(st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    @settings(max_examples=100, deadline=10000)  # 10 second deadline for file operations
    def test_format_detection_example_execution(self, test_suffix):
        """
        **Feature: project-reorganization, Property 8: Example script functionality**
        
        For any test configuration, the format detection example should execute
        without import errors or critical failures.
        """
        try:
            # Test the format detection example execution
            result = subprocess.run([
                sys.executable, "examples/format_detection_example.py"
            ], capture_output=True, text=True, timeout=15, env={"PYTHONPATH": "."})
            
            # Script should execute without import errors
            # It may fail due to missing data files, but imports should work
            if result.returncode != 0:
                # Check if failure is due to missing data files (acceptable)
                if "not found" in result.stdout.lower() or "adjust paths" in result.stdout.lower():
                    # This is expected - data files are missing
                    pass
                elif "modulenotfounderror" in result.stderr.lower() or "importerror" in result.stderr.lower():
                    pytest.fail(f"Format detection example has import errors: {result.stderr}")
                else:
                    # Other errors might be acceptable depending on the context
                    pass
            
            # If successful, should show the expected output structure
            if result.returncode == 0:
                assert "SMF File Format Detection Examples" in result.stdout
                assert "Examples complete!" in result.stdout
            
        except subprocess.TimeoutExpired:
            pytest.fail("Format detection example execution timed out")
        except Exception as e:
            pytest.fail(f"Format detection example execution failed: {e}")

    @given(st.lists(st.sampled_from(['--input', '--output']), min_size=0, max_size=2))
    @settings(max_examples=100, deadline=15000)  # 15 second deadline for pipeline operations
    def test_smf_analysis_pipeline_import_compatibility(self, args):
        """
        **Feature: project-reorganization, Property 8: Example script functionality**
        
        For any argument configuration, the SMF analysis pipeline should be able
        to import all required modules without errors.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # Create a minimal test to check imports work
                test_script = f'''
import sys
sys.path.insert(0, ".")

# Test the imports that the pipeline uses
try:
    from tools.smf_analyzer.smf_record_parser.smf_file_parser import SMFFileParser, SMFFileFormat
    from tools.smf_analyzer.smf_loader import SMFLoader
    from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
    from shared.database.schemas import UnifiedSMFSchema
    from tools.smf_analyzer.smf_queries import QueryEngine
    print("✓ All imports successful")
    sys.exit(0)
except Exception as e:
    print(f"✗ Import failed: {{e}}")
    sys.exit(1)
'''
                
                test_file = os.path.join(temp_dir, "test_imports.py")
                with open(test_file, 'w') as f:
                    f.write(test_script)
                
                # Run the import test
                result = subprocess.run([
                    sys.executable, test_file
                ], capture_output=True, text=True, timeout=10, env={"PYTHONPATH": "."})
                
                assert result.returncode == 0, f"Pipeline imports failed: {result.stderr}"
                assert "✓ All imports successful" in result.stdout
                
            except subprocess.TimeoutExpired:
                pytest.fail("Pipeline import test timed out")
            except Exception as e:
                pytest.fail(f"Pipeline import test failed: {e}")

    @given(st.text(min_size=1, max_size=10, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    @settings(max_examples=100, deadline=20000)  # 20 second deadline for full pipeline test
    def test_smf_analysis_pipeline_basic_functionality(self, test_id):
        """
        **Feature: project-reorganization, Property 8: Example script functionality**
        
        For any test configuration, the SMF analysis pipeline should handle
        missing input files gracefully and provide appropriate error messages.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # Test pipeline with non-existent input file (should fail gracefully)
                fake_input = os.path.join(temp_dir, f"fake_smf_{test_id}.dat")
                
                result = subprocess.run([
                    sys.executable, "examples/smf_analysis_pipeline.py",
                    "--input", fake_input,
                    "--output", temp_dir
                ], capture_output=True, text=True, timeout=30, env={"PYTHONPATH": "."})
                
                # Pipeline should handle missing files gracefully
                # It should not crash with import errors
                if result.returncode != 0:
                    # Check that failure is due to missing file, not import errors
                    error_output = result.stderr.lower() + result.stdout.lower()
                    
                    if "modulenotfounderror" in error_output or "importerror" in error_output:
                        pytest.fail(f"Pipeline has import errors: {result.stderr}")
                    elif "not found" in error_output or "no such file" in error_output:
                        # This is expected - input file doesn't exist
                        pass
                    else:
                        # Other errors might be acceptable
                        pass
                
            except subprocess.TimeoutExpired:
                pytest.fail("Pipeline basic functionality test timed out")
            except Exception as e:
                pytest.fail(f"Pipeline basic functionality test failed: {e}")

    @given(st.lists(st.text(min_size=1, max_size=10, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))), min_size=1, max_size=3))
    @settings(max_examples=100, deadline=10000)
    def test_example_scripts_python_syntax(self, test_params):
        """
        **Feature: project-reorganization, Property 8: Example script functionality**
        
        For any test parameters, all example scripts should have valid Python syntax
        and be importable as modules.
        """
        example_scripts = [
            "examples/format_detection_example.py",
            "examples/smf_analysis_pipeline.py"
        ]
        
        for script_path in example_scripts:
            try:
                # Test that the script has valid Python syntax
                result = subprocess.run([
                    sys.executable, "-m", "py_compile", script_path
                ], capture_output=True, text=True, timeout=5)
                
                assert result.returncode == 0, f"Script {script_path} has syntax errors: {result.stderr}"
                
            except subprocess.TimeoutExpired:
                pytest.fail(f"Syntax check for {script_path} timed out")
            except Exception as e:
                pytest.fail(f"Syntax check for {script_path} failed: {e}")

    @given(st.sampled_from([
        "examples/format_detection_example.py",
        "examples/smf_analysis_pipeline.py"
    ]))
    @settings(max_examples=100, deadline=5000)
    def test_example_script_file_existence(self, script_path):
        """
        **Feature: project-reorganization, Property 8: Example script functionality**
        
        For any example script path, the script file should exist and be readable.
        """
        try:
            # Check that the script file exists
            assert os.path.exists(script_path), f"Example script {script_path} does not exist"
            
            # Check that the script is readable
            with open(script_path, 'r') as f:
                content = f.read()
                assert len(content) > 0, f"Example script {script_path} is empty"
                assert "#!/usr/bin/env python" in content or "python" in content.lower(), f"Script {script_path} doesn't appear to be a Python script"
            
        except Exception as e:
            pytest.fail(f"Example script file check failed for {script_path}: {e}")