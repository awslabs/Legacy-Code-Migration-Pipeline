"""
Property-based tests for CLI command preservation.

**Feature: project-reorganization, Property 4: CLI command preservation**

Tests that all existing CLI commands continue to work after reorganization
and produce equivalent output.
"""

import subprocess
import pytest
import sys
from hypothesis import given, strategies as st, settings
from pathlib import Path


class TestCLIPreservationProperties:
    """Property-based tests for CLI command preservation."""

    def test_backward_compatibility_cli_commands_work(self):
        """
        **Feature: project-reorganization, Property 4: CLI command preservation**
        **Validates: Requirements 2.4, 5.4**
        
        Test that all backward compatibility CLI commands execute successfully.
        """
        # Test all backward compatibility CLI commands
        python_exe = sys.executable
        commands = [
            [python_exe, '-m', 'smf_record_parser', '--help'],
            [python_exe, '-m', 'smf_loader', '--help'],
            [python_exe, '-m', 'smf_queries', '--help'],
            [python_exe, '-m', 'legacy_analyzer', '--help']
        ]
        
        for cmd in commands:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Command should execute successfully
            assert result.returncode == 0, f"Command {' '.join(cmd)} failed with return code {result.returncode}. Error: {result.stderr}"
            
            # Should produce help output
            assert len(result.stdout) > 0, f"Command {' '.join(cmd)} produced no output"
            assert 'usage:' in result.stdout.lower(), f"Command {' '.join(cmd)} did not produce usage information"

    def test_new_tool_level_cli_commands_work(self):
        """
        **Feature: project-reorganization, Property 4: CLI command preservation**
        **Validates: Requirements 5.2**
        
        Test that new tool-level CLI commands execute successfully.
        """
        # Test new tool-level CLI commands
        python_exe = sys.executable
        commands = [
            [python_exe, '-m', 'tools.smf_analyzer', '--help'],
            [python_exe, '-m', 'tools.legacy_analyzer', '--help']
        ]
        
        for cmd in commands:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Command should execute successfully
            assert result.returncode == 0, f"Command {' '.join(cmd)} failed with return code {result.returncode}. Error: {result.stderr}"
            
            # Should produce help output
            assert len(result.stdout) > 0, f"Command {' '.join(cmd)} produced no output"
            assert 'usage:' in result.stdout.lower(), f"Command {' '.join(cmd)} did not produce usage information"

    @given(st.sampled_from(['smf_record_parser', 'smf_loader', 'smf_queries', 'legacy_analyzer']))
    @settings(max_examples=10)
    def test_cli_help_consistency_property(self, module_name):
        """
        **Feature: project-reorganization, Property 4: CLI command preservation**
        **Validates: Requirements 2.4, 5.4**
        
        Property: For any CLI module, the help command should work consistently.
        """
        cmd = [sys.executable, '-m', module_name, '--help']
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # All CLI modules should respond to --help
        assert result.returncode == 0, f"Help command failed for {module_name}"
        assert len(result.stdout) > 0, f"No help output for {module_name}"
        assert 'usage:' in result.stdout.lower(), f"No usage information for {module_name}"

    @given(st.sampled_from(['tools.smf_analyzer', 'tools.legacy_analyzer']))
    @settings(max_examples=10)
    def test_tool_level_cli_help_consistency_property(self, tool_name):
        """
        **Feature: project-reorganization, Property 4: CLI command preservation**
        **Validates: Requirements 5.2**
        
        Property: For any tool-level CLI, the help command should work consistently.
        """
        cmd = [sys.executable, '-m', tool_name, '--help']
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # All tool-level CLIs should respond to --help
        assert result.returncode == 0, f"Help command failed for {tool_name}"
        assert len(result.stdout) > 0, f"No help output for {tool_name}"
        assert 'usage:' in result.stdout.lower(), f"No usage information for {tool_name}"

    def test_smf_analyzer_subtool_access_property(self):
        """
        **Feature: project-reorganization, Property 4: CLI command preservation**
        **Validates: Requirements 5.2**
        
        Test that SMF analyzer subtools are accessible through the unified interface.
        """
        subtools = ['parser', 'loader', 'queries']
        
        for subtool in subtools:
            cmd = [sys.executable, '-m', 'tools.smf_analyzer', subtool, '--help']
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Each subtool should be accessible
            assert result.returncode == 0, f"Subtool {subtool} failed to execute"
            assert len(result.stdout) > 0, f"No output from subtool {subtool}"
            assert 'usage:' in result.stdout.lower(), f"No usage information from subtool {subtool}"

    def test_cli_command_structure_preservation(self):
        """
        **Feature: project-reorganization, Property 4: CLI command preservation**
        **Validates: Requirements 2.4, 5.4**
        
        Test that CLI command structure is preserved across reorganization.
        """
        # Test that specific command patterns still work
        python_exe = sys.executable
        test_cases = [
            # SMF Record Parser commands
            ([python_exe, '-m', 'smf_record_parser', 'parse', '--help'], 0),
            
            # SMF Loader commands  
            ([python_exe, '-m', 'smf_loader', 'load', '--help'], 0),
            ([python_exe, '-m', 'smf_loader', 'list-schemas'], 0),
            
            # SMF Queries commands
            ([python_exe, '-m', 'smf_queries', 'list', '--help'], 0),
            ([python_exe, '-m', 'smf_queries', 'categories', '--help'], 0),
            
            # Legacy Analyzer commands
            ([python_exe, '-m', 'legacy_analyzer', 'analyze', '--help'], 0),
            ([python_exe, '-m', 'legacy_analyzer', 'inventory', '--help'], 0),
        ]
        
        for cmd, expected_code in test_cases:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            assert result.returncode == expected_code, f"Command {' '.join(cmd)} returned {result.returncode}, expected {expected_code}. Error: {result.stderr}"
            
            # Commands should produce meaningful output
            if expected_code == 0:
                assert len(result.stdout) > 0, f"Command {' '.join(cmd)} produced no output"