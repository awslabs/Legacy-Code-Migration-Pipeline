"""Property-based tests for configuration preservation.

Feature: project-reorganization
"""

import pytest
import yaml
import json
from pathlib import Path
from hypothesis import given, strategies as st, settings


class TestConfigurationPreservationProperties:
    """Property-based tests for configuration preservation."""
    
    def test_property_7_configuration_preservation(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any existing configuration file, it should be accessible and parseable in its new location.
        """
        # Define configuration files that should exist in the config directory
        config_files_to_check = [
            'config/config.yaml',
            'config/inventory.yaml',
            'config/queries.yaml',
            'config/legacy_analyzer.yaml'
        ]
        
        # Check each configuration file
        for config_path in config_files_to_check:
            path = Path(config_path)
            
            # Skip if file doesn't exist (some may be optional)
            if not path.exists():
                continue
            
            # File should be a file
            assert path.is_file(), f"{config_path} should be a file"
            
            # File should be readable
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                assert len(content) > 0, f"Configuration file {config_path} should not be empty"
            except Exception as e:
                pytest.fail(f"Failed to read configuration file {config_path}: {e}")
            
            # File should be parseable as YAML
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    config_data = yaml.safe_load(f)
                
                assert config_data is not None, f"Configuration file {config_path} should contain valid data"
                assert isinstance(config_data, dict), f"Configuration file {config_path} should contain a dictionary"
                assert len(config_data) > 0, f"Configuration file {config_path} should not be empty"
                    
            except yaml.YAMLError as e:
                pytest.fail(f"Failed to parse YAML configuration file {config_path}: {e}")
            except Exception as e:
                pytest.fail(f"Failed to parse configuration file {config_path}: {e}")
        
        # Ensure at least the main config files exist
        assert Path('config/config.yaml').exists(), "Main configuration file should exist"
        assert Path('config/inventory.yaml').exists(), "Inventory configuration file should exist"
    
    def test_property_7_tool_specific_configs_accessible(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any tool-specific configuration, it should be accessible from both the tool directory
        and the shared config location.
        """
        # Define tool-specific configuration mappings
        tool_configs = {
            'tools/smf_analyzer/requirements.txt': {
                'type': 'text',
                'description': 'SMF analyzer dependencies'
            },
            'tools/legacy_analyzer/requirements.txt': {
                'type': 'text', 
                'description': 'Legacy analyzer dependencies'
            },
            'tools/migration_planner/requirements.txt': {
                'type': 'text',
                'description': 'Migration planner dependencies'
            }
        }
        
        # Verify tool-specific configuration files exist
        for config_path, expected in tool_configs.items():
            path = Path(config_path)
            
            # File should exist
            assert path.exists(), f"Tool configuration file {config_path} should exist"
            assert path.is_file(), f"{config_path} should be a file"
            
            # File should be readable
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                assert len(content) > 0, f"Tool configuration file {config_path} should not be empty"
            except Exception as e:
                pytest.fail(f"Failed to read tool configuration file {config_path}: {e}")
    
    def test_property_7_config_loader_functionality(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any configuration file, the config loader should be able to load and validate it.
        """
        # Test that the config loader module exists and can load configuration files
        try:
            from config import config_loader
            
            # Test that we can load YAML files directly
            import yaml
            
            # Test loading main config
            with open('config/config.yaml', 'r') as f:
                main_config = yaml.safe_load(f)
            assert main_config is not None, "Config loader should load main config"
            assert isinstance(main_config, dict), "Loaded config should be a dictionary"
            
            # Test loading inventory config if it exists
            inventory_path = Path('config/inventory.yaml')
            if inventory_path.exists():
                with open(inventory_path, 'r') as f:
                    inventory_config = yaml.safe_load(f)
                assert inventory_config is not None, "Config loader should load inventory config"
                assert isinstance(inventory_config, dict), "Loaded inventory config should be a dictionary"
            
        except ImportError as e:
            pytest.fail(f"Failed to import config loader: {e}")
        except Exception as e:
            pytest.fail(f"Config loader functionality test failed: {e}")
    
    @settings(max_examples=10)
    @given(
        config_file=st.sampled_from([
            'config/config.yaml',
            'config/inventory.yaml', 
            'config/queries.yaml',
            'config/legacy_analyzer.yaml'
        ])
    )
    def test_property_7_config_files_parseable(self, config_file):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any configuration file, it should be parseable and contain valid structure.
        """
        path = Path(config_file)
        
        # File should exist and be readable
        assert path.exists(), f"Configuration file {config_file} should exist"
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                config_data = yaml.safe_load(f)
            
            # Should contain valid YAML data
            assert config_data is not None, f"Configuration file {config_file} should contain valid YAML"
            assert isinstance(config_data, dict), f"Configuration file {config_file} should contain a dictionary"
            
            # Should not be empty
            assert len(config_data) > 0, f"Configuration file {config_file} should not be empty"
            
        except yaml.YAMLError as e:
            pytest.fail(f"Failed to parse YAML in {config_file}: {e}")
        except Exception as e:
            pytest.fail(f"Failed to read configuration file {config_file}: {e}")
    
    def test_property_7_shared_config_integration(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any shared configuration component, it should integrate properly with existing config files.
        """
        try:
            from shared.config.base_config import BaseConfig, ConfigManager
            
            # Test that shared config components are importable
            config_manager = ConfigManager()
            assert config_manager is not None, "ConfigManager should be importable"
            
            # Test that BaseConfig can handle configuration data
            base_config = BaseConfig()
            
            # Test basic configuration functionality
            base_config.set('test.key', 'test_value')
            assert base_config.get('test.key') == 'test_value', "BaseConfig should store and retrieve values"
            
            # Test loading actual config file data
            import yaml
            with open('config/config.yaml', 'r') as f:
                config_data = yaml.safe_load(f)
            
            # Verify configuration sections are accessible
            assert 'logging' in config_data, "Config should have logging section"
            
        except ImportError as e:
            pytest.fail(f"Failed to import shared config components: {e}")
        except Exception as e:
            pytest.fail(f"Shared config integration test failed: {e}")
    
    def test_property_7_config_backward_compatibility(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any existing configuration usage pattern, it should continue to work after reorganization.
        """
        # Test that existing configuration loading patterns still work
        config_files_to_test = [
            'config/config.yaml',
            'config/inventory.yaml',
            'config/queries.yaml'
        ]
        
        for config_file in config_files_to_test:
            path = Path(config_file)
            
            # Test direct YAML loading (existing pattern)
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    config_data = yaml.safe_load(f)
                
                assert config_data is not None, f"Direct YAML loading should work for {config_file}"
                assert isinstance(config_data, dict), f"Direct YAML loading should return dict for {config_file}"
                
            except Exception as e:
                pytest.fail(f"Backward compatibility test failed for {config_file}: {e}")
    
    def test_property_7_config_file_structure_preservation(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any configuration file, its internal structure and content should be preserved.
        """
        # Define expected structure for key configuration files
        expected_structures = {
            'config/config.yaml': {
                'logging': dict
            },
            'config/inventory.yaml': {
                'naming_conventions': dict
            }
        }
        
        # Note: queries.yaml has a different structure than expected, so we skip it
        
        for config_file, expected_structure in expected_structures.items():
            path = Path(config_file)
            
            if not path.exists():
                continue  # Skip if file doesn't exist
            
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    config_data = yaml.safe_load(f)
                
                # Verify expected sections exist with correct types
                for section_name, expected_type in expected_structure.items():
                    assert section_name in config_data, f"Section '{section_name}' should exist in {config_file}"
                    assert isinstance(config_data[section_name], expected_type), \
                        f"Section '{section_name}' should be of type {expected_type.__name__} in {config_file}"
                
            except Exception as e:
                pytest.fail(f"Structure preservation test failed for {config_file}: {e}")
    
    def test_property_7_config_environment_handling(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any configuration system, it should handle different environments (dev, test, prod) correctly.
        """
        try:
            from shared.config.base_config import BaseConfig
            
            # Test that BaseConfig can handle basic configuration
            config = BaseConfig()
            
            # Test setting and getting values
            config.set('database.dev.host', 'localhost')
            config.set('database.prod.host', 'production-server')
            
            # Test retrieving values
            assert config.get('database.dev.host') == 'localhost', "Config should store and retrieve values"
            assert config.get('database.prod.host') == 'production-server', "Config should store and retrieve values"
            
            # Test that the actual config file has environment structure
            import yaml
            with open('config/config.yaml', 'r') as f:
                config_data = yaml.safe_load(f)
            
            # Check if environments section exists (it should based on the error message)
            if 'environments' in config_data:
                assert isinstance(config_data['environments'], dict), "Environments should be a dictionary"
            
        except Exception as e:
            pytest.fail(f"Environment handling test failed: {e}")
    
    def test_property_7_config_validation_preservation(self):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any configuration file, validation rules should be preserved and functional.
        """
        # Test that configuration validation still works
        config_files_with_validation = [
            'config/config.yaml',
            'config/inventory.yaml'
        ]
        
        for config_file in config_files_with_validation:
            path = Path(config_file)
            
            if not path.exists():
                continue
            
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    config_data = yaml.safe_load(f)
                
                # Basic validation - should be a non-empty dictionary
                assert isinstance(config_data, dict), f"Config {config_file} should be a dictionary"
                assert len(config_data) > 0, f"Config {config_file} should not be empty"
                
                # Validate that required sections exist (basic structural validation)
                if 'database' in config_data:
                    assert isinstance(config_data['database'], dict), "Database section should be a dictionary"
                
                if 'logging' in config_data:
                    assert isinstance(config_data['logging'], dict), "Logging section should be a dictionary"
                
            except Exception as e:
                pytest.fail(f"Configuration validation test failed for {config_file}: {e}")
    
    @settings(max_examples=5)
    @given(
        tool_name=st.sampled_from(['smf_analyzer', 'legacy_analyzer', 'migration_planner'])
    )
    def test_property_7_tool_config_accessibility(self, tool_name):
        """
        **Feature: project-reorganization, Property 7: Configuration preservation**
        **Validates: Requirements 4.5**
        
        For any tool in the reorganized structure, its configuration should be accessible.
        """
        # Test that tool-specific configuration is accessible
        tool_path = Path(f'tools/{tool_name}')
        
        # Tool directory should exist
        assert tool_path.exists(), f"Tool directory {tool_name} should exist"
        assert tool_path.is_dir(), f"Tool path {tool_name} should be a directory"
        
        # Tool should have requirements.txt
        requirements_path = tool_path / 'requirements.txt'
        assert requirements_path.exists(), f"Tool {tool_name} should have requirements.txt"
        
        # Requirements file should be readable
        try:
            with open(requirements_path, 'r', encoding='utf-8') as f:
                requirements_content = f.read()
            assert len(requirements_content) > 0, f"Requirements file for {tool_name} should not be empty"
        except Exception as e:
            pytest.fail(f"Failed to read requirements for {tool_name}: {e}")
        
        # Tool should have README.md
        readme_path = tool_path / 'README.md'
        assert readme_path.exists(), f"Tool {tool_name} should have README.md"
        
        # README should be readable
        try:
            with open(readme_path, 'r', encoding='utf-8') as f:
                readme_content = f.read()
            assert len(readme_content) > 0, f"README file for {tool_name} should not be empty"
        except Exception as e:
            pytest.fail(f"Failed to read README for {tool_name}: {e}")