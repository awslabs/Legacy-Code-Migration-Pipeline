"""Tests for error conditions and exception handling."""

import pytest
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
from tools.smf_analyzer.smf_record_parser.parsers.base_parser import BaseRecordParser
from tools.smf_analyzer.smf_record_parser.parsers.smf30_parser_v3r2 import SMF30ParserV3R2
from tools.smf_analyzer.smf_record_parser.exceptions import (
    UnsupportedVersionError,
    UnsupportedRecordTypeError,
    ValidationError,
    EncodingError
)


class TestInvalidRecordType:
    """Test handling of invalid record types."""
    
    def test_factory_unsupported_record_type(self):
        """Test that factory raises error for unsupported record type."""
        with pytest.raises(UnsupportedRecordTypeError) as exc_info:
            SMFParserFactory.create_parser(99, "V3R2")
        
        assert exc_info.value.record_type == 99
        assert "99" in str(exc_info.value)
        assert "not supported" in str(exc_info.value)
    
    def test_parser_wrong_record_type_in_data(self):
        """Test that parser detects wrong record type in data."""
        base_parser = BaseRecordParser()
        
        # Create data with wrong record type
        data = bytearray(100)
        data[0:2] = (100).to_bytes(2, 'big')  # Length
        data[5] = 42  # Wrong record type at offset 5 (standard SMF header location)
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_record_type(bytes(data), expected_type=30)
        
        assert "type mismatch" in str(exc_info.value).lower()
        assert "30" in str(exc_info.value)
        assert "42" in str(exc_info.value)


class TestInvalidOffset:
    """Test handling of invalid offsets."""
    
    def test_offset_beyond_boundaries(self):
        """Test that offset beyond record boundaries raises error."""
        base_parser = BaseRecordParser()
        data = bytes(100)
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(data, 95, 10)
        
        assert exc_info.value.offset == 95
        assert "exceeds" in str(exc_info.value).lower()

    def test_negative_offset(self):
        """Test that negative offset raises error."""
        base_parser = BaseRecordParser()
        data = bytes(100)
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_offset(data, -5, 10)
        
        assert "negative offset" in str(exc_info.value).lower()
    
    def test_read_binary_with_invalid_offset(self):
        """Test that read_binary validates offset."""
        base_parser = BaseRecordParser()
        data = bytes(100)
        
        with pytest.raises(ValidationError):
            base_parser.read_binary(data, 98, 4)  # Would read past end


class TestMissingRequiredSection:
    """Test handling of missing required sections."""
    
    def test_missing_section_triplet_zero(self):
        """Test that zero triplet indicates missing section."""
        from tools.smf_analyzer.smf_record_parser.models.data_models import Triplet
        
        # Triplet with all zeros = section doesn't exist
        triplet = Triplet(offset=0, length=0, number=0)
        assert triplet.exists() is False


class TestUnsupportedVersion:
    """Test handling of unsupported versions."""
    
    def test_factory_unsupported_version(self):
        """Test that factory raises error for unsupported version."""
        with pytest.raises(UnsupportedVersionError) as exc_info:
            SMFParserFactory.create_parser(30, "V3R3")
        
        assert exc_info.value.version == "V3R3"
        assert exc_info.value.record_type == 30
        assert "V3R3" in str(exc_info.value)
        assert "30" in str(exc_info.value)


class TestEncodingErrors:
    """Test handling of encoding errors."""
    
    def test_invalid_utf8_sequence(self):
        """Test that invalid UTF-8 sequence raises EncodingError."""
        base_parser = BaseRecordParser(encoding="UTF-8")
        
        # Invalid UTF-8 bytes
        data = b'\xFF\xFE\xFD\xFC'
        
        with pytest.raises(EncodingError) as exc_info:
            base_parser.read_string(data, 0, 4, "test_field")
        
        assert exc_info.value.field_name == "test_field"
        assert exc_info.value.offset == 0
        assert exc_info.value.encoding == "UTF-8"


class TestRecordLengthMismatch:
    """Test handling of record length mismatches."""
    
    def test_declared_length_exceeds_actual(self):
        """Test error when declared length exceeds actual data length."""
        base_parser = BaseRecordParser()
        
        # Create 100-byte record but declare 200 bytes
        data = bytearray(100)
        data[0:2] = (200).to_bytes(2, 'big')
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_record_length(bytes(data))
        
        assert "length mismatch" in str(exc_info.value).lower()
        assert "200" in str(exc_info.value)
        assert "100" in str(exc_info.value)


class TestBinaryRangeValidation:
    """Test validation of binary field ranges."""
    
    def test_value_below_minimum(self):
        """Test that value below minimum raises ValidationError."""
        base_parser = BaseRecordParser()
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.validate_binary_range(0, 1, 10, "test_field")
        
        assert "test_field" in str(exc_info.value)
        assert "outside valid range" in str(exc_info.value)
    
    def test_value_within_range(self):
        """Test that value within range passes validation."""
        base_parser = BaseRecordParser()
        
        # Should not raise
        base_parser.validate_binary_range(5, 1, 10, "test_field")
        base_parser.validate_binary_range(1, 1, 10, "test_field")
        base_parser.validate_binary_range(10, 1, 10, "test_field")


class TestInvalidDateValues:
    """Test handling of invalid date values."""
    
    def test_invalid_day_of_year(self):
        """Test that invalid day of year raises ValidationError."""
        base_parser = BaseRecordParser()
        
        # Create packed decimal with invalid day (day 400)
        data = bytes([0x01, 0x24, 0x40, 0x0F])
        
        with pytest.raises(ValidationError) as exc_info:
            base_parser.read_date(data, 0)
        
        assert "invalid date" in str(exc_info.value).lower()
