"""Unit tests for data models."""

import pytest
import json
from datetime import datetime, date
from tools.smf_analyzer.smf_record_parser.models.data_models import Triplet, ParsedRecord


class TestTriplet:
    """Test suite for Triplet class."""
    
    def test_triplet_exists_all_nonzero(self):
        """Test that exists() returns True when all fields are non-zero."""
        triplet = Triplet(offset=100, length=50, number=1)
        assert triplet.exists() is True
    
    def test_triplet_exists_multiple_entries(self):
        """Test that exists() returns True with multiple entries."""
        triplet = Triplet(offset=200, length=64, number=5)
        assert triplet.exists() is True
    
    def test_triplet_not_exists_zero_offset(self):
        """Test that exists() returns False when offset is zero."""
        triplet = Triplet(offset=0, length=50, number=1)
        assert triplet.exists() is False
    
    def test_triplet_not_exists_zero_length(self):
        """Test that exists() returns False when length is zero."""
        triplet = Triplet(offset=100, length=0, number=1)
        assert triplet.exists() is False
    
    def test_triplet_not_exists_zero_number(self):
        """Test that exists() returns False when number is zero."""
        triplet = Triplet(offset=100, length=50, number=0)
        assert triplet.exists() is False
    
    def test_triplet_not_exists_all_zero(self):
        """Test that exists() returns False when all fields are zero."""
        triplet = Triplet(offset=0, length=0, number=0)
        assert triplet.exists() is False


class TestParsedRecord:
    """Test suite for ParsedRecord class."""
    
    def test_parsed_record_creation(self):
        """Test creating a ParsedRecord with required fields."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={"field1": "value1"}
        )
        
        assert record.record_type == 30
        assert record.subtype == 1
        assert record.record_length == 1000
        assert record.system_id == "SYS1"
        assert record.timestamp == datetime(2024, 1, 1, 12, 0, 0)
        assert record.date == date(2024, 1, 1)
        assert record.header == {"field1": "value1"}
    
    def test_parsed_record_optional_sections_default_none(self):
        """Test that optional sections default to None."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={}
        )
        
        assert record.subsystem is None
        assert record.identification is None
        assert record.io_activity is None
        assert record.completion is None
        assert record.processor is None
        assert record.excp_sections is None
        assert record.storage is None
        assert record.accounting is None
        assert record.performance is None
        assert record.operator is None
    
    def test_parsed_record_with_optional_sections(self):
        """Test creating a ParsedRecord with optional sections."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={},
            subsystem={"product": "TEST"},
            identification={"job_name": "JOB001"},
            excp_sections=[{"dd_name": "DD1"}, {"dd_name": "DD2"}]
        )
        
        assert record.subsystem == {"product": "TEST"}
        assert record.identification == {"job_name": "JOB001"}
        assert record.excp_sections == [{"dd_name": "DD1"}, {"dd_name": "DD2"}]
    
    def test_parsed_record_continuation_defaults(self):
        """Test that continuation fields default to False and 0."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={}
        )
        
        assert record.is_continuation is False
        assert record.continuation_count == 0
    
    def test_parsed_record_with_continuation(self):
        """Test creating a ParsedRecord with continuation information."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={},
            is_continuation=True,
            continuation_count=2
        )
        
        assert record.is_continuation is True
        assert record.continuation_count == 2
    
    def test_to_dict_basic(self):
        """Test converting ParsedRecord to dictionary."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={"field1": "value1"}
        )
        
        result = record.to_dict()
        
        assert result["record_type"] == 30
        assert result["subtype"] == 1
        assert result["record_length"] == 1000
        assert result["system_id"] == "SYS1"
        assert result["timestamp"] == "2024-01-01T12:00:00"
        assert result["date"] == "2024-01-01"
        assert result["header"] == {"field1": "value1"}
    
    def test_to_dict_with_optional_sections(self):
        """Test to_dict() includes optional sections when present."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={},
            subsystem={"product": "TEST"},
            identification={"job_name": "JOB001"}
        )
        
        result = record.to_dict()
        
        assert result["subsystem"] == {"product": "TEST"}
        assert result["identification"] == {"job_name": "JOB001"}
        assert result["io_activity"] is None
    
    def test_to_dict_datetime_conversion(self):
        """Test that datetime objects are converted to ISO format strings."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 3, 15, 14, 30, 45),
            date=date(2024, 3, 15),
            header={}
        )
        
        result = record.to_dict()
        
        assert isinstance(result["timestamp"], str)
        assert result["timestamp"] == "2024-03-15T14:30:45"
        assert isinstance(result["date"], str)
        assert result["date"] == "2024-03-15"
    
    def test_to_json_basic(self):
        """Test converting ParsedRecord to JSON string."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={"field1": "value1"}
        )
        
        result = record.to_json()
        
        # Verify it's valid JSON
        parsed = json.loads(result)
        assert parsed["record_type"] == 30
        assert parsed["subtype"] == 1
        assert parsed["system_id"] == "SYS1"
        assert parsed["timestamp"] == "2024-01-01T12:00:00"
        assert parsed["date"] == "2024-01-01"
    
    def test_to_json_formatting(self):
        """Test that to_json() produces formatted output."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={}
        )
        
        result = record.to_json()
        
        # Check for indentation (formatted JSON has newlines)
        assert "\n" in result
        assert "  " in result  # 2-space indentation
    
    def test_to_json_with_nested_structures(self):
        """Test to_json() with nested dictionaries and lists."""
        record = ParsedRecord(
            record_type=30,
            subtype=1,
            record_length=1000,
            system_id="SYS1",
            timestamp=datetime(2024, 1, 1, 12, 0, 0),
            date=date(2024, 1, 1),
            header={"nested": {"key": "value"}},
            excp_sections=[{"dd_name": "DD1"}, {"dd_name": "DD2"}]
        )
        
        result = record.to_json()
        parsed = json.loads(result)
        
        assert parsed["header"]["nested"]["key"] == "value"
        assert len(parsed["excp_sections"]) == 2
        assert parsed["excp_sections"][0]["dd_name"] == "DD1"
