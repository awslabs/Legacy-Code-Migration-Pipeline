"""
Property-based tests for import path correctness after reorganization.

**Feature: project-reorganization, Property 3: Import path correctness**
**Validates: Requirements 2.3, 3.5, 5.3**
"""

import pytest
import importlib
import sys
from pathlib import Path
from hypothesis import given, strategies as st
from typing import List, Tuple


class TestImportCorrectness:
    """Test that all import paths work correctly after reorganization."""
    
    def test_backward_compatibility_imports(self):
        """
        **Feature: project-reorganization, Property 3: Import path correctness**
        **Validates: Requirements 2.3, 3.5, 5.3**
        
        Test that existing import paths still work for backward compatibility.
        """
        # Test SMF record parser imports
        try:
            from tools.smf_analyzer.smf_record_parser import SMFFileParser, SMFFileFormat, SMFParserFactory
            assert SMFFileParser is not None
            assert SMFFileFormat is not None
            assert SMFParserFactory is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from tools.smf_analyzer.smf_record_parser: {e}")
        
        # Test SMF loader imports
        try:
            from tools.smf_analyzer.smf_loader import SMFLoader, BaseSchema, BaseDatabase
            assert SMFLoader is not None
            assert BaseSchema is not None
            assert BaseDatabase is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from tools.smf_analyzer.smf_loader: {e}")
        
        # Test SMF queries imports
        try:
            from tools.smf_analyzer.smf_queries import QueryEngine, BaseQuery, QueryResult
            assert QueryEngine is not None
            assert BaseQuery is not None
            assert QueryResult is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from tools.smf_analyzer.smf_queries: {e}")
        
        # Test legacy analyzer imports
        try:
            from tools.legacy_analyzer import (
                InventoryLoader, InventoryManager, DependencyAnalyzer,
                DependencyValidator, AnalysisOrchestrator, LegacyAnalyzerAPI
            )
            assert InventoryLoader is not None
            assert InventoryManager is not None
            assert DependencyAnalyzer is not None
            assert DependencyValidator is not None
            assert AnalysisOrchestrator is not None
            assert LegacyAnalyzerAPI is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from tools.legacy_analyzer: {e}")
        
        # Test database schemas imports
        try:
            from shared.database.schemas import (
                SMF30Schema, SMF110Schema, DependenciesSchema, 
                InventorySchema, SchemaRegistry
            )
            assert SMF30Schema is not None
            assert SMF110Schema is not None
            assert DependenciesSchema is not None
            assert InventorySchema is not None
            assert SchemaRegistry is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from shared.database.schemas: {e}")
    
    def test_new_tool_imports(self):
        """
        **Feature: project-reorganization, Property 3: Import path correctness**
        **Validates: Requirements 2.3, 3.5, 5.3**
        
        Test that new tool-based import paths work correctly.
        """
        # Test SMF analyzer tool imports
        try:
            from tools.smf_analyzer import SMFAnalyzer, SMFFileParser, SMFLoader, QueryEngine
            assert SMFAnalyzer is not None
            assert SMFFileParser is not None
            assert SMFLoader is not None
            assert QueryEngine is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from tools.smf_analyzer: {e}")
        
        # Test legacy analyzer tool imports
        try:
            from tools.legacy_analyzer import (
                InventoryLoader, InventoryManager, DependencyAnalyzer,
                DependencyValidator, AnalysisOrchestrator, LegacyAnalyzerAPI
            )
            assert InventoryLoader is not None
            assert InventoryManager is not None
            assert DependencyAnalyzer is not None
            assert DependencyValidator is not None
            assert AnalysisOrchestrator is not None
            assert LegacyAnalyzerAPI is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from tools.legacy_analyzer: {e}")
    
    def test_shared_infrastructure_imports(self):
        """
        **Feature: project-reorganization, Property 3: Import path correctness**
        **Validates: Requirements 2.3, 3.5, 5.3**
        
        Test that shared infrastructure imports work correctly.
        """
        # Test shared database schemas
        try:
            from shared.database.schemas import (
                SMF30Schema, SMF110Schema, DependenciesSchema, 
                InventorySchema, SchemaRegistry
            )
            assert SMF30Schema is not None
            assert SMF110Schema is not None
            assert DependenciesSchema is not None
            assert InventorySchema is not None
            assert SchemaRegistry is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from shared.database.schemas: {e}")
        
        # Test shared utilities
        try:
            from shared.utils import file_utils, validation
            assert file_utils is not None
            assert validation is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from shared.utils: {e}")
        
        # Test shared config
        try:
            from shared.config import base_config
            assert base_config is not None
        except ImportError as e:
            pytest.fail(f"Failed to import from shared.config: {e}")
    
    @given(st.sampled_from([
        'tools.smf_analyzer.smf_record_parser',
        'tools.smf_analyzer.smf_loader', 
        'tools.smf_analyzer.smf_queries',
        'tools.legacy_analyzer',
        'shared.database.schemas'
    ]))
    def test_backward_compatibility_module_importable(self, module_name: str):
        """
        **Feature: project-reorganization, Property 3: Import path correctness**
        **Validates: Requirements 2.3, 3.5, 5.3**
        
        Property: For any module in the new structure, it should be importable.
        
        Note: Backward compatibility layers have been removed. All imports now use
        the canonical paths under tools.* and shared.*
        """
        try:
            module = importlib.import_module(module_name)
            assert module is not None
            # Check that the module has expected attributes
            assert hasattr(module, '__all__')
            assert len(module.__all__) > 0
        except ImportError as e:
            pytest.fail(f"Failed to import module {module_name}: {e}")
    
    @given(st.sampled_from([
        'tools.smf_analyzer',
        'tools.legacy_analyzer',
        'shared.database.schemas',
        'shared.utils',
        'shared.config'
    ]))
    def test_new_structure_module_importable(self, module_name: str):
        """
        **Feature: project-reorganization, Property 3: Import path correctness**
        **Validates: Requirements 2.3, 3.5, 5.3**
        
        Property: For any new structure module, it should be importable.
        """
        try:
            module = importlib.import_module(module_name)
            assert module is not None
        except ImportError as e:
            pytest.fail(f"Failed to import new structure module {module_name}: {e}")
    
    def test_import_equivalence(self):
        """
        **Feature: project-reorganization, Property 3: Import path correctness**
        **Validates: Requirements 2.3, 3.5, 5.3**
        
        Test that backward compatibility imports return the same objects as new imports.
        """
        # Test SMF file parser equivalence
        from tools.smf_analyzer.smf_record_parser import SMFFileParser as OldSMFFileParser
        from tools.smf_analyzer.smf_record_parser import SMFFileParser as NewSMFFileParser
        assert OldSMFFileParser is NewSMFFileParser
        
        # Test SMF loader equivalence
        from tools.smf_analyzer.smf_loader import SMFLoader as OldSMFLoader
        from tools.smf_analyzer.smf_loader import SMFLoader as NewSMFLoader
        assert OldSMFLoader is NewSMFLoader
        
        # Test database schema equivalence
        from shared.database.schemas import SMF30Schema as OldSMF30Schema
        from shared.database.schemas import SMF30Schema as NewSMF30Schema
        assert OldSMF30Schema is NewSMF30Schema
    
    def test_relative_imports_within_tools(self):
        """
        **Feature: project-reorganization, Property 3: Import path correctness**
        **Validates: Requirements 2.3, 3.5, 5.3**
        
        Test that relative imports work correctly within tools.
        """
        # Test that we can import from within SMF analyzer
        try:
            from tools.smf_analyzer.smf_record_parser.smf_file_parser import SMFFileParser
            from tools.smf_analyzer.smf_loader.core.loader import SMFLoader
            assert SMFFileParser is not None
            assert SMFLoader is not None
        except ImportError as e:
            pytest.fail(f"Failed relative imports within SMF analyzer: {e}")
        
        # Test that we can import from within legacy analyzer
        try:
            from tools.legacy_analyzer.inventory_manager import InventoryManager
            from tools.legacy_analyzer.dependency_analyzer import DependencyAnalyzer
            assert InventoryManager is not None
            assert DependencyAnalyzer is not None
        except ImportError as e:
            pytest.fail(f"Failed relative imports within legacy analyzer: {e}")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])