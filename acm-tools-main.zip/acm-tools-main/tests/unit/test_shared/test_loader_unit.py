"""
Unit tests for SMF Loader.

Tests loading valid records, validation logic, and error handling modes.
"""

import pytest
import tempfile
import os
import json

from tools.smf_analyzer.smf_loader.core.loader import SMFLoader
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas.smf6_schema import SMF6Schema
from tools.smf_analyzer.smf_loader.schemas.smf10_schema import SMF10Schema


def create_test_record(record_type=6):
    """Create a minimal test record."""
    return {
        'record_type': record_type,
        'subtype': 0,
        'system_id': 'TEST',
        'date': '2024-01-01',
        'timestamp': '12:00:00',
        'record_length': 100,
        'header': {},
        'identification': {},
        'performance': {},
        'io_activity': {},
        'subsystem': {}
    }


class TestSMFLoaderBasics:
    """Test basic loader functionality."""
    
    def test_loader_initialization(self):
        """Test that loader can be initialized with database and schema."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            assert loader.database is not None
            assert loader.schema is not None
            assert loader.schema.record_type == 6
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_create_schema(self):
        """Test that schema creation works."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            
            # Verify tables exist
            assert loader.database.table_exists('smf_records')
            assert loader.database.table_exists('smf6_records')
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)


class TestSMFLoaderRecordLoading:
    """Test record loading functionality."""
    
    def test_load_valid_record(self):
        """Test loading a valid record."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            
            record = create_test_record(record_type=6)
            loader.load_record(record, strict=False)
            loader.database.commit()
            
            stats = loader.get_stats()
            assert stats['smf_records'] == 1
            assert stats['smf6_records'] == 1
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_load_multiple_records(self):
        """Test loading multiple records."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            
            for i in range(5):
                record = create_test_record(record_type=6)
                record['system_id'] = f'SYS{i}'
                loader.load_record(record, strict=False)
            
            loader.database.commit()
            
            stats = loader.get_stats()
            assert stats['smf_records'] == 5
            assert stats['smf6_records'] == 5
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_load_record_with_related_tables(self):
        """Test loading a record that has related tables (Type 10 with devices)."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF10Schema()
            )
            loader.create_schema()
            
            record = create_test_record(record_type=10)
            record['io_activity'] = {
                'device_count': 2,
                'devices': [
                    {'device_class': 1, 'unit_type': 2, 'device_number': 100, 'device_number_hex': '0064', 'is_virtual_io': False},
                    {'device_class': 1, 'unit_type': 2, 'device_number': 101, 'device_number_hex': '0065', 'is_virtual_io': False}
                ]
            }
            loader.load_record(record, strict=False)
            loader.database.commit()
            
            stats = loader.get_stats()
            assert stats['smf_records'] == 1
            assert stats['smf10_records'] == 1
            assert stats['smf10_devices'] == 2
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)


class TestSMFLoaderValidation:
    """Test validation logic."""
    
    def test_missing_required_field_strict_mode(self):
        """Test that missing required fields raise error in strict mode."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            
            record = create_test_record(record_type=6)
            del record['system_id']  # Remove required field
            
            with pytest.raises(ValueError, match="Missing required fields"):
                loader.load_record(record, strict=True)
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_missing_required_field_lenient_mode(self):
        """Test that missing required fields use defaults in lenient mode."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            
            record = create_test_record(record_type=6)
            del record['system_id']  # Remove required field
            
            # Should not raise in lenient mode
            loader.load_record(record, strict=False)
            loader.database.commit()
            
            stats = loader.get_stats()
            assert stats['smf_records'] == 1
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_wrong_record_type(self):
        """Test that records with wrong type are skipped."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()  # Expects type 6
            )
            loader.create_schema()
            
            record = create_test_record(record_type=0)  # Wrong type
            
            # Should not validate
            assert not loader.schema.validate_record(record)
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)


class TestSMFLoaderJSONFile:
    """Test loading from JSON files."""
    
    def test_load_json_file_single_record(self):
        """Test loading a JSON file with a single record."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as tmp_json:
            json_path = tmp_json.name
            record = create_test_record(record_type=6)
            json.dump(record, tmp_json)
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            loader.load_json_file(json_path, strict=False)
            
            stats = loader.get_stats()
            assert stats['smf_records'] == 1
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
            if os.path.exists(json_path):
                os.unlink(json_path)
    
    def test_load_json_file_multiple_records(self):
        """Test loading a JSON file with multiple records."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as tmp_json:
            json_path = tmp_json.name
            records = [create_test_record(record_type=6) for _ in range(3)]
            json.dump(records, tmp_json)
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            loader.load_json_file(json_path, strict=False)
            
            stats = loader.get_stats()
            assert stats['smf_records'] == 3
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
            if os.path.exists(json_path):
                os.unlink(json_path)
    
    def test_load_json_file_with_type_filter(self):
        """Test loading a JSON file with type filtering."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as tmp_json:
            json_path = tmp_json.name
            records = [
                create_test_record(record_type=6),
                create_test_record(record_type=30),  # Different type - should be filtered out
                create_test_record(record_type=6),
            ]
            json.dump(records, tmp_json)
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            # Should only load type 6 records
            loader.load_json_file(json_path, filter_types=[6], strict=False)
            
            stats = loader.get_stats()
            assert stats['smf_records'] == 2  # Only 2 type 6 records
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
            if os.path.exists(json_path):
                os.unlink(json_path)


class TestSMFLoaderStats:
    """Test statistics functionality."""
    
    def test_get_stats(self):
        """Test getting statistics."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            loader = SMFLoader(
                database=SQLiteAdapter(db_path),
                schema=SMF6Schema()
            )
            loader.create_schema()
            
            # Load some records
            for i in range(3):
                record = create_test_record(record_type=6)
                loader.load_record(record, strict=False)
            
            loader.database.commit()
            
            stats = loader.get_stats()
            assert 'smf_records' in stats
            assert 'smf6_records' in stats
            assert stats['smf_records'] == 3
            assert stats['smf6_records'] == 3
            
            loader.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
