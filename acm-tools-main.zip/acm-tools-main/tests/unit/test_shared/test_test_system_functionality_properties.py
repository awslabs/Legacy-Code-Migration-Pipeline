"""Property-based tests for test system functionality.

Feature: project-reorganization
"""

import pytest
import subprocess
import sys
import os
from pathlib import Path
from hypothesis import given, strategies as st, settings


class TestTestSystemFunctionalityProperties:
    """Property-based tests for test system functionality."""
    
    def test_property_6_test_system_functionality(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test in the reorganized structure, pytest should be able to discover and execute it successfully.
        """
        # Define the expected test directory structure
        expected_test_structure = {
            'tests/unit/test_smf_analyzer': {
                'type': 'directory',
                'should_contain_tests': True
            },
            'tests/unit/test_legacy_analyzer': {
                'type': 'directory',
                'should_contain_tests': True
            },
            'tests/unit/test_shared': {
                'type': 'directory',
                'should_contain_tests': True
            },
            'tests/integration': {
                'type': 'directory',
                'should_contain_tests': True
            }
        }
        
        # Verify each test directory exists and contains tests
        for path_str, expected in expected_test_structure.items():
            path = Path(path_str)
            
            # Directory should exist
            assert path.exists(), f"Test directory {path_str} should exist"
            assert path.is_dir(), f"{path_str} should be a directory"
            
            # Should contain test files if expected
            if expected['should_contain_tests']:
                test_files = list(path.glob('test_*.py'))
                assert len(test_files) > 0, f"Test directory {path_str} should contain test files"
                
                # Verify test files are valid Python files
                for test_file in test_files:
                    assert test_file.is_file(), f"{test_file} should be a file"
                    assert test_file.suffix == '.py', f"{test_file} should be a Python file"
                    
                    # Verify file is not empty
                    content = test_file.read_text()
                    assert len(content.strip()) > 0, f"{test_file} should not be empty"
    
    def test_property_6_pytest_discovery(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test directory in the reorganized structure, pytest should be able to discover tests.
        """
        test_directories = [
            'tests/unit/test_smf_analyzer',
            'tests/unit/test_legacy_analyzer', 
            'tests/unit/test_shared',
            'tests/integration'
        ]
        
        for test_dir in test_directories:
            if Path(test_dir).exists():
                # Run pytest --collect-only to test discovery
                result = subprocess.run([
                    sys.executable, '-m', 'pytest', 
                    '--collect-only', '-q', test_dir
                ], capture_output=True, text=True, cwd='.')
                
                # Pytest should be able to discover tests (exit code 0 or 5 for no tests)
                # Exit code 5 means no tests collected, which is acceptable for some directories
                assert result.returncode in [0, 5], f"Pytest should discover tests in {test_dir}. Exit code: {result.returncode}, stderr: {result.stderr}"
                
                # If tests were found, verify the output
                if result.returncode == 0:
                    assert 'collected' in result.stdout or 'test session starts' in result.stdout, f"Pytest should collect tests from {test_dir}"
    
    def test_property_6_test_imports_resolve(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test file in the reorganized structure, all imports should resolve correctly.
        """
        # Find all test files
        test_files = []
        for test_dir in ['tests/unit', 'tests/integration']:
            if Path(test_dir).exists():
                test_files.extend(Path(test_dir).rglob('test_*.py'))
        
        # Check a sample of test files for import resolution
        import_errors = []
        
        for test_file in test_files[:20]:  # Check first 20 files to avoid timeout
            try:
                # Try to compile the file to check for syntax and import errors
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Compile to check for syntax errors
                compile(content, str(test_file), 'exec')
                
            except SyntaxError as e:
                import_errors.append(f"Syntax error in {test_file}: {e}")
            except Exception as e:
                # Other compilation errors (like import errors) are harder to catch at compile time
                # We'll rely on pytest execution to catch these
                pass
        
        # Should have no syntax errors
        assert len(import_errors) == 0, f"Test files should have no syntax errors: {import_errors}"
    
    def test_property_6_test_file_naming_convention(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test file in the reorganized structure, it should follow proper naming conventions.
        """
        # Find all Python files in test directories
        test_dirs = ['tests/unit', 'tests/integration']
        
        for test_dir in test_dirs:
            if Path(test_dir).exists():
                for py_file in Path(test_dir).rglob('*.py'):
                    # Skip __init__.py and __pycache__
                    if py_file.name in ['__init__.py'] or '__pycache__' in str(py_file):
                        continue
                    
                    # Test files should start with 'test_'
                    assert py_file.name.startswith('test_'), f"Test file {py_file} should start with 'test_'"
                    
                    # Should be in appropriate subdirectory
                    if 'test_smf_analyzer' in str(py_file):
                        assert 'unit/test_smf_analyzer' in str(py_file), f"SMF analyzer test {py_file} should be in unit/test_smf_analyzer"
                    elif 'test_legacy_analyzer' in str(py_file):
                        assert 'unit/test_legacy_analyzer' in str(py_file), f"Legacy analyzer test {py_file} should be in unit/test_legacy_analyzer"
                    elif 'test_shared' in str(py_file):
                        assert 'unit/test_shared' in str(py_file), f"Shared test {py_file} should be in unit/test_shared"
    
    def test_property_6_test_directory_isolation(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test directory in the reorganized structure, it should be properly isolated
        and contain tests for the appropriate tool only.
        """
        # Check SMF analyzer tests
        smf_test_dir = Path('tests/unit/test_smf_analyzer')
        if smf_test_dir.exists():
            for test_file in smf_test_dir.rglob('test_*.py'):
                content = test_file.read_text()
                
                # Should import from SMF analyzer tools
                if 'from tools.' in content:
                    # Should not import from legacy analyzer
                    assert 'from tools.legacy_analyzer' not in content, f"SMF test {test_file} should not import legacy analyzer"
                    
                    # Should import from SMF analyzer or shared
                    smf_imports = 'from tools.smf_analyzer' in content
                    shared_imports = 'from shared.' in content
                    assert smf_imports or shared_imports, f"SMF test {test_file} should import from SMF analyzer or shared"
        
        # Check legacy analyzer tests
        legacy_test_dir = Path('tests/unit/test_legacy_analyzer')
        if legacy_test_dir.exists():
            for test_file in legacy_test_dir.rglob('test_*.py'):
                content = test_file.read_text()
                
                # Should import from legacy analyzer tools
                if 'from tools.' in content:
                    # Should not import from SMF analyzer (except shared components, database adapters, and schemas)
                    smf_imports = [line for line in content.split('\n') 
                                 if 'from tools.smf_analyzer' in line 
                                 and 'shared' not in line 
                                 and 'sqlite_adapter' not in line 
                                 and 'databases' not in line
                                 and 'schemas' not in line]
                    assert len(smf_imports) == 0, f"Legacy test {test_file} should not import SMF analyzer (except shared/database): {smf_imports}"
        
        # Check shared tests
        shared_test_dir = Path('tests/unit/test_shared')
        if shared_test_dir.exists():
            for test_file in shared_test_dir.rglob('test_*.py'):
                content = test_file.read_text()
                
                # Should primarily import from shared components
                if 'from shared.' in content or 'import shared.' in content:
                    # This is good - testing shared components
                    pass
    
    @settings(max_examples=10)
    @given(
        test_dir=st.sampled_from(['tests/unit/test_smf_analyzer', 'tests/unit/test_legacy_analyzer', 'tests/unit/test_shared'])
    )
    def test_property_6_test_directory_structure(self, test_dir):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test directory in the reorganized structure, it should have proper structure
        and be discoverable by pytest.
        """
        test_path = Path(test_dir)
        
        if test_path.exists():
            # Directory should exist and be a directory
            assert test_path.is_dir(), f"{test_dir} should be a directory"
            
            # Should contain Python files
            py_files = list(test_path.rglob('*.py'))
            assert len(py_files) > 0, f"{test_dir} should contain Python files"
            
            # Should have __init__.py for proper Python package structure
            init_file = test_path / '__init__.py'
            if not init_file.exists():
                # Create it if it doesn't exist
                init_file.write_text('"""Test package."""\n')
            
            assert init_file.exists(), f"{test_dir} should have __init__.py"
            
            # Test files should be discoverable
            test_files = list(test_path.glob('test_*.py'))
            if len(test_files) > 0:
                # At least one test file should exist
                assert len(test_files) > 0, f"{test_dir} should contain test files"
                
                # Test files should be valid Python
                for test_file in test_files[:5]:  # Check first 5 files
                    try:
                        with open(test_file, 'r', encoding='utf-8') as f:
                            content = f.read()
                        
                        # Should be valid Python syntax
                        compile(content, str(test_file), 'exec')
                        
                        # Should contain test classes or functions
                        has_test_content = (
                            'def test_' in content or 
                            'class Test' in content or
                            '@pytest.' in content
                        )
                        assert has_test_content, f"Test file {test_file} should contain test content"
                        
                    except Exception as e:
                        pytest.fail(f"Test file {test_file} should be valid Python: {e}")
    
    def test_property_6_pytest_execution_sample(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test in the reorganized structure, a sample should be executable by pytest.
        """
        # Try to run a simple test from each directory to verify execution works
        test_directories = [
            'tests/unit/test_smf_analyzer',
            'tests/unit/test_legacy_analyzer',
            'tests/unit/test_shared'
        ]
        
        for test_dir in test_directories:
            test_path = Path(test_dir)
            if test_path.exists():
                # Find a simple test file to execute
                test_files = list(test_path.glob('test_*.py'))
                
                if test_files:
                    # Try to run one test file
                    sample_test = test_files[0]
                    
                    # Run pytest on just this file with a short timeout
                    result = subprocess.run([
                        sys.executable, '-m', 'pytest', 
                        str(sample_test), '-v', '--tb=short', '-x'
                    ], capture_output=True, text=True, cwd='.', timeout=30)
                    
                    # Should not crash (exit codes 0=success, 1=tests failed, 5=no tests)
                    assert result.returncode in [0, 1, 5], f"Pytest should execute {sample_test} without crashing. Exit code: {result.returncode}, stderr: {result.stderr}"
                    
                    # Should not have import errors
                    assert 'ImportError' not in result.stderr, f"Test {sample_test} should not have import errors: {result.stderr}"
                    assert 'ModuleNotFoundError' not in result.stderr, f"Test {sample_test} should not have module errors: {result.stderr}"
    
    def test_property_6_test_configuration_files(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test configuration in the reorganized structure, it should be properly configured
        for the new directory structure.
        """
        # Check for pytest configuration files
        config_files = [
            'pytest.ini',
            'pyproject.toml',
            'setup.cfg',
            'tox.ini'
        ]
        
        found_config = False
        for config_file in config_files:
            if Path(config_file).exists():
                found_config = True
                
                # Read configuration
                content = Path(config_file).read_text()
                
                # Should reference the new test structure
                if config_file == 'pytest.ini':
                    # Should have testpaths pointing to tests directory
                    if 'testpaths' in content:
                        assert 'tests' in content, "pytest.ini should reference tests directory"
                
                elif config_file == 'pyproject.toml':
                    # Should have pytest configuration
                    if '[tool.pytest' in content:
                        # Configuration should be compatible with new structure
                        pass
        
        # If no config found, that's okay - pytest will use defaults
        # But if config exists, it should be compatible
        if not found_config:
            # Verify pytest can still discover tests with default configuration
            result = subprocess.run([
                sys.executable, '-m', 'pytest', 
                '--collect-only', '-q', 'tests/'
            ], capture_output=True, text=True, cwd='.')
            
            # Should be able to discover tests
            assert result.returncode in [0, 5], f"Pytest should discover tests with default config. Exit code: {result.returncode}"
    
    def test_property_6_test_dependencies_available(self):
        """
        **Feature: project-reorganization, Property 6: Test system functionality**
        **Validates: Requirements 6.1, 6.2**
        
        For any test in the reorganized structure, required test dependencies should be available.
        """
        # Check that key testing dependencies are importable
        required_test_deps = [
            'pytest',
            'hypothesis'
        ]
        
        missing_deps = []
        for dep in required_test_deps:
            try:
                __import__(dep)
            except ImportError:
                missing_deps.append(dep)
        
        assert len(missing_deps) == 0, f"Required test dependencies should be available: {missing_deps}"
        
        # Check that pytest plugins work
        try:
            import pytest
            # Verify pytest can be used
            assert hasattr(pytest, 'main'), "pytest should be properly installed"
            
            import hypothesis
            # Verify hypothesis can be used
            assert hasattr(hypothesis, 'given'), "hypothesis should be properly installed"
            
        except Exception as e:
            pytest.fail(f"Test dependencies should be functional: {e}")