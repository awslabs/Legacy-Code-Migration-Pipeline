"""
Property-based tests for package build correctness.

**Feature: project-reorganization, Property 10: Package build correctness**
**Validates: Requirements 6.4**
"""

import pytest
import subprocess
import tempfile
import os
import sys
import zipfile
import tarfile
from pathlib import Path
from hypothesis import given, strategies as st, settings


class TestPackageBuildCorrectnessProperties:
    """Property-based tests for package build correctness."""

    def test_property_10_package_build_creates_valid_distributions(self):
        """
        **Feature: project-reorganization, Property 10: Package build correctness**
        
        Property: Package build process creates valid wheel and source distributions
        *For any* package build operation, both wheel (.whl) and source (.tar.gz) 
        distributions should be created and be valid archives.
        **Validates: Requirements 6.4**
        """
        # Test that package building creates valid distributions
        with tempfile.TemporaryDirectory() as temp_dir:
            # Run sdist first (setuptools has issues running both commands together with --dist-dir)
            result1 = subprocess.run([
                sys.executable, 'setup.py', 'sdist', 
                '--dist-dir', temp_dir
            ], capture_output=True, text=True, cwd='.')
            
            # Run bdist_wheel second
            result2 = subprocess.run([
                sys.executable, 'setup.py', 'bdist_wheel', 
                '--dist-dir', temp_dir
            ], capture_output=True, text=True, cwd='.')
            
            # Both builds should succeed
            assert result1.returncode == 0, f"sdist build failed: {result1.stderr}"
            assert result2.returncode == 0, f"bdist_wheel build failed: {result2.stderr}"
            
            # Check that both distribution types are created
            dist_files = list(Path(temp_dir).glob('*'))
            wheel_files = [f for f in dist_files if f.suffix == '.whl']
            source_files = [f for f in dist_files if f.name.endswith('.tar.gz')]
            
            assert len(wheel_files) == 1, f"Expected 1 wheel file, got {len(wheel_files)}"
            assert len(source_files) == 1, f"Expected 1 source file, got {len(source_files)}"
            
            # Validate wheel file is a valid zip archive
            wheel_file = wheel_files[0]
            assert zipfile.is_zipfile(wheel_file), f"Wheel file {wheel_file} is not a valid zip"
            
            # Validate source file is a valid tar.gz archive
            source_file = source_files[0]
            assert tarfile.is_tarfile(source_file), f"Source file {source_file} is not a valid tar"

    def test_property_10_wheel_contains_expected_packages(self):
        """
        **Feature: project-reorganization, Property 10: Package build correctness**
        
        Property: Built wheel contains all expected package directories
        *For any* built wheel file, it should contain the tools/, shared/, config/, 
        and database_schemas/ package directories.
        **Validates: Requirements 6.4**
        """
        # Build package to temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            result = subprocess.run([
                sys.executable, 'setup.py', 'bdist_wheel', 
                '--dist-dir', temp_dir
            ], capture_output=True, text=True, cwd='.')
            
            assert result.returncode == 0, f"Package build failed: {result.stderr}"
            
            # Find the wheel file
            wheel_files = list(Path(temp_dir).glob('*.whl'))
            assert len(wheel_files) == 1, f"Expected 1 wheel file, got {len(wheel_files)}"
            
            wheel_file = wheel_files[0]
            
            # Extract and check contents
            with zipfile.ZipFile(wheel_file, 'r') as zip_ref:
                file_list = zip_ref.namelist()
                
                # Check for expected top-level packages
                expected_packages = [
                    'tools/smf_analyzer/',
                    'tools/legacy_analyzer/', 
                    'tools/migration_planner/',
                    'shared/',
                    'config/',
                    'database_schemas/'
                ]
                
                for package in expected_packages:
                    package_files = [f for f in file_list if f.startswith(package)]
                    assert len(package_files) > 0, f"Package {package} not found in wheel"

    def test_property_10_console_scripts_defined(self):
        """
        **Feature: project-reorganization, Property 10: Package build correctness**
        
        Property: Built wheel defines all expected console scripts
        *For any* built wheel file, it should define console scripts for all tools
        in the entry_points.txt file.
        **Validates: Requirements 6.4**
        """
        # Build package to temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            result = subprocess.run([
                sys.executable, 'setup.py', 'bdist_wheel', 
                '--dist-dir', temp_dir
            ], capture_output=True, text=True, cwd='.')
            
            assert result.returncode == 0, f"Package build failed: {result.stderr}"
            
            # Find the wheel file
            wheel_files = list(Path(temp_dir).glob('*.whl'))
            assert len(wheel_files) == 1
            
            wheel_file = wheel_files[0]
            
            # Extract and check entry_points.txt
            with zipfile.ZipFile(wheel_file, 'r') as zip_ref:
                # Find entry_points.txt
                entry_points_files = [f for f in zip_ref.namelist() 
                                    if f.endswith('entry_points.txt')]
                assert len(entry_points_files) == 1, "entry_points.txt not found in wheel"
                
                # Read entry points content
                with zip_ref.open(entry_points_files[0]) as ep_file:
                    content = ep_file.read().decode('utf-8')
                    
                    # Check for expected console scripts
                    expected_scripts = [
                        'smf-analyzer',
                        'smf-record-parser', 
                        'smf-loader',
                        'smf-queries',
                        'legacy-analyzer',
                        'migration-planner'
                    ]
                    
                    for script in expected_scripts:
                        assert script in content, f"Console script {script} not defined in entry_points.txt"

    def test_property_10_package_metadata_correctness(self):
        """
        **Feature: project-reorganization, Property 10: Package build correctness**
        
        Property: Built package has correct metadata
        *For any* built wheel file, the metadata should contain correct package name,
        version, and description information.
        **Validates: Requirements 6.4**
        """
        # Build package to temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            result = subprocess.run([
                sys.executable, 'setup.py', 'bdist_wheel', 
                '--dist-dir', temp_dir
            ], capture_output=True, text=True, cwd='.')
            
            assert result.returncode == 0, f"Package build failed: {result.stderr}"
            
            # Find the wheel file
            wheel_files = list(Path(temp_dir).glob('*.whl'))
            assert len(wheel_files) == 1
            
            wheel_file = wheel_files[0]
            
            # Check filename contains expected package name and version
            filename = wheel_file.name
            assert 'smf_migration_toolkit' in filename, f"Package name not in filename: {filename}"
            assert '1.0.0' in filename, f"Version not in filename: {filename}"
            
            # Extract and check METADATA
            with zipfile.ZipFile(wheel_file, 'r') as zip_ref:
                metadata_files = [f for f in zip_ref.namelist() 
                                if f.endswith('METADATA')]
                assert len(metadata_files) == 1, "METADATA file not found in wheel"
                
                # Read metadata content
                with zip_ref.open(metadata_files[0]) as metadata_file:
                    content = metadata_file.read().decode('utf-8')
                    
                    # Check for expected metadata fields
                    assert 'Name: smf-migration-toolkit' in content, "Package name not in metadata"
                    assert 'Version: 1.0.0' in content, "Version not in metadata"
                    assert 'Summary:' in content, "Summary not in metadata"

    @given(st.sampled_from(['sdist', 'bdist_wheel']))
    @settings(max_examples=2, deadline=60000)  # Limit examples since building is slow
    def test_property_10_build_commands_succeed(self, build_command):
        """
        **Feature: project-reorganization, Property 10: Package build correctness**
        
        Property: All build commands succeed without errors
        *For any* valid build command (sdist or bdist_wheel), the build
        process should complete successfully without errors.
        **Validates: Requirements 6.4**
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            # Run the build command
            cmd = [sys.executable, 'setup.py', build_command, '--dist-dir', temp_dir]
            result = subprocess.run(cmd, capture_output=True, text=True, cwd='.')
            
            # Build should succeed
            assert result.returncode == 0, f"Build command '{build_command}' failed: {result.stderr}"
            
            # Check that files were created
            dist_files = list(Path(temp_dir).glob('*'))
            assert len(dist_files) > 0, f"No distribution files created for command: {build_command}"
            
            # Verify file types match command
            if build_command == 'sdist':
                source_files = [f for f in dist_files if f.name.endswith('.tar.gz')]
                assert len(source_files) > 0, f"No source distribution created for: {build_command}"
                
            if build_command == 'bdist_wheel':
                wheel_files = [f for f in dist_files if f.suffix == '.whl']
                assert len(wheel_files) > 0, f"No wheel distribution created for: {build_command}"

    def test_property_10_installed_package_importable(self):
        """
        **Feature: project-reorganization, Property 10: Package build correctness**
        
        Property: Installed package modules are importable
        *For any* installed package, all main tool modules should be importable
        without errors.
        **Validates: Requirements 6.4**
        """
        # Test importing main tool modules
        import_tests = [
            'tools.smf_analyzer',
            'tools.legacy_analyzer', 
            'tools.migration_planner',
            'shared.config',
            'shared.utils',
            'shared.database',
            'config'
        ]
        
        for module_name in import_tests:
            try:
                __import__(module_name)
            except ImportError as e:
                pytest.fail(f"Failed to import {module_name}: {e}")

    def test_property_10_package_structure_consistency(self):
        """
        **Feature: project-reorganization, Property 10: Package build correctness**
        
        Property: Package structure is consistent between source and wheel
        *For any* package build, the directory structure in the wheel should
        match the expected source structure.
        **Validates: Requirements 6.4**
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            # Build both distributions separately (setuptools has issues with combined commands)
            result1 = subprocess.run([
                sys.executable, 'setup.py', 'sdist', 
                '--dist-dir', temp_dir
            ], capture_output=True, text=True, cwd='.')
            
            result2 = subprocess.run([
                sys.executable, 'setup.py', 'bdist_wheel', 
                '--dist-dir', temp_dir
            ], capture_output=True, text=True, cwd='.')
            
            assert result1.returncode == 0, f"sdist build failed: {result1.stderr}"
            assert result2.returncode == 0, f"bdist_wheel build failed: {result2.stderr}"
            
            # Find files
            wheel_files = list(Path(temp_dir).glob('*.whl'))
            source_files = list(Path(temp_dir).glob('*.tar.gz'))
            
            assert len(wheel_files) == 1 and len(source_files) == 1
            
            # Check wheel structure
            with zipfile.ZipFile(wheel_files[0], 'r') as zip_ref:
                wheel_files_list = [f for f in zip_ref.namelist() 
                                  if not f.endswith('.dist-info/') and not f.endswith('.egg-info/')]
                
                # Should contain Python packages
                python_files = [f for f in wheel_files_list if f.endswith('.py')]
                assert len(python_files) > 0, "No Python files found in wheel"
                
                # Should contain tool directories
                tool_dirs = set()
                for f in wheel_files_list:
                    if f.startswith('tools/'):
                        parts = f.split('/')
                        if len(parts) >= 2:
                            tool_dirs.add(parts[1])
                
                expected_tools = {'smf_analyzer', 'legacy_analyzer', 'migration_planner'}
                assert expected_tools.issubset(tool_dirs), f"Missing tools in wheel: {expected_tools - tool_dirs}"