"""Tests for PL/I include analysis functionality."""

import os
import tempfile
import pytest
from pathlib import Path
from tools.legacy_analyzer.parsers.pli_parser import PLIDependencyParser
from tools.legacy_analyzer.models.dependency import DependencyType


class TestPLIIncludeAnalysis:
    """Test PL/I include analysis functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.parser = PLIDependencyParser()
    
    def test_parse_with_include_analysis_basic(self):
        """Test basic include analysis functionality."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            inc_dir = temp_path / "inc"
            inc_dir.mkdir()
            
            # Create main program
            main_program = """
            MAINPROG: PROCEDURE OPTIONS(MAIN);
                %INCLUDE UTILS;
                CALL MAIN_PROCESS();
            END MAINPROG;
            """
            
            # Create include with executable code
            utils_include = """
            MAIN_PROCESS: PROC;
                CALL HELPER_FUNC();
                CALL ANOTHER_FUNC();
            END MAIN_PROCESS;
            """
            
            main_file = temp_path / "MAINPROG.pli"
            main_file.write_text(main_program)
            (inc_dir / "UTILS.inc").write_text(utils_include)
            
            # Test enhanced parsing
            result = self.parser.parse_with_include_analysis(main_program, str(main_file))
            
            # Should find calls from both main program and include
            assert 'calls' in result
            assert 'MAIN_PROCESS' in result['calls']
            assert 'HELPER_FUNC' in result['calls']
            assert 'ANOTHER_FUNC' in result['calls']
    
    def test_nested_includes(self):
        """Test nested include analysis."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            inc_dir = temp_path / "inc"
            inc_dir.mkdir()
            
            # Create main program
            main_program = """
            MAINPROG: PROCEDURE OPTIONS(MAIN);
                %INCLUDE LEVEL1;
                CALL MAIN_FUNC();
            END MAINPROG;
            """
            
            # Create level 1 include
            level1_include = """
            %INCLUDE LEVEL2;
            LEVEL1_PROC: PROC;
                CALL LEVEL1_FUNC();
            END LEVEL1_PROC;
            """
            
            # Create level 2 include
            level2_include = """
            LEVEL2_PROC: PROC;
                CALL LEVEL2_FUNC();
            END LEVEL2_PROC;
            """
            
            main_file = temp_path / "MAINPROG.pli"
            main_file.write_text(main_program)
            (inc_dir / "LEVEL1.inc").write_text(level1_include)
            (inc_dir / "LEVEL2.inc").write_text(level2_include)
            
            # Test enhanced parsing
            result = self.parser.parse_with_include_analysis(main_program, str(main_file))
            
            # Should find nested includes
            assert 'includes' in result
            assert 'LEVEL1' in result['includes']
            assert 'LEVEL2' in result['includes']
            
            # Should find calls from all levels
            assert 'calls' in result
            assert 'MAIN_FUNC' in result['calls']
            assert 'LEVEL1_FUNC' in result['calls']
            assert 'LEVEL2_FUNC' in result['calls']
    
    def test_circular_reference_detection(self):
        """Test circular reference detection in includes."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            inc_dir = temp_path / "inc"
            inc_dir.mkdir()
            
            # Create main program
            main_program = """
            MAINPROG: PROCEDURE OPTIONS(MAIN);
                %INCLUDE CIRCULAR_A;
                CALL MAIN_FUNC();
            END MAINPROG;
            """
            
            # Create circular includes
            circular_a = """
            %INCLUDE CIRCULAR_B;
            PROC_A: PROC;
                CALL FUNC_A();
            END PROC_A;
            """
            
            circular_b = """
            %INCLUDE CIRCULAR_A;
            PROC_B: PROC;
                CALL FUNC_B();
            END PROC_B;
            """
            
            main_file = temp_path / "MAINPROG.pli"
            main_file.write_text(main_program)
            (inc_dir / "CIRCULAR_A.inc").write_text(circular_a)
            (inc_dir / "CIRCULAR_B.inc").write_text(circular_b)
            
            # Should not hang or crash
            result = self.parser.parse_with_include_analysis(main_program, str(main_file))
            
            # Should find includes (but not get stuck in infinite loop)
            assert 'includes' in result
            assert 'CIRCULAR_A' in result['includes']
            
            # Should find some calls (but not duplicate due to circular refs)
            assert 'calls' in result
            assert 'MAIN_FUNC' in result['calls']
    
    def test_get_include_dependencies(self):
        """Test detailed dependency extraction."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            inc_dir = temp_path / "inc"
            inc_dir.mkdir()
            
            # Create main program
            main_program = """
            MAINPROG: PROCEDURE OPTIONS(MAIN);
                %INCLUDE UTILS;
                CALL MAIN_PROCESS();
            END MAINPROG;
            """
            
            # Create include with executable code
            utils_include = """
            MAIN_PROCESS: PROC;
                CALL HELPER_FUNC();
            END MAIN_PROCESS;
            """
            
            main_file = temp_path / "MAINPROG.pli"
            main_file.write_text(main_program)
            (inc_dir / "UTILS.inc").write_text(utils_include)
            
            # Test dependency extraction
            dependencies = self.parser.get_include_dependencies(main_program, str(main_file))
            
            # Should have include dependency
            include_deps = [d for d in dependencies if d.dependency_type == DependencyType.INCLUDE]
            assert len(include_deps) >= 1
            assert any(d.target_artifact == 'UTILS' for d in include_deps)
            
            # Should have call dependencies via include
            call_deps = [d for d in dependencies if d.dependency_type == DependencyType.CALL]
            assert len(call_deps) >= 1
            
            # Check that via_include information is captured in notes
            via_include_deps = [d for d in call_deps if d.notes and 'via include' in d.notes]
            assert len(via_include_deps) >= 1
    
    def test_data_only_includes_ignored(self):
        """Test that data-only includes don't contribute calls."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            inc_dir = temp_path / "inc"
            inc_dir.mkdir()
            
            # Create main program
            main_program = """
            MAINPROG: PROCEDURE OPTIONS(MAIN);
                %INCLUDE CONSTANTS;
                CALL MAIN_PROCESS();
            END MAINPROG;
            """
            
            # Create data-only include
            constants_include = """
            /* Constants only */
            DCL MAX_SIZE FIXED BIN(31) INIT(1000);
            DCL ERROR_CODES(5) CHAR(4) INIT('OK', 'WARN', 'ERR1', 'ERR2', 'FAIL');
            """
            
            main_file = temp_path / "MAINPROG.pli"
            main_file.write_text(main_program)
            (inc_dir / "CONSTANTS.inc").write_text(constants_include)
            
            # Test enhanced parsing
            basic_result = self.parser.parse(main_program)
            enhanced_result = self.parser.parse_with_include_analysis(main_program, str(main_file))
            
            # Should have same calls (data-only include shouldn't add calls)
            assert enhanced_result['calls'] == basic_result['calls']
            assert 'MAIN_PROCESS' in enhanced_result['calls']
    
    def test_include_path_resolution(self):
        """Test include path resolution with different directory structures."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create different directory structures
            (temp_path / "inc").mkdir()
            (temp_path / "include").mkdir()
            (temp_path / "copybooks").mkdir()
            
            # Test different file extensions and locations
            test_cases = [
                ("inc/UTILS.inc", "UTILS"),
                ("include/COMMON.pli", "COMMON"),
                ("copybooks/SHARED.pl1", "SHARED"),
            ]
            
            for file_path, include_name in test_cases:
                full_path = temp_path / file_path
                full_path.write_text("/* Test include */")
                
                resolved_path = self.parser._resolve_include_path(include_name, str(temp_path))
                assert resolved_path is not None
                assert os.path.exists(resolved_path)
    
    def test_library_member_format(self):
        """Test library.member format includes."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            lib_dir = temp_path / "mylib"
            lib_dir.mkdir()
            
            # Create main program with library.member format
            main_program = """
            MAINPROG: PROCEDURE OPTIONS(MAIN);
                %INCLUDE MYLIB.UTILS;
                CALL MAIN_PROCESS();
            END MAINPROG;
            """
            
            # Create library member
            utils_include = """
            MAIN_PROCESS: PROC;
                CALL HELPER_FUNC();
            END MAIN_PROCESS;
            """
            
            main_file = temp_path / "MAINPROG.pli"
            main_file.write_text(main_program)
            (lib_dir / "UTILS.inc").write_text(utils_include)
            
            # Test enhanced parsing
            result = self.parser.parse_with_include_analysis(main_program, str(main_file))
            
            # Should find the library.member include
            assert 'includes' in result
            assert 'MYLIB.UTILS' in result['includes']
            
            # Should find calls from the include
            assert 'calls' in result
            assert 'HELPER_FUNC' in result['calls']


if __name__ == '__main__':
    pytest.main([__file__, '-v'])