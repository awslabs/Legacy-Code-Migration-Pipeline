"""
Property-based tests for API compatibility after reorganization.

**Feature: project-reorganization, Property 5: API compatibility preservation**
**Validates: Requirements 2.5, 8.2**
"""

import pytest
import tempfile
import os
from hypothesis import given, strategies as st, settings


class TestAPICompatibilityProperties:
    """Property-based tests for API compatibility preservation."""

    def test_smf_file_parser_api_compatibility(self):
        """
        **Feature: project-reorganization, Property 5: API compatibility preservation**
        
        Property: SMF File Parser API remains compatible
        *For any* valid encoding parameter, the SMF File Parser should instantiate
        and provide the same interface as before reorganization.
        **Validates: Requirements 2.5, 8.2**
        """
        # Test new import path
        from tools.smf_analyzer.smf_record_parser import SMFFileParser as NewSMFFileParser
        
        # Test that the import works and can be instantiated
        try:
            parser = NewSMFFileParser(encoding='EBCDIC')
            
            # Verify expected interface exists
            assert hasattr(parser, 'parse_file'), "parse_file method should exist"
            assert hasattr(parser, 'encoding'), "encoding attribute should exist"
            
        except Exception as e:
            pytest.fail(f"SMF File Parser API compatibility broken: {e}")

    def test_smf_loader_api_compatibility(self):
        """
        **Feature: project-reorganization, Property 5: API compatibility preservation**
        
        Property: SMF Loader API remains compatible
        *For any* valid database and schema combination, the SMF Loader should
        instantiate and provide the same interface as before reorganization.
        **Validates: Requirements 2.5, 8.2**
        """
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        try:
            # Test new import path
            from tools.smf_analyzer.smf_loader import SMFLoader as NewSMFLoader
            from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter as NewSQLiteAdapter
            from shared.database.schemas import UnifiedSMFSchema as NewUnifiedSMFSchema
            
            # Test instantiation
            database = NewSQLiteAdapter(db_path)
            schema = NewUnifiedSMFSchema()
            loader = NewSMFLoader(database=database, schema=schema)
            
            # Verify expected interface exists
            assert hasattr(loader, 'create_schema'), "create_schema method should exist"
            assert hasattr(loader, 'load_json_file'), "load_json_file method should exist"
            assert hasattr(loader, 'get_stats'), "get_stats method should exist"
            
            loader.close()
            
        except Exception as e:
            pytest.fail(f"SMF Loader API compatibility broken: {e}")
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_query_engine_api_compatibility(self):
        """
        **Feature: project-reorganization, Property 5: API compatibility preservation**
        
        Property: Query Engine API remains compatible
        *For any* valid database connection, the Query Engine should instantiate
        and provide the same interface as before reorganization.
        **Validates: Requirements 2.5, 8.2**
        """
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        try:
            # Test new import path
            from tools.smf_analyzer.smf_queries import QueryEngine as NewQueryEngine
            from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter as NewSQLiteAdapter
            
            # Test instantiation
            database = NewSQLiteAdapter(db_path)
            engine = NewQueryEngine(database)
            
            # Verify expected interface exists
            assert hasattr(engine, 'execute'), "execute method should exist"
            assert hasattr(engine, 'list_queries'), "list_queries method should exist"
            
        except Exception as e:
            pytest.fail(f"Query Engine API compatibility broken: {e}")
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_legacy_analyzer_api_compatibility(self):
        """
        **Feature: project-reorganization, Property 5: API compatibility preservation**
        
        Property: Legacy Analyzer API remains compatible
        *For any* valid database connection, the Legacy Analyzer components should
        instantiate and provide the same interface as before reorganization.
        **Validates: Requirements 2.5, 8.2**
        """
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        try:
            # Test new import path
            from tools.legacy_analyzer import InventoryManager as NewInventoryManager
            from tools.legacy_analyzer import DependencyAnalyzer as NewDependencyAnalyzer
            from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter as NewSQLiteAdapter
            
            # Test instantiation
            database = NewSQLiteAdapter(db_path)
            
            inv_manager = NewInventoryManager(database=database)
            dep_analyzer = NewDependencyAnalyzer()  # No database parameter needed
            
            # Verify expected interface exists
            assert hasattr(inv_manager, 'discover_all_files'), "discover_all_files method should exist"
            assert hasattr(inv_manager, 'populate_complete_inventory'), "populate_complete_inventory method should exist"
            assert hasattr(dep_analyzer, 'analyze_artifact'), "analyze_artifact method should exist"
            
        except Exception as e:
            pytest.fail(f"Legacy Analyzer API compatibility broken: {e}")
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_schema_registry_api_compatibility(self):
        """
        **Feature: project-reorganization, Property 5: API compatibility preservation**
        
        Property: Schema Registry API remains compatible
        *For any* schema type, the schema registry should provide access to
        schemas with the same interface as before reorganization.
        **Validates: Requirements 2.5, 8.2**
        """
        try:
            # Test new import paths
            from shared.database.schemas import UnifiedSMFSchema
            from tools.smf_analyzer.smf_loader.schemas import SMF30Schema, SMF110Schema
            
            # Test schema instantiation
            unified_schema = UnifiedSMFSchema()
            smf30_schema = SMF30Schema()
            smf110_schema = SMF110Schema()
            
            # Verify expected interface exists
            for schema in [unified_schema, smf30_schema, smf110_schema]:
                assert hasattr(schema, 'get_table_definitions'), "get_table_definitions method should exist"
                assert hasattr(schema, 'record_type'), "record_type property should exist"
                assert hasattr(schema, 'record_name'), "record_name property should exist"
            
        except Exception as e:
            pytest.fail(f"Schema Registry API compatibility broken: {e}")