"""Property-based tests for shared infrastructure accessibility.

Feature: project-reorganization
"""

import pytest
import sys
import importlib
from pathlib import Path
from hypothesis import given, strategies as st, settings


class TestSharedInfrastructureProperties:
    """Property-based tests for shared infrastructure accessibility."""
    
    def test_property_2_shared_infrastructure_accessibility(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any tool in the reorganized structure, shared components should be importable and functional.
        """
        # Define the expected shared infrastructure structure
        expected_shared_structure = {
            'shared': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'required_subdirs': ['database', 'utils', 'config']
            },
            'shared/database': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'required_subdirs': ['schemas', 'adapters']
            },
            'shared/database/schemas': {
                'type': 'directory',
                'required_files': ['__init__.py', 'dependencies_schema.py', 'inventory_schema.py', 'smf_schemas.py', 'unified_schema.py', 'registry.py'],
                'optional_files': ['README.md']
            },
            'shared/database/adapters': {
                'type': 'directory',
                'required_files': ['__init__.py'],
                'optional_files': []
            },
            'shared/utils': {
                'type': 'directory',
                'required_files': ['__init__.py', 'file_utils.py', 'validation.py'],
                'optional_files': []
            },
            'shared/config': {
                'type': 'directory',
                'required_files': ['__init__.py', 'base_config.py'],
                'optional_files': []
            }
        }
        
        # Verify each expected directory and its contents
        for path_str, expected in expected_shared_structure.items():
            path = Path(path_str)
            
            # Directory should exist
            assert path.exists(), f"Shared directory {path_str} should exist"
            assert path.is_dir(), f"{path_str} should be a directory"
            
            # Check required files
            for required_file in expected['required_files']:
                file_path = path / required_file
                assert file_path.exists(), f"Required file {path_str}/{required_file} should exist"
                assert file_path.is_file(), f"{path_str}/{required_file} should be a file"
            
            # Check required subdirectories
            for required_subdir in expected.get('required_subdirs', []):
                subdir_path = path / required_subdir
                assert subdir_path.exists(), f"Required subdirectory {path_str}/{required_subdir} should exist"
                assert subdir_path.is_dir(), f"{path_str}/{required_subdir} should be a directory"
    
    def test_property_2_shared_database_schemas_importable(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any tool in the reorganized structure, shared database schemas should be importable.
        """
        # Test importing shared database schemas
        try:
            # Import the main shared database module
            import shared.database
            assert hasattr(shared.database, '__file__'), "shared.database should be a valid module"
            
            # Import specific schema modules
            from shared.database.schemas import dependencies_schema
            from shared.database.schemas import inventory_schema
            from shared.database.schemas import smf_schemas
            from shared.database.schemas import unified_schema
            from shared.database.schemas import registry
            
            # Verify key classes are accessible
            assert hasattr(dependencies_schema, 'DependenciesSchema'), "DependenciesSchema should be accessible"
            assert hasattr(inventory_schema, 'InventorySchema'), "InventorySchema should be accessible"
            assert hasattr(unified_schema, 'UnifiedSMFSchema'), "UnifiedSMFSchema should be accessible"
            assert hasattr(registry, 'SchemaRegistry'), "SchemaRegistry should be accessible"
            
        except ImportError as e:
            pytest.fail(f"Failed to import shared database schemas: {e}")
    
    def test_property_2_shared_utils_importable(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any tool in the reorganized structure, shared utilities should be importable and functional.
        """
        # Test importing shared utilities
        try:
            # Import the main shared utils module
            import shared.utils
            assert hasattr(shared.utils, '__file__'), "shared.utils should be a valid module"
            
            # Import specific utility modules
            from shared.utils import file_utils
            from shared.utils import validation
            
            # Verify key functions are accessible
            assert hasattr(file_utils, 'ensure_directory_exists'), "ensure_directory_exists should be accessible"
            assert hasattr(file_utils, 'safe_file_read'), "safe_file_read should be accessible"
            assert hasattr(file_utils, 'normalize_path'), "normalize_path should be accessible"
            
            assert hasattr(validation, 'validate_artifact_name'), "validate_artifact_name should be accessible"
            assert hasattr(validation, 'sanitize_string'), "sanitize_string should be accessible"
            assert hasattr(validation, 'is_valid_language'), "is_valid_language should be accessible"
            
        except ImportError as e:
            pytest.fail(f"Failed to import shared utilities: {e}")
    
    def test_property_2_shared_config_importable(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any tool in the reorganized structure, shared configuration should be importable and functional.
        """
        # Test importing shared configuration
        try:
            # Import the main shared config module
            import shared.config
            assert hasattr(shared.config, '__file__'), "shared.config should be a valid module"
            
            # Import specific config modules
            from shared.config import base_config
            
            # Verify key classes are accessible
            assert hasattr(base_config, 'BaseConfig'), "BaseConfig should be accessible"
            assert hasattr(base_config, 'ConfigManager'), "ConfigManager should be accessible"
            assert hasattr(base_config, 'load_config'), "load_config function should be accessible"
            
        except ImportError as e:
            pytest.fail(f"Failed to import shared configuration: {e}")
    
    @settings(max_examples=10)
    @given(
        shared_module=st.sampled_from(['shared.database', 'shared.utils', 'shared.config'])
    )
    def test_property_2_shared_modules_functional(self, shared_module):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any shared module, it should be importable and contain expected functionality.
        """
        try:
            # Import the module
            module = importlib.import_module(shared_module)
            assert hasattr(module, '__file__'), f"{shared_module} should be a valid module"
            
            # Verify module has expected attributes based on its type
            if shared_module == 'shared.database':
                # Database module should re-export schemas
                expected_attrs = ['dependencies_schema', 'inventory_schema', 'smf_schemas', 'unified_schema', 'registry']
                for attr in expected_attrs:
                    assert hasattr(module, attr), f"{shared_module} should have {attr}"
            
            elif shared_module == 'shared.utils':
                # Utils module should have utility functions
                expected_attrs = ['ensure_directory_exists', 'validate_artifact_name', 'sanitize_string']
                for attr in expected_attrs:
                    assert hasattr(module, attr), f"{shared_module} should have {attr}"
            
            elif shared_module == 'shared.config':
                # Config module should have configuration classes
                expected_attrs = ['BaseConfig', 'ConfigManager', 'load_config']
                for attr in expected_attrs:
                    assert hasattr(module, attr), f"{shared_module} should have {attr}"
                    
        except ImportError as e:
            pytest.fail(f"Failed to import {shared_module}: {e}")
    
    def test_property_2_shared_utils_functionality(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any tool using shared utilities, the utility functions should work correctly.
        """
        from shared.utils.file_utils import normalize_path, get_file_extension
        from shared.utils.validation import validate_artifact_name, normalize_language_name, sanitize_string
        
        # Test file utilities
        assert normalize_path('test/path') == 'test/path', "normalize_path should work correctly"
        assert normalize_path('test\\path') == 'test/path', "normalize_path should convert backslashes"
        assert get_file_extension('test.py') == 'py', "get_file_extension should work correctly"
        assert get_file_extension('test') == '', "get_file_extension should handle files without extension"
        
        # Test validation utilities
        assert validate_artifact_name('TESTPROG') == True, "validate_artifact_name should accept valid names"
        assert validate_artifact_name('test-prog') == False, "validate_artifact_name should reject invalid names"
        
        assert normalize_language_name('cobol') == 'COBOL', "normalize_language_name should normalize correctly"
        assert normalize_language_name('PL/I') == 'PLI', "normalize_language_name should handle variations"
        
        assert sanitize_string('test\x00string') == 'teststring', "sanitize_string should remove null bytes"
        assert len(sanitize_string('a' * 100, max_length=50)) == 50, "sanitize_string should truncate correctly"
    
    def test_property_2_shared_config_functionality(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any tool using shared configuration, the configuration classes should work correctly.
        """
        from shared.config.base_config import BaseConfig, ConfigManager
        
        # Test BaseConfig functionality
        config = BaseConfig()
        
        # Test setting and getting values
        config.set('test.key', 'test_value')
        assert config.get('test.key') == 'test_value', "BaseConfig should store and retrieve values"
        
        # Test default values
        config.set_default('default.key', 'default_value')
        assert config.get('default.key') == 'default_value', "BaseConfig should handle default values"
        
        # Test non-existent keys
        assert config.get('nonexistent.key', 'fallback') == 'fallback', "BaseConfig should return fallback for missing keys"
        
        # Test ConfigManager singleton
        manager1 = ConfigManager()
        manager2 = ConfigManager()
        assert manager1 is manager2, "ConfigManager should be a singleton"
    
    @settings(max_examples=5)
    @given(
        schema_name=st.sampled_from(['dependencies_schema', 'inventory_schema', 'smf_schemas', 'unified_schema', 'registry'])
    )
    def test_property_2_database_schemas_functional(self, schema_name):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any database schema in shared infrastructure, it should be importable and functional.
        """
        try:
            # Import the specific schema module
            schema_module = importlib.import_module(f'shared.database.schemas.{schema_name}')
            assert hasattr(schema_module, '__file__'), f"{schema_name} should be a valid module"
            
            # Verify module has expected exports
            assert hasattr(schema_module, '__all__'), f"{schema_name} should have __all__ defined"
            
            # Verify exports are not empty
            exports = getattr(schema_module, '__all__')
            assert len(exports) > 0, f"{schema_name} should export at least one class"
            
            # Verify exported classes exist
            for export in exports:
                assert hasattr(schema_module, export), f"{schema_name} should have {export}"
                
        except ImportError as e:
            pytest.fail(f"Failed to import {schema_name}: {e}")
    
    def test_property_2_backward_compatibility_imports(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any tool in the reorganized structure, shared components should maintain backward compatibility
        with existing import patterns while providing new import paths.
        """
        # Test that shared components can be imported through the new paths
        try:
            # New import paths should work
            from shared.database.schemas import InventorySchema
            from shared.utils import validate_artifact_name
            from shared.config import BaseConfig
            
            # Verify classes are accessible
            assert InventorySchema is not None, "InventorySchema should be importable from shared path"
            assert validate_artifact_name is not None, "validate_artifact_name should be importable from shared path"
            assert BaseConfig is not None, "BaseConfig should be importable from shared path"
            
        except ImportError as e:
            pytest.fail(f"Failed to import shared components through new paths: {e}")
    
    def test_property_2_shared_infrastructure_isolation(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any shared infrastructure component, it should be properly isolated and not contain
        tool-specific code that would create unwanted dependencies.
        """
        # Verify shared directory structure is clean
        shared_path = Path('shared')
        assert shared_path.exists(), "Shared directory should exist"
        
        # Check that shared components don't contain tool-specific imports
        tool_specific_patterns = [
            'from tools.smf_analyzer',
            'from tools.legacy_analyzer', 
            'from tools.migration_planner',
            'import tools.smf_analyzer',
            'import tools.legacy_analyzer',
            'import tools.migration_planner'
        ]
        
        # Check all Python files in shared directory
        for py_file in shared_path.rglob('*.py'):
            if py_file.name == '__pycache__':
                continue
                
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                for pattern in tool_specific_patterns:
                    assert pattern not in content, f"Shared file {py_file} should not contain tool-specific import: {pattern}"
                    
            except (UnicodeDecodeError, IOError):
                # Skip files that can't be read as text
                continue
    
    def test_property_2_shared_components_no_circular_dependencies(self):
        """
        **Feature: project-reorganization, Property 2: Shared infrastructure accessibility**
        **Validates: Requirements 3.4, 3.5**
        
        For any shared infrastructure component, it should not have circular dependencies
        that would prevent tools from importing them independently.
        """
        # Test that each shared module can be imported independently
        shared_modules = [
            'shared',
            'shared.database',
            'shared.database.schemas',
            'shared.database.adapters',
            'shared.utils',
            'shared.config'
        ]
        
        for module_name in shared_modules:
            try:
                # Clear module cache to ensure fresh import
                if module_name in sys.modules:
                    del sys.modules[module_name]
                
                # Import module independently
                module = importlib.import_module(module_name)
                assert module is not None, f"{module_name} should be importable independently"
                
            except ImportError as e:
                pytest.fail(f"Circular dependency or import error in {module_name}: {e}")
            except Exception as e:
                pytest.fail(f"Unexpected error importing {module_name}: {e}")