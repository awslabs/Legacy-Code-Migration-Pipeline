"""Property-based tests for database schemas.

Feature: smf-parser-expansion
Properties tested:
- Property 7: Database Table Naming Convention
- Property 8: Database Schema Standard Columns
- Property 9: Database Schema Field Coverage
- Property 10: Database Schema Indexes
"""

import pytest
from hypothesis import given, strategies as st, settings
from tools.smf_analyzer.smf_loader.schemas.smf4_schema import SMF4Schema
from tools.smf_analyzer.smf_loader.schemas.smf5_schema import SMF5Schema
from tools.smf_analyzer.smf_loader.schemas.smf6_schema import SMF6Schema
from tools.smf_analyzer.smf_loader.schemas.smf7_schema import SMF7Schema
from tools.smf_analyzer.smf_loader.schemas.smf8_schema import SMF8Schema
from tools.smf_analyzer.smf_loader.schemas.smf9_schema import SMF9Schema
from tools.smf_analyzer.smf_loader.schemas.smf10_schema import SMF10Schema
from tools.smf_analyzer.smf_loader.schemas.smf11_schema import SMF11Schema


# List of all schema classes for Types 4-11 (0 and 1 not implemented)
SCHEMA_CLASSES = [
    SMF4Schema,
    SMF5Schema,
    SMF6Schema,
    SMF7Schema,
    SMF8Schema,
    SMF9Schema,
    SMF10Schema,
    SMF11Schema,
]


@pytest.mark.parametrize("schema_class", SCHEMA_CLASSES)
def test_property_7_database_table_naming_convention(schema_class):
    """
    Feature: smf-parser-expansion, Property 7: Database Table Naming Convention
    
    For any supported record type, a database table should exist with the name
    `smf{type}_records` (e.g., `smf0_records`, `smf4_records`).
    
    Validates: Requirements 5.1
    """
    schema = schema_class()
    record_type = schema.record_type
    
    # Get table definitions
    table_defs = schema.get_table_definitions()
    
    # Expected main table name
    expected_table_name = f"smf{record_type}_records"
    
    # Verify the main table exists
    assert expected_table_name in table_defs, \
        f"Schema for Type {record_type} should have table '{expected_table_name}'"


@pytest.mark.parametrize("schema_class", SCHEMA_CLASSES)
def test_property_8_database_schema_standard_columns(schema_class):
    """
    Feature: smf-parser-expansion, Property 8: Database Schema Standard Columns
    
    For any SMF record type table, the unified smf_records table should include
    all standard columns: record_id, record_type, subtype, system_id, record_date,
    record_time, record_timestamp, record_length.
    
    Validates: Requirements 5.2
    """
    schema = schema_class()
    
    # Get table definitions
    table_defs = schema.get_table_definitions()
    
    # Check unified smf_records table
    assert 'smf_records' in table_defs, \
        f"Schema for Type {schema.record_type} should have 'smf_records' table"
    
    smf_records_table = table_defs['smf_records']
    columns = smf_records_table['columns']
    column_names = [col['name'] for col in columns]
    
    # Required standard columns
    required_columns = [
        'record_id',
        'record_type',
        'subtype',
        'system_id',
        'record_date',
        'record_time',
        'record_timestamp',
        'record_length'
    ]
    
    for col_name in required_columns:
        assert col_name in column_names, \
            f"smf_records table should have column '{col_name}'"


@pytest.mark.parametrize("schema_class", SCHEMA_CLASSES)
def test_property_9_database_schema_field_coverage(schema_class):
    """
    Feature: smf-parser-expansion, Property 9: Database Schema Field Coverage
    
    For any SMF record type table, the table schema should include columns for
    all fields that would be extracted by the corresponding parser.
    
    This test verifies that:
    1. The main type-specific table exists
    2. The table has at least one column beyond the primary key
    3. The transform_record method produces data for the table
    
    Validates: Requirements 5.3
    """
    schema = schema_class()
    record_type = schema.record_type
    
    # Get table definitions
    table_defs = schema.get_table_definitions()
    
    # Expected main table name
    main_table_name = f"smf{record_type}_records"
    
    # Verify the main table exists
    assert main_table_name in table_defs, \
        f"Schema for Type {record_type} should have table '{main_table_name}'"
    
    # Verify the table has columns
    main_table = table_defs[main_table_name]
    columns = main_table['columns']
    
    assert len(columns) > 1, \
        f"Table '{main_table_name}' should have more than just primary key"
    
    # Verify transform_record produces data for this table
    # Create a minimal test record
    test_record = {
        'record_type': record_type,
        'subtype': 0,
        'system_id': 'TEST',
        'date': '2024-01-01',
        'timestamp': '12:00:00.00',
        'record_length': 100
    }
    
    transformed = schema.transform_record(test_record)
    
    assert main_table_name in transformed, \
        f"transform_record should produce data for '{main_table_name}'"
    
    assert len(transformed[main_table_name]) > 0, \
        f"transform_record should produce at least one row for '{main_table_name}'"


@pytest.mark.parametrize("schema_class", SCHEMA_CLASSES)
def test_property_10_database_schema_indexes(schema_class):
    """
    Feature: smf-parser-expansion, Property 10: Database Schema Indexes
    
    For any SMF record type table, the smf_records table should have indexes
    on commonly queried fields: record_date, record_type, system_id.
    
    Validates: Requirements 5.4
    """
    schema = schema_class()
    
    # Get table definitions
    table_defs = schema.get_table_definitions()
    
    # Check unified smf_records table
    assert 'smf_records' in table_defs, \
        f"Schema for Type {schema.record_type} should have 'smf_records' table"
    
    smf_records_table = table_defs['smf_records']
    indexes = smf_records_table.get('indexes', [])
    
    # Extract all indexed columns
    indexed_columns = set()
    for index in indexes:
        for col in index['columns']:
            indexed_columns.add(col)
    
    # Required indexes
    required_indexes = ['record_date', 'record_type', 'system_id']
    
    for col_name in required_indexes:
        assert col_name in indexed_columns, \
            f"smf_records table should have index on '{col_name}'"


@given(
    record_type=st.sampled_from([4, 5, 6, 7, 8, 9, 10, 11]),
    system_id=st.text(min_size=1, max_size=4, alphabet=st.characters(whitelist_categories=('Lu', 'Nd'))),
    date_str=st.text(min_size=10, max_size=10, alphabet='0123456789-'),
    time_str=st.text(min_size=11, max_size=11, alphabet='0123456789:.'),
)
@settings(max_examples=100)
def test_property_transform_record_produces_valid_structure(record_type, system_id, date_str, time_str):
    """
    Property test: For any valid record type and input data, transform_record
    should produce a valid structure with smf_records table.
    
    This is a general property that ensures the transform_record method
    always produces the expected structure.
    """
    # Get the appropriate schema class
    schema_map = {
        4: SMF4Schema,
        5: SMF5Schema,
        6: SMF6Schema,
        7: SMF7Schema,
        8: SMF8Schema,
        9: SMF9Schema,
        10: SMF10Schema,
        11: SMF11Schema,
    }
    
    schema_class = schema_map[record_type]
    schema = schema_class()
    
    # Create test record
    test_record = {
        'record_type': record_type,
        'subtype': 0,
        'system_id': system_id,
        'date': date_str,
        'timestamp': time_str,
        'record_length': 100
    }
    
    # Transform the record
    transformed = schema.transform_record(test_record)
    
    # Verify structure
    assert isinstance(transformed, dict), "transform_record should return a dict"
    assert 'smf_records' in transformed, "Transformed data should include 'smf_records'"
    assert isinstance(transformed['smf_records'], list), "'smf_records' should be a list"
    assert len(transformed['smf_records']) > 0, "'smf_records' should have at least one row"
    
    # Verify the row has required fields
    row = transformed['smf_records'][0]
    assert 'record_type' in row
    assert 'system_id' in row
    assert 'record_date' in row
    assert 'record_time' in row
