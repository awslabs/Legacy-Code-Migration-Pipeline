"""
Property-based tests for SMF Loader.

Tests the following properties:
- Property 11: Loader Table Routing
- Property 12: Loader Field Validation
- Property 13: Loader NULL Handling
"""

import pytest
import tempfile
import os
import json
from hypothesis import given, strategies as st, settings, HealthCheck

from tools.smf_analyzer.smf_loader.core.loader import SMFLoader
from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas.smf4_schema import SMF4Schema
from tools.smf_analyzer.smf_loader.schemas.smf5_schema import SMF5Schema
from tools.smf_analyzer.smf_loader.schemas.smf6_schema import SMF6Schema
from tools.smf_analyzer.smf_loader.schemas.smf7_schema import SMF7Schema
from tools.smf_analyzer.smf_loader.schemas.smf8_schema import SMF8Schema
from tools.smf_analyzer.smf_loader.schemas.smf9_schema import SMF9Schema
from tools.smf_analyzer.smf_loader.schemas.smf10_schema import SMF10Schema
from tools.smf_analyzer.smf_loader.schemas.smf11_schema import SMF11Schema


# Strategy for generating valid SMF record types (only those with existing schemas)
smf_record_type_strategy = st.sampled_from([4, 5, 6, 7, 8, 9, 10, 11])

# Strategy for generating valid system IDs
system_id_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
    min_size=1,
    max_size=8
)

# Strategy for generating valid dates (YYYY-MM-DD)
from datetime import date as dt_date
date_strategy = st.dates(
    min_value=dt_date(1970, 1, 1),
    max_value=dt_date(2099, 12, 31)
).map(lambda d: d.strftime('%Y-%m-%d'))

# Strategy for generating valid timestamps (HH:MM:SS)
timestamp_strategy = st.times().map(lambda t: t.strftime('%H:%M:%S'))

# Strategy for generating valid record lengths
record_length_strategy = st.integers(min_value=18, max_value=32760)

# Strategy for generating subtype
subtype_strategy = st.integers(min_value=0, max_value=255)


def generate_minimal_record(record_type: int, system_id: str, date: str, timestamp: str, 
                           record_length: int, subtype: int) -> dict:
    """Generate a minimal valid SMF record."""
    return {
        'record_type': record_type,
        'subtype': subtype,
        'system_id': system_id,
        'date': date,
        'timestamp': timestamp,
        'record_length': record_length,
        'header': {},
        'identification': {},
        'performance': {},
        'io_activity': {},
        'subsystem': {}
    }


def get_schema_for_type(record_type: int):
    """Get schema instance for a record type."""
    schema_map = {
        4: SMF4Schema,
        5: SMF5Schema,
        6: SMF6Schema,
        7: SMF7Schema,
        8: SMF8Schema,
        9: SMF9Schema,
        10: SMF10Schema,
        11: SMF11Schema,
    }
    return schema_map[record_type]()


@settings(max_examples=100, suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    record_type=smf_record_type_strategy,
    system_id=system_id_strategy,
    date=date_strategy,
    timestamp=timestamp_strategy,
    record_length=record_length_strategy,
    subtype=subtype_strategy
)
def test_property_11_loader_table_routing(record_type, system_id, date, timestamp, record_length, subtype):
    """
    **Feature: smf-parser-expansion, Property 11: Loader Table Routing**
    
    Property: For any parsed SMF record, the loader should insert the record 
    into the table corresponding to its record type.
    
    **Validates: Requirements 6.1**
    """
    # Create temporary database
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        # Get schema for this record type
        schema = get_schema_for_type(record_type)
        
        # Create loader
        loader = SMFLoader(
            database=SQLiteAdapter(db_path),
            schema=schema
        )
        
        # Create schema
        loader.create_schema()
        
        # Generate minimal record
        record = generate_minimal_record(record_type, system_id, date, timestamp, record_length, subtype)
        
        # Load record
        loader.load_record(record, strict=False)
        loader.database.commit()
        
        # Verify record was inserted into correct table
        # Check smf_records table exists and has data
        assert loader.database.table_exists('smf_records'), "smf_records table should exist"
        
        # Check type-specific table exists and has data
        type_table = f'smf{record_type}_records'
        assert loader.database.table_exists(type_table), f"{type_table} table should exist"
        
        # Verify at least one record was inserted
        stats = loader.get_stats()
        assert stats.get('smf_records', 0) > 0, "Should have inserted into smf_records"
        assert stats.get(type_table, 0) > 0, f"Should have inserted into {type_table}"
        
        loader.close()
        
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


@settings(max_examples=100, suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    record_type=smf_record_type_strategy,
    system_id=system_id_strategy,
    date=date_strategy,
    timestamp=timestamp_strategy,
    record_length=record_length_strategy,
    subtype=subtype_strategy
)
def test_property_12_loader_field_validation(record_type, system_id, date, timestamp, record_length, subtype):
    """
    **Feature: smf-parser-expansion, Property 12: Loader Field Validation**
    
    Property: For any SMF record being loaded, the loader should validate that 
    all required fields are present before insertion.
    
    **Validates: Requirements 6.3**
    """
    # Create temporary database
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        # Get schema for this record type
        schema = get_schema_for_type(record_type)
        
        # Create loader
        loader = SMFLoader(
            database=SQLiteAdapter(db_path),
            schema=schema
        )
        
        # Create schema
        loader.create_schema()
        
        # Test 1: Valid record with all required fields should succeed
        valid_record = generate_minimal_record(record_type, system_id, date, timestamp, record_length, subtype)
        loader.load_record(valid_record, strict=False)
        loader.database.commit()
        
        stats = loader.get_stats()
        assert stats.get('smf_records', 0) > 0, "Valid record should be inserted"
        
        # Test 2: Record missing required field should fail in strict mode
        invalid_record = generate_minimal_record(record_type, system_id, date, timestamp, record_length, subtype)
        del invalid_record['system_id']  # Remove required field
        
        with pytest.raises(ValueError, match="Missing required fields"):
            loader.load_record(invalid_record, strict=True)
        
        # Test 3: Record missing required field should use default in lenient mode
        loader.load_record(invalid_record, strict=False)
        loader.database.commit()
        
        # Should still have records (with defaults)
        stats = loader.get_stats()
        assert stats.get('smf_records', 0) > 0, "Lenient mode should insert with defaults"
        
        loader.close()
        
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


@settings(max_examples=100, suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(
    record_type=smf_record_type_strategy,
    system_id=system_id_strategy,
    date=date_strategy,
    timestamp=timestamp_strategy,
    record_length=record_length_strategy,
    subtype=subtype_strategy
)
def test_property_13_loader_null_handling(record_type, system_id, date, timestamp, record_length, subtype):
    """
    **Feature: smf-parser-expansion, Property 13: Loader NULL Handling**
    
    Property: For any SMF record with missing optional fields, the loader should 
    insert NULL values for those fields without failing.
    
    **Validates: Requirements 6.4**
    """
    # Create temporary database
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        # Get schema for this record type
        schema = get_schema_for_type(record_type)
        
        # Create loader
        loader = SMFLoader(
            database=SQLiteAdapter(db_path),
            schema=schema
        )
        
        # Create schema
        loader.create_schema()
        
        # Generate minimal record (only required fields, optional fields will be None/missing)
        record = generate_minimal_record(record_type, system_id, date, timestamp, record_length, subtype)
        
        # Load record - should succeed even with missing optional fields
        loader.load_record(record, strict=False)
        loader.database.commit()
        
        # Verify record was inserted
        stats = loader.get_stats()
        assert stats.get('smf_records', 0) > 0, "Record with missing optional fields should be inserted"
        
        type_table = f'smf{record_type}_records'
        assert stats.get(type_table, 0) > 0, f"Record should be inserted into {type_table}"
        
        # Verify we can query the data (NULL values should be handled correctly)
        # Just verify the stats show the record was inserted
        # The fact that we got here without errors means NULL handling worked
        
        loader.close()
        
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
