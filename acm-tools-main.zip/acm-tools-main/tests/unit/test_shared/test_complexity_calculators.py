"""Tests for complexity calculators."""

import pytest
from tools.legacy_analyzer.parsers import (
    REXXComplexityCalculator,
    RPGComplexityCalculator,
    NATURALComplexityCalculator
)


class TestREXXComplexityCalculator:
    """Test REXX complexity calculator."""
    
    def test_loc_metrics_basic(self):
        """Test basic LOC metrics calculation."""
        calculator = REXXComplexityCalculator()
        
        source = """/* Comment line */
SAY 'Hello World'

/* Multi-line
   comment */
X = 1
"""
        
        metrics = calculator.calculate_loc_metrics(source)
        assert metrics['total_lines'] >= 7
        assert metrics['blank_lines'] >= 1
        assert metrics['comment_lines'] >= 2
        assert metrics['loc'] >= 2
    
    def test_cyclomatic_complexity_basic(self):
        """Test basic cyclomatic complexity."""
        calculator = REXXComplexityCalculator()
        
        source = """
IF X > 0 THEN
    SAY 'Positive'
ELSE
    SAY 'Not positive'
"""
        
        complexity = calculator.calculate_cyclomatic_complexity(source)
        assert complexity >= 2  # Base 1 + IF statement


class TestRPGComplexityCalculator:
    """Test RPG complexity calculator."""
    
    def test_loc_metrics_basic(self):
        """Test basic LOC metrics calculation."""
        calculator = RPGComplexityCalculator()
        
        source = """      * Comment line
     D MyVar           S             10A
     C                   EVAL      MyVar = 'Test'
"""
        
        metrics = calculator.calculate_loc_metrics(source)
        assert metrics['total_lines'] >= 3
        assert metrics['comment_lines'] >= 1
        assert metrics['loc'] >= 2
    
    def test_cyclomatic_complexity_basic(self):
        """Test basic cyclomatic complexity."""
        calculator = RPGComplexityCalculator()
        
        source = """
     C                   IF        X > 0
     C                   EVAL      Y = 1
     C                   ENDIF
"""
        
        complexity = calculator.calculate_cyclomatic_complexity(source)
        assert complexity >= 2  # Base 1 + IF statement


class TestNATURALComplexityCalculator:
    """Test NATURAL complexity calculator."""
    
    def test_loc_metrics_basic(self):
        """Test basic LOC metrics calculation."""
        calculator = NATURALComplexityCalculator()
        
        source = """* Comment line
DEFINE DATA LOCAL
1 #VAR (A10)
END-DEFINE

WRITE 'Hello'
END
"""
        
        metrics = calculator.calculate_loc_metrics(source)
        assert metrics['total_lines'] >= 7
        assert metrics['comment_lines'] >= 1
        assert metrics['loc'] >= 5
    
    def test_cyclomatic_complexity_basic(self):
        """Test basic cyclomatic complexity."""
        calculator = NATURALComplexityCalculator()
        
        source = """
IF #VAR > 0
  WRITE 'Positive'
ELSE
  WRITE 'Not positive'
END-IF
"""
        
        complexity = calculator.calculate_cyclomatic_complexity(source)
        assert complexity >= 2  # Base 1 + IF statement
    
    def test_cyclomatic_complexity_decide(self):
        """Test complexity with DECIDE statement."""
        calculator = NATURALComplexityCalculator()
        
        source = """
DECIDE ON FIRST #VAR
  VALUE 1
    WRITE 'One'
  VALUE 2
    WRITE 'Two'
  NONE
    WRITE 'Other'
END-DECIDE
"""
        
        complexity = calculator.calculate_cyclomatic_complexity(source)
        assert complexity >= 3  # Base 1 + 2 VALUE clauses
