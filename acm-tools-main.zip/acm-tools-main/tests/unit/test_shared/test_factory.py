"""Unit tests for SMFParserFactory."""

import pytest
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
from tools.smf_analyzer.smf_record_parser.parsers.smf_record_parser import SMFRecordParser
from tools.smf_analyzer.smf_record_parser.parsers.smf30_parser_v3r2 import SMF30ParserV3R2
from tools.smf_analyzer.smf_record_parser.exceptions import (
    UnsupportedRecordTypeError,
    UnsupportedVersionError
)


class TestSMFParserFactory:
    """Test suite for SMFParserFactory class."""
    
    def test_create_parser_valid_type_and_version(self):
        """Test creating parser with valid record type and version."""
        parser = SMFParserFactory.create_parser(30, "V3R2")
        
        assert parser is not None
        assert isinstance(parser, SMFRecordParser)
        assert parser.record_type == 30
    
    def test_create_parser_registers_strategy(self):
        """Test that create_parser registers the version strategy."""
        parser = SMFParserFactory.create_parser(30, "V3R2")
        
        assert "V3R2" in parser.version_strategies
        assert isinstance(parser.version_strategies["V3R2"], SMF30ParserV3R2)
    
    def test_create_parser_with_ebcdic_encoding(self):
        """Test creating parser with EBCDIC encoding (default)."""
        parser = SMFParserFactory.create_parser(30, "V3R2")
        
        strategy = parser.version_strategies["V3R2"]
        assert strategy.parser.encoding == "EBCDIC"
        assert strategy.parser.codepage == "cp037"
    
    def test_create_parser_with_utf8_encoding(self):
        """Test creating parser with UTF-8 encoding."""
        parser = SMFParserFactory.create_parser(30, "V3R2", encoding="UTF-8")
        
        strategy = parser.version_strategies["V3R2"]
        assert strategy.parser.encoding == "UTF-8"
        assert strategy.parser.codepage == "utf-8"
    
    def test_create_parser_invalid_record_type(self):
        """Test that invalid record type raises UnsupportedRecordTypeError."""
        with pytest.raises(UnsupportedRecordTypeError) as exc_info:
            SMFParserFactory.create_parser(99, "V3R2")
        
        assert exc_info.value.record_type == 99
        assert "99" in str(exc_info.value)
        assert "not supported" in str(exc_info.value)
    
    def test_create_parser_invalid_record_type_zero(self):
        """Test that an unsupported record type raises UnsupportedRecordTypeError."""
        # Type 12 is not yet implemented, so it should raise an error
        with pytest.raises(UnsupportedRecordTypeError) as exc_info:
            SMFParserFactory.create_parser(12, "V3R2")
        
        assert exc_info.value.record_type == 12
    
    def test_create_parser_unsupported_version(self):
        """Test that unsupported version raises UnsupportedVersionError."""
        with pytest.raises(UnsupportedVersionError) as exc_info:
            SMFParserFactory.create_parser(30, "V3R3")
        
        assert exc_info.value.version == "V3R3"
        assert exc_info.value.record_type == 30
        assert "V3R3" in str(exc_info.value)
        assert "30" in str(exc_info.value)
    
    def test_create_parser_unsupported_version_for_valid_type(self):
        """Test error when version is unsupported for valid record type."""
        # Record type 30 exists, but V3R1 is not supported
        with pytest.raises(UnsupportedVersionError) as exc_info:
            SMFParserFactory.create_parser(30, "V3R1")
        
        assert exc_info.value.version == "V3R1"
        assert exc_info.value.record_type == 30
    
    def test_list_available_parsers_returns_dict(self):
        """Test that list_available_parsers returns a dictionary."""
        result = SMFParserFactory.list_available_parsers()
        
        assert isinstance(result, dict)
    
    def test_list_available_parsers_includes_type_30(self):
        """Test that list_available_parsers includes record type 30."""
        result = SMFParserFactory.list_available_parsers()
        
        assert 30 in result
        assert isinstance(result[30], list)
    
    def test_list_available_parsers_includes_v3r2(self):
        """Test that list_available_parsers includes V3R2 for type 30."""
        result = SMFParserFactory.list_available_parsers()
        
        assert "V3R2" in result[30]
    
    def test_list_available_parsers_versions_sorted(self):
        """Test that versions are sorted in the result."""
        result = SMFParserFactory.list_available_parsers()
        
        for record_type, versions in result.items():
            # Check that versions are sorted
            assert versions == sorted(versions)
    
    def test_list_available_parsers_correct_registry(self):
        """Test that list_available_parsers returns correct registry."""
        result = SMFParserFactory.list_available_parsers()
        
        # Based on current implementation, should have type 30 with V3R2
        assert len(result) >= 1
        assert 30 in result
        assert len(result[30]) >= 1
        assert "V3R2" in result[30]
    
    def test_create_parser_multiple_times(self):
        """Test creating multiple parser instances."""
        parser1 = SMFParserFactory.create_parser(30, "V3R2")
        parser2 = SMFParserFactory.create_parser(30, "V3R2")
        
        # Should create separate instances
        assert parser1 is not parser2
        assert parser1.record_type == parser2.record_type
    
    def test_create_parser_different_encodings(self):
        """Test creating parsers with different encodings."""
        parser_ebcdic = SMFParserFactory.create_parser(30, "V3R2", encoding="EBCDIC")
        parser_utf8 = SMFParserFactory.create_parser(30, "V3R2", encoding="UTF-8")
        
        strategy_ebcdic = parser_ebcdic.version_strategies["V3R2"]
        strategy_utf8 = parser_utf8.version_strategies["V3R2"]
        
        assert strategy_ebcdic.parser.encoding == "EBCDIC"
        assert strategy_utf8.parser.encoding == "UTF-8"


class TestFactoryRegistry:
    """Test the factory registry mechanism."""
    
    def test_registry_structure(self):
        """Test that registry has correct structure."""
        # Access the private registry for testing
        registry = SMFParserFactory._registry
        
        assert isinstance(registry, dict)
        assert len(registry) > 0
    
    def test_registry_contains_type_30_v3r2(self):
        """Test that registry contains type 30 V3R2."""
        registry = SMFParserFactory._registry
        
        assert (30, "V3R2") in registry
        assert registry[(30, "V3R2")] == SMF30ParserV3R2
    
    def test_registry_keys_are_tuples(self):
        """Test that registry keys are (record_type, version) tuples."""
        registry = SMFParserFactory._registry
        
        for key in registry.keys():
            assert isinstance(key, tuple)
            assert len(key) == 2
            assert isinstance(key[0], int)  # record_type
            assert isinstance(key[1], str)  # version
    
    def test_registry_values_are_classes(self):
        """Test that registry values are strategy classes."""
        registry = SMFParserFactory._registry
        
        for strategy_class in registry.values():
            # Should be a class, not an instance
            assert isinstance(strategy_class, type)


class TestFactoryErrorMessages:
    """Test error message formatting from factory."""
    
    def test_unsupported_record_type_error_message(self):
        """Test error message for unsupported record type."""
        try:
            SMFParserFactory.create_parser(999, "V3R2")
            assert False, "Should have raised UnsupportedRecordTypeError"
        except UnsupportedRecordTypeError as e:
            error_msg = str(e)
            assert "999" in error_msg
            assert "not supported" in error_msg.lower()
    
    def test_unsupported_version_error_message(self):
        """Test error message for unsupported version."""
        try:
            SMFParserFactory.create_parser(30, "V9R9")
            assert False, "Should have raised UnsupportedVersionError"
        except UnsupportedVersionError as e:
            error_msg = str(e)
            assert "V9R9" in error_msg
            assert "30" in error_msg
            assert "not supported" in error_msg.lower()


class TestFactoryParserAvailability:
    """Test parser availability checking functionality."""
    
    def test_is_parser_available_for_existing_type(self):
        """Test that is_parser_available returns True for existing parsers."""
        # Type 30 V3R2 should be available
        assert SMFParserFactory.is_parser_available(30, "V3R2") is True
    
    def test_is_parser_available_for_nonexistent_type(self):
        """Test that is_parser_available returns False for non-existent parsers."""
        # Type 200 is not yet implemented (using a high number that's unlikely to be implemented soon)
        assert SMFParserFactory.is_parser_available(200, "V3R2") is False
    
    def test_is_parser_available_for_unsupported_version(self):
        """Test that is_parser_available returns False for unsupported versions."""
        # Type 30 V3R3 is not supported
        assert SMFParserFactory.is_parser_available(30, "V3R3") is False
    
    def test_is_parser_available_default_version(self):
        """Test that is_parser_available uses V3R2 as default version."""
        # Should use V3R2 by default
        assert SMFParserFactory.is_parser_available(30) is True
    
    def test_is_parser_available_all_existing_types(self):
        """Test that is_parser_available works for all registered types."""
        available = SMFParserFactory.list_available_parsers()
        
        for record_type, versions in available.items():
            for version in versions:
                assert SMFParserFactory.is_parser_available(record_type, version) is True


class TestFactoryRegistration:
    """Test factory registration for new parser types."""
    
    def test_factory_returns_correct_parser_for_each_type(self):
        """Test that factory returns correct parser for each registered type.
        
        Validates: Requirements 4.2
        """
        # Get all available parsers
        available = SMFParserFactory.list_available_parsers()
        
        # Test each registered type
        for record_type in available.keys():
            parser = SMFParserFactory.create_parser(record_type, "V3R2")
            assert parser is not None
            assert isinstance(parser, SMFRecordParser)
            assert parser.record_type == record_type
    
    def test_factory_version_selection_logic(self):
        """Test that factory correctly selects parser based on version.
        
        Validates: Requirements 4.4
        """
        # Create parser for Type 30 V3R2
        parser = SMFParserFactory.create_parser(30, "V3R2")
        
        # Verify correct version strategy is registered
        assert "V3R2" in parser.version_strategies
        assert isinstance(parser.version_strategies["V3R2"], SMF30ParserV3R2)
    
    def test_factory_handles_multiple_versions_per_type(self):
        """Test that factory can handle multiple versions for same type.
        
        Validates: Requirements 4.4
        """
        # Currently all types only have V3R2, but test the mechanism
        available = SMFParserFactory.list_available_parsers()
        
        for record_type, versions in available.items():
            # Each type should have at least one version
            assert len(versions) >= 1
            
            # All versions should be strings
            for version in versions:
                assert isinstance(version, str)
    
    def test_factory_registry_contains_all_documented_types(self):
        """Test that factory registry includes all currently implemented types."""
        available = SMFParserFactory.list_available_parsers()
        
        # These types should be available (currently implemented)
        expected_types = [2, 3, 14, 15, 17, 30, 62, 64, 110]
        
        for record_type in expected_types:
            assert record_type in available, f"Type {record_type} should be in registry"
            assert "V3R2" in available[record_type]
    
    def test_factory_does_not_include_unimplemented_types(self):
        """Test that factory does not include types that are not yet implemented."""
        available = SMFParserFactory.list_available_parsers()
        
        # These types are planned but not yet implemented (Phase 3 and beyond)
        # Types 52, 53, 54 are now implemented, so exclude them from unimplemented list
        unimplemented_types = [51, 55, 56, 57, 58, 59, 60, 61, 63, 65, 66, 67, 68, 69, 70]
        
        for record_type in unimplemented_types:
            assert record_type not in available, f"Type {record_type} should not be in registry yet"
