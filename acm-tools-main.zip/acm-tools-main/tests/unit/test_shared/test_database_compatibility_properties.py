"""
Property-based tests for database compatibility after reorganization.

**Feature: project-reorganization, Property 9: Database schema compatibility**
**Validates: Requirements 8.5**
"""

import pytest
import tempfile
import os
import json
from hypothesis import given, strategies as st, settings


class TestDatabaseCompatibilityProperties:
    """Property-based tests for database compatibility preservation."""

    def test_unified_schema_compatibility(self):
        """
        **Feature: project-reorganization, Property 9: Database schema compatibility**
        
        Property: Unified schema maintains compatibility
        *For any* schema instance, the table definitions and structure should
        remain identical after reorganization.
        **Validates: Requirements 8.5**
        """
        try:
            # Test import path
            from shared.database.schemas import UnifiedSMFSchema
            
            # Create schema instance
            schema = UnifiedSMFSchema()
            
            # Verify expected interface exists
            assert hasattr(schema, 'get_table_definitions'), "get_table_definitions method should exist"
            assert hasattr(schema, 'record_type'), "record_type property should exist"
            assert hasattr(schema, 'record_name'), "record_name property should exist"
            
            # Verify table definitions structure
            table_defs = schema.get_table_definitions()
            assert isinstance(table_defs, dict), "Table definitions should be a dictionary"
            assert 'smf_records' in table_defs, "smf_records table should exist"
            
        except Exception as e:
            pytest.fail(f"Unified schema compatibility broken: {e}")

    def test_smf30_schema_compatibility(self):
        """
        **Feature: project-reorganization, Property 9: Database schema compatibility**
        
        Property: SMF30 schema maintains compatibility
        *For any* SMF30 schema instance, the table definitions should remain
        identical after reorganization.
        **Validates: Requirements 8.5**
        """
        try:
            # Test import path
            from tools.smf_analyzer.smf_loader.schemas import SMF30Schema
            
            # Create schema instance
            schema = SMF30Schema()
            
            # Verify expected interface exists
            assert hasattr(schema, 'get_table_definitions'), "get_table_definitions method should exist"
            assert schema.record_type == 30, "Record type should be 30"
            
            # Verify table definitions structure
            table_defs = schema.get_table_definitions()
            assert isinstance(table_defs, dict), "Table definitions should be a dictionary"
            
        except Exception as e:
            pytest.fail(f"SMF30 schema compatibility broken: {e}")

    def test_smf110_schema_compatibility(self):
        """
        **Feature: project-reorganization, Property 9: Database schema compatibility**
        
        Property: SMF110 schema maintains compatibility
        *For any* SMF110 schema instance, the table definitions should remain
        identical after reorganization.
        **Validates: Requirements 8.5**
        """
        try:
            # Test import path
            from tools.smf_analyzer.smf_loader.schemas import SMF110Schema
            
            # Create schema instance
            schema = SMF110Schema()
            
            # Verify expected interface exists
            assert hasattr(schema, 'get_table_definitions'), "get_table_definitions method should exist"
            assert schema.record_type == 110, "Record type should be 110"
            
            # Verify table definitions structure
            table_defs = schema.get_table_definitions()
            assert isinstance(table_defs, dict), "Table definitions should be a dictionary"
            
        except Exception as e:
            pytest.fail(f"SMF110 schema compatibility broken: {e}")

    def test_database_adapter_compatibility(self):
        """
        **Feature: project-reorganization, Property 9: Database schema compatibility**
        
        Property: Database adapters maintain compatibility
        *For any* database adapter, the interface should remain identical
        after reorganization.
        **Validates: Requirements 8.5**
        """
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        try:
            # Test import path
            from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
            
            # Create adapter instance
            adapter = SQLiteAdapter(db_path)
            
            # Verify expected interface exists
            assert hasattr(adapter, 'connect'), "connect method should exist"
            assert hasattr(adapter, 'close'), "close method should exist"
            assert hasattr(adapter, 'create_table'), "create_table method should exist"
            
        except Exception as e:
            pytest.fail(f"Database adapter compatibility broken: {e}")
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_database_loading_compatibility(self):
        """
        **Feature: project-reorganization, Property 9: Database schema compatibility**
        
        Property: Database loading operations maintain compatibility
        *For any* valid record data, the loading process should work identically
        after reorganization.
        **Validates: Requirements 8.5**
        """
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as tmp_json:
            json_path = tmp_json.name
            
            # Create test data
            test_records = [
                {
                    'record_type': 30,
                    'system_id': 'SYS1',
                    'timestamp': '2024-01-01T12:00:00',
                    'job_name': 'TESTJOB1'
                }
            ]
            json.dump(test_records, tmp_json)
        
        try:
            # Test import path
            from tools.smf_analyzer.smf_loader import SMFLoader
            from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
            from shared.database.schemas import UnifiedSMFSchema
            
            # Create loader
            database = SQLiteAdapter(db_path)
            schema = UnifiedSMFSchema()
            loader = SMFLoader(database=database, schema=schema)
            
            # Test loading operations
            loader.create_schema()
            loader.load_json_file(json_path, batch_size=10, strict=False)
            
            # Verify stats
            stats = loader.get_stats()
            assert isinstance(stats, dict), "Stats should be a dictionary"
            
            loader.close()
            
        except Exception as e:
            pytest.fail(f"Database loading compatibility broken: {e}")
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
            if os.path.exists(json_path):
                os.unlink(json_path)