"""Unit tests for exception classes."""

import pytest
from tools.smf_analyzer.smf_record_parser.exceptions import (
    SMFParserError,
    UnsupportedVersionError,
    UnsupportedRecordTypeError,
    ValidationError,
    EncodingError
)


class TestExceptions:
    """Test suite for exception classes."""
    
    def test_smf_parser_error_base(self):
        """Test base SMFParserError exception."""
        error = SMFParserError("Test error message")
        assert str(error) == "Test error message"
        assert isinstance(error, Exception)
    
    def test_unsupported_version_error_message(self):
        """Test UnsupportedVersionError message formatting."""
        error = UnsupportedVersionError("V3R3", 30)
        
        assert "V3R3" in str(error)
        assert "30" in str(error)
        assert "not supported" in str(error)
        assert error.version == "V3R3"
        assert error.record_type == 30
    
    def test_unsupported_version_error_inheritance(self):
        """Test that UnsupportedVersionError inherits from SMFParserError."""
        error = UnsupportedVersionError("V3R1", 42)
        assert isinstance(error, SMFParserError)
        assert isinstance(error, Exception)
    
    def test_unsupported_record_type_error_message(self):
        """Test UnsupportedRecordTypeError message formatting."""
        error = UnsupportedRecordTypeError(99)
        
        assert "99" in str(error)
        assert "not supported" in str(error)
        assert error.record_type == 99
    
    def test_unsupported_record_type_error_inheritance(self):
        """Test that UnsupportedRecordTypeError inherits from SMFParserError."""
        error = UnsupportedRecordTypeError(50)
        assert isinstance(error, SMFParserError)
        assert isinstance(error, Exception)
    
    def test_validation_error_without_offset(self):
        """Test ValidationError without offset information."""
        error = ValidationError("Invalid field value")
        
        assert str(error) == "Invalid field value"
        assert error.offset is None
    
    def test_validation_error_with_offset(self):
        """Test ValidationError with offset information."""
        error = ValidationError("Invalid field value", offset=100)
        
        error_msg = str(error)
        assert "Invalid field value" in error_msg
        assert "100" in error_msg
        assert "0X64" in error_msg.upper()  # Hex representation (uppercase X)
        assert error.offset == 100
    
    def test_validation_error_with_zero_offset(self):
        """Test ValidationError with offset 0."""
        error = ValidationError("Invalid header", offset=0)
        
        error_msg = str(error)
        assert "Invalid header" in error_msg
        assert "0" in error_msg
        assert "0X0" in error_msg.upper()  # Hex representation (uppercase X)
        assert error.offset == 0
    
    def test_validation_error_inheritance(self):
        """Test that ValidationError inherits from SMFParserError."""
        error = ValidationError("Test validation error")
        assert isinstance(error, SMFParserError)
        assert isinstance(error, Exception)
    
    def test_encoding_error_message(self):
        """Test EncodingError message formatting with field information."""
        error = EncodingError("job_name", 50, "EBCDIC")
        
        error_msg = str(error)
        assert "job_name" in error_msg
        assert "50" in error_msg
        assert "EBCDIC" in error_msg
        assert "Failed to decode" in error_msg
    
    def test_encoding_error_attributes(self):
        """Test EncodingError stores field name, offset, and encoding."""
        error = EncodingError("system_id", 25, "UTF-8")
        
        assert error.field_name == "system_id"
        assert error.offset == 25
        assert error.encoding == "UTF-8"
    
    def test_encoding_error_inheritance(self):
        """Test that EncodingError inherits from SMFParserError."""
        error = EncodingError("test_field", 0, "EBCDIC")
        assert isinstance(error, SMFParserError)
        assert isinstance(error, Exception)
