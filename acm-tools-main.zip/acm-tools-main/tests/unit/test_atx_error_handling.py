"""
Unit tests for error handling in ATX Dependency Transformer.

Tests error conditions for:
- Missing files
- Invalid JSON/CSV
- Schema validation errors
- Configuration errors
- Write permission errors
"""

import pytest
import tempfile
import json
import csv
import os
from pathlib import Path

from tools.atx.dependency_transformer.loaders.atx_dependency_loader import ATXDependencyLoader
from tools.atx.dependency_transformer.loaders.atx_assets_loader import ATXAssetsLoader
from tools.atx.dependency_transformer.loaders.atx_data_operations_loader import ATXDataOperationsLoader
from tools.atx.dependency_transformer.orchestration.configuration_manager import ConfigurationManager
from tools.atx.dependency_transformer.writers.flow_writer import FlowWriter
from tools.atx.dependency_transformer.writers.job_writer import JobWriter
from tools.atx.dependency_transformer.writers.entry_point_writer import EntryPointWriter
from tools.atx.dependency_transformer.models.legacy_models import (
    Flow, Job, EntryPointRecord, EntryPoint, Scope, Complexity,
    FlowDependencies, DataOperations, JobStep, JobDependencies
)


class TestDependencyLoaderErrors:
    """Test error handling in ATXDependencyLoader."""
    
    def test_missing_file(self):
        """Test handling of missing dependencies.json file."""
        loader = ATXDependencyLoader()
        
        with pytest.raises(FileNotFoundError) as exc_info:
            loader.load('nonexistent_dependencies.json')
        
        assert "Dependencies file not found" in str(exc_info.value)
        assert "nonexistent_dependencies.json" in str(exc_info.value)
    
    def test_invalid_json_syntax(self):
        """Test handling of malformed JSON."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('{"invalid": json syntax}')
            temp_file = f.name
        
        try:
            loader = ATXDependencyLoader()
            
            with pytest.raises(ValueError) as exc_info:
                loader.load(temp_file)
            
            assert "Invalid JSON" in str(exc_info.value)
            assert "line" in str(exc_info.value).lower()
        finally:
            os.unlink(temp_file)
    
    def test_schema_mismatch_not_list(self):
        """Test handling of schema mismatch (not a list)."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump({"not": "a list"}, f)
            temp_file = f.name
        
        try:
            loader = ATXDependencyLoader()
            
            with pytest.raises(ValueError) as exc_info:
                loader.load(temp_file)
            
            assert "Schema mismatch" in str(exc_info.value)
            assert "Expected a JSON array" in str(exc_info.value)
        finally:
            os.unlink(temp_file)
    
    def test_permission_denied(self):
        """Test handling of permission denied error."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump([], f)
            temp_file = f.name
        
        try:
            # Make file unreadable
            os.chmod(temp_file, 0o000)
            
            loader = ATXDependencyLoader()
            
            with pytest.raises(PermissionError) as exc_info:
                loader.load(temp_file)
            
            assert "Permission denied" in str(exc_info.value)
        finally:
            # Restore permissions and delete
            os.chmod(temp_file, 0o644)
            os.unlink(temp_file)
    
    def test_invalid_entry_skipped(self, capsys):
        """Test that invalid entries are skipped with warnings."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump([
                {"name": "VALID", "path": "/path", "type": "COB", "dependencies": []},
                {"invalid": "entry"},  # Missing required fields
                {"name": "VALID2", "path": "/path2", "type": "COB", "dependencies": []}
            ], f)
            temp_file = f.name
        
        try:
            loader = ATXDependencyLoader()
            deps = loader.load(temp_file)
            
            # Should load 2 valid entries
            assert len(deps) == 2
            
            # Check warning was printed
            captured = capsys.readouterr()
            assert "Warning" in captured.out
            assert "Skipped" in captured.out
        finally:
            os.unlink(temp_file)


class TestAssetsLoaderErrors:
    """Test error handling in ATXAssetsLoader."""
    
    def test_missing_file(self):
        """Test handling of missing assets.csv file."""
        loader = ATXAssetsLoader()
        
        with pytest.raises(FileNotFoundError) as exc_info:
            loader.load('nonexistent_assets.csv')
        
        assert "Assets file not found" in str(exc_info.value)
    
    def test_invalid_csv_format(self):
        """Test handling of malformed CSV."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            # Write CSV with missing required column
            writer = csv.DictWriter(f, fieldnames=['Name', 'Path'])
            writer.writeheader()
            temp_file = f.name
        
        try:
            loader = ATXAssetsLoader()
            
            with pytest.raises(ValueError) as exc_info:
                loader.load(temp_file)
            
            # Should fail due to missing required column
            assert "Schema mismatch" in str(exc_info.value) or "Missing required" in str(exc_info.value)
        finally:
            os.unlink(temp_file)
    
    def test_missing_required_columns(self):
        """Test handling of missing required columns."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['WrongColumn'])
            writer.writeheader()
            temp_file = f.name
        
        try:
            loader = ATXAssetsLoader()
            
            with pytest.raises(ValueError) as exc_info:
                loader.load(temp_file)
            
            assert "Schema mismatch" in str(exc_info.value)
            assert "Missing required columns" in str(exc_info.value)
        finally:
            os.unlink(temp_file)
    
    def test_permission_denied(self):
        """Test handling of permission denied error."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['Name', 'Path', 'File type'])
            writer.writeheader()
            temp_file = f.name
        
        try:
            # Make file unreadable
            os.chmod(temp_file, 0o000)
            
            loader = ATXAssetsLoader()
            
            with pytest.raises(PermissionError) as exc_info:
                loader.load(temp_file)
            
            assert "Permission denied" in str(exc_info.value)
        finally:
            # Restore permissions and delete
            os.chmod(temp_file, 0o644)
            os.unlink(temp_file)


class TestDataOperationsLoaderErrors:
    """Test error handling in ATXDataOperationsLoader."""
    
    def test_missing_file(self):
        """Test handling of missing program_to_dsn.json file."""
        loader = ATXDataOperationsLoader()
        
        with pytest.raises(FileNotFoundError) as exc_info:
            loader.load('nonexistent_program_to_dsn.json')
        
        assert "Data operations file not found" in str(exc_info.value)
    
    def test_invalid_json_syntax(self):
        """Test handling of malformed JSON."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('[invalid json')
            temp_file = f.name
        
        try:
            loader = ATXDataOperationsLoader()
            
            with pytest.raises(ValueError) as exc_info:
                loader.load(temp_file)
            
            assert "Invalid JSON" in str(exc_info.value)
            assert "line" in str(exc_info.value).lower()
        finally:
            os.unlink(temp_file)
    
    def test_schema_mismatch_not_list(self):
        """Test handling of schema mismatch (not a list)."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump({"not": "a list"}, f)
            temp_file = f.name
        
        try:
            loader = ATXDataOperationsLoader()
            
            with pytest.raises(ValueError) as exc_info:
                loader.load(temp_file)
            
            assert "Schema mismatch" in str(exc_info.value)
            assert "Expected a JSON array" in str(exc_info.value)
        finally:
            os.unlink(temp_file)


class TestConfigurationManagerErrors:
    """Test error handling in ConfigurationManager."""
    
    def test_missing_config_file(self):
        """Test handling of missing configuration file."""
        with pytest.raises(FileNotFoundError) as exc_info:
            manager = ConfigurationManager('nonexistent_config.yaml')
            manager.load()
        
        assert "Configuration file not found" in str(exc_info.value)
    
    def test_invalid_yaml_syntax(self):
        """Test handling of malformed YAML."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write('invalid: yaml: syntax:')
            temp_file = f.name
        
        try:
            with pytest.raises(Exception) as exc_info:
                manager = ConfigurationManager(temp_file)
                manager.load()
            
            # Should raise some kind of YAML error
            assert "YAML" in str(exc_info.value) or "parse" in str(exc_info.value).lower()
        finally:
            os.unlink(temp_file)
    
    def test_invalid_complexity_weight(self):
        """Test handling of invalid complexity weight."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write('complexity:\n  formula:\n    cc_weight: -1.0\n    loc_weight: 0.7\n')
            temp_file = f.name
        
        try:
            with pytest.raises(ValueError) as exc_info:
                manager = ConfigurationManager(temp_file)
                manager.load()
            
            assert "cc_weight must be non-negative" in str(exc_info.value)
        finally:
            os.unlink(temp_file)
    
    def test_invalid_threshold_order(self):
        """Test handling of invalid threshold order."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write('complexity:\n  tiers:\n    low_threshold: 20.0\n    medium_threshold: 10.0\n')
            temp_file = f.name
        
        try:
            with pytest.raises(ValueError) as exc_info:
                manager = ConfigurationManager(temp_file)
                manager.load()
            
            assert "medium_threshold" in str(exc_info.value)
            assert "greater than" in str(exc_info.value)
        finally:
            os.unlink(temp_file)


class TestWriterErrors:
    """Test error handling in writers."""
    
    def test_flow_writer_permission_denied(self):
        """Test handling of permission denied when writing flows."""
        # Create a minimal flow
        flow = Flow(
            flow_id="TEST001",
            name="TestFlow",
            entry_point=EntryPoint(program="PROG1", types=[], primary_type="CICS_TRANSACTION"),
            scope=Scope(programs=[], copybooks=[], datasets=[]),
            interfaces=None,
            data_operations=DataOperations(databases=[], datasets=[]),
            complexity=Complexity(
                total_programs=1,
                total_lines=100,
                cyclomatic_complexity=10,
                composite_score=5.0,
                tier="LOW"
            ),
            dependencies=FlowDependencies(required_flows=[], dependent_flows=[]),
            invoked_by_jobs=[]
        )
        
        # Create a read-only directory
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = os.path.join(temp_dir, 'flows.json')
            
            # Make directory read-only
            os.chmod(temp_dir, 0o444)
            
            try:
                writer = FlowWriter()
                
                with pytest.raises(PermissionError) as exc_info:
                    writer.write_migration_flows([flow], output_file)
                
                assert "Permission denied" in str(exc_info.value)
            finally:
                # Restore permissions
                os.chmod(temp_dir, 0o755)
    
    def test_job_writer_permission_denied(self):
        """Test handling of permission denied when writing jobs."""
        # Create a minimal job
        job = Job(
            job_name="TESTJOB",
            job_type="APPLICATION",
            has_custom_code=True,
            linked_flow=None,
            steps=[],
            datasets=[],
            dependencies=JobDependencies(must_run_after=[], must_run_before=[])
        )
        
        # Create a read-only directory
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = os.path.join(temp_dir, 'jobs.json')
            
            # Make directory read-only
            os.chmod(temp_dir, 0o444)
            
            try:
                writer = JobWriter()
                
                with pytest.raises(PermissionError) as exc_info:
                    writer.write_jobs([job], output_file)
                
                assert "Permission denied" in str(exc_info.value)
            finally:
                # Restore permissions
                os.chmod(temp_dir, 0o755)
    
    def test_entry_point_writer_permission_denied(self):
        """Test handling of permission denied when writing entry points."""
        # Create a minimal entry point
        entry_point = EntryPointRecord(
            program_name="PROG1",
            entry_type="ONLINE",
            confidence="EXPLICIT",
            source="CSD",
            description=None,
            transaction_id="TRN1",
            jcl_name=None,
            status="ENABLED"
        )
        
        # Create a read-only directory
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = os.path.join(temp_dir, 'entry_points.json')
            
            # Make directory read-only
            os.chmod(temp_dir, 0o444)
            
            try:
                writer = EntryPointWriter()
                
                with pytest.raises(PermissionError) as exc_info:
                    writer.write_json([entry_point], output_file)
                
                assert "Permission denied" in str(exc_info.value)
            finally:
                # Restore permissions
                os.chmod(temp_dir, 0o755)


class TestCircularDependencyWarnings:
    """Test circular dependency detection and warnings."""
    
    def test_circular_dependency_warning(self, capsys):
        """Test that circular dependencies generate warnings."""
        from tools.atx.dependency_transformer.analysis.call_graph_analyzer import CallGraphAnalyzer
        
        # Create a circular dependency: A -> B -> C -> A
        program_calls = {
            "PROG_A": ["PROG_B"],
            "PROG_B": ["PROG_C"],
            "PROG_C": ["PROG_A"]
        }
        
        analyzer = CallGraphAnalyzer()
        analyzer.build_call_graph(program_calls)
        
        # Detect circular dependencies (should print warnings)
        cycles = analyzer.detect_circular_dependencies()
        
        # Should find one cycle
        assert len(cycles) == 1
        assert set(cycles[0]) == {"PROG_A", "PROG_B", "PROG_C"}
        
        # Check warning was printed
        captured = capsys.readouterr()
        assert "Warning" in captured.out
        assert "circular dependency" in captured.out.lower()


class TestMissingMetricsWarnings:
    """Test missing metrics handling and warnings."""
    
    def test_missing_metrics_warning(self, capsys):
        """Test that missing metrics generate warnings."""
        from tools.atx.dependency_transformer.analysis.complexity_calculator import ComplexityCalculator
        from tools.atx.dependency_transformer.models.atx_models import ATXAssetMetrics
        
        # Create metrics for only one program
        metrics = {
            "PROG1": ATXAssetMetrics(
                name="PROG1",
                path="/path/prog1.cob",
                file_type="COB",
                cyclomatic_complexity=10,
                total_lines=100,
                empty_lines=10,
                effective_lines=80,
                comment_lines=10
            )
        }
        
        # Calculate complexity for multiple programs (one missing)
        calculator = ComplexityCalculator()
        result = calculator.calculate_flow_complexity(
            programs=["PROG1", "PROG2", "PROG3"],
            metrics=metrics,
            warn_on_missing=True
        )
        
        # Should have metrics for 1 program
        assert result["programs_with_metrics"] == 1
        assert len(result["programs_without_metrics"]) == 2
        
        # Check warning was printed
        captured = capsys.readouterr()
        assert "Warning" in captured.out
        assert "Missing metrics" in captured.out


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
