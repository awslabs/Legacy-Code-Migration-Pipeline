"""
Unit tests for dashboard control scripts.

Tests verify that dashboard scripts:
- Create PID and log files in project root
- Call other scripts with correct paths
- Execute successfully from project root
"""

import os
import subprocess
import tempfile
import time
from pathlib import Path
import pytest


class TestDashboardScripts:
    """Test suite for dashboard control scripts."""

    @pytest.fixture
    def project_root(self):
        """Get the project root directory."""
        # Navigate up from tests/unit to project root
        test_dir = Path(__file__).parent
        return test_dir.parent.parent

    @pytest.fixture
    def cleanup_dashboard_files(self, project_root):
        """Clean up dashboard files before and after tests."""
        pid_file = project_root / ".dashboard.pid"
        log_file = project_root / "dashboard.log"
        
        # Clean up before test
        if pid_file.exists():
            pid_file.unlink()
        if log_file.exists():
            log_file.unlink()
        
        yield
        
        # Clean up after test
        if pid_file.exists():
            pid_file.unlink()
        if log_file.exists():
            log_file.unlink()

    def test_startDashboard_creates_pid_in_project_root(
        self, project_root, cleanup_dashboard_files
    ):
        """Test that startDashboard.sh creates .dashboard.pid in project root."""
        script_path = project_root / "scripts" / "startDashboard.sh"
        
        # Skip if script doesn't exist
        if not script_path.exists():
            pytest.skip("startDashboard.sh not found in scripts/")
        
        # Read script content to verify PID file path
        script_content = script_path.read_text()
        
        # Verify PID_FILE variable is set to project root path
        assert 'PID_FILE=".dashboard.pid"' in script_content, \
            "startDashboard.sh doesn't set PID_FILE to .dashboard.pid"
        
        # Verify script writes to PID_FILE (not to scripts/.dashboard.pid)
        assert 'echo "$DASHBOARD_PID" > "$PID_FILE"' in script_content, \
            "startDashboard.sh doesn't write PID to PID_FILE"
        
        # Verify script changes to project root before creating PID file
        assert 'cd "$SCRIPT_DIR/.."' in script_content, \
            "startDashboard.sh doesn't change to project root"

    def test_startDashboard_creates_log_in_project_root(
        self, project_root, cleanup_dashboard_files
    ):
        """Test that startDashboard.sh creates dashboard.log in project root."""
        script_path = project_root / "scripts" / "startDashboard.sh"
        
        # Skip if script doesn't exist
        if not script_path.exists():
            pytest.skip("startDashboard.sh not found in scripts/")
        
        # Read script content to verify log file path
        script_content = script_path.read_text()
        
        # Verify LOG_FILE variable is set to project root path
        assert 'LOG_FILE="dashboard.log"' in script_content, \
            "startDashboard.sh doesn't set LOG_FILE to dashboard.log"
        
        # Verify script redirects output to LOG_FILE (not to scripts/dashboard.log)
        assert '> "$LOG_FILE"' in script_content, \
            "startDashboard.sh doesn't redirect output to LOG_FILE"
        
        # Verify script changes to project root before creating log file
        assert 'cd "$SCRIPT_DIR/.."' in script_content, \
            "startDashboard.sh doesn't change to project root"

    def test_stopDashboard_reads_pid_from_project_root(
        self, project_root, cleanup_dashboard_files
    ):
        """Test that stopDashboard.sh reads .dashboard.pid from project root."""
        pid_file = project_root / ".dashboard.pid"
        stop_script = project_root / "scripts" / "stopDashboard.sh"
        
        # Skip if script doesn't exist
        if not stop_script.exists():
            pytest.skip("stopDashboard.sh not found in scripts/")
        
        # Create a fake PID file with a non-existent PID
        fake_pid = "999999"
        pid_file.write_text(fake_pid)
        
        # Run stop script - it should read the PID file and handle gracefully
        result = subprocess.run(
            [str(stop_script)],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=10
        )
        
        # Script should complete successfully (exit code 0)
        # even if process doesn't exist
        assert result.returncode == 0, f"Stop script failed: {result.stderr}"
        
        # PID file should be cleaned up
        assert not pid_file.exists(), "PID file was not cleaned up"

    def test_restart_dashboard_calls_both_scripts(self, project_root):
        """Test that restart_dashboard.sh calls both stop and start scripts."""
        restart_script = project_root / "scripts" / "restart_dashboard.sh"
        
        # Skip if script doesn't exist
        if not restart_script.exists():
            pytest.skip("restart_dashboard.sh not found in scripts/")
        
        # Read the script content
        script_content = restart_script.read_text()
        
        # Verify it calls stopDashboard.sh with correct path
        assert "./scripts/stopDashboard.sh" in script_content, \
            "restart_dashboard.sh doesn't call ./scripts/stopDashboard.sh"
        
        # Verify it calls startDashboard.sh with correct path
        assert "./scripts/startDashboard.sh" in script_content, \
            "restart_dashboard.sh doesn't call ./scripts/startDashboard.sh"
        
        # Verify it changes to project root
        assert 'SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"' in script_content, \
            "restart_dashboard.sh doesn't set SCRIPT_DIR"
        assert 'cd "$SCRIPT_DIR/.."' in script_content, \
            "restart_dashboard.sh doesn't change to project root"

    def test_all_scripts_have_path_resolution(self, project_root):
        """Test that all dashboard scripts have path resolution code."""
        scripts = [
            "restart_dashboard.sh",
            "startDashboard.sh",
            "stopDashboard.sh"
        ]
        
        for script_name in scripts:
            script_path = project_root / "scripts" / script_name
            
            # Skip if script doesn't exist
            if not script_path.exists():
                pytest.skip(f"{script_name} not found in scripts/")
            
            script_content = script_path.read_text()
            
            # Verify path resolution code exists
            assert 'SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"' in script_content, \
                f"{script_name} doesn't set SCRIPT_DIR"
            assert 'cd "$SCRIPT_DIR/.."' in script_content, \
                f"{script_name} doesn't change to project root"

    def test_pid_and_log_files_use_project_root_paths(self, project_root):
        """Test that PID and log file paths are relative to project root."""
        scripts = ["startDashboard.sh", "stopDashboard.sh"]
        
        for script_name in scripts:
            script_path = project_root / "scripts" / script_name
            
            # Skip if script doesn't exist
            if not script_path.exists():
                pytest.skip(f"{script_name} not found in scripts/")
            
            script_content = script_path.read_text()
            
            # Verify PID_FILE uses simple relative path (not scripts/ prefix)
            assert 'PID_FILE=".dashboard.pid"' in script_content, \
                f"{script_name} doesn't use correct PID_FILE path"
            
            # For startDashboard.sh, also check LOG_FILE
            if script_name == "startDashboard.sh":
                assert 'LOG_FILE="dashboard.log"' in script_content, \
                    f"{script_name} doesn't use correct LOG_FILE path"
