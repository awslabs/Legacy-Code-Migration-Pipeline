"""Property-based tests for SMF record writer."""
