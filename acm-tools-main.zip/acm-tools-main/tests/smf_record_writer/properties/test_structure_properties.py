"""Property-based tests for structure correctness."""

import pytest
from hypothesis import given, settings, strategies as st
from tools.smf_analyzer.smf_record_writer.writers import BaseRecordWriter
from tools.smf_analyzer.smf_record_parser.models import Triplet


class TestStructureProperties:
    """Property tests for structure correctness."""
    
    @given(
        section_sizes=st.lists(st.integers(min_value=10, max_value=200), min_size=1, max_size=5),
        header_length=st.integers(min_value=50, max_value=150)
    )
    @settings(max_examples=100)
    def test_triplet_correctness(self, section_sizes, header_length):
        """Property 8: Triplet calculations enable correct section location.
        
        Feature: smf-record-writer, Property 8: Triplet Correctness
        Validates: Requirements 5.6, 6.4, 6.5.4
        """
        writer = BaseRecordWriter()
        
        # Create sections
        sections = {f'section_{i}': b'\x00' * size for i, size in enumerate(section_sizes)}
        
        # Calculate triplets
        triplets = writer.calculate_triplets(sections, header_length)
        
        # Verify triplets are sequential and correct
        expected_offset = header_length
        for i, (name, section_data) in enumerate(sections.items()):
            triplet = triplets[name]
            assert triplet.offset == expected_offset
            assert triplet.length == len(section_data)
            assert triplet.number == 1
            expected_offset += len(section_data)
