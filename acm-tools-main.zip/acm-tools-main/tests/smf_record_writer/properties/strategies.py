"""Hypothesis strategies for generating test SMF records."""

from hypothesis import strategies as st
from datetime import datetime, date, timedelta
import random


@st.composite
def generate_smf30_record(draw):
    """Generate a valid SMF Type 30 record for property testing."""
    return {
        'record_type': 30,
        'subtype': draw(st.integers(min_value=0, max_value=6)),
        'system_id': draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', min_size=4, max_size=4)),
        'timestamp': draw(st.datetimes(
            min_value=datetime(2020, 1, 1),
            max_value=datetime(2025, 12, 31)
        )),
        'date': draw(st.dates(
            min_value=date(2020, 1, 1),
            max_value=date(2025, 12, 31)
        )),
        'header': {},
        'identification': {
            'job_name': draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', min_size=1, max_size=8)),
            'program_name': draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', min_size=1, max_size=8)),
            'step_name': draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', min_size=1, max_size=8)),
            'user_id': draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', min_size=1, max_size=8))
        }
    }


@st.composite
def generate_smf64_record(draw):
    """Generate a valid SMF Type 64 record for property testing."""
    return {
        'record_type': 64,
        'subtype': draw(st.integers(min_value=0, max_value=5)),
        'system_id': draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', min_size=4, max_size=4)),
        'timestamp': draw(st.datetimes(
            min_value=datetime(2020, 1, 1),
            max_value=datetime(2025, 12, 31)
        )),
        'date': draw(st.dates(
            min_value=date(2020, 1, 1),
            max_value=date(2025, 12, 31)
        ))
    }


@st.composite
def generate_smf110_record(draw):
    """Generate a valid SMF Type 110 record for property testing."""
    return {
        'record_type': 110,
        'subtype': draw(st.integers(min_value=0, max_value=5)),
        'system_id': draw(st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', min_size=4, max_size=4)),
        'timestamp': draw(st.datetimes(
            min_value=datetime(2020, 1, 1),
            max_value=datetime(2025, 12, 31)
        )),
        'date': draw(st.dates(
            min_value=date(2020, 1, 1),
            max_value=date(2025, 12, 31)
        ))
    }
