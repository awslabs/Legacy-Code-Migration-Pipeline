"""Property-based tests for format consistency."""

import pytest
import tempfile
import struct
from hypothesis import given, settings, strategies as st
from tools.smf_analyzer.smf_record_writer import SMFFileWriter, SMFFileFormat
from .strategies import generate_smf30_record


class TestFormatProperties:
    """Property tests for format consistency."""
    
    @given(
        records=st.lists(generate_smf30_record(), min_size=1, max_size=5),
        format=st.sampled_from([SMFFileFormat.SIMPLE, SMFFileFormat.VB, SMFFileFormat.RDW4])
    )
    @settings(max_examples=50)
    def test_format_consistency(self, records, format):
        """Property 2: All records in file have correct format structure.
        
        Feature: smf-record-writer, Property 2: Format Consistency
        Validates: Requirements 2.1, 2.2, 2.3, 2.4
        """
        with tempfile.NamedTemporaryFile(delete=False, suffix='.dat') as f:
            temp_path = f.name
        
        # Write records
        with SMFFileWriter(temp_path, format=format) as writer:
            writer.write_records(records)
        
        # Verify format structure
        with open(temp_path, 'rb') as f:
            for _ in range(len(records)):
                if format == SMFFileFormat.SIMPLE:
                    rdw = f.read(2)
                    if len(rdw) < 2:
                        break
                    length = struct.unpack('>H', rdw)[0]
                    data = f.read(length - 2)
                    assert len(data) == length - 2
                elif format == SMFFileFormat.VB:
                    bdw = f.read(4)
                    if len(bdw) < 4:
                        break
                    rdw = f.read(4)
                    assert len(rdw) == 4
                elif format == SMFFileFormat.RDW4:
                    rdw = f.read(4)
                    if len(rdw) < 4:
                        break
                    length = struct.unpack('>H', rdw[:2])[0]
                    data = f.read(length - 4)
                    assert len(data) == length - 4
