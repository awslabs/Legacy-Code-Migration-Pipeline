"""Property-based tests for encoding correctness."""

import pytest
from hypothesis import given, settings, strategies as st
from datetime import datetime, date
from tools.smf_analyzer.smf_record_writer.writers import BaseRecordWriter


class TestEncodingProperties:
    """Property tests for encoding correctness."""
    
    @given(value=st.text(min_size=0, max_size=20), length=st.integers(min_value=1, max_value=50))
    @settings(max_examples=100)
    def test_ebcdic_string_encoding(self, value, length):
        """Property 3: EBCDIC string encoding with padding/truncation.
        
        Feature: smf-record-writer, Property 3: EBCDIC String Encoding
        Validates: Requirements 3.1, 3.2, 3.3
        """
        writer = BaseRecordWriter()
        result = writer.write_string(value, length)
        
        # Result should always be exact length
        assert len(result) == length
        
        # Should be EBCDIC encoded
        assert isinstance(result, bytes)
    
    @given(value=st.integers(min_value=0, max_value=255), length=st.just(1))
    @settings(max_examples=100)
    def test_binary_integer_encoding(self, value, length):
        """Property 4: Binary integer encoding round-trip.
        
        Feature: smf-record-writer, Property 4: Binary Integer Encoding
        Validates: Requirements 4.1
        """
        writer = BaseRecordWriter()
        result = writer.write_binary(value, length)
        
        # Result should be correct length
        assert len(result) == length
        
        # Should be bytes
        assert isinstance(result, bytes)
    
    @given(value=st.integers(min_value=0, max_value=99999), length=st.integers(min_value=3, max_value=8))
    @settings(max_examples=100)
    def test_packed_decimal_encoding(self, value, length):
        """Property 5: Packed decimal encoding.
        
        Feature: smf-record-writer, Property 5: Packed Decimal Encoding
        Validates: Requirements 4.2
        """
        writer = BaseRecordWriter()
        
        # Check if value fits in field
        max_digits = 2 * length - 1
        if len(str(value)) <= max_digits:
            result = writer.write_packed_decimal(value, length)
            assert len(result) == length
            assert isinstance(result, bytes)
