"""Property-based tests for write operations."""

import pytest
import tempfile
from hypothesis import given, settings, strategies as st
from tools.smf_analyzer.smf_record_writer import SMFFileWriter, SMFFileFormat
from .strategies import generate_smf30_record


class TestWriteProperties:
    """Property tests for write operations."""
    
    @given(records=st.lists(generate_smf30_record(), min_size=1, max_size=10))
    @settings(max_examples=50)
    def test_sequential_write_preservation(self, records):
        """Property 10: Sequential writes maintain order.
        
        Feature: smf-record-writer, Property 10: Sequential Write Preservation
        Validates: Requirements 1.2
        """
        with tempfile.NamedTemporaryFile(delete=False, suffix='.dat') as f:
            temp_path = f.name
        
        # Write records sequentially
        with SMFFileWriter(temp_path, format=SMFFileFormat.SIMPLE) as writer:
            writer.write_records(records)
        
        # Verify file exists and has content
        import os
        assert os.path.exists(temp_path)
        assert os.path.getsize(temp_path) > 0
        
        # Verify correct number of records written
        assert writer.records_written == len(records)
