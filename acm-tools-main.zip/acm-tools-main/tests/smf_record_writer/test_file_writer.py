"""Unit tests for SMFFileWriter."""

import pytest
import tempfile
from datetime import datetime, date
from tools.smf_analyzer.smf_record_writer import SMFFileWriter, SMFFileFormat


class TestSMFFileWriter:
    """Tests for SMFFileWriter."""
    
    def test_context_manager(self):
        """Test context manager usage."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            temp_path = f.name
        
        record = {
            'record_type': 30,
            'subtype': 4,
            'system_id': 'PROD',
            'timestamp': datetime(2024, 3, 15, 14, 30, 45),
            'date': date(2024, 3, 15),
            'header': {}
        }
        
        with SMFFileWriter(temp_path, format=SMFFileFormat.SIMPLE) as writer:
            writer.write_record(record)
        
        # File should exist and have content
        import os
        assert os.path.exists(temp_path)
        assert os.path.getsize(temp_path) > 0
    
    def test_write_multiple_records(self):
        """Test writing multiple records."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            temp_path = f.name
        
        records = [
            {
                'record_type': 30,
                'subtype': 4,
                'system_id': 'PROD',
                'timestamp': datetime(2024, 3, 15, 14, 30, 45),
                'date': date(2024, 3, 15),
                'header': {}
            }
            for _ in range(3)
        ]
        
        with SMFFileWriter(temp_path) as writer:
            writer.write_records(records)
        
        assert writer.records_written == 3
    
    def test_get_supported_types(self):
        """Test getting supported record types."""
        types = SMFFileWriter.get_supported_record_types()
        assert 30 in types
        assert 64 in types
        assert 110 in types
    
    def test_get_supported_formats(self):
        """Test getting supported formats."""
        formats = SMFFileWriter.get_supported_formats()
        assert SMFFileFormat.SIMPLE in formats
        assert SMFFileFormat.VB in formats
        assert SMFFileFormat.RDW4 in formats
