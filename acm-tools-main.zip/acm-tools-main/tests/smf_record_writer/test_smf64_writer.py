"""Unit tests for SMF64Writer."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_writer.writers import SMF64Writer


class TestSMF64Writer:
    """Tests for SMF64Writer."""
    
    def test_write_minimal_record(self):
        """Test writing minimal Type 64 record."""
        writer = SMF64Writer()
        record = {
            'record_type': 64,
            'subtype': 1,
            'system_id': 'PROD',
            'timestamp': datetime(2024, 3, 15, 14, 30, 45),
            'date': date(2024, 3, 15)
        }
        
        result = writer.write(record)
        assert len(result) > 0
        assert result[5] == 64  # Record type at offset 5
