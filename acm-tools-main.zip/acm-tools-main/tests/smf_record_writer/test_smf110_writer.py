"""Unit tests for SMF110Writer."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_writer.writers import SMF110Writer


class TestSMF110Writer:
    """Tests for SMF110Writer."""
    
    def test_write_minimal_record(self):
        """Test writing minimal Type 110 record."""
        writer = SMF110Writer()
        record = {
            'record_type': 110,
            'subtype': 1,
            'system_id': 'PROD',
            'timestamp': datetime(2024, 3, 15, 14, 30, 45),
            'date': date(2024, 3, 15)
        }
        
        result = writer.write(record)
        assert len(result) > 0
        assert result[5] == 110  # Record type at offset 5
