"""Unit tests for RecordValidator."""

import pytest
import warnings
from datetime import datetime, date
from tools.smf_analyzer.smf_record_writer.validation import RecordValidator


class TestValidateRecord:
    """Tests for validate_record method."""
    
    def test_validate_record_valid(self):
        """Test validation passes for valid record."""
        record = {
            'record_type': 30,
            'subtype': 4,
            'system_id': 'PROD',
            'timestamp': datetime.now(),
            'date': date.today(),
            'header': {}
        }
        
        # Should not raise
        RecordValidator.validate_record(record, 30)
    
    def test_validate_record_missing_fields(self):
        """Test validation fails for missing required fields."""
        record = {
            'record_type': 30,
            'subtype': 4
            # Missing system_id, timestamp, date, header
        }
        
        with pytest.raises(ValueError, match="Missing required fields"):
            RecordValidator.validate_record(record, 30)
    
    def test_validate_record_type_mismatch(self):
        """Test validation fails for record type mismatch."""
        record = {
            'record_type': 110,
            'subtype': 1,
            'system_id': 'PROD',
            'timestamp': datetime.now(),
            'date': date.today(),
            'header': {}
        }
        
        with pytest.raises(ValueError, match="Record type mismatch"):
            RecordValidator.validate_record(record, 30)


class TestValidateRequiredFields:
    """Tests for validate_required_fields method."""
    
    def test_all_fields_present(self):
        """Test validation passes when all fields present."""
        record = {'field1': 'value1', 'field2': 'value2'}
        required = ['field1', 'field2']
        
        # Should not raise
        RecordValidator.validate_required_fields(record, required)
    
    def test_missing_single_field(self):
        """Test validation fails for single missing field."""
        record = {'field1': 'value1'}
        required = ['field1', 'field2']
        
        with pytest.raises(ValueError, match="Missing required fields.*field2"):
            RecordValidator.validate_required_fields(record, required)
    
    def test_missing_multiple_fields(self):
        """Test validation fails for multiple missing fields."""
        record = {'field1': 'value1'}
        required = ['field1', 'field2', 'field3']
        
        with pytest.raises(ValueError, match="Missing required fields"):
            RecordValidator.validate_required_fields(record, required)
    
    def test_none_value_treated_as_missing(self):
        """Test that None values are treated as missing."""
        record = {'field1': 'value1', 'field2': None}
        required = ['field1', 'field2']
        
        with pytest.raises(ValueError, match="Missing required fields.*field2"):
            RecordValidator.validate_required_fields(record, required)



class TestValidateFieldType:
    """Tests for validate_field_type method."""
    
    def test_correct_type(self):
        """Test validation passes for correct type."""
        # Should not raise
        RecordValidator.validate_field_type(123, "test_field", int)
        RecordValidator.validate_field_type("test", "test_field", str)
    
    def test_wrong_type(self):
        """Test validation fails for wrong type."""
        with pytest.raises(ValueError, match="incorrect type"):
            RecordValidator.validate_field_type("123", "test_field", int)
    
    def test_multiple_allowed_types(self):
        """Test validation with multiple allowed types."""
        # Should not raise
        RecordValidator.validate_field_type(123, "test_field", (int, str))
        RecordValidator.validate_field_type("test", "test_field", (int, str))
        
        # Should raise
        with pytest.raises(ValueError, match="incorrect type"):
            RecordValidator.validate_field_type(12.5, "test_field", (int, str))


class TestValidateFieldRange:
    """Tests for validate_field_range method."""
    
    def test_value_in_range(self):
        """Test validation passes for value in range."""
        # Should not raise
        RecordValidator.validate_field_range(50, "test_field", 0, 100)
        RecordValidator.validate_field_range(0, "test_field", 0, 100)
        RecordValidator.validate_field_range(100, "test_field", 0, 100)
    
    def test_value_below_minimum(self):
        """Test validation fails for value below minimum."""
        with pytest.raises(ValueError, match="out of range"):
            RecordValidator.validate_field_range(-1, "test_field", 0, 100)
    
    def test_value_above_maximum(self):
        """Test validation fails for value above maximum."""
        with pytest.raises(ValueError, match="out of range"):
            RecordValidator.validate_field_range(101, "test_field", 0, 100)


class TestValidateStringLength:
    """Tests for validate_string_length method."""
    
    def test_string_within_length(self):
        """Test no warning for string within length."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            RecordValidator.validate_string_length("test", "test_field", 10)
            assert len(w) == 0
    
    def test_string_exceeds_length(self):
        """Test warning issued for string exceeding length."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            RecordValidator.validate_string_length("verylongstring", "test_field", 5)
            assert len(w) == 1
            assert "truncated" in str(w[0].message).lower()
    
    def test_empty_string(self):
        """Test no warning for empty string."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            RecordValidator.validate_string_length("", "test_field", 10)
            assert len(w) == 0
