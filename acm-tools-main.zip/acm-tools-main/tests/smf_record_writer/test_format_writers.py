"""Unit tests for format writers."""

import pytest
import struct
import tempfile
from tools.smf_analyzer.smf_record_parser.utils.format_detection import SMFFileFormat
from tools.smf_analyzer.smf_record_writer.formats import (
    SimpleFormatWriter,
    VBFormatWriter,
    RDW4FormatWriter,
    FormatWriterFactory
)


class TestSimpleFormatWriter:
    """Tests for SimpleFormatWriter."""
    
    def test_write_record_basic(self):
        """Test Simple format (2-byte RDW) writing."""
        writer = SimpleFormatWriter()
        record_data = b'\x00' * 100  # 100 bytes of data
        
        with tempfile.NamedTemporaryFile(delete=False, mode='wb') as f:
            writer.write_record(f, record_data)
            f.flush()
            
            # Read back and verify
            f.seek(0)
            rdw = f.read(2)
            assert struct.unpack('>H', rdw)[0] == 102  # 100 + 2 for RDW
            data = f.read(100)
            assert data == record_data
    
    def test_write_record_too_large(self):
        """Test that oversized records raise error."""
        writer = SimpleFormatWriter()
        record_data = b'\x00' * 32760  # Too large
        
        with tempfile.NamedTemporaryFile(delete=False, mode='wb') as f:
            with pytest.raises(ValueError, match="too large"):
                writer.write_record(f, record_data)


class TestVBFormatWriter:
    """Tests for VBFormatWriter."""
    
    def test_write_record_basic(self):
        """Test VB format (BDW + RDW) writing."""
        writer = VBFormatWriter()
        record_data = b'\x00' * 100
        
        with tempfile.NamedTemporaryFile(delete=False, mode='wb') as f:
            writer.write_record(f, record_data)
            f.flush()
            
            # Read back and verify
            f.seek(0)
            bdw = f.read(4)
            block_length = struct.unpack('>H', bdw[:2])[0]
            assert block_length == 108  # 100 + 4 (RDW) + 4 (BDW)
            
            rdw = f.read(4)
            record_length = struct.unpack('>H', rdw[:2])[0]
            assert record_length == 104  # 100 + 4 (RDW)
            
            data = f.read(100)
            assert data == record_data
    
    def test_write_record_too_large(self):
        """Test that oversized records raise error."""
        writer = VBFormatWriter()
        record_data = b'\x00' * 32760
        
        with tempfile.NamedTemporaryFile(delete=False, mode='wb') as f:
            with pytest.raises(ValueError, match="too large"):
                writer.write_record(f, record_data)


class TestRDW4FormatWriter:
    """Tests for RDW4FormatWriter."""
    
    def test_write_record_basic(self):
        """Test RDW4 format (4-byte RDW) writing."""
        writer = RDW4FormatWriter()
        record_data = b'\x00' * 100
        
        with tempfile.NamedTemporaryFile(delete=False, mode='wb') as f:
            writer.write_record(f, record_data)
            f.flush()
            
            # Read back and verify
            f.seek(0)
            rdw = f.read(4)
            record_length = struct.unpack('>H', rdw[:2])[0]
            assert record_length == 104  # 100 + 4 for RDW
            
            data = f.read(100)
            assert data == record_data
    
    def test_write_record_too_large(self):
        """Test that oversized records raise error."""
        writer = RDW4FormatWriter()
        record_data = b'\x00' * 32760
        
        with tempfile.NamedTemporaryFile(delete=False, mode='wb') as f:
            with pytest.raises(ValueError, match="too large"):
                writer.write_record(f, record_data)


class TestFormatWriterFactory:
    """Tests for FormatWriterFactory."""
    
    def test_create_simple_writer(self):
        """Test creating Simple format writer."""
        writer = FormatWriterFactory.create_writer(SMFFileFormat.SIMPLE)
        assert isinstance(writer, SimpleFormatWriter)
    
    def test_create_vb_writer(self):
        """Test creating VB format writer."""
        writer = FormatWriterFactory.create_writer(SMFFileFormat.VB)
        assert isinstance(writer, VBFormatWriter)
    
    def test_create_rdw4_writer(self):
        """Test creating RDW4 format writer."""
        writer = FormatWriterFactory.create_writer(SMFFileFormat.RDW4)
        assert isinstance(writer, RDW4FormatWriter)
    
    def test_unsupported_format(self):
        """Test that unsupported formats raise error."""
        with pytest.raises(ValueError, match="Unsupported format"):
            FormatWriterFactory.create_writer(SMFFileFormat.AUTO)
