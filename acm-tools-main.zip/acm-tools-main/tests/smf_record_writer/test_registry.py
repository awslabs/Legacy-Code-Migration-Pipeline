"""Unit tests for WriterRegistry."""

import pytest
from tools.smf_analyzer.smf_record_writer.writers.writer_registry import WriterRegistry
from tools.smf_analyzer.smf_record_writer.writers import SMF30Writer, SMF64Writer, SMF110Writer


class TestWriterRegistry:
    """Tests for WriterRegistry."""
    
    def test_get_writer_smf30(self):
        """Test getting SMF30 writer."""
        registry = WriterRegistry()
        writer = registry.get_writer(30)
        assert isinstance(writer, SMF30Writer)
    
    def test_get_writer_smf64(self):
        """Test getting SMF64 writer."""
        registry = WriterRegistry()
        writer = registry.get_writer(64)
        assert isinstance(writer, SMF64Writer)
    
    def test_get_writer_smf110(self):
        """Test getting SMF110 writer."""
        registry = WriterRegistry()
        writer = registry.get_writer(110)
        assert isinstance(writer, SMF110Writer)
    
    def test_get_writer_unsupported_type(self):
        """Test error for unsupported record type."""
        registry = WriterRegistry()
        with pytest.raises(ValueError, match="No writer registered"):
            registry.get_writer(999)
    
    def test_get_supported_types(self):
        """Test getting list of supported types."""
        types = WriterRegistry.get_supported_types()
        assert 30 in types
        assert 64 in types
        assert 110 in types
        assert len(types) == 3
