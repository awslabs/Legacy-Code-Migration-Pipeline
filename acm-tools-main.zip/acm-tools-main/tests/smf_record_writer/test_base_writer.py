"""Unit tests for BaseRecordWriter encoding methods."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_writer.writers.base_writer import BaseRecordWriter
from tools.smf_analyzer.smf_record_parser.models import Triplet


class TestWriteBinary:
    """Tests for write_binary method."""
    
    def test_write_binary_1_byte(self):
        """Test encoding 1-byte binary integer."""
        writer = BaseRecordWriter()
        assert writer.write_binary(30, 1) == b'\x1e'
        assert writer.write_binary(255, 1) == b'\xff'
        assert writer.write_binary(0, 1) == b'\x00'
    
    def test_write_binary_2_bytes(self):
        """Test encoding 2-byte binary integer."""
        writer = BaseRecordWriter()
        assert writer.write_binary(1024, 2) == b'\x04\x00'
        assert writer.write_binary(0, 2) == b'\x00\x00'
        assert writer.write_binary(65535, 2) == b'\xff\xff'
    
    def test_write_binary_4_bytes(self):
        """Test encoding 4-byte binary integer."""
        writer = BaseRecordWriter()
        assert writer.write_binary(1000000, 4) == b'\x00\x0f\x42\x40'
        assert writer.write_binary(0, 4) == b'\x00\x00\x00\x00'
    
    def test_write_binary_8_bytes(self):
        """Test encoding 8-byte binary integer."""
        writer = BaseRecordWriter()
        result = writer.write_binary(1234567890123, 8)
        assert len(result) == 8
    
    def test_write_binary_overflow(self):
        """Test that oversized values raise error."""
        writer = BaseRecordWriter()
        with pytest.raises(ValueError, match="exceeds field size"):
            writer.write_binary(256, 1)  # 256 doesn't fit in 1 byte
        
        with pytest.raises(ValueError, match="exceeds field size"):
            writer.write_binary(65536, 2)  # 65536 doesn't fit in 2 bytes
    
    def test_write_binary_signed(self):
        """Test signed binary encoding."""
        writer = BaseRecordWriter()
        assert writer.write_binary(-1, 1, signed=True) == b'\xff'
        assert writer.write_binary(-128, 1, signed=True) == b'\x80'


class TestWriteString:
    """Tests for write_string method."""
    
    def test_write_string_padding(self):
        """Test EBCDIC string encoding with padding."""
        writer = BaseRecordWriter()
        result = writer.write_string("PROD", 8)
        
        # Should be "PROD" + 4 spaces in EBCDIC
        assert len(result) == 8
        assert result[:4] == "PROD".encode('cp037')
        assert result[4:] == b'\x40\x40\x40\x40'  # EBCDIC spaces
    
    def test_write_string_truncation(self):
        """Test EBCDIC string encoding with truncation."""
        writer = BaseRecordWriter()
        result = writer.write_string("VERYLONGNAME", 8)
        
        # Should be truncated to 8 bytes
        assert len(result) == 8
        assert result == "VERYLONG".encode('cp037')
    
    def test_write_string_exact_length(self):
        """Test EBCDIC string encoding with exact length."""
        writer = BaseRecordWriter()
        result = writer.write_string("EXACTLY8", 8)
        
        assert len(result) == 8
        assert result == "EXACTLY8".encode('cp037')
    
    def test_write_string_empty(self):
        """Test empty string encoding."""
        writer = BaseRecordWriter()
        result = writer.write_string("", 4)
        
        # Should be all EBCDIC spaces
        assert result == b'\x40\x40\x40\x40'
    
    def test_write_string_none(self):
        """Test None value encoding."""
        writer = BaseRecordWriter()
        result = writer.write_string(None, 4)
        
        # Should be all EBCDIC spaces
        assert result == b'\x40\x40\x40\x40'
    
    def test_write_string_whitespace_only(self):
        """Test whitespace-only string encoding."""
        writer = BaseRecordWriter()
        result = writer.write_string("   ", 4)
        
        # Should be all EBCDIC spaces
        assert result == b'\x40\x40\x40\x40'


class TestWritePackedDecimal:
    """Tests for write_packed_decimal method."""
    
    def test_write_packed_decimal_basic(self):
        """Test basic packed decimal encoding."""
        writer = BaseRecordWriter()
        
        # 12345 → 0x01234F (3 bytes)
        result = writer.write_packed_decimal(12345, 3)
        assert result == b'\x01\x23\x4f'
    
    def test_write_packed_decimal_date_format(self):
        """Test packed decimal encoding for date format."""
        writer = BaseRecordWriter()
        
        # 2024074 → 0x02024074F (4 bytes)
        result = writer.write_packed_decimal(2024074, 4)
        assert result == b'\x02\x02\x40\x74\x0f'
    
    def test_write_packed_decimal_zero(self):
        """Test packed decimal encoding of zero."""
        writer = BaseRecordWriter()
        result = writer.write_packed_decimal(0, 2)
        assert result == b'\x00\x0f'
    
    def test_write_packed_decimal_overflow(self):
        """Test that oversized values raise error."""
        writer = BaseRecordWriter()
        # 3 bytes = max 5 digits
        with pytest.raises(ValueError, match="has .* digits"):
            writer.write_packed_decimal(123456, 3)
    
    def test_write_packed_decimal_negative(self):
        """Test that negative values raise error."""
        writer = BaseRecordWriter()
        with pytest.raises(ValueError, match="negative"):
            writer.write_packed_decimal(-123, 2)


class TestWriteTimestamp:
    """Tests for write_timestamp method."""
    
    def test_write_timestamp_hundredths(self):
        """Test timestamp encoding in hundredths format."""
        writer = BaseRecordWriter()
        # 14:30:45.50
        dt = datetime(2024, 3, 15, 14, 30, 45, 500000)
        result = writer.write_timestamp(dt, format="hundredths")
        
        # 14*3600 + 30*60 + 45 = 52245 seconds = 5224500 hundredths
        assert len(result) == 4
    
    def test_write_timestamp_tod(self):
        """Test timestamp encoding in TOD format."""
        writer = BaseRecordWriter()
        dt = datetime(2024, 3, 15, 14, 30, 45)
        result = writer.write_timestamp(dt, format="tod")
        
        assert len(result) == 8
    
    def test_write_timestamp_from_string(self):
        """Test timestamp encoding from ISO string."""
        writer = BaseRecordWriter()
        result = writer.write_timestamp("2024-03-15T14:30:45", format="hundredths")
        
        assert len(result) == 4


class TestWriteDate:
    """Tests for write_date method."""
    
    def test_write_date_2024(self):
        """Test date encoding for 2024."""
        writer = BaseRecordWriter()
        # 2024-03-15 (day 75 of year)
        result = writer.write_date(date(2024, 3, 15))
        
        # 0x0124075F: century=1, year=24, day=075
        assert result == b'\x01\x24\x07\x5f'
    
    def test_write_date_1999(self):
        """Test date encoding for 1999."""
        writer = BaseRecordWriter()
        # 1999-12-31 (day 365 of year)
        result = writer.write_date(date(1999, 12, 31))
        
        # 0x0099365F: century=0, year=99, day=365
        assert result == b'\x00\x99\x36\x5f'
    
    def test_write_date_from_string(self):
        """Test date encoding from ISO string."""
        writer = BaseRecordWriter()
        result = writer.write_date("2024-01-01")
        
        assert len(result) == 4



class TestWriteTriplet:
    """Tests for write_triplet method."""
    
    def test_write_triplet_basic(self):
        """Test triplet encoding."""
        writer = BaseRecordWriter()
        triplet = Triplet(offset=104, length=38, number=1)
        result = writer.write_triplet(triplet)
        
        # 8 bytes: offset(4) + length(2) + number(2)
        assert len(result) == 8
        assert result[:4] == b'\x00\x00\x00\x68'  # 104
        assert result[4:6] == b'\x00\x26'  # 38
        assert result[6:8] == b'\x00\x01'  # 1
    
    def test_write_triplet_zero(self):
        """Test encoding of zero triplet (section doesn't exist)."""
        writer = BaseRecordWriter()
        triplet = Triplet(offset=0, length=0, number=0)
        result = writer.write_triplet(triplet)
        
        assert result == b'\x00' * 8


class TestCalculateTriplets:
    """Tests for calculate_triplets method."""
    
    def test_calculate_triplets_single_section(self):
        """Test triplet calculation with single section."""
        writer = BaseRecordWriter()
        sections = {
            'identification': b'\x00' * 148
        }
        triplets = writer.calculate_triplets(sections, header_length=104)
        
        assert triplets['identification'].offset == 104
        assert triplets['identification'].length == 148
        assert triplets['identification'].number == 1
    
    def test_calculate_triplets_multiple_sections(self):
        """Test triplet calculation with multiple sections."""
        writer = BaseRecordWriter()
        sections = {
            'subsystem': b'\x00' * 38,
            'identification': b'\x00' * 148,
            'processor': b'\x00' * 52
        }
        triplets = writer.calculate_triplets(sections, header_length=104)
        
        # First section starts after header
        assert triplets['subsystem'].offset == 104
        assert triplets['subsystem'].length == 38
        
        # Second section starts after first
        assert triplets['identification'].offset == 142
        assert triplets['identification'].length == 148
        
        # Third section starts after second
        assert triplets['processor'].offset == 290
        assert triplets['processor'].length == 52
    
    def test_calculate_triplets_with_none(self):
        """Test triplet calculation with missing sections."""
        writer = BaseRecordWriter()
        sections = {
            'subsystem': b'\x00' * 38,
            'identification': None,
            'processor': b'\x00' * 52
        }
        triplets = writer.calculate_triplets(sections, header_length=104)
        
        # First section exists
        assert triplets['subsystem'].offset == 104
        
        # Second section doesn't exist
        assert triplets['identification'].offset == 0
        assert triplets['identification'].length == 0
        assert triplets['identification'].number == 0
        
        # Third section starts after first (skipping missing second)
        assert triplets['processor'].offset == 142


class TestValidateFieldValue:
    """Tests for validate_field_value method."""
    
    def test_validate_field_value_correct_type(self):
        """Test validation passes for correct type."""
        writer = BaseRecordWriter()
        # Should not raise
        writer.validate_field_value(123, "test_field", int)
        writer.validate_field_value("test", "test_field", str)
    
    def test_validate_field_value_wrong_type(self):
        """Test validation fails for wrong type."""
        writer = BaseRecordWriter()
        with pytest.raises(ValueError, match="incorrect type"):
            writer.validate_field_value("123", "test_field", int)
    
    def test_validate_field_value_range(self):
        """Test validation with range checks."""
        writer = BaseRecordWriter()
        # Should not raise
        writer.validate_field_value(50, "test_field", int, min_value=0, max_value=100)
        
        # Below minimum
        with pytest.raises(ValueError, match="below minimum"):
            writer.validate_field_value(-1, "test_field", int, min_value=0)
        
        # Above maximum
        with pytest.raises(ValueError, match="exceeds maximum"):
            writer.validate_field_value(101, "test_field", int, max_value=100)
