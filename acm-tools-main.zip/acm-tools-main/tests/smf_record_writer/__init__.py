"""Tests for SMF record writer."""
