"""Unit tests for SMF30Writer."""

import pytest
from datetime import datetime, date
from tools.smf_analyzer.smf_record_writer.writers import SMF30Writer


class TestSMF30Writer:
    """Tests for SMF30Writer."""
    
    def test_write_minimal_record(self):
        """Test writing minimal Type 30 record."""
        writer = SMF30Writer()
        record = {
            'record_type': 30,
            'subtype': 4,
            'system_id': 'PROD',
            'timestamp': datetime(2024, 3, 15, 14, 30, 45),
            'date': date(2024, 3, 15),
            'header': {}
        }
        
        result = writer.write(record)
        assert len(result) > 0
        assert result[5] == 30  # Record type at offset 5
    
    def test_write_with_identification(self):
        """Test writing record with identification section."""
        writer = SMF30Writer()
        record = {
            'record_type': 30,
            'subtype': 4,
            'system_id': 'PROD',
            'timestamp': datetime(2024, 3, 15, 14, 30, 45),
            'date': date(2024, 3, 15),
            'header': {},
            'identification': {
                'job_name': 'TESTJOB',
                'program_name': 'TESTPGM',
                'step_name': 'STEP01',
                'user_id': 'USER01'
            }
        }
        
        result = writer.write(record)
        assert len(result) > 104  # Header + identification section
