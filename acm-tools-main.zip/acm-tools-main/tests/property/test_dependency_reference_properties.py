"""
Property-based tests for dependency reference validation.

Feature: migration-workpackage-planner
Property 15: Dependency Reference Validation
Validates: Requirements 8.1, 8.2
"""

import pytest
from hypothesis import given, strategies as st, settings, assume
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.phase.phase_assigner import PhaseAssigner, ValidationError


# Custom strategies for generating test data
@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def valid_flows_strategy(draw):
    """Generate flows where all dependency references are valid."""
    # Generate 1 to 15 flows
    num_flows = draw(st.integers(min_value=1, max_value=15))
    flows = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        name = f"Flow {i}"
        
        # Generate programs (1 to 5 programs)
        num_programs = draw(st.integers(min_value=1, max_value=5))
        programs = [draw(program_strategy()) for _ in range(num_programs)]
        
        # Dependencies: can only reference flows created before this one
        max_deps = min(i, 3)
        num_deps = draw(st.integers(min_value=0, max_value=max_deps))
        
        if num_deps > 0:
            dep_indices = draw(st.lists(
                st.integers(min_value=0, max_value=i-1),
                min_size=num_deps,
                max_size=num_deps,
                unique=True
            ))
            required_flows = [f"FLOW_{idx:03d}" for idx in dep_indices]
        else:
            required_flows = []
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=name,
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
    
    return flows


@st.composite
def invalid_flows_strategy(draw):
    """Generate flows with at least one invalid dependency reference."""
    # Generate 1 to 10 flows
    num_flows = draw(st.integers(min_value=1, max_value=10))
    flows = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        name = f"Flow {i}"
        
        num_programs = draw(st.integers(min_value=1, max_value=5))
        programs = [draw(program_strategy()) for _ in range(num_programs)]
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=name,
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
    
    # Now add an invalid reference to at least one flow
    # Choose a random flow to add invalid reference
    target_flow_idx = draw(st.integers(min_value=0, max_value=num_flows-1))
    
    # Generate a non-existent flow ID
    invalid_flow_id = f"FLOW_INVALID_{draw(st.integers(min_value=100, max_value=999))}"
    
    flows[target_flow_idx].required_flows = [invalid_flow_id]
    
    return flows, invalid_flow_id


@given(valid_flows_strategy())
@settings(max_examples=100, deadline=None)
def test_dependency_reference_validation_accepts_valid_references(flows):
    """
    Property 15: Dependency Reference Validation (valid references)
    
    For any set of flows where all dependency references exist,
    the validator should accept the references without errors.
    
    **Validates: Requirements 8.1, 8.2**
    """
    assigner = PhaseAssigner()
    
    # Should not raise any exception
    try:
        assigner.validate_dag(flows)
    except ValidationError as e:
        pytest.fail(f"Valid dependency references rejected: {e}")
    
    # Verify all references are valid
    flow_ids = {flow.flow_id for flow in flows}
    
    for flow in flows:
        for required_flow in flow.required_flows:
            assert required_flow in flow_ids, (
                f"Flow {flow.flow_id} references non-existent flow {required_flow}"
            )


@given(invalid_flows_strategy())
@settings(max_examples=100, deadline=None)
def test_dependency_reference_validation_rejects_invalid_references(flows_and_invalid):
    """
    Property 15: Dependency Reference Validation (invalid references)
    
    For any set of flows with at least one invalid dependency reference,
    the validator should:
    1. Detect the invalid reference
    2. Raise a ValidationError
    3. Report the missing flow ID in the error message
    
    **Validates: Requirements 8.1, 8.2**
    """
    flows, invalid_flow_id = flows_and_invalid
    
    assigner = PhaseAssigner()
    
    # Should raise ValidationError
    with pytest.raises(ValidationError) as exc_info:
        assigner.validate_dag(flows)
    
    # Error message should mention the invalid flow ID
    error_message = str(exc_info.value)
    assert invalid_flow_id in error_message, (
        f"Error message does not mention invalid flow ID {invalid_flow_id}: "
        f"{error_message}"
    )
    
    # Error message should mention "non-existent"
    assert "non-existent" in error_message.lower(), (
        f"Error message does not indicate reference is non-existent: {error_message}"
    )


def test_dependency_reference_validation_single_invalid_reference():
    """
    Property 15: Dependency Reference Validation (single invalid reference)
    
    Test validation with a single flow referencing a non-existent flow.
    
    **Validates: Requirements 8.1, 8.2**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_NONEXISTENT"],  # Invalid reference
            dependent_flows=[]
        )
    ]
    
    assigner = PhaseAssigner()
    
    # Should raise ValidationError
    with pytest.raises(ValidationError) as exc_info:
        assigner.validate_dag(flows)
    
    error_message = str(exc_info.value)
    
    # Should mention both the referencing flow and the missing flow
    assert "FLOW_A" in error_message, (
        f"Error message does not mention referencing flow: {error_message}"
    )
    assert "FLOW_NONEXISTENT" in error_message, (
        f"Error message does not mention missing flow: {error_message}"
    )


def test_dependency_reference_validation_multiple_invalid_references():
    """
    Property 15: Dependency Reference Validation (multiple invalid references)
    
    Test validation with multiple flows referencing non-existent flows.
    
    **Validates: Requirements 8.1, 8.2**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_MISSING1"],  # Invalid reference
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_B",
            name="Flow B",
            programs=[Program(name="PROG_B", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_MISSING2"],  # Invalid reference
            dependent_flows=[]
        )
    ]
    
    assigner = PhaseAssigner()
    
    # Should raise ValidationError (at least for the first invalid reference)
    with pytest.raises(ValidationError):
        assigner.validate_dag(flows)


def test_dependency_reference_validation_mixed_valid_invalid():
    """
    Property 15: Dependency Reference Validation (mixed references)
    
    Test validation with some valid and some invalid references.
    
    **Validates: Requirements 8.1, 8.2**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_B",
            name="Flow B",
            programs=[Program(name="PROG_B", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A", "FLOW_INVALID"],  # One valid, one invalid
            dependent_flows=[]
        )
    ]
    
    assigner = PhaseAssigner()
    
    # Should raise ValidationError due to invalid reference
    with pytest.raises(ValidationError) as exc_info:
        assigner.validate_dag(flows)
    
    error_message = str(exc_info.value)
    assert "FLOW_INVALID" in error_message, (
        f"Error message does not mention invalid flow: {error_message}"
    )


@given(st.integers(min_value=1, max_value=20))
@settings(max_examples=100)
def test_dependency_reference_validation_no_dependencies(num_flows):
    """
    Property 15: Dependency Reference Validation (no dependencies)
    
    Flows with no dependencies should always pass validation.
    
    **Validates: Requirements 8.1**
    """
    flows = []
    
    for i in range(num_flows):
        flow = BusinessFlow(
            flow_id=f"FLOW_{i:03d}",
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],  # No dependencies
            dependent_flows=[]
        )
        flows.append(flow)
    
    assigner = PhaseAssigner()
    
    # Should not raise any exception
    try:
        assigner.validate_dag(flows)
    except ValidationError as e:
        pytest.fail(f"Flows with no dependencies rejected: {e}")


def test_dependency_reference_validation_all_valid_references():
    """
    Property 15: Dependency Reference Validation (all valid)
    
    Test with a complex dependency graph where all references are valid.
    
    **Validates: Requirements 8.1, 8.2**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_B",
            name="Flow B",
            programs=[Program(name="PROG_B", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A"],  # Valid reference
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_C",
            name="Flow C",
            programs=[Program(name="PROG_C", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A", "FLOW_B"],  # Valid references
            dependent_flows=[]
        )
    ]
    
    assigner = PhaseAssigner()
    
    # Should not raise any exception
    try:
        assigner.validate_dag(flows)
    except ValidationError as e:
        pytest.fail(f"Valid dependency references rejected: {e}")
