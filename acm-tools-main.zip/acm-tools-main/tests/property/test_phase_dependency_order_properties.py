"""
Property-based tests for phase dependency order validation.

Feature: migration-workpackage-planner
Property 16: Phase Dependency Order Validation
Validates: Requirements 8.6
"""

import pytest
from hypothesis import given, strategies as st, settings
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.models.workpackage import WorkpackageAssignment
from tools.migration_planner.phase.phase_assigner import PhaseAssigner


# Custom strategies for generating test data
@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def dag_flows_strategy(draw):
    """Generate a list of flows that form a valid DAG."""
    # Generate 1 to 15 flows
    num_flows = draw(st.integers(min_value=1, max_value=15))
    flows = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        name = f"Flow {i}"
        
        # Generate programs (1 to 10 programs)
        num_programs = draw(st.integers(min_value=1, max_value=10))
        programs = [draw(program_strategy()) for _ in range(num_programs)]
        
        # Generate databases (0 to 3 databases)
        num_databases = draw(st.integers(min_value=0, max_value=3))
        databases = [f"DB{j}" for j in range(num_databases)]
        
        composite_score = draw(st.floats(
            min_value=0.0,
            max_value=100.0,
            allow_nan=False,
            allow_infinity=False
        ))
        
        # Dependencies: can only depend on flows created before this one (DAG property)
        max_deps = min(i, 3)
        num_deps = draw(st.integers(min_value=0, max_value=max_deps))
        
        if num_deps > 0:
            dep_indices = draw(st.lists(
                st.integers(min_value=0, max_value=i-1),
                min_size=num_deps,
                max_size=num_deps,
                unique=True
            ))
            required_flows = [f"FLOW_{idx:03d}" for idx in dep_indices]
        else:
            required_flows = []
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=name,
            programs=programs,
            databases=databases,
            total_programs=len(programs),
            composite_score=composite_score,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
    
    return flows


@given(dag_flows_strategy())
@settings(max_examples=100, deadline=None)
def test_phase_dependency_order_validation(flows):
    """
    Property 16: Phase Dependency Order Validation
    
    For any phase assignment, all flows in a phase should only depend on
    flows in earlier phases (lower phase numbers).
    
    **Validates: Requirements 8.6**
    """
    # Generate workpackages
    workpackages = []
    for i, flow in enumerate(flows):
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow.flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Build flow_id to phase mapping
    flow_phases = assigner.flow_phases
    flow_map = {flow.flow_id: flow for flow in flows}
    
    # Property: All dependencies must be in earlier phases
    for flow in flows:
        current_phase = flow_phases[flow.flow_id]
        
        for required_flow_id in flow.required_flows:
            required_phase = flow_phases[required_flow_id]
            
            assert required_phase < current_phase, (
                f"Phase dependency order violated: "
                f"Flow {flow.flow_id} (phase {current_phase}) depends on "
                f"flow {required_flow_id} (phase {required_phase}), "
                f"but dependency is not in an earlier phase"
            )
    
    # Additional property: Phase difference should be minimal
    # (dependency should be in the immediately preceding phase or earlier)
    for flow in flows:
        if flow.required_flows:
            current_phase = flow_phases[flow.flow_id]
            
            # Find maximum phase of all dependencies
            max_dep_phase = max(
                flow_phases[dep_flow_id]
                for dep_flow_id in flow.required_flows
            )
            
            # Current phase should be exactly max_dep_phase + 1
            assert current_phase == max_dep_phase + 1, (
                f"Phase assignment not optimal: "
                f"Flow {flow.flow_id} is in phase {current_phase}, "
                f"but max dependency phase is {max_dep_phase} "
                f"(should be in phase {max_dep_phase + 1})"
            )


@given(st.integers(min_value=2, max_value=10))
@settings(max_examples=100)
def test_phase_dependency_order_linear_chain(chain_length):
    """
    Property 16: Phase Dependency Order Validation (linear chain)
    
    For a linear chain of dependencies (A -> B -> C -> ...),
    each flow should be in a phase one higher than its dependency.
    
    **Validates: Requirements 8.6**
    """
    # Create linear chain of flows
    flows = []
    workpackages = []
    
    for i in range(chain_length):
        flow_id = f"FLOW_{i:03d}"
        
        # Each flow depends on the previous one (except the first)
        if i == 0:
            required_flows = []
        else:
            required_flows = [f"FLOW_{i-1:03d}"]
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
        
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Verify phase order
    for i in range(len(flows)):
        flow = flows[i]
        current_phase = assigner.flow_phases[flow.flow_id]
        
        if i == 0:
            # First flow should be in phase 1
            assert current_phase == 1, (
                f"First flow should be in phase 1, but is in phase {current_phase}"
            )
        else:
            # Each subsequent flow should be in phase i+1
            expected_phase = i + 1
            assert current_phase == expected_phase, (
                f"Flow {flow.flow_id} should be in phase {expected_phase}, "
                f"but is in phase {current_phase}"
            )
            
            # Verify dependency is in earlier phase
            dep_flow_id = flow.required_flows[0]
            dep_phase = assigner.flow_phases[dep_flow_id]
            
            assert dep_phase < current_phase, (
                f"Dependency {dep_flow_id} (phase {dep_phase}) "
                f"is not in earlier phase than {flow.flow_id} (phase {current_phase})"
            )


def test_phase_dependency_order_diamond_pattern():
    """
    Property 16: Phase Dependency Order Validation (diamond pattern)
    
    Test with a diamond dependency pattern:
        A
       / \
      B   C
       \ /
        D
    
    **Validates: Requirements 8.6**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_B",
            name="Flow B",
            programs=[Program(name="PROG_B", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A"],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_C",
            name="Flow C",
            programs=[Program(name="PROG_C", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A"],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_D",
            name="Flow D",
            programs=[Program(name="PROG_D", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_B", "FLOW_C"],
            dependent_flows=[]
        )
    ]
    
    workpackages = [
        WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id, 
                            priority_score=float(i), preexistent_modules=[])
        for i, flow in enumerate(flows)
    ]
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Expected phases:
    # A: phase 1 (no dependencies)
    # B, C: phase 2 (depend on A)
    # D: phase 3 (depends on B and C)
    
    assert assigner.flow_phases["FLOW_A"] == 1
    assert assigner.flow_phases["FLOW_B"] == 2
    assert assigner.flow_phases["FLOW_C"] == 2
    assert assigner.flow_phases["FLOW_D"] == 3
    
    # Verify all dependencies are in earlier phases
    for flow in flows:
        current_phase = assigner.flow_phases[flow.flow_id]
        
        for dep_flow_id in flow.required_flows:
            dep_phase = assigner.flow_phases[dep_flow_id]
            
            assert dep_phase < current_phase, (
                f"Dependency {dep_flow_id} (phase {dep_phase}) "
                f"is not in earlier phase than {flow.flow_id} (phase {current_phase})"
            )


def test_phase_dependency_order_complex_tree():
    """
    Property 16: Phase Dependency Order Validation (complex tree)
    
    Test with a more complex dependency tree.
    
    **Validates: Requirements 8.6**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_B",
            name="Flow B",
            programs=[Program(name="PROG_B", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_C",
            name="Flow C",
            programs=[Program(name="PROG_C", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A", "FLOW_B"],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_D",
            name="Flow D",
            programs=[Program(name="PROG_D", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_B"],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_E",
            name="Flow E",
            programs=[Program(name="PROG_E", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_C", "FLOW_D"],
            dependent_flows=[]
        )
    ]
    
    workpackages = [
        WorkpackageAssignment(workpackage_id=i+1, flow_id=flow.flow_id,
                            priority_score=float(i), preexistent_modules=[])
        for i, flow in enumerate(flows)
    ]
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Verify all dependencies are in earlier phases
    for flow in flows:
        current_phase = assigner.flow_phases[flow.flow_id]
        
        for dep_flow_id in flow.required_flows:
            dep_phase = assigner.flow_phases[dep_flow_id]
            
            assert dep_phase < current_phase, (
                f"Dependency {dep_flow_id} (phase {dep_phase}) "
                f"is not in earlier phase than {flow.flow_id} (phase {current_phase})"
            )
    
    # Verify specific phase assignments
    # A, B: phase 1 (no dependencies)
    assert assigner.flow_phases["FLOW_A"] == 1
    assert assigner.flow_phases["FLOW_B"] == 1
    
    # C, D: phase 2 (depend on phase 1 flows)
    assert assigner.flow_phases["FLOW_C"] == 2
    assert assigner.flow_phases["FLOW_D"] == 2
    
    # E: phase 3 (depends on phase 2 flows)
    assert assigner.flow_phases["FLOW_E"] == 3


@given(st.integers(min_value=1, max_value=20))
@settings(max_examples=100)
def test_phase_dependency_order_independent_flows(num_flows):
    """
    Property 16: Phase Dependency Order Validation (independent flows)
    
    Independent flows (no dependencies) should all be in phase 1,
    which trivially satisfies the dependency order requirement.
    
    **Validates: Requirements 8.6**
    """
    flows = []
    workpackages = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],  # No dependencies
            dependent_flows=[]
        )
        flows.append(flow)
        
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # All flows should be in phase 1
    for flow in flows:
        assert assigner.flow_phases[flow.flow_id] == 1, (
            f"Independent flow {flow.flow_id} should be in phase 1"
        )
        
        # No dependencies to validate
        assert len(flow.required_flows) == 0
