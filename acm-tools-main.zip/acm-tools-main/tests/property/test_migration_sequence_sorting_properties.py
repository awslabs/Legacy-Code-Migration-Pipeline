"""
Property-based tests for migration sequence sorting.

Feature: migration-workpackage-planner
Property 11: Migration Sequence Sorting
Validates: Requirements 5.5
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings

from tools.migration_planner.models import (
    BusinessFlow,
    Program,
    PriorityResult,
    PriorityFactors,
    WorkpackageAssignment,
    PhaseAssignment,
    MigrationSequenceItem,
    PlanningData,
    Metadata,
    Statistics,
)
from tools.migration_planner.output import OutputGenerator


# Custom strategies
@st.composite
def business_flow_strategy(draw):
    """Generate a random business flow."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    num_programs = draw(st.integers(min_value=1, max_value=10))
    programs = []
    for i in range(num_programs):
        prog_name = f"PROG{i:03d}"
        is_utility = draw(st.booleans())
        programs.append(Program(name=prog_name, is_utility=is_utility))
    
    # Generate databases
    num_dbs = draw(st.integers(min_value=0, max_value=5))
    databases = [f"DB{i}" for i in range(num_dbs)]
    
    total_programs = len(programs)
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0))
    
    return BusinessFlow(
        flow_id=flow_id,
        name=name,
        programs=programs,
        databases=databases,
        total_programs=total_programs,
        composite_score=composite_score,
        required_flows=[],
        dependent_flows=[]
    )


@st.composite
def planning_data_with_sequence_strategy(draw):
    """Generate random planning data with migration sequence."""
    project_name = draw(st.text(min_size=1, max_size=30))
    
    # Generate flows
    num_flows = draw(st.integers(min_value=2, max_value=15))
    flows = [draw(business_flow_strategy()) for _ in range(num_flows)]
    
    # Generate priorities
    priorities = {}
    for flow in flows:
        priority_score = draw(st.floats(min_value=0.0, max_value=100.0))
        factors = PriorityFactors(
            total_programs=flow.total_programs,
            common_modules=draw(st.integers(min_value=0, max_value=5)),
            composite_score=flow.composite_score,
            complete_flow_bonus=draw(st.integers(min_value=-5, max_value=0)),
            simple_flow_bonus=draw(st.integers(min_value=-3, max_value=0))
        )
        priorities[flow.flow_id] = PriorityResult(
            flow_id=flow.flow_id,
            priority_score=priority_score,
            factors=factors
        )
    
    # Generate workpackage assignments
    flow_priorities = {}
    for idx, flow in enumerate(flows, start=1):
        wp = WorkpackageAssignment(
            workpackage_id=idx,
            flow_id=flow.flow_id,
            priority_score=priorities[flow.flow_id].priority_score,
            preexistent_modules=[]
        )
        flow_priorities[flow.flow_id] = wp
    
    # Generate phases
    num_phases = draw(st.integers(min_value=1, max_value=min(5, num_flows)))
    phases = []
    workpackages_per_phase = [[] for _ in range(num_phases)]
    
    for idx, flow in enumerate(flows, start=1):
        phase_idx = idx % num_phases
        workpackages_per_phase[phase_idx].append(idx)
    
    for phase_id in range(1, num_phases + 1):
        phase = PhaseAssignment(
            phase_id=phase_id,
            workpackages=workpackages_per_phase[phase_id - 1],
            dependencies=list(range(1, phase_id))
        )
        phases.append(phase)
    
    # Generate migration sequence with random order initially
    migration_sequence = []
    sequence_numbers = list(range(1, num_flows + 1))
    draw(st.randoms()).shuffle(sequence_numbers)  # Shuffle to test sorting
    
    for seq_num, flow in zip(sequence_numbers, flows):
        item = MigrationSequenceItem(
            sequence_number=seq_num,
            workpackage_id=flows.index(flow) + 1,
            flow_id=flow.flow_id,
            phase=((flows.index(flow) + 1) % num_phases) + 1,
            prerequisites=[]
        )
        migration_sequence.append(item)
    
    # Create metadata and statistics
    metadata = Metadata.create(project_name)
    statistics = Statistics.calculate(flow_priorities, phases)
    
    planning_data = PlanningData(
        metadata=metadata,
        flow_priorities=flow_priorities,
        phases=phases,
        migration_sequence=migration_sequence,
        statistics=statistics
    )
    
    return planning_data, priorities, flows


@settings(max_examples=100, deadline=None)
@given(data=planning_data_with_sequence_strategy())
def test_migration_sequence_sorting(data):
    """
    Property 11: Migration Sequence Sorting
    
    For any migration sequence, items should be sorted by sequenceNumber
    in ascending order in the output JSON.
    
    Validates: Requirements 5.5
    """
    planning_data, priorities, flows = data
    
    # Create temporary output directory
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, planning_data.metadata.project_name)
        
        # Generate planning JSON
        output_path = generator.generate_planning_json(planning_data, priorities, flows)
        
        # Load and parse JSON
        with open(output_path, 'r', encoding='utf-8') as f:
            output = json.load(f)
        
        # Get migration sequence from output
        migration_sequence = output["migrationSequence"]
        
        # Requirement 5.5: Migration sequence should be sorted by sequenceNumber
        assert len(migration_sequence) > 0, "Migration sequence should not be empty"
        
        # Extract sequence numbers
        sequence_numbers = [item["sequenceNumber"] for item in migration_sequence]
        
        # Verify they are in ascending order
        for i in range(len(sequence_numbers) - 1):
            assert sequence_numbers[i] <= sequence_numbers[i + 1], \
                f"Migration sequence must be sorted: {sequence_numbers[i]} should be <= {sequence_numbers[i + 1]}"
        
        # Verify sorted list equals original list (i.e., it's already sorted)
        sorted_sequence_numbers = sorted(sequence_numbers)
        assert sequence_numbers == sorted_sequence_numbers, \
            "Migration sequence must be sorted in ascending order by sequenceNumber"
        
        # Verify all sequence numbers are present and unique
        expected_numbers = list(range(1, len(migration_sequence) + 1))
        assert sorted(sequence_numbers) == expected_numbers, \
            "Migration sequence should contain all sequence numbers from 1 to N"
