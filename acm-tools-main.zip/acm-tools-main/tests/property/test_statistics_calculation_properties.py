"""
Property-based tests for statistics calculation.

Feature: migration-workpackage-planner
Property 12: Statistics Calculation
Validates: Requirements 5.6
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings

from tools.migration_planner.models import (
    BusinessFlow,
    Program,
    PriorityResult,
    PriorityFactors,
    WorkpackageAssignment,
    PhaseAssignment,
    MigrationSequenceItem,
    PlanningData,
    Metadata,
    Statistics,
)
from tools.migration_planner.output import OutputGenerator


# Custom strategies
@st.composite
def business_flow_strategy(draw, flow_id=None):
    """Generate a random business flow."""
    if flow_id is None:
        flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    num_programs = draw(st.integers(min_value=1, max_value=10))
    programs = []
    for i in range(num_programs):
        prog_name = f"PROG{i:03d}"
        is_utility = draw(st.booleans())
        programs.append(Program(name=prog_name, is_utility=is_utility))
    
    # Generate databases
    num_dbs = draw(st.integers(min_value=0, max_value=5))
    databases = [f"DB{i}" for i in range(num_dbs)]
    
    total_programs = len(programs)
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0))
    
    return BusinessFlow(
        flow_id=flow_id,
        name=name,
        programs=programs,
        databases=databases,
        total_programs=total_programs,
        composite_score=composite_score,
        required_flows=[],
        dependent_flows=[]
    )


@st.composite
def planning_data_strategy(draw):
    """Generate random planning data."""
    project_name = draw(st.text(min_size=1, max_size=30))
    
    # Generate flows with unique flow_ids
    num_flows = draw(st.integers(min_value=1, max_value=20))
    flows = []
    for i in range(num_flows):
        flow_id = f"FLOW{i:03d}"
        flow = draw(business_flow_strategy(flow_id=flow_id))
        flows.append(flow)
    
    # Generate priorities
    priorities = {}
    priority_scores = []
    for flow in flows:
        priority_score = draw(st.floats(min_value=0.0, max_value=100.0))
        priority_scores.append(priority_score)
        factors = PriorityFactors(
            total_programs=flow.total_programs,
            common_modules=draw(st.integers(min_value=0, max_value=5)),
            composite_score=flow.composite_score,
            complete_flow_bonus=draw(st.integers(min_value=-5, max_value=0)),
            simple_flow_bonus=draw(st.integers(min_value=-3, max_value=0))
        )
        priorities[flow.flow_id] = PriorityResult(
            flow_id=flow.flow_id,
            priority_score=priority_score,
            factors=factors
        )
    
    # Generate workpackage assignments
    flow_priorities = {}
    for idx, flow in enumerate(flows, start=1):
        wp = WorkpackageAssignment(
            workpackage_id=idx,
            flow_id=flow.flow_id,
            priority_score=priorities[flow.flow_id].priority_score,
            preexistent_modules=[]
        )
        flow_priorities[flow.flow_id] = wp
    
    # Generate phases
    num_phases = draw(st.integers(min_value=1, max_value=min(5, num_flows)))
    phases = []
    workpackages_per_phase = [[] for _ in range(num_phases)]
    
    for idx, flow in enumerate(flows, start=1):
        phase_idx = idx % num_phases
        workpackages_per_phase[phase_idx].append(idx)
    
    for phase_id in range(1, num_phases + 1):
        phase = PhaseAssignment(
            phase_id=phase_id,
            workpackages=workpackages_per_phase[phase_id - 1],
            dependencies=list(range(1, phase_id))
        )
        phases.append(phase)
    
    # Generate migration sequence
    migration_sequence = []
    for seq_num, flow in enumerate(flows, start=1):
        item = MigrationSequenceItem(
            sequence_number=seq_num,
            workpackage_id=seq_num,
            flow_id=flow.flow_id,
            phase=(seq_num % num_phases) + 1,
            prerequisites=[]
        )
        migration_sequence.append(item)
    
    # Create metadata and statistics
    metadata = Metadata.create(project_name)
    statistics = Statistics.calculate(flow_priorities, phases)
    
    planning_data = PlanningData(
        metadata=metadata,
        flow_priorities=flow_priorities,
        phases=phases,
        migration_sequence=migration_sequence,
        statistics=statistics
    )
    
    # Calculate expected statistics
    expected_total_flows = num_flows
    expected_total_phases = num_phases
    expected_avg_priority = sum(priority_scores) / num_flows if num_flows > 0 else 0.0
    expected_flows_per_phase = {}
    for phase in phases:
        expected_flows_per_phase[phase.phase_id] = len(phase.workpackages)
    
    return planning_data, priorities, flows, expected_total_flows, expected_total_phases, expected_avg_priority, expected_flows_per_phase


@settings(max_examples=100, deadline=None)
@given(data=planning_data_strategy())
def test_statistics_calculation(data):
    """
    Property 12: Statistics Calculation
    
    For any set of flows and phases, calculated statistics (totalFlows,
    totalPhases, averagePriorityScore) should match the actual data.
    
    Validates: Requirements 5.6
    """
    planning_data, priorities, flows, expected_total_flows, expected_total_phases, expected_avg_priority, expected_flows_per_phase = data
    
    # Create temporary output directory
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, planning_data.metadata.project_name)
        
        # Generate planning JSON
        output_path = generator.generate_planning_json(planning_data, priorities, flows)
        
        # Load and parse JSON
        with open(output_path, 'r', encoding='utf-8') as f:
            output = json.load(f)
        
        # Get statistics from output
        statistics = output["statistics"]
        
        # Requirement 5.6: Statistics should match actual data
        
        # Verify totalFlows
        assert "totalFlows" in statistics, "Statistics must contain totalFlows"
        assert statistics["totalFlows"] == expected_total_flows, \
            f"totalFlows should be {expected_total_flows}, got {statistics['totalFlows']}"
        
        # Verify totalPhases
        assert "totalPhases" in statistics, "Statistics must contain totalPhases"
        assert statistics["totalPhases"] == expected_total_phases, \
            f"totalPhases should be {expected_total_phases}, got {statistics['totalPhases']}"
        
        # Verify averagePriorityScore
        assert "averagePriorityScore" in statistics, "Statistics must contain averagePriorityScore"
        # Allow small floating point differences
        assert abs(statistics["averagePriorityScore"] - expected_avg_priority) < 0.01, \
            f"averagePriorityScore should be approximately {expected_avg_priority}, got {statistics['averagePriorityScore']}"
        
        # Verify flowsPerPhase
        assert "flowsPerPhase" in statistics, "Statistics must contain flowsPerPhase"
        flows_per_phase = statistics["flowsPerPhase"]
        
        # Convert keys to integers for comparison (JSON keys are strings)
        flows_per_phase_int = {int(k): v for k, v in flows_per_phase.items()}
        
        assert flows_per_phase_int == expected_flows_per_phase, \
            f"flowsPerPhase should be {expected_flows_per_phase}, got {flows_per_phase_int}"
        
        # Verify sum of flows per phase equals total flows
        total_flows_from_phases = sum(flows_per_phase_int.values())
        assert total_flows_from_phases == expected_total_flows, \
            f"Sum of flows per phase ({total_flows_from_phases}) should equal totalFlows ({expected_total_flows})"
