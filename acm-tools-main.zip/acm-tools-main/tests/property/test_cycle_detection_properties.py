"""
Property-based tests for dependency graph cycle detection.

Feature: migration-workpackage-planner
Property 6: Dependency Graph Cycle Detection
Validates: Requirements 3.3, 3.4, 8.3, 8.4, 8.5
"""

import pytest
from hypothesis import given, strategies as st, settings, assume
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.phase.phase_assigner import PhaseAssigner, ValidationError


# Custom strategies for generating test data
@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def dag_flows_strategy(draw):
    """Generate a list of flows that form a valid DAG (no cycles)."""
    # Generate 1 to 15 flows
    num_flows = draw(st.integers(min_value=1, max_value=15))
    flows = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        name = f"Flow {i}"
        
        # Generate programs (1 to 5 programs)
        num_programs = draw(st.integers(min_value=1, max_value=5))
        programs = [draw(program_strategy()) for _ in range(num_programs)]
        
        # Dependencies: can only depend on flows created before this one (DAG property)
        max_deps = min(i, 3)
        num_deps = draw(st.integers(min_value=0, max_value=max_deps))
        
        if num_deps > 0:
            dep_indices = draw(st.lists(
                st.integers(min_value=0, max_value=i-1),
                min_size=num_deps,
                max_size=num_deps,
                unique=True
            ))
            required_flows = [f"FLOW_{idx:03d}" for idx in dep_indices]
        else:
            required_flows = []
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=name,
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
    
    return flows


@st.composite
def cyclic_flows_strategy(draw):
    """Generate a list of flows that contain at least one cycle."""
    # Generate 2 to 10 flows
    num_flows = draw(st.integers(min_value=2, max_value=10))
    flows = []
    
    # First create flows without dependencies
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        name = f"Flow {i}"
        
        num_programs = draw(st.integers(min_value=1, max_value=5))
        programs = [draw(program_strategy()) for _ in range(num_programs)]
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=name,
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
    
    # Now add a cycle
    # Choose cycle type: simple (A -> B -> A) or complex
    cycle_type = draw(st.sampled_from(['simple', 'complex']))
    
    if cycle_type == 'simple' and num_flows >= 2:
        # Create simple cycle: FLOW_0 -> FLOW_1 -> FLOW_0
        flows[0].required_flows = [flows[1].flow_id]
        flows[1].required_flows = [flows[0].flow_id]
    else:
        # Create a longer cycle
        cycle_length = draw(st.integers(min_value=2, max_value=min(num_flows, 5)))
        
        # Select flows to form the cycle
        cycle_indices = draw(st.lists(
            st.integers(min_value=0, max_value=num_flows-1),
            min_size=cycle_length,
            max_size=cycle_length,
            unique=True
        ))
        
        # Create cycle: flow[i] depends on flow[i+1], last depends on first
        for i in range(len(cycle_indices)):
            current_idx = cycle_indices[i]
            next_idx = cycle_indices[(i + 1) % len(cycle_indices)]
            flows[current_idx].required_flows = [flows[next_idx].flow_id]
    
    return flows


@given(dag_flows_strategy())
@settings(max_examples=100, deadline=None)
def test_dag_validation_accepts_valid_graphs(flows):
    """
    Property 6: Dependency Graph Cycle Detection (valid DAGs)
    
    For any valid DAG (no cycles), the validator should accept the graph
    and not raise any errors.
    
    **Validates: Requirements 3.3, 8.3, 8.5**
    """
    assigner = PhaseAssigner()
    
    # Should not raise any exception
    try:
        assigner.validate_dag(flows)
        cycles = assigner.detect_cycles(flows)
        
        # Should detect no cycles
        assert len(cycles) == 0, (
            f"Valid DAG incorrectly detected as having cycles: {cycles}"
        )
    except ValidationError as e:
        pytest.fail(f"Valid DAG rejected by validator: {e}")


@given(cyclic_flows_strategy())
@settings(max_examples=100, deadline=None)
def test_dag_validation_rejects_cyclic_graphs(flows):
    """
    Property 6: Dependency Graph Cycle Detection (cyclic graphs)
    
    For any graph containing cycles, the validator should:
    1. Detect the cycles
    2. Raise a ValidationError
    3. Report the complete cycle path
    
    **Validates: Requirements 3.3, 3.4, 8.3, 8.4, 8.5**
    """
    assigner = PhaseAssigner()
    
    # Should detect cycles
    cycles = assigner.detect_cycles(flows)
    
    # Property 1: At least one cycle should be detected
    assert len(cycles) > 0, (
        f"Cyclic graph not detected as having cycles"
    )
    
    # Property 2: Each detected cycle should be valid
    for cycle in cycles:
        # Cycle should have at least 2 nodes
        assert len(cycle) >= 2, (
            f"Invalid cycle detected with less than 2 nodes: {cycle}"
        )
        
        # First and last nodes should be the same (cycle property)
        assert cycle[0] == cycle[-1], (
            f"Cycle does not start and end with same node: {cycle}"
        )
        
        # Verify the cycle path is valid
        flow_map = {flow.flow_id: flow for flow in flows}
        for i in range(len(cycle) - 1):
            current_flow_id = cycle[i]
            next_flow_id = cycle[i + 1]
            
            # Current flow should depend on next flow
            current_flow = flow_map.get(current_flow_id)
            if current_flow:
                assert next_flow_id in current_flow.required_flows, (
                    f"Invalid cycle path: {current_flow_id} does not depend on {next_flow_id}"
                )
    
    # Property 3: validate_dag should raise ValidationError
    with pytest.raises(ValidationError) as exc_info:
        assigner.validate_dag(flows)
    
    # Property 4: Error message should contain cycle information
    error_message = str(exc_info.value)
    assert "Circular dependencies detected" in error_message, (
        f"Error message does not mention circular dependencies: {error_message}"
    )


def test_simple_cycle_detection():
    """
    Property 6: Dependency Graph Cycle Detection (simple cycle)
    
    Test detection of a simple 2-node cycle: A -> B -> A
    
    **Validates: Requirements 3.3, 3.4, 8.4**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_B"],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_B",
            name="Flow B",
            programs=[Program(name="PROG_B", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A"],
            dependent_flows=[]
        )
    ]
    
    assigner = PhaseAssigner()
    cycles = assigner.detect_cycles(flows)
    
    # Should detect exactly one cycle
    assert len(cycles) >= 1, "Simple cycle not detected"
    
    # Cycle should contain both flows
    cycle = cycles[0]
    assert "FLOW_A" in cycle and "FLOW_B" in cycle, (
        f"Cycle does not contain both flows: {cycle}"
    )
    
    # validate_dag should raise error
    with pytest.raises(ValidationError) as exc_info:
        assigner.validate_dag(flows)
    
    error_message = str(exc_info.value)
    assert "FLOW_A" in error_message and "FLOW_B" in error_message, (
        f"Error message does not mention both flows in cycle: {error_message}"
    )


def test_three_node_cycle_detection():
    """
    Property 6: Dependency Graph Cycle Detection (3-node cycle)
    
    Test detection of a 3-node cycle: A -> B -> C -> A
    
    **Validates: Requirements 3.3, 3.4, 8.4**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_B"],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_B",
            name="Flow B",
            programs=[Program(name="PROG_B", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_C"],
            dependent_flows=[]
        ),
        BusinessFlow(
            flow_id="FLOW_C",
            name="Flow C",
            programs=[Program(name="PROG_C", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A"],
            dependent_flows=[]
        )
    ]
    
    assigner = PhaseAssigner()
    cycles = assigner.detect_cycles(flows)
    
    # Should detect at least one cycle
    assert len(cycles) >= 1, "3-node cycle not detected"
    
    # Cycle should contain all three flows
    cycle = cycles[0]
    assert all(flow_id in cycle for flow_id in ["FLOW_A", "FLOW_B", "FLOW_C"]), (
        f"Cycle does not contain all three flows: {cycle}"
    )


def test_self_referencing_cycle():
    """
    Property 6: Dependency Graph Cycle Detection (self-reference)
    
    Test detection of a self-referencing flow: A -> A
    
    **Validates: Requirements 3.3, 3.4, 8.4**
    """
    flows = [
        BusinessFlow(
            flow_id="FLOW_A",
            name="Flow A",
            programs=[Program(name="PROG_A", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=["FLOW_A"],  # Self-reference
            dependent_flows=[]
        )
    ]
    
    assigner = PhaseAssigner()
    cycles = assigner.detect_cycles(flows)
    
    # Should detect the self-reference as a cycle
    assert len(cycles) >= 1, "Self-referencing cycle not detected"
    
    # validate_dag should raise error
    with pytest.raises(ValidationError):
        assigner.validate_dag(flows)


@given(st.integers(min_value=1, max_value=20))
@settings(max_examples=100)
def test_independent_flows_have_no_cycles(num_flows):
    """
    Property 6: Dependency Graph Cycle Detection (independent flows)
    
    Flows with no dependencies should never form cycles.
    
    **Validates: Requirements 3.3, 8.3**
    """
    flows = []
    
    for i in range(num_flows):
        flow = BusinessFlow(
            flow_id=f"FLOW_{i:03d}",
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],  # No dependencies
            dependent_flows=[]
        )
        flows.append(flow)
    
    assigner = PhaseAssigner()
    
    # Should not detect any cycles
    cycles = assigner.detect_cycles(flows)
    assert len(cycles) == 0, (
        f"Independent flows incorrectly detected as having cycles: {cycles}"
    )
    
    # validate_dag should not raise error
    try:
        assigner.validate_dag(flows)
    except ValidationError as e:
        pytest.fail(f"Independent flows rejected by validator: {e}")
