"""
Property-based tests for ValidationEngine.

Tests universal properties that should hold for all validation operations.
"""

import tempfile
import json
import csv
from pathlib import Path
from hypothesis import given, strategies as st, settings, assume
from tools.atx.dependency_transformer.orchestration import ValidationEngine


# Strategy for generating valid ATX dependency entries
@st.composite
def valid_dependency_entry(draw):
    """Generate a valid ATX dependency entry."""
    name = draw(st.text(min_size=1, max_size=50, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    path = draw(st.text(min_size=1, max_size=100, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'Ps'))))
    dep_type = draw(st.sampled_from(["COB", "JCL", "TRANSACTION", "CICS_FILE", "COPYBOOK"]))
    dependencies = draw(st.lists(st.dictionaries(
        st.text(min_size=1, max_size=20),
        st.text(min_size=1, max_size=50),
        min_size=1,
        max_size=3
    ), min_size=0, max_size=5))
    
    return {
        "name": name,
        "path": path,
        "type": dep_type,
        "dependencies": dependencies
    }


# Strategy for generating valid ATX asset entries
@st.composite
def valid_asset_entry(draw):
    """Generate a valid ATX asset entry."""
    name = draw(st.text(min_size=1, max_size=50, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    path = draw(st.text(min_size=1, max_size=100, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'Ps'))))
    file_type = draw(st.sampled_from(["COB", "JCL", "CPY", "PLI"]))
    cc = draw(st.integers(min_value=0, max_value=1000))
    total_lines = draw(st.integers(min_value=0, max_value=10000))
    empty_lines = draw(st.integers(min_value=0, max_value=total_lines))
    effective_lines = draw(st.integers(min_value=0, max_value=total_lines - empty_lines))
    comment_lines = draw(st.integers(min_value=0, max_value=total_lines - empty_lines - effective_lines))
    
    return {
        "Name": name,
        "Path": path,
        "File type": file_type,
        "Cyclomatic Complexity": str(cc),
        "Total lines": str(total_lines),
        "Empty Lines": str(empty_lines),
        "Effective Lines": str(effective_lines),
        "Comment Lines": str(comment_lines)
    }


# Strategy for generating valid data operation entries
@st.composite
def valid_data_operation_entry(draw):
    """Generate a valid data operation entry."""
    file_name = draw(st.text(min_size=1, max_size=50, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    file_path = draw(st.text(min_size=1, max_size=100, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'Ps'))))
    dsn = draw(st.text(min_size=1, max_size=50, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    access_type = draw(st.sampled_from(["READ", "WRITE", "UPDATE", "READ; WRITE", "READ; UPDATE"]))
    
    return {
        "fileName": file_name,
        "filePath": file_path,
        "dataSourceName": dsn,
        "ddName": "DDNAME",
        "logicalName": "LOGICAL",
        "copybookRecordName": "RECORD",
        "copybookFilePath": "./path/to/copybook.cpy",
        "dataSourceType": "VSAM KSDS",
        "accessType": access_type
    }


@given(
    dependencies=st.lists(valid_dependency_entry(), min_size=1, max_size=10),
    assets=st.lists(valid_asset_entry(), min_size=1, max_size=10),
    data_ops=st.lists(valid_data_operation_entry(), min_size=1, max_size=10)
)
@settings(max_examples=100, deadline=None)
def test_property_20_input_validation_completeness(dependencies, assets, data_ops):
    """
    Feature: atx-dependency-transformer, Property 20: Input Validation Completeness
    
    For any input directory, validation should fail if required files (dependencies.json,
    assets.csv, program_to_dsn.json) are missing or unreadable, and should succeed if all
    files are present and valid.
    
    Validates: Requirements AC-4.4, AC-4.5
    """
    engine = ValidationEngine()
    
    # Create a temporary directory with all required files
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Write dependencies.json
        deps_file = temp_path / "dependencies.json"
        with open(deps_file, 'w', encoding='utf-8') as f:
            json.dump(dependencies, f)
        
        # Write assets.csv
        assets_file = temp_path / "assets.csv"
        with open(assets_file, 'w', encoding='utf-8', newline='') as f:
            if assets:
                writer = csv.DictWriter(f, fieldnames=assets[0].keys())
                writer.writeheader()
                writer.writerows(assets)
        
        # Write program_to_dsn.json
        data_ops_file = temp_path / "program_to_dsn.json"
        with open(data_ops_file, 'w', encoding='utf-8') as f:
            json.dump(data_ops, f)
        
        # Property 1: Validation should succeed when all files are present and valid
        result = engine.validate_input_directory(str(temp_path))
        assert result.valid is True, \
            f"Validation should succeed with all valid files present. Errors: {result.errors}"
        assert not result.has_fatal_errors(), \
            "Validation should not have fatal errors with valid files"
        
        # Property 2: Validation should fail when dependencies.json is missing
        deps_file.unlink()
        result_missing_deps = engine.validate_input_directory(str(temp_path))
        assert result_missing_deps.valid is False, \
            "Validation should fail when dependencies.json is missing"
        assert result_missing_deps.has_fatal_errors(), \
            "Missing dependencies.json should be a fatal error"
        assert any("dependencies.json" in str(error).lower() for error in result_missing_deps.errors), \
            "Error message should mention dependencies.json"
        
        # Restore dependencies.json
        with open(deps_file, 'w', encoding='utf-8') as f:
            json.dump(dependencies, f)
        
        # Property 3: Validation should fail when assets.csv is missing
        assets_file.unlink()
        result_missing_assets = engine.validate_input_directory(str(temp_path))
        assert result_missing_assets.valid is False, \
            "Validation should fail when assets.csv is missing"
        assert result_missing_assets.has_fatal_errors(), \
            "Missing assets.csv should be a fatal error"
        assert any("assets.csv" in str(error).lower() for error in result_missing_assets.errors), \
            "Error message should mention assets.csv"
        
        # Restore assets.csv
        with open(assets_file, 'w', encoding='utf-8', newline='') as f:
            if assets:
                writer = csv.DictWriter(f, fieldnames=assets[0].keys())
                writer.writeheader()
                writer.writerows(assets)
        
        # Property 4: Validation should fail when program_to_dsn.json is missing
        data_ops_file.unlink()
        result_missing_data_ops = engine.validate_input_directory(str(temp_path))
        assert result_missing_data_ops.valid is False, \
            "Validation should fail when program_to_dsn.json is missing"
        assert result_missing_data_ops.has_fatal_errors(), \
            "Missing program_to_dsn.json should be a fatal error"
        assert any("program_to_dsn.json" in str(error).lower() for error in result_missing_data_ops.errors), \
            "Error message should mention program_to_dsn.json"


@given(
    dependencies=st.lists(valid_dependency_entry(), min_size=1, max_size=10)
)
@settings(max_examples=100, deadline=None)
def test_property_20_json_format_validation(dependencies):
    """
    Feature: atx-dependency-transformer, Property 20: Input Validation Completeness (JSON Format)
    
    For any JSON file, validation should detect and report invalid JSON format with
    appropriate error messages including line and column numbers.
    
    Validates: Requirements AC-4.5
    """
    engine = ValidationEngine()
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create valid files first
        deps_file = temp_path / "dependencies.json"
        with open(deps_file, 'w', encoding='utf-8') as f:
            json.dump(dependencies, f)
        
        assets_file = temp_path / "assets.csv"
        with open(assets_file, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=[
                "Name", "Path", "File type", "Cyclomatic Complexity",
                "Total lines", "Empty Lines", "Effective Lines", "Comment Lines"
            ])
            writer.writeheader()
            writer.writerow({
                "Name": "TEST", "Path": "./test", "File type": "COB",
                "Cyclomatic Complexity": "0", "Total lines": "100",
                "Empty Lines": "10", "Effective Lines": "80", "Comment Lines": "10"
            })
        
        data_ops_file = temp_path / "program_to_dsn.json"
        with open(data_ops_file, 'w', encoding='utf-8') as f:
            json.dump([{
                "fileName": "TEST.cbl",
                "filePath": "./test.cbl",
                "dataSourceName": "DSN",
                "accessType": "READ"
            }], f)
        
        # Property 1: Valid JSON should pass validation
        result_valid = engine.validate_input_directory(str(temp_path))
        assert result_valid.valid is True, \
            "Valid JSON files should pass validation"
        
        # Property 2: Invalid JSON should be detected
        with open(deps_file, 'w', encoding='utf-8') as f:
            f.write('{"invalid": "json" missing bracket')
        
        result_invalid = engine.validate_input_directory(str(temp_path))
        assert result_invalid.valid is False, \
            "Invalid JSON should fail validation"
        assert result_invalid.has_fatal_errors(), \
            "Invalid JSON should be a fatal error"
        assert any("json" in str(error).lower() for error in result_invalid.errors), \
            "Error message should mention JSON format issue"


@given(
    assets=st.lists(valid_asset_entry(), min_size=1, max_size=10)
)
@settings(max_examples=100, deadline=None)
def test_property_20_csv_format_validation(assets):
    """
    Feature: atx-dependency-transformer, Property 20: Input Validation Completeness (CSV Format)
    
    For any CSV file, validation should detect missing required columns and report
    appropriate error messages.
    
    Validates: Requirements AC-4.5
    """
    engine = ValidationEngine()
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create valid files first
        deps_file = temp_path / "dependencies.json"
        with open(deps_file, 'w', encoding='utf-8') as f:
            json.dump([{
                "name": "TEST",
                "path": "./test",
                "type": "COB",
                "dependencies": []
            }], f)
        
        assets_file = temp_path / "assets.csv"
        with open(assets_file, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=assets[0].keys())
            writer.writeheader()
            writer.writerows(assets)
        
        data_ops_file = temp_path / "program_to_dsn.json"
        with open(data_ops_file, 'w', encoding='utf-8') as f:
            json.dump([{
                "fileName": "TEST.cbl",
                "filePath": "./test.cbl",
                "dataSourceName": "DSN",
                "accessType": "READ"
            }], f)
        
        # Property 1: Valid CSV should pass validation
        result_valid = engine.validate_input_directory(str(temp_path))
        assert result_valid.valid is True, \
            "Valid CSV file should pass validation"
        
        # Property 2: CSV with missing required columns should fail
        with open(assets_file, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=["Name", "Path"])  # Missing required columns
            writer.writeheader()
            writer.writerow({"Name": "TEST", "Path": "./test"})
        
        result_invalid = engine.validate_input_directory(str(temp_path))
        assert result_invalid.valid is False, \
            "CSV with missing required columns should fail validation"
        assert result_invalid.has_fatal_errors(), \
            "Missing required columns should be a fatal error"
        assert any("column" in str(error).lower() or "field" in str(error).lower() 
                   for error in result_invalid.errors), \
            "Error message should mention missing columns"


@given(
    directory_exists=st.booleans()
)
@settings(max_examples=100, deadline=None)
def test_property_20_directory_validation(directory_exists):
    """
    Feature: atx-dependency-transformer, Property 20: Input Validation Completeness (Directory)
    
    For any input path, validation should detect if the directory exists and is accessible.
    
    Validates: Requirements AC-4.4
    """
    engine = ValidationEngine()
    
    if directory_exists:
        # Test with existing directory
        with tempfile.TemporaryDirectory() as temp_dir:
            # Directory exists but has no files
            result = engine.validate_input_directory(temp_dir)
            
            # Property: Should fail due to missing files, not missing directory
            assert result.valid is False, \
                "Validation should fail when required files are missing"
            assert any("file" in str(error).lower() for error in result.errors), \
                "Errors should be about missing files, not missing directory"
            assert not any("directory" in str(error).lower() and "not exist" in str(error).lower() 
                          for error in result.errors), \
                "Should not report directory as non-existent when it exists"
    else:
        # Test with non-existent directory
        non_existent = "/tmp/nonexistent_directory_12345678"
        result = engine.validate_input_directory(non_existent)
        
        # Property: Should fail due to missing directory
        assert result.valid is False, \
            "Validation should fail when directory doesn't exist"
        assert result.has_fatal_errors(), \
            "Missing directory should be a fatal error"
        assert any("directory" in str(error).lower() for error in result.errors), \
            "Error message should mention directory"


@given(
    file_path=st.text(min_size=1, max_size=100, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd', 'Ps')))
)
@settings(max_examples=100, deadline=None)
def test_property_20_file_existence_validation(file_path):
    """
    Feature: atx-dependency-transformer, Property 20: Input Validation Completeness (File Existence)
    
    For any file path, validation should correctly detect whether the file exists and is readable.
    
    Validates: Requirements AC-4.4
    """
    engine = ValidationEngine()
    
    # Assume the file path doesn't exist (very unlikely to collide with real files)
    assume(not Path(file_path).exists())
    
    # Property 1: Non-existent file should fail validation
    result = engine.validate_file_exists(file_path)
    assert result.valid is False, \
        f"Validation should fail for non-existent file: {file_path}"
    assert result.has_fatal_errors(), \
        "Non-existent file should be a fatal error"
    
    # Property 2: Existing file should pass validation
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write("test content")
        temp_file = f.name
    
    try:
        result_exists = engine.validate_file_exists(temp_file)
        assert result_exists.valid is True, \
            f"Validation should succeed for existing file: {temp_file}"
        assert not result_exists.has_fatal_errors(), \
            "Existing readable file should not have fatal errors"
    finally:
        Path(temp_file).unlink()


@given(
    entry_count=st.integers(min_value=0, max_value=20)
)
@settings(max_examples=100, deadline=None)
def test_property_20_empty_file_handling(entry_count):
    """
    Feature: atx-dependency-transformer, Property 20: Input Validation Completeness (Empty Files)
    
    For any valid JSON/CSV file, validation should handle empty files (no entries) with
    appropriate warnings but not fatal errors.
    
    Validates: Requirements AC-4.5
    """
    engine = ValidationEngine()
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create files with specified entry count
        deps_file = temp_path / "dependencies.json"
        deps_data = [{"name": f"PROG{i}", "path": f"./prog{i}", "type": "COB", "dependencies": []} 
                     for i in range(entry_count)]
        with open(deps_file, 'w', encoding='utf-8') as f:
            json.dump(deps_data, f)
        
        assets_file = temp_path / "assets.csv"
        with open(assets_file, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=[
                "Name", "Path", "File type", "Cyclomatic Complexity",
                "Total lines", "Empty Lines", "Effective Lines", "Comment Lines"
            ])
            writer.writeheader()
            for i in range(entry_count):
                writer.writerow({
                    "Name": f"PROG{i}", "Path": f"./prog{i}", "File type": "COB",
                    "Cyclomatic Complexity": "0", "Total lines": "100",
                    "Empty Lines": "10", "Effective Lines": "80", "Comment Lines": "10"
                })
        
        data_ops_file = temp_path / "program_to_dsn.json"
        data_ops_data = [{"fileName": f"PROG{i}.cbl", "filePath": f"./prog{i}.cbl", 
                         "dataSourceName": f"DSN{i}", "accessType": "READ"} 
                        for i in range(entry_count)]
        with open(data_ops_file, 'w', encoding='utf-8') as f:
            json.dump(data_ops_data, f)
        
        result = engine.validate_input_directory(str(temp_path))
        
        if entry_count == 0:
            # Property: Empty files should generate warnings but not fatal errors
            assert not result.has_fatal_errors(), \
                "Empty files should not generate fatal errors"
            # Note: Warnings about empty files are acceptable but not required
        else:
            # Property: Non-empty valid files should pass validation
            assert result.valid is True, \
                f"Validation should succeed with {entry_count} valid entries"
