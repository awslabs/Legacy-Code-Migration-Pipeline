"""
Property-based tests for priority factors breakdown.

Feature: migration-workpackage-planner
Property 2: Priority Factors Breakdown
Validates: Requirements 1.11
"""

import pytest
from hypothesis import given, strategies as st, settings
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.priority.priority_calculator import PriorityCalculator


@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    # Use UUID-like names to ensure uniqueness
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def business_flow_strategy(draw):
    """Generate a random BusinessFlow with valid complexity metrics."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs (0 to 20 programs)
    num_programs = draw(st.integers(min_value=0, max_value=20))
    programs = [draw(program_strategy()) for _ in range(num_programs)]
    
    # Generate databases (0 to 10 databases)
    num_databases = draw(st.integers(min_value=0, max_value=10))
    databases = [f"DB{i}" for i in range(num_databases)]
    
    # Total programs matches actual program count
    total_programs = len(programs)
    
    # Composite score (0.0 to 100.0)
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False))
    
    # Dependencies
    required_flows = draw(st.lists(st.text(min_size=1, max_size=10), max_size=5))
    dependent_flows = draw(st.lists(st.text(min_size=1, max_size=10), max_size=5))
    
    return BusinessFlow(
        flow_id=flow_id,
        name=name,
        programs=programs,
        databases=databases,
        total_programs=total_programs,
        composite_score=composite_score,
        required_flows=required_flows,
        dependent_flows=dependent_flows
    )


@given(business_flow_strategy())
@settings(max_examples=100)
def test_priority_factors_breakdown_stored(flow):
    """
    Property 2: Priority Factors Breakdown
    
    For any business flow, the priority calculation should store all factor values
    (totalPrograms, commonModules, compositeScore, completeFlowBonus, simpleFlowBonus)
    in the output.
    
    **Validates: Requirements 1.11**
    """
    # Initialize calculator with no classifications
    calculator = PriorityCalculator(classifications={})
    
    # Calculate priority
    result = calculator.calculate_priority(flow)
    
    # Verify that result has factors attribute
    assert hasattr(result, 'factors'), "PriorityResult should have 'factors' attribute"
    
    # Verify all factor fields are present
    factors = result.factors
    assert hasattr(factors, 'total_programs'), "PriorityFactors should have 'total_programs' field"
    assert hasattr(factors, 'common_modules'), "PriorityFactors should have 'common_modules' field"
    assert hasattr(factors, 'composite_score'), "PriorityFactors should have 'composite_score' field"
    assert hasattr(factors, 'complete_flow_bonus'), "PriorityFactors should have 'complete_flow_bonus' field"
    assert hasattr(factors, 'simple_flow_bonus'), "PriorityFactors should have 'simple_flow_bonus' field"
    
    # Verify factor values match flow characteristics
    assert factors.total_programs == flow.total_programs, (
        f"total_programs factor should match flow.total_programs: "
        f"expected {flow.total_programs}, got {factors.total_programs}"
    )
    
    assert abs(factors.composite_score - flow.composite_score) < 0.001, (
        f"composite_score factor should match flow.composite_score: "
        f"expected {flow.composite_score}, got {factors.composite_score}"
    )
    
    # Verify complete_flow_bonus is correct
    expected_complete_bonus = -5 if len(flow.databases) > 0 else 0
    assert factors.complete_flow_bonus == expected_complete_bonus, (
        f"complete_flow_bonus should be {expected_complete_bonus} for "
        f"{len(flow.databases)} databases, got {factors.complete_flow_bonus}"
    )
    
    # Verify simple_flow_bonus is correct
    if flow.total_programs <= 3:
        expected_simple_bonus = -3
    elif flow.total_programs <= 5:
        expected_simple_bonus = -1
    else:
        expected_simple_bonus = 0
    
    assert factors.simple_flow_bonus == expected_simple_bonus, (
        f"simple_flow_bonus should be {expected_simple_bonus} for "
        f"{flow.total_programs} programs, got {factors.simple_flow_bonus}"
    )
    
    # Verify common_modules is 0 when no classifications provided
    assert factors.common_modules == 0, (
        f"common_modules should be 0 when no classifications provided, "
        f"got {factors.common_modules}"
    )


@given(business_flow_strategy())
@settings(max_examples=100)
def test_priority_factors_breakdown_with_classifications(flow):
    """
    Property 2: Priority Factors Breakdown (with classifications)
    
    For any business flow with module classifications, the priority calculation
    should store the correct common_modules count in the factors breakdown.
    
    **Validates: Requirements 1.11**
    """
    # Create deterministic classifications for this flow's programs
    classifications = {}
    expected_common_count = 0
    
    for i, program in enumerate(flow.programs):
        # Deterministically assign COMMONLY_USED to every 3rd program
        if i % 3 == 0:
            classifications[program.name] = "COMMONLY_USED"
            expected_common_count += 1
        else:
            classifications[program.name] = "UTILITY"
    
    # Initialize calculator with classifications
    calculator = PriorityCalculator(classifications=classifications)
    
    # Calculate priority
    result = calculator.calculate_priority(flow)
    
    # Verify common_modules count is correct
    assert result.factors.common_modules == expected_common_count, (
        f"common_modules should be {expected_common_count}, "
        f"got {result.factors.common_modules}"
    )
    
    # Verify all other factors are still present and correct
    assert result.factors.total_programs == flow.total_programs
    assert abs(result.factors.composite_score - flow.composite_score) < 0.001
    
    expected_complete_bonus = -5 if len(flow.databases) > 0 else 0
    assert result.factors.complete_flow_bonus == expected_complete_bonus
    
    if flow.total_programs <= 3:
        expected_simple_bonus = -3
    elif flow.total_programs <= 5:
        expected_simple_bonus = -1
    else:
        expected_simple_bonus = 0
    assert result.factors.simple_flow_bonus == expected_simple_bonus


@given(business_flow_strategy())
@settings(max_examples=100)
def test_priority_factors_used_in_score_calculation(flow):
    """
    Property 2: Priority Factors Used in Score Calculation
    
    For any business flow, the priority score should be calculable from the
    stored factors using the formula.
    
    **Validates: Requirements 1.11**
    """
    # Initialize calculator
    calculator = PriorityCalculator(classifications={})
    
    # Calculate priority
    result = calculator.calculate_priority(flow)
    
    # Recalculate score from stored factors
    factors = result.factors
    recalculated_score = (
        (factors.total_programs * 2) +
        (factors.common_modules * 3) +
        (factors.composite_score * 0.5) +
        factors.complete_flow_bonus +
        factors.simple_flow_bonus
    )
    
    # Verify the stored score matches the recalculated score
    assert abs(result.priority_score - recalculated_score) < 0.001, (
        f"Priority score should be calculable from factors: "
        f"stored score={result.priority_score}, "
        f"recalculated score={recalculated_score}, "
        f"factors={factors}"
    )
