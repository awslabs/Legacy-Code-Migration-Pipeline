"""
Property-based tests for phase assignment correctness.

Feature: migration-workpackage-planner
Property 5: Phase Assignment Correctness
Validates: Requirements 3.1, 3.2
"""

import pytest
from hypothesis import given, strategies as st, settings, assume
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.models.workpackage import WorkpackageAssignment
from tools.migration_planner.phase.phase_assigner import PhaseAssigner


# Custom strategies for generating test data
@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def dag_flows_strategy(draw):
    """Generate a list of flows that form a valid DAG."""
    # Generate 1 to 15 flows
    num_flows = draw(st.integers(min_value=1, max_value=15))
    flows = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        name = f"Flow {i}"
        
        # Generate programs (1 to 10 programs)
        num_programs = draw(st.integers(min_value=1, max_value=10))
        programs = [draw(program_strategy()) for _ in range(num_programs)]
        
        # Generate databases (0 to 3 databases)
        num_databases = draw(st.integers(min_value=0, max_value=3))
        databases = [f"DB{j}" for j in range(num_databases)]
        
        composite_score = draw(st.floats(
            min_value=0.0,
            max_value=100.0,
            allow_nan=False,
            allow_infinity=False
        ))
        
        # Dependencies: can only depend on flows created before this one (DAG property)
        # Randomly select 0 to min(i, 3) dependencies
        max_deps = min(i, 3)
        num_deps = draw(st.integers(min_value=0, max_value=max_deps))
        
        if num_deps > 0:
            # Select random flows from those already created
            dep_indices = draw(st.lists(
                st.integers(min_value=0, max_value=i-1),
                min_size=num_deps,
                max_size=num_deps,
                unique=True
            ))
            required_flows = [f"FLOW_{idx:03d}" for idx in dep_indices]
        else:
            required_flows = []
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=name,
            programs=programs,
            databases=databases,
            total_programs=len(programs),
            composite_score=composite_score,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
    
    return flows


@st.composite
def workpackages_from_flows_strategy(draw, flows):
    """Generate workpackage assignments from flows."""
    workpackages = []
    
    for i, flow in enumerate(flows):
        # Generate a priority score
        priority_score = draw(st.floats(
            min_value=-20.0,
            max_value=200.0,
            allow_nan=False,
            allow_infinity=False
        ))
        
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow.flow_id,
            priority_score=priority_score,
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    return workpackages


@given(dag_flows_strategy())
@settings(max_examples=100, deadline=None)
def test_phase_assignment_correctness(flows):
    """
    Property 5: Phase Assignment Correctness
    
    For any valid dependency graph (DAG):
    1. Flows with no dependencies should be in phase 1
    2. All other flows should be in the minimum phase where all their
       dependencies are in earlier phases
    
    **Validates: Requirements 3.1, 3.2**
    """
    # Generate workpackages
    workpackages = []
    for i, flow in enumerate(flows):
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow.flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Build flow_id to phase mapping
    flow_phases = assigner.flow_phases
    
    # Property 1: Flows with no dependencies should be in phase 1
    for flow in flows:
        if not flow.required_flows:
            assert flow_phases[flow.flow_id] == 1, (
                f"Flow {flow.flow_id} has no dependencies but is not in phase 1 "
                f"(phase={flow_phases[flow.flow_id]})"
            )
    
    # Property 2: All flows should be in minimum phase where dependencies are satisfied
    for flow in flows:
        if flow.required_flows:
            # Find maximum phase of all dependencies
            max_dep_phase = max(
                flow_phases[dep_flow_id]
                for dep_flow_id in flow.required_flows
            )
            
            expected_phase = max_dep_phase + 1
            actual_phase = flow_phases[flow.flow_id]
            
            assert actual_phase == expected_phase, (
                f"Flow {flow.flow_id} should be in phase {expected_phase} "
                f"(max dependency phase is {max_dep_phase}), "
                f"but is in phase {actual_phase}"
            )
    
    # Property 3: All dependencies must be in earlier phases
    for flow in flows:
        current_phase = flow_phases[flow.flow_id]
        for dep_flow_id in flow.required_flows:
            dep_phase = flow_phases[dep_flow_id]
            assert dep_phase < current_phase, (
                f"Flow {flow.flow_id} (phase {current_phase}) depends on "
                f"{dep_flow_id} (phase {dep_phase}), but dependency is not in earlier phase"
            )
    
    # Property 4: Phase assignments should be contiguous (no gaps)
    phase_numbers = sorted(flow_phases.values())
    unique_phases = sorted(set(phase_numbers))
    expected_phases = list(range(1, len(unique_phases) + 1))
    
    assert unique_phases == expected_phases, (
        f"Phase numbers are not contiguous: {unique_phases} "
        f"(expected {expected_phases})"
    )
    
    # Property 5: All flows should be assigned a phase
    assert len(flow_phases) == len(flows), (
        f"Not all flows were assigned a phase: "
        f"{len(flow_phases)} assigned, {len(flows)} flows"
    )


@given(st.integers(min_value=1, max_value=20))
@settings(max_examples=100)
def test_phase_assignment_independent_flows(num_flows):
    """
    Property 5: Phase Assignment Correctness (independent flows)
    
    When all flows have no dependencies, they should all be in phase 1.
    
    **Validates: Requirements 3.1**
    """
    # Create independent flows (no dependencies)
    flows = []
    workpackages = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],  # No dependencies
            dependent_flows=[]
        )
        flows.append(flow)
        
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # All flows should be in phase 1
    for flow in flows:
        assert assigner.flow_phases[flow.flow_id] == 1, (
            f"Independent flow {flow.flow_id} should be in phase 1, "
            f"but is in phase {assigner.flow_phases[flow.flow_id]}"
        )
    
    # Should have exactly one phase
    assert len(phase_list) == 1, (
        f"Expected 1 phase for independent flows, got {len(phase_list)}"
    )
    
    assert phase_list[0].phase_id == 1, (
        f"Expected phase ID 1, got {phase_list[0].phase_id}"
    )


@given(st.integers(min_value=2, max_value=10))
@settings(max_examples=100)
def test_phase_assignment_linear_chain(chain_length):
    """
    Property 5: Phase Assignment Correctness (linear chain)
    
    For a linear chain of dependencies (A -> B -> C -> ...),
    each flow should be in phase N where N is its position in the chain.
    
    **Validates: Requirements 3.2**
    """
    # Create linear chain of flows
    flows = []
    workpackages = []
    
    for i in range(chain_length):
        flow_id = f"FLOW_{i:03d}"
        
        # Each flow depends on the previous one (except the first)
        if i == 0:
            required_flows = []
        else:
            required_flows = [f"FLOW_{i-1:03d}"]
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
        
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Each flow should be in phase equal to its position + 1
    for i, flow in enumerate(flows):
        expected_phase = i + 1
        actual_phase = assigner.flow_phases[flow.flow_id]
        
        assert actual_phase == expected_phase, (
            f"Flow {flow.flow_id} at position {i} should be in phase {expected_phase}, "
            f"but is in phase {actual_phase}"
        )
    
    # Should have exactly chain_length phases
    assert len(phase_list) == chain_length, (
        f"Expected {chain_length} phases for linear chain, got {len(phase_list)}"
    )
