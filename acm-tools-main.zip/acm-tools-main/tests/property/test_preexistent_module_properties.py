"""
Property-based tests for pre-existent module identification.

Feature: migration-workpackage-planner
Property 4: Pre-existent Module Identification
Validates: Requirements 2.4
"""

import pytest
from hypothesis import given, strategies as st, settings, assume
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.models.priority import PriorityResult, PriorityFactors
from tools.migration_planner.workpackage.workpackage_assigner import WorkpackageAssigner


# Custom strategies for generating test data
@st.composite
def program_with_name_strategy(draw, name):
    """Generate a Program with a specific name."""
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def flows_with_shared_programs_strategy(draw):
    """
    Generate flows where some programs are shared across flows.
    This ensures we can test pre-existent module identification.
    """
    # Create a pool of program names
    num_unique_programs = draw(st.integers(min_value=5, max_value=20))
    program_names = [f"PROG_{i:03d}" for i in range(num_unique_programs)]
    
    # Generate 2 to 10 flows
    num_flows = draw(st.integers(min_value=2, max_value=10))
    flows = []
    priorities = {}
    
    for flow_idx in range(num_flows):
        flow_id = f"FLOW_{flow_idx:03d}"
        
        # Each flow gets 1 to 8 programs from the pool
        num_programs = draw(st.integers(min_value=1, max_value=min(8, num_unique_programs)))
        selected_names = draw(st.lists(
            st.sampled_from(program_names),
            min_size=num_programs,
            max_size=num_programs,
            unique=True
        ))
        
        # Create programs for this flow
        programs = [Program(name=name, is_utility=False) for name in selected_names]
        
        # Create flow
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {flow_idx}",
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
        
        # Assign priority (lower index = higher priority = lower score)
        priority_score = float(flow_idx * 10)
        factors = PriorityFactors(
            total_programs=len(programs),
            common_modules=0,
            composite_score=10.0,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities[flow_id] = PriorityResult(
            flow_id=flow_id,
            priority_score=priority_score,
            factors=factors
        )
    
    return flows, priorities


@given(flows_with_shared_programs_strategy())
@settings(max_examples=100)
def test_preexistent_module_identification(flows_and_priorities):
    """
    Property 4: Pre-existent Module Identification
    
    For any workpackage assignment, programs that appear in higher-priority
    (lower workpackage ID) workpackages should be correctly identified as
    pre-existent modules.
    
    **Validates: Requirements 2.4**
    """
    flows, priorities = flows_and_priorities
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # Track programs seen in previous workpackages
    seen_programs = set()
    
    for assignment in assignments:
        # Get the flow for this assignment
        flow = next(f for f in flows if f.flow_id == assignment.flow_id)
        
        # Property 1: Pre-existent modules should be programs seen in earlier workpackages
        for program_name in assignment.preexistent_modules:
            assert program_name in seen_programs, (
                f"Program {program_name} in workpackage {assignment.workpackage_id} "
                f"is marked as pre-existent but was not seen in earlier workpackages"
            )
        
        # Property 2: All programs in earlier workpackages should be marked as pre-existent
        flow_program_names = set(flow.get_program_names())
        expected_preexistent = flow_program_names & seen_programs
        actual_preexistent = set(assignment.preexistent_modules)
        
        assert actual_preexistent == expected_preexistent, (
            f"Pre-existent modules mismatch for workpackage {assignment.workpackage_id}: "
            f"expected {expected_preexistent}, got {actual_preexistent}"
        )
        
        # Property 3: Pre-existent modules should be a subset of flow's programs
        for program_name in assignment.preexistent_modules:
            assert program_name in flow_program_names, (
                f"Pre-existent module {program_name} in workpackage {assignment.workpackage_id} "
                f"is not in the flow's program list"
            )
        
        # Property 4: Pre-existent modules list should be sorted
        assert assignment.preexistent_modules == sorted(assignment.preexistent_modules), (
            f"Pre-existent modules list for workpackage {assignment.workpackage_id} "
            f"is not sorted: {assignment.preexistent_modules}"
        )
        
        # Update seen programs for next iteration
        seen_programs.update(flow_program_names)


@given(st.integers(min_value=2, max_value=10))
@settings(max_examples=100)
def test_preexistent_modules_first_workpackage_has_none(num_flows):
    """
    Property 4: Pre-existent Module Identification (first workpackage)
    
    The first workpackage (highest priority) should never have pre-existent modules
    since no workpackages have been assigned before it.
    
    **Validates: Requirements 2.4**
    """
    # Create flows with unique programs
    flows = []
    priorities = {}
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i}"
        programs = [Program(name=f"PROG_{i}_{j}", is_utility=False) for j in range(3)]
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
        
        # Assign priorities
        factors = PriorityFactors(
            total_programs=len(programs),
            common_modules=0,
            composite_score=10.0,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities[flow_id] = PriorityResult(
            flow_id=flow_id,
            priority_score=float(i * 10),
            factors=factors
        )
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # First workpackage should have no pre-existent modules
    first_assignment = assignments[0]
    assert len(first_assignment.preexistent_modules) == 0, (
        f"First workpackage {first_assignment.workpackage_id} should have no pre-existent modules, "
        f"but has: {first_assignment.preexistent_modules}"
    )


@given(st.integers(min_value=3, max_value=8))
@settings(max_examples=100)
def test_preexistent_modules_with_complete_overlap(num_flows):
    """
    Property 4: Pre-existent Module Identification (complete overlap)
    
    When all flows share the same programs, later workpackages should identify
    all programs as pre-existent.
    
    **Validates: Requirements 2.4**
    """
    # Create shared programs
    shared_programs = [Program(name=f"SHARED_{i}", is_utility=False) for i in range(5)]
    shared_program_names = [p.name for p in shared_programs]
    
    # Create flows that all use the same programs
    flows = []
    priorities = {}
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i}"
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=shared_programs.copy(),
            databases=[],
            total_programs=len(shared_programs),
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
        
        # Assign priorities
        factors = PriorityFactors(
            total_programs=len(shared_programs),
            common_modules=0,
            composite_score=10.0,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities[flow_id] = PriorityResult(
            flow_id=flow_id,
            priority_score=float(i * 10),
            factors=factors
        )
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # First workpackage should have no pre-existent modules
    assert len(assignments[0].preexistent_modules) == 0
    
    # All subsequent workpackages should have all programs as pre-existent
    for i in range(1, len(assignments)):
        assignment = assignments[i]
        assert set(assignment.preexistent_modules) == set(shared_program_names), (
            f"Workpackage {assignment.workpackage_id} should have all programs as pre-existent: "
            f"expected {set(shared_program_names)}, got {set(assignment.preexistent_modules)}"
        )


@given(st.integers(min_value=2, max_value=8))
@settings(max_examples=100)
def test_preexistent_modules_with_no_overlap(num_flows):
    """
    Property 4: Pre-existent Module Identification (no overlap)
    
    When flows have completely different programs, no workpackage should have
    pre-existent modules.
    
    **Validates: Requirements 2.4**
    """
    # Create flows with unique programs
    flows = []
    priorities = {}
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i}"
        # Each flow gets unique programs
        programs = [Program(name=f"PROG_{i}_{j}", is_utility=False) for j in range(3)]
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
        
        # Assign priorities
        factors = PriorityFactors(
            total_programs=len(programs),
            common_modules=0,
            composite_score=10.0,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities[flow_id] = PriorityResult(
            flow_id=flow_id,
            priority_score=float(i * 10),
            factors=factors
        )
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # No workpackage should have pre-existent modules
    for assignment in assignments:
        assert len(assignment.preexistent_modules) == 0, (
            f"Workpackage {assignment.workpackage_id} should have no pre-existent modules "
            f"when flows have no overlapping programs, but has: {assignment.preexistent_modules}"
        )


@given(st.integers(min_value=3, max_value=10))
@settings(max_examples=100)
def test_preexistent_modules_accumulate_over_workpackages(num_flows):
    """
    Property 4: Pre-existent Module Identification (accumulation)
    
    Pre-existent modules should accumulate as more workpackages are assigned.
    Each workpackage can only reference programs from earlier workpackages.
    
    **Validates: Requirements 2.4**
    """
    # Create flows where each flow adds one new program and reuses one from previous
    flows = []
    priorities = {}
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i}"
        programs = []
        
        # Add a unique program for this flow
        programs.append(Program(name=f"UNIQUE_{i}", is_utility=False))
        
        # If not the first flow, reuse one program from the previous flow
        if i > 0:
            programs.append(Program(name=f"UNIQUE_{i-1}", is_utility=False))
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=programs,
            databases=[],
            total_programs=len(programs),
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
        
        # Assign priorities
        factors = PriorityFactors(
            total_programs=len(programs),
            common_modules=0,
            composite_score=10.0,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities[flow_id] = PriorityResult(
            flow_id=flow_id,
            priority_score=float(i * 10),
            factors=factors
        )
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # First workpackage should have no pre-existent modules
    assert len(assignments[0].preexistent_modules) == 0
    
    # Each subsequent workpackage should have exactly one pre-existent module
    for i in range(1, len(assignments)):
        assignment = assignments[i]
        assert len(assignment.preexistent_modules) == 1, (
            f"Workpackage {assignment.workpackage_id} should have exactly 1 pre-existent module, "
            f"but has {len(assignment.preexistent_modules)}: {assignment.preexistent_modules}"
        )
        
        # The pre-existent module should be from the previous flow
        expected_preexistent = f"UNIQUE_{i-1}"
        assert expected_preexistent in assignment.preexistent_modules, (
            f"Workpackage {assignment.workpackage_id} should have {expected_preexistent} "
            f"as pre-existent, but has: {assignment.preexistent_modules}"
        )
