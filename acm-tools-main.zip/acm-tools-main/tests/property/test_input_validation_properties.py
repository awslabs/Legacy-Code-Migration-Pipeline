"""
Property-based tests for input validation in migration workpackage planner.

Feature: migration-workpackage-planner
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings, assume

from tools.migration_planner.input import FlowDataLoader


# Hypothesis strategies for generating test data

@st.composite
def valid_program_strategy(draw):
    """Generate a valid program object."""
    name = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    is_utility = draw(st.booleans())
    return {
        'name': name,
        'isUtility': is_utility
    }


@st.composite
def valid_flow_strategy(draw):
    """Generate a valid business flow object."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    programs = draw(st.lists(valid_program_strategy(), min_size=1, max_size=10))
    total_programs = len(programs)
    
    # Generate complexity
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False))
    
    # Generate dependencies
    required_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    dependent_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    
    # Generate databases (optional)
    databases = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    
    flow = {
        'flowId': flow_id,
        'name': name,
        'scope': {
            'programs': programs
        },
        'complexity': {
            'totalPrograms': total_programs,
            'compositeScore': composite_score
        },
        'dependencies': {
            'requiredFlows': required_flows,
            'dependentFlows': dependent_flows
        }
    }
    
    # Optionally add dataOperations
    if databases:
        flow['dataOperations'] = {'databases': databases}
    
    return flow


@st.composite
def flow_with_missing_field_strategy(draw, field_to_remove):
    """Generate a flow with a specific required field missing."""
    flow = draw(valid_flow_strategy())
    
    # Remove the specified field
    if field_to_remove == 'flowId':
        del flow['flowId']
    elif field_to_remove == 'scope':
        del flow['scope']
    elif field_to_remove == 'scope.programs':
        del flow['scope']['programs']
    elif field_to_remove == 'complexity':
        del flow['complexity']
    elif field_to_remove == 'complexity.totalPrograms':
        del flow['complexity']['totalPrograms']
    elif field_to_remove == 'dependencies':
        del flow['dependencies']
    
    return flow


# Property 8: Input Validation
# Validates: Requirements 4.2, 4.5, 4.6

@given(flows=st.lists(valid_flow_strategy(), min_size=1, max_size=10))
@settings(max_examples=100, deadline=None)
def test_property_8_valid_flows_load_successfully(flows):
    """
    Property 8: Input Validation
    
    For any valid flow data with all required fields, the validator should
    successfully parse and create BusinessFlow objects without errors.
    
    Validates: Requirements 4.2, 4.5, 4.6
    """
    loader = FlowDataLoader()
    
    # Create temporary file with valid flows
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'flows': flows}, f)
        temp_path = Path(f.name)
    
    try:
        # Load flows should succeed
        loaded_flows = loader.load_flows(temp_path)
        
        # Verify all flows were loaded
        assert len(loaded_flows) == len(flows), "All flows should be loaded"
        
        # Verify each flow has required attributes
        for loaded_flow in loaded_flows:
            assert hasattr(loaded_flow, 'flow_id'), "Flow should have flow_id"
            assert hasattr(loaded_flow, 'name'), "Flow should have name"
            assert hasattr(loaded_flow, 'programs'), "Flow should have programs"
            assert hasattr(loaded_flow, 'total_programs'), "Flow should have total_programs"
            assert hasattr(loaded_flow, 'composite_score'), "Flow should have composite_score"
            assert hasattr(loaded_flow, 'required_flows'), "Flow should have required_flows"
            assert hasattr(loaded_flow, 'dependent_flows'), "Flow should have dependent_flows"
            assert hasattr(loaded_flow, 'databases'), "Flow should have databases"
            
            # Verify flow_id is not empty
            assert loaded_flow.flow_id, "flow_id should not be empty"
            
            # Verify programs list
            assert isinstance(loaded_flow.programs, list), "programs should be a list"
            assert len(loaded_flow.programs) > 0, "programs should not be empty"
            
            # Verify all programs have names
            for program in loaded_flow.programs:
                assert hasattr(program, 'name'), "Program should have name"
                assert program.name, "Program name should not be empty"
    
    finally:
        # Clean up
        temp_path.unlink()


@given(field=st.sampled_from(['flowId', 'scope', 'scope.programs', 'complexity', 
                               'complexity.totalPrograms', 'dependencies']),
       data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_8_missing_required_fields_raise_error(field, data):
    """
    Property 8: Input Validation
    
    For any flow missing a required field, the validator should raise a ValueError
    with context about the missing field.
    
    Validates: Requirements 4.2, 4.5, 4.6
    """
    loader = FlowDataLoader()
    
    # Generate a flow with the missing field
    flow = data.draw(flow_with_missing_field_strategy(field))
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'flows': [flow]}, f)
        temp_path = Path(f.name)
    
    try:
        # Loading should raise ValueError
        try:
            loader.load_flows(temp_path)
            assert False, f"Should have raised ValueError for missing {field}"
        except ValueError as e:
            # Error message should mention the missing field or related context
            error_msg = str(e).lower()
            assert 'missing' in error_msg or 'required' in error_msg, \
                f"Error message should indicate missing field: {e}"
    
    finally:
        # Clean up
        temp_path.unlink()


@given(flows=st.lists(valid_flow_strategy(), min_size=1, max_size=10))
@settings(max_examples=100, deadline=None)
def test_property_8_invalid_json_raises_error(flows):
    """
    Property 8: Input Validation
    
    For any file with invalid JSON, the validator should raise a ValueError
    indicating JSON parsing failure.
    
    Validates: Requirements 4.2
    """
    loader = FlowDataLoader()
    
    # Create temporary file with invalid JSON
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        f.write('{"flows": [invalid json}')
        temp_path = Path(f.name)
    
    try:
        # Loading should raise ValueError
        try:
            loader.load_flows(temp_path)
            assert False, "Should have raised ValueError for invalid JSON"
        except ValueError as e:
            error_msg = str(e).lower()
            assert 'json' in error_msg or 'invalid' in error_msg, \
                f"Error message should indicate JSON error: {e}"
    
    finally:
        # Clean up
        temp_path.unlink()


@given(flows=st.lists(valid_flow_strategy(), min_size=1, max_size=10))
@settings(max_examples=100, deadline=None)
def test_property_8_missing_flows_array_raises_error(flows):
    """
    Property 8: Input Validation
    
    For any file without a 'flows' array, the validator should raise a ValueError.
    
    Validates: Requirements 4.2
    """
    loader = FlowDataLoader()
    
    # Create temporary file without 'flows' key
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'data': flows}, f)  # Wrong key
        temp_path = Path(f.name)
    
    try:
        # Loading should raise ValueError
        try:
            loader.load_flows(temp_path)
            assert False, "Should have raised ValueError for missing 'flows' array"
        except ValueError as e:
            error_msg = str(e).lower()
            assert 'flows' in error_msg, f"Error message should mention 'flows': {e}"
    
    finally:
        # Clean up
        temp_path.unlink()


@settings(max_examples=100, deadline=None)
@given(st.text(min_size=1, max_size=100))
def test_property_8_missing_file_raises_error(filename):
    """
    Property 8: Input Validation
    
    For any non-existent file path, the validator should raise FileNotFoundError.
    
    Validates: Requirements 4.1
    """
    loader = FlowDataLoader()
    
    # Use a path that definitely doesn't exist
    non_existent_path = Path(f"/tmp/nonexistent_{filename}_12345.json")
    assume(not non_existent_path.exists())
    
    try:
        loader.load_flows(non_existent_path)
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass  # Expected


@given(flows=st.lists(valid_flow_strategy(), min_size=1, max_size=10))
@settings(max_examples=100, deadline=None)
def test_property_8_program_without_name_raises_error(flows):
    """
    Property 8: Input Validation
    
    For any program without a 'name' field, the validator should raise a ValueError.
    
    Validates: Requirements 4.5, 4.6
    """
    loader = FlowDataLoader()
    
    # Take first flow and remove name from first program
    flow = flows[0].copy()
    if flow['scope']['programs']:
        flow['scope']['programs'][0] = {'isUtility': True}  # Missing 'name'
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'flows': [flow]}, f)
        temp_path = Path(f.name)
    
    try:
        # Loading should raise ValueError
        try:
            loader.load_flows(temp_path)
            assert False, "Should have raised ValueError for program without name"
        except ValueError as e:
            error_msg = str(e).lower()
            assert 'name' in error_msg, f"Error message should mention 'name': {e}"
    
    finally:
        # Clean up
        temp_path.unlink()
