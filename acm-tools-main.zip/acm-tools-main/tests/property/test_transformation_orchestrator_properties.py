"""
Property-based tests for TransformationOrchestrator.

Tests universal properties that should hold for all transformation operations.
"""

import tempfile
import json
import csv
from pathlib import Path
from hypothesis import given, strategies as st, settings, assume
from tools.atx.dependency_transformer.orchestration import TransformationOrchestrator
from tools.atx.dependency_transformer.models.config_models import TransformationConfig


# Strategy for generating minimal valid ATX data
@st.composite
def minimal_atx_data(draw):
    """Generate minimal valid ATX data for testing."""
    program_name = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd')
    )))
    
    dependencies = [
        {
            "name": program_name,
            "path": f"/path/to/{program_name}.cbl",
            "type": "COB",
            "dependencies": []
        }
    ]
    
    assets = [
        {
            "name": program_name,
            "path": f"/path/to/{program_name}.cbl",
            "file_type": "COB",
            "cyclomatic_complexity": draw(st.integers(min_value=0, max_value=100)),
            "total_lines": draw(st.integers(min_value=1, max_value=1000)),
            "empty_lines": 0,
            "effective_lines": draw(st.integers(min_value=1, max_value=1000)),
            "comment_lines": 0,
        }
    ]
    
    program_to_dsn = []
    
    return {
        "dependencies": dependencies,
        "assets": assets,
        "program_to_dsn": program_to_dsn,
    }


def create_temp_atx_directory(atx_data):
    """Create a temporary directory with ATX files."""
    temp_dir = tempfile.mkdtemp()
    temp_path = Path(temp_dir)
    
    # Write dependencies.json
    with open(temp_path / "dependencies.json", "w") as f:
        json.dump(atx_data["dependencies"], f)
    
    # Write assets.csv
    with open(temp_path / "assets.csv", "w", newline="") as f:
        if atx_data["assets"]:
            writer = csv.DictWriter(f, fieldnames=atx_data["assets"][0].keys())
            writer.writeheader()
            writer.writerows(atx_data["assets"])
    
    # Write program_to_dsn.json
    with open(temp_path / "program_to_dsn.json", "w") as f:
        json.dump(atx_data["program_to_dsn"], f)
    
    return temp_dir


# Feature: atx-dependency-transformer, Property 22: Dry-Run Mode Behavior
@given(atx_data=minimal_atx_data())
@settings(max_examples=100, deadline=None)
def test_property_22_dry_run_mode_behavior(atx_data):
    """
    Feature: atx-dependency-transformer, Property 22: Dry-Run Mode Behavior
    
    For any transformation executed in dry-run mode, validation should be 
    performed and reports generated, but no output files should be written to disk.
    
    Validates: Requirements AC-4.8
    """
    # Create temporary input directory
    input_dir = create_temp_atx_directory(atx_data)
    
    # Create temporary output directory
    output_dir = tempfile.mkdtemp()
    output_path = Path(output_dir)
    
    try:
        # Create orchestrator
        orchestrator = TransformationOrchestrator()
        
        # Run transformation in dry-run mode
        report = orchestrator.transform_all(
            input_dir=input_dir,
            output_dir=output_dir,
            dry_run=True
        )
        
        # Property: Report should be generated
        assert report is not None, "Report should be generated in dry-run mode"
        assert report.dry_run == True, "Report should indicate dry-run mode"
        
        # Property: No output files should be written
        # Check that output directory is empty or only contains directories
        output_files = list(output_path.rglob("*.json")) + list(output_path.rglob("*.csv"))
        assert len(output_files) == 0, \
            f"No output files should be written in dry-run mode, found: {output_files}"
        
        # Property: Validation should still be performed
        # (indicated by report having execution time and statistics)
        assert report.execution_time_seconds >= 0, \
            "Execution time should be recorded"
        
    finally:
        # Cleanup
        import shutil
        shutil.rmtree(input_dir, ignore_errors=True)
        shutil.rmtree(output_dir, ignore_errors=True)


# Feature: atx-dependency-transformer, Property 23: Transformation Report Completeness
@given(atx_data=minimal_atx_data())
@settings(max_examples=100, deadline=None)
def test_property_23_transformation_report_completeness(atx_data):
    """
    Feature: atx-dependency-transformer, Property 23: Transformation Report Completeness
    
    For any completed transformation, the report should include counts of flows, 
    jobs, entry points, programs, and any warnings about missing or incomplete data.
    
    Validates: Requirements AC-4.6, AC-4.7
    """
    # Create temporary input directory
    input_dir = create_temp_atx_directory(atx_data)
    
    # Create temporary output directory
    output_dir = tempfile.mkdtemp()
    
    try:
        # Create orchestrator
        orchestrator = TransformationOrchestrator()
        
        # Run transformation in dry-run mode (to avoid file I/O)
        report = orchestrator.transform_all(
            input_dir=input_dir,
            output_dir=output_dir,
            dry_run=True
        )
        
        # Property: Report should have all required fields
        assert hasattr(report, "success"), "Report should have success field"
        assert hasattr(report, "flows_generated"), "Report should have flows_generated field"
        assert hasattr(report, "jobs_generated"), "Report should have jobs_generated field"
        assert hasattr(report, "entry_points_generated"), \
            "Report should have entry_points_generated field"
        assert hasattr(report, "programs_processed"), \
            "Report should have programs_processed field"
        assert hasattr(report, "warnings"), "Report should have warnings field"
        assert hasattr(report, "errors"), "Report should have errors field"
        assert hasattr(report, "execution_time_seconds"), \
            "Report should have execution_time_seconds field"
        
        # Property: Counts should be non-negative
        assert report.flows_generated >= 0, "Flows count should be non-negative"
        assert report.jobs_generated >= 0, "Jobs count should be non-negative"
        assert report.entry_points_generated >= 0, "Entry points count should be non-negative"
        assert report.programs_processed >= 0, "Programs count should be non-negative"
        
        # Property: Warnings and errors should be lists
        assert isinstance(report.warnings, list), "Warnings should be a list"
        assert isinstance(report.errors, list), "Errors should be a list"
        
        # Property: Execution time should be non-negative
        assert report.execution_time_seconds >= 0, "Execution time should be non-negative"
        
        # Property: Report should have a summary method
        summary = report.get_summary()
        assert isinstance(summary, str), "Summary should be a string"
        assert len(summary) > 0, "Summary should not be empty"
        
        # Property: Report should be convertible to dict
        report_dict = report.to_dict()
        assert isinstance(report_dict, dict), "Report should be convertible to dict"
        assert "success" in report_dict, "Report dict should have success field"
        assert "flows_generated" in report_dict, "Report dict should have flows_generated field"
        assert "jobs_generated" in report_dict, "Report dict should have jobs_generated field"
        assert "entry_points_generated" in report_dict, \
            "Report dict should have entry_points_generated field"
        assert "programs_processed" in report_dict, \
            "Report dict should have programs_processed field"
        
    finally:
        # Cleanup
        import shutil
        shutil.rmtree(input_dir, ignore_errors=True)
        shutil.rmtree(output_dir, ignore_errors=True)


# Additional property test: Validation before transformation
@given(atx_data=minimal_atx_data())
@settings(max_examples=50, deadline=None)
def test_validation_before_transformation(atx_data):
    """
    Test that validation is always performed before transformation.
    
    For any transformation, if validation fails, the transformation should not proceed
    and the report should indicate failure with appropriate errors.
    """
    # Create temporary input directory with invalid data (missing required file)
    temp_dir = tempfile.mkdtemp()
    temp_path = Path(temp_dir)
    
    # Only write dependencies.json, missing assets.csv and program_to_dsn.json
    with open(temp_path / "dependencies.json", "w") as f:
        json.dump(atx_data["dependencies"], f)
    
    output_dir = tempfile.mkdtemp()
    
    try:
        orchestrator = TransformationOrchestrator()
        
        # Run transformation (should fail validation)
        report = orchestrator.transform_all(
            input_dir=temp_dir,
            output_dir=output_dir,
            dry_run=True
        )
        
        # Property: Transformation should fail if validation fails
        assert report.success == False, \
            "Transformation should fail when required files are missing"
        
        # Property: Report should contain validation errors
        assert len(report.errors) > 0, \
            "Report should contain errors when validation fails"
        
    finally:
        # Cleanup
        import shutil
        shutil.rmtree(temp_dir, ignore_errors=True)
        shutil.rmtree(output_dir, ignore_errors=True)


# Additional property test: Individual transformation methods
@given(atx_data=minimal_atx_data())
@settings(max_examples=50, deadline=None)
def test_individual_transformation_methods(atx_data):
    """
    Test that individual transformation methods (flows, jobs, entry_points) work correctly.
    
    For any valid ATX data, each individual transformation method should produce
    a valid report with appropriate counts.
    """
    # Create temporary input directory
    input_dir = create_temp_atx_directory(atx_data)
    output_dir = tempfile.mkdtemp()
    
    try:
        orchestrator = TransformationOrchestrator()
        
        # Test transform_flows
        flows_report = orchestrator.transform_flows(
            input_dir=input_dir,
            output_dir=output_dir,
            dry_run=True
        )
        assert flows_report is not None, "Flows report should be generated"
        assert hasattr(flows_report, "flows_generated"), \
            "Flows report should have flows_generated field"
        
        # Test transform_jobs
        jobs_report = orchestrator.transform_jobs(
            input_dir=input_dir,
            output_dir=output_dir,
            dry_run=True
        )
        assert jobs_report is not None, "Jobs report should be generated"
        assert hasattr(jobs_report, "jobs_generated"), \
            "Jobs report should have jobs_generated field"
        
        # Test transform_entry_points
        entry_points_report = orchestrator.transform_entry_points(
            input_dir=input_dir,
            output_dir=output_dir,
            dry_run=True
        )
        assert entry_points_report is not None, "Entry points report should be generated"
        assert hasattr(entry_points_report, "entry_points_generated"), \
            "Entry points report should have entry_points_generated field"
        
    finally:
        # Cleanup
        import shutil
        shutil.rmtree(input_dir, ignore_errors=True)
        shutil.rmtree(output_dir, ignore_errors=True)
