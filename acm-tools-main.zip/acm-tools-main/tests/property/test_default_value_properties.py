"""
Property-based tests for default value application in migration workpackage planner.

Feature: migration-workpackage-planner
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings

from tools.migration_planner.input import FlowDataLoader


# Hypothesis strategies for generating test data

@st.composite
def valid_program_strategy(draw):
    """Generate a valid program object."""
    name = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    is_utility = draw(st.booleans())
    return {
        'name': name,
        'isUtility': is_utility
    }


@st.composite
def flow_without_optional_fields_strategy(draw):
    """Generate a flow without optional fields (to test defaults)."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    programs = draw(st.lists(valid_program_strategy(), min_size=1, max_size=10))
    total_programs = len(programs)
    
    # Generate dependencies
    required_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    dependent_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    
    # Create flow WITHOUT optional fields
    flow = {
        'flowId': flow_id,
        'name': name,
        'scope': {
            'programs': programs
        },
        'complexity': {
            'totalPrograms': total_programs
            # Missing compositeScore - should default to 0
        },
        'dependencies': {
            'requiredFlows': required_flows,
            'dependentFlows': dependent_flows
        }
        # Missing dataOperations - databases should default to empty list
    }
    
    return flow


# Property 9: Default Value Application
# Validates: Requirements 4.7

@given(flows=st.lists(flow_without_optional_fields_strategy(), min_size=1, max_size=10))
@settings(max_examples=100, deadline=None)
def test_property_9_missing_composite_score_defaults_to_zero(flows):
    """
    Property 9: Default Value Application
    
    For any flow missing compositeScore, the system should apply default value of 0.
    
    Validates: Requirements 4.7
    """
    loader = FlowDataLoader()
    
    # Create temporary file with flows missing compositeScore
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'flows': flows}, f)
        temp_path = Path(f.name)
    
    try:
        # Load flows should succeed
        loaded_flows = loader.load_flows(temp_path)
        
        # Verify all flows have composite_score = 0.0
        for loaded_flow in loaded_flows:
            assert hasattr(loaded_flow, 'composite_score'), "Flow should have composite_score"
            assert loaded_flow.composite_score == 0.0, \
                f"Missing compositeScore should default to 0.0, got {loaded_flow.composite_score}"
    
    finally:
        # Clean up
        temp_path.unlink()


@given(flows=st.lists(flow_without_optional_fields_strategy(), min_size=1, max_size=10))
@settings(max_examples=100, deadline=None)
def test_property_9_missing_databases_defaults_to_empty_list(flows):
    """
    Property 9: Default Value Application
    
    For any flow missing dataOperations.databases, the system should apply default
    value of empty list.
    
    Validates: Requirements 4.7
    """
    loader = FlowDataLoader()
    
    # Create temporary file with flows missing dataOperations
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'flows': flows}, f)
        temp_path = Path(f.name)
    
    try:
        # Load flows should succeed
        loaded_flows = loader.load_flows(temp_path)
        
        # Verify all flows have empty databases list
        for loaded_flow in loaded_flows:
            assert hasattr(loaded_flow, 'databases'), "Flow should have databases"
            assert isinstance(loaded_flow.databases, list), "databases should be a list"
            assert len(loaded_flow.databases) == 0, \
                f"Missing databases should default to empty list, got {loaded_flow.databases}"
    
    finally:
        # Clean up
        temp_path.unlink()


@st.composite
def flow_with_explicit_composite_score_strategy(draw):
    """Generate a flow with explicit compositeScore."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    programs = draw(st.lists(valid_program_strategy(), min_size=1, max_size=10))
    total_programs = len(programs)
    
    # Generate explicit composite score
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False))
    
    # Generate dependencies
    required_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    dependent_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    
    flow = {
        'flowId': flow_id,
        'name': name,
        'scope': {
            'programs': programs
        },
        'complexity': {
            'totalPrograms': total_programs,
            'compositeScore': composite_score  # Explicit value
        },
        'dependencies': {
            'requiredFlows': required_flows,
            'dependentFlows': dependent_flows
        }
    }
    
    return flow, composite_score


@given(flow_data=flow_with_explicit_composite_score_strategy())
@settings(max_examples=100, deadline=None)
def test_property_9_explicit_composite_score_preserved(flow_data):
    """
    Property 9: Default Value Application
    
    For any flow with explicit compositeScore, the system should preserve the
    provided value (not apply default).
    
    Validates: Requirements 4.7
    """
    flow, expected_score = flow_data
    loader = FlowDataLoader()
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'flows': [flow]}, f)
        temp_path = Path(f.name)
    
    try:
        # Load flows should succeed
        loaded_flows = loader.load_flows(temp_path)
        
        # Verify composite_score matches the explicit value
        assert len(loaded_flows) == 1, "Should load exactly one flow"
        loaded_flow = loaded_flows[0]
        assert hasattr(loaded_flow, 'composite_score'), "Flow should have composite_score"
        assert abs(loaded_flow.composite_score - expected_score) < 0.0001, \
            f"Explicit compositeScore should be preserved: expected {expected_score}, got {loaded_flow.composite_score}"
    
    finally:
        # Clean up
        temp_path.unlink()


@st.composite
def flow_with_explicit_databases_strategy(draw):
    """Generate a flow with explicit databases."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    programs = draw(st.lists(valid_program_strategy(), min_size=1, max_size=10))
    total_programs = len(programs)
    
    # Generate explicit databases
    databases = draw(st.lists(st.text(min_size=1, max_size=20), min_size=1, max_size=5))
    
    # Generate dependencies
    required_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    dependent_flows = draw(st.lists(st.text(min_size=1, max_size=20), max_size=5))
    
    flow = {
        'flowId': flow_id,
        'name': name,
        'scope': {
            'programs': programs
        },
        'complexity': {
            'totalPrograms': total_programs
        },
        'dependencies': {
            'requiredFlows': required_flows,
            'dependentFlows': dependent_flows
        },
        'dataOperations': {
            'databases': databases  # Explicit value
        }
    }
    
    return flow, databases


@given(flow_data=flow_with_explicit_databases_strategy())
@settings(max_examples=100, deadline=None)
def test_property_9_explicit_databases_preserved(flow_data):
    """
    Property 9: Default Value Application
    
    For any flow with explicit databases, the system should preserve the
    provided list (not apply default).
    
    Validates: Requirements 4.7
    """
    flow, expected_databases = flow_data
    loader = FlowDataLoader()
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'flows': [flow]}, f)
        temp_path = Path(f.name)
    
    try:
        # Load flows should succeed
        loaded_flows = loader.load_flows(temp_path)
        
        # Verify databases match the explicit value
        assert len(loaded_flows) == 1, "Should load exactly one flow"
        loaded_flow = loaded_flows[0]
        assert hasattr(loaded_flow, 'databases'), "Flow should have databases"
        assert isinstance(loaded_flow.databases, list), "databases should be a list"
        assert len(loaded_flow.databases) == len(expected_databases), \
            f"Explicit databases should be preserved: expected {len(expected_databases)}, got {len(loaded_flow.databases)}"
        assert set(loaded_flow.databases) == set(expected_databases), \
            f"Explicit databases should match: expected {expected_databases}, got {loaded_flow.databases}"
    
    finally:
        # Clean up
        temp_path.unlink()
