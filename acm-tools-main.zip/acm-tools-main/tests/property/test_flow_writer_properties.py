"""
Property-based tests for FlowWriter.

Tests universal properties of flow output writing and sorting.
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st
import hypothesis

from tools.atx.dependency_transformer.writers.flow_writer import FlowWriter
from tools.atx.dependency_transformer.models.legacy_models import (
    Flow, EntryPoint, EntryPointType, Caller, Scope, Program,
    DataOperations, Complexity, FlowDependencies
)


# Strategy for generating valid flow names
flow_names = st.text(
    alphabet=st.characters(whitelist_categories=("Lu", "Ll", "Nd"), whitelist_characters="_-"),
    min_size=1,
    max_size=50
)

# Strategy for generating program names
program_names = st.text(
    alphabet=st.characters(whitelist_categories=("Lu", "Nd")),
    min_size=1,
    max_size=8
)


@st.composite
def flow_strategy(draw):
    """Generate a valid Flow object."""
    flow_id = draw(st.text(min_size=1, max_size=20))
    name = draw(flow_names)
    program = draw(program_names)
    
    # Generate entry point
    entry_point = EntryPoint(
        program=program,
        types=[
            EntryPointType(
                type="CICS_TRANSACTION",
                callers=[Caller(source="TRAN001", metadata={})]
            )
        ],
        primary_type="CICS_TRANSACTION"
    )
    
    # Generate scope
    num_programs = draw(st.integers(min_value=1, max_value=10))
    programs = [
        Program(name=draw(program_names), is_utility=draw(st.booleans()))
        for _ in range(num_programs)
    ]
    scope = Scope(programs=programs, copybooks=[], datasets=[])
    
    # Generate complexity
    cc = draw(st.integers(min_value=0, max_value=1000))
    loc = draw(st.integers(min_value=0, max_value=100000))
    composite_score = (cc * 0.3) + (loc / 100 * 0.7)
    
    if composite_score < 10:
        tier = "LOW"
    elif composite_score < 20:
        tier = "MEDIUM"
    else:
        tier = "HIGH"
    
    complexity = Complexity(
        total_programs=num_programs,
        total_lines=loc,
        cyclomatic_complexity=cc,
        composite_score=composite_score,
        tier=tier
    )
    
    # Generate dependencies
    num_required = draw(st.integers(min_value=0, max_value=5))
    required_flows = [draw(flow_names) for _ in range(num_required)]
    dependencies = FlowDependencies(required_flows=required_flows, dependent_flows=[])
    
    return Flow(
        flow_id=flow_id,
        name=name,
        entry_point=entry_point,
        scope=scope,
        interfaces={},
        data_operations=DataOperations(),
        complexity=complexity,
        dependencies=dependencies,
        invoked_by_jobs=[]
    )


@given(flows=st.lists(flow_strategy(), min_size=2, max_size=20))
@hypothesis.settings(max_examples=100, deadline=None)
def test_property_19_sort_order_correctness(flows):
    """
    Feature: atx-dependency-transformer, Property 19: Sort Order Correctness
    
    For any sorted output file (flows_by_name.json, flows_by_complexity.json, etc.),
    the entries should be ordered according to the specified sort key in ascending
    or descending order as appropriate.
    
    Validates: Requirements AC-2.7
    """
    writer = FlowWriter(pretty_print=True, indent=2)
    
    with tempfile.TemporaryDirectory() as temp_dir:
        # Write flows with all sort variants
        writer.write(flows, temp_dir)
        
        flows_dir = Path(temp_dir) / "flows"
        
        # Test flows_by_name.json is sorted by name
        with open(flows_dir / "flows_by_name.json") as f:
            flows_by_name = json.load(f)
        
        names = [flow["name"] for flow in flows_by_name]
        assert names == sorted(names), "flows_by_name.json should be sorted by name"
        
        # Test flows_by_complexity_asc.json is sorted by composite score ascending
        with open(flows_dir / "flows_by_complexity_asc.json") as f:
            flows_by_complexity_asc = json.load(f)
        
        scores_asc = [flow["complexity"]["compositeScore"] for flow in flows_by_complexity_asc]
        assert scores_asc == sorted(scores_asc), \
            "flows_by_complexity_asc.json should be sorted by composite score ascending"
        
        # Test flows_by_complexity_desc.json is sorted by composite score descending
        with open(flows_dir / "flows_by_complexity_desc.json") as f:
            flows_by_complexity_desc = json.load(f)
        
        scores_desc = [flow["complexity"]["compositeScore"] for flow in flows_by_complexity_desc]
        assert scores_desc == sorted(scores_desc, reverse=True), \
            "flows_by_complexity_desc.json should be sorted by composite score descending"
        
        # Test flows_by_independence.json is sorted by required flows count
        with open(flows_dir / "flows_by_independence.json") as f:
            flows_by_independence = json.load(f)
        
        dep_counts = [
            len(flow["dependencies"]["requiredFlows"])
            for flow in flows_by_independence
        ]
        assert dep_counts == sorted(dep_counts), \
            "flows_by_independence.json should be sorted by dependency count ascending"
