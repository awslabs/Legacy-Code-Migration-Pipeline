"""
Property-based tests for ATXDependencyLoader.

Tests universal properties that should hold for all valid ATX dependency files.
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings
from tools.atx.dependency_transformer.loaders.atx_dependency_loader import ATXDependencyLoader


# Strategy for generating valid ATX dependency entries
@st.composite
def atx_dependency_entry(draw):
    """Generate a valid ATX dependency entry."""
    # Generate unique names to avoid collisions
    name = draw(st.text(min_size=1, max_size=50, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='.-_')))
    # Add a unique suffix to ensure uniqueness
    unique_suffix = draw(st.integers(min_value=0, max_value=10000))
    name = f"{name}_{unique_suffix}"
    
    path = draw(st.text(min_size=1, max_size=100))
    dep_type = draw(st.sampled_from(['COB', 'JCL', 'TRANSACTION', 'CPY', 'CICS_FILE', 'DATASET']))
    
    # Generate dependencies
    num_deps = draw(st.integers(min_value=0, max_value=5))
    dependencies = []
    for _ in range(num_deps):
        dep_name = draw(st.text(min_size=1, max_size=30))
        dep_dep_type = draw(st.sampled_from([
            'Call', 'Copy', 'Dataset use', 'Exec program', 'Start program'
        ]))
        dep_obj_type = draw(st.sampled_from(['COB', 'CPY', 'System', 'PS', 'VSAM KSDS DATASET']))
        dependencies.append({
            'dependencyType': dep_dep_type,
            'name': dep_name,
            'path': draw(st.one_of(st.none(), st.text())),
            'type': dep_obj_type
        })
    
    return {
        'name': name,
        'path': path,
        'type': dep_type,
        'dependencies': dependencies
    }


@st.composite
def atx_dependencies_file(draw):
    """Generate a list of ATX dependency entries."""
    num_entries = draw(st.integers(min_value=1, max_value=20))
    entries = [draw(atx_dependency_entry()) for _ in range(num_entries)]
    return entries


@given(dependencies=atx_dependencies_file())
@settings(max_examples=100, deadline=None)
def test_property_1_atx_file_loading_completeness(dependencies):
    """
    Feature: atx-dependency-transformer, Property 1: ATX File Loading Completeness
    
    For any valid ATX input directory containing dependencies.json, loading the file
    should successfully extract all programs, metrics, and data operations without data loss.
    
    Validates: Requirements AC-1.1, AC-1.2, AC-1.3
    """
    # Create temporary file with generated dependencies
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(dependencies, f)
        temp_path = f.name
    
    try:
        # Load the file
        loader = ATXDependencyLoader()
        loaded_deps = loader.load(temp_path)
        
        # Property 1: All entries should be loaded
        assert len(loaded_deps) == len(dependencies), \
            f"Expected {len(dependencies)} entries, got {len(loaded_deps)}"
        
        # Property 2: All unique names should be accessible
        # Note: If there are duplicate names, only the last one is kept in the index
        unique_names = {}
        for dep in dependencies:
            unique_names[dep['name']] = dep
        
        for name in unique_names:
            loaded_dep = loader.get_by_name(name)
            assert loaded_dep is not None, f"Dependency {name} not found"
        
        # Property 3: Types should be preserved for unique names
        for name, orig_dep in unique_names.items():
            loaded_dep = loader.get_by_name(name)
            assert loaded_dep.type == orig_dep['type'], \
                f"Type mismatch for {name}: {loaded_dep.type} != {orig_dep['type']}"
        
        # Property 4: Dependencies should be preserved for unique names
        for name, orig_dep in unique_names.items():
            loaded_dep = loader.get_by_name(name)
            assert len(loaded_dep.dependencies) == len(orig_dep['dependencies']), \
                f"Dependency count mismatch for {name}"
        
        # Property 5: Type-based indexing should work correctly
        for dep_type in ['COB', 'JCL', 'TRANSACTION', 'CPY']:
            expected_count = sum(1 for d in dependencies if d['type'] == dep_type)
            actual_count = len(loader.get_by_type(dep_type))
            assert actual_count == expected_count, \
                f"Type index mismatch for {dep_type}: {actual_count} != {expected_count}"
        
        # Property 6: Loader should report as loaded
        assert loader.is_loaded(), "Loader should report as loaded after successful load"
        
    finally:
        # Clean up temporary file
        Path(temp_path).unlink(missing_ok=True)


@given(
    dependencies=atx_dependencies_file(),
    program_name=st.text(min_size=1, max_size=50)
)
@settings(max_examples=100, deadline=None)
def test_property_2_dependency_relationship_preservation(dependencies, program_name):
    """
    Feature: atx-dependency-transformer, Property 2: Dependency Relationship Preservation
    
    For any program in dependencies.json with call dependencies, the loaded call graph
    should preserve all caller-callee relationships exactly as specified in the input.
    
    Validates: Requirements AC-1.1
    """
    # Add a program with known call dependencies
    test_program = {
        'name': program_name,
        'path': f'/path/to/{program_name}',
        'type': 'COB',
        'dependencies': [
            {
                'dependencyType': 'Call',
                'name': 'PROG1',
                'path': '/path/to/PROG1',
                'type': 'COB'
            },
            {
                'dependencyType': 'Call',
                'name': 'PROG2',
                'path': '/path/to/PROG2',
                'type': 'COB'
            },
            {
                'dependencyType': 'Copy',
                'name': 'COPY1',
                'path': '/path/to/COPY1',
                'type': 'CPY'
            }
        ]
    }
    dependencies.append(test_program)
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(dependencies, f)
        temp_path = f.name
    
    try:
        # Load the file
        loader = ATXDependencyLoader()
        loader.load(temp_path)
        
        # Property: All call relationships should be preserved
        calls = loader.get_program_calls(program_name)
        expected_calls = ['PROG1', 'PROG2']
        assert set(calls) == set(expected_calls), \
            f"Call relationships not preserved. Expected {expected_calls}, got {calls}"
        
        # Property: Copybook relationships should be preserved
        copybooks = loader.get_copybooks(program_name)
        expected_copybooks = ['COPY1']
        assert set(copybooks) == set(expected_copybooks), \
            f"Copybook relationships not preserved. Expected {expected_copybooks}, got {copybooks}"
        
        # Property: Non-existent programs should return empty lists
        non_existent_calls = loader.get_program_calls('NON_EXISTENT_PROGRAM')
        assert non_existent_calls == [], \
            "Non-existent program should return empty call list"
        
    finally:
        # Clean up temporary file
        Path(temp_path).unlink(missing_ok=True)


def test_property_1_with_real_data():
    """
    Test Property 1 with real CardDemo data to ensure it works with actual ATX output.
    """
    loader = ATXDependencyLoader()
    deps = loader.load('examples/atx/dependency-analysis/dependencies.json')
    
    # Verify completeness
    assert len(deps) > 0, "Should load dependencies from real file"
    assert loader.is_loaded(), "Loader should report as loaded"
    
    # Verify programs are extracted
    programs = loader.get_programs()
    assert len(programs) > 0, "Should extract programs from real file"
    
    # Verify transactions are extracted
    transactions = loader.get_transactions()
    assert len(transactions) > 0, "Should extract transactions from real file"
    
    # Verify JCL jobs are extracted
    jcl_jobs = loader.get_jcl_jobs()
    assert len(jcl_jobs) > 0, "Should extract JCL jobs from real file"
    
    # Verify indexing works
    if programs:
        prog = loader.get_by_name(programs[0].name)
        assert prog is not None, "Should find program by name"
        assert prog.name == programs[0].name, "Should return correct program"


def test_error_handling():
    """Test error handling for invalid inputs."""
    loader = ATXDependencyLoader()
    
    # Test missing file
    try:
        loader.load('nonexistent_file.json')
        assert False, "Should raise FileNotFoundError"
    except FileNotFoundError:
        pass
    
    # Test invalid JSON
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        f.write('invalid json {')
        temp_path = f.name
    
    try:
        loader.load(temp_path)
        assert False, "Should raise ValueError for invalid JSON"
    except ValueError:
        pass
    finally:
        Path(temp_path).unlink(missing_ok=True)
    
    # Test non-list JSON
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({'not': 'a list'}, f)
        temp_path = f.name
    
    try:
        loader.load(temp_path)
        assert False, "Should raise ValueError for non-list JSON"
    except ValueError:
        pass
    finally:
        Path(temp_path).unlink(missing_ok=True)
