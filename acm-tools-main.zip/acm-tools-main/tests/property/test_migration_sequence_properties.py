"""
Property-based tests for migration sequence ordering.

Feature: migration-workpackage-planner
Property 7: Migration Sequence Ordering
Validates: Requirements 3.6
"""

import pytest
from hypothesis import given, strategies as st, settings
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.models.workpackage import WorkpackageAssignment
from tools.migration_planner.phase.phase_assigner import PhaseAssigner


# Custom strategies for generating test data
@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def dag_flows_strategy(draw):
    """Generate a list of flows that form a valid DAG."""
    # Generate 1 to 15 flows
    num_flows = draw(st.integers(min_value=1, max_value=15))
    flows = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        name = f"Flow {i}"
        
        # Generate programs (1 to 10 programs)
        num_programs = draw(st.integers(min_value=1, max_value=10))
        programs = [draw(program_strategy()) for _ in range(num_programs)]
        
        # Generate databases (0 to 3 databases)
        num_databases = draw(st.integers(min_value=0, max_value=3))
        databases = [f"DB{j}" for j in range(num_databases)]
        
        composite_score = draw(st.floats(
            min_value=0.0,
            max_value=100.0,
            allow_nan=False,
            allow_infinity=False
        ))
        
        # Dependencies: can only depend on flows created before this one (DAG property)
        max_deps = min(i, 3)
        num_deps = draw(st.integers(min_value=0, max_value=max_deps))
        
        if num_deps > 0:
            dep_indices = draw(st.lists(
                st.integers(min_value=0, max_value=i-1),
                min_size=num_deps,
                max_size=num_deps,
                unique=True
            ))
            required_flows = [f"FLOW_{idx:03d}" for idx in dep_indices]
        else:
            required_flows = []
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=name,
            programs=programs,
            databases=databases,
            total_programs=len(programs),
            composite_score=composite_score,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
    
    return flows


@given(dag_flows_strategy())
@settings(max_examples=100, deadline=None)
def test_migration_sequence_ordering(flows):
    """
    Property 7: Migration Sequence Ordering
    
    For any set of phase assignments, the migration sequence should be:
    1. Ordered by phase first (ascending)
    2. Then by workpackage ID within each phase (ascending)
    3. Prerequisites should be correctly tracked
    4. Sequence numbers should be sequential starting from 1
    
    **Validates: Requirements 3.6**
    """
    # Generate workpackages
    workpackages = []
    for i, flow in enumerate(flows):
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow.flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Property 1: Sequence numbers should be sequential starting from 1
    expected_sequence_numbers = list(range(1, len(flows) + 1))
    actual_sequence_numbers = [item.sequence_number for item in migration_sequence]
    
    assert actual_sequence_numbers == expected_sequence_numbers, (
        f"Sequence numbers are not sequential: "
        f"expected {expected_sequence_numbers}, got {actual_sequence_numbers}"
    )
    
    # Property 2: Sequence should be ordered by phase first
    for i in range(len(migration_sequence) - 1):
        current_phase = migration_sequence[i].phase
        next_phase = migration_sequence[i + 1].phase
        
        assert current_phase <= next_phase, (
            f"Migration sequence not ordered by phase: "
            f"item {i} has phase {current_phase}, "
            f"but item {i+1} has phase {next_phase}"
        )
    
    # Property 3: Within each phase, items should be ordered by workpackage ID
    # Group by phase
    phase_groups = {}
    for item in migration_sequence:
        if item.phase not in phase_groups:
            phase_groups[item.phase] = []
        phase_groups[item.phase].append(item)
    
    for phase, items in phase_groups.items():
        for i in range(len(items) - 1):
            current_wp_id = items[i].workpackage_id
            next_wp_id = items[i + 1].workpackage_id
            
            assert current_wp_id <= next_wp_id, (
                f"Within phase {phase}, workpackages not ordered by ID: "
                f"workpackage {current_wp_id} comes before {next_wp_id}"
            )
    
    # Property 4: Prerequisites should be correctly tracked
    flow_map = {flow.flow_id: flow for flow in flows}
    wp_map = {wp.flow_id: wp for wp in workpackages}
    
    for item in migration_sequence:
        flow = flow_map[item.flow_id]
        
        # Get expected prerequisites (workpackage IDs of required flows)
        expected_prerequisites = []
        for req_flow_id in flow.required_flows:
            req_wp = wp_map.get(req_flow_id)
            if req_wp:
                expected_prerequisites.append(req_wp.workpackage_id)
        
        expected_prerequisites.sort()
        actual_prerequisites = sorted(item.prerequisites)
        
        assert actual_prerequisites == expected_prerequisites, (
            f"Prerequisites mismatch for flow {item.flow_id}: "
            f"expected {expected_prerequisites}, got {actual_prerequisites}"
        )
    
    # Property 5: All prerequisites should appear earlier in the sequence
    for i, item in enumerate(migration_sequence):
        # Get workpackage IDs that appear before this item
        earlier_wp_ids = {
            migration_sequence[j].workpackage_id
            for j in range(i)
        }
        
        # All prerequisites should be in earlier_wp_ids
        for prereq_wp_id in item.prerequisites:
            assert prereq_wp_id in earlier_wp_ids, (
                f"Prerequisite workpackage {prereq_wp_id} for "
                f"workpackage {item.workpackage_id} appears later in sequence"
            )
    
    # Property 6: All flows should be in the migration sequence
    sequence_flow_ids = {item.flow_id for item in migration_sequence}
    original_flow_ids = {flow.flow_id for flow in flows}
    
    assert sequence_flow_ids == original_flow_ids, (
        f"Not all flows in migration sequence: "
        f"missing {original_flow_ids - sequence_flow_ids}, "
        f"extra {sequence_flow_ids - original_flow_ids}"
    )


@given(st.integers(min_value=1, max_value=20))
@settings(max_examples=100)
def test_migration_sequence_independent_flows(num_flows):
    """
    Property 7: Migration Sequence Ordering (independent flows)
    
    For independent flows (no dependencies), the migration sequence should:
    1. Have all flows in phase 1
    2. Be ordered by workpackage ID
    3. Have no prerequisites
    
    **Validates: Requirements 3.6**
    """
    # Create independent flows
    flows = []
    workpackages = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i:03d}"
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],  # No dependencies
            dependent_flows=[]
        )
        flows.append(flow)
        
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # All items should be in phase 1
    for item in migration_sequence:
        assert item.phase == 1, (
            f"Independent flow {item.flow_id} should be in phase 1, "
            f"but is in phase {item.phase}"
        )
    
    # Should be ordered by workpackage ID
    for i in range(len(migration_sequence) - 1):
        current_wp_id = migration_sequence[i].workpackage_id
        next_wp_id = migration_sequence[i + 1].workpackage_id
        
        assert current_wp_id < next_wp_id, (
            f"Migration sequence not ordered by workpackage ID: "
            f"{current_wp_id} should come before {next_wp_id}"
        )
    
    # No prerequisites
    for item in migration_sequence:
        assert len(item.prerequisites) == 0, (
            f"Independent flow {item.flow_id} should have no prerequisites, "
            f"but has {item.prerequisites}"
        )


@given(st.integers(min_value=2, max_value=10))
@settings(max_examples=100)
def test_migration_sequence_linear_chain(chain_length):
    """
    Property 7: Migration Sequence Ordering (linear chain)
    
    For a linear chain of dependencies (A -> B -> C -> ...),
    the migration sequence should respect the dependency order.
    
    **Validates: Requirements 3.6**
    """
    # Create linear chain of flows
    flows = []
    workpackages = []
    
    for i in range(chain_length):
        flow_id = f"FLOW_{i:03d}"
        
        # Each flow depends on the previous one (except the first)
        if i == 0:
            required_flows = []
        else:
            required_flows = [f"FLOW_{i-1:03d}"]
        
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=required_flows,
            dependent_flows=[]
        )
        flows.append(flow)
        
        wp = WorkpackageAssignment(
            workpackage_id=i + 1,
            flow_id=flow_id,
            priority_score=float(i),
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Create assigner and assign phases
    assigner = PhaseAssigner()
    phase_list, migration_sequence = assigner.assign_phases(workpackages, flows)
    
    # Verify sequence order matches dependency order
    for i in range(len(migration_sequence)):
        expected_flow_id = f"FLOW_{i:03d}"
        actual_flow_id = migration_sequence[i].flow_id
        
        assert actual_flow_id == expected_flow_id, (
            f"Migration sequence order incorrect: "
            f"position {i} should have {expected_flow_id}, got {actual_flow_id}"
        )
    
    # Verify prerequisites
    for i in range(len(migration_sequence)):
        item = migration_sequence[i]
        
        if i == 0:
            # First flow should have no prerequisites
            assert len(item.prerequisites) == 0, (
                f"First flow should have no prerequisites, got {item.prerequisites}"
            )
        else:
            # Each flow should have previous flow as prerequisite
            expected_prereq = [i]  # Previous workpackage ID
            assert item.prerequisites == expected_prereq, (
                f"Flow {item.flow_id} should have prerequisite {expected_prereq}, "
                f"got {item.prerequisites}"
            )
