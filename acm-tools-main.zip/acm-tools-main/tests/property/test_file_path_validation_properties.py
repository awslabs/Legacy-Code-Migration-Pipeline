"""
Property-based tests for file path validation in migration workpackage planner CLI.

Feature: migration-workpackage-planner
Property 19: File Path Validation
"""

import tempfile
import json
from pathlib import Path
from hypothesis import given, strategies as st, settings, assume

from tools.migration_planner.cli import parse_arguments


# Hypothesis strategies for generating test data

@st.composite
def valid_flows_file_strategy(draw):
    """Generate a valid flows file with minimal content."""
    flows = [{
        'flowId': 'TEST_FLOW',
        'name': 'Test Flow',
        'scope': {
            'programs': [{'name': 'PROG1', 'isUtility': False}]
        },
        'complexity': {
            'totalPrograms': 1,
            'compositeScore': 10.0
        },
        'dependencies': {
            'requiredFlows': [],
            'dependentFlows': []
        }
    }]
    return {'flows': flows}


# Property 19: File Path Validation
# Validates: Requirements 6.7

@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_19_existing_flows_file_validates_successfully(data):
    """
    Property 19: File Path Validation
    
    For any configured flows-file path that exists, the CLI should validate
    successfully and proceed with processing.
    
    Validates: Requirements 6.7
    """
    # Create a temporary flows file
    flows_data = data.draw(valid_flows_file_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        # Parse arguments with existing file
        args = parse_arguments(['--flows-file', str(temp_path)])
        
        # Verify the file path was accepted
        assert args.flows_file == temp_path, "Flows file path should be set"
        assert args.flows_file.exists(), "Flows file should exist"
        
    finally:
        # Clean up
        temp_path.unlink()


@given(filename=st.text(min_size=1, max_size=50, alphabet=st.characters(
    whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-.'
)))
@settings(max_examples=100, deadline=None)
def test_property_19_nonexistent_flows_file_raises_error(filename):
    """
    Property 19: File Path Validation
    
    For any configured flows-file path that does not exist, the CLI should
    exit with an error before processing.
    
    Validates: Requirements 6.7
    """
    # Create a path that definitely doesn't exist
    non_existent_path = Path(f"/tmp/nonexistent_{filename}_12345.json")
    assume(not non_existent_path.exists())
    
    # Parse arguments should exit with error
    try:
        parse_arguments(['--flows-file', str(non_existent_path)])
        assert False, "Should have raised SystemExit for non-existent file"
    except SystemExit as e:
        # Should exit with non-zero code
        assert e.code != 0, "Should exit with non-zero code for missing file"


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_19_default_flows_file_path_is_validated(data):
    """
    Property 19: File Path Validation
    
    When no flows-file is specified, the CLI should validate the default path
    and raise an error if it doesn't exist.
    
    Validates: Requirements 6.7
    """
    # Parse arguments without flows-file (uses default)
    # This will fail if default doesn't exist, which is expected behavior
    default_path = Path('./results/carddemo_analysis/flows/Business_Flows.json')
    
    if default_path.exists():
        # If default exists, parsing should succeed
        args = parse_arguments([])
        assert args.flows_file == default_path, "Should use default path"
    else:
        # If default doesn't exist, should exit with error
        try:
            parse_arguments([])
            assert False, "Should have raised SystemExit for missing default file"
        except SystemExit as e:
            assert e.code != 0, "Should exit with non-zero code"


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_19_relative_paths_are_resolved(data):
    """
    Property 19: File Path Validation
    
    For any relative file path, the CLI should resolve it to an absolute path
    and validate its existence.
    
    Validates: Requirements 6.7
    """
    # Create a temporary flows file
    flows_data = data.draw(valid_flows_file_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False, dir='.') as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        # Get just the filename (relative path)
        relative_path = temp_path.name
        
        # Parse arguments with relative path
        args = parse_arguments(['--flows-file', relative_path])
        
        # Verify the path was resolved and exists
        assert args.flows_file.exists(), "Resolved path should exist"
        assert args.flows_file.name == relative_path, "Filename should match"
        
    finally:
        # Clean up
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_19_absolute_paths_are_validated(data):
    """
    Property 19: File Path Validation
    
    For any absolute file path, the CLI should validate its existence.
    
    Validates: Requirements 6.7
    """
    # Create a temporary flows file
    flows_data = data.draw(valid_flows_file_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name).resolve()  # Get absolute path
    
    try:
        # Parse arguments with absolute path
        args = parse_arguments(['--flows-file', str(temp_path)])
        
        # Verify the path was accepted and exists
        assert args.flows_file.exists(), "Absolute path should exist"
        assert args.flows_file.is_absolute() or temp_path.is_absolute(), \
            "Path should be absolute"
        
    finally:
        # Clean up
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_19_classifications_file_is_optional(data):
    """
    Property 19: File Path Validation
    
    The classifications file is optional and should not cause validation errors
    if not provided or if it doesn't exist (handled gracefully by loader).
    
    Validates: Requirements 6.7
    """
    # Create a temporary flows file
    flows_data = data.draw(valid_flows_file_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        # Parse arguments without classifications file
        args = parse_arguments(['--flows-file', str(temp_path)])
        
        # Verify classifications file is None
        assert args.classifications_file is None, \
            "Classifications file should be None when not provided"
        
        # Parse arguments with non-existent classifications file
        # This should not cause parse_arguments to fail (loader handles it)
        non_existent = Path('/tmp/nonexistent_classifications.json')
        args2 = parse_arguments([
            '--flows-file', str(temp_path),
            '--classifications-file', str(non_existent)
        ])
        
        # Verify classifications file is set (even if doesn't exist)
        assert args2.classifications_file == non_existent, \
            "Classifications file path should be set"
        
    finally:
        # Clean up
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_19_output_base_path_does_not_require_existence(data):
    """
    Property 19: File Path Validation
    
    The output base path does not need to exist before processing (it will be
    created by the output generator).
    
    Validates: Requirements 6.7
    """
    # Create a temporary flows file
    flows_data = data.draw(valid_flows_file_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        # Parse arguments with non-existent output path
        non_existent_output = Path('/tmp/nonexistent_output_dir')
        args = parse_arguments([
            '--flows-file', str(temp_path),
            '--output-base', str(non_existent_output)
        ])
        
        # Verify output path is set (even if doesn't exist)
        assert args.output_base == non_existent_output, \
            "Output base path should be set"
        
    finally:
        # Clean up
        temp_path.unlink()
