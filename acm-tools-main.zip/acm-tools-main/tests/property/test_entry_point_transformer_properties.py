"""
Property-based tests for EntryPointTransformer.

Tests universal properties that should hold for all entry point transformations.
"""

from hypothesis import given, strategies as st, settings, assume
import json
from pathlib import Path
from tools.atx.dependency_transformer.transformers import EntryPointTransformer
from tools.atx.dependency_transformer.loaders import ATXDependencyLoader
from tools.atx.dependency_transformer.analysis import CallGraphAnalyzer
from tools.atx.dependency_transformer.models.config_models import TransformationConfig


def setup_transformer():
    """
    Set up an EntryPointTransformer with real CardDemo data.
    
    Returns:
        Tuple of (transformer, dependency_loader, call_graph)
    """
    # Load dependencies
    dep_loader = ATXDependencyLoader()
    dep_loader.load('examples/atx/dependency-analysis/dependencies.json')
    
    # Build call graph
    call_graph = CallGraphAnalyzer()
    program_calls = {}
    for dep in dep_loader.get_all_dependencies():
        if dep.type == 'COB':
            calls = dep_loader.get_program_calls(dep.name)
            program_calls[dep.name] = calls
    call_graph.build_call_graph(program_calls)
    
    # Create config
    config = TransformationConfig()
    
    # Create transformer
    transformer = EntryPointTransformer(
        dependency_loader=dep_loader,
        call_graph=call_graph,
        config=config
    )
    
    return transformer, dep_loader, call_graph


def test_property_15_entry_point_source_mapping():
    """
    Feature: atx-dependency-transformer, Property 15: Entry Point Source Mapping
    
    For any entry point, if derived from a TRANSACTION type, it should have
    entry_type="ONLINE", source="CSD", and confidence="EXPLICIT"; if derived
    from JCL, it should have entry_type="BATCH", source="JCL", and
    confidence="EXPLICIT"; if inferred from call graph, it should have
    entry_type="INFERRED", source="CODE_ANALYSIS", and confidence="INFERRED".
    
    Validates: Requirements AC-3.1, AC-3.2, AC-3.3, AC-3.4, AC-3.5
    """
    transformer, dep_loader, call_graph = setup_transformer()
    
    # Transform all entry points
    entry_points = transformer.transform()
    
    # Property: All entry points should have correct source mapping
    for ep in entry_points:
        if ep.entry_type == "ONLINE":
            # ONLINE entry points should come from CICS transactions
            assert ep.source == "CSD", \
                f"ONLINE entry point {ep.program_name} should have source=CSD, got {ep.source}"
            assert ep.confidence == "EXPLICIT", \
                f"ONLINE entry point {ep.program_name} should have confidence=EXPLICIT, got {ep.confidence}"
            assert ep.transaction_id is not None, \
                f"ONLINE entry point {ep.program_name} should have transaction_id"
            assert ep.jcl_name is None, \
                f"ONLINE entry point {ep.program_name} should not have jcl_name"
        
        elif ep.entry_type == "BATCH":
            # BATCH entry points should come from JCL
            assert ep.source == "JCL", \
                f"BATCH entry point {ep.program_name} should have source=JCL, got {ep.source}"
            assert ep.confidence == "EXPLICIT", \
                f"BATCH entry point {ep.program_name} should have confidence=EXPLICIT, got {ep.confidence}"
            assert ep.jcl_name is not None, \
                f"BATCH entry point {ep.program_name} should have jcl_name"
            assert ep.transaction_id is None, \
                f"BATCH entry point {ep.program_name} should not have transaction_id"
        
        elif ep.entry_type == "INFERRED":
            # INFERRED entry points should come from code analysis
            assert ep.source == "CODE_ANALYSIS", \
                f"INFERRED entry point {ep.program_name} should have source=CODE_ANALYSIS, got {ep.source}"
            assert ep.confidence == "INFERRED", \
                f"INFERRED entry point {ep.program_name} should have confidence=INFERRED, got {ep.confidence}"
            assert ep.transaction_id is None, \
                f"INFERRED entry point {ep.program_name} should not have transaction_id"
            assert ep.jcl_name is None, \
                f"INFERRED entry point {ep.program_name} should not have jcl_name"
        
        else:
            raise AssertionError(f"Unknown entry_type: {ep.entry_type}")
    
    # Verify we have all three types
    online_count = sum(1 for ep in entry_points if ep.entry_type == "ONLINE")
    batch_count = sum(1 for ep in entry_points if ep.entry_type == "BATCH")
    inferred_count = sum(1 for ep in entry_points if ep.entry_type == "INFERRED")
    
    assert online_count > 0, "Should have at least one ONLINE entry point"
    assert batch_count > 0, "Should have at least one BATCH entry point"
    assert inferred_count > 0, "Should have at least one INFERRED entry point"
    
    print(f"✓ Property 15 verified: {online_count} ONLINE, {batch_count} BATCH, {inferred_count} INFERRED")


def test_property_16_inferred_entry_point_completeness():
    """
    Feature: atx-dependency-transformer, Property 16: Inferred Entry Point Completeness
    
    For any program P in the call graph with zero inbound calls and not already
    identified as an explicit entry point, P should appear in the entry points
    list with confidence="INFERRED".
    
    Validates: Requirements AC-3.3
    """
    transformer, dep_loader, call_graph = setup_transformer()
    
    # Transform all entry points
    entry_points = transformer.transform()
    
    # Get programs with no inbound calls from call graph
    inferred_programs = call_graph.find_entry_points()
    
    # Get explicit entry points (ONLINE and BATCH)
    explicit_programs = {
        ep.program_name for ep in entry_points 
        if ep.confidence == "EXPLICIT"
    }
    
    # Get inferred entry points from transformation
    inferred_entry_points = {
        ep.program_name for ep in entry_points 
        if ep.confidence == "INFERRED"
    }
    
    # Property: All programs with no inbound calls (excluding explicit entry points)
    # should be in the inferred entry points list
    for program in inferred_programs:
        if program not in explicit_programs:
            assert program in inferred_entry_points, \
                f"Program {program} has no inbound calls and is not explicit, " \
                f"so it should be in inferred entry points"
    
    # Property: All inferred entry points should have no inbound calls
    # (unless they are also explicit entry points)
    for ep in entry_points:
        if ep.confidence == "INFERRED":
            # This program should have no inbound calls
            assert ep.program_name in inferred_programs, \
                f"Inferred entry point {ep.program_name} should have no inbound calls"
    
    print(f"✓ Property 16 verified: {len(inferred_entry_points)} inferred entry points, "
          f"{len(explicit_programs)} explicit entry points")


def test_entry_point_uniqueness():
    """
    Additional property: Entry points should not have duplicate program names
    with the same entry type.
    
    A program can appear multiple times if it's both BATCH and ONLINE, but
    should not appear twice with the same entry type.
    """
    transformer, dep_loader, call_graph = setup_transformer()
    
    # Transform all entry points
    entry_points = transformer.transform()
    
    # Check for duplicates
    seen = set()
    for ep in entry_points:
        key = (ep.program_name, ep.entry_type)
        assert key not in seen, \
            f"Duplicate entry point: {ep.program_name} with type {ep.entry_type}"
        seen.add(key)
    
    print(f"✓ Entry point uniqueness verified: {len(entry_points)} unique entry points")


def test_entry_point_transaction_mapping():
    """
    Additional property: Each unique program referenced by TRANSACTION entries
    should have exactly one ONLINE entry point.
    """
    transformer, dep_loader, call_graph = setup_transformer()
    
    # Transform all entry points
    entry_points = transformer.transform()
    
    # Get all transactions
    transactions = dep_loader.get_transactions()
    
    # Get all ONLINE entry points
    online_entry_points = [ep for ep in entry_points if ep.entry_type == "ONLINE"]
    
    # Count unique programs referenced by transactions
    unique_programs = set()
    for trans in transactions:
        for dep in trans.dependencies:
            if dep.get("type") == "COB":
                program_file = dep.get("name", "")
                if program_file:
                    # Extract program name
                    if program_file.endswith(".cbl"):
                        program_name = program_file[:-4]
                    else:
                        program_name = program_file
                    unique_programs.add(program_name)
    
    # Property: Number of ONLINE entry points should match number of unique programs
    online_count = len(online_entry_points)
    expected_count = len(unique_programs)
    
    assert online_count == expected_count, \
        f"Expected {expected_count} ONLINE entry points (one per unique program), " \
        f"got {online_count}"
    
    # Property: Each ONLINE entry point should have a valid transaction_id
    for ep in online_entry_points:
        assert ep.transaction_id is not None, \
            f"ONLINE entry point {ep.program_name} should have transaction_id"
        assert len(ep.transaction_id) > 0, \
            f"ONLINE entry point {ep.program_name} should have non-empty transaction_id"
    
    print(f"✓ Transaction mapping verified: {online_count} ONLINE entry points from "
          f"{expected_count} unique programs")


def test_entry_point_jcl_mapping():
    """
    Additional property: Each JCL job with COB dependencies should produce
    BATCH entry points for those programs.
    """
    transformer, dep_loader, call_graph = setup_transformer()
    
    # Transform all entry points
    entry_points = transformer.transform()
    
    # Get all JCL jobs
    jcl_jobs = dep_loader.get_jcl_jobs()
    
    # Get all BATCH entry points
    batch_entry_points = [ep for ep in entry_points if ep.entry_type == "BATCH"]
    
    # Count expected BATCH entry points
    expected_batch_programs = set()
    for jcl in jcl_jobs:
        for dep in jcl.dependencies:
            if dep.get("type") == "COB":
                program_file = dep.get("name", "")
                if program_file:
                    # Extract program name
                    if "." in program_file:
                        program_name = program_file.rsplit(".", 1)[0]
                    else:
                        program_name = program_file
                    expected_batch_programs.add(program_name)
    
    # Get actual BATCH program names
    actual_batch_programs = {ep.program_name for ep in batch_entry_points}
    
    # Property: All expected BATCH programs should be in entry points
    for program in expected_batch_programs:
        assert program in actual_batch_programs, \
            f"Expected BATCH entry point for program {program} from JCL"
    
    # Property: Each BATCH entry point should have a valid jcl_name
    for ep in batch_entry_points:
        assert ep.jcl_name is not None, \
            f"BATCH entry point {ep.program_name} should have jcl_name"
        assert len(ep.jcl_name) > 0, \
            f"BATCH entry point {ep.program_name} should have non-empty jcl_name"
    
    print(f"✓ JCL mapping verified: {len(batch_entry_points)} BATCH entry points from "
          f"{len(expected_batch_programs)} JCL programs")


if __name__ == "__main__":
    # Run all property tests
    print("Running EntryPointTransformer property tests...\n")
    
    test_property_15_entry_point_source_mapping()
    test_property_16_inferred_entry_point_completeness()
    test_entry_point_uniqueness()
    test_entry_point_transaction_mapping()
    test_entry_point_jcl_mapping()
    
    print("\n✓ All property tests passed!")
