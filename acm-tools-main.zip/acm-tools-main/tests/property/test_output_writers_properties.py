"""
Property-based tests for output writers.

Tests universal properties of output writing including CSV consistency
and schema conformance.
"""

import json
import csv
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st
import hypothesis

from tools.atx.dependency_transformer.writers import (
    FlowWriter, JobWriter, EntryPointWriter
)
from tools.atx.dependency_transformer.models.legacy_models import (
    Flow, Job, EntryPointRecord, EntryPoint, EntryPointType, Caller,
    Scope, Program, DataOperations, Complexity, FlowDependencies,
    JobStep, JobDependencies
)


# Strategy for generating valid names
valid_names = st.text(
    alphabet=st.characters(whitelist_categories=("Lu", "Ll", "Nd"), whitelist_characters="_-"),
    min_size=1,
    max_size=50
)

program_names = st.text(
    alphabet=st.characters(whitelist_categories=("Lu", "Nd")),
    min_size=1,
    max_size=8
)


@st.composite
def entry_point_record_strategy(draw):
    """Generate a valid EntryPointRecord object."""
    program_name = draw(program_names)
    entry_type = draw(st.sampled_from(["ONLINE", "BATCH", "INFERRED"]))
    confidence = draw(st.sampled_from(["EXPLICIT", "INFERRED"]))
    source = draw(st.sampled_from(["CSD", "JCL", "CODE_ANALYSIS"]))
    
    # Optional fields
    description = draw(st.one_of(st.none(), st.text(min_size=1, max_size=100)))
    transaction_id = draw(st.one_of(st.none(), st.text(min_size=1, max_size=8)))
    jcl_name = draw(st.one_of(st.none(), st.text(min_size=1, max_size=8)))
    status = draw(st.one_of(st.none(), st.sampled_from(["ENABLED", "DISABLED"])))
    
    return EntryPointRecord(
        program_name=program_name,
        entry_type=entry_type,
        confidence=confidence,
        source=source,
        description=description,
        transaction_id=transaction_id,
        jcl_name=jcl_name,
        status=status
    )


@st.composite
def flow_strategy(draw):
    """Generate a valid Flow object."""
    flow_id = draw(st.text(min_size=1, max_size=20))
    name = draw(valid_names)
    program = draw(program_names)
    
    entry_point = EntryPoint(
        program=program,
        types=[
            EntryPointType(
                type="CICS_TRANSACTION",
                callers=[Caller(source="TRAN001", metadata={})]
            )
        ],
        primary_type="CICS_TRANSACTION"
    )
    
    num_programs = draw(st.integers(min_value=1, max_value=10))
    programs = [
        Program(name=draw(program_names), is_utility=draw(st.booleans()))
        for _ in range(num_programs)
    ]
    scope = Scope(programs=programs, copybooks=[], datasets=[])
    
    cc = draw(st.integers(min_value=0, max_value=1000))
    loc = draw(st.integers(min_value=0, max_value=100000))
    composite_score = (cc * 0.3) + (loc / 100 * 0.7)
    
    if composite_score < 10:
        tier = "LOW"
    elif composite_score < 20:
        tier = "MEDIUM"
    else:
        tier = "HIGH"
    
    complexity = Complexity(
        total_programs=num_programs,
        total_lines=loc,
        cyclomatic_complexity=cc,
        composite_score=composite_score,
        tier=tier
    )
    
    return Flow(
        flow_id=flow_id,
        name=name,
        entry_point=entry_point,
        scope=scope,
        interfaces={},
        data_operations=DataOperations(),
        complexity=complexity,
        dependencies=FlowDependencies(),
        invoked_by_jobs=[]
    )


@st.composite
def job_strategy(draw):
    """Generate a valid Job object."""
    job_name = draw(program_names)
    job_type = draw(st.sampled_from(["APPLICATION", "INFRASTRUCTURE"]))
    has_custom_code = draw(st.booleans())
    
    num_steps = draw(st.integers(min_value=1, max_value=10))
    steps = [
        JobStep(
            step_name=f"STEP{i:02d}",
            program=draw(program_names),
            type=draw(st.sampled_from(["CUSTOM", "UTILITY"])),
            purpose="",
            flow_entry=False
        )
        for i in range(num_steps)
    ]
    
    return Job(
        job_name=job_name,
        job_type=job_type,
        has_custom_code=has_custom_code,
        linked_flow=None,
        steps=steps,
        datasets=[],
        dependencies=JobDependencies()
    )


@given(entry_points=st.lists(entry_point_record_strategy(), min_size=1, max_size=20))
@hypothesis.settings(max_examples=100, deadline=None)
def test_property_17_entry_point_csv_consistency(entry_points):
    """
    Feature: atx-dependency-transformer, Property 17: Entry Point CSV Consistency
    
    For any entry point in entry_points.json, a corresponding row should exist
    in entry_points.csv with matching values for all common fields.
    
    Validates: Requirements AC-3.7
    """
    writer = EntryPointWriter(pretty_print=True, indent=2)
    
    with tempfile.TemporaryDirectory() as temp_dir:
        # Write entry points
        writer.write(entry_points, temp_dir)
        
        # Read JSON
        with open(Path(temp_dir) / "entry_points.json") as f:
            json_data = json.load(f)
        
        # Read CSV
        with open(Path(temp_dir) / "exports" / "entry_points.csv") as f:
            csv_reader = csv.DictReader(f)
            csv_data = list(csv_reader)
        
        # Verify same number of entries
        assert len(json_data) == len(csv_data), \
            "JSON and CSV should have the same number of entries"
        
        # Verify each entry matches
        for json_entry, csv_entry in zip(json_data, csv_data):
            # Check required fields
            assert json_entry["programName"] == csv_entry["program_name"]
            assert json_entry["entryType"] == csv_entry["entry_type"]
            assert json_entry["confidence"] == csv_entry["confidence"]
            assert json_entry["source"] == csv_entry["source"]
            
            # Check optional fields (JSON uses camelCase, CSV uses snake_case)
            if "description" in json_entry:
                assert json_entry["description"] == csv_entry["description"]
            else:
                assert csv_entry["description"] == ""
            
            if "transactionId" in json_entry:
                assert json_entry["transactionId"] == csv_entry["transaction_id"]
            else:
                assert csv_entry["transaction_id"] == ""
            
            if "jclName" in json_entry:
                assert json_entry["jclName"] == csv_entry["jcl_name"]
            else:
                assert csv_entry["jcl_name"] == ""
            
            if "status" in json_entry:
                assert json_entry["status"] == csv_entry["status"]
            else:
                assert csv_entry["status"] == ""


@given(flows=st.lists(flow_strategy(), min_size=1, max_size=10))
@hypothesis.settings(max_examples=100, deadline=None)
def test_property_18_flow_schema_conformance(flows):
    """
    Feature: atx-dependency-transformer, Property 18: Output Schema Conformance (Flows)
    
    For any generated Business_Flows.json, the JSON structure should conform
    to the legacy_analyzer schema with all required fields present and correctly typed.
    
    Validates: Requirements AC-1.10
    """
    writer = FlowWriter(pretty_print=True, indent=2)
    
    with tempfile.TemporaryDirectory() as temp_dir:
        # Write flows
        writer.write(flows, temp_dir)
        
        # Read Business_Flows.json
        with open(Path(temp_dir) / "flows" / "Business_Flows.json") as f:
            flows_data = json.load(f)
        
        # Verify it's a list
        assert isinstance(flows_data, list), "Business_Flows.json should contain a list"
        
        # Verify each flow has required fields
        for flow_data in flows_data:
            # Required top-level fields
            assert "flowId" in flow_data
            assert "name" in flow_data
            assert "entryPoint" in flow_data
            assert "scope" in flow_data
            assert "dataOperations" in flow_data
            assert "complexity" in flow_data
            assert "dependencies" in flow_data
            
            # Entry point structure
            ep = flow_data["entryPoint"]
            assert "program" in ep
            assert "types" in ep
            assert "primaryType" in ep
            assert isinstance(ep["types"], list)
            
            # Scope structure
            scope = flow_data["scope"]
            assert "programs" in scope
            assert "copybooks" in scope
            assert "datasets" in scope
            assert isinstance(scope["programs"], list)
            assert isinstance(scope["copybooks"], list)
            assert isinstance(scope["datasets"], list)
            
            # Complexity structure
            complexity = flow_data["complexity"]
            assert "totalPrograms" in complexity
            assert "totalLines" in complexity
            assert "cyclomaticComplexity" in complexity
            assert "compositeScore" in complexity
            assert "tier" in complexity
            assert isinstance(complexity["totalPrograms"], int)
            assert isinstance(complexity["totalLines"], int)
            assert isinstance(complexity["cyclomaticComplexity"], int)
            assert isinstance(complexity["compositeScore"], (int, float))
            assert complexity["tier"] in ["LOW", "MEDIUM", "HIGH"]
            
            # Dependencies structure
            deps = flow_data["dependencies"]
            assert "requiredFlows" in deps
            assert "dependentFlows" in deps
            assert isinstance(deps["requiredFlows"], list)
            assert isinstance(deps["dependentFlows"], list)


@given(jobs=st.lists(job_strategy(), min_size=1, max_size=10))
@hypothesis.settings(max_examples=100, deadline=None)
def test_property_18_job_schema_conformance(jobs):
    """
    Feature: atx-dependency-transformer, Property 18: Output Schema Conformance (Jobs)
    
    For any generated jobs.json, the JSON structure should conform to the
    legacy_analyzer schema with all required fields present and correctly typed.
    
    Validates: Requirements AC-2.6
    """
    writer = JobWriter(pretty_print=True, indent=2)
    
    with tempfile.TemporaryDirectory() as temp_dir:
        # Write jobs
        writer.write(jobs, temp_dir)
        
        # Read jobs.json
        with open(Path(temp_dir) / "jobs" / "jobs.json") as f:
            jobs_data = json.load(f)
        
        # Verify it's a list
        assert isinstance(jobs_data, list), "jobs.json should contain a list"
        
        # Verify each job has required fields
        for job_data in jobs_data:
            # Required top-level fields
            assert "jobName" in job_data
            assert "jobType" in job_data
            assert "hasCustomCode" in job_data
            assert "steps" in job_data
            assert "datasets" in job_data
            assert "dependencies" in job_data
            
            # Type validation
            assert isinstance(job_data["jobName"], str)
            assert job_data["jobType"] in ["APPLICATION", "INFRASTRUCTURE"]
            assert isinstance(job_data["hasCustomCode"], bool)
            assert isinstance(job_data["steps"], list)
            assert isinstance(job_data["datasets"], list)
            
            # Steps structure
            for step in job_data["steps"]:
                assert "stepName" in step
                assert "program" in step
                assert "type" in step
                assert step["type"] in ["CUSTOM", "UTILITY"]
                assert isinstance(step["flowEntry"], bool)
            
            # Dependencies structure
            deps = job_data["dependencies"]
            assert "mustRunAfter" in deps
            assert "mustRunBefore" in deps
            assert isinstance(deps["mustRunAfter"], list)
            assert isinstance(deps["mustRunBefore"], list)


@given(entry_points=st.lists(entry_point_record_strategy(), min_size=1, max_size=10))
@hypothesis.settings(max_examples=100, deadline=None)
def test_property_18_entry_point_schema_conformance(entry_points):
    """
    Feature: atx-dependency-transformer, Property 18: Output Schema Conformance (Entry Points)
    
    For any generated entry_points.json, the JSON structure should conform to the
    legacy_analyzer schema with all required fields present and correctly typed.
    
    Validates: Requirements AC-3.6
    """
    writer = EntryPointWriter(pretty_print=True, indent=2)
    
    with tempfile.TemporaryDirectory() as temp_dir:
        # Write entry points
        writer.write(entry_points, temp_dir)
        
        # Read entry_points.json
        with open(Path(temp_dir) / "entry_points.json") as f:
            entry_points_data = json.load(f)
        
        # Verify it's a list
        assert isinstance(entry_points_data, list), "entry_points.json should contain a list"
        
        # Verify each entry point has required fields
        for ep_data in entry_points_data:
            # Required fields
            assert "programName" in ep_data
            assert "entryType" in ep_data
            assert "confidence" in ep_data
            assert "source" in ep_data
            
            # Type validation
            assert isinstance(ep_data["programName"], str)
            assert ep_data["entryType"] in ["ONLINE", "BATCH", "INFERRED"]
            assert ep_data["confidence"] in ["EXPLICIT", "INFERRED"]
            assert ep_data["source"] in ["CSD", "JCL", "CODE_ANALYSIS"]
            
            # Optional fields should be strings if present
            if "description" in ep_data:
                assert isinstance(ep_data["description"], str)
            if "transactionId" in ep_data:
                assert isinstance(ep_data["transactionId"], str)
            if "jclName" in ep_data:
                assert isinstance(ep_data["jclName"], str)
            if "status" in ep_data:
                assert isinstance(ep_data["status"], str)
