"""
Property-based tests for logging completeness in migration workpackage planner.

Feature: migration-workpackage-planner
Property 18: Logging Completeness
"""

import json
import tempfile
import logging
from pathlib import Path
from io import StringIO
from hypothesis import given, strategies as st, settings, assume

from tools.migration_planner.planner import MigrationPlanner
from tools.migration_planner.models import PlannerConfig
from tools.migration_planner.logging_config import setup_logging


# Hypothesis strategies for generating test data

@st.composite
def valid_flows_strategy(draw):
    """Generate valid flows for testing."""
    num_flows = draw(st.integers(min_value=1, max_value=5))
    flows = []
    
    for i in range(num_flows):
        flow_id = f"FLOW_{i}_{draw(st.integers(min_value=1, max_value=1000))}"
        flows.append({
            'flowId': flow_id,
            'name': f'Flow {i}',
            'scope': {
                'programs': [
                    {'name': f'PROG{i}_{j}', 'isUtility': False}
                    for j in range(draw(st.integers(min_value=1, max_value=3)))
                ]
            },
            'complexity': {
                'totalPrograms': draw(st.integers(min_value=1, max_value=10)),
                'compositeScore': draw(st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False))
            },
            'dependencies': {
                'requiredFlows': [],
                'dependentFlows': []
            }
        })
    
    return {'flows': flows}


@st.composite
def flows_with_missing_classifications_strategy(draw):
    """Generate flows for testing missing classifications warning."""
    flows_data = draw(valid_flows_strategy())
    return flows_data


@st.composite
def invalid_json_strategy(draw):
    """Generate invalid JSON for error logging."""
    return draw(st.sampled_from([
        '{"flows": [invalid}',
        '{"flows": [{"flowId": "test",}]}',
    ]))


class LogCapture:
    """Helper class to capture log messages."""
    
    def __init__(self, level=logging.DEBUG):
        self.stream = StringIO()
        self.handler = logging.StreamHandler(self.stream)
        self.handler.setLevel(level)
        formatter = logging.Formatter('%(levelname)s - %(message)s')
        self.handler.setFormatter(formatter)
        # Capture from root migration_planner logger and all children
        self.loggers = [
            logging.getLogger('migration_planner'),
            logging.getLogger('tools.migration_planner'),
        ]
        self.original_state = []
        
    def __enter__(self):
        # Add handler to all loggers
        for logger in self.loggers:
            self.original_state.append({
                'logger': logger,
                'level': logger.level,
                'propagate': logger.propagate,
                'handlers': logger.handlers.copy()
            })
            logger.addHandler(self.handler)
            logger.setLevel(logging.DEBUG)
            logger.propagate = True  # Allow propagation to capture all messages
        return self
    
    def __exit__(self, *args):
        # Restore original state
        for state in self.original_state:
            logger = state['logger']
            logger.removeHandler(self.handler)
            logger.setLevel(state['level'])
            logger.propagate = state['propagate']
    
    def get_logs(self):
        return self.stream.getvalue()
    
    def has_level(self, level):
        """Check if logs contain messages at the specified level."""
        logs = self.get_logs()
        return level.upper() in logs
    
    def has_message(self, message):
        """Check if logs contain a specific message."""
        logs = self.get_logs().lower()
        return message.lower() in logs


# Property 18: Logging Completeness
# Validates: Requirements 7.1, 7.2, 7.3, 7.6, 7.7

@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_18_successful_execution_logs_info_messages(data):
    """
    Property 18: Logging Completeness
    
    For any successful execution, the system should log informational messages
    for major processing steps with timestamps and severity levels.
    
    Validates: Requirements 7.1, 7.6, 7.7
    """
    flows_data = data.draw(valid_flows_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        with tempfile.TemporaryDirectory() as output_dir:
            config = PlannerConfig(
                flows_file=temp_path,
                output_base=Path(output_dir),
                project_name='test'
            )
            
            with LogCapture() as log_capture:
                planner = MigrationPlanner(config)
                result = planner.run()
                
                if result.success:
                    logs = log_capture.get_logs()
                    
                    # Should have INFO level messages
                    assert log_capture.has_level('INFO'), \
                        "Should have INFO level messages"
                    
                    # Should log major processing steps
                    assert log_capture.has_message('loading'), \
                        "Should log loading step"
                    assert log_capture.has_message('calculating') or log_capture.has_message('priority'), \
                        "Should log priority calculation step"
                    assert log_capture.has_message('assigning') or log_capture.has_message('workpackage'), \
                        "Should log workpackage assignment step"
                    assert log_capture.has_message('phase') or log_capture.has_message('determining'), \
                        "Should log phase determination step"
                    assert log_capture.has_message('generating') or log_capture.has_message('output'), \
                        "Should log output generation step"
    
    finally:
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_18_missing_optional_file_logs_warning(data):
    """
    Property 18: Logging Completeness
    
    For any execution with missing optional files (classifications), the system
    should log warning messages.
    
    Validates: Requirements 7.2, 7.6, 7.7
    """
    flows_data = data.draw(flows_with_missing_classifications_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        with tempfile.TemporaryDirectory() as output_dir:
            # Use non-existent classifications file
            non_existent_classifications = Path('/tmp/nonexistent_classifications.json')
            
            config = PlannerConfig(
                flows_file=temp_path,
                output_base=Path(output_dir),
                project_name='test',
                classifications_file=non_existent_classifications
            )
            
            with LogCapture() as log_capture:
                planner = MigrationPlanner(config)
                result = planner.run()
                
                if result.success:
                    # Should have WARNING level messages
                    assert log_capture.has_level('WARNING') or log_capture.has_level('INFO'), \
                        "Should have WARNING or INFO level messages for missing optional file"
                    
                    # Should mention classifications or missing file
                    logs_lower = log_capture.get_logs().lower()
                    assert 'classification' in logs_lower or 'no module' in logs_lower or 'not found' in logs_lower, \
                        "Should log about missing classifications"
    
    finally:
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_18_validation_failure_logs_error(data):
    """
    Property 18: Logging Completeness
    
    For any validation failure, the system should log error messages with context.
    
    Validates: Requirements 7.3, 7.6, 7.7
    """
    invalid_content = data.draw(invalid_json_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        f.write(invalid_content)
        temp_path = Path(f.name)
    
    try:
        with tempfile.TemporaryDirectory() as output_dir:
            config = PlannerConfig(
                flows_file=temp_path,
                output_base=Path(output_dir),
                project_name='test'
            )
            
            with LogCapture() as log_capture:
                planner = MigrationPlanner(config)
                result = planner.run()
                
                # Should not succeed
                assert not result.success, "Should fail with invalid JSON"
                
                # Should have ERROR level messages
                assert log_capture.has_level('ERROR'), \
                    "Should have ERROR level messages for validation failure"
                
                # Error message should have context
                logs_lower = log_capture.get_logs().lower()
                assert 'error' in logs_lower or 'validation' in logs_lower or 'json' in logs_lower, \
                    "Should log error with context"
    
    finally:
        temp_path.unlink()


@given(log_level=st.sampled_from(['DEBUG', 'INFO', 'WARNING', 'ERROR']))
@settings(max_examples=100, deadline=None)
def test_property_18_logging_respects_configured_level(log_level):
    """
    Property 18: Logging Completeness
    
    For any configured log level, the system should respect it and only log
    messages at or above that level.
    
    Validates: Requirements 7.7
    """
    # Set up logging with specific level
    logger = setup_logging(log_level=log_level)
    
    # Verify logger level is set correctly
    numeric_level = getattr(logging, log_level.upper())
    assert logger.level == numeric_level, \
        f"Logger level should be {log_level} ({numeric_level})"


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_18_all_log_messages_have_timestamps(data):
    """
    Property 18: Logging Completeness
    
    For any execution, all log messages should include timestamps.
    
    Validates: Requirements 7.6
    """
    flows_data = data.draw(valid_flows_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        with tempfile.TemporaryDirectory() as output_dir:
            config = PlannerConfig(
                flows_file=temp_path,
                output_base=Path(output_dir),
                project_name='test'
            )
            
            # Create custom log capture with timestamp format
            stream = StringIO()
            handler = logging.StreamHandler(stream)
            handler.setLevel(logging.DEBUG)
            formatter = logging.Formatter(
                fmt='%(asctime)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            
            logger = logging.getLogger('migration_planner')
            original_handlers = logger.handlers.copy()
            logger.handlers.clear()
            logger.addHandler(handler)
            logger.setLevel(logging.DEBUG)
            
            try:
                planner = MigrationPlanner(config)
                result = planner.run()
                
                logs = stream.getvalue()
                
                if logs:
                    # Check that log lines contain timestamps (YYYY-MM-DD format)
                    log_lines = [line for line in logs.split('\n') if line.strip()]
                    
                    if log_lines:
                        # At least some lines should have timestamp format
                        has_timestamp = any(
                            line[0:4].isdigit() and '-' in line[0:10]
                            for line in log_lines
                        )
                        assert has_timestamp, \
                            "Log messages should include timestamps"
            
            finally:
                logger.removeHandler(handler)
                logger.handlers = original_handlers
    
    finally:
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_18_all_log_messages_have_severity_levels(data):
    """
    Property 18: Logging Completeness
    
    For any execution, all log messages should include severity levels.
    
    Validates: Requirements 7.6
    """
    flows_data = data.draw(valid_flows_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        with tempfile.TemporaryDirectory() as output_dir:
            config = PlannerConfig(
                flows_file=temp_path,
                output_base=Path(output_dir),
                project_name='test'
            )
            
            with LogCapture() as log_capture:
                planner = MigrationPlanner(config)
                result = planner.run()
                
                logs = log_capture.get_logs()
                
                if logs:
                    # Check that logs contain severity levels
                    log_lines = [line for line in logs.split('\n') if line.strip()]
                    
                    if log_lines:
                        # Should have at least one severity level
                        severity_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR']
                        has_severity = any(
                            any(level in line for level in severity_levels)
                            for line in log_lines
                        )
                        assert has_severity, \
                            "Log messages should include severity levels"
    
    finally:
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_18_logs_flow_count_and_statistics(data):
    """
    Property 18: Logging Completeness
    
    For any successful execution, the system should log statistics about the
    flows processed (count, phases, etc.).
    
    Validates: Requirements 7.1
    """
    flows_data = data.draw(valid_flows_strategy())
    num_flows = len(flows_data['flows'])
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        with tempfile.TemporaryDirectory() as output_dir:
            config = PlannerConfig(
                flows_file=temp_path,
                output_base=Path(output_dir),
                project_name='test'
            )
            
            with LogCapture() as log_capture:
                planner = MigrationPlanner(config)
                result = planner.run()
                
                if result.success:
                    logs_lower = log_capture.get_logs().lower()
                    
                    # Should log flow count
                    assert 'flow' in logs_lower, \
                        "Should log information about flows"
                    
                    # Should log phase count
                    assert 'phase' in logs_lower, \
                        "Should log information about phases"
    
    finally:
        temp_path.unlink()
