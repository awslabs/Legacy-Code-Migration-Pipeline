"""
Property-based tests for planning JSON structure.

Feature: migration-workpackage-planner
Property 10: Planning JSON Structure
Validates: Requirements 5.1, 5.2, 5.3, 5.4
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings

from tools.migration_planner.models import (
    BusinessFlow,
    Program,
    PriorityResult,
    PriorityFactors,
    WorkpackageAssignment,
    PhaseAssignment,
    MigrationSequenceItem,
    PlanningData,
    Metadata,
    Statistics,
)
from tools.migration_planner.output import OutputGenerator


# Custom strategies
@st.composite
def business_flow_strategy(draw):
    """Generate a random business flow."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    num_programs = draw(st.integers(min_value=1, max_value=10))
    programs = []
    for i in range(num_programs):
        prog_name = f"PROG{i:03d}"
        is_utility = draw(st.booleans())
        programs.append(Program(name=prog_name, is_utility=is_utility))
    
    # Generate databases
    num_dbs = draw(st.integers(min_value=0, max_value=5))
    databases = [f"DB{i}" for i in range(num_dbs)]
    
    total_programs = len(programs)
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0))
    
    return BusinessFlow(
        flow_id=flow_id,
        name=name,
        programs=programs,
        databases=databases,
        total_programs=total_programs,
        composite_score=composite_score,
        required_flows=[],
        dependent_flows=[]
    )


@st.composite
def planning_data_strategy(draw):
    """Generate random planning data."""
    project_name = draw(st.text(min_size=1, max_size=30))
    
    # Generate flows
    num_flows = draw(st.integers(min_value=1, max_value=10))
    flows = [draw(business_flow_strategy()) for _ in range(num_flows)]
    
    # Generate priorities
    priorities = {}
    for flow in flows:
        priority_score = draw(st.floats(min_value=0.0, max_value=100.0))
        factors = PriorityFactors(
            total_programs=flow.total_programs,
            common_modules=draw(st.integers(min_value=0, max_value=5)),
            composite_score=flow.composite_score,
            complete_flow_bonus=draw(st.integers(min_value=-5, max_value=0)),
            simple_flow_bonus=draw(st.integers(min_value=-3, max_value=0))
        )
        priorities[flow.flow_id] = PriorityResult(
            flow_id=flow.flow_id,
            priority_score=priority_score,
            factors=factors
        )
    
    # Generate workpackage assignments
    flow_priorities = {}
    for idx, flow in enumerate(flows, start=1):
        wp = WorkpackageAssignment(
            workpackage_id=idx,
            flow_id=flow.flow_id,
            priority_score=priorities[flow.flow_id].priority_score,
            preexistent_modules=[]
        )
        flow_priorities[flow.flow_id] = wp
    
    # Generate phases
    num_phases = draw(st.integers(min_value=1, max_value=min(5, num_flows)))
    phases = []
    workpackages_per_phase = [[] for _ in range(num_phases)]
    
    for idx, flow in enumerate(flows, start=1):
        phase_idx = idx % num_phases
        workpackages_per_phase[phase_idx].append(idx)
    
    for phase_id in range(1, num_phases + 1):
        phase = PhaseAssignment(
            phase_id=phase_id,
            workpackages=workpackages_per_phase[phase_id - 1],
            dependencies=list(range(1, phase_id))
        )
        phases.append(phase)
    
    # Generate migration sequence
    migration_sequence = []
    for seq_num, flow in enumerate(flows, start=1):
        item = MigrationSequenceItem(
            sequence_number=seq_num,
            workpackage_id=seq_num,
            flow_id=flow.flow_id,
            phase=(seq_num % num_phases) + 1,
            prerequisites=[]
        )
        migration_sequence.append(item)
    
    # Create metadata and statistics
    metadata = Metadata.create(project_name)
    statistics = Statistics.calculate(flow_priorities, phases)
    
    planning_data = PlanningData(
        metadata=metadata,
        flow_priorities=flow_priorities,
        phases=phases,
        migration_sequence=migration_sequence,
        statistics=statistics
    )
    
    return planning_data, priorities, flows


@settings(max_examples=100, deadline=None)
@given(data=planning_data_strategy())
def test_planning_json_structure(data):
    """
    Property 10: Planning JSON Structure
    
    For any planning data, the generated JSON should contain all required
    sections (metadata, flowPriorities, phases, migrationSequence, statistics)
    with all required fields populated correctly.
    
    Validates: Requirements 5.1, 5.2, 5.3, 5.4
    """
    planning_data, priorities, flows = data
    
    # Create temporary output directory
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, planning_data.metadata.project_name)
        
        # Generate planning JSON
        output_path = generator.generate_planning_json(planning_data, priorities, flows)
        
        # Verify file was created
        assert output_path.exists(), "Planning JSON file should be created"
        
        # Load and parse JSON
        with open(output_path, 'r', encoding='utf-8') as f:
            output = json.load(f)
        
        # Requirement 5.1: Contains metadata, flowPriorities, phases, migrationSequence, statistics
        assert "metadata" in output, "Output must contain metadata section"
        assert "flowPriorities" in output, "Output must contain flowPriorities section"
        assert "phases" in output, "Output must contain phases section"
        assert "migrationSequence" in output, "Output must contain migrationSequence section"
        assert "statistics" in output, "Output must contain statistics section"
        
        # Requirement 5.2: Metadata contains required fields
        metadata = output["metadata"]
        assert "projectName" in metadata, "Metadata must contain projectName"
        assert "createdDate" in metadata, "Metadata must contain createdDate"
        assert "phase" in metadata, "Metadata must contain phase"
        assert "version" in metadata, "Metadata must contain version"
        assert metadata["projectName"] == planning_data.metadata.project_name
        assert metadata["phase"] == "WORKPACKAGE_PLANNING"
        
        # Requirement 5.3: flowPriorities contains all required fields
        flow_priorities = output["flowPriorities"]
        assert len(flow_priorities) == len(planning_data.flow_priorities), \
            "flowPriorities should contain all flows"
        
        for flow_id, flow_data in flow_priorities.items():
            assert "workpackageId" in flow_data, "Flow must have workpackageId"
            assert "priorityScore" in flow_data, "Flow must have priorityScore"
            assert "phase" in flow_data, "Flow must have phase"
            assert "preExistentModules" in flow_data, "Flow must have preExistentModules"
            assert "priorityFactors" in flow_data, "Flow must have priorityFactors"
            
            # Verify priorityFactors structure
            factors = flow_data["priorityFactors"]
            assert "totalPrograms" in factors, "Factors must have totalPrograms"
            assert "commonModules" in factors, "Factors must have commonModules"
            assert "compositeScore" in factors, "Factors must have compositeScore"
            assert "completeFlowBonus" in factors, "Factors must have completeFlowBonus"
            assert "simpleFlowBonus" in factors, "Factors must have simpleFlowBonus"
        
        # Requirement 5.4: phases array contains phase metadata
        phases = output["phases"]
        assert len(phases) == len(planning_data.phases), "Phases should match planning data"
        
        for phase in phases:
            assert "phaseId" in phase, "Phase must have phaseId"
            assert "name" in phase, "Phase must have name"
            assert "workpackages" in phase, "Phase must have workpackages list"
            assert "dependencies" in phase, "Phase must have dependencies list"
            assert isinstance(phase["workpackages"], list), "Workpackages must be a list"
            assert isinstance(phase["dependencies"], list), "Dependencies must be a list"
