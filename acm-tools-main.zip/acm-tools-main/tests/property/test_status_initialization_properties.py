"""
Property-based tests for status initialization.

Feature: migration-workpackage-planner
Property 13: Status Initialization
Validates: Requirements 5.7, 10.1, 10.2, 10.3
"""

import json
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings

from tools.migration_planner.models import (
    WorkpackageAssignment,
    PhaseAssignment,
)
from tools.migration_planner.output import OutputGenerator


# Custom strategies
@st.composite
def workpackage_and_phase_strategy(draw):
    """Generate random workpackages and phases."""
    project_name = draw(st.text(min_size=1, max_size=30))
    
    # Generate workpackages
    num_workpackages = draw(st.integers(min_value=1, max_value=20))
    workpackages = []
    for i in range(1, num_workpackages + 1):
        flow_id = f"FLOW{i:03d}"
        priority_score = draw(st.floats(min_value=0.0, max_value=100.0))
        wp = WorkpackageAssignment(
            workpackage_id=i,
            flow_id=flow_id,
            priority_score=priority_score,
            preexistent_modules=[]
        )
        workpackages.append(wp)
    
    # Generate phases
    num_phases = draw(st.integers(min_value=1, max_value=min(5, num_workpackages)))
    phases = []
    workpackages_per_phase = [[] for _ in range(num_phases)]
    
    for i in range(1, num_workpackages + 1):
        phase_idx = i % num_phases
        workpackages_per_phase[phase_idx].append(i)
    
    for phase_id in range(1, num_phases + 1):
        phase = PhaseAssignment(
            phase_id=phase_id,
            workpackages=workpackages_per_phase[phase_id - 1],
            dependencies=list(range(1, phase_id))
        )
        phases.append(phase)
    
    return project_name, workpackages, phases


@settings(max_examples=100, deadline=None)
@given(data=workpackage_and_phase_strategy())
def test_status_initialization(data):
    """
    Property 13: Status Initialization
    
    For any set of workpackages, the status JSON should contain an entry
    for each workpackage with initial status "NOT_STARTED" and all required
    fields (workpackageId, flowId, phase, status, startDate, endDate, notes).
    
    Validates: Requirements 5.7, 10.1, 10.2, 10.3
    """
    project_name, workpackages, phases = data
    
    # Create temporary output directory
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, project_name)
        
        # Generate status JSON
        output_path = generator.generate_status_json(workpackages, phases)
        
        # Verify file was created
        assert output_path.exists(), "Status JSON file should be created"
        
        # Load and parse JSON
        with open(output_path, 'r', encoding='utf-8') as f:
            output = json.load(f)
        
        # Requirement 10.1: Contains entry for each workpackage
        assert "workpackages" in output, "Output must contain workpackages array"
        assert "metadata" in output, "Output must contain metadata"
        
        status_entries = output["workpackages"]
        assert len(status_entries) == len(workpackages), \
            f"Status should contain {len(workpackages)} entries, got {len(status_entries)}"
        
        # Build phase map for verification
        phase_map = {}
        for phase in phases:
            for wp_id in phase.workpackages:
                phase_map[wp_id] = phase.phase_id
        
        # Requirement 10.2: Initial status is NOT_STARTED
        # Requirement 10.3: All required fields present
        for entry in status_entries:
            # Verify all required fields exist
            assert "workpackageId" in entry, "Entry must have workpackageId"
            assert "flowId" in entry, "Entry must have flowId"
            assert "phase" in entry, "Entry must have phase"
            assert "status" in entry, "Entry must have status"
            assert "startDate" in entry, "Entry must have startDate"
            assert "endDate" in entry, "Entry must have endDate"
            assert "notes" in entry, "Entry must have notes"
            
            # Verify initial status is NOT_STARTED
            assert entry["status"] == "NOT_STARTED", \
                f"Initial status should be NOT_STARTED, got {entry['status']}"
            
            # Verify dates are null initially
            assert entry["startDate"] is None, "Initial startDate should be null"
            assert entry["endDate"] is None, "Initial endDate should be null"
            
            # Verify notes is empty string
            assert entry["notes"] == "", "Initial notes should be empty string"
            
            # Verify workpackageId matches a real workpackage
            wp_id = entry["workpackageId"]
            matching_wp = next((wp for wp in workpackages if wp.workpackage_id == wp_id), None)
            assert matching_wp is not None, f"Workpackage {wp_id} should exist"
            
            # Verify flowId matches
            assert entry["flowId"] == matching_wp.flow_id, \
                f"FlowId should match workpackage flowId"
            
            # Verify phase is correct
            expected_phase = phase_map.get(wp_id, 1)
            assert entry["phase"] == expected_phase, \
                f"Phase should be {expected_phase}, got {entry['phase']}"
        
        # Verify metadata structure
        metadata = output["metadata"]
        assert "projectName" in metadata, "Metadata must have projectName"
        assert "lastUpdated" in metadata, "Metadata must have lastUpdated"
        assert "version" in metadata, "Metadata must have version"
        assert metadata["projectName"] == project_name, "Project name should match"
        assert metadata["version"] == "1.0", "Version should be 1.0"
