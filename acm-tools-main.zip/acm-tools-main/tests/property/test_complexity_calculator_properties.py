"""
Property-based tests for ComplexityCalculator.

Tests universal properties that should hold for all complexity calculations.
"""

from hypothesis import given, strategies as st, settings, assume
from tools.atx.dependency_transformer.analysis import ComplexityCalculator
from tools.atx.dependency_transformer.models.config_models import (
    ComplexityConfig,
    ComplexityFormula,
    ComplexityTiers
)
from tools.atx.dependency_transformer.models.atx_models import ATXAssetMetrics


@given(
    cc=st.integers(min_value=0, max_value=1000),
    loc=st.integers(min_value=0, max_value=100000)
)
@settings(max_examples=100, deadline=None)
def test_property_3_composite_score_formula_correctness(cc, loc):
    """
    Feature: atx-dependency-transformer, Property 3: Composite Score Formula Correctness
    
    For any cyclomatic complexity CC and lines of code LOC, the calculated composite score
    should equal (CC × 0.3) + (LOC / 100 × 0.7) within floating-point precision.
    
    Validates: Requirements AC-1.4
    """
    calculator = ComplexityCalculator()
    
    # Calculate expected score
    expected = (cc * 0.3) + (loc / 100.0 * 0.7)
    
    # Calculate actual score
    actual = calculator.calculate_composite_score(cc, loc)
    
    # Property: Scores should match within floating-point tolerance
    assert abs(actual - expected) < 0.001, \
        f"Score mismatch: expected {expected}, got {actual} for CC={cc}, LOC={loc}"
    
    # Property: Score should be non-negative
    assert actual >= 0, \
        f"Score should be non-negative, got {actual}"
    
    # Property: Score should increase with CC
    if cc > 0:
        score_with_less_cc = calculator.calculate_composite_score(cc - 1, loc)
        assert actual >= score_with_less_cc, \
            f"Score should increase with CC: {actual} vs {score_with_less_cc}"
    
    # Property: Score should increase with LOC
    if loc > 0:
        score_with_less_loc = calculator.calculate_composite_score(cc, loc - 1)
        assert actual >= score_with_less_loc, \
            f"Score should increase with LOC: {actual} vs {score_with_less_loc}"


@given(composite_score=st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False))
@settings(max_examples=100, deadline=None)
def test_property_4_complexity_tier_classification(composite_score):
    """
    Feature: atx-dependency-transformer, Property 4: Complexity Tier Classification
    
    For any composite score S, the tier assignment should be LOW if S < 10,
    MEDIUM if 10 ≤ S < 20, and HIGH if S ≥ 20.
    
    Validates: Requirements AC-1.5
    """
    calculator = ComplexityCalculator()
    
    tier = calculator.assign_tier(composite_score)
    
    # Property: Tier should be one of the valid values
    assert tier in ["LOW", "MEDIUM", "HIGH"], \
        f"Invalid tier: {tier}"
    
    # Property: Tier should match threshold rules
    if composite_score < 10.0:
        assert tier == "LOW", \
            f"Score {composite_score} < 10 should be LOW, got {tier}"
    elif composite_score < 20.0:
        assert tier == "MEDIUM", \
            f"Score {composite_score} in [10, 20) should be MEDIUM, got {tier}"
    else:
        assert tier == "HIGH", \
            f"Score {composite_score} >= 20 should be HIGH, got {tier}"
    
    # Property: Tier should be monotonic (higher score = same or higher tier)
    if composite_score < 99.0:  # Leave room for increment
        higher_score = composite_score + 1.0
        higher_tier = calculator.assign_tier(higher_score)
        
        tier_order = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
        assert tier_order[higher_tier] >= tier_order[tier], \
            f"Tier should be monotonic: {tier} at {composite_score} vs {higher_tier} at {higher_score}"


@given(
    cc_weight=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
    loc_weight=st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
    cc=st.integers(min_value=0, max_value=500),
    loc=st.integers(min_value=0, max_value=50000)
)
@settings(max_examples=100, deadline=None)
def test_property_5_configuration_based_formula_application(cc_weight, loc_weight, cc, loc):
    """
    Feature: atx-dependency-transformer, Property 5: Configuration-Based Formula Application
    
    For any custom complexity formula weights in configuration, the composite score
    calculation should use those weights instead of defaults.
    
    Validates: Requirements AC-4.1, AC-4.3
    """
    # Create custom configuration
    config = ComplexityConfig(
        formula=ComplexityFormula(cc_weight=cc_weight, loc_weight=loc_weight)
    )
    calculator = ComplexityCalculator(config)
    
    # Calculate expected score with custom weights
    expected = (cc * cc_weight) + (loc / 100.0 * loc_weight)
    
    # Calculate actual score
    actual = calculator.calculate_composite_score(cc, loc)
    
    # Property: Score should use custom weights
    assert abs(actual - expected) < 0.001, \
        f"Score should use custom weights: expected {expected}, got {actual}"
    
    # Property: Configuration should be retrievable
    retrieved_config = calculator.get_config()
    assert retrieved_config.formula.cc_weight == cc_weight, \
        "Configuration should be retrievable"
    assert retrieved_config.formula.loc_weight == loc_weight, \
        "Configuration should be retrievable"


@given(
    low_threshold=st.floats(min_value=1.0, max_value=50.0, allow_nan=False, allow_infinity=False),
    medium_threshold=st.floats(min_value=51.0, max_value=100.0, allow_nan=False, allow_infinity=False),
    score=st.floats(min_value=0.0, max_value=150.0, allow_nan=False, allow_infinity=False)
)
@settings(max_examples=100, deadline=None)
def test_custom_tier_thresholds(low_threshold, medium_threshold, score):
    """
    Test that custom tier thresholds are applied correctly.
    
    Validates: Requirements AC-4.3
    """
    # Create custom configuration with custom thresholds
    config = ComplexityConfig(
        tiers=ComplexityTiers(
            low_threshold=low_threshold,
            medium_threshold=medium_threshold
        )
    )
    calculator = ComplexityCalculator(config)
    
    tier = calculator.assign_tier(score)
    
    # Property: Tier should match custom thresholds
    if score < low_threshold:
        assert tier == "LOW", \
            f"Score {score} < {low_threshold} should be LOW, got {tier}"
    elif score < medium_threshold:
        assert tier == "MEDIUM", \
            f"Score {score} in [{low_threshold}, {medium_threshold}) should be MEDIUM, got {tier}"
    else:
        assert tier == "HIGH", \
            f"Score {score} >= {medium_threshold} should be HIGH, got {tier}"


@given(
    num_programs=st.integers(min_value=1, max_value=20)
)
@settings(max_examples=100, deadline=None)
def test_flow_complexity_aggregation(num_programs):
    """
    Test that flow complexity correctly aggregates metrics across programs.
    
    Validates: Requirements AC-1.4, AC-1.5
    """
    calculator = ComplexityCalculator()
    
    # Create metrics for programs
    metrics = {}
    programs = []
    cc_values = []
    loc_values = []
    
    for i in range(num_programs):
        prog_name = f"PROG{i:03d}"
        programs.append(prog_name)
        
        # Generate random values for this program
        cc = i * 5  # Deterministic but varied
        loc = i * 100 + 100  # Deterministic but varied
        cc_values.append(cc)
        loc_values.append(loc)
        
        metrics[prog_name] = ATXAssetMetrics(
            name=prog_name,
            path=f"/path/to/{prog_name}",
            file_type="COB",
            cyclomatic_complexity=cc,
            total_lines=loc
        )
    
    # Calculate flow complexity
    flow_complexity = calculator.calculate_flow_complexity(programs, metrics)
    
    # Property: Total programs should match
    assert flow_complexity["total_programs"] == num_programs, \
        f"Total programs mismatch: expected {num_programs}, got {flow_complexity['total_programs']}"
    
    # Property: Total CC should be sum of individual CCs
    expected_cc = sum(cc_values)
    assert flow_complexity["cyclomatic_complexity"] == expected_cc, \
        f"Total CC mismatch: expected {expected_cc}, got {flow_complexity['cyclomatic_complexity']}"
    
    # Property: Total LOC should be sum of individual LOCs
    expected_loc = sum(loc_values)
    assert flow_complexity["total_lines"] == expected_loc, \
        f"Total LOC mismatch: expected {expected_loc}, got {flow_complexity['total_lines']}"
    
    # Property: Composite score should match formula
    expected_score = (expected_cc * 0.3) + (expected_loc / 100.0 * 0.7)
    assert abs(flow_complexity["composite_score"] - expected_score) < 0.001, \
        f"Composite score mismatch: expected {expected_score}, got {flow_complexity['composite_score']}"
    
    # Property: Tier should be correctly assigned
    expected_tier = calculator.assign_tier(expected_score)
    assert flow_complexity["tier"] == expected_tier, \
        f"Tier mismatch: expected {expected_tier}, got {flow_complexity['tier']}"


def test_property_3_with_real_data():
    """
    Test Property 3 with real CardDemo data to ensure it works with actual metrics.
    """
    from tools.atx.dependency_transformer.loaders import ATXAssetsLoader
    
    # Load real assets
    loader = ATXAssetsLoader()
    metrics_dict = loader.load('examples/atx/inventory/assets.csv')
    
    calculator = ComplexityCalculator()
    
    # Test with real metrics
    for program_name, metrics in list(metrics_dict.items())[:10]:  # Test first 10
        cc = metrics.cyclomatic_complexity
        loc = metrics.total_lines
        
        # Calculate score
        score = calculator.calculate_composite_score(cc, loc)
        
        # Verify formula
        expected = (cc * 0.3) + (loc / 100.0 * 0.7)
        assert abs(score - expected) < 0.001, \
            f"Score mismatch for {program_name}: expected {expected}, got {score}"
        
        # Verify tier assignment
        tier = calculator.assign_tier(score)
        assert tier in ["LOW", "MEDIUM", "HIGH"], \
            f"Invalid tier for {program_name}: {tier}"


def test_property_4_boundary_conditions():
    """
    Test Property 4 at exact boundary values.
    """
    calculator = ComplexityCalculator()
    
    # Test at exact thresholds
    tier = calculator.assign_tier(10.0)
    assert tier == "MEDIUM", "Score of exactly 10.0 should be MEDIUM"
    
    tier = calculator.assign_tier(20.0)
    assert tier == "HIGH", "Score of exactly 20.0 should be HIGH"
    
    # Test just below thresholds
    tier = calculator.assign_tier(9.999)
    assert tier == "LOW", "Score just below 10.0 should be LOW"
    
    tier = calculator.assign_tier(19.999)
    assert tier == "MEDIUM", "Score just below 20.0 should be MEDIUM"
    
    # Test just above thresholds
    tier = calculator.assign_tier(10.001)
    assert tier == "MEDIUM", "Score just above 10.0 should be MEDIUM"
    
    tier = calculator.assign_tier(20.001)
    assert tier == "HIGH", "Score just above 20.0 should be HIGH"


def test_empty_and_edge_cases():
    """
    Test edge cases like empty flows and missing metrics.
    """
    calculator = ComplexityCalculator()
    
    # Test empty flow
    empty_flow = calculator.calculate_flow_complexity([], {})
    assert empty_flow["total_programs"] == 0
    assert empty_flow["composite_score"] == 0.0
    assert empty_flow["tier"] == "LOW"
    
    # Test flow with programs but no metrics
    programs = ["PROG1", "PROG2", "PROG3"]
    no_metrics_flow = calculator.calculate_flow_complexity(programs, {})
    assert no_metrics_flow["total_programs"] == 3
    assert no_metrics_flow["composite_score"] == 0.0
    assert no_metrics_flow["tier"] == "LOW"
    assert no_metrics_flow["programs_with_metrics"] == 0
    
    # Test program with no metrics
    prog_complexity = calculator.calculate_program_complexity("UNKNOWN", {})
    assert prog_complexity["has_metrics"] == False
    assert prog_complexity["composite_score"] == 0.0
    assert prog_complexity["tier"] == "LOW"


def test_configuration_update():
    """
    Test that configuration can be updated dynamically.
    """
    calculator = ComplexityCalculator()
    
    # Calculate with default config (CC=0.3, LOC=0.7)
    score1 = calculator.calculate_composite_score(100, 1000)
    expected1 = (100 * 0.3) + (1000 / 100.0 * 0.7)  # 30 + 7 = 37
    assert abs(score1 - expected1) < 0.001
    
    # Update configuration to equal weights
    new_config = ComplexityConfig(
        formula=ComplexityFormula(cc_weight=0.5, loc_weight=0.5)
    )
    calculator.update_config(new_config)
    
    # Calculate with new config (CC=0.5, LOC=0.5)
    score2 = calculator.calculate_composite_score(100, 1000)
    expected2 = (100 * 0.5) + (1000 / 100.0 * 0.5)  # 50 + 5 = 55
    assert abs(score2 - expected2) < 0.001
    
    # Scores should be different
    assert abs(score1 - score2) > 1.0, \
        f"Scores should differ after configuration update: {score1} vs {score2}"
