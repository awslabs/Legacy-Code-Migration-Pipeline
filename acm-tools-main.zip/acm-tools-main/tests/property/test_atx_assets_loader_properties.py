"""
Property-based tests for ATXAssetsLoader.

Tests universal properties that should hold for all valid ATX assets files.
"""

import csv
import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings
from tools.atx.dependency_transformer.loaders.atx_assets_loader import ATXAssetsLoader


# Strategy for generating valid CSV rows
@st.composite
def asset_row(draw):
    """Generate a valid asset metrics row."""
    name = draw(st.text(min_size=1, max_size=50, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='.-_')))
    # Add unique suffix to avoid collisions
    unique_suffix = draw(st.integers(min_value=0, max_value=10000))
    name = f"{name}_{unique_suffix}"
    
    # Avoid problematic characters in path (newlines, carriage returns, surrogates)
    path = draw(st.text(min_size=0, max_size=100, alphabet=st.characters(
        blacklist_characters='\r\n\t',
        blacklist_categories=('Cs',)  # Exclude surrogate characters
    )))
    
    return {
        'Name': name,
        'Path': path,
        'File type': draw(st.sampled_from(['COB', 'JCL', 'CPY', 'PRC', 'MD', 'UNKNOWN'])),
        'Cyclomatic Complexity': str(draw(st.integers(min_value=0, max_value=1000))),
        'Total lines': str(draw(st.integers(min_value=0, max_value=100000))),
        'Empty Lines': str(draw(st.integers(min_value=0, max_value=10000))),
        'Effective Lines': str(draw(st.integers(min_value=0, max_value=100000))),
        'Comment Lines': str(draw(st.integers(min_value=0, max_value=10000)))
    }


@st.composite
def assets_csv_data(draw):
    """Generate a list of asset rows with unique names."""
    num_rows = draw(st.integers(min_value=1, max_value=20))
    rows = []
    used_names = set()
    
    for _ in range(num_rows):
        # Keep generating until we get a unique name
        max_attempts = 100
        for attempt in range(max_attempts):
            row = draw(asset_row())
            if row['Name'] not in used_names:
                used_names.add(row['Name'])
                rows.append(row)
                break
        else:
            # If we can't find a unique name after max_attempts, just use a guaranteed unique one
            unique_name = f"unique_{len(rows)}_{draw(st.integers(min_value=0, max_value=1000000))}"
            row = draw(asset_row())
            row['Name'] = unique_name
            rows.append(row)
    
    return rows


@given(assets=assets_csv_data())
@settings(max_examples=100, deadline=None)
def test_property_2_dependency_relationship_preservation(assets):
    """
    Feature: atx-dependency-transformer, Property 2: Dependency Relationship Preservation
    
    For any program in dependencies.json with call dependencies, the loaded call graph
    should preserve all caller-callee relationships exactly as specified in the input.
    
    Note: This property is tested through the assets loader by verifying that all
    metrics relationships are preserved during loading.
    
    Validates: Requirements AC-1.1
    """
    # Create temporary CSV file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
        fieldnames = ['Name', 'Path', 'File type', 'Cyclomatic Complexity', 
                     'Total lines', 'Empty Lines', 'Effective Lines', 'Comment Lines']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(assets)
        temp_path = f.name
    
    try:
        # Load the file
        loader = ATXAssetsLoader()
        metrics = loader.load(temp_path)
        
        # Property 1: All entries should be loaded
        assert len(metrics) == len(assets), \
            f"Expected {len(assets)} entries, got {len(metrics)}"
        
        # Property 2: All names should be accessible
        for asset in assets:
            name = asset['Name']
            metric = loader.get_metrics(name)
            assert metric is not None, f"Asset {name} not found"
        
        # Property 3: All metrics should be preserved correctly
        for asset in assets:
            name = asset['Name']
            metric = loader.get_metrics(name)
            
            # Verify name and path
            assert metric.name == name, f"Name mismatch for {name}"
            assert metric.path == asset['Path'], f"Path mismatch for {name}"
            assert metric.file_type == asset['File type'], f"File type mismatch for {name}"
            
            # Verify numeric fields
            expected_cc = int(asset['Cyclomatic Complexity'])
            assert metric.cyclomatic_complexity == expected_cc, \
                f"CC mismatch for {name}: {metric.cyclomatic_complexity} != {expected_cc}"
            
            expected_loc = int(asset['Total lines'])
            assert metric.total_lines == expected_loc, \
                f"LOC mismatch for {name}: {metric.total_lines} != {expected_loc}"
        
        # Property 4: Helper methods should return correct values
        for asset in assets:
            name = asset['Name']
            expected_cc = int(asset['Cyclomatic Complexity'])
            expected_loc = int(asset['Total lines'])
            
            assert loader.get_cyclomatic_complexity(name) == expected_cc, \
                f"get_cyclomatic_complexity mismatch for {name}"
            assert loader.get_total_lines(name) == expected_loc, \
                f"get_total_lines mismatch for {name}"
        
        # Property 5: Non-existent programs should return None or 0
        non_existent = loader.get_metrics('NON_EXISTENT_PROGRAM_XYZ')
        assert non_existent is None, "Non-existent program should return None"
        
        assert loader.get_cyclomatic_complexity('NON_EXISTENT_PROGRAM_XYZ') == 0, \
            "Non-existent program should return 0 for CC"
        assert loader.get_total_lines('NON_EXISTENT_PROGRAM_XYZ') == 0, \
            "Non-existent program should return 0 for LOC"
        
        # Property 6: Loader should report as loaded
        assert loader.is_loaded(), "Loader should report as loaded after successful load"
        
        # Property 7: get_all_metrics should return all entries
        all_metrics = loader.get_all_metrics()
        assert len(all_metrics) == len(assets), \
            f"get_all_metrics should return all {len(assets)} entries"
        
    finally:
        # Clean up temporary file
        Path(temp_path).unlink(missing_ok=True)


def test_property_2_with_real_data():
    """
    Test Property 2 with real CardDemo data to ensure it works with actual ATX output.
    """
    loader = ATXAssetsLoader()
    metrics = loader.load('examples/atx/inventory/assets.csv')
    
    # Verify completeness
    assert len(metrics) > 0, "Should load metrics from real file"
    assert loader.is_loaded(), "Loader should report as loaded"
    
    # Verify known programs exist
    known_programs = ['CBACT01C.cbl', 'CBACT02C.cbl', 'CBACT03C.cbl']
    found_count = 0
    for prog in known_programs:
        metric = loader.get_metrics(prog)
        if metric:
            found_count += 1
            # Verify metrics are reasonable
            assert metric.cyclomatic_complexity >= 0, f"{prog} should have non-negative CC"
            assert metric.total_lines >= 0, f"{prog} should have non-negative LOC"
    
    assert found_count > 0, "Should find at least one known program"
    
    # Verify helper methods work
    for prog in known_programs:
        cc = loader.get_cyclomatic_complexity(prog)
        loc = loader.get_total_lines(prog)
        assert cc >= 0, f"{prog} CC should be non-negative"
        assert loc >= 0, f"{prog} LOC should be non-negative"


def test_error_handling():
    """Test error handling for invalid inputs."""
    loader = ATXAssetsLoader()
    
    # Test missing file
    try:
        loader.load('nonexistent_file.csv')
        assert False, "Should raise FileNotFoundError"
    except FileNotFoundError:
        pass
    
    # Test invalid CSV (missing required columns)
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['WrongColumn'])
        writer.writeheader()
        writer.writerow({'WrongColumn': 'value'})
        temp_path = f.name
    
    try:
        loader.load(temp_path)
        assert False, "Should raise ValueError for missing required columns"
    except ValueError as e:
        assert 'Missing required columns' in str(e)
    finally:
        Path(temp_path).unlink(missing_ok=True)
    
    # Test empty CSV (no headers)
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        temp_path = f.name
    
    try:
        loader.load(temp_path)
        assert False, "Should raise ValueError for empty CSV"
    except ValueError as e:
        assert 'no headers' in str(e)
    finally:
        Path(temp_path).unlink(missing_ok=True)


def test_numeric_field_parsing():
    """Test that numeric fields are parsed correctly with various inputs."""
    # Test with empty and invalid numeric values
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
        fieldnames = ['Name', 'Path', 'File type', 'Cyclomatic Complexity', 
                     'Total lines', 'Empty Lines', 'Effective Lines', 'Comment Lines']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        # Row with empty numeric values
        writer.writerow({
            'Name': 'test1.cbl',
            'Path': '/path/test1',
            'File type': 'COB',
            'Cyclomatic Complexity': '',
            'Total lines': '',
            'Empty Lines': '',
            'Effective Lines': '',
            'Comment Lines': ''
        })
        
        # Row with invalid numeric values
        writer.writerow({
            'Name': 'test2.cbl',
            'Path': '/path/test2',
            'File type': 'COB',
            'Cyclomatic Complexity': 'invalid',
            'Total lines': 'abc',
            'Empty Lines': '10',
            'Effective Lines': '20',
            'Comment Lines': '5'
        })
        
        temp_path = f.name
    
    try:
        loader = ATXAssetsLoader()
        metrics = loader.load(temp_path)
        
        # Verify empty values default to 0
        metric1 = loader.get_metrics('test1.cbl')
        assert metric1 is not None
        assert metric1.cyclomatic_complexity == 0
        assert metric1.total_lines == 0
        
        # Verify invalid values default to 0
        metric2 = loader.get_metrics('test2.cbl')
        assert metric2 is not None
        assert metric2.cyclomatic_complexity == 0
        assert metric2.total_lines == 0
        assert metric2.empty_lines == 10
        assert metric2.effective_lines == 20
        assert metric2.comment_lines == 5
        
    finally:
        Path(temp_path).unlink(missing_ok=True)
