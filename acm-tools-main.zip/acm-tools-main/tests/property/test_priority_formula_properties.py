"""
Property-based tests for priority formula correctness.

Feature: migration-workpackage-planner
Property 1: Priority Score Formula Correctness
Validates: Requirements 1.1, 1.2, 1.3, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10
"""

import pytest
from hypothesis import given, strategies as st, settings
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.priority.priority_calculator import PriorityCalculator


# Custom strategies for generating test data
@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    # Use UUID-like names to ensure uniqueness
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def business_flow_strategy(draw):
    """Generate a random BusinessFlow with valid complexity metrics."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs (0 to 20 programs)
    num_programs = draw(st.integers(min_value=0, max_value=20))
    programs = [draw(program_strategy()) for _ in range(num_programs)]
    
    # Generate databases (0 to 10 databases)
    num_databases = draw(st.integers(min_value=0, max_value=10))
    databases = [f"DB{i}" for i in range(num_databases)]
    
    # Total programs matches actual program count
    total_programs = len(programs)
    
    # Composite score (0.0 to 100.0)
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False))
    
    # Dependencies
    required_flows = draw(st.lists(st.text(min_size=1, max_size=10), max_size=5))
    dependent_flows = draw(st.lists(st.text(min_size=1, max_size=10), max_size=5))
    
    return BusinessFlow(
        flow_id=flow_id,
        name=name,
        programs=programs,
        databases=databases,
        total_programs=total_programs,
        composite_score=composite_score,
        required_flows=required_flows,
        dependent_flows=dependent_flows
    )


@st.composite
def module_classifications_strategy(draw, programs):
    """Generate module classifications for given programs."""
    classifications = {}
    for program in programs:
        # 30% chance of being COMMONLY_USED
        if draw(st.booleans()):
            classification = draw(st.sampled_from(["COMMONLY_USED", "UTILITY", "BUSINESS_LOGIC", "DATA_ACCESS"]))
            classifications[program.name] = classification
    return classifications


@given(business_flow_strategy())
@settings(max_examples=100)
def test_priority_formula_correctness_no_classifications(flow):
    """
    Property 1: Priority Score Formula Correctness (without classifications)
    
    For any business flow without module classifications, the calculated priority score
    should equal (totalPrograms × 2) + (compositeScore × 0.5) + completeFlowBonus + simpleFlowBonus.
    
    **Validates: Requirements 1.1, 1.2, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10**
    """
    # Initialize calculator with no classifications
    calculator = PriorityCalculator(classifications={})
    
    # Calculate priority
    result = calculator.calculate_priority(flow)
    
    # Calculate expected values
    total_programs = flow.total_programs
    composite_score = flow.composite_score
    common_modules = 0  # No classifications provided
    
    # Complete flow bonus
    complete_flow_bonus = -5 if len(flow.databases) > 0 else 0
    
    # Simple flow bonus
    if total_programs <= 3:
        simple_flow_bonus = -3
    elif total_programs <= 5:
        simple_flow_bonus = -1
    else:
        simple_flow_bonus = 0
    
    # Expected priority score
    expected_score = (
        (total_programs * 2) +
        (common_modules * 3) +
        (composite_score * 0.5) +
        complete_flow_bonus +
        simple_flow_bonus
    )
    
    # Verify the formula
    assert abs(result.priority_score - expected_score) < 0.001, (
        f"Priority score mismatch for flow {flow.flow_id}: "
        f"expected {expected_score}, got {result.priority_score}"
    )
    
    # Verify factors are stored correctly
    assert result.factors.total_programs == total_programs
    assert result.factors.common_modules == common_modules
    assert abs(result.factors.composite_score - composite_score) < 0.001
    assert result.factors.complete_flow_bonus == complete_flow_bonus
    assert result.factors.simple_flow_bonus == simple_flow_bonus


@given(business_flow_strategy())
@settings(max_examples=100)
def test_priority_formula_correctness_with_classifications(flow):
    """
    Property 1: Priority Score Formula Correctness (with classifications)
    
    For any business flow with module classifications, the calculated priority score
    should equal (totalPrograms × 2) + (commonModules × 3) + (compositeScore × 0.5) 
    + completeFlowBonus + simpleFlowBonus.
    
    **Validates: Requirements 1.1, 1.2, 1.3, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10**
    """
    # Generate deterministic classifications for this flow's programs
    # Use a deterministic approach based on program index
    classifications = {}
    expected_common_count = 0
    
    for i, program in enumerate(flow.programs):
        # Deterministically assign COMMONLY_USED to every 3rd program
        if i % 3 == 0:
            classifications[program.name] = "COMMONLY_USED"
            expected_common_count += 1
        else:
            # Assign other classifications deterministically
            other_types = ["UTILITY", "BUSINESS_LOGIC", "DATA_ACCESS"]
            classifications[program.name] = other_types[i % len(other_types)]
    
    # Initialize calculator with classifications
    calculator = PriorityCalculator(classifications=classifications)
    
    # Calculate priority
    result = calculator.calculate_priority(flow)
    
    # Calculate expected values
    total_programs = flow.total_programs
    composite_score = flow.composite_score
    common_modules = expected_common_count
    
    # Complete flow bonus
    complete_flow_bonus = -5 if len(flow.databases) > 0 else 0
    
    # Simple flow bonus
    if total_programs <= 3:
        simple_flow_bonus = -3
    elif total_programs <= 5:
        simple_flow_bonus = -1
    else:
        simple_flow_bonus = 0
    
    # Expected priority score
    expected_score = (
        (total_programs * 2) +
        (common_modules * 3) +
        (composite_score * 0.5) +
        complete_flow_bonus +
        simple_flow_bonus
    )
    
    # Verify the formula
    assert abs(result.priority_score - expected_score) < 0.001, (
        f"Priority score mismatch for flow {flow.flow_id}: "
        f"expected {expected_score}, got {result.priority_score}"
    )
    
    # Verify factors are stored correctly
    assert result.factors.total_programs == total_programs
    assert result.factors.common_modules == common_modules
    assert abs(result.factors.composite_score - composite_score) < 0.001
    assert result.factors.complete_flow_bonus == complete_flow_bonus
    assert result.factors.simple_flow_bonus == simple_flow_bonus


@given(st.integers(min_value=0, max_value=20))
@settings(max_examples=100)
def test_simple_flow_bonus_calculation(total_programs):
    """
    Property 1: Simple Flow Bonus Calculation
    
    For any program count, the simple flow bonus should be:
    - -3 if totalPrograms <= 3
    - -1 if 3 < totalPrograms <= 5
    - 0 if totalPrograms > 5
    
    **Validates: Requirements 1.7, 1.8, 1.9**
    """
    # Create a minimal flow with specified program count
    programs = [Program(name=f"PROG{i}", is_utility=False) for i in range(total_programs)]
    flow = BusinessFlow(
        flow_id="TEST",
        name="Test Flow",
        programs=programs,
        databases=[],
        total_programs=total_programs,
        composite_score=0.0,
        required_flows=[],
        dependent_flows=[]
    )
    
    calculator = PriorityCalculator(classifications={})
    result = calculator.calculate_priority(flow)
    
    # Verify simple flow bonus
    if total_programs <= 3:
        expected_bonus = -3
    elif total_programs <= 5:
        expected_bonus = -1
    else:
        expected_bonus = 0
    
    assert result.factors.simple_flow_bonus == expected_bonus, (
        f"Simple flow bonus mismatch for {total_programs} programs: "
        f"expected {expected_bonus}, got {result.factors.simple_flow_bonus}"
    )


@given(st.integers(min_value=0, max_value=10))
@settings(max_examples=100)
def test_complete_flow_bonus_calculation(num_databases):
    """
    Property 1: Complete Flow Bonus Calculation
    
    For any flow, the complete flow bonus should be:
    - -5 if databases list is non-empty
    - 0 if databases list is empty
    
    **Validates: Requirements 1.5, 1.6**
    """
    # Create a flow with specified number of databases
    databases = [f"DB{i}" for i in range(num_databases)]
    flow = BusinessFlow(
        flow_id="TEST",
        name="Test Flow",
        programs=[Program(name="PROG1", is_utility=False)],
        databases=databases,
        total_programs=1,
        composite_score=0.0,
        required_flows=[],
        dependent_flows=[]
    )
    
    calculator = PriorityCalculator(classifications={})
    result = calculator.calculate_priority(flow)
    
    # Verify complete flow bonus
    expected_bonus = -5 if num_databases > 0 else 0
    
    assert result.factors.complete_flow_bonus == expected_bonus, (
        f"Complete flow bonus mismatch for {num_databases} databases: "
        f"expected {expected_bonus}, got {result.factors.complete_flow_bonus}"
    )
