"""
Property-based tests for JobTransformer.

Tests universal properties that should hold for all job transformations.
"""

from hypothesis import given, strategies as st, settings, assume
from pathlib import Path
from tools.atx.dependency_transformer.transformers import JobTransformer
from tools.atx.dependency_transformer.loaders import ATXDependencyLoader
from tools.atx.dependency_transformer.models.config_models import TransformationConfig


def setup_transformer():
    """
    Set up a JobTransformer with real CardDemo data.
    
    Returns:
        Tuple of (transformer, dependency_loader)
    """
    # Load dependencies
    dep_loader = ATXDependencyLoader()
    dep_loader.load('examples/atx/dependency-analysis/dependencies.json')
    
    # Create configuration
    config = TransformationConfig()
    
    # Create transformer
    transformer = JobTransformer(
        dependency_loader=dep_loader,
        config=config
    )
    
    return transformer, dep_loader


def test_property_10_jcl_entry_identification():
    """
    Feature: atx-dependency-transformer, Property 10: JCL Entry Identification
    
    For any ATX dependency with type="JCL", a job should be created with the
    JCL file name as the job name.
    
    Validates: Requirements AC-2.1
    """
    transformer, dep_loader = setup_transformer()
    
    # Get all JCL entries
    jcl_entries = dep_loader.get_jcl_jobs()
    
    # Transform jobs
    jobs = transformer.transform()
    
    # Property: Number of jobs should equal number of JCL entries
    assert len(jobs) == len(jcl_entries), \
        f"Expected {len(jcl_entries)} jobs, got {len(jobs)}"
    
    # Property: Each JCL entry should produce a job
    jcl_names = {Path(jcl.name).stem for jcl in jcl_entries}
    job_names = {job.job_name for job in jobs}
    
    assert jcl_names == job_names, \
        f"JCL names {jcl_names} should match job names {job_names}"
    
    # Property: Each job name should be derived from a JCL file name
    for job in jobs:
        # Job name should not be empty
        assert job.job_name, "Job name should not be empty"
        
        # Job name should match a JCL entry (without extension)
        matching_jcl = [jcl for jcl in jcl_entries 
                       if Path(jcl.name).stem == job.job_name]
        assert len(matching_jcl) == 1, \
            f"Job {job.job_name} should match exactly one JCL entry"


def test_property_11_job_step_extraction():
    """
    Feature: atx-dependency-transformer, Property 11: Job Step Extraction
    
    For any JCL entry with N "Exec program" dependencies, the generated job
    should have exactly N steps, each with the corresponding program name.
    
    Validates: Requirements AC-2.2
    """
    transformer, dep_loader = setup_transformer()
    
    # Get all JCL entries
    jcl_entries = dep_loader.get_jcl_jobs()
    
    # Transform jobs
    jobs = transformer.transform()
    
    # Property: Each job should have steps matching "Exec program" dependencies
    for jcl_entry in jcl_entries:
        # Count "Exec program" dependencies
        exec_programs = [
            dep for dep in jcl_entry.dependencies
            if 'Exec program' in dep.get('dependencyType', '')
        ]
        
        # Find corresponding job
        job_name = Path(jcl_entry.name).stem
        matching_jobs = [j for j in jobs if j.job_name == job_name]
        assert len(matching_jobs) == 1, \
            f"Should find exactly one job for {job_name}"
        
        job = matching_jobs[0]
        
        # Property: Number of steps should equal number of "Exec program" dependencies
        assert len(job.steps) == len(exec_programs), \
            f"Job {job_name} should have {len(exec_programs)} steps, got {len(job.steps)}"
        
        # Property: Each step should have a program name from the dependencies
        exec_program_names = {dep.get('name', '') for dep in exec_programs}
        step_program_names = {step.program for step in job.steps}
        
        assert step_program_names == exec_program_names, \
            f"Job {job_name} step programs {step_program_names} should match exec programs {exec_program_names}"
        
        # Property: Steps should be numbered sequentially
        for i, step in enumerate(job.steps, start=1):
            expected_name = f"STEP{i:03d}"
            assert step.step_name == expected_name, \
                f"Step {i} should be named {expected_name}, got {step.step_name}"


def test_property_12_job_dataset_extraction():
    """
    Feature: atx-dependency-transformer, Property 12: Job Dataset Extraction
    
    For any JCL entry with "Dataset use" dependencies, all referenced datasets
    should appear in the job's datasets list.
    
    Validates: Requirements AC-2.3
    """
    transformer, dep_loader = setup_transformer()
    
    # Get all JCL entries
    jcl_entries = dep_loader.get_jcl_jobs()
    
    # Transform jobs
    jobs = transformer.transform()
    
    # Property: Each job should have datasets matching "Dataset use" dependencies
    for jcl_entry in jcl_entries:
        # Extract dataset dependencies
        dataset_deps = []
        for dep in jcl_entry.dependencies:
            dep_type = dep.get('dependencyType', '')
            dep_obj_type = dep.get('type', '')
            name = dep.get('name', '')
            
            # Check for dataset patterns
            if ('Dataset use' in dep_type or 'dataset' in dep_type.lower() or
                'DATASET' in dep_obj_type or 'VSAM' in dep_obj_type or
                'PS' in dep_obj_type or 'PDS' in dep_obj_type):
                if name:
                    dataset_deps.append(name)
        
        # Find corresponding job
        job_name = Path(jcl_entry.name).stem
        matching_jobs = [j for j in jobs if j.job_name == job_name]
        assert len(matching_jobs) == 1, \
            f"Should find exactly one job for {job_name}"
        
        job = matching_jobs[0]
        
        # Property: All dataset dependencies should be in job's datasets list
        for dataset in dataset_deps:
            assert dataset in job.datasets, \
                f"Job {job_name} should include dataset {dataset}"
        
        # Property: Job datasets should not have duplicates
        assert len(job.datasets) == len(set(job.datasets)), \
            f"Job {job_name} should not have duplicate datasets"


def test_property_13_job_type_classification():
    """
    Feature: atx-dependency-transformer, Property 13: Job Type Classification
    
    For any job, if all executed programs are in the utility program list,
    the job type should be INFRASTRUCTURE; otherwise, it should be APPLICATION.
    
    Validates: Requirements AC-2.4
    """
    transformer, dep_loader = setup_transformer()
    
    # Transform jobs
    jobs = transformer.transform()
    
    # Get configuration
    config = transformer.config
    
    # Property: Job type should be correctly classified
    for job in jobs:
        # Get all programs executed in this job
        programs = [step.program for step in job.steps]
        
        if not programs:
            # Empty job should be INFRASTRUCTURE
            assert job.job_type == "INFRASTRUCTURE", \
                f"Job {job.job_name} with no programs should be INFRASTRUCTURE"
        else:
            # Check if all programs are utilities
            all_utilities = all(
                config.is_utility_program(program)
                for program in programs
            )
            
            expected_type = "INFRASTRUCTURE" if all_utilities else "APPLICATION"
            
            assert job.job_type == expected_type, \
                f"Job {job.job_name} should be {expected_type}, got {job.job_type}"
        
        # Property: Job type should be valid
        assert job.job_type in ["APPLICATION", "INFRASTRUCTURE"], \
            f"Job {job.job_name} has invalid type {job.job_type}"


def test_property_14_custom_code_detection():
    """
    Feature: atx-dependency-transformer, Property 14: Custom Code Detection
    
    For any job, hasCustomCode should be true if and only if at least one
    executed program is not in the utility program list.
    
    Validates: Requirements AC-2.5
    """
    transformer, dep_loader = setup_transformer()
    
    # Transform jobs
    jobs = transformer.transform()
    
    # Get configuration
    config = transformer.config
    
    # Property: hasCustomCode should be correctly determined
    for job in jobs:
        # Get all programs executed in this job
        programs = [step.program for step in job.steps]
        
        if not programs:
            # Empty job should not have custom code
            assert not job.has_custom_code, \
                f"Job {job.job_name} with no programs should not have custom code"
        else:
            # Check if any program is not a utility
            has_non_utility = any(
                not config.is_utility_program(program)
                for program in programs
            )
            
            assert job.has_custom_code == has_non_utility, \
                f"Job {job.job_name} hasCustomCode should be {has_non_utility}, got {job.has_custom_code}"
        
        # Property: Consistency between job_type and has_custom_code
        if job.job_type == "INFRASTRUCTURE":
            # INFRASTRUCTURE jobs should not have custom code
            assert not job.has_custom_code, \
                f"INFRASTRUCTURE job {job.job_name} should not have custom code"
        elif job.job_type == "APPLICATION":
            # APPLICATION jobs should have custom code
            assert job.has_custom_code, \
                f"APPLICATION job {job.job_name} should have custom code"
