"""
Property-based tests for workpackage sequential assignment.

Feature: migration-workpackage-planner
Property 3: Workpackage Sequential Assignment
Validates: Requirements 2.1, 2.2, 2.3
"""

import pytest
from hypothesis import given, strategies as st, settings
from tools.migration_planner.models.business_flow import BusinessFlow, Program
from tools.migration_planner.models.priority import PriorityResult, PriorityFactors
from tools.migration_planner.workpackage.workpackage_assigner import WorkpackageAssigner


# Custom strategies for generating test data
@st.composite
def program_strategy(draw):
    """Generate a random Program with unique name."""
    import uuid
    name = f"PROG_{uuid.uuid4().hex[:8].upper()}"
    is_utility = draw(st.booleans())
    return Program(name=name, is_utility=is_utility)


@st.composite
def business_flow_strategy(draw):
    """Generate a random BusinessFlow."""
    import uuid
    flow_id = f"FLOW_{uuid.uuid4().hex[:8].upper()}"
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs (0 to 15 programs)
    num_programs = draw(st.integers(min_value=0, max_value=15))
    programs = [draw(program_strategy()) for _ in range(num_programs)]
    
    # Generate databases (0 to 5 databases)
    num_databases = draw(st.integers(min_value=0, max_value=5))
    databases = [f"DB{i}" for i in range(num_databases)]
    
    total_programs = len(programs)
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False))
    
    return BusinessFlow(
        flow_id=flow_id,
        name=name,
        programs=programs,
        databases=databases,
        total_programs=total_programs,
        composite_score=composite_score,
        required_flows=[],
        dependent_flows=[]
    )


@st.composite
def flows_with_priorities_strategy(draw):
    """Generate a list of flows with corresponding priority results."""
    # Generate 1 to 20 flows
    num_flows = draw(st.integers(min_value=1, max_value=20))
    flows = [draw(business_flow_strategy()) for _ in range(num_flows)]
    
    # Generate priority scores for each flow
    priorities = {}
    for flow in flows:
        # Generate a priority score (can be any float, including duplicates)
        priority_score = draw(st.floats(
            min_value=-20.0,
            max_value=200.0,
            allow_nan=False,
            allow_infinity=False
        ))
        
        # Create priority factors (values don't matter for this test)
        factors = PriorityFactors(
            total_programs=flow.total_programs,
            common_modules=0,
            composite_score=flow.composite_score,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        
        priorities[flow.flow_id] = PriorityResult(
            flow_id=flow.flow_id,
            priority_score=priority_score,
            factors=factors
        )
    
    return flows, priorities


@given(flows_with_priorities_strategy())
@settings(max_examples=100)
def test_workpackage_sequential_assignment(flows_and_priorities):
    """
    Property 3: Workpackage Sequential Assignment
    
    For any list of flows with priorities, workpackage IDs should be:
    1. Assigned sequentially starting from 1
    2. Sorted by priority score in ascending order
    3. Stable sorted by flowId for equal priorities
    
    **Validates: Requirements 2.1, 2.2, 2.3**
    """
    flows, priorities = flows_and_priorities
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # Property 1: Sequential IDs starting from 1
    expected_ids = list(range(1, len(flows) + 1))
    actual_ids = [assignment.workpackage_id for assignment in assignments]
    
    assert actual_ids == expected_ids, (
        f"Workpackage IDs are not sequential: expected {expected_ids}, got {actual_ids}"
    )
    
    # Property 2: Sorted by priority score (ascending)
    for i in range(len(assignments) - 1):
        current_priority = assignments[i].priority_score
        next_priority = assignments[i + 1].priority_score
        
        assert current_priority <= next_priority, (
            f"Workpackages not sorted by priority: "
            f"workpackage {assignments[i].workpackage_id} has priority {current_priority}, "
            f"but workpackage {assignments[i + 1].workpackage_id} has priority {next_priority}"
        )
    
    # Property 3: Stable sort by flowId for equal priorities
    # Group consecutive assignments with the same priority score
    i = 0
    while i < len(assignments):
        # Find all assignments with the same priority as current
        current_priority = assignments[i].priority_score
        j = i + 1
        while j < len(assignments) and assignments[j].priority_score == current_priority:
            j += 1
        
        # If we have multiple assignments with the same priority, check stable sort
        if j > i + 1:
            equal_priority_flows = [assignments[k].flow_id for k in range(i, j)]
            sorted_flows = sorted(equal_priority_flows)
            
            assert equal_priority_flows == sorted_flows, (
                f"Stable sort violated: flows with equal priority {current_priority} "
                f"are not sorted by flowId: {equal_priority_flows} should be {sorted_flows}"
            )
        
        i = j
    
    # Property 4: All flows are assigned exactly once
    assigned_flow_ids = {assignment.flow_id for assignment in assignments}
    original_flow_ids = {flow.flow_id for flow in flows}
    
    assert assigned_flow_ids == original_flow_ids, (
        f"Not all flows were assigned: "
        f"missing {original_flow_ids - assigned_flow_ids}, "
        f"extra {assigned_flow_ids - original_flow_ids}"
    )
    
    # Property 5: Each assignment has correct priority score
    for assignment in assignments:
        expected_score = priorities[assignment.flow_id].priority_score
        assert abs(assignment.priority_score - expected_score) < 0.0001, (
            f"Priority score mismatch for flow {assignment.flow_id}: "
            f"expected {expected_score}, got {assignment.priority_score}"
        )


@given(st.lists(business_flow_strategy(), min_size=0, max_size=5))
@settings(max_examples=100)
def test_workpackage_assignment_with_empty_or_small_lists(flows):
    """
    Property 3: Workpackage Sequential Assignment (edge cases)
    
    For empty or small lists of flows, workpackage assignment should still work correctly.
    
    **Validates: Requirements 2.1, 2.2, 2.3**
    """
    # Generate priorities for flows
    priorities = {}
    for i, flow in enumerate(flows):
        factors = PriorityFactors(
            total_programs=flow.total_programs,
            common_modules=0,
            composite_score=flow.composite_score,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities[flow.flow_id] = PriorityResult(
            flow_id=flow.flow_id,
            priority_score=float(i * 10),  # Simple sequential priorities
            factors=factors
        )
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # Verify correct number of assignments
    assert len(assignments) == len(flows), (
        f"Number of assignments {len(assignments)} does not match number of flows {len(flows)}"
    )
    
    # If there are flows, verify sequential IDs
    if flows:
        expected_ids = list(range(1, len(flows) + 1))
        actual_ids = [assignment.workpackage_id for assignment in assignments]
        assert actual_ids == expected_ids, (
            f"Workpackage IDs are not sequential: expected {expected_ids}, got {actual_ids}"
        )


@given(st.integers(min_value=2, max_value=10))
@settings(max_examples=100)
def test_workpackage_assignment_with_equal_priorities(num_flows):
    """
    Property 3: Workpackage Sequential Assignment (equal priorities)
    
    When all flows have equal priorities, they should be sorted by flowId (stable sort).
    
    **Validates: Requirements 2.2, 2.3**
    """
    # Create flows with equal priorities
    flows = []
    priorities = {}
    
    for i in range(num_flows):
        flow_id = f"FLOW_{chr(65 + i)}"  # FLOW_A, FLOW_B, etc.
        flow = BusinessFlow(
            flow_id=flow_id,
            name=f"Flow {i}",
            programs=[Program(name=f"PROG{i}", is_utility=False)],
            databases=[],
            total_programs=1,
            composite_score=10.0,
            required_flows=[],
            dependent_flows=[]
        )
        flows.append(flow)
        
        # All flows have the same priority score
        factors = PriorityFactors(
            total_programs=1,
            common_modules=0,
            composite_score=10.0,
            complete_flow_bonus=0,
            simple_flow_bonus=0
        )
        priorities[flow_id] = PriorityResult(
            flow_id=flow_id,
            priority_score=50.0,  # Same priority for all
            factors=factors
        )
    
    # Create assigner and assign workpackages
    assigner = WorkpackageAssigner()
    assignments = assigner.assign_workpackages(priorities, flows)
    
    # Verify flows are sorted by flowId
    for i in range(len(assignments) - 1):
        current_flow_id = assignments[i].flow_id
        next_flow_id = assignments[i + 1].flow_id
        
        assert current_flow_id < next_flow_id, (
            f"Flows with equal priority not sorted by flowId: "
            f"{current_flow_id} should come before {next_flow_id}"
        )
    
    # Verify sequential IDs
    expected_ids = list(range(1, num_flows + 1))
    actual_ids = [assignment.workpackage_id for assignment in assignments]
    assert actual_ids == expected_ids
