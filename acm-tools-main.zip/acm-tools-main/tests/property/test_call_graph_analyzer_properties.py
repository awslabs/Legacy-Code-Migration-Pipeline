"""
Property-based tests for CallGraphAnalyzer.

Tests universal properties that should hold for all valid call graphs.
"""

from hypothesis import given, strategies as st, settings, assume
from tools.atx.dependency_transformer.analysis import CallGraphAnalyzer


# Strategy for generating valid program names
@st.composite
def program_name(draw):
    """Generate a valid program name."""
    name = draw(st.text(
        min_size=1,
        max_size=20,
        alphabet=st.characters(
            whitelist_categories=('Lu', 'Ll', 'Nd'),
            whitelist_characters='_-'
        )
    ))
    # Ensure it's not empty after stripping
    assume(len(name.strip()) > 0)
    return name.strip()


# Strategy for generating call graphs
@st.composite
def call_graph(draw, min_programs=2, max_programs=15):
    """Generate a valid call graph."""
    num_programs = draw(st.integers(min_value=min_programs, max_value=max_programs))
    
    # Generate unique program names
    programs = []
    for i in range(num_programs):
        prog = f"PROG{i:03d}"
        programs.append(prog)
    
    # Generate call relationships
    program_calls = {}
    for caller in programs:
        # Each program can call 0 to 3 other programs
        num_calls = draw(st.integers(min_value=0, max_value=min(3, num_programs - 1)))
        callees = draw(st.lists(
            st.sampled_from(programs),
            min_size=num_calls,
            max_size=num_calls,
            unique=True
        ))
        # Remove self-calls
        callees = [c for c in callees if c != caller]
        program_calls[caller] = callees
    
    return program_calls


@given(program_calls=call_graph())
@settings(max_examples=100, deadline=None)
def test_property_9_flow_dependency_transitivity(program_calls):
    """
    Feature: atx-dependency-transformer, Property 9: Flow Dependency Transitivity
    
    For any two flows F1 and F2, if a program in F1's scope calls a program in F2's scope,
    then F1 should list F2 in its requiredFlows and F2 should list F1 in its dependentFlows.
    
    This property tests the transitive closure of dependencies: if A calls B and B calls C,
    then A's transitive dependencies should include both B and C.
    
    Validates: Requirements AC-1.9
    """
    # Build the call graph
    analyzer = CallGraphAnalyzer()
    analyzer.build_call_graph(program_calls)
    
    # Property 1: Transitive closure should include all reachable programs
    for caller, direct_callees in program_calls.items():
        transitive_deps = analyzer.get_transitive_dependencies(caller)
        
        # All direct callees should be in transitive dependencies
        for callee in direct_callees:
            assert callee in transitive_deps, \
                f"Direct callee {callee} not in transitive dependencies of {caller}"
        
        # All programs reachable from direct callees should also be in transitive dependencies
        # EXCEPT the caller itself (which is excluded by design)
        for callee in direct_callees:
            callee_transitive = analyzer.get_transitive_dependencies(callee)
            for indirect_callee in callee_transitive:
                # Skip if the indirect callee is the original caller (circular dependency)
                if indirect_callee == caller:
                    continue
                assert indirect_callee in transitive_deps, \
                    f"Indirect callee {indirect_callee} (via {callee}) not in transitive dependencies of {caller}"
    
    # Property 2: Transitive dependencies should not include the program itself
    for program in program_calls.keys():
        transitive_deps = analyzer.get_transitive_dependencies(program)
        assert program not in transitive_deps, \
            f"Program {program} should not be in its own transitive dependencies"
    
    # Property 3: If A has path to B, then B should be in A's transitive dependencies
    for program_a in program_calls.keys():
        transitive_deps = analyzer.get_transitive_dependencies(program_a)
        for program_b in program_calls.keys():
            if program_a != program_b:
                has_path = analyzer.has_path(program_a, program_b)
                in_transitive = program_b in transitive_deps
                assert has_path == in_transitive, \
                    f"Inconsistency: has_path({program_a}, {program_b})={has_path} but in_transitive={in_transitive}"
    
    # Property 4: Transitive dependencies should be idempotent (calling twice gives same result)
    for program in program_calls.keys():
        deps1 = analyzer.get_transitive_dependencies(program)
        deps2 = analyzer.get_transitive_dependencies(program)
        assert deps1 == deps2, \
            f"Transitive dependencies not idempotent for {program}"
    
    # Property 5: If A calls B, then B should have A as a caller
    for caller, callees in program_calls.items():
        for callee in callees:
            callers = analyzer.get_direct_callers(callee)
            assert caller in callers, \
                f"Reverse graph inconsistency: {caller} calls {callee} but {callee} doesn't list {caller} as caller"


@given(program_calls=call_graph(min_programs=5, max_programs=10))
@settings(max_examples=100, deadline=None)
def test_entry_point_detection_properties(program_calls):
    """
    Test properties of entry point detection.
    
    Entry points are programs with no inbound calls.
    """
    analyzer = CallGraphAnalyzer()
    analyzer.build_call_graph(program_calls)
    
    entry_points = analyzer.find_entry_points()
    
    # Property 1: Entry points should have no callers
    for entry_point in entry_points:
        callers = analyzer.get_direct_callers(entry_point)
        assert len(callers) == 0, \
            f"Entry point {entry_point} has callers: {callers}"
    
    # Property 2: All programs with no callers should be entry points
    for program in program_calls.keys():
        callers = analyzer.get_direct_callers(program)
        is_entry_point = program in entry_points
        has_no_callers = len(callers) == 0
        assert is_entry_point == has_no_callers, \
            f"Inconsistency for {program}: is_entry_point={is_entry_point}, has_no_callers={has_no_callers}"
    
    # Property 3: Entry points list should be deterministic (sorted)
    entry_points2 = analyzer.find_entry_points()
    assert entry_points == entry_points2, \
        "Entry points should be deterministic"


@given(program_calls=call_graph(min_programs=3, max_programs=8))
@settings(max_examples=100, deadline=None)
def test_circular_dependency_detection_properties(program_calls):
    """
    Test properties of circular dependency detection.
    
    Circular dependencies are strongly connected components with more than one node.
    """
    analyzer = CallGraphAnalyzer()
    analyzer.build_call_graph(program_calls)
    
    cycles = analyzer.detect_circular_dependencies()
    
    # Property 1: All programs in a cycle should be mutually reachable
    for cycle in cycles:
        for prog_a in cycle:
            for prog_b in cycle:
                if prog_a != prog_b:
                    # Both directions should have paths
                    assert analyzer.has_path(prog_a, prog_b), \
                        f"In cycle {cycle}, no path from {prog_a} to {prog_b}"
                    assert analyzer.has_path(prog_b, prog_a), \
                        f"In cycle {cycle}, no path from {prog_b} to {prog_a}"
    
    # Property 2: Cycles should not contain single programs
    for cycle in cycles:
        assert len(cycle) > 1, \
            f"Cycle should have more than one program, got {cycle}"
    
    # Property 3: Cycles should be deterministic (sorted)
    cycles2 = analyzer.detect_circular_dependencies()
    assert cycles == cycles2, \
        "Circular dependency detection should be deterministic"
    
    # Property 4: Each cycle should be sorted internally
    for cycle in cycles:
        assert cycle == sorted(cycle), \
            f"Cycle {cycle} should be sorted"


@given(
    program_calls=call_graph(min_programs=5, max_programs=10),
    program_idx=st.integers(min_value=0, max_value=9)
)
@settings(max_examples=100, deadline=None)
def test_call_depth_properties(program_calls, program_idx):
    """
    Test properties of call depth calculation.
    
    Call depth is the maximum distance from a program to any leaf program.
    """
    analyzer = CallGraphAnalyzer()
    analyzer.build_call_graph(program_calls)
    
    programs = list(program_calls.keys())
    if program_idx >= len(programs):
        return  # Skip if index out of range
    
    program = programs[program_idx]
    depth = analyzer.get_call_depth(program)
    
    # Property 1: Depth should be non-negative
    assert depth >= 0, \
        f"Call depth should be non-negative, got {depth}"
    
    # Property 2: If program has no callees, depth should be 0
    direct_callees = analyzer.get_direct_callees(program)
    if len(direct_callees) == 0:
        assert depth == 0, \
            f"Program {program} with no callees should have depth 0, got {depth}"
    
    # Property 3: Depth should be at least 1 if program has callees
    if len(direct_callees) > 0:
        assert depth >= 1, \
            f"Program {program} with callees should have depth >= 1, got {depth}"
    
    # Property 4: Depth should not exceed number of programs (prevents infinite loops)
    assert depth < len(programs), \
        f"Call depth {depth} exceeds number of programs {len(programs)}"


@given(program_calls=call_graph(min_programs=3, max_programs=8))
@settings(max_examples=100, deadline=None)
def test_graph_consistency_properties(program_calls):
    """
    Test general consistency properties of the call graph.
    """
    analyzer = CallGraphAnalyzer()
    analyzer.build_call_graph(program_calls)
    
    # Property 1: All programs should be in the graph
    all_programs = analyzer.get_all_programs()
    for program in program_calls.keys():
        assert program in all_programs, \
            f"Program {program} not in graph"
    
    # Property 2: All callees should also be in the graph
    for caller, callees in program_calls.items():
        for callee in callees:
            assert callee in all_programs, \
                f"Callee {callee} not in graph"
    
    # Property 3: Direct callees should match input
    for caller, expected_callees in program_calls.items():
        actual_callees = analyzer.get_direct_callees(caller)
        assert set(actual_callees) == set(expected_callees), \
            f"Direct callees mismatch for {caller}: expected {expected_callees}, got {actual_callees}"
    
    # Property 4: Graph should report as built
    assert analyzer.is_built(), \
        "Analyzer should report as built after build_call_graph()"
    
    # Property 5: Calling methods before build should raise error
    analyzer2 = CallGraphAnalyzer()
    try:
        analyzer2.get_transitive_dependencies("PROG001")
        assert False, "Should raise RuntimeError when graph not built"
    except RuntimeError:
        pass


def test_property_9_with_real_data():
    """
    Test Property 9 with real CardDemo data to ensure it works with actual ATX output.
    """
    from tools.atx.dependency_transformer.loaders import ATXDependencyLoader
    
    # Load real dependencies
    loader = ATXDependencyLoader()
    loader.load('examples/atx/dependency-analysis/dependencies.json')
    
    # Build call graph from real data
    program_calls = {}
    for program in loader.get_programs():
        calls = loader.get_program_calls(program.name)
        program_calls[program.name] = calls
    
    # Build analyzer
    analyzer = CallGraphAnalyzer()
    analyzer.build_call_graph(program_calls)
    
    # Verify transitive dependencies work
    programs = list(program_calls.keys())
    if len(programs) > 0:
        first_program = programs[0]
        transitive_deps = analyzer.get_transitive_dependencies(first_program)
        
        # Verify transitivity property
        direct_callees = analyzer.get_direct_callees(first_program)
        for callee in direct_callees:
            assert callee in transitive_deps, \
                f"Direct callee {callee} not in transitive dependencies"
            
            # Check second-level transitivity
            callee_deps = analyzer.get_transitive_dependencies(callee)
            for indirect in callee_deps:
                assert indirect in transitive_deps, \
                    f"Indirect callee {indirect} not in transitive dependencies"
    
    # Verify entry points exist
    entry_points = analyzer.find_entry_points()
    assert len(entry_points) > 0, "Should find entry points in real data"
    
    # Verify entry points have no callers
    for entry_point in entry_points:
        callers = analyzer.get_direct_callers(entry_point)
        assert len(callers) == 0, \
            f"Entry point {entry_point} should have no callers"


def test_memoization_performance():
    """
    Test that memoization improves performance for repeated queries.
    """
    import time
    
    # Create a deep call chain
    program_calls = {}
    for i in range(50):
        if i < 49:
            program_calls[f"PROG{i:03d}"] = [f"PROG{i+1:03d}"]
        else:
            program_calls[f"PROG{i:03d}"] = []
    
    analyzer = CallGraphAnalyzer()
    analyzer.build_call_graph(program_calls)
    
    # First call (should compute and cache)
    start = time.time()
    deps1 = analyzer.get_transitive_dependencies("PROG000")
    time1 = time.time() - start
    
    # Second call (should use cache)
    start = time.time()
    deps2 = analyzer.get_transitive_dependencies("PROG000")
    time2 = time.time() - start
    
    # Results should be identical
    assert deps1 == deps2, "Memoized results should be identical"
    
    # Second call should be faster (or at least not significantly slower)
    # We use a generous threshold since timing can be variable
    assert time2 <= time1 * 2, \
        f"Memoized call should be fast: {time2} vs {time1}"
