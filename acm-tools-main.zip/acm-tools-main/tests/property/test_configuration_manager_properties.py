"""
Property-based tests for ConfigurationManager.

Tests universal properties that should hold for all configuration operations.
"""

import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings, assume
from tools.atx.dependency_transformer.orchestration import ConfigurationManager
from tools.atx.dependency_transformer.models.config_models import TransformationConfig


# Strategy for generating valid configuration dictionaries
@st.composite
def valid_config_dict(draw):
    """Generate a valid configuration dictionary."""
    cc_weight = draw(st.floats(min_value=0.0, max_value=1.0))
    loc_weight = draw(st.floats(min_value=0.0, max_value=1.0))
    low_threshold = draw(st.floats(min_value=0.0, max_value=50.0))
    medium_threshold = draw(st.floats(min_value=low_threshold + 0.1, max_value=100.0))
    
    utility_programs = draw(st.lists(
        st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))),
        min_size=0,
        max_size=10
    ))
    
    include_inferred = draw(st.booleans())
    warn_on_missing = draw(st.booleans())
    fail_on_invalid = draw(st.booleans())
    
    generate_sorted = draw(st.booleans())
    generate_csv = draw(st.booleans())
    pretty_print = draw(st.booleans())
    indent_size = draw(st.integers(min_value=0, max_value=8))
    
    return {
        "complexity": {
            "formula": {
                "cc_weight": cc_weight,
                "loc_weight": loc_weight,
            },
            "tiers": {
                "low_threshold": low_threshold,
                "medium_threshold": medium_threshold,
            },
        },
        "utility_programs": utility_programs,
        "transformation": {
            "include_inferred_entry_points": include_inferred,
            "warn_on_missing_metrics": warn_on_missing,
            "fail_on_invalid_schema": fail_on_invalid,
        },
        "output": {
            "generate_sorted_variants": generate_sorted,
            "generate_csv_exports": generate_csv,
            "pretty_print_json": pretty_print,
            "indent_size": indent_size,
        },
    }


@given(config_dict=valid_config_dict())
@settings(max_examples=100, deadline=None)
def test_property_21_configuration_application(config_dict):
    """
    Feature: atx-dependency-transformer, Property 21: Configuration Application
    
    For any configuration file specifying utility programs, complexity thresholds, or formula weights,
    the transformation should apply those settings instead of defaults.
    
    Validates: Requirements AC-4.2
    """
    # Create a temporary YAML file with the configuration
    import yaml
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = Path(f.name)
    
    try:
        # Load configuration from file
        manager = ConfigurationManager(temp_path)
        config = manager.load()
        
        # Property 1: Configuration values should match what was specified in the file
        assert abs(config.complexity.formula.cc_weight - config_dict["complexity"]["formula"]["cc_weight"]) < 0.001, \
            "CC weight should match configuration file"
        
        assert abs(config.complexity.formula.loc_weight - config_dict["complexity"]["formula"]["loc_weight"]) < 0.001, \
            "LOC weight should match configuration file"
        
        assert abs(config.complexity.tiers.low_threshold - config_dict["complexity"]["tiers"]["low_threshold"]) < 0.001, \
            "Low threshold should match configuration file"
        
        assert abs(config.complexity.tiers.medium_threshold - config_dict["complexity"]["tiers"]["medium_threshold"]) < 0.001, \
            "Medium threshold should match configuration file"
        
        # Property 2: Utility programs should match exactly
        assert config.utility_programs == config_dict["utility_programs"], \
            "Utility programs should match configuration file"
        
        # Property 3: Transformation options should match
        assert config.transformation.include_inferred_entry_points == config_dict["transformation"]["include_inferred_entry_points"], \
            "include_inferred_entry_points should match configuration file"
        
        assert config.transformation.warn_on_missing_metrics == config_dict["transformation"]["warn_on_missing_metrics"], \
            "warn_on_missing_metrics should match configuration file"
        
        assert config.transformation.fail_on_invalid_schema == config_dict["transformation"]["fail_on_invalid_schema"], \
            "fail_on_invalid_schema should match configuration file"
        
        # Property 4: Output options should match
        assert config.output.generate_sorted_variants == config_dict["output"]["generate_sorted_variants"], \
            "generate_sorted_variants should match configuration file"
        
        assert config.output.generate_csv_exports == config_dict["output"]["generate_csv_exports"], \
            "generate_csv_exports should match configuration file"
        
        assert config.output.pretty_print_json == config_dict["output"]["pretty_print_json"], \
            "pretty_print_json should match configuration file"
        
        assert config.output.indent_size == config_dict["output"]["indent_size"], \
            "indent_size should match configuration file"
        
        # Property 5: Configuration should be usable (not defaults)
        default_config = ConfigurationManager.get_default_config()
        
        # At least one value should differ from defaults (unless by chance they match)
        # This ensures the configuration was actually applied
        differs_from_default = (
            abs(config.complexity.formula.cc_weight - default_config.complexity.formula.cc_weight) > 0.001 or
            abs(config.complexity.formula.loc_weight - default_config.complexity.formula.loc_weight) > 0.001 or
            abs(config.complexity.tiers.low_threshold - default_config.complexity.tiers.low_threshold) > 0.001 or
            abs(config.complexity.tiers.medium_threshold - default_config.complexity.tiers.medium_threshold) > 0.001 or
            config.utility_programs != default_config.utility_programs or
            config.transformation.include_inferred_entry_points != default_config.transformation.include_inferred_entry_points or
            config.transformation.warn_on_missing_metrics != default_config.transformation.warn_on_missing_metrics or
            config.transformation.fail_on_invalid_schema != default_config.transformation.fail_on_invalid_schema or
            config.output.generate_sorted_variants != default_config.output.generate_sorted_variants or
            config.output.generate_csv_exports != default_config.output.generate_csv_exports or
            config.output.pretty_print_json != default_config.output.pretty_print_json or
            config.output.indent_size != default_config.output.indent_size
        )
        
        # Note: We don't assert differs_from_default because random generation might
        # occasionally produce default values. The important property is that the
        # configuration matches what was in the file, not that it differs from defaults.
        
        # Property 6: Configuration should be valid (no exceptions during creation)
        # This is implicitly tested by the fact that we got here without exceptions
        
        # Property 7: Utility program checking should work with configured programs
        for program in config.utility_programs:
            assert config.is_utility_program(program) is True, \
                f"Configured utility program {program} should be recognized"
            assert config.is_utility_program(program.lower()) is True, \
                f"Utility program check should be case-insensitive for {program}"
        
        # Property 8: Non-utility programs should not be recognized
        non_utility = "NOTAUTILITYPROGRAM123"
        if non_utility not in [p.upper() for p in config.utility_programs]:
            assert config.is_utility_program(non_utility) is False, \
                "Non-utility program should not be recognized"
        
    finally:
        # Clean up temporary file
        temp_path.unlink()


@given(
    cc_weight=st.floats(min_value=0.0, max_value=1.0),
    loc_weight=st.floats(min_value=0.0, max_value=1.0),
)
@settings(max_examples=100, deadline=None)
def test_property_21_complexity_formula_application(cc_weight, loc_weight):
    """
    Feature: atx-dependency-transformer, Property 21: Configuration Application (Complexity Formula)
    
    For any custom complexity formula weights in configuration, the composite score calculation
    should use those weights instead of defaults.
    
    Validates: Requirements AC-4.1, AC-4.3
    """
    import yaml
    
    config_dict = {
        "complexity": {
            "formula": {
                "cc_weight": cc_weight,
                "loc_weight": loc_weight,
            }
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = Path(f.name)
    
    try:
        # Load configuration
        manager = ConfigurationManager(temp_path)
        config = manager.load()
        
        # Property: Formula weights should match configuration
        assert abs(config.complexity.formula.cc_weight - cc_weight) < 0.001, \
            f"CC weight should be {cc_weight}, got {config.complexity.formula.cc_weight}"
        
        assert abs(config.complexity.formula.loc_weight - loc_weight) < 0.001, \
            f"LOC weight should be {loc_weight}, got {config.complexity.formula.loc_weight}"
        
        # Property: Complexity calculator should use configured weights
        from tools.atx.dependency_transformer.analysis import ComplexityCalculator
        calculator = ComplexityCalculator(config.complexity)
        
        # Test with known values
        cc = 10
        loc = 1000
        expected_score = (cc * cc_weight) + (loc / 100.0 * loc_weight)
        actual_score = calculator.calculate_composite_score(cc, loc)
        
        assert abs(actual_score - expected_score) < 0.001, \
            f"Calculator should use configured weights: expected {expected_score}, got {actual_score}"
        
    finally:
        temp_path.unlink()


@given(
    low_threshold=st.floats(min_value=0.0, max_value=50.0),
)
@settings(max_examples=100, deadline=None)
def test_property_21_complexity_tier_application(low_threshold):
    """
    Feature: atx-dependency-transformer, Property 21: Configuration Application (Complexity Tiers)
    
    For any custom complexity tier thresholds in configuration, the tier assignment
    should use those thresholds instead of defaults.
    
    Validates: Requirements AC-4.3
    """
    import yaml
    
    # Ensure medium_threshold > low_threshold
    medium_threshold = low_threshold + 10.0
    
    config_dict = {
        "complexity": {
            "tiers": {
                "low_threshold": low_threshold,
                "medium_threshold": medium_threshold,
            }
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(config_dict, f)
        temp_path = Path(f.name)
    
    try:
        # Load configuration
        manager = ConfigurationManager(temp_path)
        config = manager.load()
        
        # Property: Tier thresholds should match configuration
        assert abs(config.complexity.tiers.low_threshold - low_threshold) < 0.001, \
            f"Low threshold should be {low_threshold}, got {config.complexity.tiers.low_threshold}"
        
        assert abs(config.complexity.tiers.medium_threshold - medium_threshold) < 0.001, \
            f"Medium threshold should be {medium_threshold}, got {config.complexity.tiers.medium_threshold}"
        
        # Property: Complexity calculator should use configured thresholds
        from tools.atx.dependency_transformer.analysis import ComplexityCalculator
        calculator = ComplexityCalculator(config.complexity)
        
        # Test tier assignment with configured thresholds
        score_low = low_threshold - 1.0
        score_medium = (low_threshold + medium_threshold) / 2.0
        score_high = medium_threshold + 1.0
        
        if score_low >= 0:
            tier_low = calculator.assign_tier(score_low)
            assert tier_low == "LOW", \
                f"Score {score_low} should be LOW with threshold {low_threshold}"
        
        tier_medium = calculator.assign_tier(score_medium)
        assert tier_medium == "MEDIUM", \
            f"Score {score_medium} should be MEDIUM with thresholds {low_threshold}/{medium_threshold}"
        
        tier_high = calculator.assign_tier(score_high)
        assert tier_high == "HIGH", \
            f"Score {score_high} should be HIGH with threshold {medium_threshold}"
        
    finally:
        temp_path.unlink()
