"""
Property-based tests for roadmap markdown structure.

Feature: migration-workpackage-planner
Property 14: Roadmap Markdown Structure
Validates: Requirements 5.8, 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7
"""

import tempfile
from pathlib import Path
from hypothesis import given, strategies as st, settings

from tools.migration_planner.models import (
    BusinessFlow,
    Program,
    PriorityResult,
    PriorityFactors,
    WorkpackageAssignment,
    PhaseAssignment,
    MigrationSequenceItem,
    PlanningData,
    Metadata,
    Statistics,
)
from tools.migration_planner.output import OutputGenerator


# Custom strategies
@st.composite
def business_flow_strategy(draw, flow_id=None):
    """Generate a random business flow."""
    if flow_id is None:
        flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'))))
    name = draw(st.text(min_size=1, max_size=50))
    
    # Generate programs
    num_programs = draw(st.integers(min_value=1, max_value=10))
    programs = []
    for i in range(num_programs):
        prog_name = f"PROG{i:03d}"
        is_utility = draw(st.booleans())
        programs.append(Program(name=prog_name, is_utility=is_utility))
    
    # Generate databases
    num_dbs = draw(st.integers(min_value=0, max_value=5))
    databases = [f"DB{i}" for i in range(num_dbs)]
    
    total_programs = len(programs)
    composite_score = draw(st.floats(min_value=0.0, max_value=100.0))
    
    # Generate dependencies
    required_flows = []
    
    return BusinessFlow(
        flow_id=flow_id,
        name=name,
        programs=programs,
        databases=databases,
        total_programs=total_programs,
        composite_score=composite_score,
        required_flows=required_flows,
        dependent_flows=[]
    )


@st.composite
def planning_data_strategy(draw):
    """Generate random planning data."""
    # Generate project name without control characters
    project_name = draw(st.text(min_size=1, max_size=30, alphabet=st.characters(blacklist_categories=('Cc',))))
    
    # Generate flows with unique flow_ids
    num_flows = draw(st.integers(min_value=2, max_value=15))
    flows = []
    for i in range(num_flows):
        flow_id = f"FLOW{i:03d}"
        flow = draw(business_flow_strategy(flow_id=flow_id))
        flows.append(flow)
    
    # Add some dependencies
    for i in range(1, min(3, num_flows)):
        if i < len(flows):
            flows[i].required_flows = [flows[0].flow_id]
    
    # Generate priorities
    priorities = {}
    for flow in flows:
        priority_score = draw(st.floats(min_value=0.0, max_value=100.0))
        factors = PriorityFactors(
            total_programs=flow.total_programs,
            common_modules=draw(st.integers(min_value=0, max_value=5)),
            composite_score=flow.composite_score,
            complete_flow_bonus=draw(st.integers(min_value=-5, max_value=0)),
            simple_flow_bonus=draw(st.integers(min_value=-3, max_value=0))
        )
        priorities[flow.flow_id] = PriorityResult(
            flow_id=flow.flow_id,
            priority_score=priority_score,
            factors=factors
        )
    
    # Generate workpackage assignments
    flow_priorities = {}
    for idx, flow in enumerate(flows, start=1):
        wp = WorkpackageAssignment(
            workpackage_id=idx,
            flow_id=flow.flow_id,
            priority_score=priorities[flow.flow_id].priority_score,
            preexistent_modules=[]
        )
        flow_priorities[flow.flow_id] = wp
    
    # Generate phases
    num_phases = draw(st.integers(min_value=1, max_value=min(5, num_flows)))
    phases = []
    workpackages_per_phase = [[] for _ in range(num_phases)]
    
    for idx, flow in enumerate(flows, start=1):
        phase_idx = idx % num_phases
        workpackages_per_phase[phase_idx].append(idx)
    
    for phase_id in range(1, num_phases + 1):
        phase = PhaseAssignment(
            phase_id=phase_id,
            workpackages=workpackages_per_phase[phase_id - 1],
            dependencies=list(range(1, phase_id))
        )
        phases.append(phase)
    
    # Generate migration sequence
    migration_sequence = []
    for seq_num, flow in enumerate(flows, start=1):
        item = MigrationSequenceItem(
            sequence_number=seq_num,
            workpackage_id=seq_num,
            flow_id=flow.flow_id,
            phase=(seq_num % num_phases) + 1,
            prerequisites=[]
        )
        migration_sequence.append(item)
    
    # Create metadata and statistics
    metadata = Metadata.create(project_name)
    statistics = Statistics.calculate(flow_priorities, phases)
    
    planning_data = PlanningData(
        metadata=metadata,
        flow_priorities=flow_priorities,
        phases=phases,
        migration_sequence=migration_sequence,
        statistics=statistics
    )
    
    return planning_data, flows


@settings(max_examples=100, deadline=None)
@given(data=planning_data_strategy())
def test_roadmap_markdown_structure(data):
    """
    Property 14: Roadmap Markdown Structure
    
    For any planning data, the generated markdown should contain all required
    sections (executive summary, phase breakdown, dependency visualization,
    migration sequence table) with correct formatting.
    
    Validates: Requirements 5.8, 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7
    """
    planning_data, flows = data
    
    # Create temporary output directory
    with tempfile.TemporaryDirectory() as tmpdir:
        output_base = Path(tmpdir)
        generator = OutputGenerator(output_base, planning_data.metadata.project_name)
        
        # Generate roadmap markdown
        output_path = generator.generate_roadmap_markdown(planning_data, flows)
        
        # Verify file was created
        assert output_path.exists(), "Roadmap markdown file should be created"
        
        # Read the markdown content
        with open(output_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Requirement 9.7: Include metadata in header
        assert planning_data.metadata.project_name in content, \
            "Roadmap should contain project name"
        assert "Generated:" in content, "Roadmap should contain generation date"
        assert "Version:" in content, "Roadmap should contain version"
        
        # Requirement 9.1: Executive summary with total flows, phases, average priority
        assert "## Executive Summary" in content, \
            "Roadmap should contain Executive Summary section"
        assert "Total Flows:" in content, \
            "Executive summary should contain total flows"
        assert "Total Phases:" in content, \
            "Executive summary should contain total phases"
        assert "Average Priority Score:" in content, \
            "Executive summary should contain average priority score"
        
        # Verify statistics values are present
        assert str(planning_data.statistics.total_flows) in content, \
            "Total flows value should be in content"
        assert str(planning_data.statistics.total_phases) in content, \
            "Total phases value should be in content"
        
        # Requirement 9.2: Phase breakdown section
        assert "## Phase Breakdown" in content, \
            "Roadmap should contain Phase Breakdown section"
        
        # Requirement 9.3: Each phase has subsection with workpackages
        for phase in planning_data.phases:
            phase_header = f"### Phase {phase.phase_id}"
            assert phase_header in content, \
                f"Roadmap should contain {phase_header}"
            assert "Workpackages:" in content, \
                "Phase section should list workpackages"
        
        # Requirement 9.4: Dependency visualization section
        assert "## Dependency Visualization" in content, \
            "Roadmap should contain Dependency Visualization section"
        assert "### Flow Dependencies" in content, \
            "Dependency section should have Flow Dependencies subsection"
        
        # Requirement 9.5: Migration sequence table
        assert "## Migration Sequence" in content, \
            "Roadmap should contain Migration Sequence section"
        
        # Verify table structure (markdown table with headers)
        assert "| Seq | Workpackage | Flow ID | Phase | Prerequisites |" in content, \
            "Migration sequence should have table headers"
        assert "|-----|-------------|---------|-------|---------------|" in content, \
            "Migration sequence should have table separator"
        
        # Requirement 9.6: Format with proper Markdown syntax
        # Check for markdown headers
        assert content.count("# ") >= 1, "Should have at least one H1 header"
        assert content.count("## ") >= 3, "Should have multiple H2 headers"
        assert content.count("### ") >= 1, "Should have at least one H3 header"
        
        # Check for markdown lists
        assert "- **" in content, "Should contain markdown list items"
        
        # Check for horizontal rules
        assert "---" in content, "Should contain horizontal rules"
        
        # Verify all workpackages are mentioned
        for flow_id, wp in planning_data.flow_priorities.items():
            wp_str = f"WP{wp.workpackage_id}"
            assert wp_str in content, \
                f"Workpackage {wp_str} should be mentioned in roadmap"
        
        # Verify migration sequence items are present
        for item in planning_data.migration_sequence:
            # Check that sequence number appears in table
            assert f"| {item.sequence_number} |" in content, \
                f"Sequence number {item.sequence_number} should appear in table"
