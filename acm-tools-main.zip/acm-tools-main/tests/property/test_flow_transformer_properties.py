"""
Property-based tests for FlowTransformer.

Tests universal properties that should hold for all flow transformations.
"""

from hypothesis import given, strategies as st, settings, assume
import json
from pathlib import Path
from tools.atx.dependency_transformer.transformers import FlowTransformer
from tools.atx.dependency_transformer.loaders import (
    ATXDependencyLoader,
    ATXAssetsLoader,
    ATXDataOperationsLoader
)
from tools.atx.dependency_transformer.analysis import (
    CallGraphAnalyzer,
    ComplexityCalculator
)
from tools.atx.dependency_transformer.models.config_models import TransformationConfig


def setup_transformer():
    """
    Set up a FlowTransformer with real CardDemo data.
    
    Returns:
        Tuple of (transformer, dependency_loader, assets_loader, data_ops_loader, call_graph)
    """
    from tools.atx.dependency_transformer.loaders import PathResolver
    
    # Load dependencies
    dep_loader = ATXDependencyLoader()
    dep_loader.load('examples/atx/dependency-analysis/dependencies.json')
    
    # Load assets
    assets_loader = ATXAssetsLoader()
    assets_loader.load('examples/atx/inventory/assets.csv')
    
    # Load data operations
    data_ops_loader = ATXDataOperationsLoader()
    data_ops_loader.load('examples/atx/data-analysis/program_to_dsn.json')
    
    # Build call graph
    call_graph = CallGraphAnalyzer()
    program_calls = {}
    for dep in dep_loader.get_all_dependencies():
        if dep.type == 'COB':
            calls = dep_loader.get_program_calls(dep.name)
            program_calls[dep.name] = calls
    call_graph.build_call_graph(program_calls)
    
    # Create PathResolver with search paths
    path_resolver = PathResolver(search_paths=['.', './examples/code'])
    
    # Create complexity calculator
    config = TransformationConfig()
    complexity_calc = ComplexityCalculator(config.complexity)
    
    # Create transformer
    transformer = FlowTransformer(
        dependency_loader=dep_loader,
        assets_loader=assets_loader,
        data_ops_loader=data_ops_loader,
        path_resolver=path_resolver,
        call_graph=call_graph,
        complexity_calc=complexity_calc,
        config=config
    )
    
    return transformer, dep_loader, assets_loader, data_ops_loader, call_graph


def test_property_6_entry_point_type_mapping():
    """
    Feature: atx-dependency-transformer, Property 6: Entry Point Type Mapping
    
    For any ATX dependency with type="TRANSACTION", a flow should be created with
    primaryType="CICS_TRANSACTION", and for any JCL entry with "Exec program",
    a flow should be created with primaryType="JCL".
    
    Validates: Requirements AC-1.6, AC-1.11
    """
    transformer, dep_loader, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    # Get transactions and JCL from dependencies
    transactions = dep_loader.get_transactions()
    jcl_jobs = dep_loader.get_jcl_jobs()
    
    # Property: Each TRANSACTION should produce a flow with CICS_TRANSACTION type
    transaction_names = {t.name for t in transactions}
    cics_flows = [f for f in flows if f.entry_point.primary_type == "CICS_TRANSACTION"]
    
    for flow in cics_flows:
        # Flow should have CICS_TRANSACTION as primary type
        assert flow.entry_point.primary_type == "CICS_TRANSACTION", \
            f"Flow {flow.flow_id} should have CICS_TRANSACTION as primary type"
        
        # Flow should have at least one entry point type
        assert len(flow.entry_point.types) > 0, \
            f"Flow {flow.flow_id} should have at least one entry point type"
        
        # First entry point type should be CICS_TRANSACTION
        assert flow.entry_point.types[0].type == "CICS_TRANSACTION", \
            f"Flow {flow.flow_id} first entry point type should be CICS_TRANSACTION"
        
        # Flow name should indicate CICS
        assert "CICS" in flow.name or "Transaction" in flow.name, \
            f"Flow {flow.flow_id} name should indicate CICS transaction"
    
    # Property: Each JCL with Exec program should produce a flow with JCL type
    jcl_flows = [f for f in flows if f.entry_point.primary_type == "JCL"]
    
    for flow in jcl_flows:
        # Flow should have JCL as primary type
        assert flow.entry_point.primary_type == "JCL", \
            f"Flow {flow.flow_id} should have JCL as primary type"
        
        # Flow should have at least one entry point type
        assert len(flow.entry_point.types) > 0, \
            f"Flow {flow.flow_id} should have at least one entry point type"
        
        # First entry point type should be JCL
        assert flow.entry_point.types[0].type == "JCL", \
            f"Flow {flow.flow_id} first entry point type should be JCL"
        
        # Flow name should indicate JCL or Batch
        assert "JCL" in flow.name or "Job" in flow.name, \
            f"Flow {flow.flow_id} name should indicate JCL job"
    
    # Property: All flows should have valid entry point types
    for flow in flows:
        assert flow.entry_point.primary_type in ["CICS_TRANSACTION", "JCL"], \
            f"Flow {flow.flow_id} has invalid primary type: {flow.entry_point.primary_type}"


def test_property_7_scope_completeness():
    """
    Feature: atx-dependency-transformer, Property 7: Scope Completeness
    
    For any flow entry point program P, the flow scope should include P,
    all programs transitively called by P, all copybooks used by programs
    in scope, and all datasets referenced by programs in scope.
    
    Validates: Requirements AC-1.7
    """
    transformer, dep_loader, _, data_ops_loader, call_graph = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        entry_program = flow.entry_point.program
        scope_program_names = {p.name for p in flow.scope.programs}
        
        # Property: Entry program should be in scope
        assert entry_program in scope_program_names, \
            f"Flow {flow.flow_id}: Entry program {entry_program} should be in scope"
        
        # Property: All transitive dependencies should be in scope
        transitive_deps = call_graph.get_transitive_dependencies(entry_program)
        for dep_program in transitive_deps:
            assert dep_program in scope_program_names, \
                f"Flow {flow.flow_id}: Transitive dependency {dep_program} should be in scope"
        
        # Property: Scope should include entry program + transitive dependencies
        expected_programs = {entry_program} | transitive_deps
        assert scope_program_names == expected_programs, \
            f"Flow {flow.flow_id}: Scope programs mismatch. Expected {expected_programs}, got {scope_program_names}"
        
        # Property: All copybooks used by programs in scope should be in flow copybooks
        expected_copybooks = set()
        for prog in scope_program_names:
            prog_copybooks = dep_loader.get_copybooks(prog)
            expected_copybooks.update(prog_copybooks)
        
        flow_copybooks = set(flow.scope.copybooks)
        assert flow_copybooks == expected_copybooks, \
            f"Flow {flow.flow_id}: Copybooks mismatch. Expected {expected_copybooks}, got {flow_copybooks}"
        
        # Property: All datasets referenced by programs in scope should be in flow datasets
        expected_datasets = set()
        for prog in scope_program_names:
            # Get datasets from dependencies
            prog_datasets = dep_loader.get_datasets(prog)
            expected_datasets.update(prog_datasets)
            
            # Get datasets from data operations
            data_ops_datasets = data_ops_loader.get_datasets_for_program(prog)
            expected_datasets.update(data_ops_datasets)
        
        flow_datasets = set(flow.scope.datasets)
        assert flow_datasets == expected_datasets, \
            f"Flow {flow.flow_id}: Datasets mismatch. Expected {expected_datasets}, got {flow_datasets}"


def test_property_8_data_operations_extraction():
    """
    Feature: atx-dependency-transformer, Property 8: Data Operations Extraction
    
    For any program in program_to_dsn.json with access type "READ; WRITE; UPDATE",
    the flow data operations should include separate operations for each access type.
    
    Validates: Requirements AC-1.8
    """
    transformer, _, _, data_ops_loader, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        scope_program_names = {p.name for p in flow.scope.programs}
        
        # Collect all expected operations from program_to_dsn
        expected_operations = {}  # (program, dataset, operation) -> count
        
        for prog in scope_program_names:
            operations = data_ops_loader.get_operations_for_program(prog)
            
            for op in operations:
                access_types = op.get_access_types()
                
                # Property: Each access type should create a separate operation
                for access_type in access_types:
                    key = (prog, op.data_source_name, access_type)
                    expected_operations[key] = expected_operations.get(key, 0) + 1
        
        # Collect actual operations from flow
        actual_operations = {}  # (program, dataset, operation) -> count
        
        for db_op in flow.data_operations.databases:
            key = (db_op.program, db_op.target, db_op.operation)
            actual_operations[key] = actual_operations.get(key, 0) + 1
        
        for ds_op in flow.data_operations.datasets:
            key = (ds_op.program, ds_op.dataset, ds_op.operation)
            actual_operations[key] = actual_operations.get(key, 0) + 1
        
        # Property: All expected operations should be present
        for key, count in expected_operations.items():
            assert key in actual_operations, \
                f"Flow {flow.flow_id}: Missing operation {key}"
            
            # Note: We don't check exact counts because the same operation
            # might appear multiple times in the source data
        
        # Property: All operations should reference programs in scope
        for db_op in flow.data_operations.databases:
            assert db_op.program in scope_program_names, \
                f"Flow {flow.flow_id}: Database operation references program {db_op.program} not in scope"
        
        for ds_op in flow.data_operations.datasets:
            assert ds_op.program in scope_program_names, \
                f"Flow {flow.flow_id}: Dataset operation references program {ds_op.program} not in scope"
        
        # Property: Operations should have valid access types
        valid_access_types = {"READ", "WRITE", "UPDATE", "DELETE", "OPEN", "CLOSE"}
        
        for db_op in flow.data_operations.databases:
            assert db_op.operation in valid_access_types, \
                f"Flow {flow.flow_id}: Invalid database operation type: {db_op.operation}"
        
        for ds_op in flow.data_operations.datasets:
            assert ds_op.operation in valid_access_types, \
                f"Flow {flow.flow_id}: Invalid dataset operation type: {ds_op.operation}"


def test_flow_id_generation():
    """
    Test that flow IDs are generated correctly and uniquely.
    
    Validates: Requirements AC-1.10
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    # Property: All flow IDs should be unique
    flow_ids = [f.flow_id for f in flows]
    assert len(flow_ids) == len(set(flow_ids)), \
        f"Flow IDs should be unique. Found duplicates: {[id for id in flow_ids if flow_ids.count(id) > 1]}"
    
    # Property: Flow IDs should follow naming convention
    for flow in flows:
        if flow.entry_point.primary_type == "CICS_TRANSACTION":
            assert flow.flow_id.startswith("FLOW_CICS_"), \
                f"CICS flow ID should start with FLOW_CICS_: {flow.flow_id}"
        elif flow.entry_point.primary_type == "JCL":
            assert flow.flow_id.startswith("FLOW_BATCH_"), \
                f"JCL flow ID should start with FLOW_BATCH_: {flow.flow_id}"
        
        # Property: Flow ID should not contain special characters
        assert all(c.isalnum() or c == '_' for c in flow.flow_id), \
            f"Flow ID should only contain alphanumeric and underscore: {flow.flow_id}"


def test_flow_name_generation():
    """
    Test that flow names are generated correctly.
    
    Validates: Requirements AC-1.10
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    # Property: All flows should have non-empty names
    for flow in flows:
        assert flow.name, \
            f"Flow {flow.flow_id} should have a non-empty name"
        
        # Property: Flow name should indicate type
        if flow.entry_point.primary_type == "CICS_TRANSACTION":
            assert "CICS" in flow.name or "Transaction" in flow.name, \
                f"CICS flow name should indicate transaction: {flow.name}"
        elif flow.entry_point.primary_type == "JCL":
            assert "JCL" in flow.name or "Job" in flow.name, \
                f"JCL flow name should indicate job: {flow.name}"


def test_complexity_calculation():
    """
    Test that complexity is calculated correctly for flows.
    
    Validates: Requirements AC-1.4, AC-1.5
    """
    transformer, _, assets_loader, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    metrics_cache = assets_loader.get_all_metrics()
    
    for flow in flows:
        # Property: Complexity should have valid values
        assert flow.complexity.total_programs >= 0, \
            f"Flow {flow.flow_id}: total_programs should be non-negative"
        assert flow.complexity.total_lines >= 0, \
            f"Flow {flow.flow_id}: total_lines should be non-negative"
        assert flow.complexity.cyclomatic_complexity >= 0, \
            f"Flow {flow.flow_id}: cyclomatic_complexity should be non-negative"
        assert flow.complexity.composite_score >= 0, \
            f"Flow {flow.flow_id}: composite_score should be non-negative"
        
        # Property: Tier should be valid
        assert flow.complexity.tier in ["LOW", "MEDIUM", "HIGH"], \
            f"Flow {flow.flow_id}: Invalid tier: {flow.complexity.tier}"
        
        # Property: Total programs should match scope
        assert flow.complexity.total_programs == len(flow.scope.programs), \
            f"Flow {flow.flow_id}: total_programs mismatch"
        
        # Property: Complexity should match manual calculation
        expected_cc = 0
        expected_loc = 0
        for prog in flow.scope.programs:
            if prog.name in metrics_cache:
                metrics = metrics_cache[prog.name]
                expected_cc += metrics.cyclomatic_complexity
                expected_loc += metrics.total_lines
        
        assert flow.complexity.cyclomatic_complexity == expected_cc, \
            f"Flow {flow.flow_id}: CC mismatch. Expected {expected_cc}, got {flow.complexity.cyclomatic_complexity}"
        assert flow.complexity.total_lines == expected_loc, \
            f"Flow {flow.flow_id}: LOC mismatch. Expected {expected_loc}, got {flow.complexity.total_lines}"
        
        # Property: Composite score should match formula
        expected_score = (expected_cc * 0.3) + (expected_loc / 100.0 * 0.7)
        assert abs(flow.complexity.composite_score - expected_score) < 0.001, \
            f"Flow {flow.flow_id}: Composite score mismatch. Expected {expected_score}, got {flow.complexity.composite_score}"


def test_utility_program_classification():
    """
    Test that utility programs are correctly classified in scope.
    
    Validates: Requirements AC-1.7
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    # Get utility programs from config
    utility_programs = set(p.upper() for p in transformer.config.utility_programs)
    
    for flow in flows:
        for prog in flow.scope.programs:
            # Property: Utility flag should match configuration
            expected_is_utility = prog.name.upper() in utility_programs
            assert prog.is_utility == expected_is_utility, \
                f"Flow {flow.flow_id}: Program {prog.name} utility flag mismatch. Expected {expected_is_utility}, got {prog.is_utility}"


def test_entry_point_callers():
    """
    Test that entry point callers are correctly populated.
    
    Validates: Requirements AC-1.6
    """
    transformer, dep_loader, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        # Property: Entry point should have at least one type
        assert len(flow.entry_point.types) > 0, \
            f"Flow {flow.flow_id}: Entry point should have at least one type"
        
        # Property: Each entry point type should have at least one caller
        for ep_type in flow.entry_point.types:
            assert len(ep_type.callers) > 0, \
                f"Flow {flow.flow_id}: Entry point type {ep_type.type} should have at least one caller"
            
            # Property: Callers should have source
            for caller in ep_type.callers:
                assert caller.source, \
                    f"Flow {flow.flow_id}: Caller should have a source"
                
                # Property: Caller metadata should be a dict
                assert isinstance(caller.metadata, dict), \
                    f"Flow {flow.flow_id}: Caller metadata should be a dict"


def test_flow_structure_completeness():
    """
    Test that all flows have complete structure.
    
    Validates: Requirements AC-1.10
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        # Property: Flow should have all required fields
        assert flow.flow_id, f"Flow should have flow_id"
        assert flow.name, f"Flow {flow.flow_id} should have name"
        assert flow.entry_point, f"Flow {flow.flow_id} should have entry_point"
        assert flow.scope, f"Flow {flow.flow_id} should have scope"
        assert flow.data_operations, f"Flow {flow.flow_id} should have data_operations"
        assert flow.complexity, f"Flow {flow.flow_id} should have complexity"
        assert flow.dependencies, f"Flow {flow.flow_id} should have dependencies"
        
        # Property: Entry point should have program
        assert flow.entry_point.program, \
            f"Flow {flow.flow_id}: Entry point should have program"
        
        # Property: Scope should have programs list
        assert isinstance(flow.scope.programs, list), \
            f"Flow {flow.flow_id}: Scope programs should be a list"
        
        # Property: Data operations should have databases and datasets lists
        assert isinstance(flow.data_operations.databases, list), \
            f"Flow {flow.flow_id}: Data operations databases should be a list"
        assert isinstance(flow.data_operations.datasets, list), \
            f"Flow {flow.flow_id}: Data operations datasets should be a list"


def test_no_duplicate_programs_in_scope():
    """
    Test that scope doesn't contain duplicate programs.
    
    Validates: Requirements AC-1.7
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        program_names = [p.name for p in flow.scope.programs]
        
        # Property: No duplicate programs in scope
        assert len(program_names) == len(set(program_names)), \
            f"Flow {flow.flow_id}: Scope contains duplicate programs: {[p for p in program_names if program_names.count(p) > 1]}"


def test_sorted_scope_elements():
    """
    Test that scope elements are sorted for deterministic output.
    
    Validates: Requirements AC-1.7
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        # Property: Copybooks should be sorted
        copybooks = flow.scope.copybooks
        assert copybooks == sorted(copybooks), \
            f"Flow {flow.flow_id}: Copybooks should be sorted"
        
        # Property: Datasets should be sorted
        datasets = flow.scope.datasets
        assert datasets == sorted(datasets), \
            f"Flow {flow.flow_id}: Datasets should be sorted"


def test_property_9_flow_dependency_transitivity():
    """
    Feature: atx-dependency-transformer, Property 9: Flow Dependency Transitivity
    
    For any two flows F1 and F2, if a program in F1's scope calls a program in F2's scope,
    then F1 should list F2 in its requiredFlows and F2 should list F1 in its dependentFlows.
    
    Validates: Requirements AC-1.9
    """
    transformer, _, _, _, call_graph = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    # Build mapping of program to flow
    program_to_flow = {}
    for flow in flows:
        for prog in flow.scope.programs:
            if prog.name not in program_to_flow:
                program_to_flow[prog.name] = []
            program_to_flow[prog.name].append(flow.flow_id)
    
    # Check each flow
    for flow1 in flows:
        flow1_programs = {p.name for p in flow1.scope.programs}
        
        # Find all flows that flow1 should depend on
        expected_required_flows = set()
        
        for prog1 in flow1_programs:
            # Get programs directly called by prog1
            called_programs = call_graph.get_direct_callees(prog1)
            
            # Check if any called program belongs to a different flow
            for called_prog in called_programs:
                if called_prog in program_to_flow:
                    for flow2_id in program_to_flow[called_prog]:
                        if flow2_id != flow1.flow_id:
                            expected_required_flows.add(flow2_id)
        
        # Property: requiredFlows should match expected
        actual_required_flows = set(flow1.dependencies.required_flows)
        assert actual_required_flows == expected_required_flows, \
            f"Flow {flow1.flow_id}: Required flows mismatch. Expected {expected_required_flows}, got {actual_required_flows}"
        
        # Property: For each required flow, this flow should be in its dependent flows
        for required_flow_id in flow1.dependencies.required_flows:
            # Find the required flow
            required_flow = next((f for f in flows if f.flow_id == required_flow_id), None)
            assert required_flow is not None, \
                f"Flow {flow1.flow_id}: Required flow {required_flow_id} not found"
            
            # Check that flow1 is in required_flow's dependent flows
            assert flow1.flow_id in required_flow.dependencies.dependent_flows, \
                f"Flow {flow1.flow_id} requires {required_flow_id}, but {required_flow_id} doesn't list {flow1.flow_id} as dependent"
        
        # Property: For each dependent flow, this flow should be in its required flows
        for dependent_flow_id in flow1.dependencies.dependent_flows:
            # Find the dependent flow
            dependent_flow = next((f for f in flows if f.flow_id == dependent_flow_id), None)
            assert dependent_flow is not None, \
                f"Flow {flow1.flow_id}: Dependent flow {dependent_flow_id} not found"
            
            # Check that flow1 is in dependent_flow's required flows
            assert flow1.flow_id in dependent_flow.dependencies.required_flows, \
                f"Flow {flow1.flow_id} has dependent {dependent_flow_id}, but {dependent_flow_id} doesn't list {flow1.flow_id} as required"


def test_flow_dependencies_are_sorted():
    """
    Test that flow dependencies are sorted for deterministic output.
    
    Validates: Requirements AC-1.9
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        # Property: Required flows should be sorted
        required_flows = flow.dependencies.required_flows
        assert required_flows == sorted(required_flows), \
            f"Flow {flow.flow_id}: Required flows should be sorted"
        
        # Property: Dependent flows should be sorted
        dependent_flows = flow.dependencies.dependent_flows
        assert dependent_flows == sorted(dependent_flows), \
            f"Flow {flow.flow_id}: Dependent flows should be sorted"


def test_no_self_dependencies():
    """
    Test that flows don't depend on themselves.
    
    Validates: Requirements AC-1.9
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    for flow in flows:
        # Property: Flow should not require itself
        assert flow.flow_id not in flow.dependencies.required_flows, \
            f"Flow {flow.flow_id} should not require itself"
        
        # Property: Flow should not be dependent on itself
        assert flow.flow_id not in flow.dependencies.dependent_flows, \
            f"Flow {flow.flow_id} should not be dependent on itself"


def test_dependency_symmetry():
    """
    Test that flow dependencies are symmetric (if A requires B, then B depends on A).
    
    Validates: Requirements AC-1.9
    """
    transformer, _, _, _, _ = setup_transformer()
    
    # Transform all flows
    flows = transformer.transform()
    
    # Build flow lookup
    flow_lookup = {f.flow_id: f for f in flows}
    
    for flow in flows:
        # Property: For each required flow, the relationship should be symmetric
        for required_flow_id in flow.dependencies.required_flows:
            if required_flow_id in flow_lookup:
                required_flow = flow_lookup[required_flow_id]
                assert flow.flow_id in required_flow.dependencies.dependent_flows, \
                    f"Asymmetric dependency: {flow.flow_id} requires {required_flow_id}, but {required_flow_id} doesn't list {flow.flow_id} as dependent"
        
        # Property: For each dependent flow, the relationship should be symmetric
        for dependent_flow_id in flow.dependencies.dependent_flows:
            if dependent_flow_id in flow_lookup:
                dependent_flow = flow_lookup[dependent_flow_id]
                assert flow.flow_id in dependent_flow.dependencies.required_flows, \
                    f"Asymmetric dependency: {flow.flow_id} has dependent {dependent_flow_id}, but {dependent_flow_id} doesn't list {flow.flow_id} as required"


def test_property_21_program_scope_path_inclusion():
    """
    Feature: atx-dependency-transformer, Property 21: Program Scope Path Inclusion
    
    For any program in a flow's scope, if the program file exists on the local filesystem,
    the program entry should include a filePath field with the resolved local path.
    
    Validates: Requirements AC-1.12
    """
    from tools.atx.dependency_transformer.loaders import PathResolver
    
    # Set up transformer with PathResolver
    dep_loader = ATXDependencyLoader()
    dep_loader.load('examples/atx/dependency-analysis/dependencies.json')
    
    assets_loader = ATXAssetsLoader()
    assets_loader.load('examples/atx/inventory/assets.csv')
    
    data_ops_loader = ATXDataOperationsLoader()
    data_ops_loader.load('examples/atx/data-analysis/program_to_dsn.json')
    
    # Build call graph
    call_graph = CallGraphAnalyzer()
    program_calls = {}
    for dep in dep_loader.get_all_dependencies():
        if dep.type == 'COB':
            calls = dep_loader.get_program_calls(dep.name)
            program_calls[dep.name] = calls
    call_graph.build_call_graph(program_calls)
    
    # Create PathResolver with search paths
    path_resolver = PathResolver(search_paths=['.', './examples/code'])
    
    # Create complexity calculator
    config = TransformationConfig()
    complexity_calc = ComplexityCalculator(config.complexity)
    
    # Create transformer with PathResolver
    transformer = FlowTransformer(
        dependency_loader=dep_loader,
        assets_loader=assets_loader,
        data_ops_loader=data_ops_loader,
        path_resolver=path_resolver,
        call_graph=call_graph,
        complexity_calc=complexity_calc,
        config=config
    )
    
    # Transform all flows
    flows = transformer.transform()
    
    # Property: Programs in scope should have file_path when file exists
    for flow in flows:
        for program in flow.scope.programs:
            # Get the program dependency to check if it has a path
            prog_dep = dep_loader.get_by_name(program.name)
            
            if prog_dep and prog_dep.path:
                # If the program has a path in ATX data, check if it was resolved
                resolved_path = path_resolver.resolve_path(prog_dep.path)
                
                if resolved_path:
                    # Property: If path was resolved, program should have file_path
                    assert program.file_path is not None, \
                        f"Flow {flow.flow_id}: Program {program.name} should have file_path when file exists"
                    
                    # Property: file_path should match resolved path
                    assert program.file_path == resolved_path, \
                        f"Flow {flow.flow_id}: Program {program.name} file_path mismatch. Expected {resolved_path}, got {program.file_path}"
                else:
                    # If path couldn't be resolved, file_path should be None
                    assert program.file_path is None, \
                        f"Flow {flow.flow_id}: Program {program.name} should have None file_path when file doesn't exist"
            else:
                # If program has no path in ATX data, file_path should be None
                assert program.file_path is None, \
                    f"Flow {flow.flow_id}: Program {program.name} should have None file_path when no ATX path exists"
    
    # Property: At least some programs should have resolved paths (sanity check)
    programs_with_paths = sum(1 for flow in flows for prog in flow.scope.programs if prog.file_path is not None)
    assert programs_with_paths > 0, \
        "At least some programs should have resolved file paths"


def test_property_22_entry_point_metadata_path_inclusion():
    """
    Feature: atx-dependency-transformer, Property 22: Entry Point Metadata Path Inclusion
    
    For any JCL entry point caller, the caller metadata should include a filePath field
    with the resolved local path to the JCL file.
    
    Validates: Requirements AC-1.13
    """
    from tools.atx.dependency_transformer.loaders import PathResolver
    
    # Set up transformer with PathResolver
    dep_loader = ATXDependencyLoader()
    dep_loader.load('examples/atx/dependency-analysis/dependencies.json')
    
    assets_loader = ATXAssetsLoader()
    assets_loader.load('examples/atx/inventory/assets.csv')
    
    data_ops_loader = ATXDataOperationsLoader()
    data_ops_loader.load('examples/atx/data-analysis/program_to_dsn.json')
    
    # Build call graph
    call_graph = CallGraphAnalyzer()
    program_calls = {}
    for dep in dep_loader.get_all_dependencies():
        if dep.type == 'COB':
            calls = dep_loader.get_program_calls(dep.name)
            program_calls[dep.name] = calls
    call_graph.build_call_graph(program_calls)
    
    # Create PathResolver with search paths
    path_resolver = PathResolver(search_paths=['.', './examples/code'])
    
    # Create complexity calculator
    config = TransformationConfig()
    complexity_calc = ComplexityCalculator(config.complexity)
    
    # Create transformer with PathResolver
    transformer = FlowTransformer(
        dependency_loader=dep_loader,
        assets_loader=assets_loader,
        data_ops_loader=data_ops_loader,
        path_resolver=path_resolver,
        call_graph=call_graph,
        complexity_calc=complexity_calc,
        config=config
    )
    
    # Transform all flows
    flows = transformer.transform()
    
    # Get JCL jobs from dependencies to check paths
    jcl_jobs = dep_loader.get_jcl_jobs()
    jcl_path_map = {jcl.name: jcl.path for jcl in jcl_jobs if jcl.path}
    
    # Property: JCL entry points should have filePath in caller metadata
    jcl_flows = [f for f in flows if f.entry_point.primary_type == "JCL"]
    
    for flow in jcl_flows:
        # Find JCL entry point type
        jcl_entry_types = [et for et in flow.entry_point.types if et.type == "JCL"]
        
        assert len(jcl_entry_types) > 0, \
            f"Flow {flow.flow_id}: JCL flow should have at least one JCL entry point type"
        
        for entry_type in jcl_entry_types:
            for caller in entry_type.callers:
                # Property: Caller should have metadata
                assert isinstance(caller.metadata, dict), \
                    f"Flow {flow.flow_id}: Caller metadata should be a dict"
                
                # Get the JCL name from caller source
                jcl_name = caller.source
                
                # Check if this JCL has a path in ATX data
                if jcl_name in jcl_path_map:
                    atx_path = jcl_path_map[jcl_name]
                    resolved_path = path_resolver.resolve_path(atx_path)
                    
                    if resolved_path:
                        # Property: If JCL file was resolved, metadata should include filePath
                        assert 'filePath' in caller.metadata, \
                            f"Flow {flow.flow_id}: JCL caller {jcl_name} should have filePath in metadata when file exists"
                        
                        # Property: filePath should match resolved path
                        assert caller.metadata['filePath'] == resolved_path, \
                            f"Flow {flow.flow_id}: JCL caller {jcl_name} filePath mismatch. Expected {resolved_path}, got {caller.metadata['filePath']}"
                    else:
                        # If path couldn't be resolved, filePath should not be in metadata
                        # (or should be None if included)
                        if 'filePath' in caller.metadata:
                            assert caller.metadata['filePath'] is None, \
                                f"Flow {flow.flow_id}: JCL caller {jcl_name} should have None filePath when file doesn't exist"
    
    # Property: At least some JCL callers should have resolved paths (sanity check)
    jcl_callers_with_paths = 0
    for flow in jcl_flows:
        for entry_type in flow.entry_point.types:
            if entry_type.type == "JCL":
                for caller in entry_type.callers:
                    if 'filePath' in caller.metadata and caller.metadata['filePath'] is not None:
                        jcl_callers_with_paths += 1
    
    assert jcl_callers_with_paths > 0, \
        "At least some JCL callers should have resolved file paths"

