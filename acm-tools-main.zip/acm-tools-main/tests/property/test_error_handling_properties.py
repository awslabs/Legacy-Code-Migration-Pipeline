"""
Property-based tests for error handling behavior in migration workpackage planner.

Feature: migration-workpackage-planner
Property 17: Error Handling Behavior
"""

import json
import tempfile
import subprocess
import sys
from pathlib import Path
from hypothesis import given, strategies as st, settings, assume

from tools.migration_planner.cli import main
from tools.migration_planner.planner import MigrationPlanner
from tools.migration_planner.models import PlannerConfig
from tools.migration_planner.phase import ValidationError


# Hypothesis strategies for generating test data

@st.composite
def invalid_json_content_strategy(draw):
    """Generate invalid JSON content."""
    invalid_patterns = [
        '{"flows": [invalid}',
        '{"flows": [{"flowId": "test", missing_quote: "value"}]}',
        '{"flows": [{"flowId": "test",}]}',  # Trailing comma
        '{flows: []}',  # Missing quotes on key
        '{"flows": [{"flowId": }]}',  # Missing value
    ]
    return draw(st.sampled_from(invalid_patterns))


@st.composite
def flow_with_circular_dependency_strategy(draw):
    """Generate flows with circular dependencies."""
    # Create two flows that depend on each other
    flow1_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    flow2_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    
    assume(flow1_id != flow2_id)
    
    flows = [
        {
            'flowId': flow1_id,
            'name': 'Flow 1',
            'scope': {
                'programs': [{'name': 'PROG1', 'isUtility': False}]
            },
            'complexity': {
                'totalPrograms': 1,
                'compositeScore': 10.0
            },
            'dependencies': {
                'requiredFlows': [flow2_id],  # Flow1 depends on Flow2
                'dependentFlows': []
            }
        },
        {
            'flowId': flow2_id,
            'name': 'Flow 2',
            'scope': {
                'programs': [{'name': 'PROG2', 'isUtility': False}]
            },
            'complexity': {
                'totalPrograms': 1,
                'compositeScore': 10.0
            },
            'dependencies': {
                'requiredFlows': [flow1_id],  # Flow2 depends on Flow1 (circular!)
                'dependentFlows': []
            }
        }
    ]
    
    return {'flows': flows}


@st.composite
def flow_with_missing_reference_strategy(draw):
    """Generate flows with missing dependency references."""
    flow_id = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    missing_ref = draw(st.text(min_size=1, max_size=20, alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-'
    )))
    
    assume(flow_id != missing_ref)
    
    flows = [
        {
            'flowId': flow_id,
            'name': 'Flow with missing ref',
            'scope': {
                'programs': [{'name': 'PROG1', 'isUtility': False}]
            },
            'complexity': {
                'totalPrograms': 1,
                'compositeScore': 10.0
            },
            'dependencies': {
                'requiredFlows': [missing_ref],  # References non-existent flow
                'dependentFlows': []
            }
        }
    ]
    
    return {'flows': flows}


# Property 17: Error Handling Behavior
# Validates: Requirements 7.4, 7.5

@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_17_invalid_json_produces_clear_error(data):
    """
    Property 17: Error Handling Behavior
    
    For any error condition with invalid JSON, the system should produce a clear
    error message with context and exit with a non-zero exit code.
    
    Validates: Requirements 7.4, 7.5
    """
    invalid_content = data.draw(invalid_json_content_strategy())
    
    # Create temporary file with invalid JSON
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        f.write(invalid_content)
        temp_path = Path(f.name)
    
    try:
        # Create config
        config = PlannerConfig(
            flows_file=temp_path,
            output_base=Path('/tmp/test_output'),
            project_name='test'
        )
        
        # Run planner
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Should not succeed
        assert not result.success, "Should fail with invalid JSON"
        
        # Should have error message
        assert result.error_message, "Should have error message"
        assert len(result.error_message) > 0, "Error message should not be empty"
        
        # Error message should contain context
        error_lower = result.error_message.lower()
        assert 'json' in error_lower or 'invalid' in error_lower or 'validation' in error_lower, \
            f"Error message should indicate JSON/validation error: {result.error_message}"
        
    finally:
        # Clean up
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_17_circular_dependency_produces_clear_error(data):
    """
    Property 17: Error Handling Behavior
    
    For any error condition with circular dependencies, the system should produce
    a clear error message with the cycle path and exit with a non-zero exit code.
    
    Validates: Requirements 7.4, 7.5
    """
    flows_data = data.draw(flow_with_circular_dependency_strategy())
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        # Create config
        config = PlannerConfig(
            flows_file=temp_path,
            output_base=Path('/tmp/test_output'),
            project_name='test'
        )
        
        # Run planner
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Should not succeed
        assert not result.success, "Should fail with circular dependencies"
        
        # Should have error message
        assert result.error_message, "Should have error message"
        assert len(result.error_message) > 0, "Error message should not be empty"
        
        # Error message should contain context about circular dependencies
        error_lower = result.error_message.lower()
        assert 'circular' in error_lower or 'cycle' in error_lower or 'dependency' in error_lower, \
            f"Error message should indicate circular dependency: {result.error_message}"
        
    finally:
        # Clean up
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_17_missing_reference_produces_clear_error(data):
    """
    Property 17: Error Handling Behavior
    
    For any error condition with missing flow references, the system should produce
    a clear error message with the missing flow ID and exit with a non-zero exit code.
    
    Validates: Requirements 7.4, 7.5
    """
    flows_data = data.draw(flow_with_missing_reference_strategy())
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        # Create config
        config = PlannerConfig(
            flows_file=temp_path,
            output_base=Path('/tmp/test_output'),
            project_name='test'
        )
        
        # Run planner
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Should not succeed
        assert not result.success, "Should fail with missing reference"
        
        # Should have error message
        assert result.error_message, "Should have error message"
        assert len(result.error_message) > 0, "Error message should not be empty"
        
        # Error message should contain context about missing reference
        error_lower = result.error_message.lower()
        assert 'reference' in error_lower or 'exist' in error_lower or 'missing' in error_lower or 'dependency' in error_lower, \
            f"Error message should indicate missing reference: {result.error_message}"
        
    finally:
        # Clean up
        temp_path.unlink()


@given(filename=st.text(min_size=1, max_size=50, alphabet=st.characters(
    whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='_-.'
)))
@settings(max_examples=100, deadline=None)
def test_property_17_missing_file_produces_clear_error(filename):
    """
    Property 17: Error Handling Behavior
    
    For any error condition with missing files, the system should produce a clear
    error message with the file path and exit with a non-zero exit code.
    
    Validates: Requirements 7.4, 7.5
    """
    # Create a path that definitely doesn't exist
    non_existent_path = Path(f"/tmp/nonexistent_{filename}_12345.json")
    assume(not non_existent_path.exists())
    
    # Create config with non-existent file
    config = PlannerConfig(
        flows_file=non_existent_path,
        output_base=Path('/tmp/test_output'),
        project_name='test'
    )
    
    # Run planner
    planner = MigrationPlanner(config)
    result = planner.run()
    
    # Should not succeed
    assert not result.success, "Should fail with missing file"
    
    # Should have error message
    assert result.error_message, "Should have error message"
    assert len(result.error_message) > 0, "Error message should not be empty"
    
    # Error message should contain context about file not found
    error_lower = result.error_message.lower()
    assert 'file' in error_lower or 'not found' in error_lower or 'missing' in error_lower, \
        f"Error message should indicate file not found: {result.error_message}"


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_17_error_messages_contain_context(data):
    """
    Property 17: Error Handling Behavior
    
    For any error condition, the error message should contain sufficient context
    to help the user understand what went wrong.
    
    Validates: Requirements 7.4
    """
    # Test with invalid JSON
    invalid_content = data.draw(invalid_json_content_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        f.write(invalid_content)
        temp_path = Path(f.name)
    
    try:
        config = PlannerConfig(
            flows_file=temp_path,
            output_base=Path('/tmp/test_output'),
            project_name='test'
        )
        
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Error message should be descriptive (more than just "error")
        assert len(result.error_message) > 10, \
            "Error message should be descriptive with context"
        
        # Should not just say "error" - should have specific information
        assert result.error_message.lower() != "error", \
            "Error message should be more specific than just 'error'"
        
    finally:
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=50, deadline=None)
def test_property_17_validation_error_exits_with_nonzero_code(data):
    """
    Property 17: Error Handling Behavior
    
    For any validation error, the CLI should exit with a non-zero exit code.
    
    Validates: Requirements 7.5
    """
    # Create flows with circular dependency
    flows_data = data.draw(flow_with_circular_dependency_strategy())
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(flows_data, f)
        temp_path = Path(f.name)
    
    try:
        # Run CLI as subprocess to check exit code
        result = subprocess.run(
            [sys.executable, '-m', 'tools.migration_planner',
             '--flows-file', str(temp_path),
             '--output-base', '/tmp/test_output'],
            capture_output=True,
            text=True
        )
        
        # Should exit with non-zero code
        assert result.returncode != 0, \
            f"Should exit with non-zero code for validation error, got {result.returncode}"
        
        # Should have error output
        assert result.stderr or result.stdout, \
            "Should have error output"
        
    finally:
        temp_path.unlink()


@given(data=st.data())
@settings(max_examples=50, deadline=None)
def test_property_17_file_not_found_exits_with_nonzero_code(data):
    """
    Property 17: Error Handling Behavior
    
    For any file not found error, the CLI should exit with a non-zero exit code.
    
    Validates: Requirements 7.5
    """
    # Create a non-existent file path
    non_existent = Path('/tmp/nonexistent_flows_12345.json')
    assume(not non_existent.exists())
    
    # Run CLI as subprocess to check exit code
    result = subprocess.run(
        [sys.executable, '-m', 'tools.migration_planner',
         '--flows-file', str(non_existent),
         '--output-base', '/tmp/test_output'],
        capture_output=True,
        text=True
    )
    
    # Should exit with non-zero code
    assert result.returncode != 0, \
        f"Should exit with non-zero code for file not found, got {result.returncode}"
    
    # Should have error output
    assert result.stderr or result.stdout, \
        "Should have error output"


@given(data=st.data())
@settings(max_examples=100, deadline=None)
def test_property_17_all_errors_return_planning_result(data):
    """
    Property 17: Error Handling Behavior
    
    For any error condition, the planner should return a PlanningResult object
    with success=False and an error message, rather than raising an exception.
    
    Validates: Requirements 7.4, 7.5
    """
    # Test with various error conditions
    error_type = data.draw(st.sampled_from(['invalid_json', 'circular_dep', 'missing_ref']))
    
    if error_type == 'invalid_json':
        content = data.draw(invalid_json_content_strategy())
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write(content)
            temp_path = Path(f.name)
    elif error_type == 'circular_dep':
        flows_data = data.draw(flow_with_circular_dependency_strategy())
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
    else:  # missing_ref
        flows_data = data.draw(flow_with_missing_reference_strategy())
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(flows_data, f)
            temp_path = Path(f.name)
    
    try:
        config = PlannerConfig(
            flows_file=temp_path,
            output_base=Path('/tmp/test_output'),
            project_name='test'
        )
        
        planner = MigrationPlanner(config)
        
        # Should not raise exception - should return result
        result = planner.run()
        
        # Result should indicate failure
        assert hasattr(result, 'success'), "Result should have success attribute"
        assert not result.success, "Result should indicate failure"
        
        # Result should have error message
        assert hasattr(result, 'error_message'), "Result should have error_message attribute"
        assert result.error_message, "Result should have non-empty error message"
        
        # Result should have empty output files list
        assert hasattr(result, 'output_files'), "Result should have output_files attribute"
        assert len(result.output_files) == 0, "Failed result should have no output files"
        
    finally:
        temp_path.unlink()
