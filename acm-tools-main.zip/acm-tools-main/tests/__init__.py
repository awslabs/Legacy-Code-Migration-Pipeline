"""Test suite for SMF Record Parser."""
