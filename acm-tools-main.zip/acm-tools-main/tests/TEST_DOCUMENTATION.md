# Test Documentation

## Overview

This document provides comprehensive documentation for the SMF Toolkit test suite. It covers test organization, execution procedures, fixtures, and coverage reporting.

## Table of Contents

1. [Test Organization](#test-organization)
2. [Test Execution](#test-execution)
3. [Test Fixtures and Setup](#test-fixtures-and-setup)
4. [Test Data Requirements](#test-data-requirements)
5. [Test Coverage](#test-coverage)

---

## Test Organization

### Directory Structure

```
tests/
├── __init__.py                    # Test package initialization
├── TEST_DOCUMENTATION.md          # This file
├── INTEGRATION_TEST_SUMMARY.md   # Integration test summary
├── integration/                   # Integration tests
│   ├── __init__.py
│   ├── test_cics_metadata_workflow.py
│   └── TEST_RESULTS.md
└── unit/                          # Unit tests
    ├── test_legacy_analyzer/      # Legacy analyzer tests
    ├── test_shared/               # Shared infrastructure tests
    └── test_smf_analyzer/         # SMF analyzer tests
```

### Test Categories

The test suite is organized into the following categories:

#### 1. Unit Tests (`tests/unit/`)

Unit tests verify individual components in isolation. They are further organized by module:

##### Legacy Analyzer Tests (`test_legacy_analyzer/`)

Tests for mainframe code analysis functionality:

- **Parser Tests**: Language-specific parsers (COBOL, PL/I, JCL, REXX, Natural, RPG, Assembler)
  - `test_cobol_parser.py` - COBOL dependency parser
  - `test_pli_parser.py` - PL/I dependency parser
  - `test_jcl_parser.py` - JCL parser
  - `test_rexx_parser.py` - REXX parser
  - `test_natural_parser.py` - Natural parser
  - `test_rpg_parser.py` - RPG parser
  - `test_asm_parser.py` - Assembler parser

- **Multi-Program Analysis**: Tests for files containing multiple programs
  - `test_cobol_multi_program_properties.py` - COBOL multi-program parsing
  - `test_pli_multi_program_properties.py` - PL/I multi-program parsing
  - `test_natural_multi_program_properties.py` - Natural multi-program parsing
  - `test_rpg_multi_program_properties.py` - RPG multi-program parsing
  - `test_asm_multi_program_properties.py` - Assembler multi-program parsing

- **Analysis Features**: Flow analysis, complexity, dependencies
  - `test_flow_analysis.py` - Flow analyzer unit tests
  - `test_flow_analysis_program_granularity_properties.py` - Program-level flow analysis
  - `test_complexity_analyzer.py` - Complexity metrics calculation
  - `test_dependency_loader_unit.py` - Dependency loading
  - `test_dependency_loader_properties.py` - Dependency loading properties
  - `test_dependency_referential_integrity_properties.py` - Referential integrity checks

- **Metadata and Inventory**: CICS, JCL, dataset management
  - `test_csd_parser.py` - CICS CSD parser
  - `test_metadata_scanner.py` - Metadata file scanner
  - `test_inventory_loader.py` - Inventory loading from CSV
  - `test_cics_models.py` - CICS data models
  - `test_cics_report.py` - CICS reporting

- **Program-Level Features**: Program-level dependency tracking
  - `test_program_level_integration.py` - Program-level integration
  - `test_program_level_dependency_storage_properties.py` - Dependency storage
  - `test_program_level_schema_structure_properties.py` - Schema structure
  - `test_program_level_entry_point_identification_properties.py` - Entry point detection

- **CLI Tests**: Command-line interface
  - `test_cli_integration.py` - CLI command integration tests
  - `test_legacy_analyzer_structure_properties.py` - Project structure validation

- **Utilities**: Supporting functionality
  - `test_cache_manager.py` - Cache management
  - `test_config_manager.py` - Configuration management
  - `test_parallel_processor.py` - Parallel processing

- **Integration**: End-to-end workflows
  - `test_comprehensive_integration.py` - Complete analysis workflows
  - `test_multi_language_analyzer.py` - Multi-language analysis

##### Shared Infrastructure Tests (`test_shared/`)

Tests for shared components used across modules:

- **Database and Schema**: Database adapters and schemas
  - `test_database_compatibility_properties.py` - Database compatibility
  - `test_dependencies_schema_structure.py` - Dependencies schema
  - `test_schema_properties.py` - Schema validation properties

- **Data Models**: Core data structures
  - `test_data_models.py` - Data model validation
  - `test_complexity_calculators.py` - Complexity calculation

- **Loaders**: Data loading functionality
  - `test_loader_unit.py` - Loader unit tests
  - `test_loader_properties.py` - Loader properties

- **System Properties**: Cross-cutting concerns
  - `test_import_correctness_properties.py` - Import validation
  - `test_shared_infrastructure_properties.py` - Infrastructure validation
  - `test_cli_preservation_properties.py` - CLI backward compatibility
  - `test_api_compatibility_properties.py` - API compatibility
  - `test_configuration_preservation_properties.py` - Configuration compatibility

- **Performance**: Performance benchmarks
  - `test_performance.py` - Performance tests for large-scale analysis

- **Error Handling**: Error conditions
  - `test_error_conditions.py` - Error handling validation
  - `test_exceptions.py` - Exception handling

- **Examples and Documentation**: Example scripts
  - `test_example_script_functionality_properties.py` - Example script validation
  - `test_test_system_functionality_properties.py` - Test system validation

- **Package Building**: Migration package creation
  - `test_package_build_correctness_properties.py` - Package builder validation

- **Analysis Features**: Specific analysis capabilities
  - `test_pli_include_analysis.py` - PL/I include file analysis
  - `test_factory.py` - Factory pattern implementations

##### SMF Analyzer Tests (`test_smf_analyzer/`)

Tests for SMF record parsing and analysis:

- **Parser Tests**: Record type parsers
  - `test_smf2_parser.py` - SMF Type 2 parser
  - `test_smf3_parser.py` - SMF Type 3 parser
  - `test_smf30_parser.py` - SMF Type 30 parser
  - `test_smf52_parser.py` - SMF Type 52 parser
  - `test_smf53_parser.py` - SMF Type 53 parser
  - `test_smf54_parser.py` - SMF Type 54 parser
  - `test_smf110_parser.py` - SMF Type 110 parser

- **Real Data Tests**: Tests with actual SMF data
  - `test_smf2_real_data.py` - SMF Type 2 real data
  - `test_smf3_real_data.py` - SMF Type 3 real data
  - `test_smf30_real_data.py` - SMF Type 30 real data

- **File Parsing**: Multi-record file handling
  - `test_smf_file_parser.py` - SMF file parser
  - `test_format_detection.py` - Format detection (VB, VBS, RDW)

- **Structure Validation**: Project organization
  - `test_smf_analyzer_structure_properties.py` - Structure validation

#### 2. Integration Tests (`tests/integration/`)

Integration tests verify that multiple components work together correctly:

- **Workflow Tests**: End-to-end workflows
  - `test_cics_metadata_workflow.py` - CICS metadata integration workflow

### Test Types

The test suite includes three types of tests:

#### Unit Tests

- Test individual functions, classes, or methods in isolation
- Use mocks and stubs for dependencies
- Fast execution (< 1 second per test)
- Example: Testing a single parser method

#### Property-Based Tests

- Test universal properties that should hold for all inputs
- Use Hypothesis library to generate random test data
- Run 100+ iterations per property
- Validate correctness across input space
- Example: "For any valid COBOL program, parsing then printing should produce equivalent AST"

Property-based tests are identified by:
- Filename suffix: `*_properties.py`
- Use of `@given` decorator from Hypothesis
- Test names starting with `test_property_`

#### Integration Tests

- Test multiple components working together
- Use real or realistic test data
- Slower execution (1-30 seconds per test)
- Validate end-to-end workflows
- Example: Complete analysis pipeline from source code to database

### Test Naming Conventions

- **Test files**: `test_<module_name>.py` or `test_<feature>_properties.py`
- **Test classes**: `Test<FeatureName>` (e.g., `TestCOBOLParser`)
- **Test methods**: `test_<what_is_being_tested>` (e.g., `test_parse_cobol_program`)
- **Property tests**: `test_property_<property_name>` (e.g., `test_property_round_trip`)
- **Fixtures**: Descriptive names (e.g., `temp_db`, `sample_cobol_code`)

### Test Organization Principles

1. **Separation by Module**: Tests are organized by the module they test
2. **Separation by Type**: Unit tests separate from integration tests
3. **Co-location**: Tests for a module are in a corresponding test directory
4. **Isolation**: Each test is independent and can run in any order
5. **Clarity**: Test names clearly describe what is being tested

---

## Test Execution

### Running All Tests

```bash
# Run entire test suite
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=legacy_analyzer --cov=smf_loader --cov=smf_record_parser --cov-report=html

# Run with parallel execution (faster)
pytest tests/ -n auto
```

### Running Specific Test Categories

#### By Directory

```bash
# Run all unit tests
pytest tests/unit/ -v

# Run all integration tests
pytest tests/integration/ -v

# Run legacy analyzer tests only
pytest tests/unit/test_legacy_analyzer/ -v

# Run SMF analyzer tests only
pytest tests/unit/test_smf_analyzer/ -v

# Run shared infrastructure tests only
pytest tests/unit/test_shared/ -v
```

#### By Test File

```bash
# Run specific test file
pytest tests/unit/test_legacy_analyzer/test_cobol_parser.py -v

# Run multiple specific files
pytest tests/unit/test_legacy_analyzer/test_cobol_parser.py \
       tests/unit/test_legacy_analyzer/test_pli_parser.py -v
```

#### By Test Class

```bash
# Run specific test class
pytest tests/unit/test_legacy_analyzer/test_cli_integration.py::TestLoadCommands -v

# Run multiple test classes
pytest tests/unit/test_legacy_analyzer/test_cli_integration.py::TestLoadCommands \
       tests/unit/test_legacy_analyzer/test_cli_integration.py::TestMetadataCommands -v
```

#### By Test Method

```bash
# Run specific test method
pytest tests/unit/test_legacy_analyzer/test_cobol_parser.py::TestCOBOLParser::test_parse_simple_program -v

# Run tests matching pattern
pytest tests/unit/test_legacy_analyzer/ -k "cobol" -v
pytest tests/unit/ -k "property" -v
```

### Running Tests by Feature

#### Parser Tests

```bash
# All parser tests
pytest tests/unit/test_legacy_analyzer/test_*_parser.py -v

# Specific language parser
pytest tests/unit/test_legacy_analyzer/test_cobol_parser.py -v
```

#### Multi-Program Tests

```bash
# All multi-program tests
pytest tests/unit/test_legacy_analyzer/test_*_multi_program_properties.py -v
```

#### Property-Based Tests

```bash
# All property-based tests
pytest tests/unit/ -k "properties" -v

# Specific property test file
pytest tests/unit/test_legacy_analyzer/test_cobol_multi_program_properties.py -v
```

#### CLI Tests

```bash
# All CLI tests
pytest tests/unit/test_legacy_analyzer/test_cli_integration.py -v

# Specific CLI command group
pytest tests/unit/test_legacy_analyzer/test_cli_integration.py::TestLoadCommands -v
pytest tests/unit/test_legacy_analyzer/test_cli_integration.py::TestMetadataCommands -v
pytest tests/unit/test_legacy_analyzer/test_cli_integration.py::TestServiceCommands -v
pytest tests/unit/test_legacy_analyzer/test_cli_integration.py::TestFlowCommands -v
```

#### Performance Tests

```bash
# Run performance tests
pytest tests/unit/test_shared/test_performance.py -v

# Run with timing information
pytest tests/unit/test_shared/test_performance.py -v --durations=10
```

#### Integration Tests

```bash
# All integration tests
pytest tests/integration/ -v

# Specific workflow
pytest tests/integration/test_cics_metadata_workflow.py -v

# Comprehensive integration tests
pytest tests/unit/test_legacy_analyzer/test_comprehensive_integration.py -v
```

### Test Execution Options

#### Verbosity

```bash
# Minimal output
pytest tests/

# Verbose output (show test names)
pytest tests/ -v

# Very verbose output (show test details)
pytest tests/ -vv
```

#### Filtering

```bash
# Run only failed tests from last run
pytest tests/ --lf

# Run failed tests first, then others
pytest tests/ --ff

# Stop after first failure
pytest tests/ -x

# Stop after N failures
pytest tests/ --maxfail=3
```

#### Output Control

```bash
# Show print statements
pytest tests/ -s

# Show local variables on failure
pytest tests/ -l

# Capture output (default)
pytest tests/ --capture=yes

# Don't capture output
pytest tests/ --capture=no
```

#### Parallel Execution

```bash
# Run tests in parallel (requires pytest-xdist)
pytest tests/ -n auto

# Run with specific number of workers
pytest tests/ -n 4
```

#### Markers

```bash
# Run tests with specific marker
pytest tests/ -m "slow"
pytest tests/ -m "integration"

# Skip tests with specific marker
pytest tests/ -m "not slow"
```

### Test Execution Time Expectations

- **Unit tests**: < 1 second per test
- **Property-based tests**: 1-5 seconds per test (100+ iterations)
- **Integration tests**: 1-30 seconds per test
- **Full test suite**: < 5 minutes (with parallel execution)
- **Performance tests**: 10-60 seconds per test

### Continuous Integration

The test suite is designed to run in CI/CD pipelines:

```bash
# CI/CD command
pytest tests/ -v --cov=legacy_analyzer --cov=smf_loader --cov=smf_record_parser \
       --cov-report=xml --cov-report=term-missing --maxfail=5
```

---

## Test Fixtures and Setup

### Common Fixtures

The test suite uses pytest fixtures for test setup and teardown. Here are the most common fixtures:

#### Database Fixtures

```python
@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    db_path = "test_temp.db"
    conn = sqlite3.connect(db_path)
    # Setup schema
    yield conn
    conn.close()
    if os.path.exists(db_path):
        os.unlink(db_path)
```

**Usage**: Tests that need a temporary database
**Scope**: Function (default) - new database per test
**Cleanup**: Automatic - database deleted after test

#### Sample Code Fixtures

```python
@pytest.fixture
def sample_cobol_code():
    """Sample COBOL code for testing."""
    return """
           IDENTIFICATION DIVISION.
           PROGRAM-ID. TESTPROG.
           PROCEDURE DIVISION.
               CALL 'SUBPROG'.
               STOP RUN.
    """
```

**Usage**: Tests that need sample source code
**Scope**: Function - new code per test
**Cleanup**: None needed (string data)

#### File System Fixtures

```python
@pytest.fixture
def sample_source_dir(tmp_path):
    """Create sample source directory with files."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    # Create sample files
    yield source_dir
    # Cleanup handled by tmp_path
```

**Usage**: Tests that need file system operations
**Scope**: Function - new directory per test
**Cleanup**: Automatic via `tmp_path`

#### Parser Fixtures

```python
@pytest.fixture
def parser():
    """Create parser instance."""
    return COBOLDependencyParser()
```

**Usage**: Tests that need parser instances
**Scope**: Function - new parser per test
**Cleanup**: None needed

### Fixture Scopes

Fixtures can have different scopes:

- **function** (default): New fixture per test function
- **class**: New fixture per test class
- **module**: New fixture per test module
- **session**: One fixture for entire test session

Example:
```python
@pytest.fixture(scope="session")
def expensive_resource():
    """Create expensive resource once per session."""
    resource = create_expensive_resource()
    yield resource
    cleanup_resource(resource)
```

### Fixture Dependencies

Fixtures can depend on other fixtures:

```python
@pytest.fixture
def temp_db():
    """Create temporary database."""
    # ...

@pytest.fixture
def populated_db(temp_db):
    """Create database with test data."""
    # Use temp_db fixture
    # Add test data
    yield temp_db
```

### Parametrized Fixtures

Fixtures can be parametrized to run tests with multiple configurations:

```python
@pytest.fixture(params=["cobol", "pli", "natural"])
def language_parser(request):
    """Create parser for different languages."""
    if request.param == "cobol":
        return COBOLDependencyParser()
    elif request.param == "pli":
        return PLIDependencyParser()
    elif request.param == "natural":
        return NaturalDependencyParser()
```

### Built-in Fixtures

The test suite uses several pytest built-in fixtures:

- **tmp_path**: Temporary directory (pathlib.Path)
- **tmp_path_factory**: Create multiple temporary directories
- **monkeypatch**: Modify objects, dictionaries, environment variables
- **capsys**: Capture stdout/stderr
- **caplog**: Capture log messages

Example:
```python
def test_with_tmp_path(tmp_path):
    """Test using temporary directory."""
    test_file = tmp_path / "test.txt"
    test_file.write_text("test data")
    assert test_file.read_text() == "test data"
```

### Hypothesis Strategies

Property-based tests use Hypothesis strategies to generate test data:

```python
from hypothesis import given, strategies as st

@given(
    program_name=st.text(min_size=1, max_size=8, alphabet=st.characters(whitelist_categories=("Lu", "Nd"))),
    num_calls=st.integers(min_value=0, max_value=10)
)
def test_property_program_parsing(program_name, num_calls):
    """Test that program parsing works for any valid program."""
    # Test implementation
```

Common strategies:
- `st.text()`: Generate text strings
- `st.integers()`: Generate integers
- `st.lists()`: Generate lists
- `st.dictionaries()`: Generate dictionaries
- `st.one_of()`: Choose from multiple strategies
- `st.builds()`: Build complex objects

---

## Test Data Requirements

### Test Data Organization

Test data is organized in several locations:

```
tests/
├── unit/
│   └── test_legacy_analyzer/
│       └── fixtures/           # Test fixtures (if needed)
examples/
├── code/                       # Sample source code
│   ├── cobol/
│   ├── pli/
│   ├── natural/
│   └── ...
└── data/                       # Sample SMF data
    └── SMF30_1.Dat
```

### Sample Source Code

The test suite uses sample source code from `examples/code/`:

#### COBOL Samples
- **Location**: `examples/code/cobol/`
- **Purpose**: Test COBOL parser, multi-program detection, dependency extraction
- **Examples**: CARDDEMO application samples

#### PL/I Samples
- **Location**: `examples/code/pli/`
- **Purpose**: Test PL/I parser, include file analysis
- **Examples**: Sample PL/I programs with %INCLUDE statements

#### Natural Samples
- **Location**: `examples/code/natural/`
- **Purpose**: Test Natural parser, subprogram detection
- **Examples**: Travel system samples

#### Other Languages
- JCL, REXX, RPG, Assembler samples in respective directories

### Sample SMF Data

The test suite uses sample SMF data from `examples/data/`:

- **SMF30_1.Dat**: Sample SMF Type 30 records
- **Purpose**: Test SMF parsers with real data
- **Format**: Binary SMF format (VB, VBS, or RDW)

### Inline Test Data

Many tests use inline test data defined directly in the test:

```python
def test_parse_simple_cobol():
    """Test parsing simple COBOL program."""
    code = """
           IDENTIFICATION DIVISION.
           PROGRAM-ID. TESTPROG.
           PROCEDURE DIVISION.
               CALL 'SUBPROG'.
               STOP RUN.
    """
    parser = COBOLDependencyParser()
    result = parser.parse(code, "TESTPROG.cbl")
    assert len(result.dependencies) == 1
```

### Generated Test Data

Property-based tests generate test data automatically using Hypothesis:

```python
from hypothesis import given, strategies as st

@given(
    program_content=st.text(min_size=10, max_size=1000),
    file_name=st.text(min_size=1, max_size=50)
)
def test_property_parser_handles_any_input(program_content, file_name):
    """Test that parser handles any input without crashing."""
    parser = COBOLDependencyParser()
    # Should not raise exception
    result = parser.parse(program_content, file_name)
```

### Database Test Data

Tests that require database data typically:

1. Create temporary database
2. Populate with test data
3. Run tests
4. Clean up database

Example:
```python
def test_with_database(temp_db):
    """Test with database."""
    # Insert test data
    temp_db.execute("""
        INSERT INTO programs (name, language, file_path)
        VALUES ('TESTPROG', 'COBOL', '/path/to/test.cbl')
    """)
    temp_db.commit()
    
    # Run test
    result = query_programs(temp_db)
    assert len(result) == 1
```

### Test Data Best Practices

1. **Use Minimal Data**: Only include data necessary for the test
2. **Use Realistic Data**: Data should resemble real-world data
3. **Use Inline Data**: Prefer inline data over external files when possible
4. **Use Fixtures**: Reuse common test data via fixtures
5. **Clean Up**: Always clean up test data after tests
6. **Document Data**: Comment on what test data represents

### External Test Data

When external test data is required:

1. **Location**: Place in `examples/` directory
2. **Documentation**: Document what the data represents
3. **Size**: Keep files small (< 1 MB if possible)
4. **Format**: Use standard formats (CSV, JSON, text)
5. **Licensing**: Ensure data can be distributed

---

## Test Coverage

### Generating Coverage Reports

#### HTML Coverage Report

```bash
# Generate HTML coverage report
pytest tests/ --cov=legacy_analyzer --cov=smf_loader --cov=smf_record_parser \
       --cov-report=html

# Open report in browser
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

#### Terminal Coverage Report

```bash
# Show coverage in terminal
pytest tests/ --cov=legacy_analyzer --cov=smf_loader --cov=smf_record_parser \
       --cov-report=term

# Show missing lines
pytest tests/ --cov=legacy_analyzer --cov=smf_loader --cov=smf_record_parser \
       --cov-report=term-missing
```

#### XML Coverage Report (for CI/CD)

```bash
# Generate XML coverage report
pytest tests/ --cov=legacy_analyzer --cov=smf_loader --cov=smf_record_parser \
       --cov-report=xml
```

### Coverage by Module

```bash
# Coverage for specific module
pytest tests/unit/test_legacy_analyzer/ --cov=legacy_analyzer --cov-report=term-missing

# Coverage for multiple modules
pytest tests/ --cov=legacy_analyzer --cov=smf_loader --cov-report=term-missing
```

### Current Coverage Status

As of the latest test run:

- **Total Tests**: 1413
- **Passing**: 1413 (100%)
- **Failing**: 0
- **Errors**: 0
- **Skipped**: 28

**Module Coverage** (target: >80%):
- `legacy_analyzer`: ~85%
- `smf_loader`: ~80%
- `smf_record_parser`: ~75%
- `shared`: ~90%

### Coverage Goals

- **Overall Coverage**: > 80%
- **Critical Modules**: > 90%
- **New Code**: 100% (all new code must have tests)
- **Bug Fixes**: 100% (all bug fixes must have regression tests)

### Identifying Coverage Gaps

#### Using Coverage Report

1. Generate HTML coverage report
2. Open `htmlcov/index.html`
3. Click on module to see line-by-line coverage
4. Red lines = not covered
5. Green lines = covered

#### Using Terminal Report

```bash
# Show missing lines
pytest tests/ --cov=legacy_analyzer --cov-report=term-missing

# Example output:
# Name                                    Stmts   Miss  Cover   Missing
# ---------------------------------------------------------------------
# legacy_analyzer/parsers/cobol_parser.py   150     15    90%   45-50, 78-82
```

### Improving Coverage

To improve coverage:

1. **Identify Gaps**: Use coverage report to find untested code
2. **Write Tests**: Add tests for untested code paths
3. **Focus on Critical Code**: Prioritize high-risk areas
4. **Test Edge Cases**: Add tests for error conditions
5. **Review Regularly**: Check coverage after each change

### Coverage Best Practices

1. **Don't Chase 100%**: Focus on meaningful coverage, not just numbers
2. **Test Behavior**: Test what code does, not just that it runs
3. **Test Edge Cases**: Include error conditions and boundary cases
4. **Test Integration**: Include integration tests, not just unit tests
5. **Review Coverage**: Regularly review and improve coverage

### Coverage Exclusions

Some code may be excluded from coverage:

```python
# Exclude from coverage
def debug_function():  # pragma: no cover
    """Debug function not tested."""
    print("Debug info")
```

Common exclusions:
- Debug code
- Platform-specific code
- Deprecated code
- Code that requires external resources

---

## Appendix

### Quick Reference

#### Run All Tests
```bash
pytest tests/ -v
```

#### Run with Coverage
```bash
pytest tests/ --cov=legacy_analyzer --cov=smf_loader --cov=smf_record_parser --cov-report=html
```

#### Run Specific Category
```bash
pytest tests/unit/test_legacy_analyzer/ -v
pytest tests/integration/ -v
```

#### Run Property Tests
```bash
pytest tests/unit/ -k "properties" -v
```

#### Run Performance Tests
```bash
pytest tests/unit/test_shared/test_performance.py -v
```

### Common Issues

#### Issue: Tests Fail with Database Errors

**Solution**: Ensure database is properly cleaned up between tests
```python
@pytest.fixture
def temp_db():
    db_path = "test.db"
    conn = sqlite3.connect(db_path)
    yield conn
    conn.close()
    if os.path.exists(db_path):
        os.unlink(db_path)  # Important!
```

#### Issue: Property Tests Take Too Long

**Solution**: Reduce number of examples
```python
from hypothesis import given, settings

@settings(max_examples=50)  # Default is 100
@given(...)
def test_property(...):
    pass
```

#### Issue: Tests Pass Locally but Fail in CI

**Solution**: Check for:
- Platform-specific code
- Timing-dependent tests
- File path assumptions
- Environment variables

### Additional Resources

- [pytest Documentation](https://docs.pytest.org/)
- [Hypothesis Documentation](https://hypothesis.readthedocs.io/)
- [Coverage.py Documentation](https://coverage.readthedocs.io/)
- [Python Testing Best Practices](https://docs.python-guide.org/writing/tests/)

---

**Last Updated**: January 2026
**Version**: 1.0
**Maintainer**: SMF Toolkit Team
