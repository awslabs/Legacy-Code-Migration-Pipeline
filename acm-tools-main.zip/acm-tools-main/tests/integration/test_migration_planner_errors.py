"""Integration tests for error scenarios in migration workpackage planner."""

import json
import pytest
import tempfile
import shutil
from pathlib import Path
from tools.migration_planner.cli import main
from tools.migration_planner.planner import MigrationPlanner
from tools.migration_planner.models import PlannerConfig
from tools.migration_planner.phase import ValidationError


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    temp_path = Path(tempfile.mkdtemp())
    yield temp_path
    shutil.rmtree(temp_path)


class TestErrorScenarios:
    """Integration tests for error handling scenarios."""
    
    def test_invalid_json_format(self, temp_dir):
        """Test with invalid JSON format."""
        # Arrange
        flows_file = temp_dir / "invalid.json"
        with open(flows_file, 'w') as f:
            f.write("{ invalid json content }")
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "Validation error" in result.error_message or "error" in result.error_message.lower()
    
    def test_missing_flows_array(self, temp_dir):
        """Test with JSON missing 'flows' array."""
        # Arrange
        flows_file = temp_dir / "no_flows.json"
        with open(flows_file, 'w') as f:
            json.dump({"data": []}, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "flows" in result.error_message.lower()
    
    def test_missing_required_field_flow_id(self, temp_dir):
        """Test with flow missing required field 'flowId'."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "name": "Test Flow",
                    "scope": {
                        "programs": [{"name": "PROG001", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": [],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "missing_flowid.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "flowId" in result.error_message or "required" in result.error_message.lower()
    
    def test_missing_required_field_programs(self, temp_dir):
        """Test with flow missing required field 'scope.programs'."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW001",
                    "name": "Test Flow",
                    "scope": {},
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": [],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "missing_programs.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "programs" in result.error_message.lower() or "required" in result.error_message.lower()
    
    def test_missing_required_field_complexity(self, temp_dir):
        """Test with flow missing required field 'complexity'."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW001",
                    "name": "Test Flow",
                    "scope": {
                        "programs": [{"name": "PROG001", "isUtility": False}]
                    },
                    "dependencies": {
                        "requiredFlows": [],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "missing_complexity.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "complexity" in result.error_message.lower() or "required" in result.error_message.lower()
    
    def test_missing_required_field_dependencies(self, temp_dir):
        """Test with flow missing required field 'dependencies'."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW001",
                    "name": "Test Flow",
                    "scope": {
                        "programs": [{"name": "PROG001", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "missing_dependencies.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "dependencies" in result.error_message.lower() or "required" in result.error_message.lower()
    
    def test_circular_dependencies_simple(self, temp_dir):
        """Test with simple circular dependency (A -> B -> A)."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW_A",
                    "name": "Flow A",
                    "scope": {
                        "programs": [{"name": "PROG_A", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": ["FLOW_B"],
                        "dependentFlows": []
                    }
                },
                {
                    "flowId": "FLOW_B",
                    "name": "Flow B",
                    "scope": {
                        "programs": [{"name": "PROG_B", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": ["FLOW_A"],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "circular_simple.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "circular" in result.error_message.lower() or "cycle" in result.error_message.lower()
        # Should mention both flows in the cycle
        assert "FLOW_A" in result.error_message
        assert "FLOW_B" in result.error_message
    
    def test_circular_dependencies_complex(self, temp_dir):
        """Test with complex circular dependency (A -> B -> C -> A)."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW_A",
                    "name": "Flow A",
                    "scope": {
                        "programs": [{"name": "PROG_A", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": ["FLOW_B"],
                        "dependentFlows": []
                    }
                },
                {
                    "flowId": "FLOW_B",
                    "name": "Flow B",
                    "scope": {
                        "programs": [{"name": "PROG_B", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": ["FLOW_C"],
                        "dependentFlows": []
                    }
                },
                {
                    "flowId": "FLOW_C",
                    "name": "Flow C",
                    "scope": {
                        "programs": [{"name": "PROG_C", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": ["FLOW_A"],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "circular_complex.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "circular" in result.error_message.lower() or "cycle" in result.error_message.lower()
    
    def test_missing_flow_reference(self, temp_dir):
        """Test with dependency referencing non-existent flow."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW001",
                    "name": "Flow 1",
                    "scope": {
                        "programs": [{"name": "PROG001", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": ["FLOW_NONEXISTENT"],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "missing_reference.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "FLOW_NONEXISTENT" in result.error_message or "not found" in result.error_message.lower()
    
    def test_self_dependency(self, temp_dir):
        """Test with flow depending on itself."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW001",
                    "name": "Flow 1",
                    "scope": {
                        "programs": [{"name": "PROG001", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": ["FLOW001"],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "self_dependency.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is False
        assert "circular" in result.error_message.lower() or "cycle" in result.error_message.lower()
    
    def test_cli_missing_flows_file(self, temp_dir, monkeypatch, capsys):
        """Test CLI with non-existent flows file."""
        # Arrange
        nonexistent_file = temp_dir / "nonexistent.json"
        output_dir = temp_dir / "output"
        
        test_args = [
            'migration-planner',
            '--flows-file', str(nonexistent_file),
            '--output-base', str(output_dir)
        ]
        
        # Act
        with pytest.raises(SystemExit) as exc_info:
            from tools.migration_planner.cli import parse_arguments
            parse_arguments(test_args[1:])
        
        # Assert
        assert exc_info.value.code == 2  # argparse exits with 2 for errors
    
    def test_empty_flows_array(self, temp_dir):
        """Test with empty flows array."""
        # Arrange
        flows_data = {"flows": []}
        
        flows_file = temp_dir / "empty_flows.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert - Should succeed with empty data
        assert result.success is True
        assert result.planning_data.statistics.total_flows == 0
    
    def test_invalid_classifications_file(self, temp_dir):
        """Test with invalid classifications file format."""
        # Arrange
        flows_data = {
            "flows": [
                {
                    "flowId": "FLOW001",
                    "name": "Test Flow",
                    "scope": {
                        "programs": [{"name": "PROG001", "isUtility": False}]
                    },
                    "complexity": {
                        "totalPrograms": 1,
                        "compositeScore": 10.0
                    },
                    "dependencies": {
                        "requiredFlows": [],
                        "dependentFlows": []
                    }
                }
            ]
        }
        
        flows_file = temp_dir / "flows.json"
        with open(flows_file, 'w') as f:
            json.dump(flows_data, f)
        
        classifications_file = temp_dir / "invalid_classifications.json"
        with open(classifications_file, 'w') as f:
            f.write("{ invalid json }")
        
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=classifications_file,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert - Should succeed with warning (classifications are optional)
        # Invalid classifications file is treated as missing and continues with empty classifications
        assert result.success is True
        
        # Verify that common modules count is 0 (no classifications loaded)
        for flow_id, wp in result.planning_data.flow_priorities.items():
            # Check in the planning JSON output
            planning_json = output_dir / "Workpackage_Planning.json"
            with open(planning_json, 'r') as f:
                planning_data = json.load(f)
            
            flow_data = planning_data["flowPriorities"][flow_id]
            assert flow_data["priorityFactors"]["commonModules"] == 0
