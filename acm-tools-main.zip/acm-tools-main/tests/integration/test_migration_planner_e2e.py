"""End-to-end integration tests for migration workpackage planner."""

import json
import pytest
import tempfile
import shutil
from pathlib import Path
from tools.migration_planner.cli import main, parse_arguments
from tools.migration_planner.planner import MigrationPlanner
from tools.migration_planner.models import PlannerConfig


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    temp_path = Path(tempfile.mkdtemp())
    yield temp_path
    shutil.rmtree(temp_path)


@pytest.fixture
def sample_flows_data():
    """Sample business flows data for testing."""
    return {
        "flows": [
            {
                "flowId": "FLOW001",
                "name": "User Authentication Flow",
                "scope": {
                    "programs": [
                        {"name": "AUTH001", "isUtility": False},
                        {"name": "UTIL001", "isUtility": True}
                    ]
                },
                "complexity": {
                    "totalPrograms": 2,
                    "compositeScore": 15.5
                },
                "dataOperations": {
                    "databases": ["USERDB", "AUTHDB"]
                },
                "dependencies": {
                    "requiredFlows": [],
                    "dependentFlows": ["FLOW002"]
                }
            },
            {
                "flowId": "FLOW002",
                "name": "Payment Processing Flow",
                "scope": {
                    "programs": [
                        {"name": "PAY001", "isUtility": False},
                        {"name": "PAY002", "isUtility": False},
                        {"name": "UTIL001", "isUtility": True}
                    ]
                },
                "complexity": {
                    "totalPrograms": 3,
                    "compositeScore": 22.0
                },
                "dataOperations": {
                    "databases": ["PAYDB"]
                },
                "dependencies": {
                    "requiredFlows": ["FLOW001"],
                    "dependentFlows": []
                }
            },
            {
                "flowId": "FLOW003",
                "name": "Report Generation Flow",
                "scope": {
                    "programs": [
                        {"name": "RPT001", "isUtility": False}
                    ]
                },
                "complexity": {
                    "totalPrograms": 1,
                    "compositeScore": 5.0
                },
                "dataOperations": {
                    "databases": []
                },
                "dependencies": {
                    "requiredFlows": [],
                    "dependentFlows": []
                }
            }
        ]
    }


@pytest.fixture
def sample_classifications_data():
    """Sample module classifications data for testing."""
    return {
        "classifications": {
            "UTIL001": "COMMONLY_USED",
            "AUTH001": "BUSINESS_LOGIC",
            "PAY001": "BUSINESS_LOGIC",
            "PAY002": "BUSINESS_LOGIC",
            "RPT001": "REPORTING"
        }
    }


@pytest.fixture
def flows_file(temp_dir, sample_flows_data):
    """Create a temporary flows file."""
    flows_path = temp_dir / "Business_Flows.json"
    with open(flows_path, 'w') as f:
        json.dump(sample_flows_data, f, indent=2)
    return flows_path


@pytest.fixture
def classifications_file(temp_dir, sample_classifications_data):
    """Create a temporary classifications file."""
    classifications_path = temp_dir / "Module_Classifications.json"
    with open(classifications_path, 'w') as f:
        json.dump(sample_classifications_data, f, indent=2)
    return classifications_path


class TestEndToEndIntegration:
    """End-to-end integration tests for the complete pipeline."""
    
    def test_complete_pipeline_with_classifications(
        self, temp_dir, flows_file, classifications_file
    ):
        """Test complete pipeline with sample data and classifications file."""
        # Arrange
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=classifications_file,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert - Pipeline success
        assert result.success is True
        assert result.error_message == ""
        assert result.planning_data is not None
        
        # Assert - Output files created
        assert len(result.output_files) == 3
        planning_json = output_dir / "Workpackage_Planning.json"
        status_json = output_dir / "progress" / "Workpackage_Status.json"
        roadmap_md = output_dir / "reports" / "Workpackage_Definition_Roadmap.md"
        
        assert planning_json.exists()
        assert status_json.exists()
        assert roadmap_md.exists()
        
        # Assert - Planning JSON content
        with open(planning_json, 'r') as f:
            planning_data = json.load(f)
        
        assert "metadata" in planning_data
        assert planning_data["metadata"]["projectName"] == "test_project"
        assert planning_data["metadata"]["phase"] == "WORKPACKAGE_PLANNING"
        
        assert "flowPriorities" in planning_data
        assert len(planning_data["flowPriorities"]) == 3
        
        assert "phases" in planning_data
        assert len(planning_data["phases"]) >= 1
        
        assert "migrationSequence" in planning_data
        assert len(planning_data["migrationSequence"]) == 3
        
        assert "statistics" in planning_data
        assert planning_data["statistics"]["totalFlows"] == 3
        
        # Assert - Status JSON content
        with open(status_json, 'r') as f:
            status_data = json.load(f)
        
        assert "metadata" in status_data
        assert "status" in status_data
        assert "workpackages" in status_data
        assert status_data["status"] == "completed"
        assert len(status_data["workpackages"]) == 3
        
        for wp in status_data["workpackages"]:
            assert wp["status"] == "NOT_STARTED"
            assert wp["startDate"] is None
            assert wp["endDate"] is None
        
        # Assert - Roadmap markdown content
        with open(roadmap_md, 'r') as f:
            roadmap_content = f.read()
        
        assert "# Migration Workpackage Roadmap" in roadmap_content
        assert "**Status:** completed" in roadmap_content
        assert "## Executive Summary" in roadmap_content
        assert "## Phase Breakdown" in roadmap_content
        assert "## Migration Sequence" in roadmap_content
        assert "test_project" in roadmap_content
    
    def test_complete_pipeline_without_classifications(
        self, temp_dir, flows_file
    ):
        """Test complete pipeline without classifications file."""
        # Arrange
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert - Pipeline success
        assert result.success is True
        assert result.planning_data is not None
        
        # Assert - Output files created
        assert len(result.output_files) == 3
        planning_json = output_dir / "Workpackage_Planning.json"
        
        assert planning_json.exists()
        
        # Assert - Planning data has correct structure
        with open(planning_json, 'r') as f:
            planning_data = json.load(f)
        
        # Verify priority calculations work without classifications
        for flow_id, flow_data in planning_data["flowPriorities"].items():
            assert "priorityScore" in flow_data
            assert "priorityFactors" in flow_data
            # Common modules should be 0 without classifications
            assert flow_data["priorityFactors"]["commonModules"] == 0
    
    def test_priority_ordering(self, temp_dir, flows_file, classifications_file):
        """Test that flows are ordered correctly by priority."""
        # Arrange
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=classifications_file,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is True
        
        # Check workpackage ordering
        workpackages = list(result.planning_data.flow_priorities.values())
        workpackages_sorted = sorted(workpackages, key=lambda x: x.workpackage_id)
        
        # Workpackage IDs should be sequential starting from 1
        for i, wp in enumerate(workpackages_sorted, start=1):
            assert wp.workpackage_id == i
        
        # Priority scores should be in ascending order
        for i in range(len(workpackages_sorted) - 1):
            assert (
                workpackages_sorted[i].priority_score <=
                workpackages_sorted[i + 1].priority_score
            )
    
    def test_phase_assignment(self, temp_dir, flows_file):
        """Test that phases are assigned correctly based on dependencies."""
        # Arrange
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is True
        
        # FLOW001 and FLOW003 have no dependencies, should be in phase 1
        # FLOW002 depends on FLOW001, should be in phase 2
        flow_priorities = result.planning_data.flow_priorities
        phases = result.planning_data.phases
        
        # Build a map of workpackage_id to phase
        wp_to_phase = {}
        for phase in phases:
            for wp_id in phase.workpackages:
                wp_to_phase[wp_id] = phase.phase_id
        
        # Find phases for each flow
        flow001_wp_id = flow_priorities["FLOW001"].workpackage_id
        flow002_wp_id = flow_priorities["FLOW002"].workpackage_id
        flow003_wp_id = flow_priorities["FLOW003"].workpackage_id
        
        flow001_phase = wp_to_phase[flow001_wp_id]
        flow002_phase = wp_to_phase[flow002_wp_id]
        flow003_phase = wp_to_phase[flow003_wp_id]
        
        assert flow001_phase == 1
        assert flow003_phase == 1
        assert flow002_phase == 2
    
    def test_preexistent_modules(self, temp_dir, flows_file):
        """Test that pre-existent modules are identified correctly."""
        # Arrange
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is True
        
        # UTIL001 appears in FLOW001 and FLOW002
        # Whichever has higher priority (lower workpackage ID) should not have it as pre-existent
        # The other should have it as pre-existent
        flow_priorities = result.planning_data.flow_priorities
        
        flow001_wp = flow_priorities["FLOW001"]
        flow002_wp = flow_priorities["FLOW002"]
        
        # One of them should have UTIL001 as pre-existent
        if flow001_wp.workpackage_id < flow002_wp.workpackage_id:
            # FLOW001 has higher priority
            assert "UTIL001" not in flow001_wp.preexistent_modules
            assert "UTIL001" in flow002_wp.preexistent_modules
        else:
            # FLOW002 has higher priority
            assert "UTIL001" in flow001_wp.preexistent_modules
            assert "UTIL001" not in flow002_wp.preexistent_modules
    
    def test_statistics_calculation(self, temp_dir, flows_file):
        """Test that statistics are calculated correctly."""
        # Arrange
        output_dir = temp_dir / "output"
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is True
        
        stats = result.planning_data.statistics
        
        assert stats.total_flows == 3
        assert stats.total_phases >= 1
        assert stats.average_priority_score > 0
        assert len(stats.flows_per_phase) == stats.total_phases
        
        # Sum of flows per phase should equal total flows
        total_flows_in_phases = sum(stats.flows_per_phase.values())
        assert total_flows_in_phases == stats.total_flows
    
    def test_cli_integration(self, temp_dir, flows_file, classifications_file, monkeypatch):
        """Test CLI integration with the planner."""
        # Arrange
        output_dir = temp_dir / "output"
        
        # Mock sys.argv
        test_args = [
            'migration-planner',
            '--flows-file', str(flows_file),
            '--classifications-file', str(classifications_file),
            '--output-base', str(output_dir),
            '--project-name', 'cli_test',
            '--log-level', 'INFO'
        ]
        
        monkeypatch.setattr('sys.argv', test_args)
        
        # Act
        exit_code = main()
        
        # Assert
        assert exit_code == 0
        
        # Verify output files exist
        planning_json = output_dir / "Workpackage_Planning.json"
        status_json = output_dir / "progress" / "Workpackage_Status.json"
        roadmap_md = output_dir / "reports" / "Workpackage_Definition_Roadmap.md"
        
        assert planning_json.exists()
        assert status_json.exists()
        assert roadmap_md.exists()
    
    def test_output_directory_creation(self, temp_dir, flows_file):
        """Test that output directory is created if it doesn't exist."""
        # Arrange
        output_dir = temp_dir / "nested" / "output" / "dir"
        assert not output_dir.exists()
        
        config = PlannerConfig(
            flows_file=flows_file,
            output_base=output_dir,
            project_name="test_project",
            classifications_file=None,
            log_level="INFO"
        )
        
        # Act
        planner = MigrationPlanner(config)
        result = planner.run()
        
        # Assert
        assert result.success is True
        assert output_dir.exists()
        assert (output_dir / "Workpackage_Planning.json").exists()
