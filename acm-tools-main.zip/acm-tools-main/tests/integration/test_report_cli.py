"""
Integration tests for Legacy Analyzer report CLI command.

Tests the complete workflow of generating summary reports via CLI.
"""

import json
import pytest
import subprocess
import sys
from pathlib import Path
import tempfile
import shutil


def test_cli_help():
    """Test that report CLI help works."""
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer", "report", "--help"],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    assert "Report type" in result.stdout
    assert "summary" in result.stdout


def test_cli_summary_help():
    """Test that report summary help works."""
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer", "report", "summary", "--help"],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    assert "report summary" in result.stdout
    assert "--db" in result.stdout
    assert "--output" in result.stdout


def test_cli_missing_database():
    """Test that CLI reports error for missing database file."""
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer", 
         "report", "summary", "--db", "nonexistent.db"],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 1
    assert "Database not found" in result.stdout


def test_cli_report_summary_with_real_database(tmp_path):
    """Test report summary with real database."""
    # Use carddemo database
    db_path = Path("databases/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    
    output_file = tmp_path / "test_summary.md"
    
    # Run the report command
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer",
         "report", "summary",
         "--db", str(db_path),
         "--output", str(output_file)],
        capture_output=True,
        text=True
    )
    
    # Check exit code
    assert result.returncode == 0, f"Command failed: {result.stdout}\n{result.stderr}"
    
    # Check output messages
    assert "Generating summary report" in result.stdout
    assert "Summary report generated" in result.stdout
    
    # Check output file exists
    assert output_file.exists(), "Output file not created"
    
    # Validate Markdown content
    content = output_file.read_text()
    
    # Check for expected sections
    assert "# Analysis Summary Report" in content
    assert "## Inventory Statistics" in content
    assert "## Dependency Statistics" in content
    assert "## Programs" in content
    
    # Check for data presence (carddemo should have data)
    assert "Total Artifacts:" in content
    assert "Total Dependencies:" in content


def test_cli_report_summary_with_custom_output_path(tmp_path):
    """Test with custom output path."""
    db_path = Path("databases/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    
    # Create nested output directory
    custom_output = tmp_path / "custom" / "reports" / "summary.md"
    
    # Run the report command
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer",
         "report", "summary",
         "--db", str(db_path),
         "--output", str(custom_output)],
        capture_output=True,
        text=True
    )
    
    # Check exit code
    assert result.returncode == 0
    
    # Check output file exists in custom location
    assert custom_output.exists(), "Output file not created in custom location"
    
    # Verify parent directories were created
    assert custom_output.parent.exists()
    assert custom_output.parent.is_dir()


def test_cli_report_summary_with_default_output_path(tmp_path):
    """Test with default output path."""
    db_path = Path("databases/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    
    # Get absolute path before changing directory
    db_absolute = db_path.absolute()
    
    # Change to temp directory to test default path
    import os
    original_cwd = os.getcwd()
    
    try:
        os.chdir(tmp_path)
        
        # Run the report command without --output
        result = subprocess.run(
            [sys.executable, "-m", "tools.legacy_analyzer",
             "report", "summary",
             "--db", str(db_absolute)],
            capture_output=True,
            text=True
        )
        
        # Check exit code
        assert result.returncode == 0, f"Command failed: {result.stdout}\n{result.stderr}"
        
        # Check default output file exists
        default_output = tmp_path / "reports" / "analysis_summary.md"
        assert default_output.exists(), "Default output file not created"
        
        # Verify content
        content = default_output.read_text()
        assert "# Analysis Summary Report" in content
        
    finally:
        os.chdir(original_cwd)


def test_cli_directory_creation(tmp_path):
    """Test directory creation."""
    db_path = Path("databases/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    
    # Use non-existent nested directory
    output_file = tmp_path / "level1" / "level2" / "level3" / "summary.md"
    
    # Ensure directory doesn't exist
    assert not output_file.parent.exists()
    
    # Run the report command
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer",
         "report", "summary",
         "--db", str(db_path),
         "--output", str(output_file)],
        capture_output=True,
        text=True
    )
    
    # Check exit code
    assert result.returncode == 0
    
    # Check directory was created
    assert output_file.parent.exists()
    assert output_file.parent.is_dir()
    
    # Check file was created
    assert output_file.exists()


def test_cli_error_handling_invalid_database(tmp_path):
    """Test error handling for invalid database."""
    # Create an invalid database file (corrupted content)
    invalid_db = tmp_path / "invalid.db"
    invalid_db.write_text("This is not a valid SQLite database file")
    
    output_file = tmp_path / "output.md"
    
    # Run the report command
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer",
         "report", "summary",
         "--db", str(invalid_db),
         "--output", str(output_file)],
        capture_output=True,
        text=True
    )
    
    # Should fail with error
    assert result.returncode == 1
    assert "Error" in result.stdout or "Error" in result.stderr


def test_cli_error_handling_directory_as_database(tmp_path):
    """Test error handling when database path is a directory."""
    # Create a directory instead of a file
    db_dir = tmp_path / "not_a_file"
    db_dir.mkdir()
    
    output_file = tmp_path / "output.md"
    
    # Run the report command
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer",
         "report", "summary",
         "--db", str(db_dir),
         "--output", str(output_file)],
        capture_output=True,
        text=True
    )
    
    # Should fail with error
    assert result.returncode == 1
    assert "not a file" in result.stdout.lower() or "not a file" in result.stderr.lower()


def test_cli_no_subcommand():
    """Test that CLI reports error when no subcommand is provided."""
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer", "report"],
        capture_output=True,
        text=True
    )
    
    # Should fail or show help
    assert result.returncode != 0 or "summary" in result.stdout


def test_cli_output_format_validation(tmp_path):
    """Test that output is valid Markdown format."""
    db_path = Path("databases/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    
    output_file = tmp_path / "format_test.md"
    
    # Run the report command
    result = subprocess.run(
        [sys.executable, "-m", "tools.legacy_analyzer",
         "report", "summary",
         "--db", str(db_path),
         "--output", str(output_file)],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    
    # Read and validate Markdown structure
    content = output_file.read_text()
    
    # Check for proper Markdown headers
    assert content.startswith("# ")
    assert "## " in content
    
    # Check for tables (should have pipe characters)
    assert "|" in content
    
    # Check for proper line endings
    lines = content.split("\n")
    assert len(lines) > 10  # Should have multiple lines
    
    # Check that it's not empty
    assert len(content.strip()) > 100


def test_cli_multiple_databases(tmp_path):
    """Test with multiple different databases."""
    databases = [
        "databases/carddemo.db",
        "databases/carddemo_filled.db",
    ]
    
    for db_name in databases:
        db_path = Path(db_name)
        if not db_path.exists():
            continue
        
        output_file = tmp_path / f"{db_path.stem}_summary.md"
        
        # Run the report command
        result = subprocess.run(
            [sys.executable, "-m", "tools.legacy_analyzer",
             "report", "summary",
             "--db", str(db_path),
             "--output", str(output_file)],
            capture_output=True,
            text=True
        )
        
        # Should succeed
        assert result.returncode == 0, f"Failed for {db_name}: {result.stdout}"
        assert output_file.exists()
        
        # Verify content
        content = output_file.read_text()
        assert "# Analysis Summary Report" in content
