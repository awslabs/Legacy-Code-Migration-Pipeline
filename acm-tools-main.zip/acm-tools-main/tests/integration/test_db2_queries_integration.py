"""Integration tests for DB2 migration queries.

This test module creates a test database with synthetic SMF Type 100, 101, and 102
data and verifies that all DB2 queries execute correctly and produce expected results.

Requirements tested: 14.1-14.7
"""

import pytest
import sqlite3
import os
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

from tools.smf_analyzer.smf_queries import (
    QueryEngine, 
    FileConfigurationManager,
    DB2_INFRASTRUCTURE_QUERIES,
    DB2_COST_QUERIES,
    DB2_MIGRATION_QUERIES
)
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter


class TestDB2QueriesIntegration:
    """Integration tests for DB2 migration queries."""
    
    @pytest.fixture
    def test_db(self):
        """Create a temporary test database with synthetic DB2 data."""
        # Create temporary database
        db_fd, db_path = tempfile.mkstemp(suffix='.db')
        os.close(db_fd)
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create schema
        self._create_schema(cursor)
        
        # Insert test data
        self._insert_test_data(cursor)
        
        conn.commit()
        conn.close()
        
        yield db_path
        
        # Cleanup
        try:
            os.unlink(db_path)
        except:
            pass
    
    def _create_schema(self, cursor):
        """Create database schema for SMF Types 100, 101, 102."""
        
        # smf_records table (unified)
        cursor.execute("""
            CREATE TABLE smf_records (
                record_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_type INTEGER NOT NULL,
                system_id TEXT,
                subsystem_id TEXT,
                job_name TEXT,
                timestamp TEXT,
                record_date TEXT,
                record_time TEXT,
                db2_version TEXT
            )
        """)
        
        # SMF Type 100 tables
        cursor.execute("""
            CREATE TABLE smf100_statistics (
                stat_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                product_section_offset INTEGER,
                product_section_length INTEGER,
                product_section_count INTEGER,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE smf100_sql_statistics (
                sql_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                select_count INTEGER DEFAULT 0,
                insert_count INTEGER DEFAULT 0,
                update_count INTEGER DEFAULT 0,
                delete_count INTEGER DEFAULT 0,
                describe_count INTEGER DEFAULT 0,
                prepare_count INTEGER DEFAULT 0,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE smf100_buffer_pool (
                buffer_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                buffer_pool_id TEXT,
                getpage_requests INTEGER DEFAULT 0,
                sync_read_io INTEGER DEFAULT 0,
                sync_write_io INTEGER DEFAULT 0,
                sequential_prefetch INTEGER DEFAULT 0,
                list_prefetch INTEGER DEFAULT 0,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE smf100_latch_statistics (
                latch_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                latch_type TEXT,
                latch_requests INTEGER DEFAULT 0,
                latch_suspensions INTEGER DEFAULT 0,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE smf100_ddf_statistics (
                ddf_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                distributed_requests INTEGER DEFAULT 0,
                remote_requests INTEGER DEFAULT 0,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        # SMF Type 101 tables
        cursor.execute("""
            CREATE TABLE smf101_accounting (
                acct_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                begin_store_clock TEXT,
                end_store_clock TEXT,
                begin_cpu_time INTEGER,
                end_cpu_time INTEGER,
                accumulated_cpu_in_db2 INTEGER DEFAULT 0,
                accumulated_elapsed_in_db2 INTEGER DEFAULT 0,
                accumulated_wait_io INTEGER DEFAULT 0,
                accumulated_wait_lock INTEGER DEFAULT 0,
                commit_count INTEGER DEFAULT 0,
                abort_count INTEGER DEFAULT 0,
                db2_entry_exit_count INTEGER DEFAULT 0,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE smf101_sql_statistics (
                sql_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                select_count INTEGER DEFAULT 0,
                insert_count INTEGER DEFAULT 0,
                update_count INTEGER DEFAULT 0,
                delete_count INTEGER DEFAULT 0,
                describe_count INTEGER DEFAULT 0,
                prepare_count INTEGER DEFAULT 0,
                open_count INTEGER DEFAULT 0,
                close_count INTEGER DEFAULT 0,
                fetch_count INTEGER DEFAULT 0,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE smf101_buffer_manager (
                buffer_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                buffer_pool_id TEXT,
                getpage_requests INTEGER DEFAULT 0,
                sync_read_io INTEGER DEFAULT 0,
                seq_prefetch_requests INTEGER DEFAULT 0,
                list_prefetch_requests INTEGER DEFAULT 0,
                dynamic_prefetch_requests INTEGER DEFAULT 0,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE smf101_correlation (
                corr_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                authorization_id TEXT,
                correlation_id TEXT,
                connection_name TEXT,
                plan_name TEXT,
                connection_type TEXT,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
        
        # SMF Type 102 tables
        cursor.execute("""
            CREATE TABLE smf102_performance (
                perf_id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                product_section_offset INTEGER,
                product_section_length INTEGER,
                product_section_count INTEGER,
                data_sections_json TEXT,
                FOREIGN KEY (record_id) REFERENCES smf_records(record_id)
            )
        """)
    
    def _insert_test_data(self, cursor):
        """Insert synthetic test data for DB2 queries."""
        
        # Base timestamp
        base_time = datetime.now() - timedelta(days=1)
        
        # Insert test records for multiple plans
        plans = [
            ('PLAN001', 'USER01', 'high'),
            ('PLAN002', 'USER02', 'medium'),
            ('PLAN003', 'USER03', 'low'),
        ]
        
        for plan_name, auth_id, frequency in plans:
            # Determine record count based on frequency
            if frequency == 'high':
                count = 100
            elif frequency == 'medium':
                count = 50
            else:
                count = 20
            
            for i in range(count):
                # Calculate timestamp
                timestamp = base_time + timedelta(minutes=i * 10)
                timestamp_str = timestamp.strftime('%Y-%m-%d %H:%M:%S')
                date_str = timestamp.strftime('%Y-%m-%d')
                time_str = timestamp.strftime('%H:%M:%S')
                
                # Insert Type 100 record
                cursor.execute("""
                    INSERT INTO smf_records (record_type, system_id, subsystem_id, job_name, timestamp, record_date, record_time, db2_version)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (100, 'SYS1', 'DB2P', f'JOB{plan_name}', timestamp_str, date_str, time_str, 'V10'))
                
                record_id = cursor.lastrowid
                
                # Insert smf100_statistics
                cursor.execute("""
                    INSERT INTO smf100_statistics (record_id, product_section_offset, product_section_length, product_section_count)
                    VALUES (?, ?, ?, ?)
                """, (record_id, 100, 200, 1))
                
                # Insert smf100_sql_statistics
                select_count = 1000 + i * 10
                insert_count = 100 + i * 2
                update_count = 200 + i * 3
                delete_count = 50 + i
                prepare_count = 500 + i * 5
                
                cursor.execute("""
                    INSERT INTO smf100_sql_statistics (record_id, select_count, insert_count, update_count, delete_count, describe_count, prepare_count)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (record_id, select_count, insert_count, update_count, delete_count, 50, prepare_count))
                
                # Insert smf100_buffer_pool
                getpage_requests = 10000 + i * 100
                sync_read_io = 1000 + i * 10
                sync_write_io = 500 + i * 5
                sequential_prefetch = 300 + i * 3
                list_prefetch = 200 + i * 2
                
                cursor.execute("""
                    INSERT INTO smf100_buffer_pool (record_id, buffer_pool_id, getpage_requests, sync_read_io, sync_write_io, sequential_prefetch, list_prefetch)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (record_id, 'BP0', getpage_requests, sync_read_io, sync_write_io, sequential_prefetch, list_prefetch))
                
                # Insert smf100_latch_statistics
                latch_types = ['IRLM', 'BUFFER', 'LOG']
                for latch_type in latch_types:
                    latch_requests = 5000 + i * 50
                    latch_suspensions = 500 + i * 5
                    
                    cursor.execute("""
                        INSERT INTO smf100_latch_statistics (record_id, latch_type, latch_requests, latch_suspensions)
                        VALUES (?, ?, ?, ?)
                    """, (record_id, latch_type, latch_requests, latch_suspensions))
                
                # Insert smf100_ddf_statistics
                distributed_requests = 100 + i * 2
                remote_requests = 50 + i
                
                cursor.execute("""
                    INSERT INTO smf100_ddf_statistics (record_id, distributed_requests, remote_requests)
                    VALUES (?, ?, ?)
                """, (record_id, distributed_requests, remote_requests))
                
                # Insert Type 101 record
                cursor.execute("""
                    INSERT INTO smf_records (record_type, system_id, subsystem_id, job_name, timestamp, record_date, record_time, db2_version)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (101, 'SYS1', 'DB2P', f'JOB{plan_name}', timestamp_str, date_str, time_str, 'V10'))
                
                record_id_101 = cursor.lastrowid
                
                # Insert smf101_accounting
                accumulated_cpu_in_db2 = 1000000 + i * 10000  # microseconds
                accumulated_elapsed_in_db2 = 5000000 + i * 50000  # microseconds
                accumulated_wait_io = 500000 + i * 5000  # microseconds
                accumulated_wait_lock = 100000 + i * 1000  # microseconds
                commit_count = 100 + i
                abort_count = 5 + (i % 10)
                db2_entry_exit_count = 150 + i * 2
                
                cursor.execute("""
                    INSERT INTO smf101_accounting (record_id, accumulated_cpu_in_db2, accumulated_elapsed_in_db2, accumulated_wait_io, accumulated_wait_lock, commit_count, abort_count, db2_entry_exit_count)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (record_id_101, accumulated_cpu_in_db2, accumulated_elapsed_in_db2, accumulated_wait_io, accumulated_wait_lock, commit_count, abort_count, db2_entry_exit_count))
                
                # Insert smf101_sql_statistics
                cursor.execute("""
                    INSERT INTO smf101_sql_statistics (record_id, select_count, insert_count, update_count, delete_count, describe_count, prepare_count, open_count, close_count, fetch_count)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (record_id_101, select_count, insert_count, update_count, delete_count, 50, prepare_count, 200, 200, 5000))
                
                # Insert smf101_buffer_manager
                cursor.execute("""
                    INSERT INTO smf101_buffer_manager (record_id, buffer_pool_id, getpage_requests, sync_read_io, seq_prefetch_requests, list_prefetch_requests, dynamic_prefetch_requests)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (record_id_101, 'BP0', getpage_requests, sync_read_io, sequential_prefetch, list_prefetch, 100))
                
                # Insert smf101_correlation
                cursor.execute("""
                    INSERT INTO smf101_correlation (record_id, authorization_id, correlation_id, connection_name, plan_name, connection_type)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (record_id_101, auth_id, f'CORR{i:04d}', 'CONN01', plan_name, 'BATCH'))
                
                # Insert Type 102 record (minimal)
                cursor.execute("""
                    INSERT INTO smf_records (record_type, system_id, subsystem_id, job_name, timestamp, record_date, record_time, db2_version)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (102, 'SYS1', 'DB2P', f'JOB{plan_name}', timestamp_str, date_str, time_str, 'V10'))
                
                record_id_102 = cursor.lastrowid
                
                # Insert smf102_performance
                cursor.execute("""
                    INSERT INTO smf102_performance (record_id, product_section_offset, product_section_length, product_section_count, data_sections_json)
                    VALUES (?, ?, ?, ?, ?)
                """, (record_id_102, 100, 200, 1, '{}'))
    
    @pytest.fixture
    def query_engine(self, test_db):
        """Create QueryEngine with test database."""
        # Create database adapter
        db_adapter = SQLiteAdapter(test_db)
        db_adapter.connect()  # Connect to the database
        
        # Create configuration manager
        config_manager = FileConfigurationManager('config/query_config_defaults.yaml')
        
        # Create query engine
        engine = QueryEngine(db_adapter, config_manager)
        
        # Register DB2 queries
        engine.register_queries(DB2_INFRASTRUCTURE_QUERIES)
        engine.register_queries(DB2_COST_QUERIES)
        engine.register_queries(DB2_MIGRATION_QUERIES)
        
        yield engine
        
        # Cleanup
        db_adapter.close()
    
    def test_db2_infrastructure_queries(self, query_engine):
        """Test all DB2 infrastructure queries execute without errors."""
        
        infrastructure_queries = [
            'db2_workload_cpu',
            'db2_storage_requirements',
            'db2_iops_requirements',
            'db2_sql_workload',
            'db2_transaction_performance',
            'db2_ddf_analysis',
            'db2_latch_contention',
            'db2_buffer_pool_optimization',
        ]
        
        for query_name in infrastructure_queries:
            print(f"\nTesting query: {query_name}")
            
            # Execute query
            result = query_engine.execute(query_name)
            
            # Verify result structure
            assert result is not None, f"Query {query_name} returned None"
            assert hasattr(result, 'to_dict'), f"Query {query_name} result missing to_dict method"
            assert hasattr(result, 'to_csv'), f"Query {query_name} result missing to_csv method"
            assert hasattr(result, 'to_markdown'), f"Query {query_name} result missing to_markdown method"
            assert hasattr(result, 'to_json'), f"Query {query_name} result missing to_json method"
            
            # Test serialization
            result_dict = result.to_dict()
            assert isinstance(result_dict, dict), f"Query {query_name} to_dict() did not return dict"
            
            result_csv = result.to_csv()
            assert isinstance(result_csv, str), f"Query {query_name} to_csv() did not return string"
            
            result_markdown = result.to_markdown()
            assert isinstance(result_markdown, str), f"Query {query_name} to_markdown() did not return string"
            
            result_json = result.to_json()
            assert isinstance(result_json, str), f"Query {query_name} to_json() did not return string"
            
            print(f"  ✓ Query {query_name} executed successfully")
            print(f"  ✓ Result has {len(result_dict.get('rows', []))} rows")
    
    def test_db2_cost_queries(self, query_engine):
        """Test all DB2 cost queries execute without errors."""
        
        cost_queries = [
            'db2_mainframe_cost',
            'db2_rds_cost',
            'db2_migration_roi',
        ]
        
        for query_name in cost_queries:
            print(f"\nTesting query: {query_name}")
            
            # Execute query
            result = query_engine.execute(query_name)
            
            # Verify result structure
            assert result is not None, f"Query {query_name} returned None"
            
            # Test serialization
            result_dict = result.to_dict()
            assert isinstance(result_dict, dict), f"Query {query_name} to_dict() did not return dict"
            
            print(f"  ✓ Query {query_name} executed successfully")
            print(f"  ✓ Result has {len(result_dict.get('rows', []))} rows")
    
    def test_db2_migration_queries(self, query_engine):
        """Test all DB2 migration planning queries execute without errors."""
        
        migration_queries = [
            'db2_plan_prioritization',
            'db2_migration_complexity',
            'db2_migration_effort',
        ]
        
        for query_name in migration_queries:
            print(f"\nTesting query: {query_name}")
            
            # Execute query
            result = query_engine.execute(query_name)
            
            # Verify result structure
            assert result is not None, f"Query {query_name} returned None"
            
            # Test serialization
            result_dict = result.to_dict()
            assert isinstance(result_dict, dict), f"Query {query_name} to_dict() did not return dict"
            
            print(f"  ✓ Query {query_name} executed successfully")
            print(f"  ✓ Result has {len(result_dict.get('rows', []))} rows")
    
    def test_configuration_parameter_injection(self, query_engine):
        """Test that configuration parameters are correctly injected into queries."""
        
        # Get a query that uses configuration parameters
        query_name = 'db2_workload_cpu'
        
        # Execute with default parameters
        result1 = query_engine.execute(query_name)
        result1_dict = result1.to_dict()
        
        # Update configuration parameter
        query_engine.config_manager.set('DB2_CPU_CONVERSION_RATIO', 0.8)
        
        # Execute again with updated parameter
        result2 = query_engine.execute(query_name)
        result2_dict = result2.to_dict()
        
        # Results should be different (due to different conversion ratio)
        # Note: This is a basic check - actual values depend on query implementation
        assert result1_dict is not None
        assert result2_dict is not None
        
        print(f"  ✓ Configuration parameter injection working")
    
    def test_cross_query_consistency(self, query_engine):
        """Test consistency across related queries."""
        
        # Execute related queries
        cpu_result = query_engine.execute('db2_workload_cpu')
        storage_result = query_engine.execute('db2_storage_requirements')
        iops_result = query_engine.execute('db2_iops_requirements')
        
        # Verify all queries returned results
        assert cpu_result is not None
        assert storage_result is not None
        assert iops_result is not None
        
        cpu_dict = cpu_result.to_dict()
        storage_dict = storage_result.to_dict()
        iops_dict = iops_result.to_dict()
        
        # Verify results have data
        assert len(cpu_dict.get('rows', [])) > 0, "CPU query returned no rows"
        assert len(storage_dict.get('rows', [])) > 0, "Storage query returned no rows"
        assert len(iops_dict.get('rows', [])) > 0, "IOPS query returned no rows"
        
        print(f"  ✓ Cross-query consistency verified")
        print(f"  ✓ CPU query: {len(cpu_dict.get('rows', []))} rows")
        print(f"  ✓ Storage query: {len(storage_dict.get('rows', []))} rows")
        print(f"  ✓ IOPS query: {len(iops_dict.get('rows', []))} rows")


if __name__ == '__main__':
    pytest.main([__file__, '-v', '-s'])
