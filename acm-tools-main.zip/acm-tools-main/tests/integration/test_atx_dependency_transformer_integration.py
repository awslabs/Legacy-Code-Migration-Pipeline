"""
Integration tests for ATX Dependency Transformer.

Tests the complete transformation pipeline with CardDemo data,
verifying output schema conformance and key metrics.
"""

import json
import pytest
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Any

from tools.atx.dependency_transformer.orchestration.transformation_orchestrator import TransformationOrchestrator
from tools.atx.dependency_transformer.orchestration.configuration_manager import ConfigurationManager


@pytest.fixture
def project_root():
    """Get project root directory."""
    return Path(__file__).parent.parent.parent


@pytest.fixture
def atx_input_dir(project_root, tmp_path):
    """
    Create temporary directory with ATX input files.
    
    Copies files from examples/atx subdirectories into a single directory.
    """
    input_dir = tmp_path / "atx_input"
    input_dir.mkdir()
    
    # Copy dependencies.json
    deps_src = project_root / "examples" / "atx" / "dependency-analysis" / "dependencies.json"
    shutil.copy(deps_src, input_dir / "dependencies.json")
    
    # Copy assets.csv
    assets_src = project_root / "examples" / "atx" / "inventory" / "assets.csv"
    shutil.copy(assets_src, input_dir / "assets.csv")
    
    # Copy program_to_dsn.json
    prog_dsn_src = project_root / "examples" / "atx" / "data-analysis" / "program_to_dsn.json"
    shutil.copy(prog_dsn_src, input_dir / "program_to_dsn.json")
    
    return input_dir


@pytest.fixture
def output_dir(tmp_path):
    """Create temporary output directory."""
    output_dir = tmp_path / "atx_output"
    output_dir.mkdir()
    return output_dir


@pytest.fixture
def config():
    """Get default configuration."""
    config_manager = ConfigurationManager()
    return config_manager.get_default_config()


@pytest.fixture
def orchestrator(config):
    """Create transformation orchestrator."""
    return TransformationOrchestrator(config)


class TestATXTransformationPipeline:
    """Test complete ATX transformation pipeline."""
    
    def test_transform_all_success(self, orchestrator, atx_input_dir, output_dir):
        """Test that transform_all completes successfully."""
        report = orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        assert report.success, "Transformation should succeed"
        assert report.flows_generated > 0, "Should generate flows"
        assert report.jobs_generated > 0, "Should generate jobs"
        assert report.entry_points_generated > 0, "Should generate entry points"
        assert report.programs_processed > 0, "Should process programs"
        assert report.execution_time_seconds > 0, "Should track execution time"
    
    def test_output_files_created(self, orchestrator, atx_input_dir, output_dir):
        """Test that all expected output files are created."""
        orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        # Check flows files
        assert (output_dir / "flows" / "Business_Flows.json").exists()
        assert (output_dir / "flows" / "flows_by_name.json").exists()
        assert (output_dir / "flows" / "flows_by_complexity_asc.json").exists()
        assert (output_dir / "flows" / "flows_by_complexity_desc.json").exists()
        assert (output_dir / "flows" / "flows_by_independence.json").exists()
        
        # Check jobs files
        assert (output_dir / "jobs" / "jobs.json").exists()
        assert (output_dir / "jobs" / "jobs_by_name.json").exists()
        assert (output_dir / "jobs" / "jobs_by_type.json").exists()
        assert (output_dir / "jobs" / "jobs_by_complexity.json").exists()
        
        # Check entry points files
        assert (output_dir / "entry_points.json").exists()
        assert (output_dir / "exports" / "entry_points.csv").exists()
    
    def test_dry_run_mode(self, orchestrator, atx_input_dir, output_dir):
        """Test that dry-run mode doesn't write files."""
        report = orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir),
            dry_run=True
        )
        
        assert report.success, "Dry run should succeed"
        assert report.dry_run, "Report should indicate dry run"
        
        # No files should be written
        assert not (output_dir / "flows" / "Business_Flows.json").exists()
        assert not (output_dir / "jobs" / "jobs.json").exists()
        assert not (output_dir / "entry_points.json").exists()


class TestFlowOutputSchema:
    """Test flow output schema conformance."""
    
    @pytest.fixture
    def flows(self, orchestrator, atx_input_dir, output_dir):
        """Generate flows and return them."""
        orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        with open(output_dir / "flows" / "Business_Flows.json") as f:
            return json.load(f)
    
    def test_flows_is_list(self, flows):
        """Test that flows output is a list."""
        assert isinstance(flows, list), "Flows should be a list"
        assert len(flows) > 0, "Should have at least one flow"
    
    def test_flow_required_fields(self, flows):
        """Test that each flow has required fields."""
        required_fields = [
            'flowId', 'name', 'entryPoint', 'scope', 'interfaces',
            'dataOperations', 'complexity', 'dependencies'
        ]
        
        for flow in flows:
            for field in required_fields:
                assert field in flow, f"Flow should have '{field}' field"
    
    def test_flow_entry_point_structure(self, flows):
        """Test entry point structure."""
        for flow in flows:
            entry_point = flow['entryPoint']
            assert 'program' in entry_point
            assert 'types' in entry_point
            assert 'primaryType' in entry_point
            assert isinstance(entry_point['types'], list)
    
    def test_flow_scope_structure(self, flows):
        """Test scope structure."""
        for flow in flows:
            scope = flow['scope']
            assert 'programs' in scope
            assert 'copybooks' in scope
            assert 'datasets' in scope
            assert isinstance(scope['programs'], list)
            assert isinstance(scope['copybooks'], list)
            assert isinstance(scope['datasets'], list)
    
    def test_flow_complexity_structure(self, flows):
        """Test complexity structure."""
        for flow in flows:
            complexity = flow['complexity']
            assert 'totalPrograms' in complexity
            assert 'totalLines' in complexity
            assert 'cyclomaticComplexity' in complexity
            assert 'compositeScore' in complexity
            assert 'tier' in complexity
            
            # Validate types
            assert isinstance(complexity['totalPrograms'], int)
            assert isinstance(complexity['totalLines'], int)
            assert isinstance(complexity['cyclomaticComplexity'], int)
            assert isinstance(complexity['compositeScore'], (int, float))
            assert complexity['tier'] in ['LOW', 'MEDIUM', 'HIGH']
    
    def test_flow_dependencies_structure(self, flows):
        """Test dependencies structure."""
        for flow in flows:
            dependencies = flow['dependencies']
            assert 'requiredFlows' in dependencies
            assert 'dependentFlows' in dependencies
            assert isinstance(dependencies['requiredFlows'], list)
            assert isinstance(dependencies['dependentFlows'], list)


class TestJobOutputSchema:
    """Test job output schema conformance."""
    
    @pytest.fixture
    def jobs(self, orchestrator, atx_input_dir, output_dir):
        """Generate jobs and return them."""
        orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        with open(output_dir / "jobs" / "jobs.json") as f:
            return json.load(f)
    
    def test_jobs_is_list(self, jobs):
        """Test that jobs output is a list."""
        assert isinstance(jobs, list), "Jobs should be a list"
        assert len(jobs) > 0, "Should have at least one job"
    
    def test_job_required_fields(self, jobs):
        """Test that each job has required fields."""
        required_fields = [
            'jobName', 'jobType', 'hasCustomCode', 'linkedFlow',
            'steps', 'datasets', 'dependencies'
        ]
        
        for job in jobs:
            for field in required_fields:
                assert field in job, f"Job should have '{field}' field"
    
    def test_job_type_values(self, jobs):
        """Test that job types are valid."""
        valid_types = ['APPLICATION', 'INFRASTRUCTURE']
        
        for job in jobs:
            assert job['jobType'] in valid_types, \
                f"Job type should be one of {valid_types}"
    
    def test_job_steps_structure(self, jobs):
        """Test job steps structure."""
        for job in jobs:
            steps = job['steps']
            assert isinstance(steps, list)
            
            for step in steps:
                assert 'stepName' in step
                assert 'program' in step
                assert 'type' in step
                assert 'purpose' in step
                assert 'flowEntry' in step
                assert isinstance(step['flowEntry'], bool)
    
    def test_job_dependencies_structure(self, jobs):
        """Test job dependencies structure."""
        for job in jobs:
            dependencies = job['dependencies']
            assert 'mustRunAfter' in dependencies
            assert 'mustRunBefore' in dependencies
            assert isinstance(dependencies['mustRunAfter'], list)
            assert isinstance(dependencies['mustRunBefore'], list)


class TestEntryPointOutputSchema:
    """Test entry point output schema conformance."""
    
    @pytest.fixture
    def entry_points(self, orchestrator, atx_input_dir, output_dir):
        """Generate entry points and return them."""
        orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        with open(output_dir / "entry_points.json") as f:
            return json.load(f)
    
    def test_entry_points_is_list(self, entry_points):
        """Test that entry points output is a list."""
        assert isinstance(entry_points, list), "Entry points should be a list"
        assert len(entry_points) > 0, "Should have at least one entry point"
    
    def test_entry_point_required_fields(self, entry_points):
        """Test that each entry point has required fields."""
        required_fields = [
            'programName', 'entryType', 'confidence', 'source'
        ]
        
        for ep in entry_points:
            for field in required_fields:
                assert field in ep, f"Entry point should have '{field}' field"
    
    def test_entry_type_values(self, entry_points):
        """Test that entry types are valid."""
        valid_types = ['ONLINE', 'BATCH', 'INFERRED']
        
        for ep in entry_points:
            assert ep['entryType'] in valid_types, \
                f"Entry type should be one of {valid_types}"
    
    def test_confidence_values(self, entry_points):
        """Test that confidence values are valid."""
        valid_confidence = ['EXPLICIT', 'INFERRED']
        
        for ep in entry_points:
            assert ep['confidence'] in valid_confidence, \
                f"Confidence should be one of {valid_confidence}"
    
    def test_source_values(self, entry_points):
        """Test that source values are valid."""
        valid_sources = ['CSD', 'JCL', 'CODE_ANALYSIS']
        
        for ep in entry_points:
            assert ep['source'] in valid_sources, \
                f"Source should be one of {valid_sources}"
    
    def test_csv_export_exists(self, orchestrator, atx_input_dir, output_dir):
        """Test that CSV export is created."""
        orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        csv_file = output_dir / "exports" / "entry_points.csv"
        assert csv_file.exists(), "CSV export should be created"
        
        # Check CSV has content
        with open(csv_file) as f:
            lines = f.readlines()
            assert len(lines) > 1, "CSV should have header and data rows"


class TestKeyMetrics:
    """Test that key metrics match expected values."""
    
    @pytest.fixture
    def transformation_data(self, orchestrator, atx_input_dir, output_dir):
        """Generate all outputs and return them."""
        report = orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        with open(output_dir / "flows" / "Business_Flows.json") as f:
            flows = json.load(f)
        
        with open(output_dir / "jobs" / "jobs.json") as f:
            jobs = json.load(f)
        
        with open(output_dir / "entry_points.json") as f:
            entry_points = json.load(f)
        
        return {
            'report': report,
            'flows': flows,
            'jobs': jobs,
            'entry_points': entry_points
        }
    
    def test_program_count(self, transformation_data):
        """Test that program count is reasonable."""
        report = transformation_data['report']
        assert report.programs_processed >= 20, \
            "Should process at least 20 programs from CardDemo"
    
    def test_flow_count(self, transformation_data):
        """Test that flow count is reasonable."""
        flows = transformation_data['flows']
        assert len(flows) >= 30, \
            "Should generate at least 30 flows from CardDemo"
    
    def test_job_count(self, transformation_data):
        """Test that job count is reasonable."""
        jobs = transformation_data['jobs']
        assert len(jobs) >= 20, \
            "Should generate at least 20 jobs from CardDemo"
    
    def test_entry_point_count(self, transformation_data):
        """Test that entry point count is reasonable."""
        entry_points = transformation_data['entry_points']
        assert len(entry_points) >= 30, \
            "Should generate at least 30 entry points from CardDemo"
    
    def test_complexity_metrics_present(self, transformation_data):
        """Test that complexity metrics are calculated."""
        flows = transformation_data['flows']
        
        total_cc = sum(f['complexity']['cyclomaticComplexity'] for f in flows)
        total_loc = sum(f['complexity']['totalLines'] for f in flows)
        
        assert total_cc > 0, "Should have non-zero cyclomatic complexity"
        assert total_loc > 0, "Should have non-zero lines of code"
    
    def test_job_type_distribution(self, transformation_data):
        """Test that jobs are classified into types."""
        jobs = transformation_data['jobs']
        
        app_jobs = [j for j in jobs if j['jobType'] == 'APPLICATION']
        infra_jobs = [j for j in jobs if j['jobType'] == 'INFRASTRUCTURE']
        
        assert len(app_jobs) > 0, "Should have APPLICATION jobs"
        assert len(infra_jobs) > 0, "Should have INFRASTRUCTURE jobs"
    
    def test_entry_point_type_distribution(self, transformation_data):
        """Test that entry points have different types."""
        entry_points = transformation_data['entry_points']
        
        online_eps = [ep for ep in entry_points if ep['entryType'] == 'ONLINE']
        batch_eps = [ep for ep in entry_points if ep['entryType'] == 'BATCH']
        
        assert len(online_eps) > 0, "Should have ONLINE entry points"
        assert len(batch_eps) > 0, "Should have BATCH entry points"


class TestSortedOutputs:
    """Test that sorted output variants are correct."""
    
    @pytest.fixture
    def sorted_flows(self, orchestrator, atx_input_dir, output_dir):
        """Generate flows and return sorted variants."""
        orchestrator.transform_all(
            input_dir=str(atx_input_dir),
            output_dir=str(output_dir)
        )
        
        flows_dir = output_dir / "flows"
        
        with open(flows_dir / "flows_by_name.json") as f:
            by_name = json.load(f)
        
        with open(flows_dir / "flows_by_complexity_asc.json") as f:
            by_complexity_asc = json.load(f)
        
        with open(flows_dir / "flows_by_complexity_desc.json") as f:
            by_complexity_desc = json.load(f)
        
        return {
            'by_name': by_name,
            'by_complexity_asc': by_complexity_asc,
            'by_complexity_desc': by_complexity_desc
        }
    
    def test_flows_sorted_by_name(self, sorted_flows):
        """Test that flows are sorted by name."""
        flows = sorted_flows['by_name']
        names = [f['name'] for f in flows]
        assert names == sorted(names), "Flows should be sorted by name"
    
    def test_flows_sorted_by_complexity_asc(self, sorted_flows):
        """Test that flows are sorted by complexity ascending."""
        flows = sorted_flows['by_complexity_asc']
        scores = [f['complexity']['compositeScore'] for f in flows]
        assert scores == sorted(scores), \
            "Flows should be sorted by complexity ascending"
    
    def test_flows_sorted_by_complexity_desc(self, sorted_flows):
        """Test that flows are sorted by complexity descending."""
        flows = sorted_flows['by_complexity_desc']
        scores = [f['complexity']['compositeScore'] for f in flows]
        assert scores == sorted(scores, reverse=True), \
            "Flows should be sorted by complexity descending"


class TestErrorHandling:
    """Test error handling and validation."""
    
    def test_missing_dependencies_file(self, orchestrator, tmp_path):
        """Test handling of missing dependencies.json."""
        input_dir = tmp_path / "incomplete_input"
        input_dir.mkdir()
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        
        report = orchestrator.transform_all(
            input_dir=str(input_dir),
            output_dir=str(output_dir)
        )
        
        assert not report.success, "Should fail with missing files"
        assert len(report.errors) > 0, "Should have error messages"
    
    def test_invalid_json_handling(self, orchestrator, tmp_path):
        """Test handling of invalid JSON."""
        input_dir = tmp_path / "invalid_input"
        input_dir.mkdir()
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        
        # Create invalid JSON file
        with open(input_dir / "dependencies.json", 'w') as f:
            f.write("{ invalid json }")
        
        report = orchestrator.transform_all(
            input_dir=str(input_dir),
            output_dir=str(output_dir)
        )
        
        assert not report.success, "Should fail with invalid JSON"
        assert len(report.errors) > 0, "Should have error messages"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
