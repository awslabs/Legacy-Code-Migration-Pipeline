"""
Integration tests for CICS Metadata Workflow.

Tests complete end-to-end workflows:
- CSD file discovery and parsing
- CSV conversion and loading
- Enhanced entry point detection with CICS metadata
- Backward compatibility with code-only analysis
- Error handling and fallback scenarios
"""

import pytest
import tempfile
import os
import csv
import sqlite3
from pathlib import Path

from tools.legacy_analyzer.parsers.csd_parser import CSDParser
from tools.legacy_analyzer.metadata.scanner import MetadataFileScanner
from tools.legacy_analyzer.inventory.inventory_loader import InventoryLoader
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter


@pytest.fixture
def temp_db():
    """Create temporary database."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    yield db_path
    
    if os.path.exists(db_path):
        os.unlink(db_path)


@pytest.fixture
def sample_csd_content():
    """Sample CSD file content for testing."""
    return """DEFINE TRANSACTION(CAUP) GROUP(CARDDEMO)
  PROGRAM(COACTUPC)
  STATUS(ENABLED)
  DESCRIPTION(Account Update Transaction)

DEFINE TRANSACTION(CACT) GROUP(CARDDEMO)
  PROGRAM(COACTUP)
  STATUS(ENABLED)
  DESCRIPTION(Account List Transaction)

DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO)
  LANGUAGE(COBOL)
  STATUS(ENABLED)
  DESCRIPTION(Account Update Program)

DEFINE PROGRAM(COACTUP) GROUP(CARDDEMO)
  LANGUAGE(COBOL)
  STATUS(ENABLED)
  DESCRIPTION(Account List Program)

DEFINE FILE(ACCTDAT) GROUP(CARDDEMO)
  DSNAME(AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS)
  STATUS(ENABLED)
  DESCRIPTION(Account Data File)

DEFINE MAPSET(COACTUP) GROUP(CARDDEMO)
  STATUS(ENABLED)
  DESCRIPTION(Account Update Map)
"""


@pytest.fixture
def sample_source_dir(tmp_path, sample_csd_content):
    """Create sample source directory with CSD file."""
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    
    # Create CSD directory
    csd_dir = source_dir / "app" / "csd"
    csd_dir.mkdir(parents=True)
    
    # Write CSD file
    csd_file = csd_dir / "CARDDEMO.csd"
    csd_file.write_text(sample_csd_content)
    
    # Create COBOL directory with sample programs
    cobol_dir = source_dir / "app" / "cbl"
    cobol_dir.mkdir(parents=True)
    
    # Write sample COBOL programs
    coactupc = cobol_dir / "COACTUPC.cbl"
    coactupc.write_text("""
       IDENTIFICATION DIVISION.
       PROGRAM-ID. COACTUPC.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-ACCOUNT PIC X(10).
       
       PROCEDURE DIVISION.
           EXEC CICS RECEIVE MAP('COACTUP') END-EXEC.
           CALL 'CBACT01C'.
           EXEC CICS SEND MAP('COACTUP') END-EXEC.
           EXEC CICS RETURN END-EXEC.
""")
    
    coactup = cobol_dir / "COACTUP.cbl"
    coactup.write_text("""
       IDENTIFICATION DIVISION.
       PROGRAM-ID. COACTUP.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-ACCOUNT PIC X(10).
       
       PROCEDURE DIVISION.
           EXEC CICS RECEIVE MAP('COACTUP') END-EXEC.
           CALL 'CBACT02C'.
           EXEC CICS RETURN END-EXEC.
""")
    
    return source_dir


class TestCSDParsingWorkflow:
    """Test CSD file parsing workflow."""
    
    def test_parse_csd_to_csv(self, tmp_path, sample_csd_content):
        """Test parsing CSD file and converting to CSV."""
        # Create CSD file
        csd_file = tmp_path / "test.csd"
        csd_file.write_text(sample_csd_content)
        
        # Parse CSD file
        parser = CSDParser()
        csd_data = parser.parse_file(str(csd_file))
        
        # Verify parsed data
        assert len(csd_data.transactions) == 2
        assert len(csd_data.programs) == 2
        assert len(csd_data.files) == 1
        assert len(csd_data.mapsets) == 1
        
        # Verify transaction data
        trans = csd_data.transactions[0]
        assert trans.resource_name == 'CAUP'
        assert trans.program_name == 'COACTUPC'
        assert trans.description == 'Account Update Transaction'
        
        # Verify program data
        prog = csd_data.programs[0]
        assert prog.resource_name == 'COACTUPC'
        assert prog.language == 'COBOL'
        
        # Verify file data
        file = csd_data.files[0]
        assert file.resource_name == 'ACCTDAT'
        assert file.dataset_name == 'AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS'
    
    def test_parse_csd_with_carddemo_sample(self):
        """Test parsing actual CARDDEMO.csd sample file."""
        carddemo_csd = Path('examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd')
        
        if not carddemo_csd.exists():
            pytest.skip("CARDDEMO.csd sample file not found")
        
        # Parse the actual CARDDEMO.csd file
        parser = CSDParser()
        csd_data = parser.parse_file(str(carddemo_csd))
        
        # Verify we got data
        assert len(csd_data.transactions) > 0
        assert len(csd_data.programs) > 0
        
        # Verify specific known transactions (use resource_name, not transaction_id)
        trans_names = [t.resource_name for t in csd_data.transactions]
        assert 'CAUP' in trans_names or 'CACT' in trans_names


class TestMetadataDiscoveryWorkflow:
    """Test metadata file discovery workflow."""
    
    def test_scan_directory_for_csd_files(self, sample_source_dir):
        """Test scanning directory for CSD files."""
        scanner = MetadataFileScanner()
        metadata_files = scanner.scan_directory(str(sample_source_dir))
        
        # Verify CSD files were found (csd_files is a list of strings, not Path objects)
        assert len(metadata_files.csd_files) == 1
        assert 'CARDDEMO.csd' in metadata_files.csd_files[0]
    
    def test_scan_directory_recursive(self, sample_source_dir):
        """Test recursive directory scanning."""
        scanner = MetadataFileScanner()
        metadata_files = scanner.scan_directory(str(sample_source_dir), recursive=True)
        
        # Should find CSD file in subdirectory
        assert len(metadata_files.csd_files) >= 1
    
    def test_scan_directory_with_csv_files(self, tmp_path):
        """Test scanning for CSV files."""
        # Create directory with CSV file
        csv_file = tmp_path / "cics_inventory.csv"
        csv_file.write_text("resource_name,resource_type,group_name,status\n")
        
        scanner = MetadataFileScanner()
        metadata_files = scanner.scan_directory(str(tmp_path))
        
        # Verify CSV files were found
        assert len(metadata_files.csv_files) >= 1


class TestCSVLoadingWorkflow:
    """Test CSV loading workflow."""
    
    def test_load_enhanced_csv_to_database(self, temp_db, tmp_path):
        """Test loading enhanced CSV format to database."""
        # Create enhanced CSV file
        csv_content = """resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Account Update,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data,
COACTUP,MAPSET,CARDDEMO,ENABLED,,,Account Update Map,
"""
        csv_file = tmp_path / "cics_inventory.csv"
        csv_file.write_text(csv_content)
        
        # Load to database
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(csv_file))
        
        # Verify data was loaded
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics")
        count = cursor.fetchone()[0]
        assert count == 4
        
        # Verify enhanced columns
        cursor.execute("""
            SELECT resource_name, program_name, dataset_name, description, language 
            FROM inventory_cics 
            WHERE resource_name='CAUP'
        """)
        row = cursor.fetchone()
        assert row[0] == 'CAUP'
        assert row[1] == 'COACTUPC'
        assert row[3] == 'Account Update'
        
        conn.close()
    
    def test_load_old_csv_format_backward_compatibility(self, temp_db, tmp_path):
        """Test loading old CSV format (backward compatibility)."""
        # Create old format CSV (without enhanced columns)
        csv_content = """resource_name,resource_type,group_name,status,program_name
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC
COACTUPC,PROGRAM,CARDDEMO,ENABLED,
"""
        csv_file = tmp_path / "cics_old_format.csv"
        csv_file.write_text(csv_content)
        
        # Load to database
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(csv_file))
        
        # Verify data was loaded
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics")
        count = cursor.fetchone()[0]
        assert count == 2
        
        # Verify enhanced columns are NULL
        cursor.execute("""
            SELECT dataset_name, description, language 
            FROM inventory_cics 
            WHERE resource_name='CAUP'
        """)
        row = cursor.fetchone()
        assert row[0] is None  # dataset_name
        assert row[1] is None  # description
        assert row[2] is None  # language
        
        conn.close()


class TestCompleteEndToEndWorkflow:
    """Test complete end-to-end workflow."""
    
    def test_scan_parse_load_workflow(self, temp_db, sample_source_dir, tmp_path):
        """Test complete workflow: scan → parse → create CSV manually → load."""
        # Step 1: Scan for CSD files
        scanner = MetadataFileScanner()
        metadata_files = scanner.scan_directory(str(sample_source_dir), recursive=True)
        
        assert len(metadata_files.csd_files) > 0
        
        # Step 2: Parse CSD file
        csd_file = metadata_files.csd_files[0]
        parser = CSDParser()
        csd_data = parser.parse_file(str(csd_file))
        
        assert len(csd_data.transactions) > 0
        
        # Step 3: Manually create CSV from parsed data (since to_csv not implemented yet)
        csv_file = tmp_path / "converted.csv"
        with open(csv_file, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'resource_name', 'resource_type', 'group_name', 'status',
                'program_name', 'dataset_name', 'description', 'language'
            ])
            writer.writeheader()
            
            # Write transactions
            for trans in csd_data.transactions:
                writer.writerow({
                    'resource_name': trans.resource_name,
                    'resource_type': 'TRANSACTION',
                    'group_name': trans.group_name,
                    'status': trans.status,
                    'program_name': trans.program_name or '',
                    'dataset_name': '',
                    'description': trans.description or '',
                    'language': ''
                })
            
            # Write programs
            for prog in csd_data.programs:
                writer.writerow({
                    'resource_name': prog.resource_name,
                    'resource_type': 'PROGRAM',
                    'group_name': prog.group_name,
                    'status': prog.status,
                    'program_name': '',
                    'dataset_name': '',
                    'description': prog.description or '',
                    'language': prog.language or ''
                })
        
        assert csv_file.exists()
        
        # Step 4: Load to database
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(csv_file))
        
        # Step 5: Verify data in database
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION'")
        trans_count = cursor.fetchone()[0]
        assert trans_count > 0
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_type='PROGRAM'")
        prog_count = cursor.fetchone()[0]
        assert prog_count > 0
        
        conn.close()
    
    def test_workflow_with_carddemo_sample(self, temp_db, tmp_path):
        """Test workflow with actual CARDDEMO sample data."""
        carddemo_csd = Path('examples/code/cobol/carddemoV2/app/csd/CARDDEMO.csd')
        
        if not carddemo_csd.exists():
            pytest.skip("CARDDEMO.csd sample file not found")
        
        # Parse CSD file
        parser = CSDParser()
        csd_data = parser.parse_file(str(carddemo_csd))
        
        # Manually create CSV from parsed data
        csv_file = tmp_path / "carddemo.csv"
        with open(csv_file, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'resource_name', 'resource_type', 'group_name', 'status',
                'program_name', 'dataset_name', 'description', 'language'
            ])
            writer.writeheader()
            
            # Write all resources
            for trans in csd_data.transactions:
                writer.writerow({
                    'resource_name': trans.resource_name,
                    'resource_type': 'TRANSACTION',
                    'group_name': trans.group_name,
                    'status': trans.status,
                    'program_name': trans.program_name or '',
                    'dataset_name': '',
                    'description': trans.description or '',
                    'language': ''
                })
            
            for prog in csd_data.programs:
                writer.writerow({
                    'resource_name': prog.resource_name,
                    'resource_type': 'PROGRAM',
                    'group_name': prog.group_name,
                    'status': prog.status,
                    'program_name': '',
                    'dataset_name': '',
                    'description': prog.description or '',
                    'language': prog.language or ''
                })
        
        # Load to database
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(csv_file))
        
        # Verify data
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Check for known CARDDEMO transactions
        cursor.execute("""
            SELECT resource_name, program_name 
            FROM inventory_cics 
            WHERE resource_type='TRANSACTION'
        """)
        transactions = cursor.fetchall()
        assert len(transactions) > 0
        
        conn.close()


class TestErrorHandlingAndFallback:
    """Test error handling and fallback scenarios."""
    
    def test_parse_malformed_csd_file(self, tmp_path):
        """Test parsing malformed CSD file."""
        # Create malformed CSD file
        malformed_csd = tmp_path / "malformed.csd"
        malformed_csd.write_text("""
This is not a valid CSD file
It has random text
DEFINE TRANSACTION(INCOMPLETE
No closing parenthesis or GROUP
""")
        
        parser = CSDParser()
        
        # Should not crash, may return partial data or empty
        try:
            csd_data = parser.parse_file(str(malformed_csd))
            # If it succeeds, verify it returns valid structure
            assert hasattr(csd_data, 'transactions')
            assert hasattr(csd_data, 'programs')
        except Exception as e:
            # If it fails, should be a controlled exception
            assert isinstance(e, (ValueError, IOError))
    
    def test_parse_empty_csd_file(self, tmp_path):
        """Test parsing empty CSD file."""
        empty_csd = tmp_path / "empty.csd"
        empty_csd.write_text("")
        
        parser = CSDParser()
        csd_data = parser.parse_file(str(empty_csd))
        
        # Should return empty data structures
        assert len(csd_data.transactions) == 0
        assert len(csd_data.programs) == 0
        assert len(csd_data.files) == 0
        assert len(csd_data.mapsets) == 0
    
    def test_load_csv_with_missing_columns(self, temp_db, tmp_path):
        """Test loading CSV with missing required columns."""
        # Create CSV with missing resource_type column
        invalid_csv = tmp_path / "invalid.csv"
        invalid_csv.write_text("""resource_name,group_name,status
CAUP,CARDDEMO,ENABLED
""")
        
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        
        # Should raise validation error
        with pytest.raises(Exception):
            loader.load_cics_inventory(str(invalid_csv))
    
    def test_scan_nonexistent_directory(self):
        """Test scanning nonexistent directory."""
        scanner = MetadataFileScanner()
        
        # Should raise error or return empty results
        with pytest.raises(Exception):
            scanner.scan_directory('/nonexistent/path')


class TestBackwardCompatibility:
    """Test backward compatibility scenarios."""
    
    def test_analysis_without_cics_metadata(self, temp_db):
        """Test that analysis works without CICS metadata (fallback to code analysis)."""
        # Create database without CICS metadata
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        
        # Verify inventory_cics table exists but is empty
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics")
        count = cursor.fetchone()[0]
        assert count == 0
        
        conn.close()
        
        # Analysis should still work (would use code-based entry point detection)
        # This is tested in other test files
    
    def test_mixed_metadata_sources(self, temp_db, tmp_path):
        """Test with both CICS metadata and code analysis."""
        # Load CICS metadata for some programs
        csv_content = """resource_name,resource_type,group_name,status,program_name
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC
COACTUPC,PROGRAM,CARDDEMO,ENABLED,
"""
        csv_file = tmp_path / "partial_cics.csv"
        csv_file.write_text(csv_content)
        
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(csv_file))
        
        # Verify partial CICS data was loaded
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics")
        count = cursor.fetchone()[0]
        assert count == 2
        
        conn.close()
        
        # Other programs would be detected via code analysis
        # (tested in other test files)


class TestLargeDatasets:
    """Test with large datasets."""
    
    def test_parse_large_csd_file(self, tmp_path):
        """Test parsing CSD file with many resources."""
        # Generate large CSD file
        large_csd = tmp_path / "large.csd"
        
        with open(large_csd, 'w') as f:
            for i in range(100):
                f.write(f"""DEFINE TRANSACTION(TST{i:03d}) GROUP(TESTGRP)
  PROGRAM(PROG{i:03d})
  STATUS(ENABLED)

DEFINE PROGRAM(PROG{i:03d}) GROUP(TESTGRP)
  LANGUAGE(COBOL)
  STATUS(ENABLED)

""")
        
        # Parse large file
        parser = CSDParser()
        csd_data = parser.parse_file(str(large_csd))
        
        # Verify all resources were parsed
        assert len(csd_data.transactions) == 100
        assert len(csd_data.programs) == 100
    
    def test_load_large_csv_file(self, temp_db, tmp_path):
        """Test loading large CSV file."""
        # Generate large CSV file
        large_csv = tmp_path / "large.csv"
        
        with open(large_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['resource_name', 'resource_type', 'group_name', 'status', 'program_name'])
            
            for i in range(1000):
                writer.writerow([f'TST{i:04d}', 'TRANSACTION', 'TESTGRP', 'ENABLED', f'PROG{i:04d}'])
                writer.writerow([f'PROG{i:04d}', 'PROGRAM', 'TESTGRP', 'ENABLED', ''])
        
        # Load large file
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(large_csv))
        
        # Verify all records were loaded
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics")
        count = cursor.fetchone()[0]
        assert count == 2000  # 1000 transactions + 1000 programs
        
        conn.close()


class TestDataQuality:
    """Test data quality and validation."""
    
    def test_duplicate_resource_handling(self, temp_db, tmp_path):
        """Test handling of duplicate resources."""
        # Create CSV with duplicate resources
        csv_content = """resource_name,resource_type,group_name,status,program_name
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC
CAUP,TRANSACTION,CARDDEMO,DISABLED,COACTUPC
"""
        csv_file = tmp_path / "duplicates.csv"
        csv_file.write_text(csv_content)
        
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(csv_file))
        
        # Verify handling - current implementation inserts both records
        # This is acceptable behavior (database allows duplicates)
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics WHERE resource_name='CAUP'")
        count = cursor.fetchone()[0]
        # Current implementation allows duplicates (2 records)
        assert count >= 1  # At least one record exists
        
        conn.close()
    
    def test_status_validation(self, temp_db, tmp_path):
        """Test status field validation."""
        # Create CSV with various status values
        csv_content = """resource_name,resource_type,group_name,status,program_name
TST1,TRANSACTION,TESTGRP,ENABLED,PROG1
TST2,TRANSACTION,TESTGRP,DISABLED,PROG2
TST3,TRANSACTION,TESTGRP,enabled,PROG3
"""
        csv_file = tmp_path / "status_test.csv"
        csv_file.write_text(csv_content)
        
        db_adapter = SQLiteAdapter(temp_db)
        db_adapter.connect()
        
        loader = InventoryLoader(db_adapter)
        loader.create_inventory_schema()
        loader.load_cics_inventory(str(csv_file))
        
        # Verify all records were loaded
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM inventory_cics")
        count = cursor.fetchone()[0]
        assert count == 3
        
        conn.close()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
