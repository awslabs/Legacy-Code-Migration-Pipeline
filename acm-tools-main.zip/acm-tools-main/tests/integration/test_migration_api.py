"""
Integration tests for Migration Flow Export API.

Tests the high-level Python API for building and exporting migration flows.
"""

import pytest
import sqlite3
import json
import tempfile
from pathlib import Path

from tools.legacy_analyzer.api import LegacyAnalyzerAPI


@pytest.fixture
def test_db():
    """Create a test database with sample data."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.db', delete=False) as f:
        db_path = f.name
    
    conn = sqlite3.Connection(db_path)
    cursor = conn.cursor()
    
    # Create artifact_dependencies table
    cursor.execute("""
        CREATE TABLE artifact_dependencies (
            source_artifact_name TEXT,
            source_artifact_type TEXT,
            target_artifact_name TEXT,
            target_artifact_type TEXT,
            dependency_type TEXT,
            source_file_path TEXT,
            line_number INTEGER
        )
    """)
    
    # Create inventory table
    cursor.execute("""
        CREATE TABLE inventory (
            artifact_name TEXT,
            artifact_type TEXT,
            file_path TEXT
        )
    """)
    
    # Create migration schema tables
    from tools.legacy_analyzer.migration.schema import create_migration_flow_schema
    create_migration_flow_schema(conn, verbose=False)
    
    # Insert sample data - Entry point program
    cursor.execute("""
        INSERT INTO inventory (artifact_name, artifact_type, file_path)
        VALUES ('PAYROLL1', 'PROGRAM', '/src/PAYROLL1.cbl')
    """)
    
    # Insert dependencies
    dependencies = [
        ('PAYROLL1', 'PROGRAM', 'PAYCALC', 'PROGRAM', 'PROGRAM_CALL', '/src/PAYROLL1.cbl', 100),
        ('PAYROLL1', 'PROGRAM', 'PAYCOM', 'COPYBOOK', 'COPYBOOK_INCLUDE', '/src/PAYROLL1.cbl', 10),
        ('PAYROLL1', 'PROGRAM', 'EMPLOYEE.MASTER', 'DATASET', 'DATASET_READ', '/src/PAYROLL1.cbl', 50),
        ('PAYCALC', 'PROGRAM', 'PAYDB', 'PROGRAM', 'PROGRAM_CALL', '/src/PAYCALC.cbl', 200),
        ('PAYDB', 'PROGRAM', 'EMPLOYEE_TABLE', 'TABLE', 'EXEC_SQL', '/src/PAYDB.cbl', 150),
    ]
    
    cursor.executemany("""
        INSERT INTO artifact_dependencies 
        (source_artifact_name, source_artifact_type, target_artifact_name, 
         target_artifact_type, dependency_type, source_file_path, line_number)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, dependencies)
    
    # Create inventory_jcl table for JCL entry points
    cursor.execute("""
        CREATE TABLE inventory_jcl (
            jcl_name TEXT,
            file_path TEXT
        )
    """)
    
    cursor.execute("""
        INSERT INTO inventory_jcl (jcl_name, file_path)
        VALUES ('PAYROLL01', '/jcl/PAYROLL01.jcl')
    """)
    
    # Add JCL dependency
    cursor.execute("""
        INSERT INTO artifact_dependencies 
        (source_artifact_name, source_artifact_type, target_artifact_name, 
         target_artifact_type, dependency_type, source_file_path, line_number)
        VALUES ('PAYROLL01', 'JCL', 'PAYROLL1', 'PROGRAM', 'JCL_EXEC', '/jcl/PAYROLL01.jcl', 10)
    """)
    
    conn.commit()
    conn.close()
    
    yield db_path
    
    # Cleanup
    Path(db_path).unlink(missing_ok=True)


@pytest.fixture
def temp_output_dir():
    """Create a temporary output directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


class TestMigrationFlowAPI:
    """Test suite for Migration Flow Export API."""
    
    def test_build_migration_flows_basic(self, test_db):
        """Test basic flow building."""
        api = LegacyAnalyzerAPI(test_db)
        
        try:
            # Build flows
            flow_ids = api.build_migration_flows()
            
            # Verify flows were built
            assert isinstance(flow_ids, list)
            assert len(flow_ids) > 0
            assert all(fid.startswith('FLOW_') for fid in flow_ids)
            
            # Verify database tables were created
            cursor = api.db.conn.cursor()
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='migration_flows'
            """)
            assert cursor.fetchone() is not None
            
        finally:
            api.close()
    
    def test_build_migration_flows_with_external_config(self, test_db, temp_output_dir):
        """Test flow building with external configuration."""
        # Create external config file
        config_path = Path(temp_output_dir) / "external_config.yaml"
        config_path.write_text("""
external_programs:
  - pattern: "UTIL*"
    type: "UTILITY"
    scope: "EXTERNAL"

external_callers:
  - caller: "EXTERNAL_SYSTEM"
    calls:
      - target: "PAYROLL1"
        type: "PROGRAM_CALL"
""")
        
        api = LegacyAnalyzerAPI(test_db)
        
        try:
            # Build flows with external config
            flow_ids = api.build_migration_flows(
                external_config_path=str(config_path)
            )
            
            assert len(flow_ids) > 0
            
            # Verify external config was loaded
            cursor = api.db.conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM external_program_config")
            count = cursor.fetchone()[0]
            assert count > 0
            
        finally:
            api.close()
    
    def test_build_migration_flows_invalid_config(self, test_db):
        """Test flow building with invalid external config path."""
        api = LegacyAnalyzerAPI(test_db)
        
        try:
            with pytest.raises(FileNotFoundError):
                api.build_migration_flows(
                    external_config_path="nonexistent.yaml"
                )
        finally:
            api.close()
    
    def test_export_migration_flows_all(self, test_db, temp_output_dir):
        """Test exporting all flows."""
        api = LegacyAnalyzerAPI(test_db)
        output_file = Path(temp_output_dir) / "flows.json"
        
        try:
            # Build flows first
            flow_ids = api.build_migration_flows()
            
            # Export all flows
            result = api.export_migration_flows(str(output_file))
            
            # Verify result structure
            assert 'flows' in result
            assert isinstance(result['flows'], list)
            assert len(result['flows']) > 0
            
            # Verify file was created
            assert output_file.exists()
            
            # Verify JSON structure
            with open(output_file) as f:
                data = json.load(f)
            
            assert 'flows' in data
            flow = data['flows'][0]
            assert 'flowId' in flow
            assert 'entryPoint' in flow
            assert 'scope' in flow
            assert 'interfaces' in flow
            assert 'dataOperations' in flow
            assert 'complexity' in flow
            
        finally:
            api.close()
    
    def test_export_migration_flows_specific(self, test_db, temp_output_dir):
        """Test exporting specific flows."""
        api = LegacyAnalyzerAPI(test_db)
        output_file = Path(temp_output_dir) / "specific_flows.json"
        
        try:
            # Build flows
            flow_ids = api.build_migration_flows()
            
            # Export specific flows
            specific_ids = flow_ids[:1]  # Export first flow only
            result = api.export_migration_flows(
                str(output_file),
                flow_ids=specific_ids
            )
            
            # Verify only specified flows were exported
            assert len(result['flows']) == len(specific_ids)
            assert result['flows'][0]['flowId'] in specific_ids
            
        finally:
            api.close()
    
    def test_export_migration_flows_with_filters(self, test_db, temp_output_dir):
        """Test exporting flows with filters."""
        api = LegacyAnalyzerAPI(test_db)
        output_file = Path(temp_output_dir) / "filtered_flows.json"
        
        try:
            # Build flows
            api.build_migration_flows()
            
            # Export with complexity filter
            result = api.export_migration_flows(
                str(output_file),
                min_complexity="LOW"
            )
            
            # Verify result
            assert 'flows' in result
            
            # All flows should have complexity tier >= LOW
            for flow in result['flows']:
                tier = flow['complexity']['tier']
                assert tier in ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH']
            
        finally:
            api.close()
    
    def test_export_migration_flows_invalid_complexity(self, test_db, temp_output_dir):
        """Test export with invalid complexity tier."""
        api = LegacyAnalyzerAPI(test_db)
        output_file = Path(temp_output_dir) / "flows.json"
        
        try:
            api.build_migration_flows()
            
            with pytest.raises(ValueError, match="Invalid min_complexity"):
                api.export_migration_flows(
                    str(output_file),
                    min_complexity="INVALID"
                )
        finally:
            api.close()
    
    def test_export_migration_flows_without_building(self, temp_output_dir):
        """Test export without building flows first."""
        # Create a database without migration schema
        with tempfile.NamedTemporaryFile(mode='w', suffix='.db', delete=False) as f:
            db_path = f.name
        
        conn = sqlite3.Connection(db_path)
        cursor = conn.cursor()
        
        # Create only basic tables, not migration tables
        cursor.execute("""
            CREATE TABLE artifact_dependencies (
                source_artifact_name TEXT,
                source_artifact_type TEXT,
                target_artifact_name TEXT,
                target_artifact_type TEXT,
                dependency_type TEXT,
                source_file_path TEXT,
                line_number INTEGER
            )
        """)
        conn.commit()
        conn.close()
        
        api = LegacyAnalyzerAPI(db_path)
        output_file = Path(temp_output_dir) / "flows.json"
        
        try:
            # Try to export without building
            with pytest.raises(ValueError, match="Migration flows table not found"):
                api.export_migration_flows(str(output_file))
        finally:
            api.close()
            Path(db_path).unlink(missing_ok=True)
    
    def test_export_migration_flows_invalid_output_dir(self, test_db):
        """Test export with invalid output directory."""
        api = LegacyAnalyzerAPI(test_db)
        
        try:
            api.build_migration_flows()
            
            with pytest.raises(FileNotFoundError, match="Output directory does not exist"):
                api.export_migration_flows("/nonexistent/dir/flows.json")
        finally:
            api.close()
    
    def test_export_migration_flows_empty_flow_ids(self, test_db, temp_output_dir):
        """Test export with empty flow_ids list."""
        api = LegacyAnalyzerAPI(test_db)
        output_file = Path(temp_output_dir) / "flows.json"
        
        try:
            api.build_migration_flows()
            
            # Export with empty list - should export nothing
            result = api.export_migration_flows(
                str(output_file),
                flow_ids=[]
            )
            
            # Should return empty flows (the exporter returns empty when flow_ids is empty)
            # But the warning message is printed
            assert 'flows' in result
            # The actual behavior is that empty flow_ids exports nothing
            # which is correct
            
        finally:
            api.close()
    
    def test_context_manager(self, test_db, temp_output_dir):
        """Test API with context manager."""
        output_file = Path(temp_output_dir) / "flows.json"
        
        # Use context manager
        with LegacyAnalyzerAPI(test_db) as api:
            flow_ids = api.build_migration_flows()
            result = api.export_migration_flows(str(output_file))
            
            assert len(flow_ids) > 0
            assert len(result['flows']) > 0
        
        # Verify file was created
        assert output_file.exists()
    
    def test_complete_workflow(self, test_db, temp_output_dir):
        """Test complete workflow: build and export."""
        api = LegacyAnalyzerAPI(test_db)
        
        try:
            # Step 1: Build flows
            print("Building migration flows...")
            flow_ids = api.build_migration_flows()
            print(f"✓ Built {len(flow_ids)} flows")
            
            assert len(flow_ids) > 0
            
            # Step 2: Export all flows
            all_flows_file = Path(temp_output_dir) / "all_flows.json"
            result = api.export_migration_flows(str(all_flows_file))
            print(f"✓ Exported {len(result['flows'])} flows")
            
            assert all_flows_file.exists()
            assert len(result['flows']) == len(flow_ids)
            
            # Step 3: Export specific flows
            specific_file = Path(temp_output_dir) / "specific_flows.json"
            specific_result = api.export_migration_flows(
                str(specific_file),
                flow_ids=[flow_ids[0]]
            )
            
            assert specific_file.exists()
            assert len(specific_result['flows']) == 1
            
            # Step 4: Verify JSON structure
            with open(all_flows_file) as f:
                data = json.load(f)
            
            flow = data['flows'][0]
            
            # Verify required fields
            assert 'flowId' in flow
            assert 'name' in flow
            assert 'entryPoint' in flow
            assert 'scope' in flow
            assert 'interfaces' in flow
            assert 'dataOperations' in flow
            assert 'complexity' in flow
            assert 'dependencies' in flow
            
            # Verify entry point structure
            entry_point = flow['entryPoint']
            assert 'program' in entry_point
            assert 'types' in entry_point
            assert isinstance(entry_point['types'], list)
            
            # Verify scope structure
            scope = flow['scope']
            assert 'programs' in scope
            assert 'copybooks' in scope
            assert 'datasets' in scope
            
            # Verify interfaces structure
            interfaces = flow['interfaces']
            assert 'inbound' in interfaces
            assert 'outbound' in interfaces
            
            # Verify data operations structure
            data_ops = flow['dataOperations']
            assert 'databases' in data_ops
            assert 'datasets' in data_ops
            
            # Verify complexity structure
            complexity = flow['complexity']
            assert 'totalPrograms' in complexity
            assert 'totalLines' in complexity
            assert 'cyclomaticComplexity' in complexity
            assert 'compositeScore' in complexity
            assert 'tier' in complexity
            
            # Verify dependencies structure
            dependencies = flow['dependencies']
            assert 'requiredFlows' in dependencies
            assert 'dependentFlows' in dependencies
            
            print("✓ All validations passed")
            
        finally:
            api.close()


class TestAPIValidation:
    """Test suite for API validation and error handling."""
    
    def test_build_with_invalid_database(self):
        """Test building with invalid database."""
        with pytest.raises(Exception):
            api = LegacyAnalyzerAPI(":memory:")
            api.db.conn = None  # Simulate invalid connection
            api.build_migration_flows()
    
    def test_export_with_invalid_parameters(self, test_db, temp_output_dir):
        """Test export with various invalid parameters."""
        api = LegacyAnalyzerAPI(test_db)
        output_file = Path(temp_output_dir) / "flows.json"
        
        try:
            api.build_migration_flows()
            
            # Invalid flow_ids type
            with pytest.raises(ValueError, match="flow_ids must be a list"):
                api.export_migration_flows(
                    str(output_file),
                    flow_ids="not_a_list"
                )
            
        finally:
            api.close()
    
    def test_export_without_output_file(self, test_db):
        """Test export without output file."""
        api = LegacyAnalyzerAPI(test_db)
        
        try:
            api.build_migration_flows()
            
            with pytest.raises(ValueError, match="output_file parameter is required"):
                api.export_migration_flows("")
        finally:
            api.close()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
