"""Integration tests for Legacy Analyzer."""
