"""
Integration tests for SMF Test Data Generator - Inventory Mode Workflow.

Tests the complete inventory mode workflow including:
- Configuration loading and validation
- Inventory database reading
- Record generation for all types (30, 110, 14, 15, 17, 62, 64)
- Output file creation and validation
- Record count verification
- Artifact presence/absence verification
- Infrastructure parameter effects on metrics
"""

import json
import pytest
import tempfile
import yaml
import sqlite3
from pathlib import Path
from datetime import datetime

from tools.smf_test_data_generator.config_loader import GeneratorConfig
from tools.smf_test_data_generator.data_source_reader import DataSourceReader
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters
from tools.smf_test_data_generator.multi_type_coordinator import MultiTypeRecordCoordinator
from tools.smf_test_data_generator.json_writer import JSONWriter


@pytest.fixture
def carddemo_inventory_db():
    """Path to CardDemo inventory database."""
    # Try multiple possible locations
    possible_paths = [
        Path("./databases/carddemo_inventory.db"),
        Path("./results/carddemo_analysis/carddemo.db"),
        Path("./databases/big.db")
    ]
    
    for db_path in possible_paths:
        if db_path.exists():
            return str(db_path)
    
    pytest.skip("CardDemo inventory database not available")


@pytest.fixture
def inventory_mode_config(tmp_path, carddemo_inventory_db):
    """Create inventory mode configuration for testing."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': carddemo_inventory_db,
        'output_directory': str(tmp_path / "output"),
        'application_name': 'inventory_test',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-01-31'  # One month for faster testing
        },
        'record_types': [30, 110, 14, 15, 17, 62, 64],
        'infrastructure': {
            'mips': 1000,
            'storage_gb': 500,
            'iops': 50000,
            'network_mbps': 10000
        },
        'active_artifacts': {
            'programs': [
                {'name': 'CBACT01C', 'frequency': 'high'},
                {'name': 'CBACT02C', 'frequency': 'medium'},
                {'name': 'CBCUS01C', 'frequency': 'low'}
            ],
            'jcl': [
                {'name': 'DALYREJS', 'frequency': 'high'},
                {'name': 'TRANREPT', 'frequency': 'medium'}
            ],
            'cics_transactions': [],  # Empty since database has no CICS transactions
            'datasets': [
                {'name': 'AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS', 'frequency': 'high'},
                {'name': 'AWS.M2.CARDDEMO.TRANFILE.VSAM.KSDS', 'frequency': 'high'}
            ]
        },
        'unreferenced_artifacts': {
            'programs': ['COBDATFT', 'CSUTLDTC'],
            'jcl': [],
            'datasets': []
        },
        'missing_artifacts': {
            'programs': ['MISSING01', 'MISSING02'],
            'datasets': ['AWS.M2.MISSING.DATA.KSDS']
        }
    }
    
    config_file = tmp_path / "inventory_config.yaml"
    with open(config_file, 'w') as f:
        yaml.dump(config_dict, f)
    
    return config_file


def test_inventory_mode_complete_workflow(inventory_mode_config, tmp_path):
    """
    Test complete inventory mode workflow from configuration to output files.
    
    Verifies:
    1. Configuration loads successfully
    2. Database validation succeeds
    3. All record types are generated
    4. Output files are created with valid JSON
    5. Record counts are reasonable
    """
    # Step 1: Load configuration
    config = GeneratorConfig(str(inventory_mode_config))
    errors = config.validate()
    assert len(errors) == 0, f"Configuration validation failed: {errors}"
    assert config.generation_mode == 'inventory'
    
    # Step 2: Validate database
    reader = DataSourceReader(config.database_path, config.generation_mode)
    is_valid, db_errors = reader.validate_database()
    assert is_valid, f"Database validation failed: {db_errors}"
    
    # Step 3: Build artifact catalog
    catalog = ArtifactCatalog(reader, config)
    
    # Step 4: Create infrastructure parameters
    infrastructure = InfrastructureParameters(config.infrastructure)
    assert infrastructure.mips == 1000
    assert infrastructure.storage_gb == 500
    
    # Step 5: Create distribution strategy
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Step 6: Generate all record types
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Verify all configured record types were generated
    assert 30 in records_by_type, "Type 30 records not generated"
    assert 14 in records_by_type, "Type 14 records not generated"
    assert 15 in records_by_type, "Type 15 records not generated"
    assert 17 in records_by_type, "Type 17 records not generated"
    assert 62 in records_by_type, "Type 62 records not generated"
    assert 64 in records_by_type, "Type 64 records not generated"
    
    # Verify record counts are reasonable
    assert len(records_by_type[30]) > 0, "No Type 30 records generated"
    
    # Type 110 may be empty if no CICS transactions exist in database
    if 110 in records_by_type:
        # If Type 110 records exist, verify they have content
        pass  # Can be empty if no CICS transactions configured
    
    # Step 7: Write output files
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_all_records(records_by_type)
    
    # Step 8: Verify output files exist
    for record_type in [30, 110, 14, 15, 17, 62, 64]:
        output_file = output_dir / f"smf{record_type}_inventory_test.json"
        assert output_file.exists(), f"Output file for Type {record_type} not created"
        
        # Verify file contains valid JSON
        with open(output_file) as f:
            data = json.load(f)
            assert isinstance(data, list), f"Type {record_type} file is not a JSON array"
    
    reader.close()


def test_inventory_mode_unreferenced_artifacts_excluded(inventory_mode_config):
    """
    Verify that unreferenced artifacts do NOT appear in generated records.
    
    Tests:
    - Unreferenced programs are not in Type 30 records
    - Unreferenced programs are not in Type 110 records
    - Unreferenced programs are not in any other record types
    """
    config = GeneratorConfig(str(inventory_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Collect all program names from all record types
    all_programs = set()
    
    # Type 30 records
    for record in records_by_type.get(30, []):
        if 'identification' in record and 'program_name' in record['identification']:
            all_programs.add(record['identification']['program_name'])
    
    # Type 110 records
    for record in records_by_type.get(110, []):
        if 'identification' in record and 'program_name' in record['identification']:
            all_programs.add(record['identification']['program_name'])
    
    # Type 14 records
    for record in records_by_type.get(14, []):
        if 'identification' in record and 'program_name' in record['identification']:
            all_programs.add(record['identification']['program_name'])
    
    # Type 15 records
    for record in records_by_type.get(15, []):
        if 'identification' in record and 'program_name' in record['identification']:
            all_programs.add(record['identification']['program_name'])
    
    # Verify unreferenced programs do NOT appear
    assert 'COBDATFT' not in all_programs, "Unreferenced program COBDATFT found in records"
    assert 'CSUTLDTC' not in all_programs, "Unreferenced program CSUTLDTC found in records"
    
    reader.close()


def test_inventory_mode_missing_artifacts_included(inventory_mode_config):
    """
    Verify that missing artifacts DO appear in generated records.
    
    Tests:
    - Missing programs appear in Type 30 records
    - Missing datasets appear in Type 14/15 records
    """
    config = GeneratorConfig(str(inventory_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Collect all program names from Type 30 records
    type30_programs = set()
    for record in records_by_type.get(30, []):
        if 'identification' in record and 'program_name' in record['identification']:
            type30_programs.add(record['identification']['program_name'])
    
    # Verify missing programs DO appear
    assert 'MISSING01' in type30_programs, "Missing program MISSING01 not found in Type 30 records"
    assert 'MISSING02' in type30_programs, "Missing program MISSING02 not found in Type 30 records"
    
    # Collect all dataset names from Type 14 and 15 records
    all_datasets = set()
    for record in records_by_type.get(14, []):
        if 'identification' in record and 'dataset_name' in record['identification']:
            all_datasets.add(record['identification']['dataset_name'])
    
    for record in records_by_type.get(15, []):
        if 'identification' in record and 'dataset_name' in record['identification']:
            all_datasets.add(record['identification']['dataset_name'])
    
    # Verify missing dataset appears (if Type 14/15 records were generated)
    if len(all_datasets) > 0:
        missing_dataset_found = any('MISSING' in ds for ds in all_datasets)
        # Note: Missing datasets may not always appear due to random selection
    
    reader.close()


def test_inventory_mode_infrastructure_parameters_affect_metrics(inventory_mode_config, tmp_path):
    """
    Verify that infrastructure parameters affect generated metrics.
    
    Tests:
    - Different MIPS values produce different CPU times
    - Different IOPS values produce different I/O counts
    - Metrics stay within realistic bounds
    """
    # Test with default infrastructure
    config1 = GeneratorConfig(str(inventory_mode_config))
    reader1 = DataSourceReader(config1.database_path, config1.generation_mode)
    catalog1 = ArtifactCatalog(reader1, config1)
    distribution1 = DistributionStrategy(config1.start_date, config1.end_date)
    infrastructure1 = InfrastructureParameters(config1.infrastructure)
    
    coordinator1 = MultiTypeRecordCoordinator(config1, catalog1, distribution1, infrastructure1)
    records1 = coordinator1.generate_all_records()
    
    # Get average CPU time from Type 30 records
    cpu_times1 = []
    for record in records1.get(30, []):
        if 'processor' in record and 'total_cpu_time' in record['processor']:
            cpu_times1.append(record['processor']['total_cpu_time'])
    
    avg_cpu1 = sum(cpu_times1) / len(cpu_times1) if cpu_times1 else 0
    
    reader1.close()
    
    # Test with higher MIPS (should produce lower CPU times)
    config_dict2 = {
        'generation_mode': 'inventory',
        'database_path': config1.database_path,
        'output_directory': str(tmp_path / "output2"),
        'application_name': 'infra_test2',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-01-31'
        },
        'record_types': [30],
        'infrastructure': {
            'mips': 2000,  # Double the MIPS
            'storage_gb': 500,
            'iops': 50000,
            'network_mbps': 10000
        },
        'active_artifacts': {
            'programs': [
                {'name': 'CBACT01C', 'frequency': 'high'}
            ],
            'jcl': [
                {'name': 'DALYREJS', 'frequency': 'high'}
            ],
            'cics_transactions': [],
            'datasets': []
        },
        'unreferenced_artifacts': {
            'programs': [],
            'jcl': [],
            'datasets': []
        },
        'missing_artifacts': {
            'programs': [],
            'datasets': []
        }
    }
    
    config_file2 = tmp_path / "infra_config2.yaml"
    with open(config_file2, 'w') as f:
        yaml.dump(config_dict2, f)
    
    config2 = GeneratorConfig(str(config_file2))
    reader2 = DataSourceReader(config2.database_path, config2.generation_mode)
    catalog2 = ArtifactCatalog(reader2, config2)
    distribution2 = DistributionStrategy(config2.start_date, config2.end_date)
    infrastructure2 = InfrastructureParameters(config2.infrastructure)
    
    coordinator2 = MultiTypeRecordCoordinator(config2, catalog2, distribution2, infrastructure2)
    records2 = coordinator2.generate_all_records()
    
    # Get average CPU time from Type 30 records
    cpu_times2 = []
    for record in records2.get(30, []):
        if 'processor' in record and 'total_cpu_time' in record['processor']:
            cpu_times2.append(record['processor']['total_cpu_time'])
    
    avg_cpu2 = sum(cpu_times2) / len(cpu_times2) if cpu_times2 else 0
    
    # Higher MIPS should produce lower CPU times (inverse relationship)
    # Allow some variance due to randomness
    if avg_cpu1 > 0 and avg_cpu2 > 0:
        assert avg_cpu2 < avg_cpu1 * 1.2, \
            f"Higher MIPS should produce lower CPU times: {avg_cpu2} vs {avg_cpu1}"
    
    reader2.close()


def test_inventory_mode_record_counts_match_frequency(inventory_mode_config):
    """
    Verify that record counts approximately match expected frequency distribution.
    
    Tests:
    - High frequency artifacts appear ~daily
    - Medium frequency artifacts appear ~weekly
    - Low frequency artifacts appear ~monthly
    """
    config = GeneratorConfig(str(inventory_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Count occurrences of each program in Type 30 records
    program_counts = {}
    for record in records_by_type.get(30, []):
        if 'identification' in record and 'program_name' in record['identification']:
            prog_name = record['identification']['program_name']
            program_counts[prog_name] = program_counts.get(prog_name, 0) + 1
    
    # Time range is 31 days (January 2023)
    # High frequency: ~31 records (daily)
    # Medium frequency: ~4-5 records (weekly)
    # Low frequency: ~1 record (monthly)
    
    # Allow 50% tolerance for randomness
    if 'CBACT01C' in program_counts:
        high_freq_count = program_counts['CBACT01C']
        assert 15 <= high_freq_count <= 50, \
            f"High frequency program count {high_freq_count} outside expected range [15-50]"
    
    if 'CBACT02C' in program_counts:
        medium_freq_count = program_counts['CBACT02C']
        assert 2 <= medium_freq_count <= 10, \
            f"Medium frequency program count {medium_freq_count} outside expected range [2-10]"
    
    if 'CBCUS01C' in program_counts:
        low_freq_count = program_counts['CBCUS01C']
        assert 1 <= low_freq_count <= 5, \
            f"Low frequency program count {low_freq_count} outside expected range [1-5]"
    
    reader.close()


def test_inventory_mode_all_output_files_valid_json(inventory_mode_config, tmp_path):
    """
    Verify that all generated output files contain valid JSON arrays.
    
    Tests:
    - Each record type file is valid JSON
    - Each file contains an array
    - Each record has expected structure
    """
    config = GeneratorConfig(str(inventory_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_all_records(records_by_type)
    
    # Verify each record type file
    record_type_checks = {
        30: ['record_type', 'identification', 'processor'],
        110: ['record_type', 'subsystem', 'identification'],
        14: ['record_type', 'identification'],
        15: ['record_type', 'identification'],
        17: ['record_type', 'identification'],
        62: ['record_type', 'identification'],
        64: ['record_type', 'identification', 'performance']
    }
    
    for record_type, required_fields in record_type_checks.items():
        output_file = output_dir / f"smf{record_type}_inventory_test.json"
        
        with open(output_file) as f:
            try:
                data = json.load(f)
                assert isinstance(data, list), f"Type {record_type} file is not a JSON array"
                
                if len(data) > 0:
                    first_record = data[0]
                    for field in required_fields:
                        assert field in first_record, \
                            f"Type {record_type} record missing required field: {field}"
                    
                    assert first_record['record_type'] == record_type, \
                        f"Type {record_type} record has wrong record_type: {first_record['record_type']}"
                
            except json.JSONDecodeError as e:
                pytest.fail(f"Type {record_type} file is not valid JSON: {e}")
    
    reader.close()


def test_inventory_mode_timestamps_within_range(inventory_mode_config):
    """
    Verify that all generated timestamps fall within the configured time range.
    
    Tests:
    - All record dates are within start_date and end_date
    - Date format is correct (YYYY-MM-DD)
    - Time format is correct (HH:MM:SS)
    """
    config = GeneratorConfig(str(inventory_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    start_date = config.start_date.date() if hasattr(config.start_date, 'date') else config.start_date
    end_date = config.end_date.date() if hasattr(config.end_date, 'date') else config.end_date
    
    # Check all record types
    for record_type, records in records_by_type.items():
        for record in records:
            if 'date' in record:
                try:
                    record_date = datetime.strptime(record['date'], '%Y-%m-%d').date()
                    assert start_date <= record_date <= end_date, \
                        f"Type {record_type} record date {record_date} outside range {start_date} to {end_date}"
                except ValueError as e:
                    pytest.fail(f"Type {record_type} record has invalid date format: {record['date']}")
            
            if 'timestamp' in record:
                try:
                    datetime.strptime(record['timestamp'], '%H:%M:%S')
                except ValueError as e:
                    pytest.fail(f"Type {record_type} record has invalid time format: {record['timestamp']}")
    
    reader.close()


def test_inventory_mode_cross_type_artifact_consistency(inventory_mode_config):
    """
    Verify that artifact references are consistent across record types.
    
    Tests:
    - Programs referenced in Type 30 match those in Type 14/15
    - Datasets referenced in Type 14/15 match those in Type 30 EXCP sections
    - Job names are consistent across related records
    """
    config = GeneratorConfig(str(inventory_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Collect programs from Type 30
    type30_programs = set()
    for record in records_by_type.get(30, []):
        if 'identification' in record and 'program_name' in record['identification']:
            type30_programs.add(record['identification']['program_name'])
    
    # Collect programs from Type 14
    type14_programs = set()
    for record in records_by_type.get(14, []):
        if 'identification' in record and 'program_name' in record['identification']:
            type14_programs.add(record['identification']['program_name'])
    
    # Collect programs from Type 15
    type15_programs = set()
    for record in records_by_type.get(15, []):
        if 'identification' in record and 'program_name' in record['identification']:
            type15_programs.add(record['identification']['program_name'])
    
    # Verify that Type 14/15 programs are a subset of Type 30 programs
    # (since Type 14/15 are generated for Type 30 jobs)
    missing_programs_set = set(catalog.get_missing_programs())
    
    if type14_programs:
        assert type14_programs.issubset(type30_programs | missing_programs_set), \
            f"Type 14 programs not found in Type 30: {type14_programs - type30_programs}"
    
    if type15_programs:
        assert type15_programs.issubset(type30_programs | missing_programs_set), \
            f"Type 15 programs not found in Type 30: {type15_programs - type30_programs}"
    
    reader.close()
