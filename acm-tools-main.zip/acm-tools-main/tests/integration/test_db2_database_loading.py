"""Integration tests for DB2 database loading.

This module tests the complete workflow of:
1. Parsing DB2 SMF records (Types 100, 101, 102)
2. Loading parsed records into database
3. Verifying field mapping and NULL handling

Requirements tested:
- 8.1: Database schemas for SMF Type 100 records
- 8.2: Database schemas for SMF Type 101 records
- 8.3: Database schemas for SMF Type 102 records
- 8.5: Field mapping from parsed records to database columns
- 8.6: NULL handling for optional fields
"""

import pytest
import json
import os
import tempfile
import sqlite3
from pathlib import Path

# Import smf_loader components
from tools.smf_analyzer.smf_loader import SMFLoader
from tools.smf_analyzer.smf_loader.schemas import SMF100Schema, SMF101Schema, SMF102Schema
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter

# Import parser components
from tools.smf_analyzer.smf_record_parser import SMFFileParser
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory


class TestDB2DatabaseLoading:
    """Integration tests for loading DB2 records into database."""
    
    @pytest.fixture
    def temp_db(self):
        """Create a temporary database for testing."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        yield db_path
        
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)
    
    @pytest.fixture
    def temp_json(self):
        """Create a temporary JSON file for testing."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json_path = f.name
        
        yield json_path
        
        # Cleanup
        if os.path.exists(json_path):
            os.unlink(json_path)
    
    @pytest.fixture
    def sample_smf100_record(self):
        """Create a sample SMF Type 100 record."""
        return {
            'record_type': 100,
            'version': 'V10',
            'system_id': 'SYS1',
            'date': '2024-01-15',
            'timestamp': '12:34:56.78',
            'sections': {
                'smf_header': {
                    'record_length': 1024,
                    'subsystem_id': 'DB2P',
                    'system_id': 'SYS1',
                },
                'qwhs_header': {
                    'ifcid': 1,
                    'subsystem_name': 'DB2P',
                    'release_number': 2560,  # 0x0A00 = V10
                },
                'product_section': {
                    'offset': 28,
                    'length': 512,
                    'count': 1,
                },
            }
        }
    
    @pytest.fixture
    def sample_smf101_record(self):
        """Create a sample SMF Type 101 record with optional headers."""
        return {
            'record_type': 101,
            'version': 'V11',
            'system_id': 'SYS1',
            'date': '2024-01-15',
            'timestamp': '12:34:56.78',
            'sections': {
                'smf_header': {
                    'record_length': 2048,
                    'subsystem_id': 'DB2P',
                    'system_id': 'SYS1',
                },
                'qwhs_header': {
                    'ifcid': 3,
                    'subsystem_name': 'DB2P',
                    'release_number': 2816,  # 0x0B00 = V11
                },
                'product_section': {
                    'offset': 28,
                    'length': 1024,
                    'count': 1,
                },
                'correlation_header': {
                    'offset': 100,
                    'header_length': 64,
                },
                'cpu_header': {
                    'offset': 164,
                    'header_length': 32,
                },
            }
        }
    
    @pytest.fixture
    def sample_smf102_record(self):
        """Create a sample SMF Type 102 record."""
        return {
            'record_type': 102,
            'version': 'V12',
            'system_id': 'SYS1',
            'date': '2024-01-15',
            'timestamp': '12:34:56.78',
            'sections': {
                'smf_header': {
                    'record_length': 1536,
                    'subsystem_id': 'DB2P',
                    'system_id': 'SYS1',
                },
                'qwhs_header': {
                    'ifcid': 2,
                    'subsystem_name': 'DB2P',
                    'release_number': 3072,  # 0x0C00 = V12
                },
                'product_section': {
                    'offset': 28,
                    'length': 768,
                    'count': 1,
                },
            }
        }
    
    def test_smf100_schema_creation(self, temp_db):
        """
        Test creating database schema for Type 100 records.
        
        Requirements: 8.1
        """
        # Create database adapter
        db = SQLiteAdapter(temp_db)
        
        # Create schema
        schema = SMF100Schema()
        
        # Create loader
        loader = SMFLoader(db, schema)
        
        # Create schema
        loader.create_schema()
        
        # Verify tables exist
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        assert 'smf_records' in tables
        assert 'smf100_statistics' in tables
        
        conn.close()
        loader.close()
    
    def test_smf101_schema_creation(self, temp_db):
        """
        Test creating database schema for Type 101 records.
        
        Requirements: 8.2
        """
        # Create database adapter
        db = SQLiteAdapter(temp_db)
        
        # Create schema
        schema = SMF101Schema()
        
        # Create loader
        loader = SMFLoader(db, schema)
        
        # Create schema
        loader.create_schema()
        
        # Verify tables exist
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        assert 'smf_records' in tables
        assert 'smf101_accounting' in tables
        assert 'smf101_optional_headers' in tables
        
        conn.close()
        loader.close()
    
    def test_smf102_schema_creation(self, temp_db):
        """
        Test creating database schema for Type 102 records.
        
        Requirements: 8.3
        """
        # Create database adapter
        db = SQLiteAdapter(temp_db)
        
        # Create schema
        schema = SMF102Schema()
        
        # Create loader
        loader = SMFLoader(db, schema)
        
        # Create schema
        loader.create_schema()
        
        # Verify tables exist
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        assert 'smf_records' in tables
        assert 'smf102_performance' in tables
        
        conn.close()
        loader.close()
    
    def test_smf100_field_mapping(self, temp_db, temp_json, sample_smf100_record):
        """
        Test field mapping for Type 100 records.
        
        Requirements: 8.5
        """
        # Write sample record to JSON
        with open(temp_json, 'w') as f:
            json.dump(sample_smf100_record, f)
        
        # Create database adapter
        db = SQLiteAdapter(temp_db)
        
        # Create schema
        schema = SMF100Schema()
        
        # Create loader
        loader = SMFLoader(db, schema)
        
        # Create schema and load data
        loader.create_schema()
        loader.load_json_file(temp_json)
        loader.close()
        
        # Verify data was loaded correctly
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Check header table (now smf_records)
        cursor.execute("SELECT * FROM smf_records")
        header = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        assert header is not None
        assert header['system_id'] == 'SYS1'
        assert header['db2_version'] == 'V10'
        assert header['record_date'] == '2024-01-15'
        assert header['record_time'] == '12:34:56.78'
        assert header['ifcid'] == 1
        assert header['subsystem_name'] == 'DB2P'
        assert header['release_number'] == 2560
        
        # Check statistics table
        cursor.execute("SELECT * FROM smf100_statistics")
        stats = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        assert stats is not None
        assert stats['product_section_offset'] == 28
        assert stats['product_section_length'] == 512
        assert stats['product_section_count'] == 1
        
        conn.close()
    
    def test_smf101_field_mapping_with_optional_headers(self, temp_db, temp_json, sample_smf101_record):
        """
        Test field mapping for Type 101 records including optional headers.
        
        Requirements: 8.5
        """
        # Write sample record to JSON
        with open(temp_json, 'w') as f:
            json.dump(sample_smf101_record, f)
        
        # Create database adapter
        db = SQLiteAdapter(temp_db)
        
        # Create schema
        schema = SMF101Schema()
        
        # Create loader
        loader = SMFLoader(db, schema)
        
        # Create schema and load data
        loader.create_schema()
        loader.load_json_file(temp_json)
        loader.close()
        
        # Verify data was loaded correctly
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Check header table (now smf_records)
        cursor.execute("SELECT * FROM smf_records")
        header = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        assert header is not None
        assert header['system_id'] == 'SYS1'
        assert header['db2_version'] == 'V11'
        assert header['ifcid'] == 3
        
        # Check accounting table
        cursor.execute("SELECT * FROM smf101_accounting")
        acct = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        assert acct is not None
        assert acct['has_correlation_header'] == 1
        assert acct['has_cpu_header'] == 1
        assert acct['has_trace_header'] == 0  # Not present in sample
        
        # Check optional headers table
        cursor.execute("SELECT * FROM smf101_optional_headers ORDER BY header_type")
        headers = [dict(zip([col[0] for col in cursor.description], row)) 
                  for row in cursor.fetchall()]
        
        assert len(headers) == 2  # correlation and cpu
        
        # Verify correlation header
        corr_header = next(h for h in headers if h['header_type'] == 'correlation')
        assert corr_header['header_offset'] == 100
        assert corr_header['header_length'] == 64
        assert corr_header['header_type_code'] == 2
        
        # Verify CPU header
        cpu_header = next(h for h in headers if h['header_type'] == 'cpu')
        assert cpu_header['header_offset'] == 164
        assert cpu_header['header_length'] == 32
        assert cpu_header['header_type_code'] == 8
        
        conn.close()
    
    def test_smf102_field_mapping(self, temp_db, temp_json, sample_smf102_record):
        """
        Test field mapping for Type 102 records.
        
        Requirements: 8.5
        """
        # Write sample record to JSON
        with open(temp_json, 'w') as f:
            json.dump(sample_smf102_record, f)
        
        # Create database adapter
        db = SQLiteAdapter(temp_db)
        
        # Create schema
        schema = SMF102Schema()
        
        # Create loader
        loader = SMFLoader(db, schema)
        
        # Create schema and load data
        loader.create_schema()
        loader.load_json_file(temp_json)
        loader.close()
        
        # Verify data was loaded correctly
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Check header table (now smf_records)
        cursor.execute("SELECT * FROM smf_records")
        header = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        assert header is not None
        assert header['system_id'] == 'SYS1'
        assert header['db2_version'] == 'V12'
        assert header['ifcid'] == 2
        assert header['release_number'] == 3072
        
        # Check performance table
        cursor.execute("SELECT * FROM smf102_performance")
        perf = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        assert perf is not None
        assert perf['product_section_offset'] == 28
        assert perf['product_section_length'] == 768
        
        conn.close()
    
    def test_null_handling_for_optional_fields(self, temp_db, temp_json):
        """
        Test NULL handling for optional fields.
        
        Requirements: 8.6
        """
        # Create a minimal record with missing optional fields
        minimal_record = {
            'record_type': 100,
            'version': 'V10',
            'system_id': 'SYS1',
            'date': '2024-01-15',
            'timestamp': '12:34:56.78',
            'sections': {
                'smf_header': {},
                'qwhs_header': {},
            }
        }
        
        # Write to JSON
        with open(temp_json, 'w') as f:
            json.dump(minimal_record, f)
        
        # Create database adapter
        db = SQLiteAdapter(temp_db)
        
        # Create schema
        schema = SMF100Schema()
        
        # Create loader
        loader = SMFLoader(db, schema)
        
        # Create schema and load data
        loader.create_schema()
        loader.load_json_file(temp_json)
        loader.close()
        
        # Verify NULL values for optional fields
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Check header table (now smf_records)
        cursor.execute("SELECT * FROM smf_records")
        header = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        # Optional fields should be NULL
        assert header['subsystem_id'] is None
        assert header['ifcid'] is None
        assert header['subsystem_name'] is None
        assert header['release_number'] is None
        
        # Check statistics table
        cursor.execute("SELECT * FROM smf100_statistics")
        stats = dict(zip([col[0] for col in cursor.description], cursor.fetchone()))
        
        # Optional fields should be NULL
        assert stats['product_section_offset'] is None
        assert stats['product_section_length'] is None
        assert stats['data_sections_json'] is None
        
        # Flags should be 0 (not NULL)
        assert stats['has_correlation_header'] == 0
        assert stats['has_trace_header'] == 0
        
        conn.close()
    
    @pytest.mark.skipif(
        not os.path.exists('examples/data/j/SMF.APR4.TRS.DECOMPRESS.rdw'),
        reason="Test file not available"
    )
    def test_load_real_db2_records_from_test_file(self, temp_db):
        """
        Test loading real DB2 records from the test file.
        
        This test parses the actual test file and loads any DB2 records
        (Types 100, 101, 102) into the database.
        
        Requirements: 8.5, 8.6
        """
        test_file = 'examples/data/j/SMF.APR4.TRS.DECOMPRESS.rdw'
        
        # Parse the file to find DB2 records
        parser = SMFFileParser(test_file)
        
        # Look for DB2 record types
        db2_records = []
        record_types_found = set()
        
        for record_data in parser.records:
            if len(record_data) < 6:
                continue
            
            record_type = record_data[5]
            
            if record_type in [100, 101, 102]:
                record_types_found.add(record_type)
                db2_records.append((record_type, record_data))
                
                # Limit to first few records of each type for testing
                if len(db2_records) >= 10:
                    break
        
        if not db2_records:
            pytest.skip("No DB2 records found in test file")
        
        print(f"\nFound DB2 record types: {sorted(record_types_found)}")
        print(f"Total DB2 records to test: {len(db2_records)}")
        
        # Parse and load records by type
        for record_type in sorted(record_types_found):
            print(f"\nTesting Type {record_type} records...")
            
            # Get records of this type
            type_records = [r for rt, r in db2_records if rt == record_type]
            
            # Parse records
            parsed_records = []
            for record_data in type_records:
                try:
                    smf_parser = SMFParserFactory.create_parser(
                        record_type,
                        record_data=record_data
                    )
                    
                    # Detect version and parse
                    from tools.smf_analyzer.smf_record_parser.parsers.db2_version_detector import DB2VersionDetector
                    version = DB2VersionDetector.detect_version(record_data, record_type)
                    
                    result = smf_parser.parse(record_data, version)
                    parsed_records.append(result.to_dict())
                except Exception as e:
                    print(f"  Warning: Failed to parse record: {e}")
                    continue
            
            if not parsed_records:
                print(f"  No successfully parsed Type {record_type} records")
                continue
            
            print(f"  Successfully parsed {len(parsed_records)} Type {record_type} records")
            
            # Create temporary JSON file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                json.dump(parsed_records, f)
                json_path = f.name
            
            try:
                # Create database adapter
                db = SQLiteAdapter(temp_db)
                
                # Create appropriate schema
                if record_type == 100:
                    schema = SMF100Schema()
                elif record_type == 101:
                    schema = SMF101Schema()
                else:  # 102
                    schema = SMF102Schema()
                
                # Create loader
                loader = SMFLoader(db, schema)
                
                # Create schema and load data
                loader.create_schema()
                loader.load_json_file(json_path)
                
                # Get statistics
                stats = loader.get_stats()
                print(f"  Database statistics:")
                for table_name, count in stats.items():
                    print(f"    {table_name}: {count} rows")
                
                loader.close()
                
                # Verify data was loaded
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                
                if record_type == 100:
                    cursor.execute("SELECT COUNT(*) FROM smf_records")
                elif record_type == 101:
                    cursor.execute("SELECT COUNT(*) FROM smf_records")
                else:
                    cursor.execute("SELECT COUNT(*) FROM smf_records")
                
                count = cursor.fetchone()[0]
                assert count > 0, f"No Type {record_type} records loaded"
                print(f"  ✓ Verified {count} Type {record_type} records in database")
                
                conn.close()
                
            finally:
                # Cleanup JSON file
                if os.path.exists(json_path):
                    os.unlink(json_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
