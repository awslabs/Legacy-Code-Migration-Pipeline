"""
Integration tests for SMF Test Data Generator - Source-Code Mode Workflow.

Tests the complete source-code mode workflow including:
- Configuration loading and validation
- Analysis database reading with dependency information
- Record generation for all types (30, 110, 14, 15, 17, 62, 64)
- Output file creation and validation
- Artifact references from analysis database
- Dependencies used for cross-references
- Infrastructure parameter effects on metrics
"""

import json
import pytest
import tempfile
import yaml
import sqlite3
from pathlib import Path
from datetime import datetime

from tools.smf_test_data_generator.config_loader import GeneratorConfig
from tools.smf_test_data_generator.data_source_reader import DataSourceReader
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters
from tools.smf_test_data_generator.multi_type_coordinator import MultiTypeRecordCoordinator
from tools.smf_test_data_generator.json_writer import JSONWriter


@pytest.fixture
def carddemo_analysis_db():
    """Path to CardDemo analysis database."""
    # Try multiple possible locations
    possible_paths = [
        Path("./results/carddemo_analysis/carddemo.db"),
        Path("./databases/big.db")
    ]
    
    for db_path in possible_paths:
        if db_path.exists():
            # Check if it has artifact_dependencies table (source-code mode requirement)
            try:
                conn = sqlite3.connect(str(db_path))
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='artifact_dependencies'")
                has_dependencies = cursor.fetchone() is not None
                conn.close()
                
                if has_dependencies:
                    return str(db_path)
            except:
                pass
    
    pytest.skip("CardDemo analysis database with dependencies not available")


@pytest.fixture
def sourcecode_mode_config(tmp_path, carddemo_analysis_db):
    """Create source-code mode configuration for testing."""
    config_dict = {
        'generation_mode': 'source-code',
        'database_path': carddemo_analysis_db,
        'output_directory': str(tmp_path / "output"),
        'application_name': 'sourcecode_test',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-01-31'  # One month for faster testing
        },
        'record_types': [30, 110, 14, 15, 17, 62, 64],
        'infrastructure': {
            'mips': 500,  # Different from inventory mode
            'storage_gb': 250,
            'iops': 25000,
            'network_mbps': 5000
        },
        'active_artifacts': {
            'programs': [
                {'name': 'CBACT01C', 'frequency': 'high'},
                {'name': 'CBACT02C', 'frequency': 'medium'},
                {'name': 'CBCUS01C', 'frequency': 'low'}
            ],
            'jcl': [
                {'name': 'DALYREJS', 'frequency': 'high'},
                {'name': 'TRANREPT', 'frequency': 'medium'}
            ],
            'cics_transactions': [],  # Empty since database may not have CICS transactions
            'datasets': [
                {'name': 'AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS', 'frequency': 'high'},
                {'name': 'AWS.M2.CARDDEMO.TRANFILE.VSAM.KSDS', 'frequency': 'high'}
            ]
        },
        'unreferenced_artifacts': {
            'programs': ['COBDATFT', 'CSUTLDTC'],
            'jcl': [],
            'datasets': []
        },
        'missing_artifacts': {
            'programs': ['MISSING01', 'MISSING02'],
            'datasets': ['AWS.M2.MISSING.DATA.KSDS']
        }
    }
    
    config_file = tmp_path / "sourcecode_config.yaml"
    with open(config_file, 'w') as f:
        yaml.dump(config_dict, f)
    
    return config_file


def test_sourcecode_mode_complete_workflow(sourcecode_mode_config, tmp_path):
    """
    Test complete source-code mode workflow from configuration to output files.
    
    Verifies:
    1. Configuration loads successfully
    2. Database validation succeeds (including artifact_dependencies table)
    3. All record types are generated
    4. Output files are created with valid JSON
    5. Record counts are reasonable
    """
    # Step 1: Load configuration
    config = GeneratorConfig(str(sourcecode_mode_config))
    errors = config.validate()
    assert len(errors) == 0, f"Configuration validation failed: {errors}"
    assert config.generation_mode == 'source-code'
    
    # Step 2: Validate database (should check for artifact_dependencies table)
    reader = DataSourceReader(config.database_path, config.generation_mode)
    is_valid, db_errors = reader.validate_database()
    assert is_valid, f"Database validation failed: {db_errors}"
    
    # Step 3: Build artifact catalog
    catalog = ArtifactCatalog(reader, config)
    
    # Step 4: Create infrastructure parameters (different from inventory mode)
    infrastructure = InfrastructureParameters(config.infrastructure)
    assert infrastructure.mips == 500  # Lower MIPS than inventory mode
    assert infrastructure.storage_gb == 250
    
    # Step 5: Create distribution strategy
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Step 6: Generate all record types
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Verify all configured record types were generated
    assert 30 in records_by_type, "Type 30 records not generated"
    assert 14 in records_by_type, "Type 14 records not generated"
    assert 15 in records_by_type, "Type 15 records not generated"
    assert 17 in records_by_type, "Type 17 records not generated"
    assert 62 in records_by_type, "Type 62 records not generated"
    assert 64 in records_by_type, "Type 64 records not generated"
    
    # Verify record counts are reasonable
    assert len(records_by_type[30]) > 0, "No Type 30 records generated"
    
    # Step 7: Write output files
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_all_records(records_by_type)
    
    # Step 8: Verify output files exist
    for record_type in [30, 110, 14, 15, 17, 62, 64]:
        output_file = output_dir / f"smf{record_type}_sourcecode_test.json"
        assert output_file.exists(), f"Output file for Type {record_type} not created"
        
        # Verify file contains valid JSON
        with open(output_file) as f:
            data = json.load(f)
            assert isinstance(data, list), f"Type {record_type} file is not a JSON array"
    
    reader.close()


def test_sourcecode_mode_artifact_references_from_analysis_db(sourcecode_mode_config):
    """
    Verify that artifact references come from the analysis database.
    
    Tests:
    - Programs referenced exist in inventory_programs table
    - Datasets referenced exist in inventory_datasets table or are missing artifacts
    - All artifacts come from the analysis database
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Get all programs from analysis database
    db_programs = {p['program_name'] for p in reader.get_programs()}
    missing_programs = set(catalog.get_missing_programs())
    
    # Collect all program names from Type 30 records
    type30_programs = set()
    for record in records_by_type.get(30, []):
        if 'identification' in record and 'program_name' in record['identification']:
            type30_programs.add(record['identification']['program_name'])
    
    # Verify all programs either exist in DB or are missing artifacts
    for program in type30_programs:
        assert program in db_programs or program in missing_programs, \
            f"Program {program} not found in analysis database or missing artifacts"
    
    reader.close()


def test_sourcecode_mode_dependencies_used_for_cross_references(sourcecode_mode_config):
    """
    Verify that dependencies are used for cross-references between artifacts.
    
    Tests:
    - Dataset references in Type 14/15 may come from dependency information
    - Programs and datasets are correctly linked via dependencies
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    
    # Check if dependencies exist
    dependencies = reader.get_dependencies()
    has_dependencies = len(dependencies) > 0
    
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # If dependencies exist, verify they're being used
    if has_dependencies:
        # Collect program-dataset pairs from Type 14 records
        type14_pairs = set()
        for record in records_by_type.get(14, []):
            if 'identification' in record:
                prog = record['identification'].get('program_name')
                ds = record['identification'].get('dataset_name')
                if prog and ds:
                    type14_pairs.add((prog, ds))
        
        # At least some pairs should exist (if Type 14 records were generated)
        if type14_pairs:
            # This verifies that the generator is creating realistic cross-references
            assert len(type14_pairs) > 0, "No program-dataset pairs found in Type 14 records"
    
    reader.close()


def test_sourcecode_mode_infrastructure_parameters_affect_metrics(sourcecode_mode_config):
    """
    Verify that infrastructure parameters affect generated metrics in source-code mode.
    
    Tests:
    - Lower MIPS (500) produces higher CPU times than inventory mode (1000)
    - Metrics stay within realistic bounds
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Get CPU times from Type 30 records
    cpu_times = []
    for record in records_by_type.get(30, []):
        if 'processor' in record and 'total_cpu_time' in record['processor']:
            cpu_times.append(record['processor']['total_cpu_time'])
    
    if cpu_times:
        avg_cpu = sum(cpu_times) / len(cpu_times)
        
        # With MIPS=500 (lower than inventory mode's 1000), CPU times should be higher
        # Verify CPU times are within realistic bounds (10ms to 10 minutes in centiseconds)
        assert all(1000 <= ct <= 60000000 for ct in cpu_times), \
            "CPU times outside realistic bounds"
        
        # Average should be reasonable
        assert avg_cpu > 0, "Average CPU time should be positive"
    
    reader.close()


def test_sourcecode_mode_all_output_files_valid_json(sourcecode_mode_config, tmp_path):
    """
    Verify that all generated output files contain valid JSON arrays.
    
    Tests:
    - Each record type file is valid JSON
    - Each file contains an array
    - Each record has expected structure
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_all_records(records_by_type)
    
    # Verify each record type file
    record_type_checks = {
        30: ['record_type', 'identification', 'processor'],
        110: ['record_type', 'subsystem', 'identification'],
        14: ['record_type', 'identification'],
        15: ['record_type', 'identification'],
        17: ['record_type', 'identification'],
        62: ['record_type', 'identification'],
        64: ['record_type', 'identification', 'performance']
    }
    
    for record_type, required_fields in record_type_checks.items():
        output_file = output_dir / f"smf{record_type}_sourcecode_test.json"
        
        with open(output_file) as f:
            try:
                data = json.load(f)
                assert isinstance(data, list), f"Type {record_type} file is not a JSON array"
                
                if len(data) > 0:
                    first_record = data[0]
                    for field in required_fields:
                        assert field in first_record, \
                            f"Type {record_type} record missing required field: {field}"
                    
                    assert first_record['record_type'] == record_type, \
                        f"Type {record_type} record has wrong record_type: {first_record['record_type']}"
                
            except json.JSONDecodeError as e:
                pytest.fail(f"Type {record_type} file is not valid JSON: {e}")
    
    reader.close()


def test_sourcecode_mode_database_validation_requires_dependencies(sourcecode_mode_config):
    """
    Verify that source-code mode requires artifact_dependencies table.
    
    Tests:
    - Database validation checks for artifact_dependencies table
    - Validation fails if table is missing
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    
    # Validation should succeed because we're using a database with dependencies
    is_valid, errors = reader.validate_database()
    assert is_valid, f"Database validation failed: {errors}"
    
    # Verify we can actually query dependencies
    dependencies = reader.get_dependencies()
    # Dependencies may be empty, but the table should exist
    assert isinstance(dependencies, list), "Dependencies should be a list"
    
    reader.close()


def test_sourcecode_mode_unreferenced_artifacts_excluded(sourcecode_mode_config):
    """
    Verify that unreferenced artifacts do NOT appear in generated records.
    
    Tests:
    - Unreferenced programs are not in any record types
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Collect all program names from all record types
    all_programs = set()
    
    for record_type, records in records_by_type.items():
        for record in records:
            if 'identification' in record and 'program_name' in record['identification']:
                all_programs.add(record['identification']['program_name'])
    
    # Verify unreferenced programs do NOT appear
    assert 'COBDATFT' not in all_programs, "Unreferenced program COBDATFT found in records"
    assert 'CSUTLDTC' not in all_programs, "Unreferenced program CSUTLDTC found in records"
    
    reader.close()


def test_sourcecode_mode_missing_artifacts_included(sourcecode_mode_config):
    """
    Verify that missing artifacts DO appear in generated records.
    
    Tests:
    - Missing programs appear in Type 30 records
    - Missing datasets appear in Type 14/15 records
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Collect all program names from Type 30 records
    type30_programs = set()
    for record in records_by_type.get(30, []):
        if 'identification' in record and 'program_name' in record['identification']:
            type30_programs.add(record['identification']['program_name'])
    
    # Verify missing programs DO appear
    assert 'MISSING01' in type30_programs, "Missing program MISSING01 not found in Type 30 records"
    assert 'MISSING02' in type30_programs, "Missing program MISSING02 not found in Type 30 records"
    
    reader.close()


def test_sourcecode_mode_timestamps_within_range(sourcecode_mode_config):
    """
    Verify that all generated timestamps fall within the configured time range.
    
    Tests:
    - All record dates are within start_date and end_date
    - Date format is correct (YYYY-MM-DD)
    - Time format is correct (HH:MM:SS)
    """
    config = GeneratorConfig(str(sourcecode_mode_config))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    start_date = config.start_date.date() if hasattr(config.start_date, 'date') else config.start_date
    end_date = config.end_date.date() if hasattr(config.end_date, 'date') else config.end_date
    
    # Check all record types
    for record_type, records in records_by_type.items():
        for record in records:
            if 'date' in record:
                try:
                    record_date = datetime.strptime(record['date'], '%Y-%m-%d').date()
                    assert start_date <= record_date <= end_date, \
                        f"Type {record_type} record date {record_date} outside range {start_date} to {end_date}"
                except ValueError as e:
                    pytest.fail(f"Type {record_type} record has invalid date format: {record['date']}")
            
            if 'timestamp' in record:
                try:
                    datetime.strptime(record['timestamp'], '%H:%M:%S')
                except ValueError as e:
                    pytest.fail(f"Type {record_type} record has invalid time format: {record['timestamp']}")
    
    reader.close()
