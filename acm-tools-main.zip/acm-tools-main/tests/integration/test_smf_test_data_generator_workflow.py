"""
Integration tests for SMF Test Data Generator complete workflow.

Tests the end-to-end workflow including:
- Configuration loading and validation
- Inventory database reading
- Record generation with active, unreferenced, and missing artifacts
- Output file creation and validation
- Record count verification
- Artifact presence/absence verification
"""

import json
import pytest
import tempfile
import yaml
from pathlib import Path
from datetime import datetime

from tools.smf_test_data_generator.config_loader import GeneratorConfig
from tools.smf_test_data_generator.inventory_reader import InventoryReader
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.smf30_generator import SMF30RecordGenerator
from tools.smf_test_data_generator.smf110_generator import SMF110RecordGenerator
from tools.smf_test_data_generator.json_writer import JSONWriter


@pytest.fixture
def carddemo_db_path():
    """Path to CardDemo inventory database."""
    db_path = Path("./results/carddemo_analysis/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    return str(db_path)


@pytest.fixture
def test_config(tmp_path, carddemo_db_path):
    """Create a test configuration with known artifacts."""
    config_dict = {
        'inventory_db': carddemo_db_path,
        'output_directory': str(tmp_path / "output"),
        'application_name': 'integration_test',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-01-31'  # One month for faster testing
        },
        'active_artifacts': {
            'programs': [
                {'name': 'CBACT01C', 'frequency': 'high'},
                {'name': 'CBACT02C', 'frequency': 'medium'},
                {'name': 'CBCUS01C', 'frequency': 'low'}
            ],
            'jcl': [
                {'name': 'DALYREJS', 'frequency': 'high'},
                {'name': 'TRANREPT', 'frequency': 'medium'}
            ],
            'cics_transactions': [
                {'name': 'CAUP', 'frequency': 'high'},
                {'name': 'CAVW', 'frequency': 'medium'}
            ]
        },
        'unreferenced_artifacts': {
            'programs': ['COBDATFT', 'CSUTLDTC'],
            'jcl': [],
            'datasets': []
        },
        'missing_artifacts': {
            'programs': ['MISSING01', 'MISSING02'],
            'datasets': ['AWS.M2.MISSING.DATA.KSDS']
        }
    }
    
    config_file = tmp_path / "test_config.yaml"
    with open(config_file, 'w') as f:
        yaml.dump(config_dict, f)
    
    return config_file


def test_complete_workflow_with_carddemo(test_config, tmp_path):
    """
    Test complete workflow from configuration to output files.
    
    This integration test verifies:
    1. Configuration loads successfully
    2. Inventory database is read correctly
    3. Artifact catalog is built with proper categorization
    4. Records are generated with correct distribution
    5. Output files are created with valid JSON
    6. Active artifacts appear in records
    7. Unreferenced artifacts do NOT appear in records
    8. Missing artifacts DO appear in records
    """
    # Step 1: Load configuration
    config = GeneratorConfig(str(test_config))
    errors = config.validate()
    assert len(errors) == 0, f"Configuration validation failed: {errors}"
    
    # Step 2: Read inventory database
    inventory_reader = InventoryReader(config.inventory_db_path)
    is_valid, db_errors = inventory_reader.validate_database()
    assert is_valid, f"Database validation failed: {db_errors}"
    
    # Step 3: Build artifact catalog
    catalog = ArtifactCatalog(inventory_reader, config)
    
    # Verify catalog has expected artifacts
    active_programs = catalog.get_active_programs()
    assert 'CBACT01C' in active_programs
    assert 'CBACT02C' in active_programs
    assert 'CBCUS01C' in active_programs
    
    # Verify unreferenced artifacts are marked correctly
    assert catalog.is_unreferenced('program', 'COBDATFT')
    assert catalog.is_unreferenced('program', 'CSUTLDTC')
    
    # Verify missing artifacts are in catalog
    missing_programs = catalog.get_missing_programs()
    assert 'MISSING01' in missing_programs
    assert 'MISSING02' in missing_programs
    
    # Step 4: Create distribution strategy
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Step 5: Generate Type 30 records
    smf30_generator = SMF30RecordGenerator(catalog, distribution)
    type30_records = smf30_generator.generate_records()
    
    assert len(type30_records) > 0, "No Type 30 records generated"
    
    # Step 6: Generate Type 110 records
    smf110_generator = SMF110RecordGenerator(catalog, distribution)
    type110_records = smf110_generator.generate_records()
    
    assert len(type110_records) > 0, "No Type 110 records generated"
    
    # Step 7: Write output files
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_type30_records(type30_records)
    writer.write_type110_records(type110_records)
    
    # Step 8: Verify output files exist
    type30_file = output_dir / "smf30_integration_test.json"
    type110_file = output_dir / "smf110_integration_test.json"
    
    assert type30_file.exists(), "Type 30 output file not created"
    assert type110_file.exists(), "Type 110 output file not created"
    
    # Step 9: Verify JSON structure
    with open(type30_file) as f:
        loaded_type30 = json.load(f)
    
    assert isinstance(loaded_type30, list)
    assert len(loaded_type30) == len(type30_records)
    
    with open(type110_file) as f:
        loaded_type110 = json.load(f)
    
    assert isinstance(loaded_type110, list)
    assert len(loaded_type110) == len(type110_records)
    
    # Clean up
    inventory_reader.close()


def test_active_artifacts_appear_in_records(test_config):
    """Verify that all active artifacts appear in generated records."""
    config = GeneratorConfig(str(test_config))
    inventory_reader = InventoryReader(config.inventory_db_path)
    catalog = ArtifactCatalog(inventory_reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Generate records
    smf30_generator = SMF30RecordGenerator(catalog, distribution)
    type30_records = smf30_generator.generate_records()
    
    smf110_generator = SMF110RecordGenerator(catalog, distribution)
    type110_records = smf110_generator.generate_records()
    
    # Extract program names from Type 30 records
    type30_programs = set()
    for record in type30_records:
        if 'identification' in record and 'program_name' in record['identification']:
            type30_programs.add(record['identification']['program_name'])
    
    # Verify active programs appear
    assert 'CBACT01C' in type30_programs, "Active program CBACT01C not found in Type 30 records"
    assert 'CBACT02C' in type30_programs, "Active program CBACT02C not found in Type 30 records"
    assert 'CBCUS01C' in type30_programs, "Active program CBCUS01C not found in Type 30 records"
    
    # Extract transaction IDs from Type 110 records
    type110_transactions = set()
    for record in type110_records:
        if 'identification' in record and 'tran_name' in record['identification']:
            type110_transactions.add(record['identification']['tran_name'])
    
    # Verify active transactions appear
    assert 'CAUP' in type110_transactions, "Active transaction CAUP not found in Type 110 records"
    assert 'CAVW' in type110_transactions, "Active transaction CAVW not found in Type 110 records"
    
    inventory_reader.close()


def test_unreferenced_artifacts_excluded_from_records(test_config):
    """Verify that unreferenced artifacts do NOT appear in generated records."""
    config = GeneratorConfig(str(test_config))
    inventory_reader = InventoryReader(config.inventory_db_path)
    catalog = ArtifactCatalog(inventory_reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Generate records
    smf30_generator = SMF30RecordGenerator(catalog, distribution)
    type30_records = smf30_generator.generate_records()
    
    smf110_generator = SMF110RecordGenerator(catalog, distribution)
    type110_records = smf110_generator.generate_records()
    
    # Extract all program names from Type 30 records
    type30_programs = set()
    for record in type30_records:
        if 'identification' in record and 'program_name' in record['identification']:
            type30_programs.add(record['identification']['program_name'])
    
    # Verify unreferenced programs do NOT appear
    assert 'COBDATFT' not in type30_programs, "Unreferenced program COBDATFT found in Type 30 records"
    assert 'CSUTLDTC' not in type30_programs, "Unreferenced program CSUTLDTC found in Type 30 records"
    
    inventory_reader.close()


def test_missing_artifacts_appear_in_records(test_config):
    """Verify that missing artifacts DO appear in generated records."""
    config = GeneratorConfig(str(test_config))
    inventory_reader = InventoryReader(config.inventory_db_path)
    catalog = ArtifactCatalog(inventory_reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Generate records
    smf30_generator = SMF30RecordGenerator(catalog, distribution)
    type30_records = smf30_generator.generate_records()
    
    # Extract all program names from Type 30 records
    type30_programs = set()
    for record in type30_records:
        if 'identification' in record and 'program_name' in record['identification']:
            type30_programs.add(record['identification']['program_name'])
    
    # Verify missing programs DO appear
    assert 'MISSING01' in type30_programs, "Missing program MISSING01 not found in Type 30 records"
    assert 'MISSING02' in type30_programs, "Missing program MISSING02 not found in Type 30 records"
    
    # Extract all dataset names from Type 30 EXCP sections for records with missing programs
    type30_datasets = set()
    for record in type30_records:
        # Only check datasets in records with missing programs
        if 'identification' in record and record['identification'].get('program_name') in ['MISSING01', 'MISSING02']:
            if 'excp_sections' in record:
                for excp in record['excp_sections']:
                    if 'dd_name' in excp:
                        type30_datasets.add(excp['dd_name'])
    
    # Verify missing dataset appears in records with missing programs
    # Note: dd_name might be abbreviated, so check if any dataset contains the missing name
    if len(type30_datasets) > 0:  # Only check if there are datasets
        missing_dataset_found = any('MISSING' in ds or 'AWS.M2.MISSING' in ds for ds in type30_datasets)
        # This is optional since missing datasets are only included with missing programs
        # and the selection is random
    
    inventory_reader.close()


def test_record_counts_match_frequency_distribution(test_config):
    """Verify that record counts approximately match expected frequency distribution."""
    config = GeneratorConfig(str(test_config))
    inventory_reader = InventoryReader(config.inventory_db_path)
    catalog = ArtifactCatalog(inventory_reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Generate records
    smf30_generator = SMF30RecordGenerator(catalog, distribution)
    type30_records = smf30_generator.generate_records()
    
    # Count occurrences of each program
    program_counts = {}
    for record in type30_records:
        if 'identification' in record and 'program_name' in record['identification']:
            prog_name = record['identification']['program_name']
            program_counts[prog_name] = program_counts.get(prog_name, 0) + 1
    
    # Time range is 31 days (January 2023)
    # High frequency should be ~31 records (daily)
    # Medium frequency should be ~4-5 records (weekly)
    # Low frequency should be ~1 record (monthly)
    
    # Allow 50% tolerance for randomness
    if 'CBACT01C' in program_counts:
        high_freq_count = program_counts['CBACT01C']
        assert 15 <= high_freq_count <= 45, f"High frequency program count {high_freq_count} outside expected range"
    
    if 'CBACT02C' in program_counts:
        medium_freq_count = program_counts['CBACT02C']
        assert 2 <= medium_freq_count <= 10, f"Medium frequency program count {medium_freq_count} outside expected range"
    
    if 'CBCUS01C' in program_counts:
        low_freq_count = program_counts['CBCUS01C']
        assert 1 <= low_freq_count <= 5, f"Low frequency program count {low_freq_count} outside expected range"
    
    inventory_reader.close()


def test_generated_files_are_valid_json(test_config, tmp_path):
    """Verify that generated files contain valid JSON arrays."""
    config = GeneratorConfig(str(test_config))
    inventory_reader = InventoryReader(config.inventory_db_path)
    catalog = ArtifactCatalog(inventory_reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Generate and write records
    smf30_generator = SMF30RecordGenerator(catalog, distribution)
    type30_records = smf30_generator.generate_records()
    
    smf110_generator = SMF110RecordGenerator(catalog, distribution)
    type110_records = smf110_generator.generate_records()
    
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_type30_records(type30_records)
    writer.write_type110_records(type110_records)
    
    # Verify Type 30 file is valid JSON
    type30_file = output_dir / "smf30_integration_test.json"
    with open(type30_file) as f:
        try:
            data = json.load(f)
            assert isinstance(data, list), "Type 30 file does not contain a JSON array"
            assert len(data) > 0, "Type 30 file contains empty array"
            
            # Verify first record has expected structure
            first_record = data[0]
            assert 'record_type' in first_record
            assert first_record['record_type'] == 30
            assert 'identification' in first_record
            assert 'processor' in first_record
            
        except json.JSONDecodeError as e:
            pytest.fail(f"Type 30 file is not valid JSON: {e}")
    
    # Verify Type 110 file is valid JSON
    type110_file = output_dir / "smf110_integration_test.json"
    with open(type110_file) as f:
        try:
            data = json.load(f)
            assert isinstance(data, list), "Type 110 file does not contain a JSON array"
            assert len(data) > 0, "Type 110 file contains empty array"
            
            # Verify first record has expected structure
            first_record = data[0]
            assert 'record_type' in first_record
            assert first_record['record_type'] == 110
            assert 'subsystem' in first_record
            assert 'identification' in first_record
            
        except json.JSONDecodeError as e:
            pytest.fail(f"Type 110 file is not valid JSON: {e}")
    
    inventory_reader.close()


def test_timestamps_within_configured_range(test_config):
    """Verify that all generated timestamps fall within the configured time range."""
    config = GeneratorConfig(str(test_config))
    inventory_reader = InventoryReader(config.inventory_db_path)
    catalog = ArtifactCatalog(inventory_reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Generate records
    smf30_generator = SMF30RecordGenerator(catalog, distribution)
    type30_records = smf30_generator.generate_records()
    
    smf110_generator = SMF110RecordGenerator(catalog, distribution)
    type110_records = smf110_generator.generate_records()
    
    start_date = config.start_date.date() if hasattr(config.start_date, 'date') else config.start_date
    end_date = config.end_date.date() if hasattr(config.end_date, 'date') else config.end_date
    
    # Check Type 30 timestamps
    for record in type30_records:
        if 'date' in record:
            record_date = datetime.strptime(record['date'], '%Y-%m-%d').date()
            assert start_date <= record_date <= end_date, \
                f"Type 30 record date {record_date} outside range {start_date} to {end_date}"
    
    # Check Type 110 timestamps
    for record in type110_records:
        if 'date' in record:
            record_date = datetime.strptime(record['date'], '%Y-%m-%d').date()
            assert start_date <= record_date <= end_date, \
                f"Type 110 record date {record_date} outside range {start_date} to {end_date}"
    
    inventory_reader.close()


def test_cics_transaction_program_mapping(test_config):
    """Verify that CICS transactions are correctly mapped to their programs."""
    config = GeneratorConfig(str(test_config))
    inventory_reader = InventoryReader(config.inventory_db_path)
    catalog = ArtifactCatalog(inventory_reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    
    # Get expected mappings from catalog
    cics_programs = inventory_reader.get_cics_programs()
    
    # Generate Type 110 records
    smf110_generator = SMF110RecordGenerator(catalog, distribution)
    type110_records = smf110_generator.generate_records()
    
    # Verify mappings in generated records
    for record in type110_records:
        if 'identification' in record:
            tran_id = record['identification'].get('tran_name')
            prog_name = record['identification'].get('program_name')
            
            if tran_id and tran_id in cics_programs:
                expected_program = cics_programs[tran_id]
                assert prog_name == expected_program, \
                    f"Transaction {tran_id} mapped to {prog_name}, expected {expected_program}"
    
    inventory_reader.close()
