"""Integration test for SMF Type 101 schema redesign.

This test verifies that the new structured schema works correctly
with the parser and loader.
"""

import pytest
import tempfile
import os
from pathlib import Path

from tools.smf_analyzer.smf_loader import SMFLoader
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas import SMF101Schema


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    yield path
    if os.path.exists(path):
        os.unlink(path)


@pytest.fixture
def sample_record():
    """Create a sample SMF Type 101 record."""
    return {
        'record_type': 101,
        'subtype': 3,
        'record_length': 5000,
        'system_id': 'SYS1',
        'timestamp': '2024-01-15 10:30:00',
        'date': '2024-01-15',
        'version': 'V11',
        'sections': {
            'smf_header': {
                'record_length': 5000,
                'system_id': 'SYS1',
                'subsystem_id': 'DB2A',
            },
            'qwhs_header': {
                'ifcid': 3,
                'subsystem_name': 'DB2A',
                'release_number': 1110,
            },
            'optional_headers': {
                'correlation': {
                    'authorization_id': 'USER01',
                    'correlation_id': 'CORR0001',
                    'connection_name': 'BATCH',
                    'plan_name': 'PLAN01',
                    'connection_type': 1,
                }
            },
            'data_sections': {
                'qwac': {
                    'begin_store_clock': 1000000,
                    'end_store_clock': 1005000,
                    'begin_cpu_time': 100000,
                    'end_cpu_time': 100500,
                    'accumulated_cpu_in_db2': 50000,
                    'accumulated_elapsed_in_db2': 100000,
                    'accumulated_wait_io': 10000,
                    'accumulated_wait_lock': 5000,
                    'commit_count': 10,
                    'abort_count': 1,
                    'db2_entry_exit_count': 50,
                    'is_rollup': False,
                    'class2_active': True,
                    'class3_active': True,
                    'package_count': 5,
                    'reason_invoked': 1,
                    'flags': 0x0001,
                },
                'qxst': {
                    'select_count': 100,
                    'insert_count': 20,
                    'update_count': 30,
                    'delete_count': 5,
                    'describe_count': 3,
                    'prepare_count': 40,
                    'open_count': 80,
                    'close_count': 80,
                    'fetch_count': 500,
                },
                'qbac': {
                    'buffer_pool_id': 0,
                    'getpage_requests': 1000,
                    'sync_read_io': 100,
                    'seq_prefetch_requests': 50,
                    'list_prefetch_requests': 20,
                    'dynamic_prefetch_requests': 10,
                },
            }
        }
    }


def test_schema_creation(temp_db):
    """Test that all tables are created correctly."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    
    # Verify all tables exist
    cursor = db_adapter.conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = {row[0] for row in cursor.fetchall()}
    
    assert 'smf_records' in tables
    assert 'smf101_accounting' in tables
    assert 'smf101_sql_statistics' in tables
    assert 'smf101_buffer_manager' in tables
    assert 'smf101_correlation' in tables


def test_record_loading(temp_db, sample_record):
    """Test that a record can be loaded into all tables."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    loader.load_record(sample_record)
    
    cursor = db_adapter.conn.cursor()
    
    # Check smf_records
    cursor.execute("SELECT COUNT(*) FROM smf_records")
    assert cursor.fetchone()[0] == 1
    
    # Check smf101_accounting
    cursor.execute("SELECT COUNT(*) FROM smf101_accounting")
    assert cursor.fetchone()[0] == 1
    
    # Check smf101_sql_statistics
    cursor.execute("SELECT COUNT(*) FROM smf101_sql_statistics")
    assert cursor.fetchone()[0] == 1
    
    # Check smf101_buffer_manager
    cursor.execute("SELECT COUNT(*) FROM smf101_buffer_manager")
    assert cursor.fetchone()[0] == 1
    
    # Check smf101_correlation
    cursor.execute("SELECT COUNT(*) FROM smf101_correlation")
    assert cursor.fetchone()[0] == 1


def test_accounting_data_stored_correctly(temp_db, sample_record):
    """Test that accounting data is stored correctly."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    loader.load_record(sample_record)
    
    cursor = db_adapter.conn.cursor()
    cursor.execute("""
        SELECT begin_cpu_time, end_cpu_time, accumulated_cpu_in_db2,
               commit_count, abort_count, is_rollup, class2_active
        FROM smf101_accounting
    """)
    row = cursor.fetchone()
    
    assert row[0] == 100000  # begin_cpu_time
    assert row[1] == 100500  # end_cpu_time
    assert row[2] == 50000   # accumulated_cpu_in_db2
    assert row[3] == 10      # commit_count
    assert row[4] == 1       # abort_count
    assert row[5] == 0       # is_rollup (False)
    assert row[6] == 1       # class2_active (True)


def test_sql_statistics_stored_correctly(temp_db, sample_record):
    """Test that SQL statistics are stored correctly."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    loader.load_record(sample_record)
    
    cursor = db_adapter.conn.cursor()
    cursor.execute("""
        SELECT select_count, insert_count, update_count, delete_count, fetch_count
        FROM smf101_sql_statistics
    """)
    row = cursor.fetchone()
    
    assert row[0] == 100  # select_count
    assert row[1] == 20   # insert_count
    assert row[2] == 30   # update_count
    assert row[3] == 5    # delete_count
    assert row[4] == 500  # fetch_count


def test_buffer_manager_stored_correctly(temp_db, sample_record):
    """Test that buffer manager data is stored correctly."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    loader.load_record(sample_record)
    
    cursor = db_adapter.conn.cursor()
    cursor.execute("""
        SELECT buffer_pool_id, getpage_requests, sync_read_io
        FROM smf101_buffer_manager
    """)
    row = cursor.fetchone()
    
    assert row[0] == 0     # buffer_pool_id
    assert row[1] == 1000  # getpage_requests
    assert row[2] == 100   # sync_read_io


def test_correlation_stored_correctly(temp_db, sample_record):
    """Test that correlation data is stored correctly."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    loader.load_record(sample_record)
    
    cursor = db_adapter.conn.cursor()
    cursor.execute("""
        SELECT authorization_id, plan_name, connection_name
        FROM smf101_correlation
    """)
    row = cursor.fetchone()
    
    assert row[0] == 'USER01'  # authorization_id
    assert row[1] == 'PLAN01'  # plan_name
    assert row[2] == 'BATCH'   # connection_name


def test_missing_sections_handled_gracefully(temp_db):
    """Test that records with missing sections are handled correctly."""
    # Create a minimal record without optional sections
    minimal_record = {
        'record_type': 101,
        'subtype': 3,
        'record_length': 1000,
        'system_id': 'SYS1',
        'timestamp': '2024-01-15 10:30:00',
        'date': '2024-01-15',
        'version': 'V11',
        'sections': {
            'smf_header': {
                'record_length': 1000,
                'system_id': 'SYS1',
            },
            'qwhs_header': {
                'ifcid': 3,
            },
            'data_sections': {}  # No data sections
        }
    }
    
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    loader.load_record(minimal_record)
    
    cursor = db_adapter.conn.cursor()
    
    # Should have main record
    cursor.execute("SELECT COUNT(*) FROM smf_records")
    assert cursor.fetchone()[0] == 1
    
    # Should have no detail records
    cursor.execute("SELECT COUNT(*) FROM smf101_accounting")
    assert cursor.fetchone()[0] == 0
    
    cursor.execute("SELECT COUNT(*) FROM smf101_sql_statistics")
    assert cursor.fetchone()[0] == 0
    
    cursor.execute("SELECT COUNT(*) FROM smf101_buffer_manager")
    assert cursor.fetchone()[0] == 0
    
    cursor.execute("SELECT COUNT(*) FROM smf101_correlation")
    assert cursor.fetchone()[0] == 0


def test_indexes_created(temp_db):
    """Test that indexes are created on key fields."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    
    cursor = db_adapter.conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='index'")
    indexes = {row[0] for row in cursor.fetchall()}
    
    # Check that indexes exist (SQLite auto-creates some, we check for our custom ones)
    # The exact index names depend on the database adapter implementation
    assert len(indexes) > 0  # At least some indexes should exist


def test_foreign_key_relationships(temp_db, sample_record):
    """Test that foreign key relationships work correctly."""
    db_adapter = SQLiteAdapter(temp_db)
    schema = SMF101Schema()
    loader = SMFLoader(db_adapter, schema)
    
    loader.create_schema()
    loader.load_record(sample_record)
    
    cursor = db_adapter.conn.cursor()
    
    # Get the record_id from smf_records
    cursor.execute("SELECT record_id FROM smf_records")
    record_id = cursor.fetchone()[0]
    
    # Verify all child tables reference the same record_id
    cursor.execute("SELECT record_id FROM smf101_accounting")
    assert cursor.fetchone()[0] == record_id
    
    cursor.execute("SELECT record_id FROM smf101_sql_statistics")
    assert cursor.fetchone()[0] == record_id
    
    cursor.execute("SELECT record_id FROM smf101_buffer_manager")
    assert cursor.fetchone()[0] == record_id
    
    cursor.execute("SELECT record_id FROM smf101_correlation")
    assert cursor.fetchone()[0] == record_id
