"""Full integration test for DB2-versioned SMF parsers.

This test script performs comprehensive integration testing:
1. Parse examples/data/j/SMF.APR4.TRS.DECOMPRESS.rdw with all DB2 parsers
2. Verify all Type 100, 101, 102 records are correctly parsed
3. Load parsed records into database
4. Verify database contents
5. Output results to ./temp/ directory
6. Test fallback parser behavior with various version scenarios

Requirements tested:
- 9.1: Tests using provided test file
- 9.2: Temporary output to ./temp/ directory
- 11.1: Warning logs for unsupported versions
- 11.2: Fallback to nearest available parser
- 11.3: Logging of fallback parser usage
- 11.4: Error when no fallback available
- 11.5: Configuration option to disable fallback
- 11.6: Warning messages with version details
"""

import pytest
import json
import os
import tempfile
import sqlite3
from pathlib import Path
from datetime import datetime
import logging

# Import smf_loader components
from tools.smf_analyzer.smf_loader import SMFLoader
from tools.smf_analyzer.smf_loader.schemas import SMF100Schema, SMF101Schema, SMF102Schema
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter

# Import parser components
from tools.smf_analyzer.smf_record_parser import SMFFileParser
from tools.smf_analyzer.smf_record_parser.parsers.factory import SMFParserFactory
from tools.smf_analyzer.smf_record_parser.parsers.db2_version_detector import DB2VersionDetector
from tools.smf_analyzer.smf_record_parser.exceptions import UnsupportedVersionError


# Configure logging to capture warnings
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestDB2FullIntegration:
    """Full integration tests for DB2-versioned SMF parsers."""
    
    TEST_FILE = 'examples/data/j/SMF.APR4.TRS.DECOMPRESS.rdw'
    TEMP_DIR = './temp'
    
    @pytest.fixture(autouse=True)
    def setup_temp_dir(self):
        """Ensure temp directory exists."""
        os.makedirs(self.TEMP_DIR, exist_ok=True)
        yield
    
    @pytest.fixture
    def temp_db(self):
        """Create a temporary database for testing."""
        db_path = os.path.join(self.TEMP_DIR, f'test_db2_integration_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db')
        
        yield db_path
        
        # Keep the database for inspection
        logger.info(f"Test database saved at: {db_path}")
    
    @pytest.mark.skipif(
        not os.path.exists(TEST_FILE),
        reason="Test file not available"
    )
    def test_full_integration_parse_and_load(self, temp_db):
        """
        Full integration test: Parse all DB2 records and load into database.
        
        This test:
        1. Parses the test file to find all DB2 records (Types 100, 101, 102)
        2. Detects DB2 version for each record
        3. Parses each record with the appropriate version-specific parser
        4. Loads all parsed records into database
        5. Verifies database contents
        6. Outputs results to ./temp/ directory
        
        Requirements: 9.1, 9.2
        
        NOTE: The test file SMF.APR4.TRS.DECOMPRESS.rdw contains Type 100, 101, and 102
        records, but they are NOT DB2 records - they are from a different subsystem
        (likely VTAM or CICS based on subsystem IDs like "LY62", "LY63", "PDLY").
        
        DB2 records would have subsystem IDs like "DB2P", "DSN1", etc. and would
        contain the QWHS header with resource manager ID 0xDB.
        
        This test will skip if no actual DB2 records are found in the file.
        """
        logger.info(f"\n{'='*80}")
        logger.info("FULL INTEGRATION TEST: Parse and Load DB2 Records")
        logger.info(f"{'='*80}\n")
        logger.info("NOTE: Checking if test file contains actual DB2 records...")
        logger.info("DB2 records have subsystem IDs like 'DB2P', 'DSN1', etc.")
        logger.info(f"{'='*80}\n")
        
        # Step 1: Parse test file and find DB2 records
        logger.info(f"Step 1: Scanning test file for DB2 records: {self.TEST_FILE}")
        
        # First, we need to read the raw file to extract DB2 record data
        # We'll use a simple approach to read records
        db2_records = []
        record_types_found = {}
        version_distribution = {}
        
        with open(self.TEST_FILE, 'rb') as f:
            idx = 0
            while True:
                # Read RDW (4 bytes)
                rdw_bytes = f.read(4)
                if len(rdw_bytes) < 4:
                    break
                
                # Parse RDW to get record length
                record_length = int.from_bytes(rdw_bytes[0:2], 'big')
                
                if record_length < 6:
                    # Invalid record, skip
                    continue
                
                # Read the rest of the record (record_length includes RDW)
                remaining = record_length - 4
                record_data = f.read(remaining)
                
                if len(record_data) < remaining:
                    break
                
                # Full record including RDW
                full_record = rdw_bytes + record_data
                
                # Check record type (at offset 5 in the SMF record structure)
                # SMF record structure: bytes 0-1 = length, bytes 2-3 = segment, byte 4 = system indicator, byte 5 = record type
                # In record_data (which starts after RDW), byte 5 is the record type
                if len(record_data) < 6:
                    idx += 1
                    continue
                
                record_type = record_data[5]  # Offset 5 in SMF record
                
                if record_type in [100, 101, 102]:
                    # Detect version
                    try:
                        # Pass the record WITHOUT RDW to the detector
                        version = DB2VersionDetector.detect_version(record_data, record_type)
                        
                        # Track statistics
                        if record_type not in record_types_found:
                            record_types_found[record_type] = 0
                            version_distribution[record_type] = {}
                        
                        record_types_found[record_type] += 1
                        
                        if version not in version_distribution[record_type]:
                            version_distribution[record_type][version] = 0
                        version_distribution[record_type][version] += 1
                        
                        db2_records.append({
                            'index': idx,
                            'type': record_type,
                            'version': version,
                            'data': record_data  # Store record without RDW
                        })
                        
                    except Exception as e:
                        logger.warning(f"  Failed to detect version for record {idx} (Type {record_type}): {e}")
                
                idx += 1
                
                # Limit to first 1000 records for testing
                if idx >= 1000:
                    break
        
        # Report findings
        logger.info(f"\nFound {len(db2_records)} DB2 records:")
        for record_type in sorted(record_types_found.keys()):
            count = record_types_found[record_type]
            versions = version_distribution[record_type]
            logger.info(f"  Type {record_type}: {count} records")
            for version, v_count in sorted(versions.items()):
                logger.info(f"    {version}: {v_count} records")
        
        if not db2_records:
            pytest.skip(
                "No DB2 records found in test file. "
                "The file contains Type 100/101/102 records from a different subsystem "
                "(subsystem IDs: LY62, LY63, PDLY, etc.), not DB2. "
                "DB2 records would have subsystem IDs like 'DB2P', 'DSN1', etc."
            )
        
        # Step 2: Parse all records
        logger.info(f"\nStep 2: Parsing {len(db2_records)} DB2 records...")
        
        parsed_by_type = {100: [], 101: [], 102: []}
        parse_errors = []
        
        for record_info in db2_records:
            record_type = record_info['type']
            version = record_info['version']
            record_data = record_info['data']
            
            try:
                # Create parser
                smf_parser = SMFParserFactory.create_parser(
                    record_type,
                    record_data=record_data,
                    allow_fallback=True
                )
                
                # Parse record
                result = smf_parser.parse(record_data, version)
                parsed_by_type[record_type].append(result.to_dict())
                
            except Exception as e:
                parse_errors.append({
                    'index': record_info['index'],
                    'type': record_type,
                    'version': version,
                    'error': str(e)
                })
                logger.warning(f"  Failed to parse record {record_info['index']} (Type {record_type} {version}): {e}")
        
        # Report parsing results
        logger.info(f"\nParsing results:")
        for record_type in sorted(parsed_by_type.keys()):
            count = len(parsed_by_type[record_type])
            if count > 0:
                logger.info(f"  Type {record_type}: {count} successfully parsed")
        
        if parse_errors:
            logger.warning(f"  Parse errors: {len(parse_errors)}")
            # Save error details
            error_file = os.path.join(self.TEMP_DIR, 'parse_errors.json')
            with open(error_file, 'w') as f:
                json.dump(parse_errors, f, indent=2)
            logger.info(f"  Error details saved to: {error_file}")
        
        # Verify we have some successfully parsed records
        total_parsed = sum(len(records) for records in parsed_by_type.values())
        assert total_parsed > 0, "No records were successfully parsed"
        
        # Step 3: Save parsed records to JSON files
        logger.info(f"\nStep 3: Saving parsed records to ./temp/...")
        
        json_files = {}
        for record_type, records in parsed_by_type.items():
            if not records:
                continue
            
            json_file = os.path.join(self.TEMP_DIR, f'parsed_type_{record_type}.json')
            with open(json_file, 'w') as f:
                json.dump(records, f, indent=2)
            
            json_files[record_type] = json_file
            logger.info(f"  Type {record_type}: {len(records)} records saved to {json_file}")
        
        # Step 4: Load records into database
        logger.info(f"\nStep 4: Loading records into database: {temp_db}")
        
        db_stats = {}
        
        for record_type, json_file in json_files.items():
            logger.info(f"  Loading Type {record_type} records...")
            
            # Create database adapter
            db = SQLiteAdapter(temp_db)
            
            # Create appropriate schema
            if record_type == 100:
                schema = SMF100Schema()
            elif record_type == 101:
                schema = SMF101Schema()
            else:  # 102
                schema = SMF102Schema()
            
            # Create loader
            loader = SMFLoader(db, schema)
            
            # Create schema and load data
            loader.create_schema()
            loader.load_json_file(json_file)
            
            # Get statistics
            stats = loader.get_stats()
            db_stats[record_type] = stats
            
            logger.info(f"    Database statistics for Type {record_type}:")
            for table_name, count in stats.items():
                logger.info(f"      {table_name}: {count} rows")
            
            loader.close()
        
        # Step 5: Verify database contents
        logger.info(f"\nStep 5: Verifying database contents...")
        
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        # Verify smf_records table
        cursor.execute("SELECT COUNT(*) FROM smf_records")
        total_records = cursor.fetchone()[0]
        logger.info(f"  Total records in smf_records table: {total_records}")
        assert total_records > 0, "No records in smf_records table"
        
        # Verify records by type
        for record_type in [100, 101, 102]:
            cursor.execute("SELECT COUNT(*) FROM smf_records WHERE record_type = ?", (record_type,))
            count = cursor.fetchone()[0]
            if count > 0:
                logger.info(f"  Type {record_type} records: {count}")
                
                # Verify version distribution
                cursor.execute(
                    "SELECT db2_version, COUNT(*) FROM smf_records WHERE record_type = ? GROUP BY db2_version",
                    (record_type,)
                )
                for version, v_count in cursor.fetchall():
                    logger.info(f"    {version}: {v_count} records")
        
        # Verify type-specific tables
        for record_type in [100, 101, 102]:
            if record_type == 100:
                table_name = 'smf100_statistics'
            elif record_type == 101:
                table_name = 'smf101_accounting'
            else:
                table_name = 'smf102_performance'
            
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            if count > 0:
                logger.info(f"  {table_name} table: {count} rows")
        
        conn.close()
        
        # Step 6: Generate summary report
        logger.info(f"\nStep 6: Generating summary report...")
        
        report_file = os.path.join(self.TEMP_DIR, 'integration_test_report.md')
        with open(report_file, 'w') as f:
            f.write("# DB2 Parser Integration Test Report\n\n")
            f.write(f"**Test Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"**Test File:** {self.TEST_FILE}\n\n")
            f.write(f"**Database:** {temp_db}\n\n")
            
            f.write("## Summary\n\n")
            f.write(f"- Total DB2 records found: {len(db2_records)}\n")
            f.write(f"- Successfully parsed: {total_parsed}\n")
            f.write(f"- Parse errors: {len(parse_errors)}\n")
            f.write(f"- Records loaded to database: {total_records}\n\n")
            
            f.write("## Record Type Distribution\n\n")
            for record_type in sorted(record_types_found.keys()):
                f.write(f"### Type {record_type}\n\n")
                f.write(f"- Total found: {record_types_found[record_type]}\n")
                f.write(f"- Successfully parsed: {len(parsed_by_type[record_type])}\n")
                f.write(f"- Version distribution:\n")
                for version, count in sorted(version_distribution[record_type].items()):
                    f.write(f"  - {version}: {count} records\n")
                f.write("\n")
            
            f.write("## Database Statistics\n\n")
            for record_type, stats in db_stats.items():
                f.write(f"### Type {record_type}\n\n")
                for table_name, count in stats.items():
                    f.write(f"- {table_name}: {count} rows\n")
                f.write("\n")
            
            if parse_errors:
                f.write("## Parse Errors\n\n")
                f.write(f"See `parse_errors.json` for details.\n\n")
            
            f.write("## Output Files\n\n")
            for record_type, json_file in json_files.items():
                f.write(f"- Type {record_type}: `{json_file}`\n")
            f.write(f"- Database: `{temp_db}`\n")
            f.write(f"- Report: `{report_file}`\n")
        
        logger.info(f"  Report saved to: {report_file}")
        
        logger.info(f"\n{'='*80}")
        logger.info("FULL INTEGRATION TEST COMPLETED SUCCESSFULLY")
        logger.info(f"{'='*80}\n")
    
    def test_fallback_parser_behavior(self, caplog):
        """
        Test fallback parser behavior with various version scenarios.
        
        This test verifies:
        1. Warning logs for unsupported versions
        2. Fallback to nearest available parser
        3. Logging of fallback parser usage
        4. Error when no fallback available
        5. Configuration option to disable fallback
        6. Warning messages with version details
        
        Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 11.6
        """
        logger.info(f"\n{'='*80}")
        logger.info("FALLBACK PARSER BEHAVIOR TEST")
        logger.info(f"{'='*80}\n")
        
        # Create a minimal valid SMF record structure for testing
        def create_test_record(record_type, db2_version_code):
            """Create a minimal test record with specified DB2 version."""
            # SMF header (24 bytes) + product section triplet (8 bytes) = 32 bytes
            header = bytearray(36)  # Extra space for safety
            header[0:2] = (120).to_bytes(2, 'big')  # Record length (total)
            header[5] = record_type  # Record type
            
            # Product section triplet at offset 28 (offset, length, count)
            # Offset points to where QWHS starts (after this header)
            header[28:32] = (36).to_bytes(4, 'big')  # Offset to product section (after header)
            header[32:34] = (92).to_bytes(2, 'big')  # Length of product section
            header[34:36] = (1).to_bytes(2, 'big')  # Count = 1
            
            # QWHS header (92 bytes minimum)
            qwhs = bytearray(92)
            qwhs[0:2] = (92).to_bytes(2, 'big')  # Header length
            qwhs[2] = 1  # Header type
            qwhs[3] = 0xDB  # Resource manager ID (DB2)
            qwhs[6:8] = db2_version_code.to_bytes(2, 'big')  # Release number (QWHSRELN)
            
            return bytes(header + qwhs)
        
        # Test 1: Unsupported version with fallback enabled (should use fallback)
        logger.info("Test 1: Unsupported version with fallback enabled")
        
        with caplog.at_level(logging.WARNING):
            # Create record with V11 (0x0B00) - Type 100 only has V10 parser, should fallback
            record_data = create_test_record(100, 0x0B00)
            
            try:
                parser = SMFParserFactory.create_parser(
                    100,
                    record_data=record_data,
                    allow_fallback=True
                )
                logger.info("  ✓ Parser created successfully with fallback")
                
                # Check for warning log
                warning_found = any(
                    "No exact parser" in record.message and "fallback" in record.message.lower()
                    for record in caplog.records
                )
                
                if warning_found:
                    logger.info("  ✓ Warning logged for fallback usage")
                else:
                    logger.warning("  ⚠ Expected warning log not found")
                
            except Exception as e:
                pytest.fail(f"Should not raise error with fallback enabled: {e}")
        
        caplog.clear()
        
        # Test 2: Unsupported version with fallback disabled (should raise error)
        logger.info("\nTest 2: Unsupported version with fallback disabled")
        
        with caplog.at_level(logging.WARNING):
            # Create record with V11 (0x0B00) - Type 100 only has V10 parser
            record_data = create_test_record(100, 0x0B00)
            
            with pytest.raises(UnsupportedVersionError) as exc_info:
                parser = SMFParserFactory.create_parser(
                    100,
                    record_data=record_data,
                    allow_fallback=False
                )
            
            error_msg = str(exc_info.value)
            logger.info(f"  ✓ Raised UnsupportedVersionError as expected")
            logger.info(f"  Error message: {error_msg}")
            
            # Verify error message contains required details
            assert "No exact parser" in error_msg or "not supported" in error_msg.lower()
            assert "V10" in error_msg or "0x0a01" in error_msg.lower()
            logger.info("  ✓ Error message contains version details")
        
        caplog.clear()
        
        # Test 3: Completely unsupported record type (should raise error even with fallback)
        logger.info("\nTest 3: Completely unsupported record type")
        
        # Create record with V99 (0x6300) - no parsers available
        record_data = create_test_record(100, 0x6300)
        
        with pytest.raises(UnsupportedVersionError) as exc_info:
            parser = SMFParserFactory.create_parser(
                100,
                record_data=record_data,
                allow_fallback=True
            )
        
        error_msg = str(exc_info.value)
        logger.info(f"  ✓ Raised UnsupportedVersionError for completely unsupported version")
        logger.info(f"  Error message: {error_msg}")
        
        # Verify error message mentions available versions
        assert "available" in error_msg.lower() or "supported" in error_msg.lower()
        logger.info("  ✓ Error message mentions available versions")
        
        caplog.clear()
        
        # Test 4: Supported version (should work without warnings)
        logger.info("\nTest 4: Supported version (no fallback needed)")
        
        with caplog.at_level(logging.WARNING):
            # Create record with V10 (0x0A00) - explicitly supported
            record_data = create_test_record(100, 0x0A00)
            
            try:
                parser = SMFParserFactory.create_parser(
                    100,
                    record_data=record_data,
                    allow_fallback=True
                )
                logger.info("  ✓ Parser created successfully")
                
                # Check that no fallback warning was logged
                fallback_warnings = [
                    record for record in caplog.records
                    if "fallback" in record.message.lower()
                ]
                
                if not fallback_warnings:
                    logger.info("  ✓ No fallback warnings (as expected)")
                else:
                    logger.warning(f"  ⚠ Unexpected fallback warning: {fallback_warnings[0].message}")
                
            except Exception as e:
                pytest.fail(f"Should not raise error for supported version: {e}")
        
        logger.info(f"\n{'='*80}")
        logger.info("FALLBACK PARSER BEHAVIOR TEST COMPLETED")
        logger.info(f"{'='*80}\n")


if __name__ == '__main__':
    pytest.main([__file__, '-v', '-s'])
