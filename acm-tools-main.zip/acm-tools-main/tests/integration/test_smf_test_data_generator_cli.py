"""
Integration tests for SMF Test Data Generator CLI.

Tests the complete workflow from configuration loading through record generation
and output file writing.
"""

import json
import pytest
import subprocess
import sys
from pathlib import Path
import tempfile
import shutil


@pytest.fixture
def test_config_file(tmp_path):
    """Create a test configuration file."""
    config_content = """
inventory_db: ./results/carddemo_analysis/carddemo.db
output_directory: {output_dir}
application_name: test_app
time_range:
  start_date: 2023-01-01
  end_date: 2023-01-07

active_artifacts:
  programs:
    - name: CBACT01C
      frequency: high
  
  jcl:
    - name: DALYREJS
      frequency: medium
  
  cics_transactions:
    - name: CAUP
      frequency: high

unreferenced_artifacts:
  programs: []
  jcl: []
  datasets: []

missing_artifacts:
  programs:
    - MISSING01
  datasets:
    - AWS.M2.MISSING.DATA.KSDS
"""
    config_file = tmp_path / "test_config.yaml"
    config_file.write_text(config_content.format(output_dir=str(tmp_path / "output")))
    return config_file


def test_cli_help():
    """Test that CLI help works."""
    result = subprocess.run(
        [sys.executable, "-m", "tools.smf_test_data_generator", "--help"],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    assert "Generate SMF test data" in result.stdout
    assert "--config" in result.stdout
    assert "--verbose" in result.stdout


def test_cli_version():
    """Test that CLI version works."""
    result = subprocess.run(
        [sys.executable, "-m", "tools.smf_test_data_generator", "--version"],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    assert "0.1.0" in result.stdout


def test_cli_missing_config():
    """Test that CLI reports error for missing config file."""
    result = subprocess.run(
        [sys.executable, "-m", "tools.smf_test_data_generator", 
         "--config", "nonexistent.yaml"],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 1
    assert "Configuration file not found" in result.stderr


def test_cli_complete_workflow(test_config_file, tmp_path):
    """Test complete workflow from config to output files."""
    # Skip if database doesn't exist
    db_path = Path("./results/carddemo_analysis/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    
    output_dir = tmp_path / "output"
    
    # Run the generator
    result = subprocess.run(
        [sys.executable, "-m", "tools.smf_test_data_generator",
         "--config", str(test_config_file),
         "--verbose"],
        capture_output=True,
        text=True
    )
    
    # Check exit code
    assert result.returncode == 0, f"Generator failed: {result.stderr}"
    
    # Check output messages
    assert "Configuration loaded successfully" in result.stdout
    assert "Database validated successfully" in result.stdout
    assert "Artifact catalog built successfully" in result.stdout
    assert "Generated" in result.stdout
    assert "Type 30" in result.stdout
    assert "Type 110" in result.stdout
    
    # Check output files exist
    type30_file = output_dir / "smf30_test_app.json"
    type110_file = output_dir / "smf110_test_app.json"
    
    assert type30_file.exists(), "Type 30 output file not created"
    assert type110_file.exists(), "Type 110 output file not created"
    
    # Validate JSON structure
    with open(type30_file) as f:
        type30_records = json.load(f)
    
    assert isinstance(type30_records, list)
    assert len(type30_records) > 0
    
    # Check Type 30 record structure
    sample_record = type30_records[0]
    assert sample_record['record_type'] == 30
    assert 'identification' in sample_record
    assert 'processor' in sample_record
    assert 'io_activity' in sample_record
    
    with open(type110_file) as f:
        type110_records = json.load(f)
    
    assert isinstance(type110_records, list)
    assert len(type110_records) > 0
    
    # Check Type 110 record structure
    sample_record = type110_records[0]
    assert sample_record['record_type'] == 110
    assert 'subsystem' in sample_record
    assert 'identification' in sample_record


def test_cli_invalid_yaml(tmp_path):
    """Test that CLI reports error for invalid YAML."""
    invalid_config = tmp_path / "invalid.yaml"
    invalid_config.write_text("invalid: yaml: content:\n  - bad\n    - structure")
    
    result = subprocess.run(
        [sys.executable, "-m", "tools.smf_test_data_generator",
         "--config", str(invalid_config)],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 1
    assert "Failed to load configuration" in result.stderr
    assert "Invalid YAML" in result.stderr


def test_cli_without_verbose(test_config_file):
    """Test that CLI works without verbose flag."""
    # Skip if database doesn't exist
    db_path = Path("./results/carddemo_analysis/carddemo.db")
    if not db_path.exists():
        pytest.skip("CardDemo database not available")
    
    result = subprocess.run(
        [sys.executable, "-m", "tools.smf_test_data_generator",
         "--config", str(test_config_file)],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    # Should have summary but not verbose progress messages
    assert "SMF Test Data Generation Complete" in result.stdout
    assert "✓" not in result.stdout  # No checkmarks without verbose
