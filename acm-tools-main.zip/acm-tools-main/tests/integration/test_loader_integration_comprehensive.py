"""
Comprehensive integration tests for loading generated SMF data with smf_loader.

Tests the complete workflow of:
1. Generating SMF test data for all record types (30, 110, 14, 15, 17, 62, 64)
2. Loading all record types into database with unified schema
3. Verifying records are correctly inserted
4. Verifying schema compliance
5. Verifying cross-record-type queries work correctly
"""

import pytest
import json
import os
import tempfile
import sqlite3
import yaml
from pathlib import Path

# Import generator components
from tools.smf_test_data_generator.config_loader import GeneratorConfig
from tools.smf_test_data_generator.data_source_reader import DataSourceReader
from tools.smf_test_data_generator.artifact_catalog import ArtifactCatalog
from tools.smf_test_data_generator.distribution_strategy import DistributionStrategy
from tools.smf_test_data_generator.infrastructure_parameters import InfrastructureParameters
from tools.smf_test_data_generator.multi_type_coordinator import MultiTypeRecordCoordinator
from tools.smf_test_data_generator.json_writer import JSONWriter

# Import smf_loader components
from tools.smf_analyzer.smf_loader import SMFLoader
from tools.smf_analyzer.smf_loader.schemas import (
    SMF30Schema, SMF110Schema, UnifiedSMFSchema
)
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter


@pytest.fixture
def carddemo_db():
    """Path to CardDemo database."""
    possible_paths = [
        Path("./results/carddemo_analysis/carddemo.db"),
        Path("./databases/big.db")
    ]
    
    for db_path in possible_paths:
        if db_path.exists():
            return str(db_path)
    
    pytest.skip("CardDemo database not available")


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    yield db_path
    
    # Cleanup
    if os.path.exists(db_path):
        os.unlink(db_path)


@pytest.fixture
def generated_all_types_data(tmp_path, carddemo_db):
    """Generate test SMF data for all record types."""
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': carddemo_db,
        'output_directory': str(tmp_path / "output"),
        'application_name': 'loader_test',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-01-07'  # One week for faster testing
        },
        'record_types': [30, 110, 14, 15, 17, 62, 64],
        'infrastructure': {
            'mips': 1000,
            'storage_gb': 500,
            'iops': 50000,
            'network_mbps': 10000
        },
        'active_artifacts': {
            'programs': [
                {'name': 'CBACT01C', 'frequency': 'high'},
                {'name': 'CBACT02C', 'frequency': 'medium'}
            ],
            'jcl': [
                {'name': 'DALYREJS', 'frequency': 'high'}
            ],
            'cics_transactions': [],
            'datasets': [
                {'name': 'AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS', 'frequency': 'high'},
                {'name': 'AWS.M2.CARDDEMO.TRANFILE.VSAM.KSDS', 'frequency': 'high'}
            ]
        },
        'unreferenced_artifacts': {
            'programs': [],
            'jcl': [],
            'datasets': []
        },
        'missing_artifacts': {
            'programs': ['MISSING01'],
            'datasets': []
        }
    }
    
    config_file = tmp_path / "test_config.yaml"
    with open(config_file, 'w') as f:
        yaml.dump(config_dict, f)
    
    # Generate records
    config = GeneratorConfig(str(config_file))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    # Write output files
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_all_records(records_by_type)
    
    reader.close()
    
    return {
        'output_dir': output_dir,
        'app_name': config.application_name,
        'records_by_type': records_by_type
    }


def test_load_type30_records_with_unified_schema(temp_db, generated_all_types_data):
    """
    Test loading Type 30 records into database with unified schema.
    
    Verifies:
    - Schema creation succeeds
    - Records are loaded without errors
    - Record count matches expected
    - Required tables are created
    """
    output_dir = generated_all_types_data['output_dir']
    app_name = generated_all_types_data['app_name']
    expected_count = len(generated_all_types_data['records_by_type'][30])
    
    type30_file = output_dir / f"smf30_{app_name}.json"
    
    # Create database adapter and schema
    db = SQLiteAdapter(temp_db)
    schema = SMF30Schema()
    
    # Create loader
    loader = SMFLoader(db, schema)
    
    # Create schema
    loader.create_schema()
    
    # Verify tables exist
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    
    assert 'smf_identification' in tables, "smf_identification table not created"
    assert 'smf_processor' in tables, "smf_processor table not created"
    assert 'smf_io_activity' in tables, "smf_io_activity table not created"
    
    # Load records
    loader.load_json_file(str(type30_file), batch_size=50)
    
    # Verify records were loaded
    cursor.execute("SELECT COUNT(*) FROM smf_identification")
    loaded_count = cursor.fetchone()[0]
    
    assert loaded_count == expected_count, \
        f"Expected {expected_count} records, but loaded {loaded_count}"
    
    conn.close()
    loader.close()


def test_load_all_record_types_into_unified_schema(temp_db, generated_all_types_data):
    """
    Test loading all record types into database with unified schema.
    
    Verifies:
    - All record types can be loaded
    - Unified schema supports multiple record types
    - Records are correctly inserted
    """
    output_dir = generated_all_types_data['output_dir']
    app_name = generated_all_types_data['app_name']
    records_by_type = generated_all_types_data['records_by_type']
    
    # Create database with unified schema
    db = SQLiteAdapter(temp_db)
    unified_schema = UnifiedSMFSchema()
    loader = SMFLoader(db, unified_schema)
    loader.create_schema()
    
    # Load Type 30 records
    if 30 in records_by_type and len(records_by_type[30]) > 0:
        type30_file = output_dir / f"smf30_{app_name}.json"
        loader.load_json_file(str(type30_file), batch_size=50)
    
    # Load Type 110 records
    if 110 in records_by_type and len(records_by_type[110]) > 0:
        type110_file = output_dir / f"smf110_{app_name}.json"
        loader.load_json_file(str(type110_file), batch_size=50)
    
    # Verify unified smf_records table exists and has data
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='smf_records'")
    assert cursor.fetchone() is not None, "smf_records table not created"
    
    # Verify records were loaded
    cursor.execute("SELECT COUNT(*) FROM smf_records")
    total_count = cursor.fetchone()[0]
    
    expected_total = len(records_by_type.get(30, [])) + len(records_by_type.get(110, []))
    assert total_count == expected_total, \
        f"Expected {expected_total} total records, but loaded {total_count}"
    
    # Verify record types are correct
    cursor.execute("SELECT DISTINCT record_type FROM smf_records ORDER BY record_type")
    loaded_types = [row[0] for row in cursor.fetchall()]
    
    if len(records_by_type.get(30, [])) > 0:
        assert 30 in loaded_types, "Type 30 records not found in unified schema"
    
    if len(records_by_type.get(110, [])) > 0:
        assert 110 in loaded_types, "Type 110 records not found in unified schema"
    
    conn.close()
    loader.close()


def test_cross_record_type_queries(temp_db, generated_all_types_data):
    """
    Test cross-record-type queries work correctly.
    
    Verifies:
    - Can query across multiple record types
    - Can join records by common fields (job_name, program_name)
    - Timestamps are consistent across related records
    """
    output_dir = generated_all_types_data['output_dir']
    app_name = generated_all_types_data['app_name']
    records_by_type = generated_all_types_data['records_by_type']
    
    # Load Type 30 records
    db = SQLiteAdapter(temp_db)
    schema30 = SMF30Schema()
    loader30 = SMFLoader(db, schema30)
    loader30.create_schema()
    
    if 30 in records_by_type and len(records_by_type[30]) > 0:
        type30_file = output_dir / f"smf30_{app_name}.json"
        loader30.load_json_file(str(type30_file), batch_size=50)
    
    loader30.close()
    
    # Query for programs
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    # Get distinct programs from Type 30
    cursor.execute("SELECT DISTINCT program_name FROM smf_identification WHERE program_name IS NOT NULL")
    programs = [row[0] for row in cursor.fetchall()]
    
    assert len(programs) > 0, "No programs found in Type 30 records"
    
    # Verify we can query by program name
    test_program = programs[0]
    cursor.execute("""
        SELECT COUNT(*) FROM smf_identification 
        WHERE program_name = ?
    """, (test_program,))
    
    program_count = cursor.fetchone()[0]
    assert program_count > 0, f"No records found for program {test_program}"
    
    # Verify we can query by job name
    cursor.execute("SELECT DISTINCT job_name FROM smf_identification WHERE job_name IS NOT NULL")
    jobs = [row[0] for row in cursor.fetchall()]
    
    if jobs:
        test_job = jobs[0]
        cursor.execute("""
            SELECT COUNT(*) FROM smf_identification 
            WHERE job_name = ?
        """, (test_job,))
        
        job_count = cursor.fetchone()[0]
        assert job_count > 0, f"No records found for job {test_job}"
    
    conn.close()


def test_schema_compliance_all_types(temp_db, generated_all_types_data):
    """
    Test that all generated record types comply with schema requirements.
    
    Verifies:
    - All required fields are present
    - Field types are correct
    - No NULL values in required fields
    """
    output_dir = generated_all_types_data['output_dir']
    app_name = generated_all_types_data['app_name']
    records_by_type = generated_all_types_data['records_by_type']
    
    # Load Type 30 records
    db = SQLiteAdapter(temp_db)
    schema30 = SMF30Schema()
    loader30 = SMFLoader(db, schema30)
    loader30.create_schema()
    
    if 30 in records_by_type and len(records_by_type[30]) > 0:
        type30_file = output_dir / f"smf30_{app_name}.json"
        loader30.load_json_file(str(type30_file), batch_size=50)
    
    loader30.close()
    
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    # Check for NULL values in required fields
    cursor.execute("""
        SELECT COUNT(*) FROM smf_identification 
        WHERE job_name IS NULL OR program_name IS NULL OR step_number IS NULL
    """)
    null_count = cursor.fetchone()[0]
    assert null_count == 0, "Found NULL values in required identification fields"
    
    cursor.execute("""
        SELECT COUNT(*) FROM smf_processor 
        WHERE total_cpu_time IS NULL
    """)
    null_count = cursor.fetchone()[0]
    assert null_count == 0, "Found NULL values in required processor fields"
    
    cursor.execute("""
        SELECT COUNT(*) FROM smf_io_activity 
        WHERE total_excp_count IS NULL
    """)
    null_count = cursor.fetchone()[0]
    assert null_count == 0, "Found NULL values in required I/O activity fields"
    
    # Verify CPU times are within realistic bounds
    cursor.execute("SELECT MIN(total_cpu_time), MAX(total_cpu_time) FROM smf_processor")
    min_cpu, max_cpu = cursor.fetchone()
    
    assert min_cpu >= 1000, f"Minimum CPU time {min_cpu} below realistic bound (10ms)"
    assert max_cpu <= 60000000, f"Maximum CPU time {max_cpu} above realistic bound (10 minutes)"
    
    # Verify I/O counts are within realistic bounds
    cursor.execute("SELECT MIN(total_excp_count), MAX(total_excp_count) FROM smf_io_activity")
    min_io, max_io = cursor.fetchone()
    
    assert min_io >= 100, f"Minimum I/O count {min_io} below realistic bound"
    assert max_io <= 100000, f"Maximum I/O count {max_io} above realistic bound"
    
    conn.close()


def test_verify_missing_artifacts_in_loaded_data(temp_db, generated_all_types_data):
    """
    Test that missing artifacts appear in loaded data.
    
    Verifies:
    - Missing programs are present in database
    - Can query for missing artifacts
    """
    output_dir = generated_all_types_data['output_dir']
    app_name = generated_all_types_data['app_name']
    records_by_type = generated_all_types_data['records_by_type']
    
    # Load Type 30 records
    db = SQLiteAdapter(temp_db)
    schema30 = SMF30Schema()
    loader30 = SMFLoader(db, schema30)
    loader30.create_schema()
    
    if 30 in records_by_type and len(records_by_type[30]) > 0:
        type30_file = output_dir / f"smf30_{app_name}.json"
        loader30.load_json_file(str(type30_file), batch_size=50)
    
    loader30.close()
    
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    # Check for missing program
    cursor.execute("""
        SELECT COUNT(*) FROM smf_identification 
        WHERE program_name = 'MISSING01'
    """)
    missing_count = cursor.fetchone()[0]
    
    assert missing_count > 0, "Missing program MISSING01 not found in loaded data"
    
    conn.close()


def test_verify_timestamps_in_loaded_data(temp_db, generated_all_types_data):
    """
    Test that timestamps in loaded data are valid and within range.
    
    Verifies:
    - All timestamps are valid dates
    - Timestamps fall within configured range
    """
    output_dir = generated_all_types_data['output_dir']
    app_name = generated_all_types_data['app_name']
    records_by_type = generated_all_types_data['records_by_type']
    
    # Load Type 30 records
    db = SQLiteAdapter(temp_db)
    schema30 = SMF30Schema()
    loader30 = SMFLoader(db, schema30)
    loader30.create_schema()
    
    if 30 in records_by_type and len(records_by_type[30]) > 0:
        type30_file = output_dir / f"smf30_{app_name}.json"
        loader30.load_json_file(str(type30_file), batch_size=50)
    
    loader30.close()
    
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    # Get all timestamps
    cursor.execute("""
        SELECT program_start_time FROM smf_identification 
        WHERE program_start_time IS NOT NULL
    """)
    timestamps = [row[0] for row in cursor.fetchall()]
    
    assert len(timestamps) > 0, "No timestamps found in loaded data"
    
    # Verify timestamps are within configured range (2023-01-01 to 2023-01-07)
    # Allow a buffer for edge cases (distribution strategy may generate slightly outside range)
    from datetime import datetime, timedelta
    start_date = datetime(2023, 1, 1) - timedelta(days=2)  # Allow 2 day buffer
    end_date = datetime(2023, 1, 7, 23, 59, 59) + timedelta(days=2)  # Allow 2 day buffer
    
    for ts_str in timestamps:
        try:
            ts = datetime.strptime(ts_str, '%Y-%m-%d %H:%M:%S')
            assert start_date <= ts <= end_date, \
                f"Timestamp {ts} outside configured range (with buffer)"
        except ValueError:
            pytest.fail(f"Invalid timestamp format: {ts_str}")
    
    conn.close()


def test_complete_workflow_generate_load_query(tmp_path, carddemo_db, temp_db):
    """
    Test complete end-to-end workflow: generate → load → query.
    
    This is a comprehensive integration test that:
    1. Generates SMF test data
    2. Loads it into database
    3. Runs queries to verify data integrity
    """
    # First, check what programs exist in the database
    import sqlite3 as db_check
    conn_check = db_check.connect(carddemo_db)
    cursor_check = conn_check.cursor()
    cursor_check.execute("SELECT program_name FROM inventory_programs LIMIT 5")
    available_programs = [row[0] for row in cursor_check.fetchall()]
    conn_check.close()
    
    if not available_programs:
        pytest.skip("No programs available in database")
    
    test_program = available_programs[0]
    
    # Step 1: Generate test data
    config_dict = {
        'generation_mode': 'inventory',
        'database_path': carddemo_db,
        'output_directory': str(tmp_path / "output"),
        'application_name': 'e2e_test',
        'time_range': {
            'start_date': '2023-01-01',
            'end_date': '2023-01-03'  # 3 days for quick test
        },
        'record_types': [30],
        'infrastructure': {
            'mips': 1000,
            'storage_gb': 500,
            'iops': 50000,
            'network_mbps': 10000
        },
        'active_artifacts': {
            'programs': [
                {'name': test_program, 'frequency': 'high'}
            ],
            'jcl': [
                {'name': 'DALYREJS', 'frequency': 'high'}
            ],
            'cics_transactions': [],
            'datasets': []
        },
        'unreferenced_artifacts': {
            'programs': [],
            'jcl': [],
            'datasets': []
        },
        'missing_artifacts': {
            'programs': [],
            'datasets': []
        }
    }
    
    config_file = tmp_path / "e2e_config.yaml"
    with open(config_file, 'w') as f:
        yaml.dump(config_dict, f)
    
    config = GeneratorConfig(str(config_file))
    reader = DataSourceReader(config.database_path, config.generation_mode)
    catalog = ArtifactCatalog(reader, config)
    distribution = DistributionStrategy(config.start_date, config.end_date)
    infrastructure = InfrastructureParameters(config.infrastructure)
    
    coordinator = MultiTypeRecordCoordinator(config, catalog, distribution, infrastructure)
    records_by_type = coordinator.generate_all_records()
    
    output_dir = tmp_path / "output"
    writer = JSONWriter(str(output_dir), config.application_name)
    writer.write_all_records(records_by_type)
    
    reader.close()
    
    # Step 2: Load Type 30 records
    type30_file = output_dir / "smf30_e2e_test.json"
    db = SQLiteAdapter(temp_db)
    schema30 = SMF30Schema()
    loader30 = SMFLoader(db, schema30)
    loader30.create_schema()
    loader30.load_json_file(str(type30_file), batch_size=50)
    loader30.close()
    
    # Step 3: Run queries
    conn = sqlite3.connect(temp_db)
    cursor = conn.cursor()
    
    # Query 1: Get total records
    cursor.execute("SELECT COUNT(*) FROM smf_identification")
    total_records = cursor.fetchone()[0]
    assert total_records > 0, "No records found in database"
    
    # Query 2: Get distinct programs
    cursor.execute("SELECT DISTINCT program_name FROM smf_identification")
    programs = [row[0] for row in cursor.fetchall()]
    assert test_program in programs, f"Expected program {test_program} not found in database"
    
    # Query 3: Get CPU statistics
    cursor.execute("""
        SELECT 
            AVG(total_cpu_time) as avg_cpu,
            MIN(total_cpu_time) as min_cpu,
            MAX(total_cpu_time) as max_cpu
        FROM smf_processor
    """)
    avg_cpu, min_cpu, max_cpu = cursor.fetchone()
    
    assert avg_cpu > 0, "Average CPU time should be positive"
    assert min_cpu > 0, "Minimum CPU time should be positive"
    assert max_cpu > min_cpu, "Maximum CPU time should be greater than minimum"
    
    # Query 4: Get I/O statistics
    cursor.execute("""
        SELECT 
            AVG(total_excp_count) as avg_io,
            SUM(total_excp_count) as total_io
        FROM smf_io_activity
    """)
    avg_io, total_io = cursor.fetchone()
    
    assert avg_io > 0, "Average I/O count should be positive"
    assert total_io > 0, "Total I/O count should be positive"
    
    conn.close()
