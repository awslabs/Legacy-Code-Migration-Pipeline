"""
Integration tests for Flow Analysis Enhancements.

Tests the complete flow export workflow with:
- Internal procedure filtering
- File metadata enrichment
- Configuration options
- Backward compatibility
"""

import pytest
import sqlite3
import json
import tempfile
import os
from tools.legacy_analyzer.migration import (
    MigrationFlowExporter,
    MigrationFlowSchema,
    FlowExportConfig
)


@pytest.fixture
def test_db_with_metadata():
    """Create test database with program_file_mapping table and test data."""
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create migration flow schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Create inventory_copybooks table
    cursor.execute("""
        CREATE TABLE inventory_copybooks (
            name TEXT PRIMARY KEY,
            file_path TEXT,
            language TEXT
        )
    """)
    
    # Create inventory table
    cursor.execute("""
        CREATE TABLE inventory (
            artifact_name TEXT,
            artifact_type TEXT,
            file_path TEXT,
            language TEXT,
            PRIMARY KEY (artifact_name, artifact_type)
        )
    """)
    
    # Insert programs with mixed types
    programs_data = [
        # Standalone programs (should be included)
        ('PAYROLL1', 'src/cobol/PAYROLL1.cbl', 1, 500, 'MAIN', 'COBOL'),
        ('PAYCALC', 'src/cobol/PAYCALC.cbl', 1, 300, 'SUBPROGRAM', 'COBOL'),
        ('PAYDB', 'src/cobol/PAYDB.cbl', 1, 200, 'ENTRY_POINT', 'COBOL'),
        ('DATEUTIL', 'src/cobol/DATEUTIL.cbl', 1, 150, 'ROUTINE', 'COBOL'),
        
        # Internal procedures (should be filtered out)
        ('CALC_TAX', 'src/cobol/PAYROLL1.cbl', 100, 150, 'PROCEDURE', 'COBOL'),
        ('VALIDATE_EMP', 'src/cobol/PAYROLL1.cbl', 200, 250, 'PROCEDURE', 'COBOL'),
        ('FORMAT_OUTPUT', 'src/cobol/PAYCALC.cbl', 150, 200, 'NESTED', 'COBOL'),
    ]
    
    cursor.executemany("""
        INSERT INTO program_file_mapping 
        (program_name, file_path, start_line, end_line, program_type, language)
        VALUES (?, ?, ?, ?, ?, ?)
    """, programs_data)
    
    # Insert copybooks with file paths
    copybooks_data = [
        ('PAYCOM', 'src/copybooks/PAYCOM.cpy', 'COBOL'),
        ('EMPDATA', 'src/copybooks/EMPDATA.cpy', 'COBOL'),
    ]
    
    cursor.executemany("""
        INSERT INTO inventory_copybooks (name, file_path, language)
        VALUES (?, ?, ?)
    """, copybooks_data)
    
    # Insert inventory entries for copybooks
    inventory_data = [
        ('PAYCOM', 'COPYBOOK', 'src/copybooks/PAYCOM.cpy', 'COBOL'),
        ('EMPDATA', 'COPYBOOK', 'src/copybooks/EMPDATA.cpy', 'COBOL'),
    ]
    
    cursor.executemany("""
        INSERT INTO inventory (artifact_name, artifact_type, file_path, language)
        VALUES (?, ?, ?, ?)
    """, inventory_data)
    
    # Insert test flow
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        'FLOW_PAYROLL1', 'Payroll Processing', 'PAYROLL1', 'JCL',
        7, 2, 2,  # 7 programs including internal procedures
        2500, 45, 67.5, 'MEDIUM',
        '2024-01-01', '2024-01-01'
    ))
    
    # Insert entry types
    cursor.execute("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, ('FLOW_PAYROLL1', 'JCL', 'PAYROLL01', json.dumps({'jclName': 'PAYROLL01'})))
    
    # Insert scope - includes both standalone and internal procedures
    scope_data = [
        ('FLOW_PAYROLL1', 'PROGRAM', 'PAYROLL1'),
        ('FLOW_PAYROLL1', 'PROGRAM', 'PAYCALC'),
        ('FLOW_PAYROLL1', 'PROGRAM', 'PAYDB'),
        ('FLOW_PAYROLL1', 'PROGRAM', 'DATEUTIL'),
        ('FLOW_PAYROLL1', 'PROGRAM', 'CALC_TAX'),  # Internal procedure
        ('FLOW_PAYROLL1', 'PROGRAM', 'VALIDATE_EMP'),  # Internal procedure
        ('FLOW_PAYROLL1', 'PROGRAM', 'FORMAT_OUTPUT'),  # Internal procedure
        ('FLOW_PAYROLL1', 'COPYBOOK', 'PAYCOM'),
        ('FLOW_PAYROLL1', 'COPYBOOK', 'EMPDATA'),
        ('FLOW_PAYROLL1', 'DATASET', 'EMPLOYEE.MASTER'),
        ('FLOW_PAYROLL1', 'DATASET', 'PAYROLL.TRANS'),
    ]
    
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, scope_data)
    
    conn.commit()
    
    yield conn
    
    conn.close()


class TestEndToEndExport:
    """Test end-to-end flow export with filtering and metadata."""
    
    def test_export_with_filtering_enabled(self, test_db_with_metadata):
        """
        Test complete export workflow with internal procedure filtering enabled.
        
        Validates:
        - Internal procedures are excluded from scope
        - Standalone programs are included
        - File metadata is present for programs
        - File metadata is present for copybooks
        """
        # Create exporter with filtering enabled (default)
        exporter = MigrationFlowExporter(
            test_db_with_metadata,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Export the flow
        result = exporter.export_flows(['FLOW_PAYROLL1'])
        
        # Verify export succeeded
        assert 'flows' in result
        assert len(result['flows']) == 1
        
        flow = result['flows'][0]
        assert flow['flowId'] == 'FLOW_PAYROLL1'
        
        # Verify internal procedures are excluded
        scope = flow['scope']
        program_names = [p['name'] for p in scope['programs']]
        
        # Should include standalone programs
        assert 'PAYROLL1' in program_names
        assert 'PAYCALC' in program_names
        assert 'PAYDB' in program_names
        assert 'DATEUTIL' in program_names
        
        # Should NOT include internal procedures
        assert 'CALC_TAX' not in program_names
        assert 'VALIDATE_EMP' not in program_names
        assert 'FORMAT_OUTPUT' not in program_names
        
        # Verify only 4 standalone programs are included
        assert len(scope['programs']) == 4
        
        # Verify file metadata is present for programs
        for program in scope['programs']:
            assert 'name' in program
            assert 'filePath' in program
            assert 'startLine' in program
            assert 'endLine' in program
            assert 'programType' in program
            assert 'language' in program
            
            # Verify metadata values are correct
            if program['name'] == 'PAYROLL1':
                assert program['filePath'] == 'src/cobol/PAYROLL1.cbl'
                assert program['startLine'] == 1
                assert program['endLine'] == 500
                assert program['programType'] == 'MAIN'
                assert program['language'] == 'COBOL'
        
        # Verify file metadata is present for copybooks
        copybook_names = [c['name'] for c in scope['copybooks']]
        assert 'PAYCOM' in copybook_names
        assert 'EMPDATA' in copybook_names
        
        for copybook in scope['copybooks']:
            assert 'name' in copybook
            assert 'filePath' in copybook
            
            # Verify copybook file paths
            if copybook['name'] == 'PAYCOM':
                assert copybook['filePath'] == 'src/copybooks/PAYCOM.cpy'
            elif copybook['name'] == 'EMPDATA':
                assert copybook['filePath'] == 'src/copybooks/EMPDATA.cpy'
    
    def test_export_with_filtering_disabled(self, test_db_with_metadata):
        """
        Test export with filtering disabled - should include all programs.
        
        Validates:
        - All programs are included (standalone + internal procedures)
        - File metadata is still present
        """
        # Create exporter with filtering disabled
        exporter = MigrationFlowExporter(
            test_db_with_metadata,
            filter_internal_procedures=False,
            include_file_metadata=True
        )
        
        # Export the flow
        result = exporter.export_flows(['FLOW_PAYROLL1'])
        
        flow = result['flows'][0]
        scope = flow['scope']
        program_names = [p['name'] for p in scope['programs']]
        
        # Should include ALL programs (standalone + internal)
        assert 'PAYROLL1' in program_names
        assert 'PAYCALC' in program_names
        assert 'PAYDB' in program_names
        assert 'DATEUTIL' in program_names
        assert 'CALC_TAX' in program_names
        assert 'VALIDATE_EMP' in program_names
        assert 'FORMAT_OUTPUT' in program_names
        
        # Should have all 7 programs
        assert len(scope['programs']) == 7
        
        # Verify file metadata is still present
        for program in scope['programs']:
            assert 'filePath' in program
            assert 'programType' in program
    
    def test_export_with_metadata_disabled(self, test_db_with_metadata):
        """
        Test export with metadata enrichment disabled.
        
        Validates:
        - Programs are still filtered correctly
        - File metadata fields are omitted
        """
        # Create exporter with metadata disabled
        exporter = MigrationFlowExporter(
            test_db_with_metadata,
            filter_internal_procedures=True,
            include_file_metadata=False
        )
        
        # Export the flow
        result = exporter.export_flows(['FLOW_PAYROLL1'])
        
        flow = result['flows'][0]
        scope = flow['scope']
        
        # Verify filtering still works
        program_names = [p['name'] for p in scope['programs']]
        assert len(scope['programs']) == 4
        assert 'CALC_TAX' not in program_names
        
        # Verify metadata fields are omitted
        for program in scope['programs']:
            assert 'name' in program
            assert 'filePath' not in program
            assert 'startLine' not in program
            assert 'endLine' not in program
            assert 'programType' not in program
            assert 'language' not in program
        
        # Verify copybook metadata is also omitted
        for copybook in scope['copybooks']:
            assert 'name' in copybook
            assert 'filePath' not in copybook
    
    def test_export_to_file(self, test_db_with_metadata):
        """Test exporting to JSON file."""
        exporter = MigrationFlowExporter(
            test_db_with_metadata,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_file = f.name
        
        try:
            # Export to file
            result = exporter.export_flows(['FLOW_PAYROLL1'], output_file=temp_file)
            
            # Verify file was created
            assert os.path.exists(temp_file)
            
            # Read and verify file content
            with open(temp_file, 'r') as f:
                file_data = json.load(f)
            
            # Verify content
            assert 'flows' in file_data
            assert len(file_data['flows']) == 1
            
            flow = file_data['flows'][0]
            program_names = [p['name'] for p in flow['scope']['programs']]
            
            # Verify filtering was applied
            assert len(program_names) == 4
            assert 'CALC_TAX' not in program_names
            
            # Verify metadata is present
            assert 'filePath' in flow['scope']['programs'][0]
            
        finally:
            # Clean up
            if os.path.exists(temp_file):
                os.remove(temp_file)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])



class TestBackwardCompatibility:
    """Test backward compatibility with databases lacking program_file_mapping table."""
    
    @pytest.fixture
    def test_db_without_metadata(self):
        """Create test database WITHOUT program_file_mapping table."""
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration flow schema only (no program_file_mapping)
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_LEGACY1', 'Legacy Flow', 'LEGACY1', 'JCL',
            3, 2, 1,
            1500, 30, 55.0, 'MEDIUM',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert entry types
        cursor.execute("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, ('FLOW_LEGACY1', 'JCL', 'LEGACY01', json.dumps({'jclName': 'LEGACY01'})))
        
        # Insert scope
        scope_data = [
            ('FLOW_LEGACY1', 'PROGRAM', 'LEGACY1'),
            ('FLOW_LEGACY1', 'PROGRAM', 'LEGACYSUB'),
            ('FLOW_LEGACY1', 'PROGRAM', 'LEGACYUTIL'),
            ('FLOW_LEGACY1', 'COPYBOOK', 'LEGACYCPY1'),
            ('FLOW_LEGACY1', 'COPYBOOK', 'LEGACYCPY2'),
            ('FLOW_LEGACY1', 'DATASET', 'LEGACY.DATA'),
        ]
        
        cursor.executemany("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, scope_data)
        
        conn.commit()
        
        yield conn
        
        conn.close()
    
    def test_export_without_metadata_table(self, test_db_without_metadata):
        """
        Test export succeeds when program_file_mapping table doesn't exist.
        
        Validates:
        - Export completes without errors
        - Programs are included (no filtering without metadata)
        - No file metadata fields are present
        - Current behavior is maintained
        """
        # Create exporter with default settings
        exporter = MigrationFlowExporter(
            test_db_without_metadata,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Export should succeed
        result = exporter.export_flows(['FLOW_LEGACY1'])
        
        # Verify export succeeded
        assert 'flows' in result
        assert len(result['flows']) == 1
        
        flow = result['flows'][0]
        assert flow['flowId'] == 'FLOW_LEGACY1'
        
        # Verify scope is present
        scope = flow['scope']
        assert 'programs' in scope
        assert 'copybooks' in scope
        assert 'datasets' in scope
        
        # All programs should be included (no filtering without metadata)
        program_names = [p['name'] for p in scope['programs']]
        assert 'LEGACY1' in program_names
        assert 'LEGACYSUB' in program_names
        assert 'LEGACYUTIL' in program_names
        assert len(scope['programs']) == 3
        
        # Programs should NOT have file metadata fields
        for program in scope['programs']:
            assert 'name' in program
            assert 'filePath' not in program
            assert 'startLine' not in program
            assert 'endLine' not in program
            assert 'programType' not in program
            assert 'language' not in program
        
        # Copybooks should be present
        copybook_names = [c['name'] for c in scope['copybooks']]
        assert 'LEGACYCPY1' in copybook_names
        assert 'LEGACYCPY2' in copybook_names
        
        # Copybooks should NOT have file metadata
        for copybook in scope['copybooks']:
            assert 'name' in copybook
            assert 'filePath' not in copybook
        
        # Datasets should be present
        assert 'LEGACY.DATA' in scope['datasets']
    
    def test_export_with_filtering_disabled_no_metadata(self, test_db_without_metadata):
        """
        Test export with filtering disabled when metadata table doesn't exist.
        
        Validates:
        - Export succeeds
        - All programs are included
        - No errors or exceptions
        """
        # Create exporter with filtering disabled
        exporter = MigrationFlowExporter(
            test_db_without_metadata,
            filter_internal_procedures=False,
            include_file_metadata=False
        )
        
        # Export should succeed
        result = exporter.export_flows(['FLOW_LEGACY1'])
        
        # Verify export succeeded
        assert 'flows' in result
        assert len(result['flows']) == 1
        
        flow = result['flows'][0]
        
        # All programs should be included
        program_names = [p['name'] for p in flow['scope']['programs']]
        assert len(program_names) == 3
        assert 'LEGACY1' in program_names
    
    def test_multiple_flows_without_metadata(self, test_db_without_metadata):
        """Test exporting multiple flows without metadata table."""
        # Add another flow
        cursor = test_db_without_metadata.cursor()
        
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_LEGACY2', 'Legacy Flow 2', 'LEGACY2', 'CICS_TRANSACTION',
            2, 1, 1,
            1000, 20, 45.0, 'LOW',
            '2024-01-01', '2024-01-01'
        ))
        
        cursor.execute("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, ('FLOW_LEGACY2', 'CICS_TRANSACTION', 'LEG2', json.dumps({'transactionId': 'LEG2'})))
        
        cursor.executemany("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, [
            ('FLOW_LEGACY2', 'PROGRAM', 'LEGACY2'),
            ('FLOW_LEGACY2', 'PROGRAM', 'LEGACY2SUB'),
            ('FLOW_LEGACY2', 'COPYBOOK', 'LEG2CPY'),
            ('FLOW_LEGACY2', 'DATASET', 'LEGACY2.DATA'),
        ])
        
        test_db_without_metadata.commit()
        
        # Export all flows
        exporter = MigrationFlowExporter(test_db_without_metadata)
        result = exporter.export_all_flows()
        
        # Verify both flows exported successfully
        assert 'flows' in result
        assert len(result['flows']) == 2
        
        flow_ids = [f['flowId'] for f in result['flows']]
        assert 'FLOW_LEGACY1' in flow_ids
        assert 'FLOW_LEGACY2' in flow_ids
        
        # Verify no metadata fields in any flow
        for flow in result['flows']:
            for program in flow['scope']['programs']:
                assert 'filePath' not in program



class TestConfigurationCombinations:
    """Test all combinations of configuration flags."""
    
    @pytest.fixture
    def test_db_full(self):
        """Create test database with complete metadata for configuration testing."""
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Create migration flow schema
        schema = MigrationFlowSchema(conn)
        schema.create_schema(verbose=False)
        
        # Create program_file_mapping table
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        # Create inventory table
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT,
                language TEXT,
                PRIMARY KEY (artifact_name, artifact_type)
            )
        """)
        
        # Insert programs with mixed types
        programs_data = [
            ('TESTPROG1', 'src/cobol/TESTPROG1.cbl', 1, 300, 'MAIN', 'COBOL'),
            ('TESTSUB1', 'src/cobol/TESTSUB1.cbl', 1, 200, 'SUBPROGRAM', 'COBOL'),
            ('TESTPROC1', 'src/cobol/TESTPROG1.cbl', 100, 150, 'PROCEDURE', 'COBOL'),
        ]
        
        cursor.executemany("""
            INSERT INTO program_file_mapping 
            (program_name, file_path, start_line, end_line, program_type, language)
            VALUES (?, ?, ?, ?, ?, ?)
        """, programs_data)
        
        # Insert copybook
        cursor.execute("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path, language)
            VALUES (?, ?, ?, ?)
        """, ('TESTCPY1', 'COPYBOOK', 'src/copybooks/TESTCPY1.cpy', 'COBOL'))
        
        # Insert test flow
        cursor.execute("""
            INSERT INTO migration_flows (
                flow_id, name, entry_program, primary_entry_type,
                total_programs, total_copybooks, total_datasets,
                complexity_total_lines, complexity_cyclomatic,
                complexity_score, complexity_tier,
                created_date, updated_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'FLOW_CONFIG_TEST', 'Config Test Flow', 'TESTPROG1', 'JCL',
            3, 1, 1,
            1000, 25, 50.0, 'MEDIUM',
            '2024-01-01', '2024-01-01'
        ))
        
        # Insert entry types
        cursor.execute("""
            INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
            VALUES (?, ?, ?, ?)
        """, ('FLOW_CONFIG_TEST', 'JCL', 'TESTJOB', json.dumps({'jclName': 'TESTJOB'})))
        
        # Insert scope
        scope_data = [
            ('FLOW_CONFIG_TEST', 'PROGRAM', 'TESTPROG1'),
            ('FLOW_CONFIG_TEST', 'PROGRAM', 'TESTSUB1'),
            ('FLOW_CONFIG_TEST', 'PROGRAM', 'TESTPROC1'),  # Internal procedure
            ('FLOW_CONFIG_TEST', 'COPYBOOK', 'TESTCPY1'),
            ('FLOW_CONFIG_TEST', 'DATASET', 'TEST.DATA'),
        ]
        
        cursor.executemany("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, scope_data)
        
        conn.commit()
        
        yield conn
        
        conn.close()
    
    def test_config_filter_true_metadata_true(self, test_db_full):
        """
        Test configuration: filter_internal_procedures=True, include_file_metadata=True
        
        Expected:
        - Internal procedures excluded
        - File metadata present
        """
        exporter = MigrationFlowExporter(
            test_db_full,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        result = exporter.export_flows(['FLOW_CONFIG_TEST'])
        flow = result['flows'][0]
        scope = flow['scope']
        
        # Verify filtering
        program_names = [p['name'] for p in scope['programs']]
        assert 'TESTPROG1' in program_names
        assert 'TESTSUB1' in program_names
        assert 'TESTPROC1' not in program_names  # Filtered out
        assert len(scope['programs']) == 2
        
        # Verify metadata present
        for program in scope['programs']:
            assert 'filePath' in program
            assert 'programType' in program
            assert 'language' in program
        
        # Verify copybook metadata
        assert 'filePath' in scope['copybooks'][0]
    
    def test_config_filter_true_metadata_false(self, test_db_full):
        """
        Test configuration: filter_internal_procedures=True, include_file_metadata=False
        
        Expected:
        - Internal procedures excluded
        - File metadata NOT present
        """
        exporter = MigrationFlowExporter(
            test_db_full,
            filter_internal_procedures=True,
            include_file_metadata=False
        )
        
        result = exporter.export_flows(['FLOW_CONFIG_TEST'])
        flow = result['flows'][0]
        scope = flow['scope']
        
        # Verify filtering
        program_names = [p['name'] for p in scope['programs']]
        assert 'TESTPROG1' in program_names
        assert 'TESTSUB1' in program_names
        assert 'TESTPROC1' not in program_names  # Filtered out
        assert len(scope['programs']) == 2
        
        # Verify metadata NOT present
        for program in scope['programs']:
            assert 'name' in program
            assert 'filePath' not in program
            assert 'programType' not in program
            assert 'language' not in program
        
        # Verify copybook metadata NOT present
        assert 'filePath' not in scope['copybooks'][0]
    
    def test_config_filter_false_metadata_true(self, test_db_full):
        """
        Test configuration: filter_internal_procedures=False, include_file_metadata=True
        
        Expected:
        - Internal procedures included
        - File metadata present
        """
        exporter = MigrationFlowExporter(
            test_db_full,
            filter_internal_procedures=False,
            include_file_metadata=True
        )
        
        result = exporter.export_flows(['FLOW_CONFIG_TEST'])
        flow = result['flows'][0]
        scope = flow['scope']
        
        # Verify NO filtering - all programs included
        program_names = [p['name'] for p in scope['programs']]
        assert 'TESTPROG1' in program_names
        assert 'TESTSUB1' in program_names
        assert 'TESTPROC1' in program_names  # NOT filtered
        assert len(scope['programs']) == 3
        
        # Verify metadata present for all programs
        for program in scope['programs']:
            assert 'filePath' in program
            assert 'programType' in program
            assert 'language' in program
        
        # Verify internal procedure has metadata
        testproc1 = next(p for p in scope['programs'] if p['name'] == 'TESTPROC1')
        assert testproc1['programType'] == 'PROCEDURE'
        assert testproc1['filePath'] == 'src/cobol/TESTPROG1.cbl'
    
    def test_config_filter_false_metadata_false(self, test_db_full):
        """
        Test configuration: filter_internal_procedures=False, include_file_metadata=False
        
        Expected:
        - Internal procedures included
        - File metadata NOT present
        """
        exporter = MigrationFlowExporter(
            test_db_full,
            filter_internal_procedures=False,
            include_file_metadata=False
        )
        
        result = exporter.export_flows(['FLOW_CONFIG_TEST'])
        flow = result['flows'][0]
        scope = flow['scope']
        
        # Verify NO filtering - all programs included
        program_names = [p['name'] for p in scope['programs']]
        assert 'TESTPROG1' in program_names
        assert 'TESTSUB1' in program_names
        assert 'TESTPROC1' in program_names  # NOT filtered
        assert len(scope['programs']) == 3
        
        # Verify metadata NOT present
        for program in scope['programs']:
            assert 'name' in program
            assert 'filePath' not in program
            assert 'programType' not in program
            assert 'language' not in program
    
    def test_default_configuration(self, test_db_full):
        """
        Test default configuration (no parameters specified).
        
        Expected:
        - filter_internal_procedures=True (default)
        - include_file_metadata=True (default)
        """
        # Create exporter with defaults
        exporter = MigrationFlowExporter(test_db_full)
        
        result = exporter.export_flows(['FLOW_CONFIG_TEST'])
        flow = result['flows'][0]
        scope = flow['scope']
        
        # Verify default filtering is applied
        program_names = [p['name'] for p in scope['programs']]
        assert 'TESTPROC1' not in program_names  # Filtered by default
        assert len(scope['programs']) == 2
        
        # Verify default metadata is included
        for program in scope['programs']:
            assert 'filePath' in program
            assert 'programType' in program
    
    def test_config_consistency_across_exports(self, test_db_full):
        """
        Test that configuration is consistent across multiple export calls.
        
        Validates:
        - Same configuration produces same results
        - Configuration doesn't change between calls
        """
        exporter = MigrationFlowExporter(
            test_db_full,
            filter_internal_procedures=True,
            include_file_metadata=True
        )
        
        # Export twice
        result1 = exporter.export_flows(['FLOW_CONFIG_TEST'])
        result2 = exporter.export_flows(['FLOW_CONFIG_TEST'])
        
        # Results should be identical
        assert result1 == result2
        
        # Verify both have filtering applied
        flow1 = result1['flows'][0]
        flow2 = result2['flows'][0]
        
        assert len(flow1['scope']['programs']) == len(flow2['scope']['programs'])
        assert len(flow1['scope']['programs']) == 2  # Filtered



# Property-Based Tests for Integration

from hypothesis import given, settings, strategies as st, assume, HealthCheck


@st.composite
def database_state_strategy(draw):
    """
    Generate a database state with optional program_file_mapping table.
    
    Returns:
        Tuple of (has_metadata_table, num_programs, num_internal_procedures)
    """
    has_metadata_table = draw(st.booleans())
    num_programs = draw(st.integers(min_value=1, max_value=10))
    num_internal_procedures = draw(st.integers(min_value=0, max_value=5))
    
    return has_metadata_table, num_programs, num_internal_procedures


# Property 4: Graceful Degradation (Database Integrity)
# Validates: Requirements 4.1
@settings(
    max_examples=100,
    suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
)
@given(db_state=database_state_strategy())
def test_property_data_integrity_graceful_degradation(db_state):
    """
    Property 4: Graceful Degradation (Database Integrity)
    
    For any database state (with or without program_file_mapping table),
    the export should succeed without modifying the database and should
    handle missing metadata gracefully.
    
    This property verifies that:
    - Export succeeds regardless of metadata table presence
    - Database is not modified during export
    - Missing metadata is handled without errors
    - Export returns valid JSON structure
    """
    has_metadata_table, num_programs, num_internal_procedures = db_state
    
    # Create test database
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create migration flow schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Optionally create program_file_mapping table
    if has_metadata_table:
        cursor.execute("""
            CREATE TABLE program_file_mapping (
                program_name TEXT PRIMARY KEY,
                file_path TEXT,
                start_line INTEGER,
                end_line INTEGER,
                program_type TEXT,
                language TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE inventory (
                artifact_name TEXT,
                artifact_type TEXT,
                file_path TEXT,
                language TEXT,
                PRIMARY KEY (artifact_name, artifact_type)
            )
        """)
    
    # Insert test flow
    flow_id = 'FLOW_PROP_TEST'
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        flow_id, 'Property Test Flow', 'PROG1', 'JCL',
        num_programs + num_internal_procedures, 0, 0,
        1000, 20, 50.0, 'MEDIUM',
        '2024-01-01', '2024-01-01'
    ))
    
    cursor.execute("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, (flow_id, 'JCL', 'JOB1', json.dumps({'jclName': 'JOB1'})))
    
    # Insert programs
    program_names = []
    for i in range(num_programs):
        prog_name = f'PROG{i+1}'
        program_names.append(prog_name)
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_id, 'PROGRAM', prog_name))
        
        # Add metadata if table exists
        if has_metadata_table:
            cursor.execute("""
                INSERT INTO program_file_mapping 
                (program_name, file_path, start_line, end_line, program_type, language)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (prog_name, f'src/{prog_name}.cbl', 1, 100, 'MAIN', 'COBOL'))
    
    # Insert internal procedures
    for i in range(num_internal_procedures):
        proc_name = f'PROC{i+1}'
        cursor.execute("""
            INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
            VALUES (?, ?, ?)
        """, (flow_id, 'PROGRAM', proc_name))
        
        # Add metadata if table exists
        if has_metadata_table:
            cursor.execute("""
                INSERT INTO program_file_mapping 
                (program_name, file_path, start_line, end_line, program_type, language)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (proc_name, f'src/PROG1.cbl', 100, 150, 'PROCEDURE', 'COBOL'))
    
    conn.commit()
    
    # Take snapshot of database before export
    cursor.execute("SELECT COUNT(*) FROM flow_scope WHERE flow_id = ?", (flow_id,))
    scope_count_before = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM migration_flows WHERE flow_id = ?", (flow_id,))
    flow_count_before = cursor.fetchone()[0]
    
    # Export flow
    exporter = MigrationFlowExporter(
        conn,
        filter_internal_procedures=True,
        include_file_metadata=True
    )
    
    try:
        result = exporter.export_flows([flow_id])
        
        # Verify export succeeded
        assert 'flows' in result
        assert len(result['flows']) == 1
        
        flow = result['flows'][0]
        assert flow['flowId'] == flow_id
        assert 'scope' in flow
        assert 'programs' in flow['scope']
        
        # Verify database was not modified
        cursor.execute("SELECT COUNT(*) FROM flow_scope WHERE flow_id = ?", (flow_id,))
        scope_count_after = cursor.fetchone()[0]
        assert scope_count_after == scope_count_before, "Database was modified during export"
        
        cursor.execute("SELECT COUNT(*) FROM migration_flows WHERE flow_id = ?", (flow_id,))
        flow_count_after = cursor.fetchone()[0]
        assert flow_count_after == flow_count_before, "Database was modified during export"
        
        # Verify graceful handling based on metadata availability
        if has_metadata_table:
            # With metadata table, internal procedures should be filtered
            exported_program_count = len(flow['scope']['programs'])
            assert exported_program_count == num_programs, \
                f"Expected {num_programs} programs, got {exported_program_count}"
            
            # Verify metadata is present
            if num_programs > 0:
                first_program = flow['scope']['programs'][0]
                assert 'filePath' in first_program
                assert 'programType' in first_program
        else:
            # Without metadata table, all programs should be included
            exported_program_count = len(flow['scope']['programs'])
            expected_count = num_programs + num_internal_procedures
            assert exported_program_count == expected_count, \
                f"Expected {expected_count} programs, got {exported_program_count}"
            
            # Verify metadata is NOT present
            if exported_program_count > 0:
                first_program = flow['scope']['programs'][0]
                assert 'filePath' not in first_program
                assert 'programType' not in first_program
        
    finally:
        conn.close()



import time


@st.composite
def flow_size_strategy(draw):
    """
    Generate flow sizes for performance testing.
    
    Returns:
        Tuple of (num_programs, num_copybooks, num_datasets)
    """
    # Test with flows up to 1000 programs as per requirement
    num_programs = draw(st.integers(min_value=10, max_value=1000))
    num_copybooks = draw(st.integers(min_value=0, max_value=100))
    num_datasets = draw(st.integers(min_value=0, max_value=50))
    
    return num_programs, num_copybooks, num_datasets


# Property 6: Query Performance
# Validates: Requirements (Non-Functional) Performance 1
@settings(
    max_examples=20,  # Reduced for performance testing
    suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow],
    deadline=None  # Disable deadline for performance tests
)
@given(flow_size=flow_size_strategy())
def test_property_query_performance(flow_size):
    """
    Property 6: Query Performance
    
    For any flow with up to 1000 programs, the enhanced _query_scope method
    should complete in under 100ms when program_file_mapping data is cached.
    
    This property verifies that:
    - Query completes within performance threshold
    - Caching improves performance
    - Performance scales reasonably with flow size
    """
    num_programs, num_copybooks, num_datasets = flow_size
    
    # Skip very small flows as they're not representative
    assume(num_programs >= 10)
    
    # Create test database
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    # Create migration flow schema
    schema = MigrationFlowSchema(conn)
    schema.create_schema(verbose=False)
    
    # Create program_file_mapping table
    cursor.execute("""
        CREATE TABLE program_file_mapping (
            program_name TEXT PRIMARY KEY,
            file_path TEXT,
            start_line INTEGER,
            end_line INTEGER,
            program_type TEXT,
            language TEXT
        )
    """)
    
    # Create inventory table
    cursor.execute("""
        CREATE TABLE inventory (
            artifact_name TEXT,
            artifact_type TEXT,
            file_path TEXT,
            language TEXT,
            PRIMARY KEY (artifact_name, artifact_type)
        )
    """)
    
    # Create indexes for performance
    cursor.execute("""
        CREATE INDEX idx_program_file_mapping_name 
        ON program_file_mapping(program_name)
    """)
    
    cursor.execute("""
        CREATE INDEX idx_inventory_artifact 
        ON inventory(artifact_name, artifact_type)
    """)
    
    cursor.execute("""
        CREATE INDEX idx_flow_scope_flow_artifact 
        ON flow_scope(flow_id, artifact_type)
    """)
    
    # Insert test flow
    flow_id = 'FLOW_PERF_TEST'
    cursor.execute("""
        INSERT INTO migration_flows (
            flow_id, name, entry_program, primary_entry_type,
            total_programs, total_copybooks, total_datasets,
            complexity_total_lines, complexity_cyclomatic,
            complexity_score, complexity_tier,
            created_date, updated_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        flow_id, 'Performance Test Flow', 'PROG1', 'JCL',
        num_programs, num_copybooks, num_datasets,
        10000, 100, 75.0, 'HIGH',
        '2024-01-01', '2024-01-01'
    ))
    
    cursor.execute("""
        INSERT INTO flow_entry_types (flow_id, entry_type, caller_source, metadata_json)
        VALUES (?, ?, ?, ?)
    """, (flow_id, 'JCL', 'PERFJOB', json.dumps({'jclName': 'PERFJOB'})))
    
    # Batch insert programs
    program_data = []
    scope_data = []
    
    for i in range(num_programs):
        prog_name = f'PROG{i:05d}'
        program_data.append((
            prog_name,
            f'src/cobol/{prog_name}.cbl',
            1,
            100 + (i % 500),
            'MAIN' if i % 10 != 0 else 'SUBPROGRAM',
            'COBOL'
        ))
        scope_data.append((flow_id, 'PROGRAM', prog_name))
    
    cursor.executemany("""
        INSERT INTO program_file_mapping 
        (program_name, file_path, start_line, end_line, program_type, language)
        VALUES (?, ?, ?, ?, ?, ?)
    """, program_data)
    
    # Batch insert copybooks
    copybook_data = []
    for i in range(num_copybooks):
        cpy_name = f'CPY{i:04d}'
        copybook_data.append((cpy_name, 'COPYBOOK', f'src/copybooks/{cpy_name}.cpy', 'COBOL'))
        scope_data.append((flow_id, 'COPYBOOK', cpy_name))
    
    if copybook_data:
        cursor.executemany("""
            INSERT INTO inventory (artifact_name, artifact_type, file_path, language)
            VALUES (?, ?, ?, ?)
        """, copybook_data)
    
    # Insert datasets
    for i in range(num_datasets):
        scope_data.append((flow_id, 'DATASET', f'DATASET.D{i:04d}'))
    
    cursor.executemany("""
        INSERT INTO flow_scope (flow_id, artifact_type, artifact_name)
        VALUES (?, ?, ?)
    """, scope_data)
    
    conn.commit()
    
    # Create exporter (this loads cache)
    exporter = MigrationFlowExporter(
        conn,
        filter_internal_procedures=True,
        include_file_metadata=True
    )
    
    # Measure query performance
    start_time = time.time()
    scope = exporter._query_scope(flow_id)
    end_time = time.time()
    
    query_time_ms = (end_time - start_time) * 1000
    
    # Verify query completed
    assert scope is not None
    assert 'programs' in scope
    assert 'copybooks' in scope
    assert 'datasets' in scope
    
    # Verify correct counts
    assert len(scope['programs']) <= num_programs
    assert len(scope['copybooks']) == num_copybooks
    assert len(scope['datasets']) == num_datasets
    
    # Performance assertion - should complete in under 100ms for flows up to 1000 programs
    # We'll be lenient and allow up to 200ms for larger flows in test environment
    max_allowed_time_ms = 200 if num_programs > 500 else 100
    
    # Log performance for analysis
    if query_time_ms > max_allowed_time_ms:
        print(f"\nPerformance warning: Query took {query_time_ms:.2f}ms for {num_programs} programs "
              f"(threshold: {max_allowed_time_ms}ms)")
    
    # Assert performance requirement
    assert query_time_ms < max_allowed_time_ms, \
        f"Query took {query_time_ms:.2f}ms, expected < {max_allowed_time_ms}ms " \
        f"for {num_programs} programs"
    
    conn.close()
