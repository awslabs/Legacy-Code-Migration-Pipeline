# Migration Packages Guide

## Overview

Migration packages group related artifacts together for coordinated migration. This guide explains how to create, validate, optimize, and manage migration packages.

## What are Migration Packages?

A migration package is a logical grouping of artifacts (programs, copybooks, datasets, JCL) that should be migrated together. Packages are based on:

- **Business domains**: Payroll, Billing, Customer Management
- **Dependencies**: Programs that call each other
- **Complexity**: Balanced effort across packages
- **Size constraints**: Manageable package sizes

## Quick Start

### Create a Package

```bash
python -m legacy_analyzer package create \
    --name "Payroll Migration" \
    --seeds PAYROLL1,PAYCALC,TAXCALC \
    --db analyzer.db
```

### Validate Package

```bash
python -m legacy_analyzer package validate \
    --name "Payroll Migration" \
    --db analyzer.db
```

### Export Package

```bash
python -m legacy_analyzer package export \
    --name "Payroll Migration" \
    --format csv \
    --output payroll_package.csv \
    --db analyzer.db
```

## Detailed Usage

### 1. Creating Packages

#### From Seed Artifacts

Start with key programs and automatically include dependencies:

```python
from legacy_analyzer.migration.package_builder import PackageBuilder
from smf_loader.databases import SQLiteAdapter

database = SQLiteAdapter('analyzer.db')
database.connect()

builder = PackageBuilder(database)

# Create package from seed programs
package = builder.create_package(
    name='Payroll Migration',
    seed_artifacts=['PAYROLL1', 'PAYCALC', 'TAXCALC']
)

print(f"Package: {package.name}")
print(f"Artifacts: {len(package.artifacts)}")
print(f"Total LOC: {package.total_loc}")
print(f"Total Complexity: {package.total_complexity:.2f}")
print(f"External Dependencies: {package.external_dependencies}")

database.close()
```

#### With Constraints

Apply size and complexity constraints:

```python
from tools.legacy_analyzer.models.package import PackageConstraints

constraints = PackageConstraints(
    max_artifacts=100,
    max_loc=50000,
    max_complexity=1000,
    allow_external_deps=False
)

package = builder.create_package(
    name='Small Package',
    seed_artifacts=['PROG1'],
    constraints=constraints
)
```

### 2. Validating Packages

#### Check Self-Containment

Ensure package has no external dependencies:

```python
validation = builder.validate_package(package)

print(f"Is Valid: {validation.is_valid}")
print(f"Is Self-Contained: {validation.is_self_contained}")

if validation.errors:
    print("Errors:")
    for error in validation.errors:
        print(f"  - {error}")

if validation.warnings:
    print("Warnings:")
    for warning in validation.warnings:
        print(f"  - {warning}")

if validation.external_dependencies:
    print("External Dependencies:")
    for dep in validation.external_dependencies:
        print(f"  - {dep}")
```

#### Check Size Constraints

```python
if package.total_loc > constraints.max_loc:
    print(f"Package exceeds LOC limit: {package.total_loc} > {constraints.max_loc}")

if package.total_complexity > constraints.max_complexity:
    print(f"Package exceeds complexity limit: {package.total_complexity} > {constraints.max_complexity}")
```

### 3. Detecting Conflicts

Find artifacts that belong to multiple packages:

```python
packages = [package1, package2, package3]

conflicts = builder.detect_conflicts(packages)

if conflicts:
    print(f"Found {len(conflicts)} conflicting artifact(s):")
    for artifact in conflicts:
        print(f"  {artifact}")
```

### 4. Optimizing Packages

Optimize package boundaries to minimize cross-package dependencies:

```python
from tools.legacy_analyzer.migration.package_optimizer import PackageOptimizer

optimizer = PackageOptimizer(database)

# Optimize packages
optimized = optimizer.optimize_packages(packages)

print(f"Original packages: {len(packages)}")
print(f"Optimized packages: {len(optimized)}")

for pkg in optimized:
    print(f"{pkg.name}: {len(pkg.artifacts)} artifacts, "
          f"{len(pkg.external_dependencies)} external deps")
```

### 5. Suggesting Packages

Let the system suggest optimal packages:

```python
# Suggest packages with max 1500 LOC each
suggested = builder.suggest_packages(max_size=1500)

print(f"Suggested {len(suggested)} package(s):")
for i, pkg in enumerate(suggested, 1):
    print(f"\nPackage {i}: {pkg.name}")
    print(f"  Artifacts: {len(pkg.artifacts)}")
    print(f"  LOC: {pkg.total_loc}")
    print(f"  Complexity: {pkg.total_complexity:.2f}")
```

## Package Metadata

### Package Structure

```python
@dataclass
class MigrationPackage:
    name: str                          # Package name
    artifacts: List[str]               # All artifacts in package
    total_loc: int                     # Total lines of code
    total_complexity: float            # Total complexity score
    external_dependencies: List[str]   # Dependencies outside package
    conflicts: List[str]               # Artifacts in multiple packages
```

### Accessing Package Data

```python
# Get all programs in package
programs = [a for a in package.artifacts if a in program_list]

# Get all copybooks in package
copybooks = [a for a in package.artifacts if a in copybook_list]

# Get all datasets in package
datasets = [a for a in package.artifacts if a in dataset_list]

# Check if artifact is in package
if 'PAYROLL1' in package.artifacts:
    print("PAYROLL1 is in this package")
```

## Migration Waves

### Generating Waves

Group packages into migration waves:

```bash
python -m legacy_analyzer package waves \
    --max-packages-per-wave 5 \
    --db analyzer.db \
    --output migration_waves.csv
```

### Wave Criteria

Waves are ordered by:
1. **Dependencies**: Packages with no dependencies first
2. **Complexity**: Lower complexity packages first
3. **Usage**: Higher usage packages later (more testing time)
4. **Size**: Balanced size across waves

### Example Wave Structure

```
Wave 1 (Pilot):
  - Small Package (50 artifacts, LOW complexity)
  - Utility Package (30 artifacts, LOW complexity)

Wave 2:
  - Customer Package (120 artifacts, MEDIUM complexity)
  - Billing Package (100 artifacts, MEDIUM complexity)

Wave 3:
  - Payroll Package (150 artifacts, HIGH complexity)
  - Accounting Package (140 artifacts, HIGH complexity)
```

## Exporting Packages

### CSV Export

```python
# Export to CSV
csv_data = package.to_csv()

with open('payroll_package.csv', 'w') as f:
    f.write(csv_data)
```

CSV format:
```csv
Artifact,Type,LOC,Complexity,Dependencies
PAYROLL1,PROGRAM,500,45.5,3
PAYCALC,PROGRAM,300,28.3,1
EMPREC,COPYBOOK,50,0,0
```

### JSON Export

```python
# Export to JSON
json_data = package.to_json()

with open('payroll_package.json', 'w') as f:
    f.write(json_data)
```

JSON format:
```json
{
  "name": "Payroll Migration",
  "artifacts": ["PAYROLL1", "PAYCALC", "TAXCALC"],
  "total_loc": 1200,
  "total_complexity": 102.1,
  "external_dependencies": ["DBACCESS"],
  "conflicts": []
}
```

## Use Cases

### 1. Domain-Based Packages

Create packages based on business domains:

```bash
# Payroll domain
python -m legacy_analyzer package create \
    --name "Payroll" \
    --seeds PAYROLL1,PAYCALC,TAXCALC \
    --db analyzer.db

# Billing domain
python -m legacy_analyzer package create \
    --name "Billing" \
    --seeds BILLING1,BILLCALC,INVOICE1 \
    --db analyzer.db

# Customer domain
python -m legacy_analyzer package create \
    --name "Customer" \
    --seeds CUSTMGMT,CUSTUPD,CUSTRPT \
    --db analyzer.db
```

### 2. Size-Constrained Packages

Create packages that fit team capacity:

```python
# Small team: max 50 artifacts per package
constraints = PackageConstraints(
    max_artifacts=50,
    max_loc=25000,
    max_complexity=500,
    allow_external_deps=True
)

packages = builder.create_packages_with_constraints(constraints)
```

### 3. Dependency-Driven Packages

Create packages that minimize cross-package dependencies:

```python
# Use optimization strategy
optimizer = PackageOptimizer(database)
packages = optimizer.create_optimal_packages(
    strategy='minimize_deps'
)
```

### 4. Pilot Package

Create a small pilot package for proof of concept:

```python
# Find lowest complexity programs
pilot_programs = database.execute_query("""
    SELECT program_name
    FROM complexity_metrics
    WHERE complexity_tier = 'LOW'
      AND dependency_count_out = 0
    ORDER BY composite_score
    LIMIT 10
""")

pilot_package = builder.create_package(
    name='Pilot Migration',
    seed_artifacts=[p[0] for p in pilot_programs]
)
```

## Configuration

Configure package settings in `config/legacy_analyzer.yaml`:

```yaml
packages:
  # Maximum artifacts per package
  max_artifacts: 100
  
  # Maximum LOC per package
  max_loc: 50000
  
  # Maximum complexity per package
  max_complexity: 1000
  
  # Allow external dependencies
  allow_external_deps: false
  
  # Optimization strategy
  optimization_strategy: "minimize_deps"
```

## Best Practices

1. **Start with Business Domains**: Align packages with business functions
2. **Keep Packages Self-Contained**: Minimize external dependencies
3. **Balance Package Sizes**: Aim for consistent effort across packages
4. **Create Pilot Package**: Test process with small, low-risk package
5. **Document Dependencies**: Track all cross-package dependencies
6. **Validate Early**: Validate packages before starting migration
7. **Plan Waves**: Group packages into logical migration waves
8. **Track Progress**: Monitor package completion status

## Troubleshooting

### Issue: Package Too Large

**Solutions**:
- Split into multiple packages
- Increase size constraints
- Remove non-essential artifacts
- Refactor to reduce dependencies

### Issue: Too Many External Dependencies

**Solutions**:
- Include dependent artifacts in package
- Create shared "Common" package
- Accept external dependencies (if unavoidable)
- Refactor to break dependencies

### Issue: Conflicting Artifacts

**Solutions**:
- Move shared artifacts to separate package
- Duplicate artifacts across packages (if small)
- Refactor to eliminate sharing
- Document and accept conflicts

### Issue: Unbalanced Waves

**Solutions**:
- Adjust `max_packages_per_wave`
- Manually reorder packages
- Split large packages
- Combine small packages

## Reporting

### Package Summary Report

```bash
python -m legacy_analyzer package report \
    --db analyzer.db \
    --output package_summary.html
```

### Package Details

```bash
python -m legacy_analyzer package details \
    --name "Payroll Migration" \
    --db analyzer.db \
    --output payroll_details.html
```

## Next Steps

- [Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md) - Analyze program flows
- [Complexity Guide](COMPLEXITY_GUIDE.md) - Assess complexity
- [Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md) - Complete migration process

## Examples

See `examples/migration_package_example.py` for complete working examples.
