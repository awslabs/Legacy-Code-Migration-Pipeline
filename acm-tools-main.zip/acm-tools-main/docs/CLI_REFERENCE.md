# Legacy Analyzer CLI Reference

Complete reference for all Legacy Analyzer command-line interface commands.

## Table of Contents

- [Installation](#installation)
- [Basic Usage](#basic-usage)
- [Inventory Management](#inventory-management)
- [Flow Analysis](#flow-analysis)
- [Complexity Analysis](#complexity-analysis)
- [Missing Code Detection](#missing-code-detection)
- [Migration Packages](#migration-packages)
- [Migration Flows](#migration-flows)
  - [Export Migration Flows](#export-migration-flows)
  - [Export JCL Jobs](#export-jcl-jobs)
- [Report Generation](#report-generation)
- [CICS Metadata Integration](#cics-metadata-integration)

## Installation

```bash
pip install -e .
```

## Basic Usage

```bash
python -m legacy_analyzer <command> [options]
```

To see all available commands:

```bash
python -m legacy_analyzer --help
```

To see help for a specific command:

```bash
python -m legacy_analyzer <command> --help
```

## Inventory Management

### Load Inventory Data

Load mainframe inventory data from CSV files.

```bash
python -m legacy_analyzer load --type <type> --file <csv_file> --db <database>
```

**Options:**
- `--type`: Type of inventory (choices: jcl, programs, copybooks, datasets, cics)
- `--file`: Path to CSV file
- `--db`: Path to SQLite database file

**Examples:**

```bash
# Load JCL inventory
python -m legacy_analyzer load --type jcl --file jcl_inventory.csv --db analyzer.db

# Load program inventory
python -m legacy_analyzer load --type programs --file programs.csv --db analyzer.db

# Load copybook inventory
python -m legacy_analyzer load --type copybooks --file copybooks.csv --db analyzer.db

# Load CICS inventory (enhanced CSV format)
python -m legacy_analyzer load --type cics --file cics_inventory.csv --db analyzer.db
```

### Load CICS Inventory

Load CICS resource definitions from CSV files into the inventory database.

```bash
python -m legacy_analyzer load --type cics --file <csv_file> --db <database>
```

**Options:**
- `--type cics`: Specifies CICS inventory type
- `--file`: Path to CICS inventory CSV file
- `--db`: Path to SQLite database file

**CSV Format:**

The CICS inventory loader supports both standard and enhanced CSV formats for backward compatibility.

**Standard CSV Format (Legacy):**
```csv
resource_name,resource_type,group_name,status
CAUP,TRANSACTION,CARDDEMO,ENABLED
COACTUPC,PROGRAM,CARDDEMO,ENABLED
ACCTDAT,FILE,CARDDEMO,ENABLED
COACTUP,MAPSET,CARDDEMO,ENABLED
```

**Enhanced CSV Format (Recommended):**
```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Credit Card Account Update,
CACT,TRANSACTION,CARDDEMO,ENABLED,COACTUP,,Credit Card Account List,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
COACTUP,PROGRAM,CARDDEMO,ENABLED,,,Account List Program,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data File,
CUSTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.CUSTDATA.VSAM.KSDS,Customer Data File,
COACTUP,MAPSET,CARDDEMO,ENABLED,,,Account Update Map,
COCRDLI,MAPSET,CARDDEMO,ENABLED,,,Credit Card List Map,
```

**Enhanced CSV Columns:**

| Column | Type | Required | Description | Applicable To |
|--------|------|----------|-------------|---------------|
| `resource_name` | VARCHAR(8) | Yes | Resource identifier (4-8 characters) | All resources |
| `resource_type` | VARCHAR(20) | Yes | TRANSACTION, PROGRAM, FILE, MAPSET | All resources |
| `group_name` | VARCHAR(20) | Yes | CICS group name | All resources |
| `status` | VARCHAR(10) | Yes | ENABLED or DISABLED | All resources |
| `program_name` | VARCHAR(44) | No | Associated program name | TRANSACTION only |
| `dataset_name` | VARCHAR(44) | No | MVS dataset name | FILE only |
| `description` | TEXT | No | Human-readable description | All resources (optional) |
| `language` | VARCHAR(20) | No | Programming language (COBOL, PLI, ASM, etc.) | PROGRAM only |

**Column Usage by Resource Type:**

- **TRANSACTION**: Requires `resource_name`, `resource_type`, `group_name`, `status`, `program_name`. Optional: `description`
- **PROGRAM**: Requires `resource_name`, `resource_type`, `group_name`, `status`. Optional: `description`, `language`
- **FILE**: Requires `resource_name`, `resource_type`, `group_name`, `status`, `dataset_name`. Optional: `description`
- **MAPSET**: Requires `resource_name`, `resource_type`, `group_name`, `status`. Optional: `description`

**Empty Fields:**
- Empty fields are represented by consecutive commas (e.g., `CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Description,`)
- All 8 columns must be present in enhanced format (even if empty)
- Standard format (4 columns) is also supported for backward compatibility

**Examples:**

```bash
# Load enhanced CICS inventory
python -m legacy_analyzer load \
  --type cics \
  --file exports/cics_inventory.csv \
  --db results/analysis/analysis.db

# Load standard CICS inventory (backward compatible)
python -m legacy_analyzer load \
  --type cics \
  --file exports/cics_inventory_legacy.csv \
  --db results/analysis/analysis.db

# Verify loading
sqlite3 results/analysis/analysis.db \
  "SELECT COUNT(*) FROM inventory_cics;"

# View loaded CICS transactions
sqlite3 results/analysis/analysis.db \
  "SELECT resource_name, program_name, description 
   FROM inventory_cics 
   WHERE resource_type = 'TRANSACTION' 
   AND status = 'ENABLED';"
```

**Benefits of Enhanced Format:**

1. **Explicit Entry Points**: Transaction-to-program mapping enables explicit ONLINE entry point identification
2. **Transaction Mapping**: Transaction IDs map to programs for API endpoint planning
3. **Dataset Relationships**: File-to-dataset mapping supports data flow analysis
4. **Status Tracking**: Track ENABLED/DISABLED resources for modernization planning
5. **Language Detection**: Program language information aids in complexity analysis
6. **Documentation**: Descriptions improve human readability and understanding

**Creating Enhanced CSV:**

You can create enhanced CSV files using:

1. **CSD Conversion**: Convert raw CSD files using `metadata convert-csd` command (see [CICS Metadata Integration](#cics-metadata-integration))
2. **Mainframe Export**: Use REXX scripts to export directly from mainframe (see [CICS Export Guide](../legacy_analyzer/inventory/exporters/docs/CICS_EXPORT_GUIDE.md))
3. **Manual Creation**: Create CSV manually following the format specification above

**Complete Example CSV:**

A complete example showing all resource types from the CardDemo application:

```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Credit Card Account Update,
CACT,TRANSACTION,CARDDEMO,ENABLED,COACTUP,,Credit Card Account List,
CCRD,TRANSACTION,CARDDEMO,ENABLED,COCRDLIC,,Credit Card List,
CMEN,TRANSACTION,CARDDEMO,ENABLED,COMENUC,,Main Menu,
CBIL,TRANSACTION,CARDDEMO,ENABLED,COBIL00C,,Bill Payment,
CRPT,TRANSACTION,CARDDEMO,ENABLED,CORPT00C,,Transaction Report,
CUSR,TRANSACTION,CARDDEMO,ENABLED,COUSR00C,,User Management,
CTRN,TRANSACTION,CARDDEMO,ENABLED,COTRN00C,,Transaction Processing,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
COACTUP,PROGRAM,CARDDEMO,ENABLED,,,Account List Program,COBOL
COCRDLIC,PROGRAM,CARDDEMO,ENABLED,,,Credit Card List Program,COBOL
COMENUC,PROGRAM,CARDDEMO,ENABLED,,,Main Menu Program,COBOL
COBIL00C,PROGRAM,CARDDEMO,ENABLED,,,Bill Payment Program,COBOL
CORPT00C,PROGRAM,CARDDEMO,ENABLED,,,Transaction Report Program,COBOL
COUSR00C,PROGRAM,CARDDEMO,ENABLED,,,User Management Program,COBOL
COTRN00C,PROGRAM,CARDDEMO,ENABLED,,,Transaction Processing Program,COBOL
CBACT01C,PROGRAM,CARDDEMO,ENABLED,,,Account Validation Subprogram,COBOL
CBACT02C,PROGRAM,CARDDEMO,ENABLED,,,Account Update Subprogram,COBOL
CBCUS01C,PROGRAM,CARDDEMO,ENABLED,,,Customer Validation Subprogram,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data File,
CUSTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.CUSTDATA.VSAM.KSDS,Customer Data File,
CARDDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS,Card Data File,
TRANDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.TRANDATA.VSAM.KSDS,Transaction Data File,
XREFDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.XREFDATA.VSAM.KSDS,Cross Reference File,
COACTUP,MAPSET,CARDDEMO,ENABLED,,,Account Update Map,
COCRDLI,MAPSET,CARDDEMO,ENABLED,,,Credit Card List Map,
COMENU,MAPSET,CARDDEMO,ENABLED,,,Main Menu Map,
COBIL00,MAPSET,CARDDEMO,ENABLED,,,Bill Payment Map,
CORPT00,MAPSET,CARDDEMO,ENABLED,,,Transaction Report Map,
```

This example demonstrates:
- **8 TRANSACTION resources** linking transaction IDs to programs
- **11 PROGRAM resources** including main programs and subprograms with language specified
- **5 FILE resources** with complete MVS dataset names
- **5 MAPSET resources** for screen definitions

**Workflow:**

1. **Export/Convert**: Create enhanced CSV from CSD files or mainframe export
2. **Load**: Use `load --type cics` to import into database
3. **Analyze**: Entry point detection now includes CICS transaction data
4. **Report**: Generate reports with explicit ONLINE entry points

**See Also:**
- [CICS Metadata Integration](#cics-metadata-integration) - Converting CSD files to CSV
- [CICS Export Guide](../legacy_analyzer/inventory/exporters/docs/CICS_EXPORT_GUIDE.md) - Detailed export instructions

### Load Dependencies

Load dependency data from CSV or JSON files.

```bash
python -m legacy_analyzer load-dependencies --csv <file> --db <database>
python -m legacy_analyzer load-dependencies --json <file> --db <database>
```

**Options:**
- `--csv`: Path to CSV file with dependencies
- `--json`: Path to JSON file with dependencies
- `--db`: Path to database file
- `--update-duplicates`: Update duplicate entries instead of skipping

**Example:**

```bash
python -m legacy_analyzer load-dependencies --csv dependencies.csv --db analyzer.db
```

## Flow Analysis

Analyze program execution flows and call graphs.

### Analyze Program Flow

Analyze the complete execution flow starting from a specific program.

```bash
python -m legacy_analyzer flow analyze --program <name> --db <database> [options]
```

**Options:**
- `--program`: Starting program name (required)
- `--db`: Path to database file (required)
- `--max-depth`: Maximum depth to traverse (default: 10)
- `--output`: Output file path (JSON format)
- `--format`: Output format (choices: json, text; default: text)

**Examples:**

```bash
# Analyze flow for PAYROLL1 program
python -m legacy_analyzer flow analyze --program PAYROLL1 --db analyzer.db

# Save flow to JSON file
python -m legacy_analyzer flow analyze --program PAYROLL1 --db analyzer.db --output flow.json --format json

# Limit depth to 5 levels
python -m legacy_analyzer flow analyze --program PAYROLL1 --db analyzer.db --max-depth 5
```

**Output:**
- Start program name
- Maximum depth reached
- Total programs in flow
- Total copybooks referenced
- Total datasets accessed
- Circular dependencies (if any)
- List of all programs in flow

### Generate Call Graph

Generate a call graph showing program-to-program relationships.

```bash
python -m legacy_analyzer flow graph --db <database> --output <file> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path (required)
- `--programs`: Comma-separated program names (optional, default: all programs)
- `--format`: Output format (choices: dot, mermaid, json; default: mermaid)

**Examples:**

```bash
# Generate Mermaid diagram for all programs
python -m legacy_analyzer flow graph --db analyzer.db --output callgraph.mmd --format mermaid

# Generate DOT format for specific programs
python -m legacy_analyzer flow graph --programs PAYROLL1,BILLING2 --db analyzer.db --output graph.dot --format dot

# Export as JSON
python -m legacy_analyzer flow graph --db analyzer.db --output graph.json --format json
```

### List Entry Points

Find all entry point programs (programs that are never called by others).

```bash
python -m legacy_analyzer flow entry-points --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path (optional)
- `--use-metadata`: Use CICS metadata and JCL dependencies for enhanced entry point detection (optional, default: False)
- `--include-disabled`: Include DISABLED CICS transactions (only with --use-metadata, optional, default: False)
- `--format`: Output format - json, csv, or text (optional, default: text)

**Basic Usage (Code Analysis Only):**

```bash
# List entry points using code analysis
python -m legacy_analyzer flow entry-points --db analyzer.db

# Save to file (legacy JSON format)
python -m legacy_analyzer flow entry-points --db analyzer.db --output entry_points.json
```

**Enhanced Usage (With CICS Metadata):**

When `--use-metadata` is specified, the command integrates CICS transaction metadata and JCL dependencies to provide explicit entry point detection with confidence levels.

```bash
# Enhanced entry points with CICS metadata (text format)
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata

# JSON format with full metadata
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata --format json --output entry_points.json

# CSV format for spreadsheet analysis (deprecated for entry_points)
# Use JSON or Markdown format instead:
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata --format json --output entry_points.json
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata --format markdown --output entry_points.md

# Include disabled CICS transactions
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata --include-disabled
```

**Output Formats:**

**Text Format (Human-Readable):**
```
================================================================================
ENTRY POINT ANALYSIS
================================================================================
Total Entry Points: 26

ONLINE Entry Points (CICS Transactions): 18
--------------------------------------------------------------------------------
  ✓ COACTUPC
      Transaction: CAUP
      CICS Group:  CARDDEMO
      Description: Credit Card Account Update
      Confidence:  EXPLICIT

BATCH Entry Points (JCL Jobs): 8
--------------------------------------------------------------------------------
  • CBACT01C
      JCL:        DALYREJS
      Confidence: EXPLICIT

INFERRED Entry Points (Code Analysis): 0
--------------------------------------------------------------------------------

================================================================================
SUMMARY
================================================================================
ONLINE (CICS):     18
BATCH (JCL):       8
INFERRED (Code):   0

EXPLICIT:          26
INFERRED:          0
================================================================================
```

**JSON Format (Structured Data):**
```json
{
  "entry_points": [
    {
      "program_name": "COACTUPC",
      "entry_type": "ONLINE",
      "confidence": "EXPLICIT",
      "source": "CSD",
      "transaction_id": "CAUP",
      "cics_group": "CARDDEMO",
      "status": "ENABLED",
      "description": "Credit Card Account Update"
    },
    {
      "program_name": "CBACT01C",
      "entry_type": "BATCH",
      "confidence": "EXPLICIT",
      "source": "JCL",
      "jcl_name": "DALYREJS",
      "status": "ENABLED"
    }
  ],
  "summary": {
    "total": 26,
    "by_type": {
      "ONLINE": 18,
      "BATCH": 8,
      "INFERRED": 0
    },
    "by_confidence": {
      "EXPLICIT": 26,
      "INFERRED": 0
    },
    "by_status": {
      "ENABLED": 24,
      "DISABLED": 2,
      "UNKNOWN": 0
    }
  }
}
```

**CSV Format (Spreadsheet-Ready):**
```csv
program_name,entry_type,confidence,source,transaction_id,cics_group,jcl_name,status,description
COACTUPC,ONLINE,EXPLICIT,CSD,CAUP,CARDDEMO,,ENABLED,Credit Card Account Update
CBACT01C,BATCH,EXPLICIT,JCL,,,DALYREJS,ENABLED,
```

**Entry Point Types:**
- **ONLINE** - CICS transactions (from CSD metadata)
- **BATCH** - JCL jobs (from JCL EXEC statements)
- **INFERRED** - Programs not called by others (from code analysis)

**Confidence Levels:**
- **EXPLICIT** - Identified from metadata (CICS/JCL), high confidence
- **INFERRED** - Identified from code analysis, lower confidence

**Backward Compatibility:**

Without `--use-metadata`, the command behaves exactly as before, returning a simple list of program names identified through code analysis. This ensures existing scripts and workflows continue to work unchanged.

### Detect Circular Dependencies

Detect circular dependencies in the system.

```bash
python -m legacy_analyzer flow circular --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path (JSON format, optional)

**Example:**

```bash
# Detect circular dependencies
python -m legacy_analyzer flow circular --db analyzer.db

# Save to file
python -m legacy_analyzer flow circular --db analyzer.db --output cycles.json
```

## Complexity Analysis

Analyze code complexity metrics.

### Analyze Complexity

Analyze complexity of source code files.

```bash
python -m legacy_analyzer complexity analyze --source-dir <directory> --db <database> [options]
```

**Options:**
- `--source-dir`: Source code directory (required)
- `--db`: Path to database file (required)
- `--language`: Programming language (choices: COBOL, PLI, JCL, REXX, NATURAL, RPG; auto-detect if not specified)
- `--pattern`: File pattern (default: *)
- `--output`: Output file path (CSV format)

**Examples:**

```bash
# Analyze COBOL programs
python -m legacy_analyzer complexity analyze --source-dir /path/to/cobol --language COBOL --db analyzer.db

# Auto-detect language and save results
python -m legacy_analyzer complexity analyze --source-dir /path/to/source --db analyzer.db --output complexity.csv

# Analyze specific file pattern
python -m legacy_analyzer complexity analyze --source-dir /path/to/cobol --pattern "*.cbl" --db analyzer.db
```

**Metrics Calculated:**
- Lines of Code (LOC)
- Cyclomatic Complexity
- Dependency Counts (in/out)
- Composite Complexity Score
- Complexity Tier (LOW, MEDIUM, HIGH, VERY_HIGH)
- God Program Detection

### Generate Complexity Report

Generate a detailed complexity report.

```bash
python -m legacy_analyzer complexity report --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--program`: Specific program name (optional)
- `--top-n`: Number of top complex programs to show (default: 10)
- `--output`: Output file path

**Examples:**

```bash
# Generate report for all programs
python -m legacy_analyzer complexity report --db analyzer.db

# Show top 20 most complex programs
python -m legacy_analyzer complexity report --db analyzer.db --top-n 20

# Save report to file
python -m legacy_analyzer complexity report --db analyzer.db --output complexity_report.txt
```

### Show Complexity Summary

Show a summary of complexity distribution.

```bash
python -m legacy_analyzer complexity summary --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path

**Example:**

```bash
python -m legacy_analyzer complexity summary --db analyzer.db
```

## Missing Code Detection

Detect artifacts referenced in code but not found in inventory.

### Detect Missing Artifacts

Find missing programs, copybooks, or datasets.

```bash
python -m legacy_analyzer missing detect --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--type`: Artifact type to check (choices: programs, copybooks, datasets, all; default: all)
- `--output`: Output file path
- `--format`: Output format (choices: csv, json, text; default: text)

**Examples:**

```bash
# Detect all missing artifacts
python -m legacy_analyzer missing detect --db analyzer.db

# Detect only missing programs
python -m legacy_analyzer missing detect --type programs --db analyzer.db

# Save results as CSV
python -m legacy_analyzer missing detect --db analyzer.db --output missing.csv --format csv

# Save results as JSON
python -m legacy_analyzer missing detect --db analyzer.db --output missing.json --format json
```

**Output:**
- Artifact name
- Artifact type
- Reference count
- Severity (HIGH, MEDIUM, LOW)
- List of artifacts that reference it

### Calculate Completeness Score

Calculate inventory completeness percentage.

```bash
python -m legacy_analyzer missing completeness --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path (JSON format)

**Example:**

```bash
# Show completeness score
python -m legacy_analyzer missing completeness --db analyzer.db

# Save to file
python -m legacy_analyzer missing completeness --db analyzer.db --output completeness.json
```

**Output:**
- Overall completeness percentage
- Program completeness
- Copybook completeness
- Dataset completeness
- Counts of found vs. missing artifacts

## Migration Packages

Create and manage migration packages.

### Create Package

Create a migration package from seed artifacts.

```bash
python -m legacy_analyzer package create --name <name> --seeds <artifacts> --db <database> [options]
```

**Options:**
- `--name`: Package name (required)
- `--seeds`: Comma-separated seed artifact names (required)
- `--db`: Path to database file (required)
- `--no-transitive`: Do not include transitive dependencies
- `--max-depth`: Maximum depth for transitive dependencies
- `--output`: Output file path (JSON format)

**Examples:**

```bash
# Create package with transitive dependencies
python -m legacy_analyzer package create --name Payroll --seeds PAYROLL1,PAYCALC --db analyzer.db

# Create package without transitive dependencies
python -m legacy_analyzer package create --name Payroll --seeds PAYROLL1 --no-transitive --db analyzer.db

# Limit dependency depth and save to file
python -m legacy_analyzer package create --name Payroll --seeds PAYROLL1 --max-depth 3 --db analyzer.db --output payroll_pkg.json
```

**Output:**
- Package name
- Total artifacts
- Total LOC
- Total complexity
- External dependencies
- Self-contained status

### Validate Package

Validate a migration package against constraints.

```bash
python -m legacy_analyzer package validate --package <file> --db <database> [options]
```

**Options:**
- `--package`: Package file path (JSON format, required)
- `--db`: Path to database file (required)
- `--max-artifacts`: Maximum artifacts constraint
- `--max-loc`: Maximum LOC constraint

**Example:**

```bash
# Validate package
python -m legacy_analyzer package validate --package payroll_pkg.json --db analyzer.db

# Validate with constraints
python -m legacy_analyzer package validate --package payroll_pkg.json --db analyzer.db --max-artifacts 100 --max-loc 50000
```

### List Packages

List all migration packages in the database.

```bash
python -m legacy_analyzer package list --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path (JSON format)

**Example:**

```bash
# List all packages
python -m legacy_analyzer package list --db analyzer.db

# Save to file
python -m legacy_analyzer package list --db analyzer.db --output packages.json
```

### Export Migration Flows

Export migration flows with various sorting strategies for migration planning.

```bash
python -m legacy_analyzer migration export-flows --db <database> --output <file> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path (JSON format, required)
- `--sort`: Sorting strategy (choices: complexity-asc, complexity-desc, independence, dependencies, name, none; default: complexity-asc)
- `--extended-scope`: Include extended utility metadata (copybooks, datasets, JCL, CICS resources)

**Sorting Strategies:**

1. **complexity-asc** (Recommended for Phase 1: Proof of Concept)
   - Sorts flows from simplest to most complex
   - Start with low-risk, easy wins to build confidence
   - Ideal for initial migration waves

2. **complexity-desc** (Phase 3: High Value)
   - Sorts flows from most complex to simplest
   - Tackle high-value, complex flows when team is experienced
   - Useful for addressing technical debt early

3. **independence** (Phase 2: Parallel Migration)
   - Sorts by minimal external dependencies
   - Enables parallel migration of independent flows
   - Reduces coordination overhead

4. **dependencies** (Phase 4: Shared Infrastructure)
   - Sorts by most dependencies first (foundational flows)
   - Migrate shared utilities and common components first
   - Reduces rework in dependent flows

5. **name** (Documentation)
   - Alphabetical sorting by flow name
   - Useful for documentation and reference
   - Easy to locate specific flows

6. **none** (Baseline)
   - Database order (no sorting)
   - Useful for comparing with other strategies

**Extended Scope:**

When `--extended-scope` is specified, each flow includes comprehensive utility metadata:

- **Copybooks**: All copybooks used across the flow with usage counts
- **Datasets**: All datasets accessed with operation types (READ/WRITE/UPDATE)
- **JCL**: All JCL jobs that execute programs in the flow
- **CICS Resources**: CICS transactions, files, and mapsets used

This metadata is essential for:
- Complete migration planning (not just programs)
- Data migration strategy
- Infrastructure requirements
- Testing scope definition

**Examples:**

```bash
# Export flows sorted by complexity (simplest first) - RECOMMENDED
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_complexity_asc.json \
  --sort complexity-asc \
  --extended-scope

# Export flows sorted by independence (parallel migration)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_independence.json \
  --sort independence \
  --extended-scope

# Export flows sorted by dependencies (foundational first)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_dependencies.json \
  --sort dependencies \
  --extended-scope

# Export flows sorted by complexity (most complex first)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_complexity_desc.json \
  --sort complexity-desc \
  --extended-scope

# Export flows alphabetically
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_name.json \
  --sort name \
  --extended-scope

# Export flows in database order (no sorting)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_database_order.json \
  --sort none \
  --extended-scope
```

**Output Format:**

The exported JSON contains an array of migration flows with complete metadata:

```json
{
  "flows": [
    {
      "flowId": "FLOW_001",
      "flowName": "Account Update Flow",
      "entryPoint": {
        "programName": "COACTUPC",
        "types": ["CICS_TRANSACTION", "CICS_PROGRAM"],
        "callers": [
          {
            "type": "CICS_TRANSACTION",
            "name": "CAUP",
            "metadata": {
              "transactionId": "CAUP",
              "cicsGroup": "CARDDEMO",
              "status": "ENABLED",
              "description": "Credit Card Account Update"
            }
          }
        ]
      },
      "programs": [
        {
          "name": "COACTUPC",
          "language": "COBOL",
          "loc": 450,
          "complexity": 12.5,
          "tier": "MEDIUM"
        }
      ],
      "complexity": {
        "totalLoc": 1250,
        "avgComplexity": 15.3,
        "maxComplexity": 28.5,
        "tier": "MEDIUM"
      },
      "dependencies": {
        "internal": 5,
        "external": 2
      },
      "utilities": {
        "copybooks": [
          {
            "name": "CUSTCOPY",
            "usedBy": ["COACTUPC", "CBACT01C"],
            "usageCount": 2
          }
        ],
        "datasets": [
          {
            "name": "ACCTDAT",
            "operations": ["READ", "WRITE"],
            "accessedBy": ["COACTUPC"]
          }
        ],
        "jcl": [
          {
            "name": "DALYREJS",
            "executesPrograms": ["CBACT01C"]
          }
        ],
        "cics": {
          "transactions": ["CAUP"],
          "files": ["ACCTDAT"],
          "mapsets": ["COACTUP"]
        }
      }
    }
  ],
  "summary": {
    "totalFlows": 27,
    "sortStrategy": "complexity-asc",
    "extendedScope": true,
    "complexityDistribution": {
      "LOW": 12,
      "MEDIUM": 10,
      "HIGH": 4,
      "VERY_HIGH": 1
    }
  }
}
```

**Migration Planning Workflow:**

1. **Export all strategies** to compare different approaches:
   ```bash
   # Export all 6 sorting strategies
   for strategy in complexity-asc complexity-desc independence dependencies name none; do
     python -m legacy_analyzer migration export-flows \
       --db analyzer.db \
       --output flows_by_${strategy}.json \
       --sort ${strategy} \
       --extended-scope
   done
   ```

2. **Review and select** the strategy that best fits your migration approach

3. **Plan migration waves** based on the selected strategy:
   - Wave 1: First 5-10 flows (pilot)
   - Wave 2: Next 10-15 flows (scale up)
   - Wave 3: Remaining flows (full migration)

4. **Use extended metadata** to plan:
   - Data migration (datasets)
   - Batch job migration (JCL)
   - Online transaction migration (CICS)
   - Shared component migration (copybooks)

### Export JCL Jobs

Export all JCL jobs with orchestration, categorization, and dependencies for infrastructure and batch migration planning.

```bash
python -m legacy_analyzer migration export-jobs --db <database> [options]
```

**Options:**
- `--db`: Path to database file (default: analyzer.db)
- `--output-dir`: Output directory for job exports (default: results/jobs)
- `--sort-by`: Sorting strategy (choices: name, type, dependencies, complexity; default: name)

**Sorting Strategiess:**

1. **name** (Default)
   - Alphabetical sorting by job name
   - Easy to locate specific jobs
   - Useful for documentation and reference

2. **type**
   - Groups APPLICATION jobs before INFRASTRUCTURE jobs
   - Within each group, sorts alphabetically
   - Helps prioritize application vs infrastructure migration

3. **dependencies**
   - Topological sort based on job dependencies
   - Jobs that must run first appear earlier
   - Maintains correct execution order during migration

4. **complexity**
   - Sorts by number of steps (descending)
   - Most complex jobs first
   - Helps identify high-risk jobs early

**Job Categorization:**

Jobs are automatically categorized into two types:

- **APPLICATION**: Jobs that invoke at least one custom program (COBOL, PL/I, etc.)
  - These jobs execute business logic
  - Require program migration before job migration
  - Linked to program flows when applicable

- **INFRASTRUCTURE**: Jobs that only invoke utility programs (IEFBR14, IDCAMS, SORT, etc.)
  - These jobs perform infrastructure tasks (dataset operations, backups, etc.)
  - Can often be migrated independently
  - May be replaced with cloud-native equivalents

**Examples:**

```bash
# Export jobs with default settings (sorted by name)
python -m legacy_analyzer migration export-jobs --db analyzer.db

# Export jobs sorted by type (APPLICATION first, then INFRASTRUCTURE)
python -m legacy_analyzer migration export-jobs \
  --db analyzer.db \
  --output-dir results/jobs \
  --sort-by type

# Export jobs sorted by dependencies (execution order)
python -m legacy_analyzer migration export-jobs \
  --db analyzer.db \
  --output-dir results/jobs \
  --sort-by dependencies

# Export jobs sorted by complexity (most complex first)
python -m legacy_analyzer migration export-jobs \
  --db analyzer.db \
  --output-dir results/jobs \
  --sort-by complexity

# Export all sorting strategies for comparison
for strategy in name type dependencies complexity; do
  python -m legacy_analyzer migration export-jobs \
    --db analyzer.db \
    --output-dir results/jobs \
    --sort-by ${strategy}
done
```

**Output Format:**

The exported JSON contains an array of jobs with complete orchestration metadata:

```json
{
  "jobs": [
    {
      "jobName": "DALYREJS",
      "jobType": "APPLICATION",
      "hasCustomCode": true,
      "linkedFlow": "FLOW_CBACT01C",
      "steps": [
        {
          "stepName": "STEP01",
          "program": "IEFBR14",
          "type": "UTILITY",
          "purpose": "Allocate or delete datasets",
          "flowEntry": false
        },
        {
          "stepName": "STEP02",
          "program": "CBACT01C",
          "type": "CUSTOM",
          "purpose": "Execute CBACT01C",
          "flowEntry": true
        },
        {
          "stepName": "STEP03",
          "program": "SORT",
          "type": "UTILITY",
          "purpose": "Sort dataset",
          "flowEntry": false
        }
      ],
      "datasets": [
        "ACCTDAT",
        "CUSTDAT",
        "TRANFILE"
      ],
      "dependencies": {
        "mustRunAfter": ["DAILYEXT"],
        "mustRunBefore": ["DAILYRPT"]
      }
    },
    {
      "jobName": "BACKUPJB",
      "jobType": "INFRASTRUCTURE",
      "hasCustomCode": false,
      "linkedFlow": null,
      "steps": [
        {
          "stepName": "STEP01",
          "program": "IEFBR14",
          "type": "UTILITY",
          "purpose": "Allocate or delete datasets",
          "flowEntry": false
        },
        {
          "stepName": "STEP02",
          "program": "ADRDSSU",
          "type": "UTILITY",
          "purpose": "Backup or restore datasets",
          "flowEntry": false
        }
      ],
      "datasets": [
        "BACKUP.DATASET"
      ],
      "dependencies": {
        "mustRunAfter": [],
        "mustRunBefore": []
      }
    }
  ],
  "summary": {
    "totalJobs": 35,
    "applicationJobs": 28,
    "infrastructureJobs": 7,
    "exportDate": "2026-01-30T12:34:56.789Z",
    "database": "analyzer.db",
    "sortedBy": "name"
  }
}
```

**Job Export Fields:**

- **jobName**: JCL job name
- **jobType**: "APPLICATION" or "INFRASTRUCTURE"
- **hasCustomCode**: True if job invokes custom programs
- **linkedFlow**: Flow name (FLOW_{program}) if job invokes a flow entry point, null otherwise
- **steps**: Array of job steps with:
  - **stepName**: Step identifier (STEP01, STEP02, etc.)
  - **program**: Program or utility name
  - **type**: "CUSTOM" or "UTILITY"
  - **purpose**: Human-readable description
  - **flowEntry**: True if this step starts a program flow
- **datasets**: Array of unique dataset names referenced by the job
- **dependencies**: Job-to-job dependencies:
  - **mustRunAfter**: Jobs that must run before this job
  - **mustRunBefore**: Jobs that must run after this job

**Migration Planning with Job Exports:**

1. **Dual Export Approach**: Export both jobs and flows for complete migration planning
   ```bash
   # Export flows
   python -m legacy_analyzer migration export-flows \
     --db analyzer.db \
     --output flows.json \
     --sort complexity-asc \
     --extended-scope
   
   # Export jobs (all strategies)
   for strategy in name type dependencies complexity; do
     python -m legacy_analyzer migration export-jobs \
       --db analyzer.db \
       --output-dir results/jobs \
       --sort-by ${strategy}
   done
   ```

2. **Three-Phase Migration Strategy**:
   
   **Phase 1: Infrastructure Jobs**
   - Migrate INFRASTRUCTURE jobs first (no custom code dependencies)
   - Replace with cloud-native equivalents where possible
   - Examples: Backups, dataset operations, file transfers
   
   **Phase 2: Application Jobs**
   - Migrate APPLICATION jobs after their linked flows are migrated
   - Use linkedFlow field to coordinate with flow migration
   - Maintain job dependencies using mustRunAfter/mustRunBefore
   
   **Phase 3: Orchestration**
   - Implement job scheduling and orchestration in cloud
   - Use dependency information to build DAGs
   - Replace JCL with cloud-native workflow tools (Airflow, Step Functions, etc.)

3. **Cross-Reference Jobs and Flows**:
   - Jobs link to flows via linkedFlow field
   - Flows link to jobs via invokedByJobs field (in flow export)
   - Use these cross-references to plan coordinated migration

4. **Dependency Analysis**:
   - Use dependencies sorting to understand execution order
   - Identify critical path jobs (many dependencies)
   - Plan migration to maintain correct execution sequence

**Use Cases:**

- **Infrastructure Migration**: Focus on INFRASTRUCTURE jobs, migrate independently
- **Batch Migration**: Focus on APPLICATION jobs, coordinate with program flow migration
- **Orchestration Planning**: Use dependencies to build cloud-native workflows
- **Risk Assessment**: Use complexity sorting to identify high-risk jobs
- **Documentation**: Use name sorting for reference documentation

**See Also:**
- [Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md) - Complete migration planning process
- [Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md) - Understanding program flows
- [API Reference](API_REFERENCE.md) - Python API for export_migration_flows()

## Report Generation

Generate various analysis reports.

### Summary Report

Generate a comprehensive analysis summary report in Markdown format.

```bash
python -m legacy_analyzer report summary --db <database> [options]
```

**Options:**
- `--db`: Path to SQLite database file (required)
- `--output`: Output file path (default: reports/analysis_summary.md)

**Examples:**

```bash
# Generate summary report with default output
python -m legacy_analyzer report summary --db analyzer.db

# Generate summary report with custom output path
python -m legacy_analyzer report summary \
  --db analyzer.db \
  --output custom/path/summary.md

# Use in bash script
python -m legacy_analyzer report summary \
  --db "$DATABASE" \
  --output "$OUTPUT_DIR/reports/analysis_summary.md"
```

**Report Contents:**

The summary report includes comprehensive statistics from the analysis database:

- **Inventory Statistics**: Total artifacts and breakdown by language
- **Dependency Statistics**: Total dependencies and breakdown by type
- **CICS Resources**: CICS resource counts by type (if available)
- **Programs**: Total program count
- **Migration Flows**: Flow counts by complexity tier (if available)

**Output Format:**

The report is generated in Markdown format with tables for easy readability:

```markdown
# Analysis Summary Report

## Inventory Statistics

**Total Artifacts:** 128

### By Language

| Language | Count |
|----------|-------|
| COBOL    | 75    |
| JCL      | 35    |
| UNKNOWN  | 14    |
| ASM      | 4     |

## Dependency Statistics

**Total Dependencies:** 264

### By Type

| Type              | Count |
|-------------------|-------|
| COPY              | 199   |
| CICS_FILE         | 20    |
| CICS_TRANSACTION  | 18    |
| CALL              | 16    |
| EXEC_PGM          | 11    |

## CICS Resources

**Total CICS Resources:** 64

### By Resource Type

| Resource Type | Count |
|---------------|-------|
| PROGRAM       | 18    |
| TRANSACTION   | 18    |
| MAPSET        | 17    |
| FILE          | 8     |
| LIBRARY       | 2     |
| TDQUEUE       | 1     |

## Programs

**Total Programs:** 33

## Migration Flows

**Total Migration Flows:** 29

### By Complexity

| Complexity | Count |
|------------|-------|
| LOW        | 24    |
| UNKNOWN    | 3     |
| HIGH       | 1     |
| MEDIUM     | 1     |
```

**Features:**

- **Automatic Directory Creation**: Creates output directory if it doesn't exist
- **Error Handling**: Gracefully handles missing tables or empty databases
- **Markdown Format**: Easy to view in any Markdown viewer or convert to other formats
- **Comprehensive Statistics**: Aggregates data from multiple database tables

**Use Cases:**

- **Quick Overview**: Get a high-level view of analysis results
- **Documentation**: Include in project documentation or reports
- **Comparison**: Compare analysis results across different projects or versions
- **Automation**: Generate reports automatically in CI/CD pipelines

**Integration with Bash Scripts:**

This command is used by the analysis bash scripts to generate summary reports:

```bash
# In run_configurable_analysis.sh
python -m legacy_analyzer report summary \
  --db "$DATABASE" \
  --output "$OUTPUT_DIR/reports/analysis_summary.md"
```

**See Also:**
- [Executive Summary](#executive-summary) - High-level executive report
- [Complete Analysis Guide](COMPLETE_ANALYSIS_GUIDE.md) - Full analysis workflow

### Executive Summary

Generate an executive summary report.

```bash
python -m legacy_analyzer report executive --db <database> [options]
```

**Options:**
- `--db`: Path to database file (required)
- `--output`: Output file path
- `--format`: Output format (choices: text, html, markdown; default: text)

**Example:**

```bash
# Generate analysis summary report
python -m legacy_analyzer report summary --db analyzer.db

# Save to custom file
python -m legacy_analyzer report summary --db analyzer.db --output custom_summary.md
```

**Report Contents:**
- Inventory overview
- Complexity distribution
- Missing artifacts summary
- Circular dependencies count
- Migration packages summary
- Key findings

### Artifact Report

Generate a detailed report for a specific artifact.

```bash
python -m legacy_analyzer report artifact --name <artifact> --db <database> [options]
```

**Options:**
- `--name`: Artifact name (required)
- `--db`: Path to database file (required)
- `--output`: Output file path

**Example:**

```bash
# Generate artifact report
python -m legacy_analyzer report artifact --name PAYROLL1 --db analyzer.db

# Save to file
python -m legacy_analyzer report artifact --name PAYROLL1 --db analyzer.db --output payroll1_report.txt
```

**Report Contents:**
- Complexity metrics
- Dependencies (callers and callees)
- Copybooks used
- Datasets accessed
- Program flow information
- Package assignment

### Package Report

Generate a report for a migration package.

```bash
python -m legacy_analyzer report package --package <file> --db <database> [options]
```

**Options:**
- `--package`: Package file path (JSON format, required)
- `--db`: Path to database file (required)
- `--output`: Output file path

**Example:**

```bash
# Generate package report
python -m legacy_analyzer report package --package payroll_pkg.json --db analyzer.db

# Save to file
python -m legacy_analyzer report package --package payroll_pkg.json --db analyzer.db --output package_report.txt
```

**Report Contents:**
- Package summary
- External dependencies
- Conflicts
- Artifacts list

## CICS Metadata Integration

Parse and integrate CICS System Definition (CSD) files to extract transaction and program metadata.

### Convert CSD to CSV

Convert raw CSD files to enhanced CSV format for loading into the inventory.

```bash
python -m legacy_analyzer metadata convert-csd --input <csd_file> --output <csv_file> [options]
```

**Options:**
- `--input`: Path to CSD file (required)
- `--output`: Path to output CSV file (required)
- `--dry-run`: Show what would be extracted without writing file

**Examples:**

```bash
# Convert CSD file to CSV
python -m legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv

# Dry run to preview extraction
python -m legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv \
  --dry-run
```

**What it extracts:**
- **TRANSACTION** definitions with program associations
- **PROGRAM** definitions with language and status
- **FILE** definitions with dataset mappings
- **MAPSET** definitions for screen layouts

**Output format:**

The command generates an enhanced CSV file with the following columns:
- `resource_name`: Name of the CICS resource
- `resource_type`: Type (TRANSACTION, PROGRAM, FILE, MAPSET)
- `group_name`: CICS group name
- `status`: Resource status (ENABLED, DISABLED)
- `program_name`: Associated program (for transactions)
- `dataset_name`: Associated dataset (for files)
- `description`: Resource description

**Example output:**
```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Account Update,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data File,
COACTUP,MAPSET,CARDDEMO,ENABLED,,,Credit Card Account Update Map,
```

**Complete example CSV file:**

Below is a complete example showing all resource types from the CardDemo application:

```csv
resource_name,resource_type,group_name,status,program_name,dataset_name,description,language
CAUP,TRANSACTION,CARDDEMO,ENABLED,COACTUPC,,Credit Card Account Update,
CACT,TRANSACTION,CARDDEMO,ENABLED,COACTUP,,Credit Card Account List,
CCRD,TRANSACTION,CARDDEMO,ENABLED,COCRDLIC,,Credit Card List,
CMEN,TRANSACTION,CARDDEMO,ENABLED,COMENUC,,Main Menu,
CBIL,TRANSACTION,CARDDEMO,ENABLED,COBIL00C,,Bill Payment,
CRPT,TRANSACTION,CARDDEMO,ENABLED,CORPT00C,,Transaction Report,
CUSR,TRANSACTION,CARDDEMO,ENABLED,COUSR00C,,User Management,
CTRN,TRANSACTION,CARDDEMO,ENABLED,COTRN00C,,Transaction Processing,
COACTUPC,PROGRAM,CARDDEMO,ENABLED,,,Account Update Program,COBOL
COACTUP,PROGRAM,CARDDEMO,ENABLED,,,Account List Program,COBOL
COCRDLIC,PROGRAM,CARDDEMO,ENABLED,,,Credit Card List Program,COBOL
COMENUC,PROGRAM,CARDDEMO,ENABLED,,,Main Menu Program,COBOL
COBIL00C,PROGRAM,CARDDEMO,ENABLED,,,Bill Payment Program,COBOL
CORPT00C,PROGRAM,CARDDEMO,ENABLED,,,Transaction Report Program,COBOL
COUSR00C,PROGRAM,CARDDEMO,ENABLED,,,User Management Program,COBOL
COTRN00C,PROGRAM,CARDDEMO,ENABLED,,,Transaction Processing Program,COBOL
CBACT01C,PROGRAM,CARDDEMO,ENABLED,,,Account Validation Subprogram,COBOL
CBACT02C,PROGRAM,CARDDEMO,ENABLED,,,Account Update Subprogram,COBOL
CBCUS01C,PROGRAM,CARDDEMO,ENABLED,,,Customer Validation Subprogram,COBOL
ACCTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS,Account Data File,
CUSTDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.CUSTDATA.VSAM.KSDS,Customer Data File,
CARDDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS,Card Data File,
TRANDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.TRANDATA.VSAM.KSDS,Transaction Data File,
XREFDAT,FILE,CARDDEMO,ENABLED,,AWS.M2.CARDDEMO.XREFDATA.VSAM.KSDS,Cross Reference File,
COACTUP,MAPSET,CARDDEMO,ENABLED,,,Account Update Map,
COCRDLI,MAPSET,CARDDEMO,ENABLED,,,Credit Card List Map,
COMENU,MAPSET,CARDDEMO,ENABLED,,,Main Menu Map,
COBIL00,MAPSET,CARDDEMO,ENABLED,,,Bill Payment Map,
CORPT00,MAPSET,CARDDEMO,ENABLED,,,Transaction Report Map,
```

This example demonstrates:
- **8 TRANSACTION resources** linking transaction IDs to programs
- **11 PROGRAM resources** including main programs and subprograms with language specified
- **5 FILE resources** with complete MVS dataset names
- **5 MAPSET resources** for screen definitions

**CSV Format Notes:**
- Header row is required
- All 8 columns must be present (even if empty)
- Empty fields are represented by consecutive commas
- `program_name` is only populated for TRANSACTION resources
- `dataset_name` is only populated for FILE resources
- `language` is only populated for PROGRAM resources
- `description` is optional for all resource types

**Dry run output:**

When using `--dry-run`, the command displays:
- Summary statistics (count of transactions, programs, files, mapsets)
- Sample of extracted resources (first 5 of each type)
- No file is written

**Loading the CSV:**

After conversion, load the CSV into the database using the standard load command:

```bash
python -m legacy_analyzer load \
  --type cics \
  --file exports/cics_inventory.csv \
  --db analyzer.db
```

**Benefits:**
- **Explicit Entry Points**: Identify ONLINE entry points from CICS transactions
- **Transaction Mapping**: Map transaction IDs to programs for API endpoint planning
- **Dataset Relationships**: Link CICS files to MVS datasets
- **Status Tracking**: Track ENABLED/DISABLED resources for modernization planning

**Workflow:**
1. **Export**: Extract CSD from mainframe using DFHCSDUP (or use existing CSD files)
2. **Convert**: Use `metadata convert-csd` to create enhanced CSV
3. **Load**: Use `load --type cics` to import into database
4. **Analyze**: Entry point detection now includes CICS transaction data

For detailed CSD export instructions from mainframe, see the [CICS Export Guide](../legacy_analyzer/inventory/exporters/docs/CICS_EXPORT_GUIDE.md).

### Load CICS Metadata from Source (Integrated Workflow)

Discover, convert, and load CICS metadata in a single command. This is the most convenient way to get CICS metadata into the system.

```bash
python -m legacy_analyzer metadata load-from-source --source-dir <directory> --db <database> [options]
```

**Options:**
- `--source-dir`: Source directory to scan for CSD files (required)
- `--db`: Path to SQLite database file (required)
- `--keep-csv`: Save converted CSV file to this path (optional)
- `--recursive`: Scan subdirectories recursively (default: True)
- `--no-recursive`: Do not scan subdirectories

**What it does:**

This integrated command performs three steps automatically:

1. **Scan**: Discovers all `.csd` files in the source directory
2. **Convert**: Parses CSD files and converts them to enhanced CSV format
3. **Load**: Imports the CSV data into the database

**Examples:**

```bash
# Basic usage - scan, convert, and load in one command
python -m legacy_analyzer metadata load-from-source \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --db results/analysis/analysis.db

# Keep the converted CSV file for review
python -m legacy_analyzer metadata load-from-source \
  --source-dir ./examples/code/cobol/carddemoV2 \
  --db results/analysis/analysis.db \
  --keep-csv exports/cics_inventory.csv

# Scan only the specified directory (no subdirectories)
python -m legacy_analyzer metadata load-from-source \
  --source-dir ./app/csd \
  --db analyzer.db \
  --no-recursive
```

**Output:**

The command provides detailed progress information:

```
============================================================
CICS METADATA LOAD FROM SOURCE
============================================================
Source directory: ./examples/code/cobol/carddemoV2
Database:         results/analysis/analysis.db
Recursive:        True
============================================================

[Step 1/3] Scanning for CSD files...
------------------------------------------------------------

✓ Found 1 CSD file(s):
  - app/csd/CARDDEMO.csd

[Step 2/3] Converting CSD files to CSV...
------------------------------------------------------------

[1/1] Processing: CARDDEMO.csd
  ✓ Parsed successfully
    Transactions: 8
    Programs:     11
    Files:        5
    Mapsets:      5
    Total:        29

------------------------------------------------------------
CONVERSION SUMMARY
------------------------------------------------------------
Total Transactions: 8
Total Programs:     11
Total Files:        5
Total Mapsets:      5
Total Resources:    29
------------------------------------------------------------

Writing CSV file...
  ✓ Using temporary CSV file

[Step 3/3] Loading CSV into database...
------------------------------------------------------------

Connecting to database: results/analysis/analysis.db
Ensuring inventory schema exists...

Loading CICS inventory from CSV...

------------------------------------------------------------
LOAD SUMMARY
------------------------------------------------------------
Total processed:  29
Inserted:         29
Updated:          0
------------------------------------------------------------

✓ Temporary CSV file cleaned up

============================================================
✓ LOAD FROM SOURCE COMPLETED SUCCESSFULLY
============================================================
CSD files processed:  1
Resources loaded:     29
Database:             results/analysis/analysis.db
============================================================

Next steps:
  - Use 'flow entry-points' to see entry points with CICS metadata
  - Use 'report executive' to generate comprehensive analysis
  - Query the 'inventory_cics' table directly for CICS resources
```

**Benefits:**

- **Convenience**: Single command replaces three separate steps
- **Automatic Discovery**: Finds all CSD files in directory tree
- **Multiple Files**: Processes and merges multiple CSD files automatically
- **Temporary Files**: Uses temporary CSV files by default (no clutter)
- **Progress Tracking**: Shows detailed progress for each step
- **Error Handling**: Continues processing if individual files fail

**Use Cases:**

1. **Quick Setup**: Get CICS metadata loaded quickly during initial analysis
2. **Batch Processing**: Process multiple CSD files from different CICS regions
3. **Automated Workflows**: Integrate into CI/CD pipelines or scripts
4. **Development**: Rapid iteration during development and testing

**Comparison with Manual Workflow:**

| Approach | Commands | Flexibility | Use Case |
|----------|----------|-------------|----------|
| **load-from-source** | 1 command | Lower | Quick setup, automation |
| **Manual workflow** | 3 commands | Higher | Review/edit CSV, custom processing |

**Manual Workflow (for comparison):**
```bash
# Step 1: Convert
python -m legacy_analyzer metadata convert-csd \
  --input app/csd/CARDDEMO.csd \
  --output exports/cics_inventory.csv

# Step 2: Review/edit CSV (optional)
# ... manual review ...

# Step 3: Load
python -m legacy_analyzer load \
  --type cics \
  --file exports/cics_inventory.csv \
  --db analyzer.db
```

**When to use load-from-source:**
- You want to get started quickly
- You trust the CSD files are correct
- You're processing multiple CSD files
- You're automating the workflow

**When to use manual workflow:**
- You want to review the CSV before loading
- You need to edit or filter the data
- You're combining data from multiple sources
- You want more control over each step

**Error Handling:**

The command handles common errors gracefully:

- **No CSD files found**: Provides helpful suggestions
- **Parse errors**: Continues with other files, reports failures
- **Database errors**: Reports connection or schema issues
- **File system errors**: Validates paths and permissions

**See Also:**
- [Convert CSD to CSV](#convert-csd-to-csv) - Manual conversion step
- [Load CICS Inventory](#load-cics-inventory) - Manual loading step
- [Scan for Metadata](#scan-for-metadata-files) - Discovery only
- [CICS Export Guide](../legacy_analyzer/inventory/exporters/docs/CICS_EXPORT_GUIDE.md) - Mainframe export instructions

### Scan for Metadata Files

Scan a directory for CICS metadata files (CSD and CSV files).

```bash
python -m legacy_analyzer metadata scan --source-dir <directory> [options]
```

**Options:**
- `--source-dir`: Source directory to scan (required)
- `--file-types`: Types of files to scan for (choices: csd, csv, all; default: all)
- `--convert`: Auto-convert discovered CSD files to CSV
- `--output-dir`: Output directory for converted CSV files (used with --convert)
- `--recursive`: Scan subdirectories recursively (default: True)
- `--no-recursive`: Do not scan subdirectories

**Examples:**

```bash
# Scan and list all metadata files
python -m legacy_analyzer metadata scan \
  --source-dir ./examples/code/cobol/carddemoV2

# Scan for CSD files only
python -m legacy_analyzer metadata scan \
  --source-dir ./app \
  --file-types csd

# Scan and auto-convert CSD files
python -m legacy_analyzer metadata scan \
  --source-dir ./app \
  --convert \
  --output-dir ./exports
```

**Note:** For a complete workflow that scans, converts, and loads in one command, use [`metadata load-from-source`](#load-cics-metadata-from-source-integrated-workflow) instead.

## Common Workflows

### Complete Analysis Workflow

```bash
# 1. Load inventory data
python -m legacy_analyzer load --type programs --file programs.csv --db analyzer.db
python -m legacy_analyzer load --type copybooks --file copybooks.csv --db analyzer.db
python -m legacy_analyzer load --type datasets --file datasets.csv --db analyzer.db

# 2. Analyze source code
python -m legacy_analyzer analyze --source-dir /path/to/cobol --language COBOL --db analyzer.db

# 3. Analyze complexity
python -m legacy_analyzer complexity analyze --source-dir /path/to/cobol --db analyzer.db

# 4. Detect missing artifacts
python -m legacy_analyzer missing detect --db analyzer.db --output missing.csv --format csv

# 5. Analyze program flows
python -m legacy_analyzer flow analyze --program MAINPROG --db analyzer.db

# 6. Create migration package
python -m legacy_analyzer package create --name MainPackage --seeds MAINPROG --db analyzer.db --output package.json

# 7. Generate analysis summary report
python -m legacy_analyzer report summary --db analyzer.db --output reports/analysis_summary.md
```

### Quick Analysis

```bash
# Analyze a single program
python -m legacy_analyzer flow analyze --program PAYROLL1 --db analyzer.db
python -m legacy_analyzer complexity report --program PAYROLL1 --db analyzer.db
python -m legacy_analyzer report artifact --name PAYROLL1 --db analyzer.db
```

## Exit Codes

- `0`: Success
- `1`: Error occurred

## Environment Variables

None currently used.

## Configuration Files

Configuration can be customized in `config/legacy_analyzer.yaml`. See [Configuration Guide](CONFIGURATION.md) for details.

## See Also

- [Getting Started Guide](GETTING_STARTED.md)
- [API Reference](API_REFERENCE.md)
- [Migration Workflow Guide](MIGRATION_WORKFLOW.md)
