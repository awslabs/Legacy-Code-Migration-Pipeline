# Entry Point Detection Guide

## Overview

The Entry Point Detection system identifies programs that serve as entry points into the legacy application. Entry points are programs that can be invoked from outside the application, such as through CICS transactions, JCL jobs, or external interfaces.

This guide explains the enhanced entry point detection algorithm that combines multiple data sources to provide comprehensive and accurate entry point identification with confidence scoring.

## Detection Algorithm

The `EntryPointDetector` class uses a **multi-source, priority-based approach** to identify entry points:

```
Priority 1: ONLINE (CICS Transactions) → EXPLICIT confidence
Priority 2: BATCH (JCL Jobs)           → EXPLICIT confidence  
Priority 3: INFERRED (Code Analysis)   → INFERRED confidence
```

### Detection Process

1. **Query CICS Metadata**: Extract ONLINE entry points from `inventory_cics` table
2. **Query JCL Dependencies**: Extract BATCH entry points from `artifact_dependencies` table
3. **Analyze Call Graph**: Identify programs never called by others (INFERRED)
4. **Merge with Priority**: Higher priority sources override lower priority ones
5. **Return Deduplicated List**: Each program appears once with its highest-priority classification

## Data Sources

### 1. CICS Metadata (ONLINE Entry Points)

**Source**: `inventory_cics` table  
**Confidence**: EXPLICIT  
**Entry Type**: ONLINE

CICS transactions provide the most reliable source of entry point information. These are explicitly defined in the CICS System Definition (CSD) files.

**Query**:
```sql
SELECT resource_name, program_name, group_name, status, description
FROM inventory_cics
WHERE resource_type = 'TRANSACTION'
  AND status = 'ENABLED'
```

**Example Entry Point**:
```python
EntryPoint(
    program_name='COACTUPC',
    entry_type='ONLINE',
    confidence='EXPLICIT',
    source='CSD',
    transaction_id='CAUP',
    cics_group='CARDDEMO',
    status='ENABLED',
    description='Account Update'
)
```

### 2. JCL Dependencies (BATCH Entry Points)

**Source**: `artifact_dependencies` table  
**Confidence**: EXPLICIT  
**Entry Type**: BATCH

JCL jobs that execute programs are explicit entry points for batch processing.

**Query**:
```sql
SELECT DISTINCT target_artifact_name, source_artifact_name
FROM artifact_dependencies
WHERE source_type = 'JCL'
  AND dependency_type = 'EXEC_PGM'
  AND target_type = 'PROGRAM'
```

**Example Entry Point**:
```python
EntryPoint(
    program_name='CBACT01C',
    entry_type='BATCH',
    confidence='EXPLICIT',
    source='JCL',
    jcl_name='DAILYJOB',
    status='ENABLED'
)
```

### 3. Code Analysis (INFERRED Entry Points)

**Source**: Call graph analysis  
**Confidence**: INFERRED  
**Entry Type**: INFERRED

Programs that are never called by other programs in the codebase are potential entry points. This is an inference based on code structure.

**Algorithm**:
```python
inferred_entry_points = all_programs - called_programs
```

**Example Entry Point**:
```python
EntryPoint(
    program_name='UTILPROG',
    entry_type='INFERRED',
    confidence='INFERRED',
    source='CODE_ANALYSIS',
    description='Program not called by any other program'
)
```

## Confidence Levels

### EXPLICIT Confidence

- **Definition**: Entry point is explicitly defined in metadata (CICS or JCL)
- **Reliability**: High - based on actual system configuration
- **Use Cases**: Production entry point mapping, API endpoint design, service boundaries

### INFERRED Confidence

- **Definition**: Entry point is inferred from code structure
- **Reliability**: Medium - may include utility programs or dead code
- **Use Cases**: Completeness checking, identifying potential missing metadata

## Usage Examples

### CLI Usage

The easiest way to use entry point detection is through the CLI:

#### Basic Entry Points (Code Analysis Only)

```bash
# List entry points using code analysis
python -m legacy_analyzer flow entry-points --db analysis.db

# Output: Simple list of program names
# Found 54 entry points:
#   • ACCTFILE
#   • CARDFILE
#   • CBADMCDJ
#   ...
```

#### Enhanced Entry Points (With Metadata)

```bash
# Enhanced entry points with CICS metadata (text format)
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata

# Output: Detailed report with entry types and confidence levels
# ================================================================================
# ENTRY POINT ANALYSIS
# ================================================================================
# Total Entry Points: 26
#
# ONLINE Entry Points (CICS Transactions): 18
# --------------------------------------------------------------------------------
#   ✓ COACTUPC
#       Transaction: CAUP
#       CICS Group:  CARDDEMO
#       Description: Credit Card Account Update
#       Confidence:  EXPLICIT
# ...
```

#### JSON Output for Automation

```bash
# Generate JSON output for automation
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --format json \
  --output entry_points/entry_points.json

# Output file contains structured data:
# {
#   "entry_points": [
#     {
#       "program_name": "COACTUPC",
#       "entry_type": "ONLINE",
#       "confidence": "EXPLICIT",
#       "source": "CSD",
#       "transaction_id": "CAUP",
#       "cics_group": "CARDDEMO",
#       "status": "ENABLED",
#       "description": "Credit Card Account Update"
#     }
#   ],
#   "summary": {
#     "total": 26,
#     "by_type": {"ONLINE": 18, "BATCH": 8, "INFERRED": 0},
#     "by_confidence": {"EXPLICIT": 26, "INFERRED": 0}
#   }
# }
```

#### CSV Output for Spreadsheet Analysis

```bash
# Generate CSV output for spreadsheet analysis (deprecated for entry_points)
# Use JSON or Markdown format instead:
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --format json \
  --output entry_points/entry_points.json

# Or use Markdown format:
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --format markdown \
  --output entry_points/entry_points.md

# Output file contains:
# JSON format with full metadata structure
```

#### Include Disabled CICS Transactions

```bash
# Include disabled transactions for completeness
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --include-disabled

# This includes both ENABLED and DISABLED CICS transactions
```

#### Complete Workflow Example

```bash
# Step 1: Load CICS metadata
python -m legacy_analyzer metadata load-from-source \
  --source-dir examples/code/cobol/carddemoV2 \
  --db analysis.db

# Step 2: Analyze source code
python -m legacy_analyzer analyze \
  --source-dir examples/code/cobol/carddemoV2/app \
  --db analysis.db

# Step 3: Generate enhanced entry points report
python -m legacy_analyzer flow entry-points \
  --db analysis.db \
  --use-metadata \
  --format json \
  --output entry_points/entry_points.json

# Result: Complete entry point analysis with CICS metadata
```

### Python API Usage

For programmatic access, use the Python API:

#### Basic Usage

```python
from legacy_analyzer.analysis.entry_point_detector import EntryPointDetector
import sqlite3

# Connect to database
conn = sqlite3.connect('analysis.db')
detector = EntryPointDetector(conn)

# Get all entry points
entry_points = detector.detect_entry_points(
    all_programs={'PROG1', 'PROG2', 'PROG3'},
    called_programs={'PROG3'},
    include_disabled=False,
    include_inferred=True
)

# Print results
for ep in entry_points:
    print(f"{ep.program_name}: {ep.entry_type} ({ep.confidence})")
```

### Get ONLINE Entry Points Only

```python
# Get enabled CICS transactions
online_entries = detector.get_online_entry_points(include_disabled=False)

for ep in online_entries:
    print(f"Transaction {ep.transaction_id} → Program {ep.program_name}")
```

### Get BATCH Entry Points Only

```python
# Get batch programs from JCL
batch_entries = detector.get_batch_entry_points()

for ep in batch_entries:
    print(f"JCL {ep.jcl_name} → Program {ep.program_name}")
```

### Get Statistics

```python
# Get entry point statistics
stats = detector.get_entry_point_statistics(entry_points)

print(f"Total entry points: {stats['total']}")
print(f"ONLINE: {stats['by_type']['ONLINE']}")
print(f"BATCH: {stats['by_type']['BATCH']}")
print(f"INFERRED: {stats['by_type']['INFERRED']}")
print(f"EXPLICIT confidence: {stats['by_confidence']['EXPLICIT']}")
print(f"INFERRED confidence: {stats['by_confidence']['INFERRED']}")
```

## Priority Merging

When a program appears in multiple sources, the **highest priority source wins**:

### Example Scenario

```
Program: COACTUPC
- Found in CICS as transaction CAUP (ONLINE, EXPLICIT)
- Found in JCL TESTJOB (BATCH, EXPLICIT)
- Not called by any program (INFERRED)

Result: ONLINE entry point (highest priority)
```

### Why Priority Matters

1. **Accuracy**: CICS metadata is more specific than JCL or code analysis
2. **Context**: Knowing a program is ONLINE vs BATCH affects modernization strategy
3. **Deduplication**: Each program appears once in the final list

## Status Filtering

Entry points can be filtered by status:

- **ENABLED**: Active entry points in production
- **DISABLED**: Inactive entry points (historical or deprecated)

```python
# Include disabled transactions
all_entries = detector.get_online_entry_points(include_disabled=True)

# Filter to enabled only
enabled_entries = [ep for ep in all_entries if ep.is_enabled()]
```

## Graceful Degradation

The detector handles missing data sources gracefully:

### Missing CICS Table

```python
# If inventory_cics table doesn't exist
detector._has_cics_table  # Returns False
detector.get_online_entry_points()  # Returns empty list, no error
```

### Missing Dependencies Table

```python
# If artifact_dependencies table doesn't exist
detector._has_dependencies_table  # Returns False
detector.get_batch_entry_points()  # Returns empty list, no error
```

### Fallback Behavior

When metadata is unavailable, the system falls back to code analysis:

```python
# No CICS or JCL metadata available
entry_points = detector.detect_entry_points(
    all_programs=all_programs,
    called_programs=called_programs,
    include_inferred=True  # Rely on code analysis
)
# All entry points will have INFERRED confidence
```

## Integration with Flow Analysis

The entry point detector integrates with the flow analyzer for comprehensive analysis:

```python
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer

# Create flow analyzer
flow_analyzer = FlowAnalyzer(db_connection)

# Use entry point detector for enhanced analysis
entry_points = detector.detect_entry_points(
    all_programs=flow_analyzer.get_all_programs(),
    called_programs=flow_analyzer.get_called_programs()
)

# Generate flow reports with entry point metadata
for ep in entry_points:
    if ep.is_explicit():
        flow = flow_analyzer.analyze_flow(ep.program_name)
        print(f"Flow for {ep.entry_type} entry point {ep.program_name}:")
        print(f"  Depth: {flow.depth}")
        print(f"  Programs: {len(flow.programs)}")
```

## Best Practices

### 1. Always Load CICS Metadata

For accurate entry point detection, always load CICS metadata when available:

```bash
# Load CICS inventory
legacy-analyzer load --type cics --file cics_inventory.csv --db analysis.db
```

### 2. Use EXPLICIT Confidence for Production

When planning modernization, focus on EXPLICIT confidence entry points:

```python
explicit_entries = [ep for ep in entry_points if ep.is_explicit()]
```

### 3. Investigate INFERRED Entry Points

INFERRED entry points may indicate:
- Missing metadata (should be in CICS/JCL)
- Utility programs (not true entry points)
- Dead code (can be removed)

Review each INFERRED entry point manually.

### 4. Include Disabled for Completeness

When analyzing the full system, include disabled entry points:

```python
all_entries = detector.detect_entry_points(include_disabled=True)
```

### 5. Export Results for Review

Export entry points to JSON for review and documentation:

```python
import json

entry_points_dict = [ep.to_dict() for ep in entry_points]
with open('entry_points.json', 'w') as f:
    json.dump(entry_points_dict, f, indent=2)
```

## Troubleshooting

### No ONLINE Entry Points Found

**Symptom**: `get_online_entry_points()` returns empty list

**Possible Causes**:
1. CICS metadata not loaded
2. `inventory_cics` table doesn't exist
3. All transactions are DISABLED

**Solution**:
```bash
# Check if table exists
sqlite3 analysis.db "SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION';"

# Load CICS metadata if missing
legacy-analyzer load --type cics --file cics_inventory.csv --db analysis.db
```

### No BATCH Entry Points Found

**Symptom**: `get_batch_entry_points()` returns empty list

**Possible Causes**:
1. JCL dependencies not loaded
2. `artifact_dependencies` table doesn't exist
3. No JCL→PROGRAM relationships in database

**Solution**:
```bash
# Check if dependencies exist
sqlite3 analysis.db "SELECT COUNT(*) FROM artifact_dependencies WHERE source_type='JCL';"

# Analyze JCL files
legacy-analyzer analyze --source-dir ./jcl --language jcl --db analysis.db
```

### Too Many INFERRED Entry Points

**Symptom**: Most entry points have INFERRED confidence

**Possible Causes**:
1. CICS/JCL metadata not loaded
2. Incomplete call graph analysis
3. Many utility programs in codebase

**Solution**:
1. Load CICS and JCL metadata
2. Ensure all programs are analyzed
3. Review INFERRED entries manually to identify utilities

## Related Documentation

- [CICS Workflows Guide](CICS_WORKFLOWS.md) - Complete CICS metadata workflows
- [Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md) - Flow analysis with entry points
- [CLI Reference](CLI_REFERENCE.md) - Command-line interface for entry point detection
- [CICS Export Guide](../legacy_analyzer/inventory/exporters/docs/CICS_EXPORT_GUIDE.md) - Exporting CICS metadata from mainframe

## API Reference

### EntryPointDetector Class

```python
class EntryPointDetector:
    def __init__(self, db_connection: sqlite3.Connection)
    
    def get_online_entry_points(
        self,
        include_disabled: bool = False
    ) -> List[EntryPoint]
    
    def get_batch_entry_points(self) -> List[EntryPoint]
    
    def get_inferred_entry_points(
        self,
        all_programs: Set[str],
        called_programs: Set[str]
    ) -> List[EntryPoint]
    
    def detect_entry_points(
        self,
        all_programs: Optional[Set[str]] = None,
        called_programs: Optional[Set[str]] = None,
        include_disabled: bool = False,
        include_inferred: bool = True
    ) -> List[EntryPoint]
    
    def get_entry_point_statistics(
        self,
        entry_points: List[EntryPoint]
    ) -> Dict[str, any]
```

### EntryPoint Model

```python
@dataclass
class EntryPoint:
    program_name: str
    entry_type: str          # ONLINE, BATCH, INFERRED
    confidence: str          # EXPLICIT, INFERRED
    source: str              # CSD, JCL, CODE_ANALYSIS
    
    # ONLINE specific
    transaction_id: Optional[str] = None
    cics_group: Optional[str] = None
    mapset_name: Optional[str] = None
    
    # BATCH specific
    jcl_name: Optional[str] = None
    job_name: Optional[str] = None
    
    # Common
    status: Optional[str] = None
    description: Optional[str] = None
    
    def to_dict(self) -> Dict[str, any]
    def is_explicit(self) -> bool
    def is_inferred(self) -> bool
    def is_enabled(self) -> bool
```

## Conclusion

The Entry Point Detection system provides a robust, multi-source approach to identifying application entry points with confidence scoring. By combining CICS metadata, JCL dependencies, and code analysis, it delivers comprehensive and accurate results for modernization planning and analysis.
