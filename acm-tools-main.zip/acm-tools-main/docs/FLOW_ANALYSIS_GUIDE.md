# Program Flow Analysis Guide

## Overview

Program flow analysis helps you understand how programs call each other and interact within your legacy system. This guide explains how to analyze program flows, detect circular dependencies, and visualize call graphs.

## What is Program Flow Analysis?

Program flow analysis traces the execution path through a system by following program calls. Starting from an entry point program, it recursively identifies all programs that are called, building a complete picture of the program call hierarchy.

### Key Concepts

- **Entry Point**: A program that is not called by any other program (typically batch jobs or CICS transactions)
- **Call Depth**: The number of levels in the call hierarchy
- **Call Graph**: A directed graph showing all program-to-program relationships
- **Circular Dependency**: A cycle where Program A calls Program B, which eventually calls Program A
- **Entry Point Types**: 
  - **ONLINE**: CICS transactions (from CSD metadata)
  - **BATCH**: JCL jobs (from JCL dependencies)
  - **INFERRED**: Programs not called by others (from code analysis)
- **Confidence Levels**:
  - **EXPLICIT**: Entry point identified from metadata (CICS, JCL)
  - **INFERRED**: Entry point inferred from code analysis

## Quick Start

### Analyze a Single Program Flow

```bash
python -m legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db analyzer.db \
    --output payroll_flow.json
```

### Visualize the Flow

```bash
# Generate Mermaid diagram
python -m legacy_analyzer flow visualize \
    --program PAYROLL1 \
    --format mermaid \
    --output payroll_flow.mmd \
    --db analyzer.db

# Generate Graphviz DOT format
python -m legacy_analyzer flow visualize \
    --program PAYROLL1 \
    --format dot \
    --output payroll_flow.dot \
    --db analyzer.db
```

### Detect Circular Dependencies

```bash
python -m legacy_analyzer flow detect-circular \
    --db analyzer.db \
    --output circular_deps.csv
```

## Detailed Usage

### 1. Analyzing Program Flows

#### Single Program Analysis

```python
from legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
from smf_loader.databases import SQLiteAdapter

database = SQLiteAdapter('analyzer.db')
database.connect()

analyzer = FlowAnalyzer(database)

# Analyze flow starting from PAYROLL1
flow = analyzer.analyze_flow('PAYROLL1', max_depth=10)

print(f"Start Program: {flow.start_program}")
print(f"Flow Depth: {flow.depth}")
print(f"Total Programs: {len(flow.programs)}")
print(f"Programs: {', '.join(flow.programs)}")

database.close()
```

#### Batch Analysis

```python
# Analyze multiple entry points
entry_points = ['PAYROLL1', 'BILLING1', 'CUSTMGMT']

flows = {}
for program in entry_points:
    flow = analyzer.analyze_flow(program, max_depth=10)
    flows[program] = flow
    print(f"{program}: {len(flow.programs)} programs, depth {flow.depth}")
```

### 2. Building Call Graphs

A call graph shows all program-to-program relationships in your system.

```python
from tools.legacy_analyzer.analysis.call_graph import CallGraph

# Build call graph for multiple programs
programs = ['PAYROLL1', 'PAYCALC', 'TAXCALC', 'DBACCESS']
call_graph = analyzer.build_call_graph(programs)

print(f"Nodes: {len(call_graph.nodes)}")
print(f"Edges: {len(call_graph.edges)}")

# Print call relationships
for caller, callee in call_graph.edges:
    print(f"{caller} -> {callee}")
```

### 3. Detecting Circular Dependencies

Circular dependencies can cause issues during migration and should be identified early.

```python
# Detect all circular dependencies
circular_deps = analyzer.detect_circular_dependencies()

if circular_deps:
    print(f"Found {len(circular_deps)} circular dependency chain(s):")
    for i, cycle in enumerate(circular_deps, 1):
        print(f"Cycle {i}: {' -> '.join(cycle.programs)} -> {cycle.programs[0]}")
else:
    print("No circular dependencies found")
```

### 4. Calculating Flow Depth

Flow depth indicates how many levels deep a program is in the call hierarchy.

```python
# Calculate depth for multiple programs
programs = ['PAYROLL1', 'PAYCALC', 'TAXCALC', 'DBACCESS']

for program in programs:
    depth = analyzer.calculate_flow_depth(program)
    print(f"{program}: depth = {depth}")
```

## Visualization

### Mermaid Format

Mermaid diagrams can be embedded in Markdown documentation:

```python
# Generate Mermaid diagram
mermaid_output = flow.to_mermaid()

# Save to file
with open('flow_diagram.mmd', 'w') as f:
    f.write(mermaid_output)
```

Example Mermaid output:

```mermaid
graph TD
    PAYROLL1[PAYROLL1]
    PAYCALC[PAYCALC]
    TAXCALC[TAXCALC]
    DBACCESS[DBACCESS]
    
    PAYROLL1 --> PAYCALC
    PAYROLL1 --> TAXCALC
    PAYCALC --> DBACCESS
    TAXCALC --> DBACCESS
```

### Graphviz DOT Format

DOT format can be rendered with Graphviz tools:

```python
# Generate DOT format
dot_output = flow.to_dot()

# Save to file
with open('flow_diagram.dot', 'w') as f:
    f.write(dot_output)

# Render with Graphviz
# dot -Tpng flow_diagram.dot -o flow_diagram.png
```

### JSON Format

JSON format is useful for programmatic processing:

```python
# Generate JSON
json_output = flow.to_json()

# Save to file
with open('flow_data.json', 'w') as f:
    f.write(json_output)
```

## CICS Metadata Integration

### Overview

When CICS metadata is available (from CSD files or CSV exports), the flow analyzer can provide enhanced entry point detection with explicit transaction IDs and confidence levels.

### Prerequisites

1. Load CICS metadata into the database:
```bash
# From CSD file
python -m legacy_analyzer metadata convert-csd \
    --input app/csd/CARDDEMO.csd \
    --output cics_inventory.csv

python -m legacy_analyzer load \
    --type cics \
    --file cics_inventory.csv \
    --db analyzer.db

# Or use integrated workflow
python -m legacy_analyzer metadata load-from-source \
    --source-dir ./app \
    --db analyzer.db
```

2. Initialize FlowAnalyzer with database connection:
```python
import sqlite3
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer

conn = sqlite3.connect('analyzer.db')
analyzer = FlowAnalyzer(dependencies, db_connection=conn)
```

### Entry Point Detection with Metadata

```python
# Get entry points with full metadata
entry_points = analyzer.get_entry_points_with_metadata()

# Categorize by type
online = [ep for ep in entry_points if ep.entry_type == 'ONLINE']
batch = [ep for ep in entry_points if ep.entry_type == 'BATCH']
inferred = [ep for ep in entry_points if ep.entry_type == 'INFERRED']

print(f"ONLINE (CICS): {len(online)}")
print(f"BATCH (JCL): {len(batch)}")
print(f"INFERRED (Code): {len(inferred)}")

# Analyze CICS transaction flows
for ep in online:
    print(f"\nTransaction: {ep.transaction_id}")
    print(f"Program: {ep.program_name}")
    print(f"Group: {ep.cics_group}")
    print(f"Status: {ep.status}")
    
    # Analyze the flow
    flow = analyzer.analyze_flow(ep.program_name)
    print(f"Flow depth: {flow.depth}")
    print(f"Programs called: {len(flow.programs)}")
```

### Fallback Behavior

If CICS metadata is not available, the analyzer automatically falls back to code-based analysis:

```python
# Without database connection - uses code analysis
analyzer = FlowAnalyzer(dependencies)
entry_points = analyzer.get_entry_points_with_metadata()

# All entry points will have:
# - entry_type = 'INFERRED'
# - confidence = 'INFERRED'
# - source = 'CODE_ANALYSIS'
```

### Priority and Deduplication

When a program appears in multiple sources, the analyzer uses priority:
1. **ONLINE** (CICS transactions) - highest priority
2. **BATCH** (JCL jobs) - medium priority
3. **INFERRED** (code analysis) - lowest priority

```python
# Example: PROG1 is both a CICS transaction and called by JCL
# Result: PROG1 will be classified as ONLINE (higher priority)
entry_points = analyzer.get_entry_points_with_metadata()
prog1 = [ep for ep in entry_points if ep.program_name == 'PROG1'][0]
assert prog1.entry_type == 'ONLINE'
assert prog1.transaction_id is not None
```

## Advanced Features

### Including Copybooks and Datasets

By default, flow analysis focuses on program-to-program calls. You can include copybooks and datasets:

```python
# Analyze with copybooks and datasets
flow = analyzer.analyze_flow(
    'PAYROLL1',
    max_depth=10,
    include_copybooks=True,
    include_datasets=True
)
```

### Filtering by Dependency Type

```python
# Only include CALL dependencies (exclude CICS LINK, XCTL)
flow = analyzer.analyze_flow(
    'PAYROLL1',
    max_depth=10,
    dependency_types=['CALL']
)
```

### Limiting Flow Depth

For very deep call hierarchies, limit the depth to improve performance:

```python
# Limit to 5 levels
flow = analyzer.analyze_flow('PAYROLL1', max_depth=5)
```

## Persisting Flows

### Save Flow to Database

```python
from tools.legacy_analyzer.analysis.flow_database import FlowDatabase

flow_db = FlowDatabase('analyzer.db')

# Save flow
flow_id = flow_db.save_flow(flow)
print(f"Saved flow with ID: {flow_id}")

# Load flow later
loaded_flow = flow_db.load_flow(flow_id)
```

### Export Flow Data

```python
# Export to CSV
flow.to_csv('flow_data.csv')

# Export to JSON
flow.to_json('flow_data.json')
```

## Use Cases

### Enhanced Entry Point Detection with Metadata

The flow analyzer now supports enhanced entry point detection using CICS metadata and JCL dependencies. This provides more accurate entry point identification with confidence levels.

#### Using Metadata-Based Entry Point Detection

```python
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer
import sqlite3

# Connect to database with CICS metadata
conn = sqlite3.connect('analyzer.db')

# Create analyzer with database connection
analyzer = FlowAnalyzer(dependencies, db_connection=conn)

# Get entry points with metadata (returns EntryPoint objects)
entry_points = analyzer.get_entry_points_with_metadata()

for ep in entry_points:
    print(f"Program: {ep.program_name}")
    print(f"  Type: {ep.entry_type}")  # ONLINE, BATCH, or INFERRED
    print(f"  Confidence: {ep.confidence}")  # EXPLICIT or INFERRED
    print(f"  Source: {ep.source}")  # CSD, JCL, or CODE_ANALYSIS
    
    if ep.entry_type == 'ONLINE':
        print(f"  Transaction ID: {ep.transaction_id}")
        print(f"  CICS Group: {ep.cics_group}")
    elif ep.entry_type == 'BATCH':
        print(f"  JCL Name: {ep.jcl_name}")
    print()

conn.close()
```

#### Backward Compatible Entry Point Detection

```python
# Traditional method (returns list of program names)
entry_points = analyzer.get_entry_points()

# With metadata enabled (still returns list of program names)
entry_points = analyzer.get_entry_points(use_metadata=True)

# Include disabled CICS transactions
entry_points = analyzer.get_entry_points(
    use_metadata=True,
    include_disabled=True
)
```

#### Filtering Entry Points

```python
# Get only ONLINE entry points (CICS transactions)
online_entries = [ep for ep in entry_points if ep.entry_type == 'ONLINE']

# Get only EXPLICIT entry points (from metadata)
explicit_entries = [ep for ep in entry_points if ep.confidence == 'EXPLICIT']

# Get enabled entry points only
enabled_entries = [ep for ep in entry_points if ep.is_enabled()]
```

### 1. Understanding System Architecture

Analyze entry points to understand system structure:

```bash
# Find all entry points (with metadata if available)
python -m legacy_analyzer flow entry-points \
    --db analyzer.db \
    --use-metadata \
    --format json \
    --output entry_points.json

# Include disabled CICS transactions
python -m legacy_analyzer flow entry-points \
    --db analyzer.db \
    --use-metadata \
    --include-disabled \
    --format json \
    --output entry_points_all.json

# Analyze each entry point
# Extract program names from JSON and analyze
python -m legacy_analyzer flow analyze \
    --program PROGRAM_NAME \
    --db analyzer.db \
    --output flows/PROGRAM_NAME_flow.json
```

### 2. Impact Analysis

Determine what programs are affected by changes:

```bash
# Find all programs that call DBACCESS
python -m legacy_analyzer flow reverse \
    --program DBACCESS \
    --db analyzer.db \
    --output dbaccess_callers.csv
```

### 3. Migration Planning

Identify self-contained subsystems for migration:

```bash
# Analyze flow for migration package
python -m legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db analyzer.db \
    --output payroll_flow.json

# Check for external dependencies
python -m legacy_analyzer flow external-deps \
    --program PAYROLL1 \
    --db analyzer.db
```

### 4. Circular Dependency Resolution

Find and document circular dependencies:

```bash
# Detect circular dependencies
python -m legacy_analyzer flow detect-circular \
    --db analyzer.db \
    --output circular_deps.csv

# Visualize circular dependencies
python -m legacy_analyzer flow visualize-circular \
    --db analyzer.db \
    --output circular_deps.mmd
```

## Configuration

Configure flow analysis in `config/legacy_analyzer.yaml`:

```yaml
analysis:
  # Maximum depth for recursive flow analysis
  max_flow_depth: 10
  
  # Enable circular dependency detection
  enable_circular_detection: true
  
  # Include copybooks in flow analysis
  include_copybooks: true
  
  # Include datasets in flow analysis
  include_datasets: true

visualization:
  # Default graph format
  graph_format: "mermaid"
  
  # Graph layout direction
  layout_direction: "TB"  # Top-to-bottom
  
  # Maximum nodes in visualization
  max_nodes: 500
```

## Performance Tips

1. **Limit Depth**: Use `max_depth` to prevent analyzing very deep hierarchies
2. **Cache Results**: Enable caching to avoid re-analyzing unchanged flows
3. **Parallel Processing**: Analyze multiple flows in parallel
4. **Filter Dependencies**: Only include relevant dependency types

## Troubleshooting

### Issue: Flow Analysis is Slow

**Solutions**:
- Reduce `max_flow_depth`
- Enable caching
- Use parallel processing
- Filter by dependency type

### Issue: Circular Dependencies Detected

**Solutions**:
- Document the circular dependencies
- Refactor code to break cycles
- Migrate circular groups together
- Use interfaces to break dependencies

### Issue: Missing Programs in Flow

**Solutions**:
- Check inventory completeness
- Verify source code was analyzed
- Check for dynamic calls (CALL with variable)
- Review parser logs for errors

### Issue: Visualization Too Large

**Solutions**:
- Reduce `max_flow_depth`
- Filter by dependency type
- Split into multiple diagrams
- Use `max_nodes` limit

## Best Practices

1. **Start with Entry Points**: Begin analysis from entry point programs
2. **Document Circular Dependencies**: Record all circular dependencies found
3. **Validate Flows**: Review generated flows for accuracy
4. **Use Visualizations**: Visual diagrams help communicate architecture
5. **Track Changes**: Re-analyze flows after code changes
6. **Combine with Complexity**: Use flow analysis with complexity metrics

## Next Steps

- [Complexity Analysis Guide](COMPLEXITY_GUIDE.md) - Assess program complexity
- [Migration Packages Guide](MIGRATION_PACKAGES_GUIDE.md) - Plan migration packages
- [Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md) - Complete migration process
- [API Reference](API_REFERENCE.md) - Python API documentation

## Examples

See `examples/flow_analysis_example.py` for complete working examples.
