# Comprehensive ROI Migration Assessment Query

## Overview

The **Comprehensive ROI Assessment** query is a unified, cohesive query that integrates all aspects of migration analysis into a single report. It eliminates the disconnect between individual queries by building a complete financial analysis from the ground up.

## Problem Solved

Previously, the dashboard had disconnected queries:
- **AWS Cost Query**: Used hardcoded parameters (10 instances) unrelated to actual workload
- **MIPS-Based EC2 Sizing**: Calculated 1 vCPU needed, but wasn't used by AWS Cost
- **Batch Workload CPU Query**: Showed 56,994 cores (incorrect calculation)
- **CICS Workload CPU Query**: Showed 1 core
- **Migration ROI Query**: Used placeholder values ($1,000,000)

These queries didn't build on each other, creating confusion and inconsistent results.

## Solution: Integrated Analysis

The Comprehensive ROI Assessment query performs a **complete end-to-end analysis**:

### Step 1: Analyze MIPS Consumption (from SMF Type 30)
```sql
-- Calculates daily MIPS consumption
-- Determines average, 95th percentile, and peak MIPS
```

### Step 2: Calculate Mainframe Costs (MSU-based)
```sql
-- Uses 4-hour rolling window (IBM pricing model)
-- Calculates peak MSU and annual mainframe cost
```

### Step 3: Determine vCPU Requirements
```sql
-- Converts MIPS to vCPUs using configurable ratio (default: 100 MIPS/vCPU)
-- Provides 3 sizing scenarios:
--   - MINIMUM: Based on average MIPS (lowest cost, highest risk)
--   - RECOMMENDED: Based on 95th percentile (balanced approach)
--   - MAXIMUM: Based on peak MIPS (handles all spikes)
```

### Step 4: Map to EC2 Instance Types
```sql
-- Maps vCPU requirements to actual EC2 instances:
--   1 vCPU  → c6i.medium
--   2 vCPUs → c6i.large
--   4 vCPUs → c6i.xlarge
--   8 vCPUs → c6i.2xlarge
-- Calculates instance count if >8 vCPUs needed
```

### Step 5: Calculate AWS Infrastructure Costs
```sql
-- EC2 compute costs (based on actual sizing)
-- EBS storage costs (configurable)
-- RDS database costs (configurable)
-- AWS Support costs (10% of infrastructure)
```

### Step 6: Estimate Migration Costs (from Inventory)
```sql
-- Assessment and planning costs
-- Code conversion costs (per program)
-- Testing and validation costs
-- Training costs
-- Contingency (20%)
```

### Step 7: Calculate Multi-Year TCO and ROI
```sql
-- Year-by-year cost comparison
-- Payback period calculation
-- 5-year (configurable) total savings
-- ROI percentage
```

## Query Parameters

### Sizing Scenario (Required)
- **minimum**: Use average MIPS (cost-optimized with auto-scaling)
- **recommended**: Use 95th percentile MIPS (balanced approach) ⭐ **DEFAULT**
- **maximum**: Use peak MIPS (guaranteed performance)

### Storage Parameters (Optional)
- **ebs_storage_gb**: Total EBS storage in GB (default: 10,000)
- **rds_instance_count**: Number of RDS instances (default: 2)
- **rds_storage_gb**: Total RDS storage in GB (default: 5,000)

### Analysis Period
- **analysis_days**: Days of SMF data to analyze (default: 365)

## Configuration Parameters

All pricing and conversion factors are configurable via the Configuration tab:

### MIPS/vCPU Conversion
- **MIPS_PER_VCPU**: MIPS per AWS vCPU (default: 100)
- **SERVICE_UNITS_PER_MIPS_HOUR**: Conversion factor (default: 3,600,000)

### Mainframe Costs (MSU Pricing)
- **MSU_COST_PER_MONTH_TIER1**: $/MSU/month for peak ≤3 MSU (default: $4,000)

### AWS EC2 Pricing (us-east-1)
- **EC2_C6I_MEDIUM_HOURLY**: $0.0425 (1 vCPU)
- **EC2_C6I_LARGE_HOURLY**: $0.085 (2 vCPUs)
- **EC2_C6I_XLARGE_HOURLY**: $0.17 (4 vCPUs)
- **EC2_C6I_2XLARGE_HOURLY**: $0.34 (8 vCPUs)

### AWS Storage Pricing
- **EBS_GP3_STORAGE_COST**: $0.08/GB-month
- **RDS_M6I_LARGE_HOURLY**: $0.192/hour
- **RDS_GP3_STORAGE_COST**: $0.115/GB-month

### AWS Support
- **AWS_SUPPORT_PERCENTAGE**: 10% of infrastructure cost

### Migration Costs
- **MIGRATION_ASSESSMENT_COST**: $50,000
- **MIGRATION_COST_PER_PROGRAM**: $500
- **MIGRATION_TESTING_COST**: $100,000
- **MIGRATION_TRAINING_COST**: $50,000
- **MIGRATION_CONTINGENCY_RATIO**: 20%

### Time Parameters
- **HOURS_PER_MONTH**: 730
- **MIGRATION_DURATION_MONTHS**: 24
- **ANALYSIS_YEARS**: 5

## Output Columns

### Infrastructure Sizing
- `sizing_scenario`: Which scenario was used (minimum/recommended/maximum)
- `vcpus_needed`: Exact vCPU requirement (decimal)
- `vcpus_actual`: Rounded vCPU count (1, 2, 4, 8, etc.)
- `instance_count`: Number of EC2 instances needed
- `instance_type`: EC2 instance type (c6i.medium, c6i.large, etc.)
- `avg_mips`: Average MIPS consumption
- `p95_mips`: 95th percentile MIPS
- `peak_mips`: Peak MIPS consumption

### Annual Costs
- `annual_mainframe_cost`: Current mainframe cost (MSU-based)
- `annual_aws_cost`: Projected AWS cost (all services)
- `annual_savings`: Annual cost savings

### Migration Costs
- `total_migration_cost`: Total one-time migration cost
- `migration_duration_months`: Expected migration duration
- `migration_assessment`: Assessment and planning cost
- `migration_code_conversion`: Code conversion cost
- `migration_testing`: Testing cost
- `migration_training`: Training cost
- `migration_contingency`: Contingency buffer

### ROI Metrics
- `payback_period_years`: Years to recover migration investment
- `mainframe_5year_tco`: 5-year mainframe total cost
- `aws_5year_tco`: 5-year AWS total cost (including migration)
- `total_5year_savings`: Total savings over 5 years
- `roi_percentage_5year`: ROI as percentage of migration investment

### Monthly Breakdown
- `monthly_ec2_cost`: Monthly EC2 compute cost
- `monthly_ebs_cost`: Monthly EBS storage cost
- `monthly_rds_cost`: Monthly RDS database cost
- `monthly_aws_total`: Total monthly AWS cost (with support)

## Example Output

```
Sizing Scenario: recommended
vCPUs Needed: 0.18
vCPUs Actual: 1
Instance Count: 1
Instance Type: c6i.medium
Avg MIPS: 0.091
P95 MIPS: 0.182
Peak MIPS: 0.298

Annual Mainframe Cost: $24,567
Annual AWS Cost: $1,491
Annual Savings: $23,076

Total Migration Cost: $120,000
Payback Period: 0.52 years (6.2 months)

5-Year Mainframe TCO: $122,835
5-Year AWS TCO: $127,455
5-Year Total Savings: $115,380
ROI: 96.2%

Monthly EC2 Cost: $31
Monthly EBS Cost: $800
Monthly RDS Cost: $281
Monthly AWS Total: $1,224
```

## Usage in Dashboard

### ROI Analysis Tab
1. Select "Comprehensive ROI Assessment" query
2. Choose sizing scenario (recommended is default)
3. Adjust storage parameters if needed
4. Click "Execute Query"
5. View complete ROI report with all metrics

### Summary Cards
The dashboard automatically extracts key metrics for the summary cards:
- **Total Annual Cost**: `annual_aws_cost`
- **Annual Savings**: `annual_savings`
- **Payback Period**: `payback_period_years`
- **5-Year ROI**: `roi_percentage_5year`

## Comparison with Individual Queries

| Aspect | Old Approach | New Comprehensive Query |
|--------|-------------|------------------------|
| **Infrastructure Sizing** | Separate query, results not used | Integrated: MIPS → vCPUs → instances |
| **AWS Costs** | Hardcoded 10 instances | Calculated from actual MIPS data |
| **Mainframe Costs** | Separate MSU query | Integrated MSU calculation |
| **Migration Costs** | Placeholder $1M | Calculated from inventory |
| **Consistency** | Disconnected results | Single cohesive analysis |
| **Usability** | Run 5+ queries manually | One query, complete report |

## Benefits

1. **Consistency**: All calculations use the same data and assumptions
2. **Traceability**: See how MIPS → vCPUs → instances → costs
3. **Accuracy**: No hardcoded values, everything calculated from actual data
4. **Simplicity**: One query instead of 5+ separate queries
5. **Completeness**: Includes all aspects: sizing, costs, migration, ROI
6. **Flexibility**: Three sizing scenarios for different risk profiles
7. **Configurability**: All parameters adjustable via Configuration tab

## When to Use Each Sizing Scenario

### MINIMUM (Average MIPS)
- **Use when**: You have auto-scaling configured
- **Risk**: May not handle peak loads without scaling
- **Cost**: Lowest baseline cost
- **Best for**: Cost-sensitive migrations with elastic workloads

### RECOMMENDED (95th Percentile) ⭐
- **Use when**: You want balanced cost and performance
- **Risk**: Handles 95% of workload, occasional spikes may need scaling
- **Cost**: Moderate
- **Best for**: Most migrations (default choice)

### MAXIMUM (Peak MIPS)
- **Use when**: You need guaranteed performance for all workloads
- **Risk**: Lowest risk, may be over-provisioned
- **Cost**: Highest
- **Best for**: Mission-critical systems, no auto-scaling

## Technical Notes

### Data Sources
- **SMF Type 30**: MIPS consumption, MSU calculation
- **Inventory Tables**: Program counts for migration costs
- **Configuration**: All pricing and conversion factors

### Calculation Flow
```
SMF Type 30 Data
    ↓
MIPS Analysis (avg, p95, peak)
    ↓
MSU Calculation (4-hour rolling window)
    ↓
vCPU Requirements (MIPS ÷ MIPS_PER_VCPU)
    ↓
EC2 Instance Mapping (vCPUs → instance type)
    ↓
AWS Cost Calculation (EC2 + EBS + RDS + Support)
    ↓
Migration Cost Estimation (inventory + fixed costs)
    ↓
Multi-Year TCO & ROI
```

### Why This Approach Works

1. **Single Source of Truth**: All calculations use the same SMF data
2. **Logical Flow**: Each step builds on the previous one
3. **No Hardcoded Values**: Everything calculated or configurable
4. **Realistic Sizing**: Based on actual workload patterns
5. **Complete Picture**: Includes all cost components

## Future Enhancements

Potential additions to the query:
- Network transfer costs (data egress)
- CloudWatch monitoring costs
- Backup and disaster recovery costs
- Multi-region deployment costs
- Reserved instance pricing options
- Savings Plans calculations
- Year-by-year cost breakdown table
