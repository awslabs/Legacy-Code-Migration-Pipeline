# Getting Started with Legacy Analyzer

## Overview

The Legacy Analyzer is a comprehensive system for analyzing legacy applications to support modernization and migration initiatives. It provides:

- **Inventory Management**: Load and track mainframe artifacts
- **Static Code Analysis**: Extract dependencies from source code
- **Program Flow Analysis**: Visualize program call hierarchies
- **Complexity Assessment**: Calculate complexity metrics
- **Missing Code Detection**: Identify incomplete inventory
- **Migration Package Planning**: Group artifacts for migration
- **Artifact Lifecycle Analysis**: Find unreferenced and missing artifacts

This guide will get you up and running quickly.

## What You'll Need

1. **SMF Data**: SMF records (Types 14, 15, 17, 30, 62, 64, 110) covering your analysis period
2. **Inventory Data**: CSV exports of your mainframe artifacts (JCL, programs, datasets, etc.)
3. **Python 3.8+**: With the SMF Toolkit installed
4. **SQLite**: For the analysis database (included with Python)

## Quick Start (5 Minutes)

### Step 1: Parse SMF Records

Parse your SMF data to create the usage database:

```bash
# Parse SMF Type 30 (batch jobs)
python -m smf_record_parser examples/SMF_30.rdw --output smf_records.json

# Load into database
python -m smf_loader load --input smf_records.json --database smf_analytics.db
```

### Step 2: Load Inventory Data

Load your mainframe inventory catalogs:

```bash
# Load JCL inventory
python -m legacy_analyzer load --type jcl \
    --file examples/INV_TEST_jcl.csv \
    --db smf_analytics.db

# Load program inventory
python -m legacy_analyzer load --type programs \
    --file examples/INV_TEST_programs.csv \
    --db smf_analytics.db

# Load dataset inventory
python -m legacy_analyzer load --type datasets \
    --file examples/INV_TEST_datasets.csv \
    --db smf_analytics.db
```

### Step 3: Run Analysis Queries

Identify unreferenced artifacts:

```bash
# Find unreferenced JCL (not executed in last 365 days)
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_jcl \
    --params analysis_days=365 \
    --format table

# Find unreferenced programs
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_programs \
    --params analysis_days=365 \
    --format table

# Find unreferenced datasets
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_datasets \
    --params analysis_days=365 \
    --format table
```

### Step 4: Generate Reports

Create a comprehensive analysis report:

```bash
python -m legacy_analyzer report \
    --db smf_analytics.db \
    --output-dir reports/ \
    --format markdown
```

## Understanding the Results

### Unreferenced Artifacts

Artifacts that exist in inventory but haven't been used within the analysis window:

- **JCL**: Job names not found in SMF Type 30 execution records
- **Programs**: Programs not executed in batch (Type 30) or CICS (Type 110)
- **Datasets**: Datasets not accessed in Types 14, 15, 17, 30, 62, 64

### Missing Artifacts

Artifacts referenced in SMF records but not found in inventory:

- Indicates incomplete inventory
- May represent shadow IT or undocumented systems
- Should be investigated and added to inventory

### Risk Levels

- **HIGH**: Matches critical patterns (DR%, YEAREND%, AUDIT%)
- **MEDIUM**: Has dependencies from other artifacts
- **LOW**: Standalone with no critical patterns

## Next Steps

1. **Review Results**: Examine the unreferenced artifacts report
2. **Assess Risk**: Run risk assessment to categorize artifacts
3. **Analyze Dependencies**: Check what depends on each artifact
4. **Plan Cleanup**: Generate prioritized cleanup recommendations
5. **Execute**: Archive or remove low-risk unreferenced artifacts

## Common Workflows

### Workflow 1: Initial Assessment

```bash
# 1. Load all data
python -m smf_loader load --input smf_records.json --database smf_analytics.db
python -m legacy_analyzer load --type jcl --file jcl_inventory.csv --db smf_analytics.db
python -m legacy_analyzer load --type programs --file program_inventory.csv --db smf_analytics.db
python -m legacy_analyzer load --type datasets --file dataset_inventory.csv --db smf_analytics.db

# 2. Run comprehensive analysis
python -m legacy_analyzer report --db smf_analytics.db --output-dir reports/

# 3. Review reports/ARTIFACT_ANALYSIS_REPORT.md
```

### Workflow 2: Cleanup Planning

```bash
# 1. Assess risk
python -m smf_queries run --db smf_analytics.db \
    --query artifact_risk_assessment \
    --format csv --output risk_assessment.csv

# 2. Get cleanup recommendations
python -m smf_queries run --db smf_analytics.db \
    --query cleanup_recommendations \
    --params top_n=100 \
    --format csv --output cleanup_plan.csv

# 3. Review and prioritize in Excel/spreadsheet
```

### Workflow 3: Dependency Analysis

```bash
# 1. Analyze source code for dependencies
python -m legacy_analyzer analyze \
    --source-dir /path/to/cobol \
    --language COBOL \
    --db smf_analytics.db

# 2. Check dependencies for specific artifact
python -m smf_queries run --db smf_analytics.db \
    --query artifact_dependencies \
    --params artifact_name=MYPROG01 \
    --format table
```

## Configuration

Customize analysis parameters in `config/artifact_analysis.yaml`:

```yaml
analysis:
  default_window_days: 365  # Analysis period
  min_usage_threshold: 1    # Minimum usage count

risk_patterns:
  high_risk:
    - pattern: "DR%"
      reason: "Disaster Recovery"
    - pattern: "YEAREND%"
      reason: "Year-end Processing"
```

## Troubleshooting

### No Results Returned

- **Check data**: Verify SMF records and inventory were loaded
- **Check dates**: Ensure SMF data covers the analysis window
- **Check names**: Verify naming conventions match (case sensitivity)

### Performance Issues

- **Add indexes**: Database indexes are created automatically
- **Reduce window**: Use shorter analysis_days parameter
- **Batch processing**: Process large datasets in chunks

### Missing Dependencies

- **Run static analysis**: Analyze source code to find dependencies
- **Check file paths**: Ensure source code paths are correct
- **Verify language**: Specify correct language (COBOL, JCL, PLI)

## Getting Help

- **Documentation**: See docs/ directory for detailed guides
- **Examples**: Check examples/ directory for sample scripts
- **Issues**: Report problems on the project repository

## What's Next?

### Core Guides
- **[Inventory Guide](INVENTORY_GUIDE.md)**: Learn how to export and load inventory data
- **[Static Analysis Guide](STATIC_ANALYSIS_GUIDE.md)**: Extract dependencies from source code
- **[Query Reference](QUERY_REFERENCE.md)**: Explore all available queries

### Analysis Guides
- **[Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md)**: Analyze program flows and call graphs
- **[Complexity Guide](COMPLEXITY_GUIDE.md)**: Assess program complexity
- **[Risk Assessment Guide](RISK_ASSESSMENT_GUIDE.md)**: Understand risk classification

### Migration Guides
- **[Migration Packages Guide](MIGRATION_PACKAGES_GUIDE.md)**: Plan migration packages
- **[Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md)**: Complete migration process
- **[Cleanup Workflow](CLEANUP_WORKFLOW.md)**: Follow the complete cleanup process

### Reference
- **[API Reference](API_REFERENCE.md)**: Python API documentation
- **[CLI Reference](CLI_REFERENCE.md)**: Command-line interface
