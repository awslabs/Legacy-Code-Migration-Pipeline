# Complexity Analysis Guide

## Overview

Complexity analysis helps you assess the difficulty of migrating each artifact by calculating metrics like lines of code, cyclomatic complexity, and dependency counts. This guide explains how to analyze complexity and use the results for migration planning.

## What is Complexity Analysis?

Complexity analysis evaluates programs based on multiple factors:

- **Lines of Code (LOC)**: Size of the program
- **Cyclomatic Complexity**: Number of decision points (IF, PERFORM, EVALUATE)
- **Dependency Count**: Number of incoming and outgoing dependencies
- **Composite Score**: Weighted combination of all metrics
- **Complexity Tier**: Classification (LOW, MEDIUM, HIGH, VERY_HIGH)

## Quick Start

### Analyze All Programs

```bash
python -m legacy_analyzer complexity analyze \
    --db analyzer.db \
    --output complexity_metrics.csv
```

### Get Complexity Statistics

```bash
python -m legacy_analyzer complexity stats \
    --db analyzer.db
```

### Find High-Complexity Programs

```bash
python -m legacy_analyzer complexity top \
    --limit 50 \
    --db analyzer.db \
    --output high_complexity.csv
```

## Detailed Usage

### 1. Analyzing Program Complexity

#### Single Program Analysis

```python
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer

analyzer = ComplexityAnalyzer()

# Analyze COBOL program
cobol_code = """
   IDENTIFICATION DIVISION.
   PROGRAM-ID. PAYROLL1.
   
   PROCEDURE DIVISION.
       IF WS-AMOUNT > 1000
           PERFORM PROCESS-LARGE
       ELSE
           PERFORM PROCESS-SMALL
       END-IF.
       STOP RUN.
"""

metrics = analyzer.analyze_program(
    program_name='PAYROLL1',
    source_code=cobol_code,
    language='COBOL',
    dependency_count_in=5,
    dependency_count_out=10
)

print(f"Program: {metrics.program_name}")
print(f"LOC: {metrics.lines_of_code}")
print(f"Cyclomatic Complexity: {metrics.cyclomatic_complexity}")
print(f"Dependencies (In/Out): {metrics.dependency_count_in}/{metrics.dependency_count_out}")
print(f"Composite Score: {metrics.composite_score:.2f}")
print(f"Complexity Tier: {metrics.complexity_tier}")
print(f"God Program: {metrics.is_god_program}")
```

#### Batch Analysis

```python
# Analyze all programs
programs = {
    'PROG1': {'source_code': code1, 'language': 'COBOL', ...},
    'PROG2': {'source_code': code2, 'language': 'PLI', ...},
}

results = analyzer.analyze_all_programs(programs)

for name, metrics in sorted(results.items(), key=lambda x: x[1].composite_score, reverse=True):
    print(f"{name}: Score={metrics.composite_score:.2f}, Tier={metrics.complexity_tier}")
```

### 2. Understanding Complexity Metrics

#### Lines of Code (LOC)

Counts non-comment, non-blank lines:

```python
loc = metrics.lines_of_code
```

#### Cyclomatic Complexity

Counts decision points in code:

- COBOL: IF, PERFORM VARYING, EVALUATE, AND, OR
- PL/I: IF, DO WHILE, SELECT, &, |
- JCL: IF/THEN/ELSE

```python
cyclomatic = metrics.cyclomatic_complexity
```

#### Dependency Counts

```python
deps_in = metrics.dependency_count_in   # Who calls this program
deps_out = metrics.dependency_count_out  # Who this program calls
```

#### Composite Score

Weighted combination of all metrics:

```
composite_score = (LOC * loc_weight) + 
                  (cyclomatic * cyclomatic_weight) + 
                  ((deps_in + deps_out) * deps_weight)
```

Default weights:
- LOC: 0.3
- Cyclomatic: 0.4
- Dependencies: 0.3

```python
score = metrics.composite_score
```

#### Complexity Tiers

Programs are classified into tiers based on composite score:

- **LOW**: Score ≤ 10 (easy to migrate)
- **MEDIUM**: Score ≤ 25 (moderate effort)
- **HIGH**: Score ≤ 50 (significant effort)
- **VERY_HIGH**: Score > 50 (very difficult)

```python
tier = metrics.complexity_tier  # 'LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH'
```

#### God Programs

Programs with excessive complexity (score > 100 by default):

```python
is_god = metrics.is_god_program  # True/False
```

### 3. Custom Thresholds

Customize complexity thresholds for your project:

```python
from tools.legacy_analyzer.models.complexity import ComplexityThresholds

custom_thresholds = ComplexityThresholds(
    low_threshold=15.0,
    medium_threshold=35.0,
    high_threshold=70.0,
    loc_weight=0.25,
    cyclomatic_weight=0.45,
    deps_weight=0.30
)

analyzer = ComplexityAnalyzer(thresholds=custom_thresholds)
```

### 4. Maintainability Index

Calculate maintainability index (0-100, higher is better):

```python
mi = metrics.get_maintainability_index()
print(f"Maintainability Index: {mi:.2f}")

# Interpretation:
# 85-100: Highly maintainable
# 65-85: Moderately maintainable
# 0-65: Difficult to maintain
```

## Use Cases

### 1. Migration Effort Estimation

Estimate effort based on complexity:

```python
# Get all programs with complexity
programs = database.execute_query("""
    SELECT program_name, composite_score, complexity_tier
    FROM complexity_metrics
    ORDER BY composite_score DESC
""")

# Estimate effort (example: 1 day per 10 complexity points)
total_effort = 0
for program, score, tier in programs:
    effort_days = score / 10
    total_effort += effort_days
    print(f"{program}: {effort_days:.1f} days ({tier})")

print(f"\nTotal Estimated Effort: {total_effort:.1f} days")
```

### 2. Identifying Refactoring Candidates

Find programs that should be refactored before migration:

```bash
# Get god programs
python -m legacy_analyzer complexity god-programs \
    --db analyzer.db \
    --output refactoring_candidates.csv
```

### 3. Resource Allocation

Allocate resources based on complexity distribution:

```bash
# Get complexity statistics
python -m legacy_analyzer complexity stats \
    --db analyzer.db

# Output:
# LOW: 60% - Junior developers
# MEDIUM: 30% - Mid-level developers
# HIGH: 8% - Senior developers
# VERY_HIGH: 2% - Architects
```

### 4. Risk Assessment

Identify high-risk programs:

```python
# High complexity + high usage = high risk
high_risk = database.execute_query("""
    SELECT c.program_name, c.composite_score, s.execution_count
    FROM complexity_metrics c
    JOIN smf_usage s ON c.program_name = s.program_name
    WHERE c.complexity_tier IN ('HIGH', 'VERY_HIGH')
      AND s.execution_count > 1000
    ORDER BY c.composite_score DESC
""")
```

## Configuration

Configure complexity analysis in `config/legacy_analyzer.yaml`:

```yaml
complexity:
  # Thresholds for tier classification
  thresholds:
    low: 10
    medium: 25
    high: 50
  
  # Weights for composite score
  weights:
    loc: 0.3
    cyclomatic: 0.4
    dependencies: 0.3
  
  # God program threshold
  god_program_threshold: 100
```

## Language-Specific Considerations

### COBOL

- Counts PERFORM, IF, EVALUATE, WHEN
- Handles nested IF statements
- Considers AND/OR operators

### PL/I

- Counts DO, IF, SELECT, WHEN
- Handles nested structures
- Considers & and | operators

### JCL

- Counts IF/THEN/ELSE
- Considers COND parameters
- Simpler complexity model

## Performance Tips

1. **Batch Processing**: Analyze multiple programs at once
2. **Caching**: Cache complexity results
3. **Parallel Processing**: Use multiple workers
4. **Incremental Analysis**: Only re-analyze changed programs

## Troubleshooting

### Issue: Complexity Seems Too High/Low

**Solutions**:
- Adjust thresholds in configuration
- Modify weights for your context
- Review cyclomatic complexity calculation
- Consider language-specific factors

### Issue: God Programs Not Detected

**Solutions**:
- Lower `god_program_threshold`
- Check if programs were analyzed
- Verify source code is available

### Issue: Analysis is Slow

**Solutions**:
- Enable parallel processing
- Increase `max_workers`
- Use caching
- Process in batches

## Best Practices

1. **Establish Baselines**: Analyze current system first
2. **Set Realistic Thresholds**: Adjust for your environment
3. **Track Trends**: Monitor complexity over time
4. **Combine with Other Metrics**: Use with flow analysis and usage data
5. **Refactor Before Migration**: Address god programs early
6. **Document Decisions**: Record threshold choices

## Reporting

### Generate Complexity Report

```bash
python -m legacy_analyzer complexity report \
    --db analyzer.db \
    --output complexity_report.html
```

### Export Metrics

```bash
# Export to CSV
python -m legacy_analyzer complexity export \
    --format csv \
    --output complexity_metrics.csv \
    --db analyzer.db

# Export to JSON
python -m legacy_analyzer complexity export \
    --format json \
    --output complexity_metrics.json \
    --db analyzer.db
```

## Next Steps

- [Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md) - Analyze program flows
- [Migration Packages Guide](MIGRATION_PACKAGES_GUIDE.md) - Plan migration packages
- [Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md) - Complete migration process

## Examples

See `examples/complexity_analysis_example.py` for complete working examples.
