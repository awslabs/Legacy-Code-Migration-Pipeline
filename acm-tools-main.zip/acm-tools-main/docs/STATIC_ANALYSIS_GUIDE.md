# Static Code Analysis Guide

## Overview

Static code analysis extracts dependencies from source code without executing it. This guide explains how to analyze COBOL, JCL, and PL/I code to build a complete dependency graph.

## Why Static Analysis?

Static analysis identifies dependencies that don't appear in SMF records:

- **Copybook usage**: COPY statements in COBOL
- **Program calls**: CALL statements
- **CICS links**: EXEC CICS LINK commands
- **JCL includes**: INCLUDE statements
- **Dataset references**: DD DSN= statements

These dependencies are critical for:
- Identifying unreferenced copybooks
- Understanding program relationships
- Assessing impact of removing artifacts
- Building complete dependency trees

## Supported Languages

### COBOL

Extracts:
- COPY statements (copybook dependencies)
- CALL statements (program dependencies)
- EXEC CICS LINK (CICS program dependencies)
- EXEC SQL INCLUDE (SQL copybook dependencies)

### JCL

Extracts:
- EXEC PGM= (program executions)
- EXEC PROC= (procedure calls)
- INCLUDE statements (JCL includes)
- DD DSN= (dataset references)

### PL/I

Extracts:
- %INCLUDE statements (include file dependencies)
- CALL statements (program dependencies)

## Running Static Analysis

### Basic Command

```bash
python -m legacy_analyzer analyze \
    --source-dir <DIRECTORY> \
    --language <LANGUAGE> \
    --db <DATABASE>
```

### Parameters

- `--source-dir`: Directory containing source files
- `--language`: Language (COBOL, JCL, PLI)
- `--db`: SQLite database path
- `--pattern`: File pattern (optional, default: *)
- `--recursive`: Scan subdirectories (optional)
- `--export-csv`: Export to CSV instead of loading to DB (optional)

### Examples

#### Analyze COBOL Programs

```bash
python -m legacy_analyzer analyze \
    --source-dir /path/to/cobol/source \
    --language COBOL \
    --db smf_analytics.db \
    --recursive
```

Expected output:
```
Analyzing COBOL source files...
✓ Found 234 COBOL files
✓ Analyzed 234 files
✓ Extracted 1,456 dependencies
  - 678 COPY statements
  - 345 CALL statements
  - 234 CICS LINK statements
  - 199 SQL INCLUDE statements
✓ Loaded dependencies to database
Completed in 12.3 seconds
```

#### Analyze JCL Members

```bash
python -m legacy_analyzer analyze \
    --source-dir /path/to/jcl \
    --language JCL \
    --db smf_analytics.db
```

#### Analyze PL/I Programs

```bash
python -m legacy_analyzer analyze \
    --source-dir /path/to/pli \
    --language PLI \
    --db smf_analytics.db
```

#### Export to CSV for Review

```bash
python -m legacy_analyzer analyze \
    --source-dir /path/to/cobol \
    --language COBOL \
    --export-csv dependencies.csv
```

Review the CSV before loading:
```bash
# Review dependencies
cat dependencies.csv

# Load to database
python -m legacy_analyzer.dependency_loader \
    --csv dependencies.csv \
    --database smf_analytics.db
```

## COBOL Analysis Details

### COPY Statements

Detects various COPY statement formats:

```cobol
* Simple COPY
COPY CUSTMAST.

* COPY with library
COPY ORDERHDR IN COPYLIB.
COPY ORDERHDR OF COPYLIB.

* COPY with REPLACING
COPY CUSTMAST REPLACING ==:TAG:== BY ==CUST==.

* COPY in different divisions
WORKING-STORAGE SECTION.
COPY CUSTMAST.

PROCEDURE DIVISION.
COPY ERRORHND.
```

All formats are detected and recorded as dependencies.

### CALL Statements

Detects static and dynamic calls:

```cobol
* Static call (literal)
CALL 'SUBPROG1' USING WS-PARM1 WS-PARM2.

* Dynamic call (identifier)
CALL WS-PROGRAM-NAME USING WS-PARM1.

* Call with ON EXCEPTION
CALL 'SUBPROG2' USING WS-PARM1
    ON EXCEPTION
        DISPLAY 'CALL FAILED'
    NOT ON EXCEPTION
        CONTINUE
END-CALL.
```

Static calls (literals) are recorded as dependencies. Dynamic calls are noted but cannot be resolved statically.

### CICS Commands

Detects CICS program links:

```cobol
* EXEC CICS LINK
EXEC CICS LINK
    PROGRAM('CICSPROG')
    COMMAREA(WS-COMMAREA)
    LENGTH(100)
END-EXEC.

* EXEC CICS START
EXEC CICS START
    TRANSID('PAY1')
    FROM(WS-DATA)
END-EXEC.

* EXEC CICS READ/WRITE (file references)
EXEC CICS READ
    FILE('CUSTFILE')
    INTO(CUSTOMER-RECORD)
    RIDFLD(CUSTOMER-ID)
END-EXEC.
```

### SQL Statements

Detects SQL includes and table references:

```cobol
* EXEC SQL INCLUDE
EXEC SQL INCLUDE SQLCA END-EXEC.
EXEC SQL INCLUDE CUSTOMER END-EXEC.

* Table references (for future enhancement)
EXEC SQL
    SELECT * FROM CUSTOMER
    WHERE CUST_ID = :WS-CUST-ID
END-EXEC.
```

### Handling COBOL Syntax

The analyzer handles:

- **Fixed format**: Columns 7-72
- **Free format**: Full line
- **Comments**: * in column 7
- **Continuations**: - in column 7
- **Sequence numbers**: Columns 1-6 (ignored)
- **Identification area**: Column 73+ (ignored)

## JCL Analysis Details

### EXEC Statements

Detects program and procedure executions:

```jcl
//STEP1    EXEC PGM=PAYROLL1
//STEP2    EXEC PGM=BILLING2,PARM='MONTHLY'
//STEP3    EXEC PROC=MONTHEND
//STEP4    EXEC MONTHEND
```

### INCLUDE Statements

Detects JCL includes:

```jcl
//         INCLUDE MEMBER=STDPARMS
//         INCLUDE MEMBER=DATASETS
```

### DD Statements

Detects dataset references:

```jcl
//INPUT1   DD DSN=PROD.CUSTOMER.MASTER,DISP=SHR
//OUTPUT1  DD DSN=PROD.REPORT.OUTPUT,DISP=(NEW,CATLG,DELETE)
//TEMP1    DD DSN=&&TEMP,DISP=(NEW,PASS)

* Concatenated datasets
//INPUT2   DD DSN=PROD.DATA1,DISP=SHR
//         DD DSN=PROD.DATA2,DISP=SHR
//         DD DSN=PROD.DATA3,DISP=SHR
```

### Handling JCL Syntax

The analyzer handles:

- **Continuations**: Comma at end of line, continue on next
- **Comments**: //* or //
- **Symbolic parameters**: &PARM (recorded as-is)
- **In-stream data**: DD * (ignored)
- **Procedures**: PROC and PEND statements

## PL/I Analysis Details

### INCLUDE Statements

Detects include files:

```pli
%INCLUDE CUSTMAST;
%INCLUDE ORDERHDR IN(COPYLIB);
```

### CALL Statements

Detects program calls:

```pli
CALL SUBPROG1(PARM1, PARM2);
CALL SUBPROG2;
```

### Handling PL/I Syntax

The analyzer handles:

- **Comments**: /* ... */
- **Preprocessor directives**: %
- **Statement terminators**: ;

## Dependency Types

Dependencies are classified by type:

| Type | Description | Example |
|------|-------------|---------|
| COPY | Copybook inclusion | COPY CUSTMAST |
| CALL | Program call | CALL 'SUBPROG1' |
| CICS_LINK | CICS program link | EXEC CICS LINK PROGRAM('PROG1') |
| SQL_INCLUDE | SQL copybook | EXEC SQL INCLUDE SQLCA |
| EXEC_PGM | JCL program execution | EXEC PGM=PAYROLL1 |
| EXEC_PROC | JCL procedure call | EXEC PROC=MONTHEND |
| INCLUDE | JCL include | INCLUDE MEMBER=STDPARMS |
| DATASET_REF | Dataset reference | DD DSN=PROD.DATA |

## Querying Dependencies

### Find Dependencies for an Artifact

```bash
python -m smf_queries run --db smf_analytics.db \
    --query artifact_dependencies \
    --params artifact_name=PAYROLL1 \
    --format table
```

Output:
```
Source Artifact | Source Type | Target Artifact | Target Type | Dependency Type | File | Line
----------------|-------------|-----------------|-------------|-----------------|------|-----
PAYROLL1        | PROGRAM     | CUSTMAST        | COPYBOOK    | COPY            | PAYROLL1.cbl | 45
PAYROLL1        | PROGRAM     | ORDERHDR        | COPYBOOK    | COPY            | PAYROLL1.cbl | 67
PAYROLL1        | PROGRAM     | SUBPROG1        | PROGRAM     | CALL            | PAYROLL1.cbl | 234
PAYROLL1        | PROGRAM     | ERRORHND        | PROGRAM     | CALL            | PAYROLL1.cbl | 456
```

### Find What Depends on an Artifact

```sql
-- Find what depends on CUSTMAST copybook
SELECT 
    source_artifact,
    source_type,
    dependency_type,
    source_file,
    line_number
FROM dependencies
WHERE target_artifact = 'CUSTMAST'
    AND target_type = 'COPYBOOK'
ORDER BY source_artifact;
```

### Build Dependency Tree

```bash
# Recursive dependencies (what PAYROLL1 depends on, and what those depend on)
python -m smf_queries run --db smf_analytics.db \
    --query artifact_dependencies \
    --params artifact_name=PAYROLL1,recursive=true \
    --format tree
```

Output:
```
PAYROLL1 (PROGRAM)
├── CUSTMAST (COPYBOOK) [COPY]
├── ORDERHDR (COPYBOOK) [COPY]
│   └── ORDERITM (COPYBOOK) [COPY]
├── SUBPROG1 (PROGRAM) [CALL]
│   ├── ERRORMSG (COPYBOOK) [COPY]
│   └── LOGGER (PROGRAM) [CALL]
└── ERRORHND (PROGRAM) [CALL]
```

## Unreferenced Copybooks

Find copybooks not used by any program:

```bash
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_copybooks \
    --format table
```

Output:
```
Copybook Name | Library Name | Last Modified | Status
--------------|--------------|---------------|-------------
OLDCOPY1      | PROD.COPYLIB | 2020-01-15    | UNREFERENCED
OLDCOPY2      | PROD.COPYLIB | 2019-06-20    | UNREFERENCED
TESTCOPY      | TEST.COPYLIB | 2021-03-10    | UNREFERENCED
```

## Best Practices

### 1. Source Code Organization

- Organize source by language
- Use consistent file extensions (.cbl, .jcl, .pli)
- Keep source in version control

### 2. Analysis Frequency

- Run after major code changes
- Run before cleanup activities
- Run quarterly for trending

### 3. Validation

- Review extracted dependencies
- Verify against known relationships
- Check for missing dependencies

### 4. Incremental Analysis

- Analyze changed files only
- Update dependencies incrementally
- Track analysis timestamps

### 5. Documentation

- Document source locations
- Note any manual adjustments
- Record analysis parameters

## Troubleshooting

### No Dependencies Found

**Problem**: Analysis completes but finds no dependencies

**Solution**:
- Check file extensions match language
- Verify source files contain expected statements
- Check file encoding (ASCII vs EBCDIC)
- Review sample files manually

### Incorrect Dependencies

**Problem**: Dependencies extracted incorrectly

**Solution**:
- Check for non-standard syntax
- Verify comment handling
- Review continuation handling
- Check for preprocessor directives

### Performance Issues

**Problem**: Analysis takes too long

**Solution**:
- Analyze in batches by directory
- Use `--pattern` to filter files
- Exclude test/sample code
- Check system resources

### Encoding Issues

**Problem**: "Invalid character" errors

**Solution**:
- Convert EBCDIC to ASCII before analysis
- Check file encoding
- Use appropriate character set

### Missing Source Files

**Problem**: Cannot find source files

**Solution**:
- Verify source directory path
- Check file permissions
- Ensure files were downloaded from mainframe
- Check for symbolic links

## Advanced Usage

### Custom Dependency Patterns

For custom dependency patterns, extend the parsers:

```python
from tools.legacy_analyzer.parsers import COBOLDependencyParser

class CustomCOBOLParser(COBOLDependencyParser):
    def parse_custom_statements(self, source_code):
        # Custom parsing logic
        pass
```

### Batch Processing

Process multiple directories:

```bash
#!/bin/bash
for dir in cobol1 cobol2 cobol3; do
    python -m legacy_analyzer analyze \
        --source-dir /path/to/$dir \
        --language COBOL \
        --db smf_analytics.db
done
```

### Dependency Export

Export dependencies for external tools:

```bash
# Export to CSV
python -m legacy_analyzer analyze \
    --source-dir /path/to/cobol \
    --language COBOL \
    --export-csv dependencies.csv

# Export to JSON
sqlite3 smf_analytics.db \
    "SELECT * FROM dependencies" \
    -json > dependencies.json
```

## Next Steps

- **[Query Reference](QUERY_REFERENCE.md)**: Query dependency data
- **[Risk Assessment Guide](RISK_ASSESSMENT_GUIDE.md)**: Assess impact of changes
- **[Cleanup Workflow](CLEANUP_WORKFLOW.md)**: Use dependencies in cleanup decisions
