# Migration Flow Export - Quick Reference

## Quick Start

Export all migration flows with the recommended strategy:

```bash
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output Business_Flows.json \
  --sort complexity-asc \
  --extended-scope
```

## All Sorting Strategies

Export flows with all 6 strategies for comparison:

```bash
# 1. Simplest first (RECOMMENDED for pilot)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_complexity_asc.json \
  --sort complexity-asc \
  --extended-scope

# 2. Most complex first (for experienced teams)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_complexity_desc.json \
  --sort complexity-desc \
  --extended-scope

# 3. Minimal dependencies (for parallel migration)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_independence.json \
  --sort independence \
  --extended-scope

# 4. Most dependencies first (for shared infrastructure)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_dependencies.json \
  --sort dependencies \
  --extended-scope

# 5. Alphabetical (for documentation)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_by_name.json \
  --sort name \
  --extended-scope

# 6. Database order (baseline)
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output flows_database_order.json \
  --sort none \
  --extended-scope
```

## Strategy Selection Guide

| Strategy | When to Use | Benefits | Risk Level |
|----------|-------------|----------|------------|
| **complexity-asc** ⭐ | Starting migration, pilot phase | Quick wins, build confidence | Low |
| **independence** | Multiple teams, parallel work | Scale up migration | Medium |
| **dependencies** | Shared components first | Reduce rework | Medium |
| **complexity-desc** | Experienced team, technical debt | Address hard problems early | High |
| **name** | Documentation, reference | Easy to locate flows | N/A |
| **none** | Debugging, comparison | Original order | N/A |

## Recommended Migration Sequence

```bash
# Wave 1: Pilot (5-10 flows)
# Use complexity-asc - simplest flows first
jq '.flows[:10]' flows_by_complexity_asc.json > wave1.json

# Wave 2: Scale (10-15 flows)
# Use independence - parallel migration
jq '.flows[:15]' flows_by_independence.json > wave2.json

# Wave 3: Infrastructure (shared components)
# Use dependencies - foundational flows
jq '.flows[:10]' flows_by_dependencies.json > wave3.json

# Wave 4: Complex (remaining flows)
# Use complexity-desc - tackle remaining complexity
jq '.flows[:10]' flows_by_complexity_desc.json > wave4.json
```

## Extended Scope Metadata

When `--extended-scope` is used, each flow includes:

### Copybooks
```json
"copybooks": [
  {
    "name": "CUSTCOPY",
    "usedBy": ["PROG1", "PROG2"],
    "usageCount": 2
  }
]
```

### Datasets
```json
"datasets": [
  {
    "name": "ACCTDAT",
    "operations": ["READ", "WRITE"],
    "accessedBy": ["PROG1"]
  }
]
```

### JCL
```json
"jcl": [
  {
    "name": "DALYREJS",
    "executesPrograms": ["PROG1"]
  }
]
```

### CICS Resources
```json
"cics": {
  "transactions": ["CAUP"],
  "files": ["ACCTDAT"],
  "mapsets": ["COACTUP"]
}
```

## Analyzing Exported Flows

### View Summary
```bash
jq '.summary' flows_by_complexity_asc.json
```

### Count Flows by Complexity
```bash
jq '.summary.complexityDistribution' flows_by_complexity_asc.json
```

### List Flow Names
```bash
jq '.flows[].flowName' flows_by_complexity_asc.json
```

### Extract Copybook Usage
```bash
jq '.flows[].utilities.copybooks[]' flows_by_complexity_asc.json | \
  jq -s 'group_by(.name) | map({name: .[0].name, totalUsage: map(.usageCount) | add})'
```

### Extract Dataset Operations
```bash
jq '.flows[].utilities.datasets[]' flows_by_complexity_asc.json | \
  jq -s 'group_by(.name) | map({name: .[0].name, operations: map(.operations[]) | unique})'
```

### Extract CICS Resources
```bash
jq '.flows[].utilities.cics' flows_by_complexity_asc.json | \
  jq -s 'map(select(. != null)) | {
    transactions: map(.transactions[]) | unique,
    files: map(.files[]) | unique,
    mapsets: map(.mapsets[]) | unique
  }'
```

## Common Use Cases

### 1. Pilot Migration (Start Small)
```bash
# Export simplest flows
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output pilot_flows.json \
  --sort complexity-asc \
  --extended-scope

# Take first 5 flows
jq '.flows[:5]' pilot_flows.json > pilot_wave1.json
```

### 2. Parallel Migration (Multiple Teams)
```bash
# Export independent flows
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output parallel_flows.json \
  --sort independence \
  --extended-scope

# Divide into 3 teams
jq '.flows[:10]' parallel_flows.json > team1.json
jq '.flows[10:20]' parallel_flows.json > team2.json
jq '.flows[20:30]' parallel_flows.json > team3.json
```

### 3. Infrastructure First (Shared Components)
```bash
# Export flows with most dependencies
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output infrastructure_flows.json \
  --sort dependencies \
  --extended-scope

# Migrate top 10 foundational flows first
jq '.flows[:10]' infrastructure_flows.json > infrastructure_wave.json
```

### 4. Technical Debt (Complex First)
```bash
# Export most complex flows
python -m legacy_analyzer migration export-flows \
  --db analyzer.db \
  --output complex_flows.json \
  --sort complexity-desc \
  --extended-scope

# Tackle top 5 most complex
jq '.flows[:5]' complex_flows.json > complex_wave.json
```

## Output Format

```json
{
  "flows": [
    {
      "flowId": "FLOW_001",
      "flowName": "Account Update Flow",
      "entryPoint": {
        "programName": "COACTUPC",
        "types": ["CICS_TRANSACTION", "CICS_PROGRAM"],
        "callers": [...]
      },
      "programs": [...],
      "complexity": {
        "totalLoc": 1250,
        "avgComplexity": 15.3,
        "maxComplexity": 28.5,
        "tier": "MEDIUM"
      },
      "dependencies": {
        "internal": 5,
        "external": 2
      },
      "invokedByJobs": [
        "PAYROLL01",
        "PAYWEEK"
      ],
      "utilities": {
        "copybooks": [...],
        "datasets": [...],
        "jcl": [...],
        "cics": {...}
      }
    }
  ],
  "summary": {
    "totalFlows": 27,
    "sortStrategy": "complexity-asc",
    "extendedScope": true,
    "complexityDistribution": {
      "LOW": 12,
      "MEDIUM": 10,
      "HIGH": 4,
      "VERY_HIGH": 1
    }
  }
}
```

### Flow Fields

Each flow object contains:

- **flowId**: Unique flow identifier (e.g., "FLOW_PAYROLL1")
- **flowName**: Human-readable flow name
- **entryPoint**: Entry point program and invocation types
- **programs**: List of programs in the flow
- **complexity**: Complexity metrics and tier
- **dependencies**: Internal and external dependencies
- **invokedByJobs**: Array of JCL job names that invoke this flow's entry point (NEW)
- **utilities**: Extended metadata (copybooks, datasets, JCL, CICS)

## Troubleshooting

### No flows exported
- Check that flow analysis has been run
- Verify database contains entry points
- Run: `python -m legacy_analyzer flow entry-points --db analyzer.db`

### Missing extended metadata
- Ensure `--extended-scope` flag is used
- Verify inventory data is loaded (copybooks, datasets, JCL, CICS)
- Check: `sqlite3 analyzer.db "SELECT COUNT(*) FROM inventory_copybooks;"`

### Unexpected sorting order
- Verify sort strategy spelling (use hyphens, not underscores)
- Check complexity metrics are calculated
- Run: `python -m legacy_analyzer complexity analyze --db analyzer.db`

## See Also

- [CLI Reference](CLI_REFERENCE.md#export-migration-flows) - Complete command documentation
- [Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md#phase-5-migration-flow-planning) - Full workflow
- [API Reference](API_REFERENCE.md#export_migration_flows) - Python API
- [run_carddemo_analysis.sh](../run_carddemo_analysis.sh) - Complete example script
