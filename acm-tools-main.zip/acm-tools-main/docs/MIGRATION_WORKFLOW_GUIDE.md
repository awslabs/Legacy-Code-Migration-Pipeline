# Migration Workflow Guide

## Overview

This guide provides a complete, step-by-step workflow for using the Legacy Analyzer to plan and execute a mainframe modernization or migration project. It covers the entire process from initial assessment through migration execution.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Phase 1: Initial Assessment](#phase-1-initial-assessment)
3. [Phase 2: Inventory Collection](#phase-2-inventory-collection)
4. [Phase 3: Dependency Analysis](#phase-3-dependency-analysis)
5. [Phase 4: Complexity Assessment](#phase-4-complexity-assessment)
6. [Phase 5: Package Planning](#phase-5-package-planning)
7. [Phase 6: Migration Execution](#phase-6-migration-execution)
8. [Best Practices](#best-practices)
9. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Data

- **Source Code**: COBOL, PL/I, JCL, copybooks, etc.
- **Inventory Data**: CSV exports of programs, datasets, JCL, CICS resources
- **SMF Data** (optional): Usage metrics for prioritization

### Required Tools

- Python 3.8+
- Legacy Analyzer toolkit
- Database (SQLite included, PostgreSQL optional)
- Graphviz (optional, for visualizations)

### Recommended Setup

```bash
# Install Legacy Analyzer
pip install -e .

# Create project directory
mkdir migration_project
cd migration_project

# Create subdirectories
mkdir -p data/{inventory,source,smf}
mkdir -p reports
mkdir -p config

# Copy configuration template
cp config/examples/migration_focused.yaml config/my_migration.yaml
```

---

## Phase 1: Initial Assessment

### Objective

Understand the scope and complexity of the legacy system.

### Steps

#### 1.1 Gather High-Level Information

Document the following:
- Number of programs, JCL jobs, copybooks
- Programming languages used
- Business domains/subsystems
- Known dependencies and integrations
- Current pain points

#### 1.2 Set Migration Goals

Define:
- Target platform (cloud, on-premise, hybrid)
- Timeline and budget constraints
- Risk tolerance
- Success criteria

#### 1.3 Configure Analysis

Edit `config/my_migration.yaml`:

```yaml
analysis:
  max_flow_depth: 12  # Adjust based on system complexity
  max_workers: 8      # Adjust based on available CPU

packages:
  max_artifacts: 150  # Adjust based on team capacity
  max_loc: 75000
  allow_external_deps: false  # Strict for migration

smf:
  enabled: true  # If SMF data available
```

---

## Phase 2: Inventory Collection

### Objective

Create a complete inventory of all artifacts in the legacy system.

### Steps

#### 2.1 Export Inventory from Mainframe

Use the provided mainframe export scripts:

```jcl
// Export JCL inventory
//JCLEXP   EXEC PGM=IEBGENER
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DUMMY
//SYSUT1   DD DSN=SYS1.JCLLIB,DISP=SHR
//SYSUT2   DD DSN=EXPORT.JCL.CSV,DISP=(NEW,CATLG)
```

See `legacy_analyzer/inventory/exporters/` for complete scripts.

#### 2.2 Load Inventory into Database

```bash
# Create database and schema
python -m legacy_analyzer init --db migration_project.db

# Load inventory data
python -m legacy_analyzer load \
    --type jcl \
    --file data/inventory/jcl_inventory.csv \
    --db migration_project.db

python -m legacy_analyzer load \
    --type programs \
    --file data/inventory/program_inventory.csv \
    --db migration_project.db

python -m legacy_analyzer load \
    --type datasets \
    --file data/inventory/dataset_inventory.csv \
    --db migration_project.db

python -m legacy_analyzer load \
    --type copybooks \
    --file data/inventory/copybook_inventory.csv \
    --db migration_project.db

python -m legacy_analyzer load \
    --type cics \
    --file data/inventory/cics_inventory.csv \
    --db migration_project.db
```

#### 2.3 Verify Inventory

```bash
# Check inventory counts
python -m legacy_analyzer inventory stats --db migration_project.db

# Expected output:
# JCL Members: 1,234
# Programs: 5,678
# Datasets: 2,345
# Copybooks: 890
# CICS Resources: 456
```

#### 2.4 Load SMF Data (Optional)

```bash
# Parse SMF records
python -m smf_record_parser parse data/smf/SMF30.dat \
    --split type \
    --output data/smf/parsed

# Load into database
python -m smf_loader load \
    --unified \
    --db migration_project.db \
    --file data/smf/parsed/SMF30_030.json
```

---

## Phase 3: Dependency Analysis

### Objective

Extract and analyze dependencies between artifacts.

### Steps

#### 3.1 Analyze Source Code

```bash
# Analyze COBOL source
python -m legacy_analyzer analyze \
    --source-dir data/source/cobol \
    --language COBOL \
    --db migration_project.db \
    --parallel

# Analyze PL/I source
python -m legacy_analyzer analyze \
    --source-dir data/source/pli \
    --language PLI \
    --db migration_project.db \
    --parallel

# Analyze JCL
python -m legacy_analyzer analyze \
    --source-dir data/source/jcl \
    --language JCL \
    --db migration_project.db \
    --parallel
```

#### 3.2 Analyze Program Flows

```bash
# Analyze flows for all entry points
python -m legacy_analyzer flow analyze-all \
    --db migration_project.db \
    --output reports/flows

# Analyze specific program
python -m legacy_analyzer flow analyze \
    --program PAYROLL1 \
    --db migration_project.db \
    --output reports/flows/PAYROLL1.json
```

#### 3.3 Detect Circular Dependencies

```bash
# Find circular dependencies
python -m legacy_analyzer flow detect-circular \
    --db migration_project.db \
    --output reports/circular_dependencies.csv

# Review and document circular dependencies
# These will need special handling during migration
```

#### 3.4 Identify Missing Artifacts

```bash
# Find missing programs
python -m smf_queries run \
    --db migration_project.db \
    --query missing_programs \
    --format csv \
    --output reports/missing_programs.csv

# Find missing copybooks
python -m smf_queries run \
    --db migration_project.db \
    --query missing_copybooks \
    --format csv \
    --output reports/missing_copybooks.csv

# Find missing datasets
python -m smf_queries run \
    --db migration_project.db \
    --query missing_datasets \
    --format csv \
    --output reports/missing_datasets.csv
```

#### 3.5 Calculate Completeness

```bash
# Calculate inventory completeness
python -m legacy_analyzer missing completeness \
    --db migration_project.db

# Expected output:
# Inventory Completeness: 94.5%
# Missing Programs: 23
# Missing Copybooks: 12
# Missing Datasets: 45
```

**Action**: Investigate and add missing artifacts to inventory before proceeding.

---

## Phase 4: Complexity Assessment

### Objective

Assess the complexity of each artifact to estimate migration effort.

### Steps

#### 4.1 Calculate Complexity Metrics

```bash
# Analyze complexity for all programs
python -m legacy_analyzer complexity analyze \
    --db migration_project.db \
    --output reports/complexity_metrics.csv
```

#### 4.2 Review Complexity Distribution

```bash
# Get complexity statistics
python -m legacy_analyzer complexity stats \
    --db migration_project.db

# Expected output:
# Total Programs: 5,678
# LOW: 3,456 (60.9%)
# MEDIUM: 1,789 (31.5%)
# HIGH: 389 (6.9%)
# VERY_HIGH: 44 (0.8%)
# God Programs: 12 (0.2%)
```

#### 4.3 Identify High-Complexity Programs

```bash
# Get top 50 most complex programs
python -m legacy_analyzer complexity top \
    --limit 50 \
    --db migration_project.db \
    --output reports/high_complexity_programs.csv
```

#### 4.4 Analyze God Programs

```bash
# Get god programs (excessive complexity)
python -m legacy_analyzer complexity god-programs \
    --db migration_project.db \
    --output reports/god_programs.csv
```

**Action**: Review god programs and high-complexity programs. Consider:
- Refactoring before migration
- Breaking into smaller components
- Allocating extra resources for migration

---

## Phase 5: Migration Flow Planning

### Objective

Export and organize migration flows using various sorting strategies to optimize the migration sequence.

### Steps

#### 5.1 Identify Entry Points

```bash
# Find entry point programs with CICS metadata
python -m legacy_analyzer flow entry-points \
    --db migration_project.db \
    --use-metadata \
    --format json \
    --output entry_points/entry_points.json
```

#### 5.2 Export Migration Flows with All Sorting Strategies

Export flows using all available sorting strategies to compare different migration approaches:

```bash
# Create output directory
mkdir -p reports/flows

# Export with all sorting strategies
python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_complexity_asc.json \
    --sort complexity-asc \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_complexity_desc.json \
    --sort complexity-desc \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_independence.json \
    --sort independence \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_dependencies.json \
    --sort dependencies \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_by_name.json \
    --sort name \
    --extended-scope

python -m legacy_analyzer migration export-flows \
    --db migration_project.db \
    --output reports/flows/flows_database_order.json \
    --sort none \
    --extended-scope
```

**Sorting Strategies Explained:**

1. **complexity-asc** (⭐ RECOMMENDED for Phase 1: Proof of Concept)
   - Sorts flows from simplest to most complex
   - **When to use**: Starting migration, building team confidence, proving feasibility
   - **Benefits**: Quick wins, lower risk, faster learning curve
   - **Example**: Start with simple CRUD operations before tackling complex business logic

2. **complexity-desc** (Phase 3: High Value)
   - Sorts flows from most complex to simplest
   - **When to use**: Team is experienced, want to tackle technical debt early
   - **Benefits**: Address hardest problems first, reduce future rework
   - **Example**: Migrate complex calculation engines when team has experience

3. **independence** (Phase 2: Parallel Migration)
   - Sorts by minimal external dependencies
   - **When to use**: Need to scale up migration, have multiple teams
   - **Benefits**: Enables parallel work, reduces coordination overhead
   - **Example**: Migrate independent subsystems simultaneously

4. **dependencies** (Phase 4: Shared Infrastructure)
   - Sorts by most dependencies first (foundational flows)
   - **When to use**: Want to migrate shared utilities and common components first
   - **Benefits**: Reduces rework, establishes common patterns
   - **Example**: Migrate shared validation routines before dependent flows

5. **name** (Documentation)
   - Alphabetical sorting by flow name
   - **When to use**: Creating documentation, need predictable ordering
   - **Benefits**: Easy to locate specific flows, consistent references
   - **Example**: Generate reference documentation for stakeholders

6. **none** (Baseline)
   - Database order (no sorting)
   - **When to use**: Comparing with other strategies, debugging
   - **Benefits**: Shows original discovery order
   - **Example**: Validate that sorting strategies are working correctly

#### 5.3 Review and Select Migration Strategy

Review the exported flows and select the strategy that best fits your migration approach:

```bash
# Compare flow counts and complexity distribution
for file in reports/flows/flows_by_*.json; do
    echo "=== $(basename $file) ==="
    jq '.summary' "$file"
    echo
done
```

**Decision Matrix:**

| Strategy | Risk | Speed | Team Size | Coordination | Best For |
|----------|------|-------|-----------|--------------|----------|
| complexity-asc | Low | Fast | Small | Low | Pilot, POC |
| independence | Medium | Fast | Large | Low | Parallel migration |
| dependencies | Medium | Medium | Medium | Medium | Shared infrastructure |
| complexity-desc | High | Slow | Large | High | Technical debt |

**Recommended Approach:**

Most successful migrations follow this sequence:

1. **Wave 1 (Pilot)**: Use `complexity-asc` - 5-10 simplest flows
2. **Wave 2 (Scale)**: Use `independence` - 10-15 independent flows in parallel
3. **Wave 3 (Infrastructure)**: Use `dependencies` - Shared components
4. **Wave 4 (Complex)**: Use `complexity-desc` - Remaining complex flows

#### 5.4 Analyze Extended Scope Metadata

Each exported flow includes comprehensive utility metadata when `--extended-scope` is used:

```bash
# Extract copybook usage across all flows
jq '.flows[].utilities.copybooks[]' reports/flows/flows_by_complexity_asc.json | \
    jq -s 'group_by(.name) | map({name: .[0].name, totalUsage: map(.usageCount) | add})' \
    > reports/copybook_usage.json

# Extract dataset operations
jq '.flows[].utilities.datasets[]' reports/flows/flows_by_complexity_asc.json | \
    jq -s 'group_by(.name) | map({name: .[0].name, operations: map(.operations[]) | unique})' \
    > reports/dataset_operations.json

# Extract CICS resources
jq '.flows[].utilities.cics' reports/flows/flows_by_complexity_asc.json | \
    jq -s 'map(select(. != null)) | {transactions: map(.transactions[]) | unique, files: map(.files[]) | unique, mapsets: map(.mapsets[]) | unique}' \
    > reports/cics_resources.json
```

This metadata helps plan:
- **Data Migration**: Which datasets need to be migrated
- **Batch Migration**: Which JCL jobs need conversion
- **Online Migration**: Which CICS transactions need modernization
- **Shared Components**: Which copybooks are used across multiple flows

#### 5.5 Create Migration Waves

Based on the selected strategy, divide flows into migration waves:

```bash
# Extract first 10 flows for Wave 1 (Pilot)
jq '.flows[:10]' reports/flows/flows_by_complexity_asc.json > reports/wave1_flows.json

# Extract next 15 flows for Wave 2 (Scale)
jq '.flows[10:25]' reports/flows/flows_by_complexity_asc.json > reports/wave2_flows.json

# Extract remaining flows for Wave 3 (Completion)
jq '.flows[25:]' reports/flows/flows_by_complexity_asc.json > reports/wave3_flows.json
```

#### 5.6 Create Traditional Packages (Optional)

If you prefer traditional package-based planning instead of flow-based planning:

```bash
# Create package for Payroll subsystem

#### 5.6 Create Traditional Packages (Optional)

If you prefer traditional package-based planning instead of flow-based planning:

```bash
# Create package for Payroll subsystem
python -m legacy_analyzer package create \
    --name "Payroll Migration" \
    --seeds PAYROLL1,PAYCALC,TAXCALC \
    --db migration_project.db

# Create package for Billing subsystem
python -m legacy_analyzer package create \
    --name "Billing Migration" \
    --seeds BILLING1,BILLCALC,INVOICE1 \
    --db migration_project.db

# Create package for Customer Management
python -m legacy_analyzer package create \
    --name "Customer Management" \
    --seeds CUSTMGMT,CUSTUPD,CUSTRPT \
    --db migration_project.db
```

#### 5.7 Validate Packages (If Using Traditional Packages)

#### 5.7 Validate Packages (If Using Traditional Packages)

```bash
# Validate all packages
python -m legacy_analyzer package validate-all \
    --db migration_project.db \
    --output reports/package_validation.csv
```

Review validation results:
- **Self-contained**: No external dependencies
- **Size constraints**: Within max_artifacts, max_loc, max_complexity
- **Conflicts**: No artifacts in multiple packages

#### 5.8 Detect and Resolve Conflicts (If Using Traditional Packages)

#### 5.8 Detect and Resolve Conflicts (If Using Traditional Packages)

```bash
# Find conflicting artifacts
python -m legacy_analyzer package conflicts \
    --db migration_project.db \
    --output reports/package_conflicts.csv
```

**Action**: Resolve conflicts by:
- Moving shared artifacts to separate "Common" package
- Duplicating artifacts across packages (if small)
- Refactoring to eliminate shared dependencies

#### 5.9 Optimize Package Boundaries (If Using Traditional Packages)

#### 5.9 Optimize Package Boundaries (If Using Traditional Packages)

```bash
# Optimize packages to minimize cross-package dependencies
python -m legacy_analyzer package optimize \
    --db migration_project.db \
    --strategy minimize_deps
```

#### 5.10 Generate Migration Waves (If Using Traditional Packages)

#### 5.10 Generate Migration Waves (If Using Traditional Packages)

```bash
# Suggest migration waves based on dependencies
python -m legacy_analyzer package waves \
    --max-packages-per-wave 5 \
    --db migration_project.db \
    --output reports/migration_waves.csv
```

#### 5.11 Prioritize with SMF Data (Optional)

#### 5.11 Prioritize with SMF Data (Optional)

```bash
# Prioritize packages by usage frequency
python -m legacy_analyzer package prioritize \
    --by usage \
    --db migration_project.db \
    --output reports/package_priority.csv
```

#### 5.12 Export Packages (If Using Traditional Packages)

```bash
# Export all packages to CSV for project management
python -m legacy_analyzer package export-all \
    --format csv \
    --output reports/packages/ \
    --db migration_project.db

# Export to JSON for programmatic use
python -m legacy_analyzer package export-all \
    --format json \
    --output reports/packages/ \
    --db migration_project.db
```

---

## Phase 5B: Dual Export Approach (Jobs + Flows)

### Objective

Export both JCL jobs and program flows to enable comprehensive migration planning that covers batch orchestration, infrastructure, and application logic.

### Why Dual Export?

The Legacy Analyzer provides two complementary export capabilities:

1. **Flow Export** (`export-flows`): Focuses on program execution flows and business logic
   - Entry point programs (CICS transactions, batch programs)
   - Program call chains and dependencies
   - Complexity metrics and shared components
   - Best for: Application migration planning

2. **Job Export** (`export-jobs`): Focuses on JCL job orchestration and infrastructure
   - Job steps and execution sequences
   - Job-to-job dependencies
   - Dataset operations and file management
   - Best for: Batch orchestration and infrastructure migration

**Together, these exports provide a complete view of your mainframe system.**

### Steps

#### 5B.1 Export JCL Jobs with All Sorting Strategies

Export jobs using all available sorting strategies to understand different migration approaches:

```bash
# Create output directory
mkdir -p reports/jobs

# Export with all sorting strategies
for strategy in name type dependencies complexity; do
    python -m legacy_analyzer migration export-jobs \
        --db migration_project.db \
        --output-dir reports/jobs \
        --sort-by ${strategy}
done
```

**Sorting Strategies for Jobs:**

1. **name** (Default - Documentation)
   - Alphabetical sorting by job name
   - **When to use**: Creating documentation, need predictable ordering
   - **Benefits**: Easy to locate specific jobs, consistent references
   - **Example**: Generate reference documentation for operations team

2. **type** (⭐ RECOMMENDED for Three-Phase Migration)
   - Groups APPLICATION jobs before INFRASTRUCTURE jobs
   - **When to use**: Want to separate infrastructure from application migration
   - **Benefits**: Clear separation of concerns, enables parallel work streams
   - **Example**: Migrate infrastructure jobs while application teams work on programs

3. **dependencies** (Execution Order)
   - Topological sort based on job dependencies
   - **When to use**: Need to maintain correct execution order
   - **Benefits**: Ensures jobs run in correct sequence, prevents data issues
   - **Example**: Migrate daily batch cycle maintaining execution order

4. **complexity** (Risk Assessment)
   - Sorts by number of steps (descending)
   - **When to use**: Want to identify high-risk jobs early
   - **Benefits**: Helps allocate resources to complex jobs
   - **Example**: Identify jobs with many steps that need extra attention

#### 5B.2 Understand Job Categorization

Jobs are automatically categorized into two types:

**APPLICATION Jobs:**
- Invoke at least one custom program (COBOL, PL/I, etc.)
- Execute business logic
- Require program migration before job migration
- Linked to program flows via `linkedFlow` field

**INFRASTRUCTURE Jobs:**
- Only invoke utility programs (IEFBR14, IDCAMS, SORT, etc.)
- Perform infrastructure tasks (dataset operations, backups, etc.)
- Can often be migrated independently
- May be replaced with cloud-native equivalents

```bash
# Analyze job distribution
jq '.summary' reports/jobs/jobs_by_type.json

# Example output:
# {
#   "totalJobs": 35,
#   "applicationJobs": 28,
#   "infrastructureJobs": 7,
#   "exportDate": "2026-01-30T12:34:56.789Z",
#   "database": "migration_project.db",
#   "sortedBy": "type"
# }
```

#### 5B.3 Cross-Reference Jobs and Flows

Use the cross-references between jobs and flows to coordinate migration:

```bash
# Extract jobs that invoke specific flows
jq '.jobs[] | select(.linkedFlow == "FLOW_CBACT01C")' reports/jobs/jobs_by_name.json

# Extract flows invoked by specific jobs
jq '.flows[] | select(.invokedByJobs[] | contains("DALYREJS"))' reports/flows/flows_by_name.json

# Create cross-reference matrix
jq -n --slurpfile jobs reports/jobs/jobs_by_name.json \
      --slurpfile flows reports/flows/flows_by_name.json \
      '{
        jobs: $jobs[0].jobs | map({name: .jobName, flow: .linkedFlow}),
        flows: $flows[0].flows | map({name: .flowId, jobs: .invokedByJobs})
      }' > reports/job_flow_cross_reference.json
```

#### 5B.4 Analyze Job Dependencies

Understand job-to-job dependencies for orchestration planning:

```bash
# Extract jobs with dependencies
jq '.jobs[] | select((.dependencies.mustRunAfter | length) > 0 or (.dependencies.mustRunBefore | length) > 0)' \
    reports/jobs/jobs_by_dependencies.json > reports/jobs_with_dependencies.json

# Identify critical path jobs (many dependencies)
jq '.jobs | sort_by(.dependencies.mustRunAfter | length + .dependencies.mustRunBefore | length) | reverse | .[0:10]' \
    reports/jobs/jobs_by_dependencies.json > reports/critical_path_jobs.json

# Build dependency graph for visualization
jq '.jobs[] | {job: .jobName, after: .dependencies.mustRunAfter, before: .dependencies.mustRunBefore}' \
    reports/jobs/jobs_by_dependencies.json > reports/job_dependency_graph.json
```

#### 5B.5 Plan Three-Phase Migration Strategy

Use the dual export to plan a three-phase migration:

**Phase 1: Infrastructure Jobs (Weeks 1-4)**
- Migrate INFRASTRUCTURE jobs first (no custom code dependencies)
- Replace with cloud-native equivalents where possible
- Examples: Backups, dataset operations, file transfers

```bash
# Extract infrastructure jobs
jq '.jobs[] | select(.jobType == "INFRASTRUCTURE")' reports/jobs/jobs_by_type.json > reports/phase1_infrastructure_jobs.json

# Count infrastructure jobs
jq '.jobs[] | select(.jobType == "INFRASTRUCTURE") | .jobName' reports/jobs/jobs_by_type.json | wc -l
```

**Phase 2: Application Programs (Weeks 5-20)**
- Migrate program flows (business logic)
- Use flow export with `complexity-asc` sorting
- Coordinate with APPLICATION jobs via `linkedFlow` field

```bash
# Extract application flows (already done in Phase 5)
cp reports/flows/flows_by_complexity_asc.json reports/phase2_application_flows.json

# Extract application jobs (for reference)
jq '.jobs[] | select(.jobType == "APPLICATION")' reports/jobs/jobs_by_type.json > reports/phase2_application_jobs.json
```

**Phase 3: Batch Orchestration (Weeks 21-24)**
- Migrate APPLICATION jobs after their linked flows are migrated
- Implement job scheduling and orchestration in cloud
- Use dependency information to build DAGs

```bash
# Extract application jobs with their linked flows
jq '.jobs[] | select(.jobType == "APPLICATION") | {job: .jobName, flow: .linkedFlow, steps: .steps | length, dependencies: .dependencies}' \
    reports/jobs/jobs_by_type.json > reports/phase3_orchestration_jobs.json

# Verify all linked flows have been migrated (manual check)
jq -r '.jobs[] | select(.jobType == "APPLICATION" and .linkedFlow != null) | .linkedFlow' \
    reports/jobs/jobs_by_type.json | sort -u > reports/flows_needed_for_jobs.txt
```

#### 5B.6 Create Migration Wave Plan

Combine flow and job exports into a comprehensive migration wave plan:

```bash
# Create wave plan directory
mkdir -p reports/waves

# Wave 1: Infrastructure Jobs (Parallel with Wave 2)
jq '{
    wave: 1,
    name: "Infrastructure Jobs",
    duration: "4 weeks",
    jobs: [.jobs[] | select(.jobType == "INFRASTRUCTURE") | {name: .jobName, steps: .steps | length, complexity: (.steps | length)}]
}' reports/jobs/jobs_by_type.json > reports/waves/wave1_infrastructure.json

# Wave 2: Simple Application Flows (Weeks 5-8)
jq '{
    wave: 2,
    name: "Simple Application Flows",
    duration: "4 weeks",
    flows: .flows[0:10]
}' reports/flows/flows_by_complexity_asc.json > reports/waves/wave2_simple_flows.json

# Wave 3: Medium Application Flows (Weeks 9-16)
jq '{
    wave: 3,
    name: "Medium Application Flows",
    duration: "8 weeks",
    flows: .flows[10:25]
}' reports/flows/flows_by_complexity_asc.json > reports/waves/wave3_medium_flows.json

# Wave 4: Complex Application Flows (Weeks 17-20)
jq '{
    wave: 4,
    name: "Complex Application Flows",
    duration: "4 weeks",
    flows: .flows[25:]
}' reports/flows/flows_by_complexity_asc.json > reports/waves/wave4_complex_flows.json

# Wave 5: Batch Orchestration (Weeks 21-24)
jq '{
    wave: 5,
    name: "Batch Orchestration",
    duration: "4 weeks",
    jobs: [.jobs[] | select(.jobType == "APPLICATION") | {name: .jobName, flow: .linkedFlow, dependencies: .dependencies}]
}' reports/jobs/jobs_by_type.json > reports/waves/wave5_orchestration.json
```

#### 5B.7 Generate Migration Summary Report

Create a comprehensive summary of the migration plan:

```bash
# Generate summary
cat > reports/migration_summary.md << 'EOF'
# Migration Summary

## Overview

This migration follows a three-phase approach:
1. Infrastructure Jobs (4 weeks)
2. Application Programs (16 weeks)
3. Batch Orchestration (4 weeks)

Total Duration: 24 weeks

## Statistics

### Jobs
EOF

# Add job statistics
jq -r '.summary | "- Total Jobs: \(.totalJobs)\n- Application Jobs: \(.applicationJobs)\n- Infrastructure Jobs: \(.infrastructureJobs)"' \
    reports/jobs/jobs_by_type.json >> reports/migration_summary.md

cat >> reports/migration_summary.md << 'EOF'

### Flows
EOF

# Add flow statistics
jq -r '.summary | "- Total Flows: \(.totalFlows)\n- Complexity Distribution:\n  - LOW: \(.complexityDistribution.LOW)\n  - MEDIUM: \(.complexityDistribution.MEDIUM)\n  - HIGH: \(.complexityDistribution.HIGH)\n  - VERY_HIGH: \(.complexityDistribution.VERY_HIGH)"' \
    reports/flows/flows_by_complexity_asc.json >> reports/migration_summary.md

cat >> reports/migration_summary.md << 'EOF'

## Migration Waves

### Wave 1: Infrastructure Jobs (Weeks 1-4)
- Migrate infrastructure jobs independently
- Replace with cloud-native equivalents where possible
- No dependencies on application migration

### Wave 2: Simple Application Flows (Weeks 5-8)
- Migrate 10 simplest flows
- Build team confidence and establish patterns
- Low risk, quick wins

### Wave 3: Medium Application Flows (Weeks 9-16)
- Migrate 15 medium complexity flows
- Scale up migration with proven patterns
- Parallel work streams

### Wave 4: Complex Application Flows (Weeks 17-20)
- Migrate remaining complex flows
- Leverage team experience
- Address technical debt

### Wave 5: Batch Orchestration (Weeks 21-24)
- Migrate application jobs
- Implement cloud-native orchestration
- Build DAGs from dependency information
- Final integration and testing

## Cross-References

Jobs link to flows via `linkedFlow` field.
Flows link to jobs via `invokedByJobs` field.

Use these cross-references to coordinate migration timing.

## Next Steps

1. Review wave plan with stakeholders
2. Allocate resources to each wave
3. Set up development and test environments
4. Begin Wave 1 (Infrastructure Jobs)
5. Prepare for Wave 2 (Simple Flows) in parallel

EOF

echo "Migration summary created: reports/migration_summary.md"
```

#### 5B.8 Validate Migration Plan

Perform final validation checks:

```bash
# Check that all application jobs have linked flows
jq -r '.jobs[] | select(.jobType == "APPLICATION" and .linkedFlow == null) | .jobName' \
    reports/jobs/jobs_by_type.json > reports/validation_jobs_without_flows.txt

if [ -s reports/validation_jobs_without_flows.txt ]; then
    echo "WARNING: Some application jobs have no linked flows:"
    cat reports/validation_jobs_without_flows.txt
else
    echo "✓ All application jobs have linked flows"
fi

# Check that all flows referenced by jobs exist
comm -23 \
    <(jq -r '.jobs[] | select(.linkedFlow != null) | .linkedFlow' reports/jobs/jobs_by_type.json | sort -u) \
    <(jq -r '.flows[].flowId' reports/flows/flows_by_name.json | sort -u) \
    > reports/validation_missing_flows.txt

if [ -s reports/validation_missing_flows.txt ]; then
    echo "WARNING: Some flows referenced by jobs do not exist:"
    cat reports/validation_missing_flows.txt
else
    echo "✓ All flows referenced by jobs exist"
fi

# Check for circular job dependencies
jq '.jobs[] | select(.dependencies.mustRunAfter | contains([.jobName]))' \
    reports/jobs/jobs_by_dependencies.json > reports/validation_circular_job_deps.json

if [ -s reports/validation_circular_job_deps.json ]; then
    echo "WARNING: Circular job dependencies detected:"
    jq -r '.jobName' reports/validation_circular_job_deps.json
else
    echo "✓ No circular job dependencies"
fi
```

### Benefits of Dual Export Approach

1. **Complete Coverage**: Covers both application logic (flows) and orchestration (jobs)
2. **Parallel Work Streams**: Infrastructure and application teams can work independently
3. **Risk Mitigation**: Infrastructure migration can start immediately while application migration is planned
4. **Clear Dependencies**: Cross-references ensure coordinated migration timing
5. **Flexible Planning**: Multiple sorting strategies enable different migration approaches
6. **Comprehensive Metadata**: Extended scope provides complete context for migration

### Common Patterns

**Pattern 1: Infrastructure First**
```bash
# Migrate infrastructure jobs first (no dependencies)
# Then migrate application flows
# Finally migrate application jobs (orchestration)
```

**Pattern 2: Parallel Streams**
```bash
# Stream 1: Infrastructure team migrates infrastructure jobs
# Stream 2: Application team migrates flows
# Stream 3: Orchestration team prepares cloud-native workflow tools
# Converge: Integrate all three streams
```

**Pattern 3: Business Domain**
```bash
# Group jobs and flows by business domain
# Migrate one domain at a time (jobs + flows together)
# Enables domain-by-domain cutover
```

---

## Phase 6: Migration Execution

### Objective

Execute the migration in controlled waves following the three-phase strategy.

### Steps

#### 6.1 Prepare Wave 1

```bash
# Get Wave 1 packages
python -m legacy_analyzer package list-wave \
    --wave 1 \
    --db migration_project.db \
    --output reports/wave1_packages.csv

# Generate detailed reports for Wave 1
python -m legacy_analyzer report wave \
    --wave 1 \
    --db migration_project.db \
    --output reports/wave1_report.html
```

#### 6.2 Migrate Wave 1 Packages

For each package in Wave 1:

1. **Extract Source Code**
   ```bash
   python -m legacy_analyzer package extract \
       --name "Payroll Migration" \
       --output migration/wave1/payroll/ \
       --db migration_project.db
   ```

2. **Generate Documentation**
   ```bash
   python -m legacy_analyzer report artifact \
       --name PAYROLL1 \
       --db migration_project.db \
       --output migration/wave1/payroll/PAYROLL1_report.html
   ```

3. **Visualize Dependencies**
   ```bash
   python -m legacy_analyzer flow visualize \
       --program PAYROLL1 \
       --format mermaid \
       --output migration/wave1/payroll/PAYROLL1_flow.mmd \
       --db migration_project.db
   ```

4. **Migrate Code** (manual or automated)
   - Convert COBOL to Java/C#/Python
   - Migrate JCL to orchestration tools
   - Migrate datasets to databases/files

5. **Test Migrated Code**
   - Unit tests
   - Integration tests
   - Performance tests

6. **Deploy to Test Environment**

7. **Validate Against Original**

#### 6.3 Track Progress

```bash
# Update package status
python -m legacy_analyzer package update-status \
    --name "Payroll Migration" \
    --status "COMPLETED" \
    --db migration_project.db

# Get overall progress
python -m legacy_analyzer package progress \
    --db migration_project.db

# Expected output:
# Total Packages: 15
# Not Started: 10 (66.7%)
# In Progress: 3 (20.0%)
# Completed: 2 (13.3%)
```

#### 6.4 Repeat for Subsequent Waves

Repeat steps 6.1-6.3 for Wave 2, Wave 3, etc.

---

## Best Practices

### Planning

1. **Start Small**: Begin with a pilot package (low complexity, low risk)
2. **Validate Inventory**: Ensure 95%+ completeness before planning
3. **Resolve Circular Dependencies**: Break cycles before migration
4. **Document Assumptions**: Record all decisions and assumptions
5. **Plan for Rollback**: Have rollback procedures for each wave

### Execution

1. **Automate Where Possible**: Use code generation tools
2. **Test Thoroughly**: Comprehensive testing at each stage
3. **Monitor Performance**: Track performance metrics
4. **Maintain Traceability**: Link migrated code to original
5. **Preserve Business Logic**: Ensure functional equivalence

### Communication

1. **Regular Status Updates**: Weekly progress reports
2. **Stakeholder Engagement**: Keep business stakeholders informed
3. **Risk Communication**: Escalate issues early
4. **Documentation**: Maintain comprehensive documentation
5. **Knowledge Transfer**: Train team on new platform

### Quality

1. **Code Reviews**: Review all migrated code
2. **Automated Testing**: Implement CI/CD pipelines
3. **Performance Testing**: Validate performance requirements
4. **Security Testing**: Ensure security standards met
5. **Acceptance Testing**: Business user validation

---

## Troubleshooting

### Issue: Inventory Completeness < 90%

**Symptoms**: Many missing artifacts detected

**Solutions**:
1. Re-export inventory from mainframe
2. Check for additional source libraries
3. Review SMF data for undocumented programs
4. Search for shadow IT or undocumented systems

### Issue: Circular Dependencies

**Symptoms**: Circular dependency chains detected

**Solutions**:
1. Refactor code to break cycles
2. Introduce interfaces/abstractions
3. Migrate circular groups together
4. Document and accept (if unavoidable)

### Issue: Package Too Large

**Symptoms**: Package exceeds size constraints

**Solutions**:
1. Split into multiple packages
2. Increase size constraints (if justified)
3. Remove non-essential artifacts
4. Refactor to reduce dependencies

### Issue: High Complexity Programs

**Symptoms**: Many VERY_HIGH complexity programs

**Solutions**:
1. Refactor before migration
2. Allocate extra resources
3. Consider rewrite instead of migration
4. Break into smaller components

### Issue: Performance Problems

**Symptoms**: Analysis takes too long

**Solutions**:
1. Increase `max_workers` in config
2. Enable caching
3. Reduce `max_flow_depth`
4. Process in batches
5. Use more powerful hardware

### Issue: Missing Dependencies

**Symptoms**: Dependencies not detected

**Solutions**:
1. Check parser configuration
2. Verify source code encoding
3. Review parser logs for errors
4. Add custom parsing rules
5. Manual dependency documentation

---

## Additional Resources

- [Getting Started Guide](GETTING_STARTED.md) - Quick start
- [Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md) - Program flow analysis
- [Complexity Guide](COMPLEXITY_GUIDE.md) - Complexity assessment
- [Migration Packages Guide](MIGRATION_PACKAGES_GUIDE.md) - Package planning
- [API Reference](API_REFERENCE.md) - Python API
- [CLI Reference](CLI_REFERENCE.md) - Command-line interface

---

## Success Metrics

Track these metrics throughout the migration:

- **Inventory Completeness**: Target 95%+
- **Package Self-Containment**: Target 90%+
- **Test Coverage**: Target 80%+
- **Performance Parity**: Target 100%
- **Defect Rate**: Target < 1% of migrated code
- **Schedule Adherence**: Target ±10%
- **Budget Adherence**: Target ±10%

---

## Conclusion

Following this workflow will help ensure a successful migration project. Remember:

1. **Plan Thoroughly**: Invest time in analysis and planning
2. **Start Small**: Pilot with low-risk packages
3. **Test Extensively**: Quality is paramount
4. **Communicate Often**: Keep stakeholders informed
5. **Learn and Adapt**: Improve process with each wave

Good luck with your migration!
