# DB2 SMF Parser User Guide

## Overview

This guide covers the DB2-versioned SMF parsers for record types 100, 101, and 102. Unlike standard z/OS-versioned SMF records, DB2 records have layouts that vary by DB2 version rather than z/OS version. The toolkit automatically detects the DB2 version from each record and selects the appropriate parser.

## Table of Contents

- [Supported Record Types](#supported-record-types)
- [DB2 Version Detection](#db2-version-detection)
- [Quick Start](#quick-start)
- [Parsing Examples](#parsing-examples)
- [Registry Pattern](#registry-pattern)
- [Fallback Parser Behavior](#fallback-parser-behavior)
- [Database Loading](#database-loading)
- [Field Mappings](#field-mappings)
- [Adding New DB2 Versions](#adding-new-db2-versions)
- [Error Handling](#error-handling)
- [Troubleshooting](#troubleshooting)

## Supported Record Types

The toolkit supports the following DB2 SMF record types:

### Type 100: DB2 Statistics Records

**Purpose**: System-level and database-level statistics collected at regular intervals

**Supported DB2 Versions**:
- V10 (DB2 10 for z/OS)

**IFCIDs**:
- IFCID 1: System Services Statistics
- IFCID 2: Database Services Statistics

**Use Cases**:
- Monitor DB2 subsystem performance
- Track buffer pool efficiency
- Analyze log activity and checkpoint frequency
- Monitor thread and connection usage

### Type 101: DB2 Accounting Records

**Purpose**: Resource consumption for individual DB2 applications and threads

**Supported DB2 Versions**:
- V11 (DB2 11 for z/OS)
- V12 (DB2 12 for z/OS)

**IFCIDs**: Multiple IFCIDs for different accounting events

**Use Cases**:
- Track application-level resource consumption
- Identify expensive SQL statements
- Monitor transaction response times
- Analyze CPU and I/O usage per application

### Type 102: DB2 Performance Records

**Purpose**: Detailed performance data for SQL statements and database operations

**Supported DB2 Versions**:
- V11 (DB2 11 for z/OS)
- V12 (DB2 12 for z/OS)
- V13 (DB2 13 for z/OS)

**IFCIDs**: Multiple IFCIDs for different performance events

**Use Cases**:
- Analyze SQL statement performance
- Identify inefficient access paths
- Monitor lock contention and deadlocks
- Track buffer pool and cache efficiency

## DB2 Version Detection

### How It Works

The parser automatically detects the DB2 version from each record using the following process:

1. **Extract Product Section**: Read the product section offset from the SMF header (offset 28)
2. **Locate QWHS Header**: The QWHS standard header is always first in the product section
3. **Read QWHSRELN Field**: Extract the 2-byte release number at offset 6 within QWHS
4. **Parse Version**: Interpret the release number to determine DB2 version

### Version Encoding

The QWHSRELN field uses the following encoding:

| Release Code | Major Byte | Minor Byte | DB2 Version |
|--------------|------------|------------|-------------|
| 0x0A00       | 0x0A (10)  | 0x00       | V10         |
| 0x0B00       | 0x0B (11)  | 0x00       | V11         |
| 0x0C00       | 0x0C (12)  | 0x00       | V12         |
| 0x0D00       | 0x0D (13)  | 0x00       | V13         |

**Note**: The minor byte may contain function level information, but the major byte determines the parser version.

### Detection Example

```python
from tools.smf_analyzer.smf_record_parser.parsers import DB2VersionDetector

# Read SMF record
with open('smf_data.rdw', 'rb') as f:
    record_data = f.read(1024)  # Read first record

# Detect DB2 version
record_type = record_data[5]  # Record type at offset 5
if record_type in {100, 101, 102}:
    db2_version = DB2VersionDetector.detect_version(record_data, record_type)
    print(f"Detected DB2 version: {db2_version}")
```

## Quick Start

### Parsing a Single Record

```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# Read SMF record
with open('smf_data.rdw', 'rb') as f:
    record_data = f.read(1024)

# Create parser (version is auto-detected for DB2 types)
parser = SMFParserFactory.create_parser(
    record_type=100,
    record_data=record_data  # Required for DB2 types
)

# Parse the record
result = parser.parse(record_data, version="V10")  # Version from detection

# Access parsed data
print(f"Record Type: {result.record_type}")
print(f"DB2 Version: {result.version}")
print(f"System ID: {result.system_id}")
print(f"Timestamp: {result.timestamp}")
print(f"IFCID: {result.sections['qwhs_header']['ifcid']}")
```

### Parsing Multiple Records from a File

```python
from tools.smf_analyzer.smf_record_parser import SMFFileParser

# Parse entire file
file_parser = SMFFileParser('smf_data.rdw')
records = file_parser.parse_all()

# Filter DB2 records
db2_records = [r for r in records if r.record_type in {100, 101, 102}]

print(f"Found {len(db2_records)} DB2 records")

# Analyze by version
from collections import Counter
versions = Counter(r.version for r in db2_records)
print(f"DB2 versions: {dict(versions)}")
```

### Command-Line Usage

```bash
# Parse SMF file and split by record type
python -m tools.smf_analyzer.smf_record_parser parse \
  examples/data/j/SMF.APR4.TRS.DECOMPRESS.rdw \
  --split type \
  -o results/

# This creates separate files for each record type:
# - results/SMF.APR4.TRS.DECOMPRESS_100.json (DB2 Statistics)
# - results/SMF.APR4.TRS.DECOMPRESS_101.json (DB2 Accounting)
# - results/SMF.APR4.TRS.DECOMPRESS_102.json (DB2 Performance)
```

## Parsing Examples

### Example 1: Parse Type 100 (Statistics)

```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# Read Type 100 record
with open('type100_record.bin', 'rb') as f:
    record_data = f.read()

# Create parser
parser = SMFParserFactory.create_parser(100, record_data=record_data)

# Parse record
result = parser.parse(record_data, version="V10")

# Access statistics data
qwhs = result.sections['qwhs_header']
print(f"Subsystem: {qwhs['subsystem_name']}")
print(f"IFCID: {qwhs['ifcid']}")

# Access self-defining section
sds = result.sections['self_defining_section']
print(f"Data sections available: {list(sds['triplets'].keys())}")

# Check for optional headers
if 'optional_headers' in result.sections:
    headers = result.sections['optional_headers']
    print(f"Optional headers present: {list(headers.keys())}")
```

### Example 2: Parse Type 101 (Accounting)

```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# Read Type 101 record
with open('type101_record.bin', 'rb') as f:
    record_data = f.read()

# Create parser (supports V11 and V12)
parser = SMFParserFactory.create_parser(101, record_data=record_data)

# Parse record
result = parser.parse(record_data, version="V11")  # or "V12"

# Access accounting data
qwhs = result.sections['qwhs_header']
print(f"Subsystem: {qwhs['subsystem_name']}")
print(f"Location: {qwhs['local_location_name']}")

# Access correlation header (if present)
if 'optional_headers' in result.sections:
    if 'correlation' in result.sections['optional_headers']:
        print("Correlation header present")
```

### Example 3: Parse Type 102 (Performance)

```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# Read Type 102 record
with open('type102_record.bin', 'rb') as f:
    record_data = f.read()

# Create parser (supports V11, V12, V13)
parser = SMFParserFactory.create_parser(102, record_data=record_data)

# Parse record
result = parser.parse(record_data, version="V13")  # or "V11", "V12"

# Access performance data
qwhs = result.sections['qwhs_header']
print(f"Subsystem: {qwhs['subsystem_name']}")
print(f"IFCID: {qwhs['ifcid']}")
```

### Example 4: Batch Processing with Version Tracking

```python
from tools.smf_analyzer.smf_record_parser import SMFFileParser
from collections import defaultdict

# Parse file
file_parser = SMFFileParser('smf_data.rdw')
records = file_parser.parse_all()

# Group by record type and version
by_type_version = defaultdict(list)
for record in records:
    if record.record_type in {100, 101, 102}:
        key = (record.record_type, record.version)
        by_type_version[key].append(record)

# Report statistics
for (rec_type, version), recs in sorted(by_type_version.items()):
    print(f"Type {rec_type} {version}: {len(recs)} records")
```

## Registry Pattern

### Understanding the Registry

The DB2 parser factory uses a dual registry pattern:

1. **z/OS Registry** (`_registry`): Maps (record_type, os_version) for standard SMF records
2. **DB2 Registry** (`_db2_registry`): Maps (record_type, db2_version) for DB2 records

### Current DB2 Registry

```python
_db2_registry = {
    # Type 100 parsers
    (100, "V10"): SMF100ParserV10,
    
    # Type 101 parsers
    (101, "V11"): SMF101ParserV11,
    (101, "V12"): SMF101ParserV12,
    
    # Type 102 parsers
    (102, "V11"): SMF102ParserV11,
    (102, "V12"): SMF102ParserV12,
    (102, "V13"): SMF102ParserV13,
}
```

### Listing Available Parsers

```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# List all DB2 parsers
db2_parsers = SMFParserFactory.list_db2_parsers()
print("Available DB2 parsers:")
for record_type, versions in sorted(db2_parsers.items()):
    print(f"  Type {record_type}: {', '.join(versions)}")

# Output:
# Available DB2 parsers:
#   Type 100: V10
#   Type 101: V12, V11
#   Type 102: V13, V12, V11
```

### Dynamic Registration

You can register custom parsers at runtime:

```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory
from tools.smf_analyzer.smf_record_parser.parsers.db2_parser_base import DB2ParserBase

# Define custom parser
class SMF100ParserV11(DB2ParserBase):
    def __init__(self, base_parser):
        super().__init__(base_parser)
        self.db2_version = "V11"
    
    def parse(self, record_data):
        # Custom parsing logic
        pass

# Register it
SMFParserFactory._db2_registry[(100, "V11")] = SMF100ParserV11

# Now it's available
parser = SMFParserFactory.create_parser(100, record_data=some_v11_record)
```

## Fallback Parser Behavior

### What is Fallback Parsing?

When a DB2 record has a version that doesn't have an exact parser match, the system can automatically use the nearest available parser version. This is useful for:

- Handling minor version differences (e.g., V12.1 using V12 parser)
- Processing records from newer DB2 versions before parsers are implemented
- Maintaining compatibility across DB2 upgrades

### Fallback Strategy

The fallback logic prefers **older parsers** over newer ones:

1. **First choice**: Exact version match (e.g., V12 record → V12 parser)
2. **Second choice**: Closest older version (e.g., V12.1 record → V12 parser)
3. **Third choice**: Closest newer version (e.g., V9 record → V10 parser)
4. **Failure**: No suitable parser exists

**Rationale**: Older parsers are more likely to be compatible with newer versions because DB2 typically adds fields rather than removing them.

### Enabling/Disabling Fallback

```python
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# Enable fallback (default)
parser = SMFParserFactory.create_parser(
    record_type=102,
    record_data=record_data,
    allow_fallback=True  # Default
)

# Disable fallback (require exact match)
parser = SMFParserFactory.create_parser(
    record_type=102,
    record_data=record_data,
    allow_fallback=False
)
```

### Fallback Examples

**Example 1: V12.1 record with V12 parser**

```python
# Record contains DB2 V12.1 (0x0C01)
# Available parsers: V11, V12, V13

# With fallback enabled:
parser = SMFParserFactory.create_parser(102, record_data=v12_1_record)
# Uses V12 parser (closest older version)
# Logs: "No exact parser for Type 102 V12. Using fallback parser V12."

# With fallback disabled:
parser = SMFParserFactory.create_parser(102, record_data=v12_1_record, allow_fallback=False)
# Raises: UnsupportedVersionError
```

**Example 2: V14 record (future version)**

```python
# Record contains DB2 V14 (0x0E00)
# Available parsers: V11, V12, V13

# With fallback enabled:
parser = SMFParserFactory.create_parser(102, record_data=v14_record)
# Uses V13 parser (newest available, closest to V14)
# Logs: "No exact parser for Type 102 V14. Using fallback parser V13."
```

### Fallback Warnings

When fallback parsing is used, the system logs a warning:

```
WARNING: No exact parser for Type 102 V12.1. Using fallback parser V12. 
Field compatibility not guaranteed - verify results carefully.
```

**Important**: Always validate fallback parsing results, especially for:
- Critical business logic
- Financial calculations
- Compliance reporting

## Database Loading

### Schema Overview

DB2 records use dedicated schemas in the shared infrastructure:

- **SMF100Schema**: Type 100 (Statistics) records
- **SMF101Schema**: Type 101 (Accounting) records
- **SMF102Schema**: Type 102 (Performance) records

All schemas are located in `shared/database/schemas/smf_schemas.py`.

### Loading Parsed Records

```python
from tools.smf_analyzer.smf_loader import SMFLoader
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas import SMF100Schema, SMF101Schema, SMF102Schema

# Create database adapter
db = SQLiteAdapter('db2_analysis.db')

# Create schemas
db.create_schema(SMF100Schema())
db.create_schema(SMF101Schema())
db.create_schema(SMF102Schema())

# Parse and load records
from tools.smf_analyzer.smf_record_parser import SMFFileParser

file_parser = SMFFileParser('smf_data.rdw')
records = file_parser.parse_all()

# Load DB2 records
loader = SMFLoader(db)
for record in records:
    if record.record_type == 100:
        loader.load_record(record, SMF100Schema())
    elif record.record_type == 101:
        loader.load_record(record, SMF101Schema())
    elif record.record_type == 102:
        loader.load_record(record, SMF102Schema())

print(f"Loaded {len(records)} records")
```

### Querying Loaded Data

```python
import sqlite3

# Connect to database
conn = sqlite3.connect('db2_analysis.db')
cursor = conn.cursor()

# Query Type 100 statistics
cursor.execute("""
    SELECT system_id, subsystem_name, ifcid, COUNT(*) as record_count
    FROM smf100_header
    GROUP BY system_id, subsystem_name, ifcid
    ORDER BY record_count DESC
""")

for row in cursor.fetchall():
    print(f"System: {row[0]}, Subsystem: {row[1]}, IFCID: {row[2]}, Count: {row[3]}")

conn.close()
```

### NULL Handling

Optional fields that are not present in a record are stored as NULL in the database:

```python
# Example: Optional correlation header
# If not present in record, correlation_id will be NULL in database

cursor.execute("""
    SELECT record_id, correlation_id
    FROM smf101_accounting
    WHERE correlation_id IS NULL
""")

records_without_correlation = cursor.fetchall()
print(f"Records without correlation: {len(records_without_correlation)}")
```

## Field Mappings

### Type 100 (Statistics) - Common Fields

All Type 100 parsers extract these common fields:

| Field Name | Source | Type | Description |
|------------|--------|------|-------------|
| record_type | SMF Header | int | Always 100 |
| record_length | SMF Header | int | Total record length in bytes |
| system_id | SMF Header | str | System identifier (4 chars) |
| subsystem_id | SMF Header | str | DB2 subsystem ID (4 chars) |
| timestamp | SMF Header | datetime | Record creation timestamp |
| date | SMF Header | date | Record creation date |
| ifcid | QWHS Header | int | Instrumentation Facility Component ID |
| release_number | QWHS Header | int | DB2 release number (hex) |
| subsystem_name | QWHS Header | str | DB2 subsystem name |
| local_location_name | QWHS Header | str | Local location name |
| network_id | QWHS Header | str | Network identifier |

### Type 100 - IFCID-Specific Sections

**IFCID 1 (System Services Statistics)**:
- QWSA: Accounting data
- QWSB: Buffer pool statistics
- QWSC: Log statistics
- Q3ST: Thread statistics
- Q9ST: Storage statistics
- QWSD: Dataset statistics
- QVLS: Virtual storage statistics
- QVAS: Address space statistics
- QSST: System services statistics
- QLST: Lock statistics
- QJST: Journal statistics
- QDST: Data sharing statistics
- QWOS: Workload statistics

**IFCID 2 (Database Services Statistics)**:
- QXST: Database statistics
- QTST: Tablespace statistics
- QBST: Buffer pool statistics
- QIST: Index statistics
- QTXA: Transaction statistics
- QISE: Index space statistics
- QBGL: Buffer pool group statistics
- QTGS: Tablespace group statistics
- QLES: Log statistics
- QISJ: Index space journal statistics
- Q8ST: Storage statistics

### Type 101 (Accounting) - Common Fields

All Type 101 parsers extract these common fields:

| Field Name | Source | Type | Description |
|------------|--------|------|-------------|
| record_type | SMF Header | int | Always 101 |
| record_length | SMF Header | int | Total record length in bytes |
| system_id | SMF Header | str | System identifier |
| subsystem_id | SMF Header | str | DB2 subsystem ID |
| timestamp | SMF Header | datetime | Record creation timestamp |
| date | SMF Header | date | Record creation date |
| ifcid | QWHS Header | int | IFCID value |
| subsystem_name | QWHS Header | str | DB2 subsystem name |
| luwid | QWHS Header | str | Logical Unit of Work ID |

### Type 101 - Optional Headers

| Header Type | Name | Description |
|-------------|------|-------------|
| 2 | Correlation | Correlation information (QWHC) |
| 4 | Trace | Trace information (QWHT) |
| 8 | CPU | CPU usage information (QWHU) |
| 16 | Distributed | Distributed transaction info (QWHD) |
| 32 | Data Sharing | Data sharing information (QWHA) |

### Type 102 (Performance) - Common Fields

All Type 102 parsers extract these common fields:

| Field Name | Source | Type | Description |
|------------|--------|------|-------------|
| record_type | SMF Header | int | Always 102 |
| record_length | SMF Header | int | Total record length in bytes |
| system_id | SMF Header | str | System identifier |
| subsystem_id | SMF Header | str | DB2 subsystem ID |
| timestamp | SMF Header | datetime | Record creation timestamp |
| date | SMF Header | date | Record creation date |
| ifcid | QWHS Header | int | IFCID value |
| subsystem_name | QWHS Header | str | DB2 subsystem name |

### Version-Specific Differences

**V11 vs V12 vs V13**:
- Field layouts may differ between versions
- New fields added in later versions
- Some fields deprecated in later versions
- Always use the correct version parser for accurate results

**Note**: Detailed field-level documentation for each version is available in the SMF documentation files at `smf_docs/record-type-{type}_V{version}.md`.

## Adding New DB2 Versions

### Step 1: Create Parser Class

Create a new parser file in `tools/smf_analyzer/smf_record_parser/parsers/`:

```python
# smf100_parser_v11.py
from .db2_parser_base import DB2ParserBase
from .base_parser import BaseRecordParser
from ..models.data_models import ParsedRecord

class SMF100ParserV11(DB2ParserBase):
    """Parser for SMF Type 100 records - DB2 V11."""
    
    def __init__(self, base_parser: BaseRecordParser):
        super().__init__(base_parser)
        self.db2_version = "V11"
    
    def parse(self, record_data: bytes) -> ParsedRecord:
        """Parse SMF Type 100 record for DB2 V11."""
        # Validate record
        self.parser.validate_record_length(record_data)
        self.parser.validate_record_type(record_data, expected_type=100)
        
        # Parse SMF header
        smf_header = self.parse_smf_header(record_data)
        
        # Parse product section
        product_section = self.parse_product_section_header(record_data)
        
        # Parse QWHS header
        qwhs_offset = product_section['offset']
        qwhs = self.parse_qwhs_header(record_data, qwhs_offset)
        
        # Parse version-specific sections
        # ... implement V11-specific parsing logic ...
        
        # Build and return ParsedRecord
        return ParsedRecord(
            record_type=100,
            version=self.db2_version,
            system_id=smf_header['system_id'],
            timestamp=smf_header['timestamp'],
            date=smf_header['date'],
            sections={
                'smf_header': smf_header,
                'qwhs_header': qwhs,
                # ... additional sections ...
            }
        )
```

### Step 2: Register Parser in Factory

Update `tools/smf_analyzer/smf_record_parser/parsers/factory.py`:

```python
# Add import
from .smf100_parser_v11 import SMF100ParserV11

# Add to _db2_registry
_db2_registry: Dict[tuple[int, str], Type[RecordVersionStrategy]] = {
    # Existing entries...
    (100, "V10"): SMF100ParserV10,
    (100, "V11"): SMF100ParserV11,  # New entry
    # ...
}

# Update _db2_version_order if needed
_db2_version_order = ["V13", "V12", "V11", "V10"]  # Add V14, V15, etc.
```

### Step 3: Update Version Detection

If adding a new major version, update `db2_version_detector.py`:

```python
# Add to DB2_VERSION_MAP
DB2_VERSION_MAP: Dict[int, str] = {
    0x0A00: "V10",
    0x0B00: "V11",
    0x0C00: "V12",
    0x0D00: "V13",
    0x0E00: "V14",  # New version
}
```

### Step 4: Export Parser

Update `tools/smf_analyzer/smf_record_parser/parsers/__init__.py`:

```python
from .smf100_parser_v11 import SMF100ParserV11

__all__ = [
    # ... existing exports ...
    'SMF100ParserV11',
]
```

### Step 5: Create Database Schema (Optional)

If the new version requires schema changes, update `shared/database/schemas/smf_schemas.py`:

```python
class SMF100Schema:
    """Schema for SMF Type 100 - DB2 Statistics records."""
    
    def get_table_definitions(self) -> Dict[str, str]:
        return {
            'smf100_header': '''
                CREATE TABLE IF NOT EXISTS smf100_header (
                    record_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    system_id TEXT,
                    subsystem_id TEXT,
                    db2_version TEXT,
                    -- Add V11-specific fields here
                    new_v11_field TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''',
            # ... other tables ...
        }
```

### Step 6: Write Tests

Create unit tests in `tests/test_smf100_parser_v11.py`:

```python
import pytest
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

def test_smf100_v11_parser_creation():
    """Test that V11 parser can be created."""
    # Create test record with V11 version
    record_data = create_test_record(version=0x0B00)
    
    parser = SMFParserFactory.create_parser(100, record_data=record_data)
    assert parser is not None

def test_smf100_v11_parsing():
    """Test parsing V11 record."""
    record_data = load_test_record('type100_v11.bin')
    
    parser = SMFParserFactory.create_parser(100, record_data=record_data)
    result = parser.parse(record_data, version="V11")
    
    assert result.record_type == 100
    assert result.version == "V11"
    assert 'qwhs_header' in result.sections
```

### Step 7: Update Documentation

1. Update this guide with the new version
2. Add version-specific field mappings
3. Update supported versions table
4. Add examples for the new version

## Error Handling

### Common Errors

#### ValidationError

Raised when record structure is invalid:

```python
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError

try:
    parser = SMFParserFactory.create_parser(100, record_data=record_data)
    result = parser.parse(record_data, version="V10")
except ValidationError as e:
    print(f"Validation error: {e}")
    print(f"Error at offset: {e.offset}")
```

**Common causes**:
- Record type mismatch
- Record length mismatch
- Out-of-bounds offset
- Missing required header
- Corrupted product section

#### EncodingError

Raised when EBCDIC conversion fails:

```python
from tools.smf_analyzer.smf_record_parser.exceptions import EncodingError

try:
    result = parser.parse(record_data, version="V10")
except EncodingError as e:
    print(f"Encoding error: {e}")
    print(f"Field: {e.field_name}")
    print(f"Offset: {e.offset}")
```

**Common causes**:
- Invalid EBCDIC byte sequences
- Corrupted string fields
- Wrong encoding specified

#### UnsupportedVersionError

Raised when DB2 version is not supported:

```python
from tools.smf_analyzer.smf_record_parser.exceptions import UnsupportedVersionError

try:
    parser = SMFParserFactory.create_parser(100, record_data=record_data, allow_fallback=False)
except UnsupportedVersionError as e:
    print(f"Unsupported version: {e.version}")
    print(f"Record type: {e.record_type}")
    print(f"Available versions: {e.available_versions}")
```

**Common causes**:
- New DB2 version without parser
- Fallback disabled and no exact match
- Corrupted version field

### Error Recovery Strategies

#### Strategy 1: Enable Fallback

```python
# Allow fallback to nearest parser
try:
    parser = SMFParserFactory.create_parser(
        record_type=102,
        record_data=record_data,
        allow_fallback=True  # Enable fallback
    )
    result = parser.parse(record_data, version="V12")
except UnsupportedVersionError:
    print("No suitable parser found even with fallback")
```

#### Strategy 2: Skip Invalid Records

```python
from tools.smf_analyzer.smf_record_parser import SMFFileParser
from tools.smf_analyzer.smf_record_parser.exceptions import ValidationError

file_parser = SMFFileParser('smf_data.rdw')
valid_records = []
errors = []

for record_data in file_parser.read_records():
    try:
        parser = SMFParserFactory.create_parser(
            record_type=record_data[5],
            record_data=record_data
        )
        result = parser.parse(record_data, version="V10")
        valid_records.append(result)
    except (ValidationError, EncodingError) as e:
        errors.append((record_data, str(e)))

print(f"Parsed: {len(valid_records)}, Errors: {len(errors)}")
```

#### Strategy 3: Log and Continue

```python
import logging

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

for record_data in file_parser.read_records():
    try:
        parser = SMFParserFactory.create_parser(100, record_data=record_data)
        result = parser.parse(record_data, version="V10")
        # Process result
    except Exception as e:
        logger.warning(f"Failed to parse record: {e}")
        continue  # Skip to next record
```

## Troubleshooting

### Problem: "record_data required for DB2 record type"

**Cause**: Trying to create a DB2 parser without providing record_data

**Solution**:
```python
# Wrong
parser = SMFParserFactory.create_parser(100)

# Correct
parser = SMFParserFactory.create_parser(100, record_data=record_data)
```

### Problem: "No parser available for Type X VY"

**Cause**: Requested version doesn't have a registered parser

**Solutions**:

1. Enable fallback parsing:
```python
parser = SMFParserFactory.create_parser(
    record_type=102,
    record_data=record_data,
    allow_fallback=True
)
```

2. Check available versions:
```python
available = SMFParserFactory.list_db2_parsers()
print(f"Available for Type 102: {available[102]}")
```

3. Implement the missing parser (see "Adding New DB2 Versions")

### Problem: "Product section offset is 0"

**Cause**: Record doesn't have a product section or is corrupted

**Solution**:
```python
# Validate record before parsing
if len(record_data) < 36:
    print("Record too short")
    continue

product_offset = int.from_bytes(record_data[28:32], byteorder='big')
if product_offset == 0:
    print("No product section - not a DB2 record")
    continue
```

### Problem: "Failed to detect DB2 version"

**Cause**: QWHSRELN field is corrupted or invalid

**Solution**:
```python
from tools.smf_analyzer.smf_record_parser.parsers import DB2VersionDetector

try:
    version = DB2VersionDetector.detect_version(record_data, record_type)
except ValidationError as e:
    print(f"Version detection failed: {e}")
    # Try manual inspection
    product_offset = int.from_bytes(record_data[28:32], byteorder='big')
    qwhsreln_offset = product_offset + 6
    release_bytes = record_data[qwhsreln_offset:qwhsreln_offset+2]
    print(f"Raw release bytes: {release_bytes.hex()}")
```

### Problem: Fallback parser produces incorrect results

**Cause**: Version differences are too significant for fallback compatibility

**Solution**:

1. Disable fallback and implement proper parser:
```python
parser = SMFParserFactory.create_parser(
    record_type=102,
    record_data=record_data,
    allow_fallback=False
)
```

2. Validate critical fields after fallback parsing:
```python
result = parser.parse(record_data, version="V12")
if result.version != "V12":
    print(f"Warning: Using fallback parser {result.version}")
    # Validate critical fields
    validate_critical_fields(result)
```

### Problem: EBCDIC encoding errors

**Cause**: Invalid EBCDIC sequences or wrong encoding

**Solution**:

1. Check encoding setting:
```python
# Ensure EBCDIC encoding is used
parser = SMFParserFactory.create_parser(
    record_type=100,
    record_data=record_data,
    encoding="EBCDIC"  # Default
)
```

2. Handle encoding errors gracefully:
```python
try:
    result = parser.parse(record_data, version="V10")
except EncodingError as e:
    print(f"Encoding error in field {e.field_name} at offset {e.offset}")
    # Try alternative encoding or skip field
```

### Getting Help

If you encounter issues not covered here:

1. **Check logs**: Enable DEBUG logging to see detailed parsing information
   ```python
   import logging
   logging.basicConfig(level=logging.DEBUG)
   ```

2. **Inspect raw data**: Use hex dump to examine record structure
   ```python
   print(record_data[:100].hex())
   ```

3. **Consult documentation**: Review IBM SMF documentation for record layout details

4. **Report issues**: Include:
   - Record type and detected version
   - Error message and stack trace
   - First 100 bytes of record (hex dump)
   - Parser configuration used

## Summary

The DB2 SMF parser toolkit provides:

- ✅ Automatic DB2 version detection from records
- ✅ Version-specific parsers for Types 100, 101, 102
- ✅ Fallback parsing for unsupported versions
- ✅ Database loading with dedicated schemas
- ✅ Comprehensive error handling
- ✅ Extensible architecture for new versions

For more information, see:
- [SMF Record Parser Documentation](../tools/smf_analyzer/smf_record_parser/README.md)
- [Database Loading Guide](../tools/smf_analyzer/smf_loader/README.md)
- [IBM SMF Documentation](../smf_docs/)
