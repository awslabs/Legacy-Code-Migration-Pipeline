# Complete CICS Metadata Analysis - Step-by-Step Guide

This guide provides complete instructions for performing a comprehensive CICS metadata analysis, including CSD parsing, code analysis, complexity metrics, and report generation.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start (5 Commands)](#quick-start-5-commands)
3. [Detailed Step-by-Step Instructions](#detailed-step-by-step-instructions)
4. [Understanding the Results](#understanding-the-results)
5. [Troubleshooting](#troubleshooting)
6. [Advanced Options](#advanced-options)

---

## Prerequisites

### Required

- Python 3.8 or higher
- SQLite 3
- Legacy Analyzer installed
- Source code directory with:
  - COBOL programs (`.cbl`, `.cob`, `.cobol`)
  - CSD files (`.csd`) or CICS inventory CSV
  - JCL files (`.jcl`)
  - Assembler files (`.asm`, `.mac`) - optional
  - Copybooks (`.cpy`)

### Optional

- BMS maps (`.bms`) - for UI analysis
- REXX scripts - for mainframe exports

---

## Quick Start (5 Commands)

For the impatient, here's the complete analysis in 5 commands:

```bash
# 1. Analyze with CICS metadata (discovers CSD, parses, loads)
python examples/analyze_with_cics_metadata.py \
  --source-dir ./your-app-directory \
  --database ./results/analysis.db \
  --output-dir ./results \
  --keep-csv ./results/cics_inventory.csv

# 2. Analyze COBOL code
python -m legacy_analyzer analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language COBOL

# 3. Analyze JCL code
python -m legacy_analyzer analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language JCL

# 4. Analyze Assembler code (if present)
python -m legacy_analyzer analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language ASM

# 5. Run complexity analysis
python -m legacy_analyzer complexity analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language COBOL

# 6. Generate reports
python examples/generate_cics_reports.py \
  --database ./results/analysis.db \
  --output-dir ./results/cics \
  --format both

python examples/service_grouping_analysis.py \
  --database ./results/analysis.db \
  --output-dir ./results/services \
  --strategy all \
  --min-confidence LOW
```

**Time:** 5-15 minutes depending on codebase size

---

## Detailed Step-by-Step Instructions

### Step 1: Prepare Your Environment

#### 1.1 Create Output Directories

```bash
mkdir -p ./results/analysis
mkdir -p ./results/cics
mkdir -p ./results/services
```

#### 1.2 Verify Source Code Structure

```bash
# Check what files you have
find ./your-app-directory -type f -name "*.cbl" | wc -l  # COBOL programs
find ./your-app-directory -type f -name "*.csd" | wc -l  # CSD files
find ./your-app-directory -type f -name "*.jcl" | wc -l  # JCL files
find ./your-app-directory -type f -name "*.asm" | wc -l  # Assembler files
find ./your-app-directory -type f -name "*.cpy" | wc -l  # Copybooks
```

**Expected output:**
```
28    # COBOL programs
1     # CSD file
35    # JCL files
4     # Assembler files
46    # Copybooks
```

---

### Step 2: CICS Metadata Discovery and Loading

This step discovers CSD files, parses them, and loads CICS metadata into the database.

#### 2.1 Run CICS Metadata Analysis

```bash
python examples/analyze_with_cics_metadata.py \
  --source-dir ./your-app-directory \
  --database ./results/analysis.db \
  --output-dir ./results \
  --keep-csv ./results/cics_inventory.csv
```

**What this does:**
1. Scans directory for `.csd` files
2. Parses CSD files (TRANSACTION, PROGRAM, FILE, MAPSET definitions)
3. Converts to enhanced CSV format
4. Creates database schema
5. Loads CICS metadata into `inventory_cics` table
6. Detects ONLINE entry points (CICS transactions)
7. Generates entry points report

**Expected output:**
```
================================================================================
  Step 1: Discover Metadata Files
================================================================================

Discovered files:
  CSD files:  1
  CSV files:  0

✓ Metadata discovery complete

================================================================================
  Step 2: Parse CSD Files
================================================================================

Parsing CARDDEMO.csd...
  Transactions: 18
  Programs:     18
  Files:        8
  Mapsets:      17
  ✓ Parsed 61 resources

✓ Wrote 61 resources to CSV

================================================================================
  Step 3: Load CICS Metadata
================================================================================

✓ Loaded 61 CICS resources

================================================================================
  Step 4: Detect Entry Points
================================================================================

✓ Total entry points detected: 18

Entry Point Breakdown:
  ONLINE (CICS):    18
  BATCH (JCL):      0
  INFERRED (Code):  0
```

**Output files:**
- `results/analysis.db` - SQLite database
- `results/entry_points_<timestamp>.json` - Entry point analysis
- `results/cics_inventory.csv` - CICS inventory CSV

#### 2.2 Verify CICS Metadata Loading

```bash
# Check CICS resources loaded
sqlite3 ./results/analysis.db \
  "SELECT resource_type, COUNT(*) FROM inventory_cics GROUP BY resource_type;"
```

**Expected output:**
```
TRANSACTION|18
PROGRAM|18
FILE|8
MAPSET|17
```

---

### Step 3: Static Code Analysis

Analyze all code files to extract dependencies and populate the inventory.

#### 3.1 Analyze COBOL Code

```bash
python -m legacy_analyzer analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language COBOL
```

**What this does:**
1. Scans for COBOL files (`.cbl`, `.cob`, `.cobol`, `.cpy`)
2. Parses COBOL code
3. Extracts dependencies (CALL, COPY, file access)
4. Populates inventory table
5. Identifies program relationships

**Expected output:**
```
Analyzing COBOL files...
  Found 74 files to analyze
  Processed 10/74 files...
  Processed 20/74 files...
  ...
  ✓ Analyzed 74 files
  ✓ Total dependencies: 518

✓ Inventory populated:
  COPYBOOKs: 46 found, 46 analyzed
  PROGRAMs: 31 found, 28 analyzed
```

#### 3.2 Analyze JCL Code

```bash
python -m legacy_analyzer analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language JCL
```

**What this does:**
1. Scans for JCL files (`.jcl`, `.JCL`)
2. Parses JCL procedures
3. Extracts program executions (EXEC PGM=)
4. Identifies BATCH entry points

**Expected output:**
```
Analyzing JCL files...
  Found 35 files to analyze
  ✓ Analyzed 35 files
  ✓ Total dependencies: 175

✓ Inventory populated:
  PROCEDUREs: 35 found, 35 analyzed
```

#### 3.3 Analyze Assembler Code (if present)

```bash
python -m legacy_analyzer analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language ASM
```

**What this does:**
1. Scans for Assembler files (`.asm`, `.mac`, `.s`)
2. Parses assembler code
3. Extracts macro calls and dependencies

**Expected output:**
```
Analyzing ASM files...
  Found 4 files to analyze
  ✓ Analyzed 4 files
  ✓ Total dependencies: 40

✓ Inventory populated:
  MACROs: 2 found, 2 analyzed
  PROGRAMs: 2 found, 2 analyzed
```

#### 3.4 Verify Code Analysis

```bash
# Check inventory
sqlite3 ./results/analysis.db \
  "SELECT artifact_type, COUNT(*) FROM inventory GROUP BY artifact_type;"
```

**Expected output:**
```
COPYBOOK|138
PROCEDURE|105
PROGRAM|93
MACRO|6
```

**Note:** Counts may include duplicates from multiple analysis runs.

---

### Step 4: Complexity Analysis

Calculate complexity metrics for all programs.

#### 4.1 Analyze COBOL Complexity

```bash
python -m legacy_analyzer complexity analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language COBOL
```

**What this does:**
1. Analyzes all COBOL programs
2. Calculates:
   - Lines of code (LOC)
   - Cyclomatic complexity
   - Composite complexity score
   - Complexity tier (LOW, MEDIUM, HIGH, VERY_HIGH)
3. Stores in `complexity_metrics` table

**Expected output:**
```
Analyzing complexity...
  Analyzed 10 files...
  Analyzed 20 files...
  ...
  ✓ Analysis complete:
    Files analyzed: 74
    Errors: 0

Complexity Distribution:
  LOW              51 ( 68.9%)
  MEDIUM           15 ( 20.3%)
  HIGH              6 (  8.1%)
  VERY_HIGH         2 (  2.7%)
```

#### 4.2 Analyze Assembler Complexity (if present)

```bash
python -m legacy_analyzer complexity analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language ASM
```

**Expected output:**
```
Complexity Distribution:
  LOW               4 (100.0%)
```

#### 4.3 Verify Complexity Metrics

```bash
# Check complexity metrics
sqlite3 ./results/analysis.db \
  "SELECT complexity_tier, COUNT(*) FROM complexity_metrics GROUP BY complexity_tier;"
```

**Expected output:**
```
LOW|55
MEDIUM|15
HIGH|6
VERY_HIGH|2
```

#### 4.4 View Top Complex Programs

```bash
sqlite3 ./results/analysis.db \
  "SELECT program_name, composite_score, complexity_tier 
   FROM complexity_metrics 
   ORDER BY composite_score DESC 
   LIMIT 10;"
```

**Expected output:**
```
COCRDUPC|97.985|VERY_HIGH
COCRDLIC|76.479|VERY_HIGH
COUSR00C|49.993|HIGH
COTRN00C|49.187|HIGH
...
```

---

### Step 5: Generate Reports

Generate comprehensive reports with all analysis data.

#### 5.1 Generate CICS Transaction Reports

```bash
python examples/generate_cics_reports.py \
  --database ./results/analysis.db \
  --output-dir ./results/cics \
  --format both
```

**What this does:**
1. Queries all CICS transactions
2. Analyzes call trees
3. Identifies data dependencies
4. Retrieves complexity metrics
5. Generates API endpoint suggestions
6. Creates JSON and HTML reports

**Expected output:**
```
Generating reports for 18 transactions...

  Processing CAUP (COACTUPC)...
    Call tree depth: 2
    Programs called: 3
    Complexity: 17.82 (MEDIUM)
    API suggestion: PUT /accounts/{id}

✓ Generated 18 transaction reports
```

**Output files:**
- `results/cics/cics_transactions_<timestamp>.json` - JSON summary
- `results/cics/cics_transactions_<timestamp>.html` - Interactive HTML report
- `results/cics/transactions/*.json` - Individual transaction reports (18 files)

#### 5.2 Generate Service Grouping Analysis

```bash
python examples/service_grouping_analysis.py \
  --database ./results/analysis.db \
  --output-dir ./results/services \
  --strategy all \
  --min-confidence LOW
```

**What this does:**
1. Groups transactions by CICS GROUP
2. Analyzes shared data access patterns
3. Identifies shared program dependencies
4. Calculates consolidation scores
5. Generates service candidate recommendations

**Expected output:**
```
Analyzing CICS groups...
✓ Found 1 service candidates

Service Candidates:

  Carddemo Service
    CICS Group:       CARDDEMO
    Entry Points:     18
    Shared Data:      8
    Shared Programs:  12
    Confidence:       MEDIUM
    Recommendation:   CONSIDER_MERGE
```

**Output files:**
- `results/services/service_candidates_<strategy>_<timestamp>.json`
- `results/services/service_grouping_summary_<timestamp>.md`

---

### Step 6: Review Results

#### 6.1 Open Interactive HTML Report

```bash
# macOS
open ./results/cics/cics_transactions_*.html

# Linux
xdg-open ./results/cics/cics_transactions_*.html

# Windows
start ./results/cics/cics_transactions_*.html
```

#### 6.2 Review Entry Points

```bash
cat ./results/entry_points_*.json | python -m json.tool | less
```

#### 6.3 Review Service Grouping

```bash
cat ./results/services/service_grouping_summary_*.md
```

#### 6.4 Query Database Directly

```bash
# View all CICS transactions
sqlite3 ./results/analysis.db \
  "SELECT resource_name, program_name, description 
   FROM inventory_cics 
   WHERE resource_type='TRANSACTION' 
   ORDER BY resource_name;"

# View complexity by tier
sqlite3 ./results/analysis.db \
  "SELECT complexity_tier, COUNT(*), 
          ROUND(AVG(composite_score), 2) as avg_score 
   FROM complexity_metrics 
   GROUP BY complexity_tier 
   ORDER BY avg_score DESC;"

# View top 10 most complex programs
sqlite3 ./results/analysis.db \
  "SELECT program_name, code_lines, cyclomatic_complexity, 
          composite_score, complexity_tier 
   FROM complexity_metrics 
   ORDER BY composite_score DESC 
   LIMIT 10;"
```

---

## Understanding the Results

### Entry Points Report

**File:** `results/entry_points_<timestamp>.json`

**Structure:**
```json
{
  "metadata": {
    "total_entry_points": 18,
    "by_type": {
      "ONLINE": 18,
      "BATCH": 0,
      "INFERRED": 0
    }
  },
  "entry_points": {
    "online": [
      {
        "program_name": "COACTUPC",
        "entry_type": "ONLINE",
        "confidence": "EXPLICIT",
        "transaction_id": "CAUP",
        "cics_group": "CARDDEMO",
        "status": "ENABLED",
        "description": "Account Update"
      }
    ]
  }
}
```

**Key fields:**
- `entry_type`: ONLINE (CICS), BATCH (JCL), or INFERRED (code analysis)
- `confidence`: EXPLICIT (from metadata) or INFERRED (from code)
- `transaction_id`: 4-character CICS transaction code
- `cics_group`: CICS group name (for service grouping)

### CICS Transaction Reports

**File:** `results/cics/cics_transactions_<timestamp>.json`

**Structure:**
```json
{
  "transactions": [
    {
      "transaction_id": "CAUP",
      "program": "COACTUPC",
      "group": "CARDDEMO",
      "status": "ENABLED",
      "description": "Account Update",
      "call_tree": {
        "depth": 2,
        "programs": ["COACTUPC", "CBACT01C"],
        "total_programs": 2
      },
      "data_dependencies": {
        "files": ["ACCTDAT", "CUSTDAT"],
        "datasets": ["AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS"]
      },
      "complexity": {
        "composite_score": 17.82,
        "tier": "MEDIUM"
      },
      "modernization": {
        "suggested_api_endpoint": "PUT /accounts/{id}",
        "suggested_service": "Account Management Service",
        "http_method": "PUT"
      }
    }
  ]
}
```

### Service Grouping Report

**File:** `results/services/service_grouping_summary_<timestamp>.md`

**Contains:**
- Service candidates grouped by strategy
- Entry points per service
- Shared data and programs
- Confidence levels
- Recommendations (CONSIDER_MERGE, NEEDS_REVIEW, etc.)

### Complexity Metrics

**Database table:** `complexity_metrics`

**Key metrics:**
- `code_lines`: Lines of code (excluding comments)
- `cyclomatic_complexity`: Number of decision points
- `composite_score`: Overall complexity score
- `complexity_tier`: LOW, MEDIUM, HIGH, VERY_HIGH

**Interpretation:**
- **LOW (< 10):** Simple, easy to migrate
- **MEDIUM (10-25):** Standard complexity, manageable
- **HIGH (25-50):** Complex, requires careful planning
- **VERY_HIGH (> 50):** Very complex, requires refactoring

---

## Troubleshooting

### Issue: No CSD files found

**Symptom:**
```
Discovered files:
  CSD files:  0
```

**Solutions:**
1. Check file extension: `.csd` (lowercase)
2. Verify file location in source directory
3. Use absolute path: `--source-dir /full/path/to/app`
4. Alternative: Use CSV export instead

**Workaround:**
```bash
# If you have CSV export from mainframe
python -m legacy_analyzer load \
  --type cics \
  --file your_cics_inventory.csv \
  --db ./results/analysis.db
```

### Issue: No entry points detected

**Symptom:**
```
✓ Total entry points detected: 0
```

**Solutions:**
1. Verify CICS metadata loaded:
   ```bash
   sqlite3 ./results/analysis.db \
     "SELECT COUNT(*) FROM inventory_cics WHERE resource_type='TRANSACTION';"
   ```
2. Check database path is correct
3. Re-run Step 2 (CICS metadata loading)

### Issue: Dependencies not stored

**Symptom:**
```
Dependencies stored: 0
```

**This is expected behavior.** Dependencies are identified but not currently stored in the `artifact_dependencies` table. The analysis still works correctly for:
- Inventory population
- Complexity calculation
- Report generation

**To verify dependencies were found:**
```bash
sqlite3 ./results/analysis.db \
  "SELECT COUNT(*) FROM inventory WHERE artifact_type='PROGRAM';"
```

### Issue: Complexity metrics missing

**Symptom:**
```
Error getting complexity metrics: no such table: complexity_metrics
```

**Solution:**
Run Step 4 (Complexity Analysis):
```bash
python -m legacy_analyzer complexity analyze \
  --source-dir ./your-app-directory \
  --db ./results/analysis.db \
  --language COBOL
```

### Issue: Reports show no call trees

**Symptom:**
```
Call tree depth: 0
Programs called: 1
```

**This is expected** if static code analysis hasn't been run. Call trees require dependency analysis.

**Solution:**
Run Step 3 (Static Code Analysis) before generating reports.

---

## Advanced Options

### Option 1: Analyze Specific Transactions

```bash
python examples/generate_cics_reports.py \
  --database ./results/analysis.db \
  --output-dir ./results/cics \
  --transaction-id CAUP \
  --format json
```

### Option 2: Include Disabled Transactions

```bash
python examples/analyze_with_cics_metadata.py \
  --source-dir ./your-app-directory \
  --database ./results/analysis.db \
  --include-disabled
```

### Option 3: Different Service Grouping Strategies

```bash
# Group by CICS GROUP only
python examples/service_grouping_analysis.py \
  --database ./results/analysis.db \
  --strategy cics-group \
  --min-confidence MEDIUM

# Group by data ownership
python examples/service_grouping_analysis.py \
  --database ./results/analysis.db \
  --strategy data-ownership

# Group by shared programs
python examples/service_grouping_analysis.py \
  --database ./results/analysis.db \
  --strategy shared-programs
```

### Option 4: Analyze Multiple Languages at Once

```bash
# Create a script to analyze all languages
cat > analyze_all.sh << 'EOF'
#!/bin/bash
DB="./results/analysis.db"
SRC="./your-app-directory"

echo "Analyzing COBOL..."
python -m legacy_analyzer analyze --source-dir "$SRC" --db "$DB" --language COBOL

echo "Analyzing JCL..."
python -m legacy_analyzer analyze --source-dir "$SRC" --db "$DB" --language JCL

echo "Analyzing Assembler..."
python -m legacy_analyzer analyze --source-dir "$SRC" --db "$DB" --language ASM

echo "Calculating complexity..."
python -m legacy_analyzer complexity analyze --source-dir "$SRC" --db "$DB" --language COBOL
python -m legacy_analyzer complexity analyze --source-dir "$SRC" --db "$DB" --language ASM

echo "Done!"
EOF

chmod +x analyze_all.sh
./analyze_all.sh
```

### Option 5: Export Results to CSV

```bash
# Export CICS transactions
sqlite3 -header -csv ./results/analysis.db \
  "SELECT resource_name, program_name, group_name, status, description 
   FROM inventory_cics 
   WHERE resource_type='TRANSACTION';" \
  > ./results/cics_transactions.csv

# Export complexity metrics
sqlite3 -header -csv ./results/analysis.db \
  "SELECT program_name, code_lines, cyclomatic_complexity, 
          composite_score, complexity_tier 
   FROM complexity_metrics 
   ORDER BY composite_score DESC;" \
  > ./results/complexity_metrics.csv
```

---

## Complete Analysis Script

Save this as `complete_analysis.sh` for one-command execution:

```bash
#!/bin/bash
set -e  # Exit on error

# Configuration
SOURCE_DIR="${1:-./examples/code/cobol/carddemoV2}"
OUTPUT_DIR="${2:-./results/full_analysis}"
DATABASE="$OUTPUT_DIR/analysis.db"

echo "================================================================================"
echo "  Complete CICS Metadata Analysis"
echo "================================================================================"
echo ""
echo "Configuration:"
echo "  Source:   $SOURCE_DIR"
echo "  Output:   $OUTPUT_DIR"
echo "  Database: $DATABASE"
echo ""

# Create directories
mkdir -p "$OUTPUT_DIR/cics"
mkdir -p "$OUTPUT_DIR/services"

# Step 1: CICS Metadata Analysis
echo "Step 1: CICS Metadata Analysis..."
python examples/analyze_with_cics_metadata.py \
  --source-dir "$SOURCE_DIR" \
  --database "$DATABASE" \
  --output-dir "$OUTPUT_DIR" \
  --keep-csv "$OUTPUT_DIR/cics_inventory.csv"

# Step 2: Static Code Analysis
echo ""
echo "Step 2: Static Code Analysis..."

echo "  Analyzing COBOL..."
python -m legacy_analyzer analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language COBOL

echo "  Analyzing JCL..."
python -m legacy_analyzer analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language JCL

echo "  Analyzing Assembler..."
python -m legacy_analyzer analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language ASM

# Step 3: Complexity Analysis
echo ""
echo "Step 3: Complexity Analysis..."

echo "  Analyzing COBOL complexity..."
python -m legacy_analyzer complexity analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language COBOL

echo "  Analyzing Assembler complexity..."
python -m legacy_analyzer complexity analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language ASM

# Step 4: Generate Reports
echo ""
echo "Step 4: Generating Reports..."

echo "  Generating CICS transaction reports..."
python examples/generate_cics_reports.py \
  --database "$DATABASE" \
  --output-dir "$OUTPUT_DIR/cics" \
  --format both

echo "  Generating service grouping analysis..."
python examples/service_grouping_analysis.py \
  --database "$DATABASE" \
  --output-dir "$OUTPUT_DIR/services" \
  --strategy all \
  --min-confidence LOW

# Summary
echo ""
echo "================================================================================"
echo "  Analysis Complete!"
echo "================================================================================"
echo ""
echo "Results saved to: $OUTPUT_DIR"
echo ""
echo "Generated files:"
echo "  - Entry points:     $OUTPUT_DIR/entry_points_*.json"
echo "  - CICS reports:     $OUTPUT_DIR/cics/"
echo "  - Service grouping: $OUTPUT_DIR/services/"
echo "  - Database:         $DATABASE"
echo ""
echo "Next steps:"
echo "  1. Open HTML report: open $OUTPUT_DIR/cics/cics_transactions_*.html"
echo "  2. Review summary:   cat $OUTPUT_DIR/services/service_grouping_summary_*.md"
echo "  3. Query database:   sqlite3 $DATABASE"
echo ""
```

**Usage:**
```bash
# Use default paths
./complete_analysis.sh

# Specify custom paths
./complete_analysis.sh ./my-app ./my-results

# Make executable first
chmod +x complete_analysis.sh
```

---

## Summary

### Complete Analysis Checklist

- [ ] **Step 1:** CICS Metadata Discovery and Loading
  - [ ] Discover CSD files
  - [ ] Parse CSD files
  - [ ] Load into database
  - [ ] Detect ONLINE entry points

- [ ] **Step 2:** Static Code Analysis
  - [ ] Analyze COBOL code
  - [ ] Analyze JCL code
  - [ ] Analyze Assembler code (if present)
  - [ ] Verify inventory populated

- [ ] **Step 3:** Complexity Analysis
  - [ ] Analyze COBOL complexity
  - [ ] Analyze Assembler complexity (if present)
  - [ ] Verify complexity metrics

- [ ] **Step 4:** Generate Reports
  - [ ] Generate CICS transaction reports
  - [ ] Generate service grouping analysis
  - [ ] Review HTML report
  - [ ] Review service grouping summary

### Expected Results

After completing all steps, you should have:

✅ **Database** with complete inventory and metrics  
✅ **Entry points** report (ONLINE + BATCH)  
✅ **CICS transaction reports** (JSON + HTML)  
✅ **Service grouping analysis** with recommendations  
✅ **Complexity metrics** for all programs  
✅ **API endpoint suggestions** for modernization  
✅ **Migration roadmap** with effort estimates  

### Time Estimates

| Step | Time | Notes |
|------|------|-------|
| Step 1: CICS Metadata | 1-2 min | Fast |
| Step 2: Code Analysis | 2-5 min | Depends on codebase size |
| Step 3: Complexity | 1-3 min | Fast |
| Step 4: Reports | 1-2 min | Fast |
| **Total** | **5-15 min** | For typical application |

---

## Additional Resources

- **CICS Workflows Guide:** `docs/CICS_WORKFLOWS.md`
- **CICS Metadata Guide:** `legacy_analyzer/docs/CICS_METADATA_GUIDE.md`
- **CLI Reference:** `docs/CLI_REFERENCE.md`
- **Example Scripts:** `examples/` directory
- **Migration Guide:** `legacy_analyzer/docs/MIGRATION_GUIDE.md`

---

**Last Updated:** November 26, 2025  
**Version:** 1.0  
**Maintained By:** Legacy Analyzer Team
