# Legacy Analyzer CLI Command Mapping

This document explains the relationship between the old and new CLI command structures, and how they map to the overall analysis workflow.

## Table of Contents

- [Overview](#overview)
- [Command Architecture](#command-architecture)
- [New CLI Commands (Workflow-Based)](#new-cli-commands-workflow-based)
- [Old CLI Commands (Feature-Based)](#old-cli-commands-feature-based)
- [Command Mapping](#command-mapping)
- [Typical Workflows](#typical-workflows)
- [Migration Guide](#migration-guide)

## Overview

The Legacy Analyzer has two CLI interfaces:

1. **New CLI** (`tools/legacy_analyzer/cli.py`) - Workflow-based commands that follow the analysis pipeline
2. **Old CLI** (backward compatibility via `legacy_analyzer/cli_compat.py`) - Feature-based commands for specific analysis tasks

Both CLIs are accessible through `python -m legacy_analyzer`, with the backward compatibility layer automatically routing commands to the appropriate implementation.

## Command Architecture

### Analysis Pipeline

The Legacy Analyzer follows a sequential analysis pipeline:

```
┌─────────────┐
│  INVENTORY  │  Discover all source files
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ DEPENDENCIES│  Parse files and extract dependencies
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  ANALYSIS   │  Flow, complexity, missing code detection
└──────┬──────┘
       │
       ▼
┌─────────────┐
│   REPORTS   │  Generate reports and packages
└─────────────┘
```

### Two Approaches

**New CLI (Workflow-Based)**:
- Commands represent stages in the pipeline
- Example: `analyze`, `inventory`, `dependencies`
- Best for: Complete analysis workflows, automation

**Old CLI (Feature-Based)**:
- Commands represent specific analysis features
- Example: `flow`, `complexity`, `missing`, `package`
- Best for: Targeted analysis, querying existing data

## New CLI Commands (Workflow-Based)

### `analyze` - Complete Analysis Workflow

**Purpose**: Run the entire analysis pipeline from start to finish.

**What it does**:
1. Discovers all source files (inventory)
2. Parses files and extracts dependencies
3. Optionally calculates complexity metrics
4. Optionally performs program-level analysis
5. Optionally performs copybook analysis
6. Stores everything in the database

**Usage**:
```bash
# Basic complete analysis
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db

# With complexity metrics
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db --complexity

# Disable advanced features
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db \
  --no-program-level --no-copybook-analysis
```

**Equivalent to running**:
```bash
# Old CLI equivalent (multiple commands)
python -m legacy_analyzer inventory --source-dir ./code --db analyzer.db
python -m legacy_analyzer dependencies --db analyzer.db
python -m legacy_analyzer complexity analyze --source-dir ./code --db analyzer.db
python -m legacy_analyzer flow analyze --program <each-program> --db analyzer.db
```

---

### `inventory` - Discovery Phase Only

**Purpose**: Discover and catalog all source files without analyzing them.

**What it does**:
1. Scans the source directory
2. Identifies file types (COBOL, PL/I, JCL, etc.)
3. Populates the `inventory` table
4. Does NOT parse files or extract dependencies

**Usage**:
```bash
python -m legacy_analyzer inventory --source-dir ./code --db analyzer.db
```

**Use when**:
- You want to see what files exist before full analysis
- You're building the inventory incrementally
- You want to validate file discovery before expensive parsing

---

### `dependencies` - Dependency Analysis Only

**Purpose**: Parse files and extract dependencies (requires existing inventory).

**What it does**:
1. Reads inventory from database
2. Parses each file
3. Extracts dependencies (CALL, COPY, EXEC, etc.)
4. Stores dependencies in `artifact_dependencies` table
5. Optionally calculates complexity
6. Optionally performs program-level and copybook analysis

**Usage**:
```bash
# Basic dependency analysis
python -m legacy_analyzer dependencies --db analyzer.db

# With complexity
python -m legacy_analyzer dependencies --db analyzer.db --complexity
```

**Prerequisites**: Must run `inventory` first

---

### `artifacts` - Specialized Artifact Parsing

**Purpose**: Parse and load specialized artifacts (CSD, JCL) without full analysis.

**What it does**:
1. Parses CSD files (CICS definitions)
2. Parses JCL files (job definitions)
3. Populates specialized tables (`inventory_cics`, `inventory_jcl`)

**Usage**:
```bash
# Parse all specialized artifacts
python -m legacy_analyzer artifacts --source-dir ./code --db analyzer.db

# Parse only CSD files
python -m legacy_analyzer artifacts --source-dir ./code --db analyzer.db --type csd

# Parse only JCL files
python -m legacy_analyzer artifacts --source-dir ./code --db analyzer.db --type jcl
```

---

### `program-level` - Program-Level Analysis

**Purpose**: Detect program boundaries within multi-program files.

**What it does**:
1. Runs complete analysis
2. Focuses on detecting program boundaries (e.g., multiple programs in one COBOL file)
3. Stores program-level dependencies

**Usage**:
```bash
python -m legacy_analyzer program-level --source-dir ./code --db analyzer.db
```

---

### `copybook-analysis` - Copybook Analysis

**Purpose**: Analyze copybook usage and dependencies.

**What it does**:
1. Runs complete analysis
2. Focuses on copybook relationships
3. Stores copybook analysis results

**Usage**:
```bash
python -m legacy_analyzer copybook-analysis --source-dir ./code --db analyzer.db
```

---

### `status` - Database Status Check

**Purpose**: Check what data exists in the database.

**What it does**:
1. Queries database tables
2. Reports counts of artifacts, dependencies, etc.
3. Shows analysis completeness

**Usage**:
```bash
python -m legacy_analyzer status --db analyzer.db
```

**Output**:
```
DATABASE STATUS
================================================================
Database: analyzer.db
Inventory exists: Yes
Dependencies exist: Yes
Artifacts in inventory: 1,234
Dependencies stored: 5,678
CICS resources: 45
JCL jobs: 23
Programs: 890
Copybooks: 234
================================================================
```

## Old CLI Commands (Feature-Based)

### `flow` - Flow Analysis

**Purpose**: Analyze program execution flows and call graphs.

**Subcommands**:
- `flow analyze` - Analyze flow for a specific program
- `flow graph` - Generate call graph visualization
- `flow entry-points` - Find entry point programs
- `flow circular` - Detect circular dependencies

**Usage**:
```bash
# Analyze flow for specific program
python -m legacy_analyzer flow analyze --program PAYROLL1 --db analyzer.db

# Generate call graph
python -m legacy_analyzer flow graph --db analyzer.db --output graph.mmd

# Find entry points
python -m legacy_analyzer flow entry-points --db analyzer.db

# Find entry points with CICS metadata
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata

# Detect circular dependencies
python -m legacy_analyzer flow circular --db analyzer.db
```

**Prerequisites**: Requires `analyze` or `dependencies` to have been run first

---

### `complexity` - Complexity Analysis

**Purpose**: Analyze code complexity metrics.

**Subcommands**:
- `complexity analyze` - Calculate complexity for source files
- `complexity report` - Generate complexity report
- `complexity summary` - Show complexity distribution

**Usage**:
```bash
# Analyze complexity
python -m legacy_analyzer complexity analyze \
  --source-dir ./code --db analyzer.db

# Generate report
python -m legacy_analyzer complexity report --db analyzer.db

# Show summary
python -m legacy_analyzer complexity summary --db analyzer.db
```

---

### `missing` - Missing Code Detection

**Purpose**: Detect artifacts referenced but not found in inventory.

**Subcommands**:
- `missing detect` - Find missing artifacts
- `missing completeness` - Calculate inventory completeness

**Usage**:
```bash
# Detect missing artifacts
python -m legacy_analyzer missing detect --db analyzer.db

# Calculate completeness
python -m legacy_analyzer missing completeness --db analyzer.db
```

**Prerequisites**: Requires `analyze` or `dependencies` to have been run first

---

### `package` - Migration Packages

**Purpose**: Create and manage migration packages.

**Subcommands**:
- `package create` - Create migration package
- `package validate` - Validate package
- `package list` - List packages

**Usage**:
```bash
# Create package
python -m legacy_analyzer package create \
  --name Payroll --seeds PAYROLL1,PAYCALC --db analyzer.db

# Validate package
python -m legacy_analyzer package validate \
  --package payroll.json --db analyzer.db

# List packages
python -m legacy_analyzer package list --db analyzer.db
```

**Prerequisites**: Requires `analyze` to have been run first

---

### `report` - Report Generation

**Purpose**: Generate various analysis reports.

**Subcommands**:
- `report executive` - Executive summary
- `report artifact` - Artifact-specific report
- `report package` - Package report

**Usage**:
```bash
# Executive summary
python -m legacy_analyzer report executive --db analyzer.db

# Artifact report
python -m legacy_analyzer report artifact --name PAYROLL1 --db analyzer.db

# Package report
python -m legacy_analyzer report package --package payroll.json --db analyzer.db
```

**Prerequisites**: Requires `analyze` to have been run first

---

### `load` - Load Inventory Data

**Purpose**: Load pre-existing inventory data from CSV files.

**Usage**:
```bash
# Load CICS inventory
python -m legacy_analyzer load --type cics --file cics.csv --db analyzer.db

# Load JCL inventory
python -m legacy_analyzer load --type jcl --file jcl.csv --db analyzer.db

# Load program inventory
python -m legacy_analyzer load --type programs --file programs.csv --db analyzer.db
```

---

### `metadata` - CICS Metadata Integration

**Purpose**: Parse and convert CICS metadata files.

**Subcommands**:
- `metadata convert-csd` - Convert CSD to CSV
- `metadata scan` - Scan directory for metadata files

**Usage**:
```bash
# Convert CSD to CSV
python -m legacy_analyzer metadata convert-csd \
  --input app.csd --output cics.csv

# Scan for metadata files
python -m legacy_analyzer metadata scan --directory ./metadata
```

## Command Mapping

### How New Commands Map to Old Commands

| New Command | Includes Old Commands | Notes |
|-------------|----------------------|-------|
| `analyze` | `complexity analyze` + partial `flow` + partial `missing` | Complete workflow |
| `inventory` | N/A | New concept - discovery only |
| `dependencies` | Partial `flow` + partial `missing` | Dependency extraction |
| `artifacts` | Partial `load` | Specialized parsing |
| `status` | N/A | New concept - status check |

### How Old Commands Map to New Commands

| Old Command | New Command Equivalent | Notes |
|-------------|------------------------|-------|
| `flow analyze` | Run `analyze` first, then query database | Requires complete analysis |
| `flow graph` | Run `analyze` first, then query database | Requires complete analysis |
| `flow entry-points` | Run `analyze` first, then query database | Requires complete analysis |
| `flow circular` | Run `analyze` first, then query database | Requires complete analysis |
| `complexity analyze` | `analyze --complexity` | Part of complete workflow |
| `complexity report` | Run `analyze --complexity` first, then query | Requires complexity data |
| `complexity summary` | Run `analyze --complexity` first, then query | Requires complexity data |
| `missing detect` | Run `analyze` first, then query database | Requires complete analysis |
| `missing completeness` | Run `analyze` first, then query database | Requires complete analysis |
| `package create` | Run `analyze` first, then create package | Requires complete analysis |
| `package validate` | Run `analyze` first, then validate | Requires complete analysis |
| `package list` | Query database | No analysis needed |
| `report executive` | Run `analyze` first, then generate report | Requires complete analysis |
| `report artifact` | Run `analyze` first, then generate report | Requires complete analysis |
| `report package` | Run `analyze` first, then generate report | Requires complete analysis |
| `load` | `artifacts` or manual CSV import | Specialized loading |
| `metadata convert-csd` | `artifacts --type csd` | CSD parsing |

## Typical Workflows

### Workflow 1: Complete Analysis (Recommended)

**Goal**: Analyze everything from scratch

```bash
# Single command - does everything
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db --complexity

# Then query results
python -m legacy_analyzer flow entry-points --db analyzer.db
python -m legacy_analyzer complexity report --db analyzer.db
python -m legacy_analyzer missing detect --db analyzer.db
python -m legacy_analyzer package create --name MyApp --seeds MAIN1,MAIN2 --db analyzer.db
```

### Workflow 2: Incremental Analysis

**Goal**: Build analysis step by step

```bash
# Step 1: Discover files
python -m legacy_analyzer inventory --source-dir ./code --db analyzer.db

# Step 2: Check what was found
python -m legacy_analyzer status --db analyzer.db

# Step 3: Analyze dependencies
python -m legacy_analyzer dependencies --db analyzer.db --complexity

# Step 4: Query results
python -m legacy_analyzer flow entry-points --db analyzer.db
```

### Workflow 3: Targeted Analysis

**Goal**: Analyze specific aspects only

```bash
# Complete analysis first
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db

# Then run targeted queries
python -m legacy_analyzer flow analyze --program PAYROLL1 --db analyzer.db
python -m legacy_analyzer complexity report --program PAYROLL1 --db analyzer.db
python -m legacy_analyzer report artifact --name PAYROLL1 --db analyzer.db
```

### Workflow 4: CICS Metadata Integration

**Goal**: Include CICS transaction metadata

```bash
# Step 1: Convert CSD files
python -m legacy_analyzer metadata convert-csd \
  --input app.csd --output cics.csv

# Step 2: Load CICS inventory
python -m legacy_analyzer load --type cics --file cics.csv --db analyzer.db

# Step 3: Run complete analysis
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db

# Step 4: Find entry points with metadata
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata
```

### Workflow 5: Migration Package Creation

**Goal**: Create migration packages for modernization

```bash
# Step 1: Complete analysis
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db --complexity

# Step 2: Find entry points
python -m legacy_analyzer flow entry-points --db analyzer.db --use-metadata

# Step 3: Create packages from entry points
python -m legacy_analyzer package create \
  --name OnlineTransactions \
  --seeds COACTUPC,COACTUP,COCRDLIC \
  --db analyzer.db

# Step 4: Validate package
python -m legacy_analyzer package validate \
  --package OnlineTransactions.json \
  --db analyzer.db \
  --max-artifacts 100 \
  --max-loc 50000

# Step 5: Generate reports
python -m legacy_analyzer report package \
  --package OnlineTransactions.json \
  --db analyzer.db
```

## Migration Guide

### From Old CLI to New CLI

If you're using the old CLI commands, here's how to migrate:

**Old approach** (multiple commands):
```bash
# Discover files (not available in old CLI)
# Parse and analyze
python -m legacy_analyzer complexity analyze --source-dir ./code --db analyzer.db
# Query results
python -m legacy_analyzer flow entry-points --db analyzer.db
python -m legacy_analyzer complexity report --db analyzer.db
```

**New approach** (single command):
```bash
# Complete analysis
python -m legacy_analyzer analyze --source-dir ./code --db analyzer.db --complexity

# Query results (same as before)
python -m legacy_analyzer flow entry-points --db analyzer.db
python -m legacy_analyzer complexity report --db analyzer.db
```

### Backward Compatibility

**All old commands still work!** The backward compatibility layer ensures existing scripts continue to function:

```bash
# These all still work
python -m legacy_analyzer flow analyze --program PROG1 --db analyzer.db
python -m legacy_analyzer complexity report --db analyzer.db
python -m legacy_analyzer missing detect --db analyzer.db
python -m legacy_analyzer package create --name Pkg --seeds PROG1 --db analyzer.db
```

### When to Use Which CLI

**Use New CLI (`analyze`, `inventory`, `dependencies`) when**:
- Starting a new analysis project
- Running complete analysis workflows
- Automating analysis pipelines
- Building analysis incrementally

**Use Old CLI (`flow`, `complexity`, `missing`, `package`) when**:
- Querying existing analysis results
- Running targeted analysis on specific programs
- Generating reports from existing data
- Working with existing scripts/automation

**Best Practice**: Use `analyze` for initial analysis, then use old CLI commands for querying and reporting.

## Summary

- **New CLI** = Workflow stages (inventory → dependencies → analysis)
- **Old CLI** = Feature queries (flow, complexity, missing, packages)
- **`analyze`** = Complete workflow in one command
- **Old commands** = Query results after `analyze` completes
- **Both CLIs work** = Backward compatibility maintained
- **Recommended** = Use `analyze` first, then query with old commands
