# SMF Migration Toolkit - Quick Start Guide

## Overview

This guide gets you up and running with the SMF Migration Toolkit in 3 simple steps.

## Prerequisites

- Python 3.8+
- SQLite (included with Python)
- CardDemo inventory database (for test data generation)

## Quick Start (3 Steps)

### Step 1: Generate Test Data

```bash
./run_smftestdata_inventory.sh
```

**What it does:**
- Generates 22,000+ synthetic SMF records
- Creates 7 individual JSON files (one per record type)
- Creates 1 merged JSON file (all types combined)
- Validates CICS transactions

**Output:**
```
examples/data/carddemo_smf_inventory/
├── smf14_carddemo.json          # Type 14: INPUT dataset activity
├── smf15_carddemo.json          # Type 15: OUTPUT dataset activity
├── smf17_carddemo.json          # Type 17: Dataset deletion
├── smf30_carddemo.json          # Type 30: Batch job accounting
├── smf62_carddemo.json          # Type 62: VSAM open
├── smf64_carddemo.json          # Type 64: VSAM close
├── smf110_carddemo.json         # Type 110: CICS transactions
└── smf_all_carddemo.json        # ALL TYPES (22,595 records)
```

### Step 2: Load into Database

```bash
./load_test_data_unified.sh
```

**What it does:**
- Creates SQLite database: `databases/carddemo_smf_test.db`
- Loads all 22,595 records using unified schema
- Creates 31 tables for comprehensive analysis
- Shows statistics

**Result:**
```
✓ Loaded 22,595 record(s)

DATABASE STATISTICS
  smf_records                   : 22,595 rows
  smf30_identification          :  3,766 rows
  smf110_performance            :  1,270 rows
  smf14_records                 :  3,066 rows
  ... (and more)
```

### Step 3: View in Dashboard

```bash
./startDashboard.sh
```

Then open: **http://localhost:5001**

**What you can do:**
- Browse database tables
- Run pre-built queries
- Analyze CPU usage, I/O patterns
- View CICS transaction performance
- Export results to CSV/JSON

## Common Tasks

### Run a Query

```bash
python3 -m tools.smf_analyzer.smf_queries run \
    --db databases/carddemo_smf_test.db \
    --query top_cpu_consumers
```

### Load Individual Record Type

```bash
python3 -m tools.smf_analyzer.smf_loader load \
    --type 30 \
    --db my_database.db \
    --file examples/data/carddemo_smf_inventory/smf30_carddemo.json \
    --create-schema
```

### Stop Dashboard

```bash
./stopDashboard.sh
```

## File Structure

```
smf_migration_toolkit/
├── run_smftestdata_inventory.sh    # Generate test data
├── load_test_data_unified.sh       # Load into database
├── startDashboard.sh               # Start web dashboard
├── stopDashboard.sh                # Stop web dashboard
├── databases/                      # SQLite databases
│   └── carddemo_smf_test.db       # Test data database
├── examples/
│   ├── config/                     # Configuration files
│   └── data/                       # Generated JSON files
└── tools/
    ├── smf_analyzer/               # SMF analysis tools
    ├── smf_dashboard/              # Web dashboard
    └── smf_test_data_generator/    # Test data generator
```

## Key Concepts

### Record Types

The toolkit supports 7 SMF record types:

| Type | Description | Use Case |
|------|-------------|----------|
| 30 | Batch Job Accounting | CPU usage, job performance |
| 110 | CICS Transactions | Transaction response times |
| 14 | INPUT Dataset Activity | Dataset read operations |
| 15 | OUTPUT Dataset Activity | Dataset write operations |
| 17 | Dataset Deletion | Dataset lifecycle tracking |
| 62 | VSAM Open | VSAM file access patterns |
| 64 | VSAM Close | VSAM file statistics |

### Schemas

**Unified Schema:**
- All record types in one database
- Enables cross-type queries
- Recommended for comprehensive analysis

**Single-Type Schema:**
- One record type per database
- Simpler structure
- Good for focused analysis

### Files

**Individual Files:**
- `smf{type}_carddemo.json` - One file per record type
- Use for single-type loading
- Smaller file sizes

**Merged File:**
- `smf_all_carddemo.json` - All types combined
- Use with unified loader
- Simplifies loading process

## Troubleshooting

### Port 5000 Already in Use

The dashboard uses port 5001 (not 5000) to avoid conflicts with macOS ControlCenter.

### Database Not Found

Make sure you've run `./load_test_data_unified.sh` before trying to query the database.

### No Test Data

Run `./run_smftestdata_inventory.sh` first to generate test data.

### Dashboard Won't Start

Check if it's already running:
```bash
ps aux | grep smf_dashboard
```

Stop it if needed:
```bash
./stopDashboard.sh
```

## Next Steps

### Learn More

- [Product Overview](product.md) - Architecture and components
- [Test Data Generator Updates](TEST_DATA_GENERATOR_UPDATES.md) - Latest features
- [Unified Loader Complete](UNIFIED_LOADER_COMPLETE.md) - Technical details
- [Dashboard Scripts](DASHBOARD_SCRIPTS_README.md) - Dashboard management

### Advanced Usage

- **Custom Queries**: Create your own SQL queries
- **Configuration**: Modify YAML configs for different scenarios
- **Integration**: Use the Python API in your own scripts
- **Production**: Deploy with Gunicorn/Waitress for production use

### Example Queries

**Top CPU Consumers:**
```sql
SELECT 
    i.job_name,
    i.program_name,
    p.cpu_seconds,
    p.service_units
FROM smf30_identification i
JOIN smf30_processor p ON i.record_id = p.record_id
ORDER BY p.cpu_seconds DESC
LIMIT 10;
```

**CICS Transaction Performance:**
```sql
SELECT 
    transaction_id,
    program_name,
    COUNT(*) as executions,
    AVG(elapsed_time) as avg_response_us,
    MAX(elapsed_time) as max_response_us
FROM smf110_performance
GROUP BY transaction_id, program_name
ORDER BY avg_response_us DESC;
```

**Dataset Usage:**
```sql
SELECT 
    dataset_name,
    COUNT(*) as access_count,
    SUM(excp_count) as total_io
FROM smf14_records
GROUP BY dataset_name
ORDER BY total_io DESC
LIMIT 10;
```

## Support

For issues or questions:
1. Check the documentation in `docs/`
2. Review example scripts in `examples/`
3. Examine test cases in `tests/`

## Summary

**Three commands to get started:**
1. `./run_smftestdata_inventory.sh` - Generate data
2. `./load_test_data_unified.sh` - Load database
3. `./startDashboard.sh` - View in browser

That's it! You're now ready to analyze SMF data.
