# Legacy Analyzer Python API Reference

Complete reference for using Legacy Analyzer programmatically in Python.

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [LegacyAnalyzerAPI Class](#legacyanalyzerapi-class)
- [Flow Analysis](#flow-analysis)
- [Complexity Analysis](#complexity-analysis)
- [Missing Code Detection](#missing-code-detection)
- [Migration Packages](#migration-packages)
- [Visualization and Reporting](#visualization-and-reporting)
- [Data Models](#data-models)
- [Examples](#examples)

## Installation

```bash
pip install -e .
```

## Quick Start

```python
from tools.legacy_analyzer import LegacyAnalyzerAPI

# Initialize API with database
with LegacyAnalyzerAPI("analyzer.db") as api:
    # Analyze program flow
    flow = api.analyze_flow("PAYROLL1")
    print(f"Flow depth: {flow.depth}")
    print(f"Programs: {len(flow.programs)}")
    
    # Detect missing artifacts
    missing = api.detect_all_missing()
    print(f"Missing artifacts: {len(missing)}")
    
    # Create migration package
    package = api.create_package("Payroll", ["PAYROLL1", "PAYCALC"])
    print(f"Package size: {len(package.artifacts)} artifacts")
```

## LegacyAnalyzerAPI Class

The main entry point for all Legacy Analyzer functionality.

### Constructor

```python
LegacyAnalyzerAPI(database_path: str)
```

**Parameters:**
- `database_path` (str): Path to SQLite database file

**Example:**

```python
api = LegacyAnalyzerAPI("analyzer.db")
```

### Context Manager

The API supports context manager protocol for automatic resource cleanup:

```python
with LegacyAnalyzerAPI("analyzer.db") as api:
    # Use API
    flow = api.analyze_flow("PAYROLL1")
# Database connection automatically closed
```

### Methods

#### close()

Close the database connection.

```python
api.close()
```

## Flow Analysis

Methods for analyzing program execution flows and call graphs.

### analyze_flow()

Analyze program flow starting from a specific program.

```python
analyze_flow(
    start_program: str,
    max_depth: int = 10
) -> ProgramFlow
```

**Parameters:**
- `start_program` (str): Program to start analysis from
- `max_depth` (int): Maximum depth to traverse (default: 10)

**Returns:**
- `ProgramFlow`: Object containing complete flow information

**Example:**

```python
flow = api.analyze_flow("PAYROLL1", max_depth=15)
print(f"Start program: {flow.start_program}")
print(f"Depth: {flow.depth}")
print(f"Programs in flow: {len(flow.programs)}")
print(f"Copybooks: {flow.total_copybooks}")
print(f"Datasets: {flow.total_datasets}")

if flow.circular_dependencies:
    print(f"Circular dependencies: {len(flow.circular_dependencies)}")
    for cycle in flow.circular_dependencies:
        print(f"  Cycle: {' -> '.join(cycle.artifacts)}")
```

### build_call_graph()

Build call graph for specified programs or all programs.

```python
build_call_graph(
    programs: Optional[List[str]] = None
) -> CallGraph
```

**Parameters:**
- `programs` (List[str], optional): List of program names (None = all programs)

**Returns:**
- `CallGraph`: Object containing nodes, edges, and metadata

**Example:**

```python
# Build graph for specific programs
graph = api.build_call_graph(["PAYROLL1", "BILLING2"])

# Build graph for all programs
graph = api.build_call_graph()

print(f"Nodes: {len(graph.nodes)}")
print(f"Edges: {len(graph.edges)}")

for caller, callee in graph.edges:
    print(f"{caller} -> {callee}")
```

### get_entry_points()

Get all entry point programs (programs that are never called).

```python
get_entry_points() -> List[str]
```

**Returns:**
- `List[str]`: List of entry point program names

**Example:**

```python
entry_points = api.get_entry_points()
print(f"Found {len(entry_points)} entry points:")
for program in entry_points:
    print(f"  • {program}")
```

### detect_circular_dependencies()

Detect all circular dependencies in the system.

```python
detect_circular_dependencies() -> List[CircularDependency]
```

**Returns:**
- `List[CircularDependency]`: List of circular dependency objects

**Example:**

```python
cycles = api.detect_circular_dependencies()
print(f"Found {len(cycles)} circular dependencies:")
for cycle in cycles:
    print(f"  Type: {cycle.cycle_type}")
    print(f"  Artifacts: {' -> '.join(cycle.artifacts)}")
    print(f"  Severity: {cycle.severity}")
```

## Complexity Analysis

Methods for analyzing code complexity.

### analyze_complexity()

Analyze complexity of a single program.

```python
analyze_complexity(
    program_name: str,
    source_code: str,
    language: str,
    dependency_count_in: int = 0,
    dependency_count_out: int = 0
) -> ComplexityMetrics
```

**Parameters:**
- `program_name` (str): Name of the program
- `source_code` (str): Source code content
- `language` (str): Programming language (COBOL, PLI, JCL, etc.)
- `dependency_count_in` (int): Number of incoming dependencies
- `dependency_count_out` (int): Number of outgoing dependencies

**Returns:**
- `ComplexityMetrics`: Object containing all complexity metrics

**Example:**

```python
with open("PAYROLL1.cbl") as f:
    source = f.read()

metrics = api.analyze_complexity(
    program_name="PAYROLL1",
    source_code=source,
    language="COBOL",
    dependency_count_in=5,
    dependency_count_out=12
)

print(f"Program: {metrics.program_name}")
print(f"LOC: {metrics.lines_of_code}")
print(f"Cyclomatic Complexity: {metrics.cyclomatic_complexity}")
print(f"Composite Score: {metrics.composite_score:.2f}")
print(f"Complexity Tier: {metrics.complexity_tier}")
print(f"God Program: {metrics.is_god_program}")
```

### analyze_all_complexity()

Analyze complexity of multiple programs.

```python
analyze_all_complexity(
    programs: Dict[str, Dict]
) -> Dict[str, ComplexityMetrics]
```

**Parameters:**
- `programs` (Dict[str, Dict]): Dictionary mapping program names to program info
  - Each program info should have:
    - `source_code` (str): Source code content
    - `language` (str): Programming language
    - `dependency_count_in` (int, optional): Incoming dependencies
    - `dependency_count_out` (int, optional): Outgoing dependencies

**Returns:**
- `Dict[str, ComplexityMetrics]`: Dictionary mapping program names to metrics

**Example:**

```python
programs = {
    "PAYROLL1": {
        "source_code": payroll_source,
        "language": "COBOL",
        "dependency_count_in": 5,
        "dependency_count_out": 12
    },
    "BILLING2": {
        "source_code": billing_source,
        "language": "COBOL",
        "dependency_count_in": 3,
        "dependency_count_out": 8
    }
}

results = api.analyze_all_complexity(programs)

for program_name, metrics in results.items():
    print(f"{program_name}: {metrics.complexity_tier}")
```

### get_complexity_thresholds()

Get current complexity thresholds.

```python
get_complexity_thresholds() -> ComplexityThresholds
```

**Returns:**
- `ComplexityThresholds`: Current threshold configuration

### set_complexity_thresholds()

Set custom complexity thresholds.

```python
set_complexity_thresholds(thresholds: ComplexityThresholds)
```

**Parameters:**
- `thresholds` (ComplexityThresholds): New threshold configuration

**Example:**

```python
from tools.legacy_analyzer.models.complexity import ComplexityThresholds

thresholds = ComplexityThresholds(
    low_threshold=15,
    medium_threshold=30,
    high_threshold=60
)
api.set_complexity_thresholds(thresholds)
```

## Missing Code Detection

Methods for detecting missing artifacts.

### detect_missing_programs()

Find programs that are called but not found in inventory.

```python
detect_missing_programs() -> List[MissingArtifact]
```

**Returns:**
- `List[MissingArtifact]`: List of missing program artifacts

**Example:**

```python
missing = api.detect_missing_programs()
print(f"Missing programs: {len(missing)}")

for artifact in missing:
    print(f"  {artifact.artifact_name}")
    print(f"    Severity: {artifact.severity}")
    print(f"    Referenced {artifact.reference_count} times")
    print(f"    Referenced by: {', '.join(artifact.referenced_by[:5])}")
```

### detect_missing_copybooks()

Find copybooks that are included but not found in inventory.

```python
detect_missing_copybooks() -> List[MissingArtifact]
```

**Returns:**
- `List[MissingArtifact]`: List of missing copybook artifacts

### detect_missing_datasets()

Find datasets that are referenced but not found in inventory.

```python
detect_missing_datasets() -> List[MissingArtifact]
```

**Returns:**
- `List[MissingArtifact]`: List of missing dataset artifacts

### detect_all_missing()

Detect all missing artifacts (programs, copybooks, datasets).

```python
detect_all_missing() -> List[MissingArtifact]
```

**Returns:**
- `List[MissingArtifact]`: Combined list of all missing artifacts

**Example:**

```python
missing = api.detect_all_missing()

# Group by type
by_type = {}
for artifact in missing:
    by_type.setdefault(artifact.artifact_type, []).append(artifact)

for artifact_type, artifacts in by_type.items():
    print(f"{artifact_type}: {len(artifacts)} missing")
```

### calculate_completeness()

Calculate inventory completeness score.

```python
calculate_completeness() -> CompletenessReport
```

**Returns:**
- `CompletenessReport`: Detailed completeness metrics

**Example:**

```python
report = api.calculate_completeness()

print(f"Overall Completeness: {report.overall_completeness:.1%}")
print(f"Program Completeness: {report.program_completeness:.1%}")
print(f"Copybook Completeness: {report.copybook_completeness:.1%}")
print(f"Dataset Completeness: {report.dataset_completeness:.1%}")

print(f"\nPrograms: {report.found_programs}/{report.total_referenced_programs}")
print(f"Copybooks: {report.found_copybooks}/{report.total_referenced_copybooks}")
print(f"Datasets: {report.found_datasets}/{report.total_referenced_datasets}")
```

## Migration Packages

Methods for creating and managing migration packages.

### create_package()

Create a migration package from seed artifacts.

```python
create_package(
    name: str,
    seed_artifacts: List[str],
    include_transitive: bool = True,
    max_depth: Optional[int] = None,
    constraints: Optional[PackageConstraints] = None
) -> MigrationPackage
```

**Parameters:**
- `name` (str): Package name
- `seed_artifacts` (List[str]): List of seed artifact names
- `include_transitive` (bool): Include transitive dependencies (default: True)
- `max_depth` (int, optional): Maximum depth for transitive dependencies
- `constraints` (PackageConstraints, optional): Package constraints

**Returns:**
- `MigrationPackage`: Created package object

**Example:**

```python
# Create package with transitive dependencies
package = api.create_package(
    name="Payroll",
    seed_artifacts=["PAYROLL1", "PAYCALC"],
    include_transitive=True
)

print(f"Package: {package.name}")
print(f"Artifacts: {len(package.artifacts)}")
print(f"LOC: {package.total_loc:,}")
print(f"Complexity: {package.total_complexity:.2f}")
print(f"External Dependencies: {len(package.external_dependencies)}")
print(f"Self-contained: {package.is_self_contained()}")

# Create package with constraints
from tools.legacy_analyzer.models.package import PackageConstraints

constraints = PackageConstraints(
    max_artifacts=100,
    max_loc=50000
)

package = api.create_package(
    name="Payroll",
    seed_artifacts=["PAYROLL1"],
    constraints=constraints
)
```

### detect_package_conflicts()

Detect artifacts that appear in multiple packages.

```python
detect_package_conflicts(
    packages: List[MigrationPackage]
) -> List[PackageConflict]
```

**Parameters:**
- `packages` (List[MigrationPackage]): List of packages to check

**Returns:**
- `List[PackageConflict]`: List of conflicts

**Example:**

```python
package1 = api.create_package("Package1", ["PROG1", "PROG2"])
package2 = api.create_package("Package2", ["PROG2", "PROG3"])

conflicts = api.detect_package_conflicts([package1, package2])

for conflict in conflicts:
    print(f"Artifact {conflict.artifact_name} in packages:")
    for pkg in conflict.packages:
        print(f"  • {pkg}")
```

### validate_package()

Validate a package against constraints.

```python
validate_package(
    package: MigrationPackage,
    constraints: Optional[PackageConstraints] = None
) -> Tuple[bool, List[str]]
```

**Parameters:**
- `package` (MigrationPackage): Package to validate
- `constraints` (PackageConstraints, optional): Constraints to validate against

**Returns:**
- `Tuple[bool, List[str]]`: (is_valid, list of error messages)

**Example:**

```python
package = api.create_package("Payroll", ["PAYROLL1"])

is_valid, errors = api.validate_package(package)

if is_valid:
    print("✓ Package is valid")
else:
    print("✗ Package validation failed:")
    for error in errors:
        print(f"  • {error}")
```

## Visualization and Reporting

Methods for generating visualizations and reports.

### export_flow_mermaid()

Export program flow as Mermaid diagram.

```python
export_flow_mermaid(
    flow: ProgramFlow,
    output_file: Optional[str] = None
) -> str
```

**Parameters:**
- `flow` (ProgramFlow): Flow to export
- `output_file` (str, optional): File path to write to

**Returns:**
- `str`: Mermaid diagram as string

**Example:**

```python
flow = api.analyze_flow("PAYROLL1")
mermaid = api.export_flow_mermaid(flow, "flow.mmd")
print(mermaid)
```

### export_flow_dot()

Export program flow as DOT format for Graphviz.

```python
export_flow_dot(
    flow: ProgramFlow,
    output_file: Optional[str] = None
) -> str
```

**Parameters:**
- `flow` (ProgramFlow): Flow to export
- `output_file` (str, optional): File path to write to

**Returns:**
- `str`: DOT format as string

### generate_executive_summary()

Generate executive summary report.

```python
generate_executive_summary(
    analysis_results: AnalysisResults
) -> str
```

**Parameters:**
- `analysis_results` (AnalysisResults): Complete analysis results

**Returns:**
- `str`: Executive summary as formatted text

**Example:**

```python
from tools.legacy_analyzer.visualization.report_generator import AnalysisResults

results = AnalysisResults(
    total_programs=1500,
    total_copybooks=800,
    total_datasets=300,
    complexity_distribution={'LOW': 500, 'MEDIUM': 700, 'HIGH': 250, 'VERY_HIGH': 50},
    missing_artifacts_count=45
)

summary = api.generate_executive_summary(results)
print(summary)
```

### generate_artifact_report()

Generate detailed artifact report.

```python
generate_artifact_report(
    artifact_name: str,
    **kwargs
) -> str
```

**Parameters:**
- `artifact_name` (str): Name of the artifact
- `**kwargs`: Additional report parameters

**Returns:**
- `str`: Detailed artifact report as formatted text

### generate_package_report()

Generate migration package report.

```python
generate_package_report(
    package: MigrationPackage
) -> str
```

**Parameters:**
- `package` (MigrationPackage): Package to report on

**Returns:**
- `str`: Package report as formatted text

**Example:**

```python
package = api.create_package("Payroll", ["PAYROLL1", "PAYCALC"])
report = api.generate_package_report(package)
print(report)
```

### export_migration_flows()

Export migration flows with various sorting strategies for migration planning.

```python
export_migration_flows(
    output_file: str,
    sort_strategy: str = "complexity-asc",
    extended_scope: bool = True
) -> Dict[str, Any]
```

**Parameters:**
- `output_file` (str): Path to output JSON file
- `sort_strategy` (str): Sorting strategy (choices: "complexity-asc", "complexity-desc", "independence", "dependencies", "name", "none"; default: "complexity-asc")
- `extended_scope` (bool): Include extended utility metadata (default: True)

**Returns:**
- `Dict[str, Any]`: Dictionary containing flows and summary metadata

**Sorting Strategies:**

1. **complexity-asc** - Simplest flows first (recommended for pilot/POC)
2. **complexity-desc** - Most complex flows first (for experienced teams)
3. **independence** - Minimal dependencies first (for parallel migration)
4. **dependencies** - Most dependencies first (for shared infrastructure)
5. **name** - Alphabetical order (for documentation)
6. **none** - Database order (no sorting)

**Extended Scope:**

When `extended_scope=True`, each flow includes:
- **Copybooks**: All copybooks used with usage counts
- **Datasets**: All datasets accessed with operation types
- **JCL**: All JCL jobs that execute programs
- **CICS Resources**: Transactions, files, and mapsets

**Example:**

```python
# Export flows sorted by complexity (simplest first)
flows = api.export_migration_flows(
    output_file="flows_by_complexity.json",
    sort_strategy="complexity-asc",
    extended_scope=True
)

print(f"Exported {len(flows['flows'])} flows")
print(f"Complexity distribution: {flows['summary']['complexityDistribution']}")

# Export flows sorted by independence (parallel migration)
flows = api.export_migration_flows(
    output_file="flows_by_independence.json",
    sort_strategy="independence",
    extended_scope=True
)

# Export all strategies for comparison
strategies = ["complexity-asc", "complexity-desc", "independence", 
              "dependencies", "name", "none"]

for strategy in strategies:
    flows = api.export_migration_flows(
        output_file=f"flows_by_{strategy}.json",
        sort_strategy=strategy,
        extended_scope=True
    )
    print(f"{strategy}: {len(flows['flows'])} flows")
```

**Output Format:**

```python
{
    "flows": [
        {
            "flowId": "FLOW_001",
            "flowName": "Account Update Flow",
            "entryPoint": {
                "programName": "COACTUPC",
                "types": ["CICS_TRANSACTION", "CICS_PROGRAM"],
                "callers": [...]
            },
            "programs": [...],
            "complexity": {
                "totalLoc": 1250,
                "avgComplexity": 15.3,
                "maxComplexity": 28.5,
                "tier": "MEDIUM"
            },
            "dependencies": {
                "internal": 5,
                "external": 2
            },
            "invokedByJobs": [
                "PAYROLL01",
                "PAYWEEK"
            ],
            "utilities": {
                "copybooks": [...],
                "datasets": [...],
                "jcl": [...],
                "cics": {...}
            }
        }
    ],
    "summary": {
        "totalFlows": 27,
        "sortStrategy": "complexity-asc",
        "extendedScope": True,
        "complexityDistribution": {
            "LOW": 12,
            "MEDIUM": 10,
            "HIGH": 4,
            "VERY_HIGH": 1
        }
    }
}
```

**Flow Object Fields:**

- **flowId**: Unique flow identifier
- **flowName**: Human-readable flow name
- **entryPoint**: Entry point program and invocation types
- **programs**: List of programs in the flow
- **complexity**: Complexity metrics and tier classification
- **dependencies**: Internal and external flow dependencies
- **invokedByJobs**: Array of JCL job names that invoke this flow's entry point (enables job-to-flow traceability)
- **utilities**: Extended metadata including copybooks, datasets, JCL, and CICS resources

**Use Cases:**

1. **Migration Planning**: Select optimal migration sequence
2. **Wave Planning**: Divide flows into migration waves
3. **Resource Planning**: Estimate effort based on complexity
4. **Parallel Migration**: Identify independent flows for parallel work
5. **Infrastructure Planning**: Plan data, batch, and online migration

**See Also:**
- [CLI Reference - Export Migration Flows](CLI_REFERENCE.md#export-migration-flows)
- [Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md#phase-5-migration-flow-planning)

### export_jobs()

Export all JCL jobs with orchestration, categorization, and dependencies for infrastructure and batch migration planning.

```python
export_jobs(
    output_dir: str = "results/jobs",
    sort_by: str = "name"
) -> Dict[str, Any]
```

**Parameters:**
- `output_dir` (str): Output directory for job exports (default: "results/jobs")
- `sort_by` (str): Sorting strategy (choices: "name", "type", "dependencies", "complexity"; default: "name")

**Returns:**
- `Dict[str, Any]`: Dictionary containing jobs array and summary metadata

**Sorting Strategies:**

1. **name** - Alphabetical order (default, for documentation)
2. **type** - APPLICATION jobs first, then INFRASTRUCTURE (for three-phase migration)
3. **dependencies** - Topological sort by dependencies (for execution order)
4. **complexity** - Most complex jobs first (for risk assessment)

**Job Categorization:**

Jobs are automatically categorized into two types:

- **APPLICATION**: Jobs that invoke at least one custom program (COBOL, PL/I, etc.)
  - Execute business logic
  - Require program migration before job migration
  - Linked to program flows when applicable

- **INFRASTRUCTURE**: Jobs that only invoke utility programs (IEFBR14, IDCAMS, SORT, etc.)
  - Perform infrastructure tasks (dataset operations, backups, etc.)
  - Can often be migrated independently
  - May be replaced with cloud-native equivalents

**Example:**

```python
# Export jobs with default settings (sorted by name)
jobs = api.export_jobs()

print(f"Total jobs: {jobs['summary']['totalJobs']}")
print(f"Application jobs: {jobs['summary']['applicationJobs']}")
print(f"Infrastructure jobs: {jobs['summary']['infrastructureJobs']}")

# Export jobs sorted by type (APPLICATION first, then INFRASTRUCTURE)
jobs = api.export_jobs(
    output_dir="results/jobs",
    sort_by="type"
)

# Separate APPLICATION and INFRASTRUCTURE jobs
app_jobs = [j for j in jobs['jobs'] if j['jobType'] == 'APPLICATION']
infra_jobs = [j for j in jobs['jobs'] if j['jobType'] == 'INFRASTRUCTURE']

# Export all sorting strategies for comparison
for strategy in ["name", "type", "dependencies", "complexity"]:
    jobs = api.export_jobs(
        output_dir="results/jobs",
        sort_by=strategy
    )
    print(f"{strategy}: {len(jobs['jobs'])} jobs")
```

**Output Format:**

```python
{
    "jobs": [
        {
            "jobName": "DALYREJS",
            "jobType": "APPLICATION",
            "hasCustomCode": True,
            "linkedFlow": "FLOW_CBACT01C",
            "steps": [
                {
                    "stepName": "STEP01",
                    "program": "IEFBR14",
                    "type": "UTILITY",
                    "purpose": "Allocate or delete datasets",
                    "flowEntry": False
                },
                {
                    "stepName": "STEP02",
                    "program": "CBACT01C",
                    "type": "CUSTOM",
                    "purpose": "Execute CBACT01C",
                    "flowEntry": True
                }
            ],
            "datasets": ["ACCTDAT", "CUSTDAT", "TRANFILE"],
            "dependencies": {
                "mustRunAfter": ["DAILYEXT"],
                "mustRunBefore": ["DAILYRPT"]
            }
        }
    ],
    "summary": {
        "totalJobs": 35,
        "applicationJobs": 28,
        "infrastructureJobs": 7,
        "exportDate": "2026-01-30T12:34:56.789Z",
        "database": "analyzer.db",
        "sortedBy": "name"
    }
}
```

**Job Object Fields:**

- **jobName**: JCL job name
- **jobType**: "APPLICATION" or "INFRASTRUCTURE"
- **hasCustomCode**: True if job invokes custom programs
- **linkedFlow**: Flow name (FLOW_{program}) if job invokes a flow entry point, null otherwise
- **steps**: Array of job steps with stepName, program, type, purpose, and flowEntry fields
- **datasets**: Array of unique dataset names referenced by the job
- **dependencies**: Job-to-job dependencies with mustRunAfter and mustRunBefore arrays

**Dual Export Approach:**

For complete migration planning, export both jobs and flows:

```python
# Export flows (application logic)
flows = api.export_migration_flows(
    output_file="flows_by_complexity_asc.json",
    sort_strategy="complexity-asc",
    extended_scope=True
)

# Export jobs (orchestration)
jobs = api.export_jobs(
    output_dir="results/jobs",
    sort_by="type"
)

# Cross-reference jobs and flows
for job in jobs['jobs']:
    if job['linkedFlow']:
        print(f"Job {job['jobName']} invokes flow {job['linkedFlow']}")
```

**Three-Phase Migration Strategy:**

```python
# Phase 1: Infrastructure Jobs (no dependencies)
infra_jobs = [j for j in jobs['jobs'] if j['jobType'] == 'INFRASTRUCTURE']
print(f"Phase 1: Migrate {len(infra_jobs)} infrastructure jobs")

# Phase 2: Application Programs (business logic)
print(f"Phase 2: Migrate {len(flows['flows'])} program flows")

# Phase 3: Batch Orchestration (application jobs)
app_jobs = [j for j in jobs['jobs'] if j['jobType'] == 'APPLICATION']
print(f"Phase 3: Migrate {len(app_jobs)} application jobs (orchestration)")
```

**See Also:**
- [CLI Reference - Export JCL Jobs](CLI_REFERENCE.md#export-jcl-jobs)
- [Migration Workflow Guide](MIGRATION_WORKFLOW_GUIDE.md#phase-5b-dual-export-approach-jobs--flows)
- [Job Export README](../tools/legacy_analyzer/migration/README_JOB_EXPORT.md)

### generate_complexity_summary()

Generate complexity summary report.

```python
generate_complexity_summary(
    complexity_metrics: Dict[str, ComplexityMetrics],
    top_n: int = 10
) -> str
```

**Parameters:**
- `complexity_metrics` (Dict[str, ComplexityMetrics]): Dictionary of metrics
- `top_n` (int): Number of top complex programs to show

**Returns:**
- `str`: Complexity summary as formatted text

## Data Models

### ProgramFlow

Represents a program execution flow.

**Attributes:**
- `start_program` (str): Starting program name
- `depth` (int): Maximum depth reached
- `programs` (List[str]): All programs in flow
- `dependencies` (List[Dependency]): All dependencies
- `circular_dependencies` (List[CircularDependency]): Circular dependencies
- `total_copybooks` (int): Total copybooks referenced
- `total_datasets` (int): Total datasets accessed

### ComplexityMetrics

Represents complexity metrics for a program.

**Attributes:**
- `program_name` (str): Program name
- `language` (str): Programming language
- `lines_of_code` (int): Lines of code
- `cyclomatic_complexity` (int): Cyclomatic complexity score
- `dependency_count_in` (int): Incoming dependencies
- `dependency_count_out` (int): Outgoing dependencies
- `composite_score` (float): Composite complexity score
- `complexity_tier` (str): Tier (LOW, MEDIUM, HIGH, VERY_HIGH)
- `is_god_program` (bool): Whether it's a god program

### MissingArtifact

Represents a missing artifact.

**Attributes:**
- `artifact_name` (str): Artifact name
- `artifact_type` (str): Type (PROGRAM, COPYBOOK, DATASET)
- `reference_count` (int): Number of references
- `referenced_by` (List[str]): List of artifacts that reference it
- `severity` (str): Severity (HIGH, MEDIUM, LOW)

### MigrationPackage

Represents a migration package.

**Attributes:**
- `name` (str): Package name
- `artifacts` (List[str]): All artifacts in package
- `total_loc` (int): Total lines of code
- `total_complexity` (float): Total complexity
- `external_dependencies` (List[str]): External dependencies
- `conflicts` (List[str]): Conflicting artifacts

**Methods:**
- `is_self_contained()`: Check if package has no external dependencies
- `has_conflicts()`: Check if package has conflicts

## Examples

### Complete Analysis Workflow

```python
from tools.legacy_analyzer import LegacyAnalyzerAPI

with LegacyAnalyzerAPI("analyzer.db") as api:
    # 1. Analyze program flow
    flow = api.analyze_flow("MAINPROG")
    print(f"Flow contains {len(flow.programs)} programs")
    
    # 2. Detect circular dependencies
    cycles = api.detect_circular_dependencies()
    if cycles:
        print(f"Warning: {len(cycles)} circular dependencies found")
    
    # 3. Analyze complexity
    with open("MAINPROG.cbl") as f:
        source = f.read()
    
    metrics = api.analyze_complexity("MAINPROG", source, "COBOL")
    print(f"Complexity: {metrics.complexity_tier}")
    
    # 4. Detect missing artifacts
    missing = api.detect_all_missing()
    print(f"Missing artifacts: {len(missing)}")
    
    # 5. Calculate completeness
    report = api.calculate_completeness()
    print(f"Completeness: {report.overall_completeness:.1%}")
    
    # 6. Create migration package
    package = api.create_package("MainPackage", ["MAINPROG"])
    print(f"Package size: {len(package.artifacts)} artifacts")
    
    # 7. Generate reports
    summary = api.generate_executive_summary(results)
    with open("summary.md", "w") as f:
        f.write(summary)
```

### Batch Processing

```python
from pathlib import Path
from tools.legacy_analyzer import LegacyAnalyzerAPI

with LegacyAnalyzerAPI("analyzer.db") as api:
    # Analyze all COBOL programs in a directory
    source_dir = Path("/path/to/cobol")
    programs = {}
    
    for file_path in source_dir.glob("*.cbl"):
        program_name = file_path.stem
        source_code = file_path.read_text()
        
        programs[program_name] = {
            "source_code": source_code,
            "language": "COBOL"
        }
    
    # Batch analyze complexity
    results = api.analyze_all_complexity(programs)
    
    # Find high complexity programs
    high_complexity = [
        name for name, metrics in results.items()
        if metrics.complexity_tier in ['HIGH', 'VERY_HIGH']
    ]
    
    print(f"High complexity programs: {len(high_complexity)}")
    for program in high_complexity:
        print(f"  • {program}")
```

## See Also

- [CLI Reference](CLI_REFERENCE.md)
- [Getting Started Guide](GETTING_STARTED.md)
- [Migration Workflow Guide](MIGRATION_WORKFLOW.md)
