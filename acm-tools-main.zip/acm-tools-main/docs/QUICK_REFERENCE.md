# SMF Migration Toolkit - Quick Reference

## Database

**Current Database**: `databases/carddemo_smf_test.db`
- 22,510 SMF records (Types 14, 15, 17, 30, 62, 64, 110)
- Date range: 2025-01-01 to 2026-02-04
- Includes inventory data (44 JCL, 33 programs, 46 copybooks, 8 datasets, 64 CICS resources)

## Dashboard

**Start Dashboard**:
```bash
./startDashboard.sh
```

**Stop Dashboard**:
```bash
./stopDashboard.sh
```

**Restart Dashboard**:
```bash
./restart_dashboard.sh
```

**Access**: http://localhost:5001

## CLI Commands

### List All Queries
```bash
python3 -m tools.smf_analyzer.smf_queries list --db databases/carddemo_smf_test.db
```

### Run a Query
```bash
python3 -m tools.smf_analyzer.smf_queries run \
    --db databases/carddemo_smf_test.db \
    --query <query_name> \
    --format table
```

**Output Formats**: `table`, `json`, `csv`, `markdown`

### Get Query Info
```bash
python3 -m tools.smf_analyzer.smf_queries info \
    --db databases/carddemo_smf_test.db \
    --query <query_name>
```

## Key Queries

### Cost Analysis
```bash
# MIPS cost estimation
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query mips_cost --format table

# MSU cost estimation
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query msu_cost --format table

# Migration ROI calculation
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query migration_roi --format table
```

### CPU Analysis
```bash
# Top CPU consumers
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query top_cpu_consumers --format table

# CPU by user
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query cpu_by_user --format table

# CPU by program
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query cpu_by_program --format table
```

### Artifact Analysis
```bash
# Missing programs (in SMF but not in inventory)
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query missing_programs --format table

# Unreferenced programs (in inventory but not in SMF)
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query unreferenced_programs --format table

# Missing datasets
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query missing_datasets --format table

# Unreferenced datasets
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query unreferenced_datasets --format table
```

### Migration Planning
```bash
# Migration complexity
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query migration_complexity --format table

# Migration effort estimation
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query migration_effort --format table

# Workload prioritization
python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query workload_prioritization --format table
```

## Test Data Management

### Regenerate Test Data
```bash
./regenerate_test_data.sh
```

This will:
1. Clean old data
2. Generate new SMF records with current dates
3. Merge JSON files
4. Create fresh database
5. Copy inventory data
6. Verify record counts

### Test Key Queries
```bash
./test_cost_queries.sh
```

Tests:
- MIPS Cost
- MSU Cost
- Migration ROI
- Top CPU Consumers
- Job Completion Rate

### Generate Test Data Manually
```bash
# Generate SMF records
python3 -m tools.smf_test_data_generator \
    --config examples/config/carddemo_smf_generation_inventory.yaml \
    --verbose

# Merge JSON files
python3 merge_smf_files.py examples/data/carddemo_smf_inventory

# Load into database
python3 -m tools.smf_analyzer.smf_loader load \
    --db databases/carddemo_smf_test.db \
    --file examples/data/carddemo_smf_inventory/smf_all_carddemo.json \
    --create-schema \
    --unified

# Copy inventory
./copy_inventory_to_test_db.sh
```

## Database Inspection

### SQLite CLI
```bash
# Open database
sqlite3 databases/carddemo_smf_test.db

# List tables
.tables

# Count records
SELECT COUNT(*) FROM smf_records;

# Check date range
SELECT MIN(record_date), MAX(record_date) FROM smf_records;

# Count by type
SELECT record_type, COUNT(*) FROM smf_records GROUP BY record_type;

# Exit
.quit
```

### Python
```python
import sqlite3

conn = sqlite3.connect('databases/carddemo_smf_test.db')
cursor = conn.cursor()

# Count records
cursor.execute('SELECT COUNT(*) FROM smf_records')
print(f"Total records: {cursor.fetchone()[0]}")

# Count by type
cursor.execute('SELECT record_type, COUNT(*) FROM smf_records GROUP BY record_type')
for row in cursor.fetchall():
    print(f"Type {row[0]}: {row[1]} records")

conn.close()
```

## Query Categories

### Cost Analysis (4 queries)
- `mips_cost` - MIPS-based cost estimation
- `msu_cost` - MSU-based cost estimation
- `aws_cost` - AWS cost estimation (requires SMF 100/101)
- `migration_roi` - ROI calculation

### CPU Analysis (4 queries)
- `top_cpu_consumers` - Top CPU consuming jobs
- `cpu_by_program` - CPU by program
- `cpu_by_user` - CPU by user
- `cpu_statistics` - CPU statistics

### I/O Analysis (2 queries)
- `dataset_activity` - Dataset activity
- `top_io_consumers` - Top I/O consumers

### Storage Analysis (1 query)
- `memory_usage` - Memory usage

### Completion Analysis (1 query)
- `job_completion_rate` - Job completion rate

### Artifact Analysis (11 queries)
- `missing_programs` - Programs in SMF not in inventory
- `missing_datasets` - Datasets in SMF not in inventory
- `missing_jcl` - JCL in SMF not in inventory
- `unreferenced_programs` - Programs in inventory not in SMF
- `unreferenced_datasets` - Datasets in inventory not in SMF
- `unreferenced_jcl` - JCL in inventory not in SMF
- `unreferenced_copybooks` - Copybooks not referenced
- `artifact_dependencies` - Artifact dependencies
- `artifact_risk_assessment` - Risk assessment
- `cleanup_recommendations` - Cleanup recommendations

### Infrastructure Sizing (7 queries)
- `batch_workload_cpu` - Batch CPU requirements
- `cics_workload_cpu` - CICS CPU requirements
- `dataset_iops` - IOPS requirements
- `dataset_storage_requirements` - Storage requirements
- `vsam_to_rds` - VSAM to RDS conversion
- `network_bandwidth` - Network bandwidth
- `db2_workload` - DB2 workload (requires SMF 100/101)

### Migration Planning (3 queries)
- `migration_complexity` - Complexity assessment
- `migration_effort` - Effort estimation
- `workload_prioritization` - Workload prioritization

## Troubleshooting

### Dashboard won't start
```bash
# Check if port is in use
lsof -i :5001

# Check logs
tail -f dashboard.log

# Kill existing process
./stopDashboard.sh

# Start fresh
./startDashboard.sh
```

### Queries return empty
```bash
# Check database has data
sqlite3 databases/carddemo_smf_test.db "SELECT COUNT(*) FROM smf_records"

# Check date range
sqlite3 databases/carddemo_smf_test.db "SELECT MIN(record_date), MAX(record_date) FROM smf_records"

# Regenerate test data
./regenerate_test_data.sh
```

### Query not found
```bash
# List available queries
python3 -m tools.smf_analyzer.smf_queries list --db databases/carddemo_smf_test.db

# Check query name spelling
python3 -m tools.smf_analyzer.smf_queries info --db databases/carddemo_smf_test.db --query <query_name>
```

## Configuration

### Global Configuration
**File**: `config/config.yaml`

Contains global parameters for queries (MIPS costs, MSU costs, etc.)

### Query Configuration
**File**: `config/queries.yaml`

Contains query-specific configurations

### Test Data Configuration
**File**: `examples/config/carddemo_smf_generation_inventory.yaml`

Contains test data generation parameters:
- Date range
- Record types
- Active artifacts
- Infrastructure parameters

## Useful Aliases

Add to your `~/.bashrc` or `~/.zshrc`:

```bash
# SMF aliases
alias smf-dashboard='./startDashboard.sh'
alias smf-stop='./stopDashboard.sh'
alias smf-restart='./restart_dashboard.sh'
alias smf-regen='./regenerate_test_data.sh'
alias smf-test='./test_cost_queries.sh'
alias smf-list='python3 -m tools.smf_analyzer.smf_queries list --db databases/carddemo_smf_test.db'
alias smf-query='python3 -m tools.smf_analyzer.smf_queries run --db databases/carddemo_smf_test.db --query'
```

Usage:
```bash
smf-dashboard          # Start dashboard
smf-list               # List queries
smf-query mips_cost    # Run MIPS cost query
smf-test               # Run test queries
smf-regen              # Regenerate test data
```

## Documentation

- `README.md` - Main project documentation
- `QUERY_FIX_COMPLETE.md` - Query fix summary
- `EMPTY_QUERIES_FIX_SUMMARY.md` - Detailed fix analysis
- `EMPTY_QUERIES_ANALYSIS.md` - Original problem analysis
- `docs/` - Comprehensive documentation
- `examples/` - Example scripts and configurations

## Support

For issues or questions:
1. Check `dashboard.log` for errors
2. Review documentation in `docs/`
3. Run `./test_cost_queries.sh` to verify setup
4. Regenerate test data with `./regenerate_test_data.sh`
