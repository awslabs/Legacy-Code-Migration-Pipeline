# Inventory Management Guide

## Overview

The inventory system manages catalogs of mainframe artifacts. This guide explains how to export inventory data from the mainframe and load it into the analysis database.

## Inventory Types

The system supports five types of inventory:

1. **JCL**: Job Control Language members
2. **Programs**: Load modules and executables
3. **Copybooks**: COBOL/PL/I copybooks and include files
4. **Datasets**: All dataset types (PS, PO, VSAM, etc.)
5. **CICS**: CICS resource definitions

## Exporting Inventory from Mainframe

### Option 1: Using Provided Scripts

The system includes mainframe export scripts in `legacy_analyzer/mainframe_exports/`:

```
mainframe_exports/
├── jcl/              # JCL scripts for exports
├── rexx/             # REXX scripts for CICS
├── sql/              # SQL scripts for DB2
├── samples/          # Sample output files
└── docs/             # Detailed export guides
```

See the detailed export guides:
- [JCL Export Guide](../legacy_analyzer/mainframe_exports/docs/JCL_EXPORT_GUIDE.md)
- [Dataset Export Guide](../legacy_analyzer/mainframe_exports/docs/DATASET_EXPORT_GUIDE.md)
- [CICS Export Guide](../legacy_analyzer/mainframe_exports/docs/CICS_EXPORT_GUIDE.md)

### Option 2: Manual Export

#### JCL Inventory

Use ISPF 3.4 or batch LISTDS:

```jcl
//LISTJCL  JOB (ACCT),'LIST JCL',CLASS=A
//STEP1    EXEC PGM=IKJEFT01
//SYSTSPRT DD SYSOUT=*
//SYSTSIN  DD *
  LISTDS 'PROD.JCL.LIB' MEMBERS
/*
```

Format as CSV:
```csv
member_name,library_name,last_modified,size_lines
PAYROLL1,PROD.JCL.LIB,2024-01-15,250
BILLING2,PROD.JCL.LIB,2023-12-20,180
```

#### Program Inventory

Use AMBLIST or IEBLIST:

```jcl
//LISTPGM  JOB (ACCT),'LIST PROGRAMS',CLASS=A
//STEP1    EXEC PGM=AMBLIST
//SYSPRINT DD SYSOUT=*
//SYSLIB   DD DSN=PROD.LOADLIB,DISP=SHR
//SYSIN    DD *
  LISTLOAD MEMBERS=ALL
/*
```

Format as CSV:
```csv
program_name,library_name,link_date,size_bytes,entry_point
PAYROLL1,PROD.LOADLIB,2024-01-15,45678,PAYROLL1
BILLING2,PROD.LOADLIB,2023-12-20,32456,BILLING2
```

#### Copybook Inventory

List source libraries:

```jcl
//LISTCPY  JOB (ACCT),'LIST COPYBOOKS',CLASS=A
//STEP1    EXEC PGM=IKJEFT01
//SYSTSPRT DD SYSOUT=*
//SYSTSIN  DD *
  LISTDS 'PROD.COPYLIB' MEMBERS
/*
```

Format as CSV:
```csv
copybook_name,library_name,last_modified
CUSTMAST,PROD.COPYLIB,2024-01-10
ORDERHDR,PROD.COPYLIB,2023-11-15
```

#### Dataset Inventory

Use IDCAMS LISTCAT:

```jcl
//LISTDS   JOB (ACCT),'LIST DATASETS',CLASS=A
//STEP1    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  LISTCAT ENTRIES('PROD.**') ALL
/*
```

Format as CSV:
```csv
dataset_name,creation_date,last_referenced,size_mb,volume,dataset_type
PROD.CUSTOMER.MASTER,2023-01-15,2024-11-01,1250.5,VOL001,VSAM
PROD.ORDER.HISTORY,2022-06-20,2024-10-28,3456.2,VOL002,PS
```

#### CICS Inventory

Use CICS CEDA or DFHCSDUP:

```rexx
/* Extract CICS definitions */
DFHCSDUP EXTRACT GROUP(*) USERGROUP(*)
```

Format as CSV:
```csv
resource_name,resource_type,group_name,status
PAY001,TRANSACTION,PAYROLL,ENABLED
BILL002,PROGRAM,BILLING,ENABLED
CUSTFILE,FILE,CUSTOMER,ENABLED
```

## Loading Inventory Data

### Command Syntax

```bash
python -m legacy_analyzer load --type <TYPE> --file <CSV_FILE> --db <DATABASE>
```

### Parameters

- `--type`: Inventory type (jcl, programs, copybooks, datasets, cics)
- `--file`: Path to CSV file
- `--db`: Path to SQLite database
- `--validate-only`: Validate CSV without loading (optional)
- `--update-mode`: How to handle duplicates (replace, skip, error)

### Examples

#### Load JCL Inventory

```bash
python -m legacy_analyzer load \
    --type jcl \
    --file exports/jcl_inventory.csv \
    --db smf_analytics.db
```

Expected output:
```
Loading JCL inventory from exports/jcl_inventory.csv...
✓ Validated 1,234 records
✓ Loaded 1,234 records
✓ Updated 0 existing records
✓ Skipped 0 invalid records
Completed in 2.3 seconds
```

#### Load Program Inventory

```bash
python -m legacy_analyzer load \
    --type programs \
    --file exports/program_inventory.csv \
    --db smf_analytics.db
```

#### Load Multiple Inventories

```bash
# Load all inventory types
for type in jcl programs copybooks datasets cics; do
    python -m legacy_analyzer load \
        --type $type \
        --file exports/${type}_inventory.csv \
        --db smf_analytics.db
done
```

### Validation

Validate CSV format before loading:

```bash
python -m legacy_analyzer load \
    --type jcl \
    --file exports/jcl_inventory.csv \
    --db smf_analytics.db \
    --validate-only
```

Validation checks:
- Required columns present
- Data types correct
- No duplicate keys
- Valid date formats
- Name length constraints

### Update Modes

Control how duplicates are handled:

```bash
# Replace existing records (default)
python -m legacy_analyzer load --type jcl --file jcl.csv --db smf.db --update-mode replace

# Skip duplicates
python -m legacy_analyzer load --type jcl --file jcl.csv --db smf.db --update-mode skip

# Error on duplicates
python -m legacy_analyzer load --type jcl --file jcl.csv --db smf.db --update-mode error
```

## CSV Format Requirements

### JCL Inventory

Required columns:
- `member_name` (VARCHAR 8): JCL member name
- `library_name` (VARCHAR 44): PDS name
- `last_modified` (DATE): Last modification date (YYYY-MM-DD)

Optional columns:
- `size_lines` (INTEGER): Number of lines

Example:
```csv
member_name,library_name,last_modified,size_lines
PAYROLL1,PROD.JCL.LIB,2024-01-15,250
BILLING2,PROD.JCL.LIB,2023-12-20,180
```

### Program Inventory

Required columns:
- `program_name` (VARCHAR 8): Load module name
- `library_name` (VARCHAR 44): LOADLIB name
- `link_date` (DATE): Link date (YYYY-MM-DD)
- `size_bytes` (INTEGER): Size in bytes

Optional columns:
- `entry_point` (VARCHAR 16): Entry point address

Example:
```csv
program_name,library_name,link_date,size_bytes,entry_point
PAYROLL1,PROD.LOADLIB,2024-01-15,45678,PAYROLL1
BILLING2,PROD.LOADLIB,2023-12-20,32456,BILLING2
```

### Copybook Inventory

Required columns:
- `copybook_name` (VARCHAR 8): Copybook name
- `library_name` (VARCHAR 44): Source library name
- `last_modified` (DATE): Last modification date (YYYY-MM-DD)

Example:
```csv
copybook_name,library_name,last_modified
CUSTMAST,PROD.COPYLIB,2024-01-10
ORDERHDR,PROD.COPYLIB,2023-11-15
```

### Dataset Inventory

Required columns:
- `dataset_name` (VARCHAR 44): Dataset name
- `creation_date` (DATE): Creation date (YYYY-MM-DD)
- `size_mb` (DECIMAL): Size in megabytes

Optional columns:
- `last_referenced` (DATE): Last reference date
- `volume` (VARCHAR 6): Volume serial
- `dataset_type` (VARCHAR 10): Type (PS, PO, VS, etc.)

Example:
```csv
dataset_name,creation_date,last_referenced,size_mb,volume,dataset_type
PROD.CUSTOMER.MASTER,2023-01-15,2024-11-01,1250.5,VOL001,VSAM
PROD.ORDER.HISTORY,2022-06-20,2024-10-28,3456.2,VOL002,PS
```

### CICS Inventory

Required columns:
- `resource_name` (VARCHAR 8): Transaction ID or program name
- `resource_type` (VARCHAR 20): TRANSACTION, PROGRAM, FILE, etc.

Optional columns:
- `group_name` (VARCHAR 8): CSD group
- `status` (VARCHAR 20): ENABLED, DISABLED

Example:
```csv
resource_name,resource_type,group_name,status
PAY001,TRANSACTION,PAYROLL,ENABLED
BILL002,PROGRAM,BILLING,ENABLED
```

## Verifying Loaded Data

### Check Record Counts

```bash
# Query database directly
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM inventory_jcl"
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM inventory_programs"
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM inventory_datasets"
```

### Sample Records

```bash
# View sample JCL records
sqlite3 smf_analytics.db "SELECT * FROM inventory_jcl LIMIT 10"

# View sample program records
sqlite3 smf_analytics.db "SELECT * FROM inventory_programs LIMIT 10"
```

### Inventory Summary

```bash
python -m legacy_analyzer summary --db smf_analytics.db
```

Expected output:
```
Inventory Summary
=================
JCL Members:      1,234
Programs:         567
Copybooks:        890
Datasets:         4,567
CICS Resources:   234
Total Artifacts:  7,492
```

## Updating Inventory

### Incremental Updates

Load new inventory data to update existing records:

```bash
# Export updated inventory from mainframe
# Load with replace mode (default)
python -m legacy_analyzer load \
    --type programs \
    --file exports/program_inventory_updated.csv \
    --db smf_analytics.db \
    --update-mode replace
```

### Tracking Changes

The system tracks when inventory was loaded:

```sql
SELECT 
    'JCL' as type,
    COUNT(*) as count,
    MAX(created_at) as last_loaded
FROM inventory_jcl
UNION ALL
SELECT 
    'Programs',
    COUNT(*),
    MAX(created_at)
FROM inventory_programs;
```

## Best Practices

### 1. Regular Updates

- Update inventory monthly or quarterly
- Coordinate with SMF data collection periods
- Track inventory changes over time

### 2. Data Quality

- Validate CSV files before loading
- Check for missing required fields
- Verify date formats
- Remove duplicate entries

### 3. Naming Conventions

- Use consistent naming (uppercase recommended)
- Match mainframe naming conventions
- Document any transformations

### 4. Backup

- Backup database before major updates
- Keep CSV export files for audit trail
- Version control inventory exports

### 5. Documentation

- Document export procedures
- Record data sources
- Note any manual adjustments

## Troubleshooting

### CSV Parsing Errors

**Problem**: "Invalid CSV format" error

**Solution**:
- Check delimiter (comma vs semicolon)
- Verify column headers match expected names
- Check for special characters in data
- Ensure proper quoting of fields with commas

### Date Format Errors

**Problem**: "Invalid date format" error

**Solution**:
- Use YYYY-MM-DD format
- Check for missing dates
- Verify date values are valid

### Duplicate Key Errors

**Problem**: "Duplicate key" error

**Solution**:
- Check for duplicate entries in CSV
- Use `--update-mode replace` to update existing records
- Remove duplicates from source data

### Missing Columns

**Problem**: "Required column missing" error

**Solution**:
- Verify all required columns are present
- Check column name spelling
- Ensure header row is first line

### Performance Issues

**Problem**: Loading takes too long

**Solution**:
- Load in batches (split large CSV files)
- Ensure database has sufficient disk space
- Check system resources (memory, CPU)

## Next Steps

- **[Static Analysis Guide](STATIC_ANALYSIS_GUIDE.md)**: Analyze source code for dependencies
- **[Query Reference](QUERY_REFERENCE.md)**: Run analysis queries
- **[Risk Assessment Guide](RISK_ASSESSMENT_GUIDE.md)**: Assess artifact risk
