# MIPS Calculation Explained

## The Confusion

There was confusion about why the test data shows ~10-20 MIPS when we wanted to generate 250 MIPS. This document explains the fundamental issue and the solution.

## What is MIPS?

**MIPS (Millions of Instructions Per Second)** is a measure of **continuous processing capacity**.

When we say a mainframe runs at "250 MIPS", we mean:
- It processes 250 million instructions per second
- **Continuously, 24 hours a day, 7 days a week**
- This is the **sustained workload**, not a one-time total

## The Fundamental Issue

### MIPS is a Rate, Not a Total

**MIPS is like speed (mph), not distance (miles).**

- ❌ Wrong: "I have 250 MIPS total across my dataset"
- ✅ Right: "My system runs at 250 MIPS continuously"

### The Correct Calculation

MIPS should be calculated as:
```python
daily_mips = SUM(daily_service_units) / 3600000 / 24
average_mips = AVG(daily_mips across all days)
```

This gives us the **average continuous MIPS** - the sustained processing rate.

## Why Test Data Can't Easily Achieve 250 MIPS

### The Math

To achieve 250 MIPS continuous with realistic job patterns:

**Current test data:**
- 12 programs at "high" frequency = 12 jobs/day
- Each job: 1-30 seconds CPU time
- Result: ~10-20 MIPS continuous

**To get 250 MIPS:**
- Need ~1,000-2,000 jobs/day (100x more)
- OR each job needs 100x more CPU time (unrealistic - would be hours per job)
- OR use a much shorter time period (loses trend analysis capability)

### The Constraint

The test data generator is designed for **realistic artifact-level execution patterns**:
- Programs run daily, weekly, or monthly
- Job CPU times are realistic (seconds to minutes)
- This naturally produces low continuous MIPS when spread over days

## The Solution: Accept Realistic Test Data

### Recommended Approach

**Use test data with ~10-20 MIPS** and understand that:
1. All calculations and ratios are correct
2. Query logic works properly
3. Dashboard functionality is fully testable
4. Numbers scale proportionally

### What the Queries Show

With ~10-20 MIPS test data, the Comprehensive ROI query shows:
- vCPUs needed: ~0.1-0.2 (rounds to 1)
- Instance type: c6i.medium
- Annual AWS cost: ~$372
- Mainframe cost: ~$1,000-2,000 (based on MSU)

These are **correct** for a 10-20 MIPS workload.

### Scaling to 250 MIPS

To see what a 250 MIPS workload would look like, multiply by ~15x:
- vCPUs needed: ~2-3 (rounds to 4)
- Instance type: c6i.xlarge
- Annual AWS cost: ~$1,500
- Mainframe cost: ~$120,000

## Alternative Approaches

### Option 1: Accept Low MIPS (RECOMMENDED)
- Current: ~10-20 MIPS
- Perfect for testing and development
- All logic works correctly
- Easy to explain and scale mentally

### Option 2: Use Real SMF Data
- Parse actual mainframe SMF files
- Will have realistic MIPS values
- Best for production demos and customer scenarios
- Use the SMF file parser: `python -m tools.smf_analyzer.smf_record_parser`

### Option 3: Modify Inventory for More Jobs
- Add 100x more programs to inventory
- Set all to "high" frequency
- Would generate 1000+ jobs/day
- Creates massive database
- May slow down queries

### Option 4: Shorter Time Period (IMPLEMENTED)
- Generate data for 7 days instead of 286 days
- Concentrates workload
- Still only achieves ~10-20 MIPS with realistic job counts
- Loses long-term trend analysis

## Technical Details

### Service Units and MIPS

Service units are calculated from CPU time:
```python
service_units = total_cpu_centiseconds * multiplier
```

MIPS are calculated from service units:
```python
mips = service_units / SERVICE_UNITS_PER_MIPS_HOUR / 24
# Default: SERVICE_UNITS_PER_MIPS_HOUR = 3,600,000
```

### Why We Can't Just Increase the Multiplier

Attempting to multiply service_units by 300x to reach 250 MIPS causes:
1. **Integer overflow**: SQLite INTEGER max is 2^63-1
2. **Unrealistic values**: Service units would be astronomically high
3. **Database errors**: "Python int too large to convert to SQLite INTEGER"

### The Real-World Analogy

Imagine you have:
- 12 cars
- Each drives 1 hour per day
- Each goes 60 mph

Your "continuous speed" is: 12 cars × 1 hour × 60 mph / 24 hours = 30 mph average

To get 250 mph continuous, you'd need:
- 100 cars (not realistic for test data)
- OR each car drives 8 hours/day (changes the pattern)
- OR each car goes 500 mph (unrealistic)

## Key Takeaways

1. **MIPS is a continuous rate**, not a total amount
2. **Test data with 10-20 MIPS is realistic** for the job frequency
3. **All queries work correctly** regardless of MIPS level
4. **For 250 MIPS demos**, use real customer SMF data
5. **The math is correct** - low job frequency = low MIPS

## Updated check_mips.py

The `check_mips.py` script now correctly calculates:
- Average daily MIPS (continuous rate)
- Min/max daily MIPS
- Jobs per day
- Days analyzed

This gives an accurate picture of the continuous MIPS workload.

## Configuration

The test data generator is now configured for:
- **Time period**: 7 days (2026-01-29 to 2026-02-05)
- **Job frequency**: ~10-12 jobs/day (realistic for inventory)
- **Expected MIPS**: ~10-20 MIPS continuous
- **Service units multiplier**: 427,903,200 (realistic, no overflow)

This provides a good balance of:
- Realistic job execution patterns
- Reasonable database size
- Fast query performance
- Correct calculations and ratios
