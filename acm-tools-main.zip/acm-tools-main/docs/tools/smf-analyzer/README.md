# SMF Analyzer Tool Documentation

This directory contains detailed documentation for the SMF Analyzer tool, which provides comprehensive analysis of IBM z/OS System Management Facilities (SMF) records.

## Documentation Structure

- **[Getting Started](getting-started.md)** - Quick start guide for SMF analysis
- **[Parser Guide](parser-guide.md)** - SMF record parsing documentation
- **[Loader Guide](loader-guide.md)** - Database loading and schema management
- **[Query Guide](query-guide.md)** - Query engine and pre-built queries
- **[API Reference](api-reference.md)** - Python API documentation
- **[CLI Reference](cli-reference.md)** - Command-line interface reference

## Tool Components

The SMF Analyzer includes four integrated components:

1. **smf_record_parser** - Parse binary SMF files into structured JSON
2. **smf_loader** - Load parsed data into databases with flexible schemas
3. **smf_queries** - Analyze data with pre-built queries and custom SQL
4. **smf_doc_parser** - Extract and organize SMF documentation from IBM sources

## Quick Links

- [Tool README](../../../tools/smf-analyzer/README.md) - Main tool documentation
- [Requirements](../../../tools/smf-analyzer/requirements.txt) - Dependencies
- [Examples](../../../examples/) - Usage examples
- [Tests](../../../tests/unit/test_smf_analyzer/) - Unit tests

## Supported Record Types

| Record Type | Description | Status |
|-------------|-------------|--------|
| Type 2 | Dump Header | ✓ Parsed |
| Type 3 | Dump Trailer | ✓ Parsed |
| Type 30 | Job/Step Accounting | ✓ Full Support |
| Type 110 | CICS Transaction Server | ✓ Full Support |
| Type 70 | RMF System Resources | Planned |
| Type 72 | RMF Workload Manager | Planned |
| Type 74 | RMF Device Activity | Planned |

## Getting Help

For specific SMF Analyzer questions:
1. Check the component-specific documentation above
2. Review the [main tool README](../../../tools/smf-analyzer/README.md)
3. Examine examples in the [examples directory](../../../examples/)
4. Check the [API reference](api-reference.md) for Python usage