# Query Reference Guide

## Overview

This guide documents all available queries in the Artifact Lifecycle Analysis system. Queries are organized by category and include parameters, output format, and usage examples.

## Query Categories

1. **Unreferenced Queries**: Find artifacts not used within analysis window
2. **Missing Queries**: Find artifacts used but not in inventory
3. **Dependency Queries**: Explore artifact relationships
4. **Risk Assessment Queries**: Evaluate risk of removing artifacts
5. **Cleanup Queries**: Generate prioritized cleanup recommendations

## Running Queries

### Basic Command

```bash
python -m smf_queries run \
    --db <DATABASE> \
    --query <QUERY_NAME> \
    --params <PARAMETERS> \
    --format <FORMAT> \
    --output <OUTPUT_FILE>
```

### Parameters

- `--db`: SQLite database path (required)
- `--query`: Query name (required)
- `--params`: Query parameters as key=value pairs (optional)
- `--format`: Output format: table, csv, json, markdown (default: table)
- `--output`: Output file path (optional, default: stdout)

### Examples

```bash
# Table output to console
python -m smf_queries run --db smf_analytics.db --query unreferenced_jcl

# CSV output to file
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_programs \
    --format csv \
    --output unreferenced_programs.csv

# JSON output with parameters
python -m smf_queries run --db smf_analytics.db \
    --query missing_programs \
    --params analysis_days=730,min_executions=10 \
    --format json
```

## Unreferenced Queries

### unreferenced_jcl

Find JCL members not executed within the analysis window.

**Description**: Compares inventory JCL with SMF Type 30 job execution records.

**Parameters**:
- `analysis_days` (integer, default: 365): Number of days of SMF data to analyze
- `library_pattern` (string, default: '%'): Filter by library name pattern

**Output Columns**:
- `member_name`: JCL member name
- `library_name`: PDS library name
- `last_modified`: Last modification date
- `days_since_modified`: Days since last modified
- `size_lines`: Number of lines (if available)
- `status`: Always 'UNREFERENCED'

**Example**:
```bash
# Find JCL not executed in last 2 years
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_jcl \
    --params analysis_days=730 \
    --format csv \
    --output unreferenced_jcl.csv

# Find unreferenced JCL in specific library
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_jcl \
    --params library_pattern='PROD.JCL%' \
    --format table
```

**Sample Output**:
```
Member Name | Library Name    | Last Modified | Days Since Modified | Size Lines | Status
------------|-----------------|---------------|---------------------|------------|-------------
OLDJOB1     | PROD.JCL.LIB   | 2020-01-15    | 1768                | 250        | UNREFERENCED
TESTJOB2    | TEST.JCL.LIB   | 2019-06-20    | 1977                | 180        | UNREFERENCED
```

---

### unreferenced_programs

Find programs not executed within the analysis window.

**Description**: Compares inventory programs with SMF Type 30 (batch) and Type 110 (CICS) execution records, plus Types 14/15 for program names in dataset activity.

**Parameters**:
- `analysis_days` (integer, default: 365): Number of days of SMF data to analyze
- `min_size_kb` (integer, default: 0): Minimum program size in KB

**Output Columns**:
- `program_name`: Load module name
- `library_name`: LOADLIB name
- `link_date`: Link/compile date
- `size_bytes`: Size in bytes
- `size_kb`: Size in kilobytes
- `days_since_link`: Days since linked
- `status`: Always 'UNREFERENCED'

**Example**:
```bash
# Find programs not executed in last year
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_programs \
    --params analysis_days=365 \
    --format table

# Find large unreferenced programs (>100KB)
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_programs \
    --params min_size_kb=100 \
    --format csv \
    --output large_unreferenced_programs.csv
```

**Sample Output**:
```
Program Name | Library Name    | Link Date  | Size Bytes | Size KB | Days Since Link | Status
-------------|-----------------|------------|------------|---------|-----------------|-------------
OLDPROG1     | PROD.LOADLIB   | 2020-03-10 | 456789     | 446.08  | 1714            | UNREFERENCED
TESTPROG2    | TEST.LOADLIB   | 2019-11-20 | 234567     | 229.07  | 1824            | UNREFERENCED
```

---

### unreferenced_datasets

Find datasets not accessed within the analysis window.

**Description**: Compares inventory datasets with SMF Types 14 (INPUT), 15 (OUTPUT), 17 (deletion), 30 (job I/O), 62 (VSAM open), and 64 (VSAM close) records.

**Parameters**:
- `analysis_days` (integer, default: 365): Number of days of SMF data to analyze

**Output Columns**:
- `dataset_name`: Dataset name
- `creation_date`: Creation date
- `size_mb`: Size in megabytes
- `dataset_type`: Type (PS, PO, VS, etc.)
- `volume`: Volume serial
- `days_since_creation`: Days since created
- `status`: Always 'UNREFERENCED'

**Example**:
```bash
# Find datasets not accessed in last year
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_datasets \
    --params analysis_days=365 \
    --format table

# Export to CSV for review
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_datasets \
    --format csv \
    --output unreferenced_datasets.csv
```

**Sample Output**:
```
Dataset Name              | Creation Date | Size MB | Dataset Type | Volume | Days Since Creation | Status
--------------------------|---------------|---------|--------------|--------|---------------------|-------------
PROD.OLD.DATA            | 2020-01-15    | 1250.5  | PS           | VOL001 | 1768                | UNREFERENCED
TEST.ARCHIVE.FILE        | 2019-06-20    | 3456.2  | VSAM         | VOL002 | 1977                | UNREFERENCED
```

---

### unreferenced_copybooks

Find copybooks not referenced by any source program.

**Description**: Compares inventory copybooks with dependencies extracted from static code analysis.

**Parameters**:
- `library_pattern` (string, default: '%'): Filter by library name pattern

**Output Columns**:
- `copybook_name`: Copybook name
- `library_name`: Source library name
- `last_modified`: Last modification date
- `status`: Always 'UNREFERENCED'

**Example**:
```bash
# Find all unreferenced copybooks
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_copybooks \
    --format table

# Find unreferenced copybooks in specific library
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_copybooks \
    --params library_pattern='PROD.COPYLIB%' \
    --format csv
```

**Sample Output**:
```
Copybook Name | Library Name    | Last Modified | Status
--------------|-----------------|---------------|-------------
OLDCOPY1      | PROD.COPYLIB   | 2020-01-15    | UNREFERENCED
TESTCOPY2     | TEST.COPYLIB   | 2019-06-20    | UNREFERENCED
```

## Missing Queries

### missing_jcl

Find job names in SMF records not found in inventory.

**Description**: Identifies jobs being executed but not documented in inventory.

**Parameters**:
- `analysis_days` (integer, default: 365): Number of days of SMF data to analyze
- `min_executions` (integer, default: 1): Minimum execution count

**Output Columns**:
- `job_name`: Job name from SMF
- `first_seen`: First execution date
- `last_seen`: Last execution date
- `execution_count`: Number of executions
- `status`: Always 'MISSING'

**Example**:
```bash
# Find missing JCL executed at least 10 times
python -m smf_queries run --db smf_analytics.db \
    --query missing_jcl \
    --params min_executions=10 \
    --format table

# Find all missing JCL in last 2 years
python -m smf_queries run --db smf_analytics.db \
    --query missing_jcl \
    --params analysis_days=730 \
    --format csv \
    --output missing_jcl.csv
```

**Sample Output**:
```
Job Name  | First Seen | Last Seen  | Execution Count | Status
----------|------------|------------|-----------------|--------
NEWJOB1   | 2024-01-15 | 2024-11-15 | 234             | MISSING
SHADOW2   | 2024-03-20 | 2024-11-10 | 45              | MISSING
```

---

### missing_programs

Find programs in SMF records not found in inventory.

**Description**: Identifies programs being executed but not documented in inventory. Checks batch (Type 30), CICS (Type 110), and dataset activity (Types 14/15).

**Parameters**:
- `analysis_days` (integer, default: 365): Number of days of SMF data to analyze
- `min_executions` (integer, default: 1): Minimum execution count

**Output Columns**:
- `program_name`: Program name from SMF
- `source_type`: Where found (BATCH, CICS, DATASET_ACTIVITY)
- `first_seen`: First execution date
- `last_seen`: Last execution date
- `execution_count`: Number of executions
- `status`: Always 'MISSING'

**Example**:
```bash
# Find frequently executed missing programs
python -m smf_queries run --db smf_analytics.db \
    --query missing_programs \
    --params min_executions=50 \
    --format table

# Export all missing programs
python -m smf_queries run --db smf_analytics.db \
    --query missing_programs \
    --format csv \
    --output missing_programs.csv
```

**Sample Output**:
```
Program Name | Source Type | First Seen | Last Seen  | Execution Count | Status
-------------|-------------|------------|------------|-----------------|--------
NEWPROG1     | BATCH       | 2024-01-15 | 2024-11-15 | 456             | MISSING
CICSPROG2    | CICS        | 2024-03-20 | 2024-11-10 | 789             | MISSING
```

---

### missing_datasets

Find datasets in SMF records not found in inventory.

**Description**: Identifies datasets being accessed but not documented in inventory.

**Parameters**:
- `analysis_days` (integer, default: 365): Number of days of SMF data to analyze
- `min_accesses` (integer, default: 1): Minimum access count

**Output Columns**:
- `dataset_name`: Dataset name from SMF
- `first_seen`: First access date
- `last_seen`: Last access date
- `access_count`: Number of accesses
- `status`: Always 'MISSING'

**Example**:
```bash
# Find frequently accessed missing datasets
python -m smf_queries run --db smf_analytics.db \
    --query missing_datasets \
    --params min_accesses=100 \
    --format table
```

**Sample Output**:
```
Dataset Name              | First Seen | Last Seen  | Access Count | Status
--------------------------|------------|------------|--------------|--------
PROD.NEW.DATA            | 2024-01-15 | 2024-11-15 | 1234         | MISSING
TEMP.WORK.FILE           | 2024-03-20 | 2024-11-10 | 567          | MISSING
```

## Dependency Queries

### artifact_dependencies

Find all dependencies for a specific artifact.

**Description**: Shows what an artifact depends on (forward dependencies) or what depends on it (reverse dependencies).

**Parameters**:
- `artifact_name` (string, required): Artifact name
- `artifact_type` (string, optional): Artifact type filter
- `dependency_type` (string, optional): Dependency type filter
- `recursive` (boolean, default: false): Include transitive dependencies

**Output Columns**:
- `source_artifact`: Source artifact name
- `source_type`: Source artifact type
- `target_artifact`: Target artifact name
- `target_type`: Target artifact type
- `dependency_type`: Type of dependency
- `source_file`: Source file path
- `line_number`: Line number in source file

**Example**:
```bash
# Find what PAYROLL1 depends on
python -m smf_queries run --db smf_analytics.db \
    --query artifact_dependencies \
    --params artifact_name=PAYROLL1 \
    --format table

# Find what depends on CUSTMAST copybook
python -m smf_queries run --db smf_analytics.db \
    --query artifact_dependencies \
    --params artifact_name=CUSTMAST,artifact_type=COPYBOOK \
    --format table

# Recursive dependency tree
python -m smf_queries run --db smf_analytics.db \
    --query artifact_dependencies \
    --params artifact_name=PAYROLL1,recursive=true \
    --format tree
```

**Sample Output**:
```
Source Artifact | Source Type | Target Artifact | Target Type | Dependency Type | Source File      | Line
----------------|-------------|-----------------|-------------|-----------------|------------------|-----
PAYROLL1        | PROGRAM     | CUSTMAST        | COPYBOOK    | COPY            | PAYROLL1.cbl     | 45
PAYROLL1        | PROGRAM     | ORDERHDR        | COPYBOOK    | COPY            | PAYROLL1.cbl     | 67
PAYROLL1        | PROGRAM     | SUBPROG1        | PROGRAM     | CALL            | PAYROLL1.cbl     | 234
```

## Risk Assessment Queries

### artifact_risk_assessment

Assess risk level of removing unreferenced artifacts.

**Description**: Categorizes artifacts by risk level (HIGH, MEDIUM, LOW) based on naming patterns and dependencies.

**Parameters**:
- `artifact_type` (string, default: 'ALL'): Filter by artifact type
- `risk_level` (string, optional): Filter by risk level

**Output Columns**:
- `artifact_name`: Artifact name
- `artifact_type`: Artifact type
- `risk_level`: HIGH, MEDIUM, or LOW
- `risk_reason`: Explanation of risk classification
- `dependent_count`: Number of artifacts that depend on this
- `days_inactive`: Days since last use
- `recommended_action`: Recommended action

**Example**:
```bash
# Assess all unreferenced artifacts
python -m smf_queries run --db smf_analytics.db \
    --query artifact_risk_assessment \
    --format table

# Show only high-risk artifacts
python -m smf_queries run --db smf_analytics.db \
    --query artifact_risk_assessment \
    --params risk_level=HIGH \
    --format csv \
    --output high_risk_artifacts.csv

# Assess only programs
python -m smf_queries run --db smf_analytics.db \
    --query artifact_risk_assessment \
    --params artifact_type=PROGRAM \
    --format table
```

**Sample Output**:
```
Artifact Name | Artifact Type | Risk Level | Risk Reason           | Dependent Count | Days Inactive | Recommended Action
--------------|---------------|------------|-----------------------|-----------------|---------------|-------------------
DRBACKUP1     | PROGRAM       | HIGH       | Disaster Recovery     | 0               | 456           | REVIEW_REQUIRED
PAYROLL1      | PROGRAM       | MEDIUM     | Has 3 dependencies    | 3               | 234           | ANALYZE_DEPENDENCIES
TESTPROG1     | PROGRAM       | LOW        | No dependencies       | 0               | 789           | ARCHIVE_CANDIDATE
```

**Risk Classification**:
- **HIGH**: Matches critical patterns (DR%, YEAREND%, AUDIT%, BACKUP%, EMERGENCY%)
- **MEDIUM**: Has dependencies from other artifacts
- **LOW**: Standalone with no critical patterns

**Recommended Actions**:
- **REVIEW_REQUIRED**: Manual review needed before any action
- **ANALYZE_DEPENDENCIES**: Check dependencies before removal
- **ARCHIVE_CANDIDATE**: Safe to archive (>2 years inactive)
- **MONITOR**: Continue monitoring

## Cleanup Queries

### cleanup_recommendations

Generate prioritized cleanup recommendations.

**Description**: Ranks artifacts by cleanup priority based on size, age, risk level, and usage.

**Parameters**:
- `top_n` (integer, default: 100): Number of recommendations to return
- `min_priority_score` (float, optional): Minimum priority score

**Output Columns**:
- `artifact_name`: Artifact name
- `artifact_type`: Artifact type
- `risk_level`: Risk level
- `days_inactive`: Days since last use
- `size_mb`: Size in megabytes
- `priority_score`: Calculated priority score (higher = better candidate)
- `recommendation`: Recommended action

**Example**:
```bash
# Get top 50 cleanup candidates
python -m smf_queries run --db smf_analytics.db \
    --query cleanup_recommendations \
    --params top_n=50 \
    --format csv \
    --output cleanup_plan.csv

# Get all recommendations above priority score 100
python -m smf_queries run --db smf_analytics.db \
    --query cleanup_recommendations \
    --params min_priority_score=100 \
    --format table
```

**Sample Output**:
```
Artifact Name | Artifact Type | Risk Level | Days Inactive | Size MB | Priority Score | Recommendation
--------------|---------------|------------|---------------|---------|----------------|----------------
OLDDATA1      | DATASET       | LOW        | 1234          | 5678.9  | 789.45         | ARCHIVE_NOW
TESTPROG1     | PROGRAM       | LOW        | 987           | 123.4   | 456.78         | ARCHIVE_NOW
OLDCOPY1      | COPYBOOK      | LOW        | 876           | 0.1     | 234.56         | ARCHIVE_SOON
BACKUP1       | PROGRAM       | MEDIUM     | 456           | 234.5   | 123.45         | REVIEW_DEPENDENCIES
```

**Priority Score Calculation**:
```
priority_score = 
    (risk_weight) +           # LOW=100, MEDIUM=50, HIGH=0
    (days_inactive / 10) +    # Age factor
    (size_factor)             # Size in MB * multiplier
```

**Recommendations**:
- **ARCHIVE_NOW**: Low risk, >2 years inactive
- **ARCHIVE_SOON**: Low risk, >1 year inactive
- **REVIEW_DEPENDENCIES**: Medium risk, check dependencies first
- **MONITOR**: Continue monitoring

## Output Formats

### Table Format

Human-readable table output (default):

```bash
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_jcl \
    --format table
```

### CSV Format

Comma-separated values for Excel/spreadsheet:

```bash
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_programs \
    --format csv \
    --output programs.csv
```

### JSON Format

Structured data for programmatic processing:

```bash
python -m smf_queries run --db smf_analytics.db \
    --query missing_datasets \
    --format json \
    --output datasets.json
```

### Markdown Format

Documentation-friendly format:

```bash
python -m smf_queries run --db smf_analytics.db \
    --query cleanup_recommendations \
    --format markdown \
    --output cleanup_plan.md
```

## Query Combinations

### Complete Analysis Workflow

```bash
#!/bin/bash
DB="smf_analytics.db"
OUTPUT_DIR="reports"

# Create output directory
mkdir -p $OUTPUT_DIR

# Run all unreferenced queries
python -m smf_queries run --db $DB --query unreferenced_jcl \
    --format csv --output $OUTPUT_DIR/unreferenced_jcl.csv

python -m smf_queries run --db $DB --query unreferenced_programs \
    --format csv --output $OUTPUT_DIR/unreferenced_programs.csv

python -m smf_queries run --db $DB --query unreferenced_datasets \
    --format csv --output $OUTPUT_DIR/unreferenced_datasets.csv

python -m smf_queries run --db $DB --query unreferenced_copybooks \
    --format csv --output $OUTPUT_DIR/unreferenced_copybooks.csv

# Run all missing queries
python -m smf_queries run --db $DB --query missing_jcl \
    --format csv --output $OUTPUT_DIR/missing_jcl.csv

python -m smf_queries run --db $DB --query missing_programs \
    --format csv --output $OUTPUT_DIR/missing_programs.csv

python -m smf_queries run --db $DB --query missing_datasets \
    --format csv --output $OUTPUT_DIR/missing_datasets.csv

# Run risk assessment
python -m smf_queries run --db $DB --query artifact_risk_assessment \
    --format csv --output $OUTPUT_DIR/risk_assessment.csv

# Generate cleanup recommendations
python -m smf_queries run --db $DB --query cleanup_recommendations \
    --params top_n=100 \
    --format csv --output $OUTPUT_DIR/cleanup_plan.csv

echo "Analysis complete. Reports in $OUTPUT_DIR/"
```

## Flow Analysis Queries

The Legacy Analyzer also provides programmatic access to flow analysis, complexity analysis, and migration package planning through Python APIs. These are not SQL queries but Python functions.

### Program Flow Analysis

```python
from tools.legacy_analyzer.analysis.flow_analyzer import FlowAnalyzer

analyzer = FlowAnalyzer(database)

# Analyze program flow
flow = analyzer.analyze_flow('PAYROLL1', max_depth=10)

# Build call graph
call_graph = analyzer.build_call_graph(['PAYROLL1', 'PAYCALC'])

# Detect circular dependencies
circular_deps = analyzer.detect_circular_dependencies()
```

See [Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md) for details.

### Complexity Analysis

```python
from tools.legacy_analyzer.analysis.complexity_analyzer import ComplexityAnalyzer

analyzer = ComplexityAnalyzer()

# Analyze program complexity
metrics = analyzer.analyze_program(
    program_name='PAYROLL1',
    source_code=cobol_code,
    language='COBOL',
    dependency_count_in=5,
    dependency_count_out=10
)

# Batch analysis
results = analyzer.analyze_all_programs(programs)
```

See [Complexity Guide](COMPLEXITY_GUIDE.md) for details.

### Migration Package Planning

```python
from tools.legacy_analyzer.migration.package_builder import PackageBuilder

builder = PackageBuilder(database)

# Create migration package
package = builder.create_package(
    name='Payroll Migration',
    seed_artifacts=['PAYROLL1', 'PAYCALC']
)

# Validate package
validation = builder.validate_package(package)

# Suggest optimal packages
suggested = builder.suggest_packages(max_size=1500)
```

See [Migration Packages Guide](MIGRATION_PACKAGES_GUIDE.md) for details.

## Next Steps

- **[Flow Analysis Guide](FLOW_ANALYSIS_GUIDE.md)**: Analyze program flows
- **[Complexity Guide](COMPLEXITY_GUIDE.md)**: Assess complexity
- **[Migration Packages Guide](MIGRATION_PACKAGES_GUIDE.md)**: Plan migration packages
- **[Risk Assessment Guide](RISK_ASSESSMENT_GUIDE.md)**: Understand risk classification
- **[Cleanup Workflow](CLEANUP_WORKFLOW.md)**: Use query results for cleanup
- **[Getting Started](GETTING_STARTED.md)**: Return to quick start guide
