# Risk Assessment and Cleanup Recommendations Guide

This guide explains how to use the artifact risk assessment and cleanup recommendation queries to identify and prioritize mainframe artifacts for archival or removal.

## Overview

The risk assessment system categorizes unreferenced artifacts into three risk levels:

- **HIGH**: Critical artifacts that match disaster recovery, year-end, audit, or compliance patterns
- **MEDIUM**: Artifacts with dependencies or matching utility/reporting patterns
- **LOW**: Standalone artifacts with no critical patterns or dependencies

The cleanup recommendation system prioritizes artifacts for archival based on:
- Risk level (LOW risk = higher priority)
- Age (older = higher priority)
- Size (larger = higher priority)

## Queries

### 1. Artifact Risk Assessment Query

**Query Name**: `artifact_risk_assessment`

**Purpose**: Categorize unreferenced artifacts by risk level to identify which artifacts require review before removal.

**Parameters**:
- `artifact_type` (str, optional, default: 'ALL'): Filter by artifact type
  - Options: 'JCL', 'PROGRAM', 'DATASET', 'COPYBOOK', 'ALL'
- `analysis_days` (int, optional, default: 365): Number of days of SMF data to analyze

**Output Columns**:
- `artifact_name`: Name of the artifact
- `artifact_type`: Type (JCL, PROGRAM, DATASET, COPYBOOK)
- `risk_level`: Risk level (HIGH, MEDIUM, LOW)
- `risk_reason`: Explanation for the risk level
- `dependent_count`: Number of artifacts that depend on this one
- `days_inactive`: Days since last activity
- `recommended_action`: Recommended next step
  - `REVIEW_REQUIRED`: High-risk artifact, requires manual review
  - `ANALYZE_DEPENDENCIES`: Has dependencies, analyze impact
  - `ARCHIVE_CANDIDATE`: Safe to archive (2+ years inactive)
  - `MONITOR`: Continue monitoring

**Example Usage**:

```bash
# Risk assessment for all artifacts (365 days)
python -m smf_queries run \
  --db smf_analytics.db \
  --query artifact_risk_assessment \
  --params analysis_days=365

# Risk assessment for programs only (730 days)
python -m smf_queries run \
  --db smf_analytics.db \
  --query artifact_risk_assessment \
  --params artifact_type=PROGRAM analysis_days=730

# Risk assessment for datasets only
python -m smf_queries run \
  --db smf_analytics.db \
  --query artifact_risk_assessment \
  --params artifact_type=DATASET
```

**Python API**:

```python
from smf_loader.databases.sqlite_adapter import SQLiteAdapter
from smf_queries.query_engine import QueryEngine

database = SQLiteAdapter('smf_analytics.db')
engine = QueryEngine(database)

# Run risk assessment
result = engine.execute('artifact_risk_assessment',
                       artifact_type='ALL',
                       analysis_days=365)

# Display results
print(result.to_markdown())

# Count by risk level
risk_counts = {}
for row in result.rows:
    risk_level = row[2]  # risk_level column
    risk_counts[risk_level] = risk_counts.get(risk_level, 0) + 1

print(f"HIGH: {risk_counts.get('HIGH', 0)}")
print(f"MEDIUM: {risk_counts.get('MEDIUM', 0)}")
print(f"LOW: {risk_counts.get('LOW', 0)}")
```

### 2. Cleanup Recommendations Query

**Query Name**: `cleanup_recommendations`

**Purpose**: Generate prioritized list of artifacts for archival or removal based on size, age, and risk level.

**Parameters**:
- `top_n` (int, optional, default: 100): Number of top candidates to return
- `analysis_days` (int, optional, default: 365): Number of days of SMF data to analyze
- `min_days_inactive` (int, optional, default: 365): Minimum days inactive to consider

**Output Columns**:
- `artifact_name`: Name of the artifact
- `artifact_type`: Type (JCL, PROGRAM, DATASET, COPYBOOK)
- `risk_level`: Risk level (MEDIUM or LOW only)
- `days_inactive`: Days since last activity
- `size_mb`: Size in megabytes
- `priority_score`: Calculated priority score (higher = better candidate)
- `recommendation`: Recommended action
  - `ARCHIVE_NOW`: Low risk, 2+ years inactive
  - `ARCHIVE_SOON`: Low risk, 1+ years inactive
  - `REVIEW_DEPENDENCIES`: Medium risk, check dependencies first
  - `MONITOR`: Continue monitoring

**Priority Score Calculation**:
```
priority_score = risk_weight + age_weight + size_weight

Where:
- risk_weight: 100 (LOW), 50 (MEDIUM), 0 (HIGH)
- age_weight: days_inactive / 10
- size_weight: size_bytes / 10000
```

**Example Usage**:

```bash
# Top 50 cleanup candidates (365+ days inactive)
python -m smf_queries run \
  --db smf_analytics.db \
  --query cleanup_recommendations \
  --params top_n=50 min_days_inactive=365

# Aggressive cleanup (730+ days inactive)
python -m smf_queries run \
  --db smf_analytics.db \
  --query cleanup_recommendations \
  --params top_n=100 min_days_inactive=730

# Export to CSV
python -m smf_queries run \
  --db smf_analytics.db \
  --query cleanup_recommendations \
  --params top_n=200 \
  --format csv \
  --output cleanup_plan.csv
```

**Python API**:

```python
from smf_loader.databases.sqlite_adapter import SQLiteAdapter
from smf_queries.query_engine import QueryEngine

database = SQLiteAdapter('smf_analytics.db')
engine = QueryEngine(database)

# Get cleanup recommendations
result = engine.execute('cleanup_recommendations',
                       top_n=100,
                       analysis_days=365,
                       min_days_inactive=365)

# Display results
print(result.to_markdown())

# Calculate total savings
total_size_mb = sum(row[4] for row in result.rows)  # size_mb column
print(f"Total potential savings: {total_size_mb:.2f} MB")

# Group by recommendation
rec_counts = {}
for row in result.rows:
    recommendation = row[6]  # recommendation column
    rec_counts[recommendation] = rec_counts.get(recommendation, 0) + 1

for rec, count in sorted(rec_counts.items()):
    print(f"{rec}: {count} artifacts")
```

## Risk Patterns

The system uses configurable risk patterns to identify critical artifacts:

### High Risk Patterns
- `DR%` - Disaster Recovery
- `YEAREND%` - Year-end Processing
- `AUDIT%` - Audit/Compliance
- `BACKUP%` - Backup Process
- `EMERGENCY%` - Emergency Procedure
- `EOY%` - End of Year Processing
- `EOM%` - End of Month Processing
- `REGULATORY%` - Regulatory Compliance
- `COMPLIANCE%` - Compliance Related
- `CRITICAL%` - Critical Process

### Medium Risk Patterns
- `UTIL%` - Utility Program
- `REPORT%` - Reporting Function
- `BATCH%` - Batch Processing
- `MONTHLY%` - Monthly Processing
- `QUARTERLY%` - Quarterly Processing

**Note**: These patterns can be customized by modifying the queries or creating a configuration file.

## Workflow

### 1. Initial Assessment

Start with a broad risk assessment to understand the landscape:

```bash
python -m smf_queries run \
  --db smf_analytics.db \
  --query artifact_risk_assessment \
  --params analysis_days=365 \
  --format markdown \
  --output risk_assessment.md
```

Review the results and focus on:
- HIGH risk artifacts: Verify they are truly unused before considering removal
- MEDIUM risk artifacts: Analyze dependencies
- LOW risk artifacts: Safe candidates for archival

### 2. Generate Cleanup Plan

Generate prioritized cleanup recommendations:

```bash
python -m smf_queries run \
  --db smf_analytics.db \
  --query cleanup_recommendations \
  --params top_n=100 min_days_inactive=365 \
  --format csv \
  --output cleanup_plan.csv
```

### 3. Review Dependencies

For MEDIUM risk artifacts, check dependencies:

```bash
python -m smf_queries run \
  --db smf_analytics.db \
  --query artifact_dependencies \
  --params artifact_name=PROGNAME direction=incoming
```

### 4. Archive Candidates

Focus on artifacts with `ARCHIVE_NOW` or `ARCHIVE_SOON` recommendations:

```python
result = engine.execute('cleanup_recommendations',
                       top_n=1000,
                       min_days_inactive=730)

archive_now = [row for row in result.rows if row[6] == 'ARCHIVE_NOW']
print(f"Ready to archive: {len(archive_now)} artifacts")
```

### 5. Track Progress

After archiving artifacts, re-run the analysis to track progress:

```bash
# Before cleanup
python -m smf_queries run \
  --db smf_analytics.db \
  --query cleanup_recommendations \
  --params top_n=1000 > before_cleanup.txt

# After cleanup
python -m smf_queries run \
  --db smf_analytics.db \
  --query cleanup_recommendations \
  --params top_n=1000 > after_cleanup.txt

# Compare results
diff before_cleanup.txt after_cleanup.txt
```

## Best Practices

### 1. Start Conservative

Begin with artifacts that are:
- LOW risk
- 2+ years inactive (730+ days)
- No dependencies

```python
result = engine.execute('cleanup_recommendations',
                       top_n=50,
                       min_days_inactive=730)

# Filter for LOW risk only
low_risk = [row for row in result.rows if row[2] == 'LOW']
```

### 2. Verify Before Removal

Always verify artifacts are truly unused:
1. Check SMF records for recent activity
2. Review dependencies
3. Consult with application owners
4. Archive first, delete later

### 3. Document Decisions

Keep a record of cleanup decisions:

```python
# Export with timestamp
import datetime
timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
output_file = f'cleanup_plan_{timestamp}.csv'

result = engine.execute('cleanup_recommendations', top_n=100)
with open(output_file, 'w') as f:
    f.write(result.to_csv())
```

### 4. Incremental Approach

Don't try to clean up everything at once:
- Week 1: Archive 10-20 LOW risk artifacts
- Week 2: Review results, archive 20-30 more
- Week 3: Start on MEDIUM risk artifacts with no dependencies
- Week 4: Review and adjust approach

### 5. Monitor for Reactivation

After archiving, monitor for any usage:

```bash
# Check if archived artifacts appear in recent SMF data
python -m smf_queries run \
  --db smf_analytics.db \
  --query missing_programs \
  --params analysis_days=30 min_executions=1
```

## Example: Complete Workflow

```python
#!/usr/bin/env python3
"""Complete artifact cleanup workflow."""

from smf_loader.databases.sqlite_adapter import SQLiteAdapter
from smf_queries.query_engine import QueryEngine

# Initialize
database = SQLiteAdapter('smf_analytics.db')
engine = QueryEngine(database)

# Step 1: Risk Assessment
print("Step 1: Risk Assessment")
risk_result = engine.execute('artifact_risk_assessment',
                             artifact_type='ALL',
                             analysis_days=365)

risk_counts = {}
for row in risk_result.rows:
    risk_level = row[2]
    risk_counts[risk_level] = risk_counts.get(risk_level, 0) + 1

print(f"HIGH: {risk_counts.get('HIGH', 0)}")
print(f"MEDIUM: {risk_counts.get('MEDIUM', 0)}")
print(f"LOW: {risk_counts.get('LOW', 0)}")

# Step 2: Generate Cleanup Plan
print("\nStep 2: Cleanup Recommendations")
cleanup_result = engine.execute('cleanup_recommendations',
                               top_n=100,
                               min_days_inactive=730)

print(f"Found {len(cleanup_result.rows)} cleanup candidates")

# Step 3: Calculate Savings
total_size_mb = sum(row[4] for row in cleanup_result.rows)
print(f"Potential savings: {total_size_mb:.2f} MB")

# Step 4: Export Results
with open('cleanup_plan.csv', 'w') as f:
    f.write(cleanup_result.to_csv())

print("\n✓ Cleanup plan saved to cleanup_plan.csv")
```

## Troubleshooting

### No Results Returned

If queries return no results:
1. Verify inventory data is loaded
2. Check SMF records are loaded
3. Adjust `analysis_days` parameter (try 730 or 1095)
4. Verify database schema is correct

### Unexpected Risk Levels

If artifacts are classified incorrectly:
1. Review risk patterns in the query
2. Check dependency data is loaded
3. Verify artifact naming conventions
4. Consider customizing risk patterns

### Performance Issues

For large databases:
1. Ensure indexes are created on key columns
2. Reduce `top_n` parameter
3. Filter by `artifact_type`
4. Consider running queries during off-peak hours

## See Also

- [Artifact Analysis Overview](README.md)
- [Inventory Management Guide](INVENTORY_GUIDE.md)
- [Query Reference](QUERY_REFERENCE.md)
- [Cleanup Workflow](CLEANUP_WORKFLOW.md)
