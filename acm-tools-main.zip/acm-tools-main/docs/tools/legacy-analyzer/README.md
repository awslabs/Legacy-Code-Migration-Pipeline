# Legacy Analyzer Tool Documentation

This directory contains detailed documentation for the Legacy Analyzer tool, which provides comprehensive static code analysis and migration planning capabilities for mainframe applications.

## Documentation Structure

- **[Getting Started](getting-started.md)** - Quick start guide for legacy code analysis
- **[Inventory Management](inventory-guide.md)** - Loading and managing inventory data
- **[Static Analysis](static-analysis-guide.md)** - Code parsing and dependency extraction
- **[Flow Analysis](flow-analysis-guide.md)** - Program flow and call graph analysis
- **[Complexity Assessment](complexity-guide.md)** - Code complexity metrics and assessment
- **[Migration Planning](migration-planning-guide.md)** - Migration package creation and planning
- **[Risk Assessment](risk-assessment-guide.md)** - Risk classification and assessment
- **[API Reference](api-reference.md)** - Python API documentation
- **[CLI Reference](cli-reference.md)** - Command-line interface reference

## Tool Capabilities

The Legacy Analyzer provides comprehensive analysis capabilities:

### Multi-Language Support
- **COBOL** - Full parsing with COPY statement resolution
- **JCL** - Job Control Language analysis with dataset dependencies
- **PL/I** - Program dependencies and INCLUDE statement resolution
- **RPG** - RPG program analysis and dependencies
- **Natural** - Natural language program analysis
- **REXX** - REXX script analysis
- **Assembler** - Basic assembler program analysis

### Analysis Features
- **Dependency Extraction** - Cross-language dependency mapping
- **Flow Analysis** - Complete program flow visualization
- **Complexity Assessment** - LOC, cyclomatic complexity, dependency metrics
- **Missing Code Detection** - Identify referenced but missing artifacts
- **Circular Dependency Detection** - Find and report circular dependencies
- **Migration Package Planning** - Group artifacts into logical migration units
- **Migration Flow Export** - Export flows with multiple sorting strategies for optimal migration planning

### Migration Planning Features
- **Flow-Based Planning** - Organize migration around program execution flows
- **Multiple Sorting Strategies** - 6 different strategies for different migration approaches:
  - **complexity-asc**: Simplest first (pilot/POC)
  - **complexity-desc**: Most complex first (experienced teams)
  - **independence**: Minimal dependencies (parallel migration)
  - **dependencies**: Most dependencies first (shared infrastructure)
  - **name**: Alphabetical (documentation)
  - **none**: Database order (baseline)
- **Extended Scope Metadata** - Include copybooks, datasets, JCL, and CICS resources
- **Wave Planning** - Divide flows into migration waves
- **Parallel Migration Support** - Identify independent flows for concurrent migration

### Integration Features
- **Database Integration** - Store analysis results with SMF data
- **Visualization Export** - Mermaid, Graphviz DOT, JSON formats
- **Report Generation** - Comprehensive analysis reports
- **Risk Classification** - Automated risk assessment based on patterns

## Quick Links

- [Tool README](../../../tools/legacy-analyzer/README.md) - Main tool documentation
- [Requirements](../../../tools/legacy-analyzer/requirements.txt) - Dependencies
- [Examples](../../../examples/) - Usage examples
- [Tests](../../../tests/unit/test_legacy_analyzer/) - Unit tests
- [Configuration](../../../config/legacy_analyzer.yaml) - Tool configuration

## Supported Languages

| Language | Parser | Dependencies | Flow Analysis | Complexity |
|----------|--------|--------------|---------------|------------|
| COBOL | ✓ | ✓ | ✓ | ✓ |
| JCL | ✓ | ✓ | ✓ | ✓ |
| PL/I | ✓ | ✓ | ✓ | ✓ |
| RPG | ✓ | ✓ | ✓ | ✓ |
| Natural | ✓ | ✓ | ✓ | ✓ |
| REXX | ✓ | ✓ | ✓ | ✓ |
| Assembler | ✓ | ✓ | ✓ | ✓ |

## Getting Help

For specific Legacy Analyzer questions:
1. Check the component-specific documentation above
2. Review the [main tool README](../../../tools/legacy-analyzer/README.md)
3. Examine examples in the [examples directory](../../../examples/)
4. Check the [API reference](api-reference.md) for Python usage
5. Review configuration options in [config files](../../../config/)