# Cleanup Workflow Guide

## Overview

This guide provides a step-by-step workflow for safely identifying, archiving, and removing unreferenced mainframe artifacts. The workflow emphasizes safety, validation, and incremental progress.

## Workflow Phases

1. **Discovery**: Identify unreferenced artifacts
2. **Assessment**: Evaluate risk and dependencies
3. **Planning**: Prioritize cleanup activities
4. **Validation**: Verify artifacts are truly unused
5. **Archival**: Move artifacts to archive
6. **Monitoring**: Track for unexpected usage
7. **Removal**: Permanently delete archived artifacts

## Phase 1: Discovery

### Objective
Identify all unreferenced artifacts across all types.

### Steps

#### 1.1 Load Data

Ensure all data is loaded:

```bash
# Verify SMF data is loaded
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM smf30_identification"
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM smf110_performance"

# Verify inventory is loaded
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM inventory_jcl"
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM inventory_programs"
sqlite3 smf_analytics.db "SELECT COUNT(*) FROM inventory_datasets"
```

#### 1.2 Run Discovery Queries

Execute all unreferenced queries:

```bash
#!/bin/bash
DB="smf_analytics.db"
DISCOVERY_DIR="discovery_$(date +%Y%m%d)"
mkdir -p $DISCOVERY_DIR

# Find unreferenced artifacts
python -m smf_queries run --db $DB --query unreferenced_jcl \
    --params analysis_days=365 \
    --format csv --output $DISCOVERY_DIR/unreferenced_jcl.csv

python -m smf_queries run --db $DB --query unreferenced_programs \
    --params analysis_days=365 \
    --format csv --output $DISCOVERY_DIR/unreferenced_programs.csv

python -m smf_queries run --db $DB --query unreferenced_datasets \
    --params analysis_days=365 \
    --format csv --output $DISCOVERY_DIR/unreferenced_datasets.csv

python -m smf_queries run --db $DB --query unreferenced_copybooks \
    --format csv --output $DISCOVERY_DIR/unreferenced_copybooks.csv

echo "Discovery complete. Results in $DISCOVERY_DIR/"
```

#### 1.3 Review Results

Open the CSV files in Excel or a spreadsheet application:
- Sort by size to identify large artifacts
- Sort by age to identify old artifacts
- Count artifacts by library/type

### Deliverables
- CSV files with unreferenced artifacts by type
- Initial counts and statistics

## Phase 2: Assessment

### Objective
Evaluate risk level and dependencies for each unreferenced artifact.

### Steps

#### 2.1 Run Risk Assessment

```bash
DB="smf_analytics.db"
ASSESSMENT_DIR="assessment_$(date +%Y%m%d)"
mkdir -p $ASSESSMENT_DIR

# Risk assessment for all artifacts
python -m smf_queries run --db $DB \
    --query artifact_risk_assessment \
    --format csv --output $ASSESSMENT_DIR/risk_assessment.csv

# Separate by risk level
python -m smf_queries run --db $DB \
    --query artifact_risk_assessment \
    --params risk_level=HIGH \
    --format csv --output $ASSESSMENT_DIR/high_risk.csv

python -m smf_queries run --db $DB \
    --query artifact_risk_assessment \
    --params risk_level=MEDIUM \
    --format csv --output $ASSESSMENT_DIR/medium_risk.csv

python -m smf_queries run --db $DB \
    --query artifact_risk_assessment \
    --params risk_level=LOW \
    --format csv --output $ASSESSMENT_DIR/low_risk.csv
```

#### 2.2 Analyze Dependencies

For MEDIUM risk artifacts, check dependencies:

```bash
# Export all dependencies
sqlite3 $DB -csv -header \
    "SELECT * FROM dependencies" \
    > $ASSESSMENT_DIR/all_dependencies.csv

# Find artifacts with dependencies
sqlite3 $DB -csv -header \
    "SELECT target_artifact, COUNT(*) as dependent_count 
     FROM dependencies 
     GROUP BY target_artifact 
     HAVING COUNT(*) > 0" \
    > $ASSESSMENT_DIR/artifacts_with_dependencies.csv
```

#### 2.3 Review with Stakeholders

Schedule review meetings with:
- Application owners
- Database administrators
- Operations team
- Compliance/audit team

Discuss:
- HIGH risk artifacts: Why are they unreferenced?
- MEDIUM risk artifacts: Can dependencies be removed?
- LOW risk artifacts: Any concerns with archival?

### Deliverables
- Risk assessment report
- Dependency analysis
- Stakeholder sign-off on cleanup plan

## Phase 3: Planning

### Objective
Create a prioritized, phased cleanup plan.

### Steps

#### 3.1 Generate Cleanup Recommendations

```bash
DB="smf_analytics.db"
PLAN_DIR="cleanup_plan_$(date +%Y%m%d)"
mkdir -p $PLAN_DIR

# Top 100 cleanup candidates
python -m smf_queries run --db $DB \
    --query cleanup_recommendations \
    --params top_n=100 \
    --format csv --output $PLAN_DIR/cleanup_top100.csv

# Conservative plan (2+ years inactive, LOW risk only)
python -m smf_queries run --db $DB \
    --query cleanup_recommendations \
    --params top_n=200,min_days_inactive=730 \
    --format csv --output $PLAN_DIR/cleanup_conservative.csv

# Aggressive plan (1+ years inactive, LOW and MEDIUM risk)
python -m smf_queries run --db $DB \
    --query cleanup_recommendations \
    --params top_n=500,min_days_inactive=365 \
    --format csv --output $PLAN_DIR/cleanup_aggressive.csv
```

#### 3.2 Create Phased Plan

Organize cleanup into phases:

**Phase 1 (Week 1-2)**: Quick Wins
- LOW risk artifacts
- 2+ years inactive
- No dependencies
- Target: 20-50 artifacts

**Phase 2 (Week 3-4)**: Moderate Cleanup
- LOW risk artifacts
- 1-2 years inactive
- No dependencies
- Target: 50-100 artifacts

**Phase 3 (Week 5-8)**: Dependency Cleanup
- MEDIUM risk artifacts
- Check and remove dependencies first
- Then archive the artifact
- Target: 30-50 artifacts

**Phase 4 (Week 9-12)**: Large Datasets
- Focus on large datasets (>1GB)
- Significant storage savings
- Target: 10-20 datasets

#### 3.3 Calculate Savings

```python
#!/usr/bin/env python3
"""Calculate potential savings from cleanup plan."""

import csv

def calculate_savings(csv_file):
    total_size_mb = 0
    count = 0
    
    with open(csv_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            size_mb = float(row.get('size_mb', 0))
            total_size_mb += size_mb
            count += 1
    
    total_size_gb = total_size_mb / 1024
    return count, total_size_mb, total_size_gb

# Calculate for each phase
phases = [
    'cleanup_conservative.csv',
    'cleanup_aggressive.csv'
]

for phase in phases:
    count, size_mb, size_gb = calculate_savings(f'cleanup_plan/{phase}')
    print(f"{phase}:")
    print(f"  Artifacts: {count}")
    print(f"  Size: {size_mb:.2f} MB ({size_gb:.2f} GB)")
    print()
```

### Deliverables
- Phased cleanup plan with timelines
- Expected storage savings
- Resource requirements

## Phase 4: Validation

### Objective
Verify artifacts are truly unused before archival.

### Steps

#### 4.1 Extended Analysis Window

Re-run analysis with longer window:

```bash
# Check 2-year window
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_programs \
    --params analysis_days=730 \
    --format csv --output validation_730days.csv

# Check 3-year window
python -m smf_queries run --db smf_analytics.db \
    --query unreferenced_programs \
    --params analysis_days=1095 \
    --format csv --output validation_1095days.csv
```

#### 4.2 Cross-Reference with Other Sources

Check additional sources:
- Change management records
- Application documentation
- Source code repositories
- Incident tickets

#### 4.3 Pilot Test

Select 5-10 artifacts for pilot archival:
- Archive to test location
- Monitor for 2-4 weeks
- Check for any access attempts
- Verify no impact on operations

```bash
# Monitor for usage of pilot artifacts
# (Create a list of pilot artifact names)
cat > pilot_artifacts.txt <<EOF
TESTPROG1
TESTPROG2
OLDJCL1
EOF

# Check if any appear in recent SMF data
while read artifact; do
    echo "Checking $artifact..."
    sqlite3 smf_analytics.db \
        "SELECT COUNT(*) FROM smf30_identification 
         WHERE program_name = '$artifact' 
         AND record_date >= DATE('now', '-30 days')"
done < pilot_artifacts.txt
```

### Deliverables
- Validation report
- Pilot test results
- Final approval for archival

## Phase 5: Archival

### Objective
Safely move artifacts to archive location.

### Steps

#### 5.1 Prepare Archive Location

Create archive datasets on mainframe:

```jcl
//ARCHIVE  JOB (ACCT),'CREATE ARCHIVE',CLASS=A
//STEP1    EXEC PGM=IEFBR14
//ARCHJCL  DD DSN=ARCHIVE.JCL.LIB,DISP=(NEW,CATLG),
//            SPACE=(TRK,(100,10,50)),
//            DCB=(RECFM=FB,LRECL=80,BLKSIZE=3120)
//ARCHPGM  DD DSN=ARCHIVE.LOADLIB,DISP=(NEW,CATLG),
//            SPACE=(TRK,(500,50,100)),
//            DCB=(RECFM=U,BLKSIZE=32760)
//ARCHCPY  DD DSN=ARCHIVE.COPYLIB,DISP=(NEW,CATLG),
//            SPACE=(TRK,(100,10,50)),
//            DCB=(RECFM=FB,LRECL=80,BLKSIZE=3120)
```

#### 5.2 Copy Artifacts to Archive

```jcl
//COPYARC  JOB (ACCT),'COPY TO ARCHIVE',CLASS=A
//*
//* Copy JCL member to archive
//*
//STEP1    EXEC PGM=IEBCOPY
//SYSPRINT DD SYSOUT=*
//SYSUT1   DD DSN=PROD.JCL.LIB,DISP=SHR
//SYSUT2   DD DSN=ARCHIVE.JCL.LIB,DISP=SHR
//SYSIN    DD *
  COPY INDD=SYSUT1,OUTDD=SYSUT2
  SELECT MEMBER=((OLDJCL1,OLDJCL1))
/*
```

#### 5.3 Verify Archive

```jcl
//VERIFY   JOB (ACCT),'VERIFY ARCHIVE',CLASS=A
//STEP1    EXEC PGM=IEBPTPCH
//SYSPRINT DD SYSOUT=*
//SYSUT1   DD DSN=ARCHIVE.JCL.LIB,DISP=SHR
//SYSUT2   DD SYSOUT=*
//SYSIN    DD *
  PRINT MAXNAME=1,MEMBER=OLDJCL1
/*
```

#### 5.4 Document Archive

Create archive inventory:

```csv
artifact_name,artifact_type,original_location,archive_location,archive_date,archived_by
OLDJCL1,JCL,PROD.JCL.LIB,ARCHIVE.JCL.LIB,2024-11-18,USERID
OLDPROG1,PROGRAM,PROD.LOADLIB,ARCHIVE.LOADLIB,2024-11-18,USERID
```

#### 5.5 Update Database

Record archival in database:

```sql
-- Update artifact status
UPDATE artifact_status
SET status = 'ARCHIVED',
    recommended_action = 'ARCHIVED',
    analysis_date = DATE('now')
WHERE artifact_name IN ('OLDJCL1', 'OLDPROG1');

-- Record history
INSERT INTO artifact_history 
    (artifact_name, artifact_type, status_from, status_to, 
     change_date, change_reason, changed_by)
VALUES 
    ('OLDJCL1', 'JCL', 'UNREFERENCED', 'ARCHIVED', 
     DATE('now'), 'Cleanup Phase 1', 'USERID'),
    ('OLDPROG1', 'PROGRAM', 'UNREFERENCED', 'ARCHIVED', 
     DATE('now'), 'Cleanup Phase 1', 'USERID');
```

### Deliverables
- Archived artifacts in archive location
- Archive inventory
- Updated database records

## Phase 6: Monitoring

### Objective
Monitor for unexpected usage of archived artifacts.

### Steps

#### 6.1 Set Up Monitoring

Create monitoring script:

```bash
#!/bin/bash
# monitor_archived.sh - Check for usage of archived artifacts

DB="smf_analytics.db"
ARCHIVE_LIST="archived_artifacts.txt"
ALERT_FILE="archive_alerts_$(date +%Y%m%d).txt"

echo "Monitoring archived artifacts..." > $ALERT_FILE

while read artifact; do
    # Check SMF Type 30 (batch)
    count=$(sqlite3 $DB \
        "SELECT COUNT(*) FROM smf30_identification 
         WHERE program_name = '$artifact' 
         AND record_date >= DATE('now', '-7 days')")
    
    if [ $count -gt 0 ]; then
        echo "ALERT: $artifact used $count times in last 7 days" >> $ALERT_FILE
    fi
    
    # Check SMF Type 110 (CICS)
    count=$(sqlite3 $DB \
        "SELECT COUNT(*) FROM smf110_performance 
         WHERE program_name = '$artifact' 
         AND record_date >= DATE('now', '-7 days')")
    
    if [ $count -gt 0 ]; then
        echo "ALERT: $artifact used $count times in CICS in last 7 days" >> $ALERT_FILE
    fi
done < $ARCHIVE_LIST

# Send alerts if any found
if [ -s $ALERT_FILE ]; then
    mail -s "Archived Artifact Usage Alert" admin@company.com < $ALERT_FILE
fi
```

#### 6.2 Schedule Monitoring

Add to cron:

```bash
# Run daily at 6 AM
0 6 * * * /path/to/monitor_archived.sh
```

#### 6.3 Review Alerts

If archived artifact is used:
1. Investigate why it was used
2. Restore from archive if needed
3. Update documentation
4. Adjust cleanup criteria

### Deliverables
- Monitoring script
- Alert reports
- Incident documentation (if any)

## Phase 7: Removal

### Objective
Permanently delete archived artifacts after retention period.

### Steps

#### 7.1 Verify Retention Period

Wait appropriate retention period:
- **Minimum**: 90 days
- **Recommended**: 180 days
- **Conservative**: 365 days

#### 7.2 Final Validation

Before deletion, verify:
- No usage during retention period
- No pending change requests
- No audit holds
- Stakeholder approval

```bash
# Check for any usage during retention period
sqlite3 smf_analytics.db \
    "SELECT program_name, COUNT(*) as usage_count
     FROM smf30_identification
     WHERE program_name IN (SELECT artifact_name FROM artifact_status WHERE status = 'ARCHIVED')
     AND record_date >= DATE('now', '-180 days')
     GROUP BY program_name"
```

#### 7.3 Delete from Archive

```jcl
//DELETE   JOB (ACCT),'DELETE ARCHIVED',CLASS=A
//STEP1    EXEC PGM=IEFBR14
//ARCHJCL  DD DSN=ARCHIVE.JCL.LIB(OLDJCL1),DISP=(OLD,DELETE)
//ARCHPGM  DD DSN=ARCHIVE.LOADLIB(OLDPROG1),DISP=(OLD,DELETE)
```

#### 7.4 Update Database

```sql
-- Update status to DELETED
UPDATE artifact_status
SET status = 'DELETED',
    analysis_date = DATE('now')
WHERE artifact_name IN ('OLDJCL1', 'OLDPROG1')
AND status = 'ARCHIVED';

-- Record history
INSERT INTO artifact_history 
    (artifact_name, artifact_type, status_from, status_to, 
     change_date, change_reason, changed_by)
VALUES 
    ('OLDJCL1', 'JCL', 'ARCHIVED', 'DELETED', 
     DATE('now'), 'Retention period expired', 'USERID');
```

#### 7.5 Document Deletion

Create deletion report:

```csv
artifact_name,artifact_type,archive_date,deletion_date,retention_days,deleted_by
OLDJCL1,JCL,2024-11-18,2025-05-17,180,USERID
OLDPROG1,PROGRAM,2024-11-18,2025-05-17,180,USERID
```

### Deliverables
- Deletion report
- Updated database records
- Final storage savings calculation

## Best Practices

### 1. Start Small

Begin with a pilot:
- 5-10 artifacts
- LOW risk only
- 2+ years inactive
- Monitor for 30 days

### 2. Communicate

Keep stakeholders informed:
- Weekly status updates
- Monthly summary reports
- Immediate alerts for issues

### 3. Document Everything

Maintain records of:
- What was archived/deleted
- When it was archived/deleted
- Why it was archived/deleted
- Who approved the action

### 4. Automate

Automate repetitive tasks:
- Monitoring scripts
- Report generation
- Alert notifications
- Status updates

### 5. Measure Success

Track metrics:
- Artifacts archived/deleted
- Storage reclaimed
- Time saved
- Issues encountered

## Rollback Procedures

### If Archived Artifact is Needed

1. **Immediate Restore**:
```jcl
//RESTORE  JOB (ACCT),'RESTORE FROM ARCHIVE',CLASS=A
//STEP1    EXEC PGM=IEBCOPY
//SYSPRINT DD SYSOUT=*
//SYSUT1   DD DSN=ARCHIVE.JCL.LIB,DISP=SHR
//SYSUT2   DD DSN=PROD.JCL.LIB,DISP=SHR
//SYSIN    DD *
  COPY INDD=SYSUT1,OUTDD=SYSUT2
  SELECT MEMBER=((OLDJCL1,OLDJCL1))
/*
```

2. **Update Database**:
```sql
UPDATE artifact_status
SET status = 'ACTIVE',
    recommended_action = 'MONITOR',
    analysis_date = DATE('now')
WHERE artifact_name = 'OLDJCL1';

INSERT INTO artifact_history 
    (artifact_name, artifact_type, status_from, status_to, 
     change_date, change_reason, changed_by)
VALUES 
    ('OLDJCL1', 'JCL', 'ARCHIVED', 'ACTIVE', 
     DATE('now'), 'Restored due to usage', 'USERID');
```

3. **Document Incident**:
- Why was it needed?
- How was it discovered?
- What can be improved?

## Troubleshooting

### Artifact Still Referenced

**Problem**: Artifact marked unreferenced but still in use

**Solution**:
1. Check SMF data completeness
2. Verify analysis window is sufficient
3. Check for dynamic calls (not detectable)
4. Update inventory with correct information

### Cannot Archive

**Problem**: Archive operation fails

**Solution**:
1. Check archive dataset space
2. Verify permissions
3. Check for locks on source
4. Review JCL syntax

### Performance Degradation

**Problem**: Cleanup activities impact performance

**Solution**:
1. Schedule during off-peak hours
2. Process in smaller batches
3. Add delays between operations
4. Monitor system resources

## Metrics and Reporting

### Weekly Report

```
Cleanup Progress Report - Week of 2024-11-18

Phase 1 (Quick Wins):
- Artifacts archived: 25
- Storage reclaimed: 1.2 GB
- Issues encountered: 0
- Status: On track

Phase 2 (Moderate Cleanup):
- Artifacts identified: 75
- Risk assessment: Complete
- Stakeholder approval: Pending
- Status: In progress

Next Week:
- Complete Phase 1
- Begin Phase 2 archival
- Review monitoring alerts
```

### Monthly Summary

```
Monthly Cleanup Summary - November 2024

Total Artifacts Archived: 125
Total Storage Reclaimed: 15.3 GB
Artifacts by Type:
- JCL: 45
- Programs: 35
- Datasets: 30
- Copybooks: 15

Risk Distribution:
- LOW: 100 (80%)
- MEDIUM: 25 (20%)
- HIGH: 0 (0%)

Issues:
- Restored from archive: 2
- Monitoring alerts: 3
- Stakeholder escalations: 0

Next Month Goals:
- Archive 150 artifacts
- Reclaim 20 GB storage
- Begin Phase 3 (dependencies)
```

## Next Steps

- **[Getting Started](GETTING_STARTED.md)**: Return to quick start
- **[Query Reference](QUERY_REFERENCE.md)**: Explore available queries
- **[Risk Assessment Guide](RISK_ASSESSMENT_GUIDE.md)**: Understand risk levels
- **[Inventory Guide](INVENTORY_GUIDE.md)**: Manage inventory data
