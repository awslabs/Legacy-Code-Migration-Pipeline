# ROI Analysis Workflow Guide

## Overview

The ROI Analysis tab provides comprehensive cost analysis and return on investment calculations for mainframe migration projects. The reports use a **component-based calculation approach** that reuses infrastructure sizing reports to ensure accuracy and consistency across all cost estimates.

## Calculation Methodology

### Component-Based Approach

The ROI reports aggregate costs from specialized infrastructure sizing reports rather than using hardcoded formulas:

**EC2 Costs:**
- Calculated separately for Batch and CICS workloads
- Batch EC2 costs from **Batch Sizing Report**
- CICS EC2 costs from **CICS Sizing Report**
- Combined for total EC2 costs
- **Why separate?** Batch and CICS have different performance characteristics and instance requirements. Separate sizing provides more accurate results than a single combined MIPS calculation.

**Storage Costs:**
- VSAM storage costs from **VSAM Replacement Report** (EBS/EFS for file-based storage)
- General storage costs from **EFS/EBS Storage Report** (non-VSAM datasets)
- Combined for total storage costs

**RDS Costs:**
- Database costs from **DB2 Replacement Report**
- If no DB2 data is found, RDS costs will be $0

**Network Costs:**
- Network costs from **Network Requirements Report**
- Based on data transfer patterns and bandwidth requirements

### Comparison with MIPS/EC2 Sizing Report

You may notice that the **MIPS/EC2 Sizing Report** in the Infrastructure Sizing tab shows different (typically lower) costs than the ROI Analysis. This is expected:

- **MIPS/EC2 Report**: Sizes a single instance pool for the combined workload (more efficient, less accurate)
- **ROI Analysis**: Sizes batch and CICS separately, then combines (more conservative, more accurate)

The difference represents the trade-off between efficiency and accuracy. The ROI report uses the more conservative approach to avoid underestimating costs.

## Quick Start: Complete ROI Analysis in One Query

The **Comprehensive ROI Assessment** query provides everything you need for migration decision-making in a single, cohesive report.

## Step-by-Step Workflow

### 1. Navigate to ROI Analysis Tab
- Open the SMF Dashboard
- Click on the "ROI Analysis" tab
- Ensure your database is selected (check top-right dropdown)

### 2. Select the Comprehensive ROI Assessment Query
- In the query dropdown, select: **"Comprehensive ROI Assessment"**
- This query will appear in the "Cost Analysis" category

### 3. Configure Parameters (Optional)

#### Sizing Scenario (Most Important)
Choose one based on your risk tolerance:

- **recommended** (default): Balanced approach using 95th percentile MIPS
  - Handles 95% of workload
  - Best for most migrations
  
- **minimum**: Cost-optimized using average MIPS
  - Lowest cost
  - Requires auto-scaling for peak loads
  - Best for elastic workloads
  
- **maximum**: Performance-guaranteed using peak MIPS
  - Handles all workload spikes
  - Highest cost
  - Best for mission-critical systems

#### Storage Parameters (Optional)
- **ebs_storage_gb**: Total EBS storage (default: 10,000 GB)
- **rds_instance_count**: Number of RDS instances (default: 2)
- **rds_storage_gb**: Total RDS storage (default: 5,000 GB)

### 4. Execute the Query
- Click "Execute Query"
- Wait for results (typically 2-5 seconds)

### 5. Review the Results

The query returns a **single comprehensive row** with all metrics:

#### Infrastructure Sizing Section
```
sizing_scenario: recommended
vcpus_needed: 0.18
vcpus_actual: 1
instance_count: 1
instance_type: c6i.medium
avg_mips: 0.091
p95_mips: 0.182
peak_mips: 0.298
```

**Interpretation**: Your workload needs 0.18 vCPUs on average (95th percentile). This maps to 1× c6i.medium instance (1 vCPU).

#### Cost Comparison Section
```
annual_mainframe_cost: $24,567
annual_aws_cost: $1,491
annual_savings: $23,076
```

**Interpretation**: You're currently spending $24,567/year on mainframe (MSU-based). AWS will cost $1,491/year, saving $23,076 annually.

#### Migration Cost Section
```
total_migration_cost: $120,000
migration_duration_months: 24
payback_period_years: 0.52
```

**Interpretation**: Migration will cost $120,000 one-time. You'll recover this investment in 6.2 months through cost savings.

#### 5-Year TCO Section
```
mainframe_5year_tco: $122,835
aws_5year_tco: $127,455
total_5year_savings: $115,380
roi_percentage_5year: 96.2%
```

**Interpretation**: Over 5 years, you'll save $115,380 total. That's a 96% return on your $120,000 migration investment.

#### Monthly Breakdown Section
```
monthly_ec2_cost: $31
monthly_ebs_cost: $800
monthly_rds_cost: $281
monthly_aws_total: $1,224
```

**Interpretation**: Monthly AWS costs break down to: $31 compute, $800 storage, $281 database, $1,224 total (including 10% support).

### 6. Adjust Configuration (If Needed)

If the results don't match your expectations, adjust configuration parameters:

#### Go to Configuration Tab
- Click "Configuration" tab
- Scroll to relevant parameter sections

#### Key Parameters to Adjust

**MIPS/vCPU Conversion**
- `MIPS_PER_VCPU`: Default 100 (range: 50-200)
  - Lower value = more vCPUs needed = higher cost
  - Higher value = fewer vCPUs needed = lower cost

**AWS Pricing** (Update for your region)
- `EC2_C6I_MEDIUM_HOURLY`: $0.0425 (us-east-1)
- `EC2_C6I_LARGE_HOURLY`: $0.085 (us-east-1)
- Update to match your target AWS region

**Migration Costs** (Adjust for your organization)
- `MIGRATION_COST_PER_PROGRAM`: $500 per program
  - Increase for complex programs
  - Decrease for simple programs
- `MIGRATION_TESTING_COST`: $100,000
  - Adjust based on testing scope
- `MIGRATION_CONTINGENCY_RATIO`: 0.20 (20%)
  - Increase for higher risk projects

#### Save Configuration
- Click "Save Configuration" after making changes
- Return to ROI Analysis tab
- Re-run the query to see updated results

### 7. Export Results

Export the comprehensive report for stakeholders:

- **JSON**: For programmatic processing
- **CSV**: For Excel analysis
- **Markdown**: For documentation

Click the appropriate export button below the results table.

## Understanding the Numbers

### Why is MSU cost higher than MIPS cost?
- **MSU**: Measures peak consumption (4-hour rolling window)
- **MIPS**: Measures average consumption
- Peak is typically 5-10x higher than average for batch workloads
- IBM charges based on peak capacity (MSU), not average usage

### Why do I need so few vCPUs?
- Modern AWS vCPUs are very powerful (100 MIPS per vCPU)
- Mainframe MIPS are measured differently than x86 performance
- Your test data may represent a small workload
- Real production workloads will likely need more vCPUs

### How accurate is the migration cost estimate?
- Based on program counts from inventory
- Uses configurable per-program conversion cost
- Includes testing, training, and contingency
- Adjust parameters to match your organization's costs

## Comparison with Old Workflow

### Old Workflow (Disconnected)
1. Run "MIPS-Based EC2 Sizing" → Get 1 vCPU needed
2. Run "AWS Cost" → Uses hardcoded 10 instances (❌ disconnect!)
3. Run "MSU Cost" → Get mainframe cost
4. Run "Migration ROI" → Uses placeholder $1M (❌ disconnect!)
5. Manually reconcile conflicting numbers
6. Create spreadsheet to combine results

**Problems**: 
- Inconsistent results
- Manual reconciliation required
- Hardcoded values
- Time-consuming

### New Workflow (Integrated)
1. Run "Comprehensive ROI Assessment" → Get complete report
2. Review all metrics in one place
3. Export for stakeholders

**Benefits**:
- Consistent calculations
- Single source of truth
- All values calculated from data
- Fast and easy

## Common Scenarios

### Scenario 1: Cost-Sensitive Migration
**Goal**: Minimize AWS costs

**Configuration**:
- Sizing scenario: `minimum`
- Enable auto-scaling in AWS
- Use spot instances where possible

**Expected Result**: Lowest AWS cost, requires elastic infrastructure

### Scenario 2: Performance-Critical Migration
**Goal**: Guarantee performance for all workloads

**Configuration**:
- Sizing scenario: `maximum`
- No auto-scaling needed
- Reserved instances for cost savings

**Expected Result**: Highest AWS cost, zero performance risk

### Scenario 3: Balanced Migration (Recommended)
**Goal**: Balance cost and performance

**Configuration**:
- Sizing scenario: `recommended`
- Auto-scaling for occasional spikes
- Mix of reserved and on-demand instances

**Expected Result**: Moderate cost, handles 95% of workload

## Troubleshooting

### Query Returns No Results
**Cause**: No SMF Type 30 data or no inventory data

**Solution**:
1. Check Database Inspector tab
2. Verify SMF Type 30 tables have data
3. Verify inventory tables have data
4. Load data if missing

### vCPU Count Seems Wrong
**Cause**: MIPS_PER_VCPU parameter may not match your assumptions

**Solution**:
1. Go to Configuration tab
2. Adjust `MIPS_PER_VCPU` parameter
3. Typical range: 80-120 MIPS per vCPU
4. Re-run query

### Migration Cost Seems Too High/Low
**Cause**: Default per-program cost may not match your organization

**Solution**:
1. Go to Configuration tab
2. Adjust `MIGRATION_COST_PER_PROGRAM`
3. Adjust `MIGRATION_TESTING_COST`
4. Adjust `MIGRATION_TRAINING_COST`
5. Re-run query

### AWS Cost Doesn't Match AWS Calculator
**Cause**: Pricing parameters may be outdated or for different region

**Solution**:
1. Go to Configuration tab
2. Update EC2 pricing parameters for your region
3. Update EBS and RDS pricing
4. Re-run query

## Next Steps

After running the Comprehensive ROI Assessment:

1. **Review with Stakeholders**: Export results and present to decision-makers
2. **Refine Assumptions**: Adjust configuration parameters based on feedback
3. **Run Sensitivity Analysis**: Try all three sizing scenarios to understand cost range
4. **Plan Migration**: Use the results to build detailed migration plan
5. **Monitor Progress**: Re-run query periodically to track actual vs. projected costs

## Additional Resources

- **COMPREHENSIVE_ROI_QUERY.md**: Detailed technical documentation
- **MIPS_MSU_ANALYSIS.md**: Understanding MIPS vs MSU differences
- **Configuration Tab**: Adjust all parameters
- **Infrastructure Sizing Tab**: Detailed infrastructure analysis
- **Migration Planning Tab**: Migration complexity and effort analysis
