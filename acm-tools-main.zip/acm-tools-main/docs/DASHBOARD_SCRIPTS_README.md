# SMF Dashboard Management Scripts

This directory contains convenience scripts for managing the SMF Dashboard web interface.

## Scripts

### startDashboard.sh

Starts the SMF Dashboard in the background as a daemon process.

**Usage:**
```bash
./startDashboard.sh
```

**Features:**
- Checks if dashboard is already running
- Validates port availability (default: 5001)
- Starts dashboard in background with nohup
- Saves process ID to `.dashboard.pid`
- Logs output to `dashboard.log`
- Provides access URL and management instructions

**Output:**
```
========================================
SMF Dashboard Startup
========================================

Starting SMF Dashboard...
✓ Dashboard started successfully
  PID: 12345
  Port: 5001
  Log file: dashboard.log

========================================
Dashboard is running!
========================================
Access the dashboard at:
  http://localhost:5001

To stop the dashboard, run:
  ./stopDashboard.sh

To view logs in real-time:
  tail -f dashboard.log
```

### stopDashboard.sh

Gracefully stops the running SMF Dashboard.

**Usage:**
```bash
./stopDashboard.sh
```

**Features:**
- Checks if dashboard is running via PID file
- Attempts graceful shutdown (SIGTERM)
- Falls back to forced shutdown (SIGKILL) if needed
- Cleans up PID file
- Preserves log file for review

**Output:**
```
========================================
SMF Dashboard Shutdown
========================================

Stopping dashboard (PID: 12345)...
✓ Dashboard stopped successfully

========================================
Dashboard has been shut down
========================================

To start the dashboard again, run:
  ./startDashboard.sh

Log file preserved at: dashboard.log
```

## Files Created

- `.dashboard.pid` - Contains the process ID of the running dashboard
- `dashboard.log` - Contains all dashboard output (stdout and stderr)

## Common Scenarios

### Starting the Dashboard
```bash
./startDashboard.sh
```

### Stopping the Dashboard
```bash
./stopDashboard.sh
```

### Viewing Real-time Logs
```bash
tail -f dashboard.log
```

### Checking Dashboard Status
```bash
# Check if PID file exists
if [ -f .dashboard.pid ]; then
    PID=$(cat .dashboard.pid)
    if ps -p $PID > /dev/null; then
        echo "Dashboard is running (PID: $PID)"
    else
        echo "Dashboard is not running (stale PID file)"
    fi
else
    echo "Dashboard is not running"
fi
```

### Restarting the Dashboard
```bash
./stopDashboard.sh && ./startDashboard.sh
```

## Troubleshooting

### Port Already in Use

If you see:
```
Error: Port 5001 is already in use
```

**Solution:**
1. Check what's using the port:
   ```bash
   lsof -i :5001
   ```

2. Stop the conflicting process or change the dashboard port in `tools/smf_dashboard/app.py`

**Note:** On macOS, port 5000 is used by the system ControlCenter service, which is why the dashboard uses port 5001 by default.

### Dashboard Won't Start

If the dashboard fails to start:

1. Check the log file:
   ```bash
   cat dashboard.log
   ```

2. Verify the module is installed:
   ```bash
   python3 -c "from tools.smf_dashboard import app"
   ```

3. Install if needed:
   ```bash
   pip install -e .
   ```

### Dashboard Won't Stop

If the stop script fails:

1. Manually kill the process:
   ```bash
   kill -9 $(cat .dashboard.pid)
   rm .dashboard.pid
   ```

2. Or find and kill by port:
   ```bash
   lsof -ti :5000 | xargs kill -9
   ```

### Stale PID File

If the PID file exists but the process isn't running:

```bash
rm .dashboard.pid
./startDashboard.sh
```

## Integration with Other Scripts

These scripts work alongside other toolkit scripts:

- `run_smftestdata_inventory.sh` - Generate test data
- `run_carddemo_analysis.sh` - Run analysis
- `complete_analysis.sh` - Complete analysis workflow

**Example Workflow:**
```bash
# 1. Generate test data
./run_smftestdata_inventory.sh

# 2. Start dashboard
./startDashboard.sh

# 3. Access dashboard at http://localhost:5000
# 4. Load and analyze data through the web interface

# 5. Stop dashboard when done
./stopDashboard.sh
```

## Environment Variables

The scripts use these environment variables:

- `FLASK_ENV=development` - Flask environment mode
- `FLASK_DEBUG=0` - Debug mode disabled for background operation

To customize, edit the scripts or set before running:
```bash
export FLASK_ENV=production
./startDashboard.sh
```

## Security Notes

- Dashboard runs on `0.0.0.0:5001` (accessible from network)
- Port 5001 is used instead of 5000 to avoid conflicts with macOS ControlCenter
- For production use, consider:
  - Running behind a reverse proxy (nginx, Apache)
  - Enabling HTTPS
  - Setting a secure `SECRET_KEY` environment variable
  - Restricting network access with firewall rules

## Alternative: Direct Execution

You can also run the dashboard directly (foreground):

```bash
# Using Python module
python3 -m tools.smf_dashboard.app

# Or using console script (if installed)
smf-dashboard
```

This is useful for development and debugging as you can see output in real-time and stop with Ctrl+C.
