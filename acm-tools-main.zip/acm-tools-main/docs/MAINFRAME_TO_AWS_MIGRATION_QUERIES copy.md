# Mainframe-to-AWS Migration Queries

## Overview

This document provides a comprehensive catalog of SQL queries for analyzing mainframe workloads and planning AWS migrations. These queries leverage SMF (System Management Facilities) records and static code analysis to provide insights into:

- **Code Artifact Analysis**: Identify unreferenced, missing, and risky artifacts
- **Infrastructure Sizing**: Calculate EC2, EBS, EFS, RDS, and network requirements
- **Cost Analysis**: Estimate mainframe costs and AWS migration costs
- **Migration Planning**: Prioritize workloads and assess migration complexity

## Table of Contents

1. [Code Artifact Analysis Queries](#1-code-artifact-analysis-queries)
2. [Infrastructure Sizing Queries](#2-infrastructure-sizing-queries)
3. [Cost Analysis Queries](#3-cost-analysis-queries)
4. [Migration Planning Queries](#4-migration-planning-queries)
5. [Missing SMF Record Types](#5-missing-smf-record-types)

---

## 1. Code Artifact Analysis Queries

These queries help identify which code artifacts (JCL, programs, datasets, copybooks, transactions) are actively used, which are unreferenced, and which are missing from inventory.

### 1.1 Unreferenced Artifacts

#### 1.1.1 Unreferenced JCL Jobs

**Purpose**: Find JCL members in inventory that have not been executed in the analysis window.

**SMF Record Types Used**: Type 30 (Batch Job Completion)

**SQL Query**:
```sql
SELECT 
    ij.member_name,
    ij.library_name,
    ij.last_modified,
    CAST(JULIANDAY('now') - JULIANDAY(ij.last_modified) AS INTEGER) as days_since_modified,
    ij.size_lines,
    'UNREFERENCED' as status
FROM inventory_jcl ij
LEFT JOIN (
    SELECT DISTINCT i.job_name, MAX(r.record_date) as last_used
    FROM smf30_identification i
    JOIN smf_records r ON i.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
    GROUP BY i.job_name
) usage ON UPPER(TRIM(ij.member_name)) = UPPER(TRIM(usage.job_name))
WHERE usage.job_name IS NULL
ORDER BY days_since_modified DESC;
```


**Migration Impact**: Unreferenced JCL can be excluded from migration, reducing scope and cost.

#### 1.1.2 Unreferenced Programs

**Purpose**: Find programs in inventory that have not been executed in batch (Type 30), I/O operations (Types 14, 15), or CICS (Type 110).

**SMF Record Types Used**: Types 14, 15, 30, 110

**SQL Query**:
```sql
WITH program_usage AS (
    -- Programs from SMF Type 30 (batch execution)
    SELECT DISTINCT UPPER(TRIM(i.program_name)) as program_name
    FROM smf30_identification i
    JOIN smf_records r ON i.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND i.program_name IS NOT NULL
    
    UNION
    
    -- Programs from SMF Type 14 (INPUT operations)
    SELECT DISTINCT UPPER(TRIM(s14.program_name)) as program_name
    FROM smf14_records s14
    JOIN smf_records r ON s14.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s14.program_name IS NOT NULL
    
    UNION
    
    -- Programs from SMF Type 15 (OUTPUT operations)
    SELECT DISTINCT UPPER(TRIM(s15.program_name)) as program_name
    FROM smf15_records s15
    JOIN smf_records r ON s15.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s15.program_name IS NOT NULL
    
    UNION
    
    -- Programs from SMF Type 110 (CICS execution)
    SELECT DISTINCT UPPER(TRIM(s110.program_name)) as program_name
    FROM smf110_performance s110
    JOIN smf_records r ON s110.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s110.program_name IS NOT NULL
)
SELECT 
    ip.program_name,
    ip.library_name,
    ip.link_date,
    ip.size_bytes,
    ROUND(ip.size_bytes / 1024.0, 2) as size_kb,
    CAST(JULIANDAY('now') - JULIANDAY(ip.link_date) AS INTEGER) as days_since_link,
    'UNREFERENCED' as status
FROM inventory_programs ip
LEFT JOIN program_usage pu 
    ON UPPER(TRIM(ip.program_name)) = pu.program_name
WHERE pu.program_name IS NULL
ORDER BY size_bytes DESC;
```

**Migration Impact**: Unreferenced programs can be excluded from migration, reducing conversion effort.


#### 1.1.3 Unreferenced Datasets

**Purpose**: Find datasets in inventory that have not been accessed via I/O operations (Types 14, 15, 17) or VSAM operations (Types 62, 64).

**SMF Record Types Used**: Types 14, 15, 17, 62, 64

**SQL Query**:
```sql
WITH dataset_usage AS (
    -- Datasets from SMF Type 14 (INPUT activity)
    SELECT DISTINCT UPPER(TRIM(s14.dataset_name)) as dataset_name
    FROM smf14_records s14
    JOIN smf_records r ON s14.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s14.dataset_name IS NOT NULL
    
    UNION
    
    -- Datasets from SMF Type 15 (OUTPUT activity)
    SELECT DISTINCT UPPER(TRIM(s15.dataset_name)) as dataset_name
    FROM smf15_records s15
    JOIN smf_records r ON s15.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s15.dataset_name IS NOT NULL
    
    UNION
    
    -- Datasets from SMF Type 17 (deletion)
    SELECT DISTINCT UPPER(TRIM(s17.dataset_name)) as dataset_name
    FROM smf17_records s17
    JOIN smf_records r ON s17.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s17.dataset_name IS NOT NULL
    
    UNION
    
    -- Datasets from SMF Type 64 (VSAM close)
    SELECT DISTINCT UPPER(TRIM(s64.component_name)) as dataset_name
    FROM smf64_records s64
    JOIN smf_records r ON s64.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s64.component_name IS NOT NULL
    
    UNION
    
    -- Datasets from SMF Type 62 (VSAM open)
    SELECT DISTINCT UPPER(TRIM(s62.component_name)) as dataset_name
    FROM smf62_records s62
    JOIN smf_records r ON s62.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s62.component_name IS NOT NULL
)
SELECT 
    ids.dataset_name,
    ids.creation_date,
    ids.size_mb,
    ids.dataset_type,
    ids.volume,
    CAST(JULIANDAY('now') - JULIANDAY(ids.creation_date) AS INTEGER) as days_since_creation,
    'UNREFERENCED' as status
FROM inventory_datasets ids
LEFT JOIN dataset_usage du 
    ON UPPER(TRIM(ids.dataset_name)) = du.dataset_name
WHERE du.dataset_name IS NULL
ORDER BY size_mb DESC;
```

**Migration Impact**: Unreferenced datasets can be excluded from migration, reducing storage migration costs.


#### 1.1.4 Unreferenced Copybooks

**Purpose**: Find copybooks in inventory that are not referenced by any source program via COPY statements.

**SMF Record Types Used**: None (uses static analysis dependency data)

**SQL Query**:
```sql
SELECT 
    ic.copybook_name,
    ic.library_name,
    ic.last_modified,
    CAST(JULIANDAY('now') - JULIANDAY(ic.last_modified) AS INTEGER) as days_since_modified,
    'UNREFERENCED' as status
FROM inventory_copybooks ic
LEFT JOIN (
    SELECT DISTINCT UPPER(TRIM(target_artifact_name)) as copybook_name
    FROM artifact_dependencies
    WHERE dependency_type = 'COPY'
        AND target_artifact_type = 'COPYBOOK'
) deps ON UPPER(TRIM(ic.copybook_name)) = deps.copybook_name
WHERE deps.copybook_name IS NULL
ORDER BY days_since_modified DESC;
```

**Migration Impact**: Unreferenced copybooks can be excluded from migration.

#### 1.1.5 Unreferenced CICS Transactions

**Purpose**: Find CICS transactions defined in inventory but not executed in the analysis window.

**SMF Record Types Used**: Type 110 (CICS Transaction)

**SQL Query**:
```sql
SELECT 
    it.transaction_id,
    it.program_name,
    it.transaction_type,
    'UNREFERENCED' as status
FROM inventory_transactions it
LEFT JOIN (
    SELECT DISTINCT UPPER(TRIM(s110.transaction_id)) as transaction_id
    FROM smf110_performance s110
    JOIN smf_records r ON s110.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s110.transaction_id IS NOT NULL
) usage ON UPPER(TRIM(it.transaction_id)) = usage.transaction_id
WHERE usage.transaction_id IS NULL
ORDER BY it.transaction_id;
```

**Migration Impact**: Unreferenced transactions can be excluded from migration, reducing CICS conversion effort.

### 1.2 Missing Artifacts

#### 1.2.1 Missing JCL Jobs

**Purpose**: Find job names in SMF Type 30 records that are not found in JCL inventory (may indicate dynamic JCL generation or missing source).

**SMF Record Types Used**: Type 30

**SQL Query**:
```sql
WITH job_usage AS (
    SELECT 
        UPPER(TRIM(i.job_name)) as job_name,
        r.record_date
    FROM smf30_identification i
    JOIN smf_records r ON i.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND i.job_name IS NOT NULL
)
SELECT 
    usage.job_name,
    MIN(usage.record_date) as first_seen,
    MAX(usage.record_date) as last_seen,
    COUNT(*) as execution_count,
    'MISSING' as status
FROM job_usage usage
LEFT JOIN inventory_jcl ij 
    ON usage.job_name = UPPER(TRIM(ij.member_name))
WHERE ij.member_name IS NULL
GROUP BY usage.job_name
HAVING COUNT(*) >= 1
ORDER BY execution_count DESC;
```

**Migration Impact**: Missing JCL must be located or recreated before migration.


#### 1.2.2 Missing Programs

**Purpose**: Find programs in SMF records that are not found in program inventory.

**SMF Record Types Used**: Types 14, 15, 30, 110

**SQL Query**:
```sql
WITH program_usage AS (
    -- Programs from SMF Type 30 (batch execution)
    SELECT 
        UPPER(TRIM(i.program_name)) as program_name,
        'BATCH' as source_type,
        r.record_date
    FROM smf30_identification i
    JOIN smf_records r ON i.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND i.program_name IS NOT NULL
    
    UNION ALL
    
    -- Programs from SMF Type 110 (CICS execution)
    SELECT 
        UPPER(TRIM(s110.program_name)) as program_name,
        'CICS' as source_type,
        r.record_date
    FROM smf110_performance s110
    JOIN smf_records r ON s110.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s110.program_name IS NOT NULL
)
SELECT 
    usage.program_name,
    usage.source_type,
    MIN(usage.record_date) as first_seen,
    MAX(usage.record_date) as last_seen,
    COUNT(*) as execution_count,
    'MISSING' as status
FROM program_usage usage
LEFT JOIN inventory_programs ip 
    ON usage.program_name = UPPER(TRIM(ip.program_name))
WHERE ip.program_name IS NULL
GROUP BY usage.program_name, usage.source_type
HAVING COUNT(*) >= 1
ORDER BY execution_count DESC;
```

**Migration Impact**: Missing programs must be located or recreated before migration.

#### 1.2.3 Missing Datasets

**Purpose**: Find datasets in SMF records that are not found in dataset inventory.

**SMF Record Types Used**: Types 14, 15, 17, 62, 64

**SQL Query**:
```sql
WITH dataset_usage AS (
    SELECT 
        UPPER(TRIM(s14.dataset_name)) as dataset_name,
        r.record_date
    FROM smf14_records s14
    JOIN smf_records r ON s14.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s14.dataset_name IS NOT NULL
    
    UNION ALL
    
    SELECT 
        UPPER(TRIM(s15.dataset_name)) as dataset_name,
        r.record_date
    FROM smf15_records s15
    JOIN smf_records r ON s15.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s15.dataset_name IS NOT NULL
    
    UNION ALL
    
    SELECT 
        UPPER(TRIM(s64.component_name)) as dataset_name,
        r.record_date
    FROM smf64_records s64
    JOIN smf_records r ON s64.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s64.component_name IS NOT NULL
)
SELECT 
    usage.dataset_name,
    MIN(usage.record_date) as first_seen,
    MAX(usage.record_date) as last_seen,
    COUNT(*) as access_count,
    'MISSING' as status
FROM dataset_usage usage
LEFT JOIN inventory_datasets ids 
    ON usage.dataset_name = UPPER(TRIM(ids.dataset_name))
WHERE ids.dataset_name IS NULL
GROUP BY usage.dataset_name
HAVING COUNT(*) >= 1
ORDER BY access_count DESC;
```

**Migration Impact**: Missing datasets must be located or recreated before migration.


### 1.3 Artifact Risk Assessment

**Purpose**: Categorize unreferenced artifacts by risk level (HIGH/MEDIUM/LOW) based on naming patterns and dependencies.

**SMF Record Types Used**: Types 14, 15, 30, 110

**SQL Query**:
```sql
WITH unreferenced_artifacts AS (
    -- Combine all unreferenced artifacts (JCL, programs, datasets, copybooks)
    -- See queries 1.1.1 - 1.1.4 for details
    ...
),
risk_patterns AS (
    -- High risk patterns (configurable)
    SELECT 'DR%' as pattern, 'HIGH' as risk_level, 'Disaster Recovery' as reason
    UNION SELECT 'YEAREND%', 'HIGH', 'Year-end Processing'
    UNION SELECT 'AUDIT%', 'HIGH', 'Audit/Compliance'
    UNION SELECT 'BACKUP%', 'HIGH', 'Backup Process'
    UNION SELECT 'EMERGENCY%', 'HIGH', 'Emergency Procedure'
    UNION SELECT 'EOY%', 'HIGH', 'End of Year Processing'
    UNION SELECT 'EOM%', 'HIGH', 'End of Month Processing'
    UNION SELECT 'REGULATORY%', 'HIGH', 'Regulatory Compliance'
    -- Medium risk patterns
    UNION SELECT 'UTIL%', 'MEDIUM', 'Utility Program'
    UNION SELECT 'REPORT%', 'MEDIUM', 'Reporting Function'
    UNION SELECT 'BATCH%', 'MEDIUM', 'Batch Processing'
),
dependencies AS (
    SELECT 
        UPPER(TRIM(target_artifact_name)) as artifact_name,
        COUNT(*) as dependent_count
    FROM artifact_dependencies
    GROUP BY UPPER(TRIM(target_artifact_name))
)
SELECT 
    u.artifact_name,
    u.artifact_type,
    CASE 
        WHEN EXISTS (SELECT 1 FROM risk_patterns rp 
                     WHERE UPPER(TRIM(u.artifact_name)) LIKE rp.pattern
                     AND rp.risk_level = 'HIGH') THEN 'HIGH'
        WHEN d.dependent_count > 0 THEN 'MEDIUM'
        WHEN EXISTS (SELECT 1 FROM risk_patterns rp 
                     WHERE UPPER(TRIM(u.artifact_name)) LIKE rp.pattern
                     AND rp.risk_level = 'MEDIUM') THEN 'MEDIUM'
        ELSE 'LOW'
    END as risk_level,
    COALESCE(d.dependent_count, 0) as dependent_count,
    CAST(JULIANDAY('now') - JULIANDAY(u.last_activity) AS INTEGER) as days_inactive,
    CASE 
        WHEN EXISTS (SELECT 1 FROM risk_patterns rp 
                     WHERE UPPER(TRIM(u.artifact_name)) LIKE rp.pattern
                     AND rp.risk_level = 'HIGH') THEN 'REVIEW_REQUIRED'
        WHEN d.dependent_count > 0 THEN 'ANALYZE_DEPENDENCIES'
        WHEN JULIANDAY('now') - JULIANDAY(u.last_activity) > 730 
            THEN 'ARCHIVE_CANDIDATE'
        ELSE 'MONITOR'
    END as recommended_action
FROM unreferenced_artifacts u
LEFT JOIN dependencies d ON UPPER(TRIM(u.artifact_name)) = d.artifact_name
ORDER BY 
    CASE risk_level 
        WHEN 'HIGH' THEN 1 
        WHEN 'MEDIUM' THEN 2 
        ELSE 3 
    END,
    days_inactive DESC;
```

**Migration Impact**: High-risk artifacts should be reviewed before exclusion; low-risk artifacts are safe to exclude.

---

## 2. Infrastructure Sizing Queries

These queries calculate AWS infrastructure requirements based on mainframe workload characteristics.


### 2.1 EC2 Compute Sizing

#### 2.1.1 Batch Workload CPU Requirements

**Purpose**: Calculate CPU requirements for batch workloads based on SMF Type 30 data.

**SMF Record Types Used**: Type 30

**SQL Query**:
```sql
SELECT 
    i.job_name,
    i.program_name,
    COUNT(*) as execution_count,
    -- CPU metrics
    AVG(p.cpu_time_seconds) as avg_cpu_seconds,
    MAX(p.cpu_time_seconds) as max_cpu_seconds,
    SUM(p.cpu_time_seconds) as total_cpu_seconds,
    AVG(p.cpu_time_seconds * 1000 / NULLIF(c.elapsed_time_seconds, 0)) as avg_cpu_utilization_pct,
    -- Service units (for MIPS calculation)
    AVG(p.service_units) as avg_service_units,
    SUM(p.service_units) as total_service_units,
    -- Elapsed time
    AVG(c.elapsed_time_seconds) as avg_elapsed_seconds,
    MAX(c.elapsed_time_seconds) as max_elapsed_seconds,
    -- Memory
    AVG(s.region_size_kb / 1024.0) as avg_memory_mb,
    MAX(s.region_size_kb / 1024.0) as max_memory_mb,
    -- Execution pattern
    MIN(r.record_date) as first_execution,
    MAX(r.record_date) as last_execution,
    COUNT(DISTINCT DATE(r.record_date)) as days_active
FROM smf30_identification i
JOIN smf30_processor p ON i.record_id = p.record_id
JOIN smf30_completion c ON i.record_id = c.record_id
JOIN smf30_storage s ON i.record_id = s.record_id
JOIN smf_records r ON i.record_id = r.record_id
WHERE r.record_date >= DATE('now', '-365 days')
    AND i.job_name IS NOT NULL
GROUP BY i.job_name, i.program_name
ORDER BY total_cpu_seconds DESC;
```

**AWS Sizing Calculation**:
```python
# Convert CPU seconds to vCPU requirements
# Assume 1 mainframe CPU second ≈ 0.5 AWS vCPU seconds (conservative)
aws_vcpu_seconds = total_cpu_seconds * 0.5

# Calculate average vCPU requirement
avg_vcpu_required = aws_vcpu_seconds / (days_active * 86400)

# Add 20% headroom for peaks
recommended_vcpu = avg_vcpu_required * 1.2

# Map to EC2 instance types
if recommended_vcpu <= 2:
    instance_type = "c6i.large"  # 2 vCPU
elif recommended_vcpu <= 4:
    instance_type = "c6i.xlarge"  # 4 vCPU
elif recommended_vcpu <= 8:
    instance_type = "c6i.2xlarge"  # 8 vCPU
else:
    instance_type = "c6i.4xlarge"  # 16 vCPU
```

**Migration Impact**: Determines EC2 instance type and count for batch workloads.


#### 2.1.2 CICS Workload CPU Requirements

**Purpose**: Calculate CPU requirements for CICS workloads based on SMF Type 110 data.

**SMF Record Types Used**: Type 110

**SQL Query**:
```sql
SELECT 
    s110.transaction_id,
    s110.program_name,
    s110.applid,
    COUNT(*) as transaction_count,
    -- CPU metrics
    AVG(s110.cpu_time_seconds) as avg_cpu_seconds,
    MAX(s110.cpu_time_seconds) as max_cpu_seconds,
    SUM(s110.cpu_time_seconds) as total_cpu_seconds,
    -- Response time
    AVG(s110.elapsed_time_seconds) as avg_response_seconds,
    MAX(s110.elapsed_time_seconds) as max_response_seconds,
    PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY s110.elapsed_time_seconds) as p95_response_seconds,
    -- Throughput
    COUNT(*) / NULLIF(COUNT(DISTINCT DATE(r.record_date)), 0) as avg_daily_transactions,
    MAX(hourly.transactions_per_hour) as peak_hourly_transactions,
    -- Execution pattern
    MIN(r.record_date) as first_execution,
    MAX(r.record_date) as last_execution
FROM smf110_performance s110
JOIN smf_records r ON s110.record_id = r.record_id
LEFT JOIN (
    SELECT 
        transaction_id,
        DATE(record_date) as date,
        strftime('%H', record_date) as hour,
        COUNT(*) as transactions_per_hour
    FROM smf110_performance s110
    JOIN smf_records r ON s110.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
    GROUP BY transaction_id, DATE(record_date), strftime('%H', record_date)
) hourly ON s110.transaction_id = hourly.transaction_id
WHERE r.record_date >= DATE('now', '-365 days')
    AND s110.transaction_id IS NOT NULL
GROUP BY s110.transaction_id, s110.program_name, s110.applid
ORDER BY total_cpu_seconds DESC;
```

**AWS Sizing Calculation**:
```python
# Convert to vCPU requirements
# CICS transactions typically need more headroom for response time
aws_vcpu_seconds = total_cpu_seconds * 0.5

# Calculate vCPU for average load
avg_vcpu_required = aws_vcpu_seconds / (days_active * 86400)

# Add 50% headroom for CICS response time requirements
recommended_vcpu = avg_vcpu_required * 1.5

# Calculate for peak load
peak_vcpu_required = (peak_hourly_transactions * avg_cpu_seconds * 0.5) / 3600

# Use the higher of average or peak
final_vcpu = max(recommended_vcpu, peak_vcpu_required * 1.2)

# Map to EC2 instance types (compute-optimized for CICS)
if final_vcpu <= 4:
    instance_type = "c6i.xlarge"  # 4 vCPU
elif final_vcpu <= 8:
    instance_type = "c6i.2xlarge"  # 8 vCPU
elif final_vcpu <= 16:
    instance_type = "c6i.4xlarge"  # 16 vCPU
else:
    instance_type = "c6i.8xlarge"  # 32 vCPU
```

**Migration Impact**: Determines EC2 instance type and count for CICS regions.


### 2.2 Storage Sizing (EBS/EFS)

#### 2.2.1 Dataset Storage Requirements

**Purpose**: Calculate storage requirements for datasets based on SMF Types 14, 15, 64 and inventory data.

**SMF Record Types Used**: Types 14, 15, 64

**SQL Query**:
```sql
WITH dataset_metrics AS (
    SELECT 
        s14.dataset_name,
        -- Size metrics from Type 14 (INPUT)
        AVG(s14.bytes_read / 1024.0 / 1024.0) as avg_size_mb_type14,
        MAX(s14.bytes_read / 1024.0 / 1024.0) as max_size_mb_type14,
        -- Track allocation from Type 15 (OUTPUT)
        AVG(s15.tracks_allocated * 56 / 1024.0) as avg_allocated_mb_type15,
        -- VSAM metrics from Type 64
        AVG(s64.ci_size * s64.ca_size / 1024.0 / 1024.0) as avg_vsam_size_mb,
        -- Access patterns
        COUNT(DISTINCT s14.record_id) as read_count,
        COUNT(DISTINCT s15.record_id) as write_count,
        COUNT(DISTINCT s64.record_id) as vsam_close_count,
        -- Compression
        AVG(CASE WHEN s15.compressed_dataset_size > 0 
            THEN (s15.compressed_dataset_size * 1.0 / NULLIF(s15.tracks_allocated * 56 * 1024, 0))
            ELSE 1.0 END) as avg_compression_ratio
    FROM (
        SELECT DISTINCT dataset_name FROM smf14_records
        UNION
        SELECT DISTINCT dataset_name FROM smf15_records
        UNION
        SELECT DISTINCT component_name FROM smf64_records
    ) datasets
    LEFT JOIN smf14_records s14 ON datasets.dataset_name = s14.dataset_name
    LEFT JOIN smf15_records s15 ON datasets.dataset_name = s15.dataset_name
    LEFT JOIN smf64_records s64 ON datasets.dataset_name = s64.component_name
    JOIN smf_records r ON (s14.record_id = r.record_id 
                           OR s15.record_id = r.record_id 
                           OR s64.record_id = r.record_id)
    WHERE r.record_date >= DATE('now', '-365 days')
    GROUP BY datasets.dataset_name
)
SELECT 
    dm.dataset_name,
    ids.dataset_type,
    -- Current size
    COALESCE(ids.size_mb, dm.max_size_mb_type14, dm.avg_allocated_mb_type15, dm.avg_vsam_size_mb) as current_size_mb,
    -- Projected size with compression
    COALESCE(ids.size_mb, dm.max_size_mb_type14, dm.avg_allocated_mb_type15, dm.avg_vsam_size_mb) 
        * COALESCE(dm.avg_compression_ratio, 1.0) as compressed_size_mb,
    -- Access pattern
    dm.read_count,
    dm.write_count,
    dm.vsam_close_count,
    -- Storage recommendation
    CASE 
        WHEN dm.read_count > dm.write_count * 10 THEN 'EBS_GP3'  -- Read-heavy
        WHEN dm.write_count > dm.read_count * 10 THEN 'EBS_IO2'  -- Write-heavy
        WHEN dm.vsam_close_count > 0 THEN 'EBS_IO2'  -- VSAM needs high IOPS
        ELSE 'EBS_GP3'  -- General purpose
    END as recommended_storage_type
FROM dataset_metrics dm
LEFT JOIN inventory_datasets ids ON dm.dataset_name = ids.dataset_name
ORDER BY current_size_mb DESC;
```

**AWS Sizing Calculation**:
```python
# Total storage required
total_storage_gb = sum(compressed_size_mb) / 1024

# Add 30% growth headroom
recommended_storage_gb = total_storage_gb * 1.3

# Calculate by storage type
ebs_gp3_gb = sum(compressed_size_mb where recommended_storage_type = 'EBS_GP3') / 1024 * 1.3
ebs_io2_gb = sum(compressed_size_mb where recommended_storage_type = 'EBS_IO2') / 1024 * 1.3

# EFS for shared datasets (accessed by multiple jobs/programs)
efs_gb = sum(compressed_size_mb where access_count > 10) / 1024 * 1.3
```

**Migration Impact**: Determines EBS volume sizes and types, EFS capacity.


### 2.3 IOPS Requirements

#### 2.3.1 Dataset IOPS Analysis

**Purpose**: Calculate IOPS requirements for datasets based on I/O activity.

**SMF Record Types Used**: Types 14, 15, 64

**SQL Query**:
```sql
WITH iops_metrics AS (
    SELECT 
        dataset_name,
        -- Type 14 (INPUT) IOPS
        SUM(s14.excp_count) as total_read_ios,
        AVG(s14.excp_count / NULLIF(s14.connect_time_seconds, 0)) as avg_read_iops,
        MAX(s14.excp_count / NULLIF(s14.connect_time_seconds, 0)) as peak_read_iops,
        -- Type 15 (OUTPUT) IOPS
        SUM(s15.excp_count) as total_write_ios,
        AVG(s15.excp_count / NULLIF(s15.connect_time_seconds, 0)) as avg_write_iops,
        MAX(s15.excp_count / NULLIF(s15.connect_time_seconds, 0)) as peak_write_iops,
        -- Type 64 (VSAM) IOPS
        SUM(s64.total_requests) as total_vsam_requests,
        AVG(s64.total_requests / NULLIF(s64.open_time_seconds, 0)) as avg_vsam_iops,
        MAX(s64.total_requests / NULLIF(s64.open_time_seconds, 0)) as peak_vsam_iops,
        -- Block sizes
        AVG(s14.block_size) as avg_block_size_read,
        AVG(s15.block_size) as avg_block_size_write,
        -- Time window
        COUNT(DISTINCT DATE(r.record_date)) as days_active
    FROM (
        SELECT DISTINCT dataset_name FROM smf14_records
        UNION
        SELECT DISTINCT dataset_name FROM smf15_records
        UNION
        SELECT DISTINCT component_name FROM smf64_records
    ) datasets
    LEFT JOIN smf14_records s14 ON datasets.dataset_name = s14.dataset_name
    LEFT JOIN smf15_records s15 ON datasets.dataset_name = s15.dataset_name
    LEFT JOIN smf64_records s64 ON datasets.dataset_name = s64.component_name
    JOIN smf_records r ON (s14.record_id = r.record_id 
                           OR s15.record_id = r.record_id 
                           OR s64.record_id = r.record_id)
    WHERE r.record_date >= DATE('now', '-365 days')
    GROUP BY datasets.dataset_name
)
SELECT 
    dataset_name,
    -- Total IOPS
    COALESCE(avg_read_iops, 0) + COALESCE(avg_write_iops, 0) + COALESCE(avg_vsam_iops, 0) as avg_total_iops,
    COALESCE(peak_read_iops, 0) + COALESCE(peak_write_iops, 0) + COALESCE(peak_vsam_iops, 0) as peak_total_iops,
    -- Read/Write breakdown
    avg_read_iops,
    avg_write_iops,
    avg_vsam_iops,
    peak_read_iops,
    peak_write_iops,
    peak_vsam_iops,
    -- Throughput (MB/s)
    (COALESCE(avg_read_iops, 0) * COALESCE(avg_block_size_read, 4096) / 1024.0 / 1024.0) as avg_read_throughput_mbps,
    (COALESCE(avg_write_iops, 0) * COALESCE(avg_block_size_write, 4096) / 1024.0 / 1024.0) as avg_write_throughput_mbps,
    -- Storage recommendation
    CASE 
        WHEN COALESCE(peak_read_iops, 0) + COALESCE(peak_write_iops, 0) + COALESCE(peak_vsam_iops, 0) > 16000 
            THEN 'EBS_IO2_HIGH_IOPS'
        WHEN COALESCE(peak_read_iops, 0) + COALESCE(peak_write_iops, 0) + COALESCE(peak_vsam_iops, 0) > 3000 
            THEN 'EBS_IO2'
        ELSE 'EBS_GP3'
    END as recommended_storage_type,
    -- Recommended IOPS provisioning
    CAST((COALESCE(peak_read_iops, 0) + COALESCE(peak_write_iops, 0) + COALESCE(peak_vsam_iops, 0)) * 1.2 AS INTEGER) as recommended_iops
FROM iops_metrics
WHERE COALESCE(avg_read_iops, 0) + COALESCE(avg_write_iops, 0) + COALESCE(avg_vsam_iops, 0) > 0
ORDER BY peak_total_iops DESC;
```

**AWS Sizing Calculation**:
```python
# EBS GP3: 3,000 baseline IOPS (free), up to 16,000 IOPS
# EBS IO2: Up to 64,000 IOPS per volume

for dataset in datasets:
    if dataset.recommended_iops <= 3000:
        # Use GP3 baseline
        storage_type = "gp3"
        provisioned_iops = 3000
        additional_cost = 0
    elif dataset.recommended_iops <= 16000:
        # Use GP3 with additional IOPS
        storage_type = "gp3"
        provisioned_iops = dataset.recommended_iops
        additional_iops = dataset.recommended_iops - 3000
        additional_cost = additional_iops * 0.005  # $0.005 per IOPS-month
    else:
        # Use IO2
        storage_type = "io2"
        provisioned_iops = dataset.recommended_iops
        additional_cost = provisioned_iops * 0.065  # $0.065 per IOPS-month
```

**Migration Impact**: Determines EBS IOPS provisioning and storage type selection.


### 2.4 Network Bandwidth Requirements

#### 2.4.1 Data Transfer Analysis

**Purpose**: Calculate network bandwidth requirements based on data transfer volumes.

**SMF Record Types Used**: Types 14, 15

**SQL Query**:
```sql
WITH transfer_metrics AS (
    SELECT 
        DATE(r.record_date) as date,
        strftime('%H', r.record_date) as hour,
        -- Type 14 (INPUT) - data read
        SUM(s14.bytes_read / 1024.0 / 1024.0) as read_mb,
        -- Type 15 (OUTPUT) - data written
        SUM(s15.bytes_written / 1024.0 / 1024.0) as write_mb,
        -- Total transfer
        SUM(COALESCE(s14.bytes_read, 0) + COALESCE(s15.bytes_written, 0)) / 1024.0 / 1024.0 as total_mb
    FROM smf_records r
    LEFT JOIN smf14_records s14 ON r.record_id = s14.record_id
    LEFT JOIN smf15_records s15 ON r.record_id = s15.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
    GROUP BY DATE(r.record_date), strftime('%H', r.record_date)
)
SELECT 
    -- Daily metrics
    AVG(daily.total_mb) as avg_daily_transfer_mb,
    MAX(daily.total_mb) as peak_daily_transfer_mb,
    -- Hourly metrics
    AVG(total_mb) as avg_hourly_transfer_mb,
    MAX(total_mb) as peak_hourly_transfer_mb,
    -- Bandwidth calculation (MB/hour to Mbps)
    AVG(total_mb * 8 / 3600.0) as avg_bandwidth_mbps,
    MAX(total_mb * 8 / 3600.0) as peak_bandwidth_mbps,
    -- Read/Write breakdown
    AVG(read_mb) as avg_hourly_read_mb,
    AVG(write_mb) as avg_hourly_write_mb,
    MAX(read_mb) as peak_hourly_read_mb,
    MAX(write_mb) as peak_hourly_write_mb
FROM transfer_metrics
LEFT JOIN (
    SELECT 
        date,
        SUM(total_mb) as total_mb
    FROM transfer_metrics
    GROUP BY date
) daily ON transfer_metrics.date = daily.date;
```

**AWS Sizing Calculation**:
```python
# Convert to required network bandwidth
# Add 50% headroom for peaks and protocol overhead
required_bandwidth_mbps = peak_bandwidth_mbps * 1.5

# Map to AWS network performance tiers
if required_bandwidth_mbps <= 1250:  # 10 Gbps
    network_tier = "Up to 10 Gbps"
    instance_types = ["c6i.2xlarge", "m6i.2xlarge"]
elif required_bandwidth_mbps <= 2500:  # 20 Gbps
    network_tier = "Up to 20 Gbps"
    instance_types = ["c6i.4xlarge", "m6i.4xlarge"]
elif required_bandwidth_mbps <= 6250:  # 50 Gbps
    network_tier = "Up to 50 Gbps"
    instance_types = ["c6i.8xlarge", "m6i.8xlarge"]
else:  # 100 Gbps
    network_tier = "Up to 100 Gbps"
    instance_types = ["c6i.16xlarge", "m6i.16xlarge"]

# Calculate data transfer costs
# Intra-region: Free
# Inter-region: $0.02 per GB
# Internet egress: $0.09 per GB (first 10 TB)
monthly_transfer_gb = avg_daily_transfer_mb * 30 / 1024
```

**Migration Impact**: Determines network bandwidth requirements and data transfer costs.


### 2.5 RDS Database Sizing

#### 2.5.1 DB2 Workload Analysis

**Purpose**: Calculate RDS requirements for DB2 workloads based on SMF Types 100, 101.

**SMF Record Types Used**: Types 100, 101

**SQL Query**:
```sql
WITH db2_metrics AS (
    SELECT 
        s101.connection_id,
        s101.plan_name,
        s101.program_name,
        -- CPU metrics
        AVG(s101.cpu_time_seconds) as avg_cpu_seconds,
        SUM(s101.cpu_time_seconds) as total_cpu_seconds,
        -- I/O metrics
        AVG(s101.getpage_requests) as avg_getpage,
        SUM(s101.getpage_requests) as total_getpage,
        AVG(s101.buffer_pool_reads) as avg_bp_reads,
        SUM(s101.buffer_pool_reads) as total_bp_reads,
        -- Lock metrics
        AVG(s101.lock_requests) as avg_locks,
        AVG(s101.lock_wait_time_seconds) as avg_lock_wait_seconds,
        -- Transaction metrics
        COUNT(*) as transaction_count,
        AVG(s101.elapsed_time_seconds) as avg_elapsed_seconds,
        -- Execution pattern
        COUNT(DISTINCT DATE(r.record_date)) as days_active
    FROM smf101_accounting s101
    JOIN smf_records r ON s101.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s101.plan_name IS NOT NULL
    GROUP BY s101.connection_id, s101.plan_name, s101.program_name
),
db2_storage AS (
    SELECT 
        s100.database_name,
        s100.tablespace_name,
        -- Storage metrics
        AVG(s100.total_pages * 4 / 1024.0) as avg_size_mb,
        MAX(s100.total_pages * 4 / 1024.0) as max_size_mb,
        AVG(s100.used_pages * 4 / 1024.0) as avg_used_mb,
        -- Activity metrics
        AVG(s100.getpage_requests) as avg_getpage,
        AVG(s100.buffer_pool_hit_ratio) as avg_hit_ratio
    FROM smf100_statistics s100
    JOIN smf_records r ON s100.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
    GROUP BY s100.database_name, s100.tablespace_name
)
SELECT 
    -- Workload summary
    COUNT(DISTINCT dm.plan_name) as unique_plans,
    COUNT(DISTINCT dm.program_name) as unique_programs,
    SUM(dm.transaction_count) as total_transactions,
    AVG(dm.transaction_count / NULLIF(dm.days_active, 0)) as avg_daily_transactions,
    -- CPU requirements
    SUM(dm.total_cpu_seconds) as total_cpu_seconds,
    AVG(dm.avg_cpu_seconds) as avg_cpu_per_transaction,
    -- I/O requirements
    SUM(dm.total_getpage) as total_getpage_requests,
    AVG(dm.avg_getpage) as avg_getpage_per_transaction,
    SUM(dm.total_bp_reads) as total_buffer_pool_reads,
    -- Storage requirements
    SUM(ds.max_size_mb) as total_storage_mb,
    AVG(ds.avg_hit_ratio) as avg_buffer_pool_hit_ratio,
    -- Performance metrics
    AVG(dm.avg_elapsed_seconds) as avg_transaction_time,
    AVG(dm.avg_lock_wait_seconds) as avg_lock_wait_time
FROM db2_metrics dm
CROSS JOIN db2_storage ds;
```

**AWS RDS Sizing Calculation**:
```python
# Calculate vCPU requirements
# DB2 CPU to RDS vCPU conversion (conservative)
rds_vcpu_seconds = total_cpu_seconds * 0.6
avg_vcpu_required = rds_vcpu_seconds / (days_active * 86400)

# Add 40% headroom for database overhead
recommended_vcpu = avg_vcpu_required * 1.4

# Calculate memory requirements
# Rule of thumb: 4 GB RAM per vCPU for databases
recommended_memory_gb = recommended_vcpu * 4

# Buffer pool sizing (based on hit ratio)
if avg_buffer_pool_hit_ratio < 0.90:
    # Low hit ratio - need more memory
    recommended_memory_gb *= 1.5

# Calculate storage requirements
total_storage_gb = total_storage_mb / 1024
# Add 50% growth headroom
recommended_storage_gb = total_storage_gb * 1.5

# Calculate IOPS requirements
# Assume 100 IOPS per 1000 getpage requests per second
avg_getpage_per_second = total_getpage_requests / (days_active * 86400)
recommended_iops = (avg_getpage_per_second / 1000) * 100 * 1.2

# Map to RDS instance types (PostgreSQL as DB2 alternative)
if recommended_vcpu <= 2 and recommended_memory_gb <= 8:
    instance_type = "db.m6i.large"  # 2 vCPU, 8 GB
elif recommended_vcpu <= 4 and recommended_memory_gb <= 16:
    instance_type = "db.m6i.xlarge"  # 4 vCPU, 16 GB
elif recommended_vcpu <= 8 and recommended_memory_gb <= 32:
    instance_type = "db.m6i.2xlarge"  # 8 vCPU, 32 GB
elif recommended_vcpu <= 16 and recommended_memory_gb <= 64:
    instance_type = "db.m6i.4xlarge"  # 16 vCPU, 64 GB
else:
    instance_type = "db.m6i.8xlarge"  # 32 vCPU, 128 GB
```

**Migration Impact**: Determines RDS instance type, storage, and IOPS for DB2 migration.


#### 2.5.2 VSAM to RDS/DynamoDB Sizing

**Purpose**: Calculate database requirements for VSAM datasets migrating to RDS or DynamoDB.

**SMF Record Types Used**: Types 62, 64

**SQL Query**:
```sql
WITH vsam_metrics AS (
    SELECT 
        s64.component_name,
        s64.cluster_name,
        -- Size metrics
        AVG(s64.ci_size * s64.ca_size / 1024.0 / 1024.0) as avg_size_mb,
        MAX(s64.ci_size * s64.ca_size / 1024.0 / 1024.0) as max_size_mb,
        -- I/O metrics
        SUM(s64.total_requests) as total_requests,
        AVG(s64.total_requests / NULLIF(s64.open_time_seconds, 0)) as avg_iops,
        MAX(s64.total_requests / NULLIF(s64.open_time_seconds, 0)) as peak_iops,
        -- Access pattern
        SUM(s64.get_requests) as total_reads,
        SUM(s64.put_requests) as total_writes,
        SUM(s64.browse_requests) as total_scans,
        -- Record metrics
        AVG(s64.total_logical_records) as avg_record_count,
        AVG(s64.ci_size) as avg_record_size,
        -- Performance
        AVG(s64.string_requests / NULLIF(s64.total_requests, 0)) as avg_string_ratio,
        -- Activity
        COUNT(*) as close_count,
        COUNT(DISTINCT DATE(r.record_date)) as days_active
    FROM smf64_records s64
    JOIN smf_records r ON s64.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND s64.component_name IS NOT NULL
    GROUP BY s64.component_name, s64.cluster_name
)
SELECT 
    component_name,
    cluster_name,
    -- Storage
    max_size_mb,
    avg_record_count,
    avg_record_size,
    -- Access pattern
    total_reads,
    total_writes,
    total_scans,
    ROUND(total_reads * 100.0 / NULLIF(total_reads + total_writes, 0), 2) as read_percentage,
    -- IOPS
    avg_iops,
    peak_iops,
    -- Database recommendation
    CASE 
        WHEN total_scans > (total_reads + total_writes) * 0.5 THEN 'RDS'  -- Scan-heavy
        WHEN avg_record_size > 400 THEN 'RDS'  -- Large records
        WHEN total_reads > total_writes * 10 THEN 'DynamoDB'  -- Read-heavy key-value
        WHEN peak_iops > 10000 THEN 'DynamoDB'  -- High throughput
        ELSE 'RDS'  -- Default to RDS for complex queries
    END as recommended_database,
    -- Sizing
    CAST(max_size_mb * 1.5 AS INTEGER) as recommended_storage_mb,
    CAST(peak_iops * 1.2 AS INTEGER) as recommended_iops
FROM vsam_metrics
ORDER BY max_size_mb DESC;
```

**AWS Sizing Calculation**:

For **RDS** (relational model):
```python
# Storage
total_storage_gb = sum(recommended_storage_mb) / 1024

# IOPS
total_iops = sum(recommended_iops)

# Instance sizing (similar to DB2 calculation)
# Assume 1 vCPU per 1000 IOPS
recommended_vcpu = total_iops / 1000
recommended_memory_gb = recommended_vcpu * 4

# Map to RDS instance type
if recommended_vcpu <= 2:
    instance_type = "db.m6i.large"
elif recommended_vcpu <= 4:
    instance_type = "db.m6i.xlarge"
else:
    instance_type = "db.m6i.2xlarge"
```

For **DynamoDB** (key-value model):
```python
# Calculate read/write capacity units
# 1 RCU = 1 strongly consistent read/sec (up to 4 KB)
# 1 WCU = 1 write/sec (up to 1 KB)

for dataset in vsam_datasets:
    # Read capacity
    reads_per_second = dataset.total_reads / (dataset.days_active * 86400)
    read_size_kb = dataset.avg_record_size / 1024
    rcu_per_read = math.ceil(read_size_kb / 4)
    required_rcu = reads_per_second * rcu_per_read * 1.2  # 20% headroom
    
    # Write capacity
    writes_per_second = dataset.total_writes / (dataset.days_active * 86400)
    write_size_kb = dataset.avg_record_size / 1024
    wcu_per_write = math.ceil(write_size_kb / 1)
    required_wcu = writes_per_second * wcu_per_write * 1.2
    
    # Storage
    storage_gb = dataset.max_size_mb / 1024 * 1.5
    
    # Cost calculation
    # On-demand: $1.25 per million write requests, $0.25 per million read requests
    # Provisioned: $0.00065 per WCU-hour, $0.00013 per RCU-hour
    monthly_cost_provisioned = (required_wcu * 0.00065 + required_rcu * 0.00013) * 730
    monthly_cost_storage = storage_gb * 0.25
```

**Migration Impact**: Determines database type (RDS vs DynamoDB) and sizing for VSAM datasets.

---


## 3. Cost Analysis Queries

These queries estimate mainframe costs and AWS migration costs for ROI analysis.

### 3.1 Mainframe Cost Estimation

#### 3.1.1 MIPS-Based Cost Calculation

**Purpose**: Estimate mainframe costs based on MIPS consumption.

**SMF Record Types Used**: Type 30

**SQL Query**:
```sql
WITH mips_calculation AS (
    SELECT 
        i.job_name,
        i.program_name,
        -- Service units to MIPS conversion
        -- Typical: 1 MIPS ≈ 3,600,000 service units per hour
        SUM(p.service_units) / 3600000.0 as total_mips_hours,
        AVG(p.service_units) / 3600000.0 as avg_mips_per_execution,
        COUNT(*) as execution_count,
        COUNT(DISTINCT DATE(r.record_date)) as days_active
    FROM smf30_identification i
    JOIN smf30_processor p ON i.record_id = p.record_id
    JOIN smf_records r ON i.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
        AND i.job_name IS NOT NULL
    GROUP BY i.job_name, i.program_name
)
SELECT 
    -- Total MIPS consumption
    SUM(total_mips_hours) as total_mips_hours_annual,
    SUM(total_mips_hours) / 8760.0 as avg_mips_continuous,
    MAX(total_mips_hours / NULLIF(days_active, 0) * 365) as peak_mips_annual,
    -- Cost estimation
    -- Typical mainframe cost: $3,000 - $5,000 per MIPS per month
    SUM(total_mips_hours) / 8760.0 * 4000 * 12 as estimated_annual_cost_mid,
    SUM(total_mips_hours) / 8760.0 * 3000 * 12 as estimated_annual_cost_low,
    SUM(total_mips_hours) / 8760.0 * 5000 * 12 as estimated_annual_cost_high,
    -- Breakdown by workload
    COUNT(DISTINCT job_name) as unique_jobs,
    SUM(execution_count) as total_executions
FROM mips_calculation;
```

**Cost Calculation**:
```python
# Mainframe cost components
mips_cost_per_month = avg_mips_continuous * 4000  # $4,000 per MIPS/month (typical)
software_cost_per_month = mips_cost_per_month * 0.6  # Software ~60% of total
hardware_cost_per_month = mips_cost_per_month * 0.25  # Hardware ~25%
support_cost_per_month = mips_cost_per_month * 0.15  # Support ~15%

total_mainframe_cost_annual = (mips_cost_per_month + software_cost_per_month + 
                                hardware_cost_per_month + support_cost_per_month) * 12
```

**Migration Impact**: Establishes baseline mainframe costs for ROI calculation.


#### 3.1.2 MSU-Based Cost Calculation

**Purpose**: Estimate mainframe costs based on MSU (Million Service Units) consumption.

**SMF Record Types Used**: Type 30

**SQL Query**:
```sql
WITH msu_calculation AS (
    SELECT 
        DATE(r.record_date) as date,
        strftime('%H', r.record_date) as hour,
        -- Service units aggregation
        SUM(p.service_units) / 1000000.0 as msu_consumed,
        -- Peak calculation (4-hour rolling window)
        SUM(p.service_units) OVER (
            ORDER BY r.record_date 
            ROWS BETWEEN 3 PRECEDING AND CURRENT ROW
        ) / 1000000.0 as msu_4hour_window
    FROM smf30_processor p
    JOIN smf_records r ON p.record_id = r.record_id
    WHERE r.record_date >= DATE('now', '-365 days')
    GROUP BY DATE(r.record_date), strftime('%H', r.record_date)
)
SELECT 
    -- Average MSU consumption
    AVG(msu_consumed) as avg_hourly_msu,
    AVG(msu_consumed) * 24 as avg_daily_msu,
    AVG(msu_consumed) * 24 * 365 as avg_annual_msu,
    -- Peak MSU (4-hour rolling window - IBM pricing model)
    MAX(msu_4hour_window) as peak_4hour_msu,
    AVG(msu_4hour_window) as avg_4hour_msu,
    -- Cost estimation
    -- Typical MSU cost: $2,000 - $4,000 per MSU per month (based on peak)
    MAX(msu_4hour_window) * 3000 * 12 as estimated_annual_cost_mid,
    MAX(msu_4hour_window) * 2000 * 12 as estimated_annual_cost_low,
    MAX(msu_4hour_window) * 4000 * 12 as estimated_annual_cost_high
FROM msu_calculation;
```

**Cost Calculation**:
```python
# MSU-based pricing (IBM z/OS)
# Pricing is based on peak 4-hour rolling window
peak_msu = max(msu_4hour_window)

# Tiered pricing (example)
if peak_msu <= 3:
    cost_per_msu = 4000
elif peak_msu <= 10:
    cost_per_msu = 3500
elif peak_msu <= 50:
    cost_per_msu = 3000
else:
    cost_per_msu = 2500

monthly_msu_cost = peak_msu * cost_per_msu
annual_msu_cost = monthly_msu_cost * 12

# Add software costs (CICS, DB2, etc.)
software_multiplier = 1.8  # Software typically 80% more than hardware
total_annual_cost = annual_msu_cost * software_multiplier
```

**Migration Impact**: Establishes baseline mainframe costs using MSU pricing model.

### 3.2 AWS Cost Estimation

#### 3.2.1 Comprehensive AWS Cost Calculation

**Purpose**: Estimate total AWS costs for migrated workloads.

**SMF Record Types Used**: Types 14, 15, 30, 64, 100, 101, 110

**SQL Query** (combines multiple queries from Section 2):
```sql
-- This is a conceptual query combining infrastructure sizing results
WITH compute_costs AS (
    -- From query 2.1.1 and 2.1.2
    SELECT 
        'EC2_Batch' as service,
        SUM(recommended_vcpu) as total_vcpu,
        SUM(recommended_memory_gb) as total_memory_gb,
        'c6i.xlarge' as instance_type,
        COUNT(*) as instance_count
    FROM batch_sizing_results
    UNION ALL
    SELECT 
        'EC2_CICS' as service,
        SUM(recommended_vcpu) as total_vcpu,
        SUM(recommended_memory_gb) as total_memory_gb,
        'c6i.2xlarge' as instance_type,
        COUNT(*) as instance_count
    FROM cics_sizing_results
),
storage_costs AS (
    -- From query 2.2.1
    SELECT 
        'EBS_GP3' as service,
        SUM(recommended_storage_gb) as total_gb,
        SUM(recommended_iops) as total_iops
    FROM dataset_storage_results
    WHERE recommended_storage_type = 'EBS_GP3'
    UNION ALL
    SELECT 
        'EBS_IO2' as service,
        SUM(recommended_storage_gb) as total_gb,
        SUM(recommended_iops) as total_iops
    FROM dataset_storage_results
    WHERE recommended_storage_type = 'EBS_IO2'
),
database_costs AS (
    -- From query 2.5.1 and 2.5.2
    SELECT 
        'RDS_PostgreSQL' as service,
        instance_type,
        storage_gb,
        provisioned_iops
    FROM rds_sizing_results
),
network_costs AS (
    -- From query 2.4.1
    SELECT 
        'Data_Transfer' as service,
        monthly_transfer_gb
    FROM network_sizing_results
)
SELECT 
    service,
    -- Cost calculations would be done in application layer
    -- This query provides the sizing data needed for cost calculation
    *
FROM (
    SELECT * FROM compute_costs
    UNION ALL
    SELECT * FROM storage_costs
    UNION ALL
    SELECT * FROM database_costs
    UNION ALL
    SELECT * FROM network_costs
);
```

**AWS Cost Calculation** (Python):
```python
# EC2 Compute Costs (us-east-1 pricing, On-Demand)
ec2_pricing = {
    'c6i.large': 0.085,      # per hour
    'c6i.xlarge': 0.17,
    'c6i.2xlarge': 0.34,
    'c6i.4xlarge': 0.68,
    'c6i.8xlarge': 1.36,
}

monthly_ec2_cost = 0
for instance in ec2_instances:
    hourly_cost = ec2_pricing[instance.type]
    monthly_cost = hourly_cost * 730  # hours per month
    monthly_ec2_cost += monthly_cost * instance.count

# EBS Storage Costs
ebs_gp3_storage_cost = ebs_gp3_gb * 0.08  # $0.08 per GB-month
ebs_gp3_iops_cost = max(0, (ebs_gp3_iops - 3000)) * 0.005  # $0.005 per IOPS-month above 3000
ebs_io2_storage_cost = ebs_io2_gb * 0.125  # $0.125 per GB-month
ebs_io2_iops_cost = ebs_io2_iops * 0.065  # $0.065 per IOPS-month

monthly_ebs_cost = (ebs_gp3_storage_cost + ebs_gp3_iops_cost + 
                    ebs_io2_storage_cost + ebs_io2_iops_cost)

# RDS Costs
rds_pricing = {
    'db.m6i.large': 0.192,    # per hour
    'db.m6i.xlarge': 0.384,
    'db.m6i.2xlarge': 0.768,
    'db.m6i.4xlarge': 1.536,
}

monthly_rds_cost = 0
for instance in rds_instances:
    hourly_cost = rds_pricing[instance.type]
    monthly_cost = hourly_cost * 730
    storage_cost = instance.storage_gb * 0.115  # $0.115 per GB-month (gp3)
    iops_cost = max(0, (instance.iops - 3000)) * 0.20  # $0.20 per IOPS-month above 3000
    monthly_rds_cost += monthly_cost + storage_cost + iops_cost

# Data Transfer Costs
# First 10 TB: $0.09 per GB
# Next 40 TB: $0.085 per GB
# Over 150 TB: $0.05 per GB
monthly_transfer_cost = calculate_tiered_transfer_cost(monthly_transfer_gb)

# Total AWS Cost
monthly_aws_cost = (monthly_ec2_cost + monthly_ebs_cost + 
                    monthly_rds_cost + monthly_transfer_cost)
annual_aws_cost = monthly_aws_cost * 12

# Add 15% for AWS support (Business tier)
annual_aws_cost_with_support = annual_aws_cost * 1.15
```

**Migration Impact**: Provides total AWS cost estimate for ROI analysis.


### 3.3 ROI Analysis

#### 3.3.1 Migration ROI Calculation

**Purpose**: Calculate return on investment for mainframe-to-AWS migration.

**Cost Components**:

```python
# Migration Costs (One-time)
migration_costs = {
    'assessment': 50000,  # Initial assessment and planning
    'code_conversion': len(programs) * 500,  # $500 per program
    'data_migration': total_storage_gb * 10,  # $10 per GB
    'testing': 100000,  # Testing and validation
    'training': 50000,  # Staff training
    'contingency': 0.20  # 20% contingency
}

total_migration_cost = sum(migration_costs.values()) * (1 + migration_costs['contingency'])

# Annual Operating Costs
mainframe_annual_cost = msu_annual_cost  # From query 3.1.2
aws_annual_cost = annual_aws_cost_with_support  # From query 3.2.1

# Annual Savings
annual_savings = mainframe_annual_cost - aws_annual_cost

# ROI Calculation
roi_years = total_migration_cost / annual_savings
roi_percentage = (annual_savings * 5 - total_migration_cost) / total_migration_cost * 100

# 5-year TCO comparison
mainframe_5year_tco = mainframe_annual_cost * 5
aws_5year_tco = total_migration_cost + (aws_annual_cost * 5)
total_5year_savings = mainframe_5year_tco - aws_5year_tco

print(f"Migration Cost: ${total_migration_cost:,.0f}")
print(f"Annual Savings: ${annual_savings:,.0f}")
print(f"Payback Period: {roi_years:.1f} years")
print(f"5-Year ROI: {roi_percentage:.1f}%")
print(f"5-Year Total Savings: ${total_5year_savings:,.0f}")
```

**SQL Query for Migration Complexity**:
```sql
WITH complexity_metrics AS (
    SELECT 
        COUNT(DISTINCT ip.program_name) as total_programs,
        SUM(ip.size_bytes) / 1024.0 / 1024.0 as total_program_size_mb,
        COUNT(DISTINCT ij.member_name) as total_jcl,
        COUNT(DISTINCT ids.dataset_name) as total_datasets,
        SUM(ids.size_mb) as total_dataset_size_mb,
        COUNT(DISTINCT ic.copybook_name) as total_copybooks,
        -- Complexity factors
        COUNT(DISTINCT CASE WHEN ad.dependency_type = 'CICS_LINK' THEN ad.source_artifact_name END) as cics_programs,
        COUNT(DISTINCT CASE WHEN ad.dependency_type = 'CALL' THEN ad.source_artifact_name END) as programs_with_calls,
        -- From static analysis
        AVG(cm.cyclomatic_complexity) as avg_complexity,
        SUM(CASE WHEN cm.cyclomatic_complexity > 50 THEN 1 ELSE 0 END) as high_complexity_programs
    FROM inventory_programs ip
    LEFT JOIN inventory_jcl ij ON 1=1
    LEFT JOIN inventory_datasets ids ON 1=1
    LEFT JOIN inventory_copybooks ic ON 1=1
    LEFT JOIN artifact_dependencies ad ON ip.program_name = ad.source_artifact_name
    LEFT JOIN complexity_metrics cm ON ip.program_name = cm.artifact_name
)
SELECT 
    total_programs,
    total_jcl,
    total_datasets,
    total_copybooks,
    cics_programs,
    programs_with_calls,
    avg_complexity,
    high_complexity_programs,
    -- Complexity score (0-100)
    CAST(
        (cics_programs * 1.0 / NULLIF(total_programs, 0) * 30) +
        (programs_with_calls * 1.0 / NULLIF(total_programs, 0) * 20) +
        (high_complexity_programs * 1.0 / NULLIF(total_programs, 0) * 30) +
        (CASE WHEN avg_complexity > 20 THEN 20 ELSE avg_complexity END)
    AS INTEGER) as complexity_score,
    -- Estimated conversion effort (person-months)
    CAST(
        (total_programs * 0.5) +  -- 0.5 PM per program
        (cics_programs * 1.0) +   -- Additional 1 PM per CICS program
        (high_complexity_programs * 2.0) +  -- Additional 2 PM per complex program
        (total_jcl * 0.1) +  -- 0.1 PM per JCL
        (total_datasets * 0.05)  -- 0.05 PM per dataset
    AS INTEGER) as estimated_effort_person_months
FROM complexity_metrics;
```

**Migration Impact**: Provides ROI justification and effort estimation for migration project.

---

## 4. Migration Planning Queries

These queries help prioritize workloads and plan migration waves.

### 4.1 Workload Prioritization

**Purpose**: Rank workloads by migration priority based on multiple factors.

**SMF Record Types Used**: Types 30, 110

**SQL Query**:
```sql
WITH workload_metrics AS (
    SELECT 
        i.job_name,
        i.program_name,
        -- Usage metrics
        COUNT(*) as execution_count,
        COUNT(DISTINCT DATE(r.record_date)) as days_active,
        MIN(r.record_date) as first_seen,
        MAX(r.record_date) as last_seen,
        -- Resource consumption
        SUM(p.cpu_time_seconds) as total_cpu_seconds,
        SUM(p.service_units) as total_service_units,
        AVG(s.region_size_kb / 1024.0) as avg_memory_mb,
        -- Complexity (from static analysis)
        MAX(cm.cyclomatic_complexity) as complexity,
        MAX(cm.lines_of_code) as loc,
        -- Dependencies
        COUNT(DISTINCT ad.target_artifact_name) as dependency_count,
        -- Business criticality (from completion codes)
        SUM(CASE WHEN c.completion_code != '0000' THEN 1 ELSE 0 END) as failure_count,
        AVG(CASE WHEN c.completion_code != '0000' THEN 1 ELSE 0 END) as failure_rate
    FROM smf30_identification i
    JOIN smf30_processor p ON i.record_id = p.record_id
    JOIN smf30_storage s ON i.record_id = s.record_id
    JOIN smf30_completion c ON i.record_id = c.record_id
    JOIN smf_records r ON i.record_id = r.record_id
    LEFT JOIN complexity_metrics cm ON i.program_name = cm.artifact_name
    LEFT JOIN artifact_dependencies ad ON i.program_name = ad.source_artifact_name
    WHERE r.record_date >= DATE('now', '-365 days')
        AND i.job_name IS NOT NULL
    GROUP BY i.job_name, i.program_name
)
SELECT 
    job_name,
    program_name,
    execution_count,
    days_active,
    total_cpu_seconds,
    complexity,
    dependency_count,
    failure_rate,
    -- Priority scoring (0-100)
    CAST(
        -- High usage = higher priority (30 points)
        (CASE 
            WHEN execution_count > 1000 THEN 30
            WHEN execution_count > 100 THEN 20
            WHEN execution_count > 10 THEN 10
            ELSE 5
        END) +
        -- Low complexity = higher priority (25 points)
        (CASE 
            WHEN complexity < 10 THEN 25
            WHEN complexity < 20 THEN 15
            WHEN complexity < 50 THEN 5
            ELSE 0
        END) +
        -- Low dependencies = higher priority (20 points)
        (CASE 
            WHEN dependency_count < 5 THEN 20
            WHEN dependency_count < 10 THEN 10
            ELSE 5
        END) +
        -- High resource consumption = higher priority (15 points)
        (CASE 
            WHEN total_cpu_seconds > 10000 THEN 15
            WHEN total_cpu_seconds > 1000 THEN 10
            ELSE 5
        END) +
        -- Low failure rate = higher priority (10 points)
        (CASE 
            WHEN failure_rate < 0.01 THEN 10
            WHEN failure_rate < 0.05 THEN 5
            ELSE 0
        END)
    AS INTEGER) as migration_priority_score,
    -- Migration wave recommendation
    CASE 
        WHEN migration_priority_score >= 80 THEN 'Wave 1 - Quick Wins'
        WHEN migration_priority_score >= 60 THEN 'Wave 2 - Standard'
        WHEN migration_priority_score >= 40 THEN 'Wave 3 - Complex'
        ELSE 'Wave 4 - Deferred'
    END as recommended_wave
FROM workload_metrics
ORDER BY migration_priority_score DESC;
```

**Migration Impact**: Prioritizes workloads for phased migration approach.


### 4.2 Dependency Analysis for Migration Waves

**Purpose**: Identify dependency chains to ensure proper migration sequencing.

**SQL Query**:
```sql
WITH RECURSIVE dependency_tree AS (
    -- Base case: programs with no dependencies (leaf nodes)
    SELECT 
        ip.program_name,
        0 as dependency_depth,
        ip.program_name as dependency_path,
        0 as total_dependencies
    FROM inventory_programs ip
    LEFT JOIN artifact_dependencies ad 
        ON ip.program_name = ad.source_artifact_name
    WHERE ad.source_artifact_name IS NULL
    
    UNION ALL
    
    -- Recursive case: programs that depend on leaf nodes
    SELECT 
        ad.source_artifact_name as program_name,
        dt.dependency_depth + 1,
        ad.source_artifact_name || ' -> ' || dt.dependency_path,
        dt.total_dependencies + 1
    FROM artifact_dependencies ad
    JOIN dependency_tree dt 
        ON ad.target_artifact_name = dt.program_name
    WHERE dt.dependency_depth < 10  -- Prevent infinite loops
        AND dt.dependency_path NOT LIKE '%' || ad.source_artifact_name || '%'  -- Prevent circular
)
SELECT 
    program_name,
    MAX(dependency_depth) as max_dependency_depth,
    MAX(total_dependencies) as total_dependencies,
    -- Migration wave based on dependency depth
    CASE 
        WHEN MAX(dependency_depth) = 0 THEN 'Wave 1 - No Dependencies'
        WHEN MAX(dependency_depth) <= 2 THEN 'Wave 2 - Shallow Dependencies'
        WHEN MAX(dependency_depth) <= 5 THEN 'Wave 3 - Medium Dependencies'
        ELSE 'Wave 4 - Deep Dependencies'
    END as dependency_wave,
    -- Get sample dependency path
    (SELECT dependency_path 
     FROM dependency_tree dt2 
     WHERE dt2.program_name = dependency_tree.program_name 
     LIMIT 1) as sample_dependency_path
FROM dependency_tree
GROUP BY program_name
ORDER BY max_dependency_depth, program_name;
```

**Migration Impact**: Ensures dependencies are migrated before dependent programs.

### 4.3 Circular Dependency Detection

**Purpose**: Identify circular dependencies that require special handling during migration.

**SQL Query**:
```sql
WITH RECURSIVE dependency_paths AS (
    -- Start from each program
    SELECT 
        source_artifact_name as start_program,
        source_artifact_name,
        target_artifact_name,
        dependency_type,
        1 as depth,
        source_artifact_name || ' -> ' || target_artifact_name as path,
        CAST(source_artifact_name AS TEXT) as visited
    FROM artifact_dependencies
    WHERE source_artifact_type = 'PROGRAM'
        AND target_artifact_type = 'PROGRAM'
    
    UNION ALL
    
    -- Follow the dependency chain
    SELECT 
        dp.start_program,
        ad.source_artifact_name,
        ad.target_artifact_name,
        ad.dependency_type,
        dp.depth + 1,
        dp.path || ' -> ' || ad.target_artifact_name,
        dp.visited || ',' || ad.source_artifact_name
    FROM dependency_paths dp
    JOIN artifact_dependencies ad 
        ON dp.target_artifact_name = ad.source_artifact_name
    WHERE dp.depth < 20
        AND ad.source_artifact_type = 'PROGRAM'
        AND ad.target_artifact_type = 'PROGRAM'
        -- Detect circular dependency
        AND (ad.target_artifact_name = dp.start_program 
             OR dp.visited LIKE '%' || ad.target_artifact_name || '%')
)
SELECT DISTINCT
    start_program,
    path || ' -> ' || start_program as circular_path,
    depth as cycle_length,
    'CIRCULAR_DEPENDENCY' as issue_type,
    'Requires refactoring or special migration handling' as recommendation
FROM dependency_paths
WHERE target_artifact_name = start_program
ORDER BY cycle_length, start_program;
```

**Migration Impact**: Identifies programs requiring refactoring before migration.

---

## 5. Missing SMF Record Types

The following SMF record types are **not currently implemented** but would provide valuable additional insights for migration planning:

### 5.1 Type 70 - System Resources

**What it provides**: System-wide CPU, memory, and I/O utilization across all LPARs.

**Migration value**:
- Overall system capacity planning
- LPAR-to-AWS-account mapping
- Peak load analysis across entire mainframe
- Identify underutilized capacity

**Potential queries**:
```sql
-- System-wide CPU utilization
SELECT 
    DATE(record_date) as date,
    AVG(cpu_utilization_pct) as avg_cpu_pct,
    MAX(cpu_utilization_pct) as peak_cpu_pct,
    AVG(memory_utilization_pct) as avg_memory_pct
FROM smf70_system_resources
GROUP BY DATE(record_date);

-- LPAR resource distribution
SELECT 
    lpar_name,
    AVG(cpu_utilization_pct) as avg_cpu,
    AVG(memory_gb) as avg_memory_gb,
    SUM(msu_consumed) as total_msu
FROM smf70_lpar_resources
GROUP BY lpar_name;
```


### 5.2 Type 72 - Workload Manager (WLM)

**What it provides**: Workload classification, service class performance, and resource group usage.

**Migration value**:
- Identify business-critical workloads by service class
- Map WLM policies to AWS resource tagging and cost allocation
- Understand workload priorities for migration sequencing
- Performance SLA requirements

**Potential queries**:
```sql
-- Workload classification and performance
SELECT 
    service_class,
    workload_name,
    COUNT(*) as transaction_count,
    AVG(response_time_seconds) as avg_response_time,
    AVG(cpu_time_seconds) as avg_cpu_time,
    PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY response_time_seconds) as p95_response_time,
    -- Business priority
    CASE 
        WHEN service_class LIKE 'CRITICAL%' THEN 'HIGH'
        WHEN service_class LIKE 'PRODUCTION%' THEN 'MEDIUM'
        ELSE 'LOW'
    END as business_priority
FROM smf72_workload_activity
GROUP BY service_class, workload_name
ORDER BY business_priority, avg_response_time;

-- Resource group consumption
SELECT 
    resource_group,
    SUM(cpu_time_seconds) as total_cpu,
    SUM(service_units) as total_service_units,
    AVG(goal_achievement_pct) as avg_goal_achievement
FROM smf72_resource_groups
GROUP BY resource_group;
```

**AWS mapping**: Service classes → AWS resource tags for cost allocation and priority-based auto-scaling.

### 5.3 Type 74 - Device Activity

**What it provides**: Detailed storage device performance, response times, and queue depths.

**Migration value**:
- Storage performance requirements for EBS volume types
- Identify storage bottlenecks
- Queue depth analysis for IOPS sizing
- Device-level latency requirements

**Potential queries**:
```sql
-- Storage device performance
SELECT 
    device_number,
    device_type,
    AVG(response_time_ms) as avg_response_ms,
    MAX(response_time_ms) as max_response_ms,
    AVG(queue_depth) as avg_queue_depth,
    MAX(queue_depth) as max_queue_depth,
    SUM(io_operations) as total_ios,
    AVG(io_operations / NULLIF(sample_duration_seconds, 0)) as avg_iops,
    -- EBS recommendation based on performance
    CASE 
        WHEN AVG(response_time_ms) < 1 AND MAX(queue_depth) > 32 THEN 'EBS_IO2_HIGH_PERF'
        WHEN AVG(response_time_ms) < 5 THEN 'EBS_IO2'
        WHEN AVG(response_time_ms) < 10 THEN 'EBS_GP3'
        ELSE 'EBS_GP3_STANDARD'
    END as recommended_ebs_type
FROM smf74_device_activity
GROUP BY device_number, device_type
ORDER BY avg_iops DESC;

-- Identify storage bottlenecks
SELECT 
    device_number,
    COUNT(*) as high_latency_samples,
    AVG(response_time_ms) as avg_response_ms,
    AVG(queue_depth) as avg_queue_depth
FROM smf74_device_activity
WHERE response_time_ms > 10  -- High latency threshold
GROUP BY device_number
HAVING COUNT(*) > 100
ORDER BY high_latency_samples DESC;
```

**AWS mapping**: Device performance → EBS volume type and IOPS provisioning.

### 5.4 Type 80 - RACF Security

**What it provides**: Security audit trail, access attempts, authorization failures **for active users during the recording period**.

**Important Limitation**: Type 80 is **event-driven** and only captures security events that actually occurred. It does NOT provide:
- Complete list of all defined RACF users
- Inactive users who didn't access resources
- Full RACF profile definitions
- Complete security policy configurations

**Migration value**:
- Identify **active** user access patterns for IAM role design
- Map resource access patterns to AWS IAM policies
- Audit trail requirements for compliance
- Detect security violations and unauthorized access attempts

**Note**: For complete user and security policy migration, you need:
- RACF database exports (IRRDBU00 utility)
- RACF profile listings (LISTUSER, LISTDSD, LISTGRP commands)
- Security policy documentation

**Potential queries**:
```sql
-- Active user access patterns (ONLY users with activity in SMF period)
SELECT 
    user_id,
    resource_type,
    resource_name,
    COUNT(*) as access_count,
    SUM(CASE WHEN access_granted = 'Y' THEN 1 ELSE 0 END) as successful_access,
    SUM(CASE WHEN access_granted = 'N' THEN 1 ELSE 0 END) as failed_access,
    MIN(event_timestamp) as first_access,
    MAX(event_timestamp) as last_access,
    -- IAM policy recommendation based on actual usage
    CASE 
        WHEN resource_type = 'DATASET' THEN 'S3_BUCKET_POLICY'
        WHEN resource_type = 'PROGRAM' THEN 'LAMBDA_EXECUTION_ROLE'
        WHEN resource_type = 'TRANSACTION' THEN 'API_GATEWAY_AUTHORIZER'
        ELSE 'IAM_POLICY'
    END as aws_security_mapping
FROM smf80_security_events
GROUP BY user_id, resource_type, resource_name
ORDER BY access_count DESC;

-- Compliance audit requirements
SELECT 
    DATE(event_timestamp) as date,
    event_type,
    COUNT(*) as event_count,
    COUNT(DISTINCT user_id) as unique_active_users  -- Only active users
FROM smf80_security_events
WHERE event_type IN ('UNAUTHORIZED_ACCESS', 'PRIVILEGE_ESCALATION', 'DATA_ACCESS')
GROUP BY DATE(event_timestamp), event_type
ORDER BY date DESC;

-- Identify inactive vs active users (requires RACF export)
-- This query would need data from RACF database export, NOT from SMF Type 80
SELECT 
    racf.user_id,
    racf.user_name,
    racf.last_password_change,
    CASE 
        WHEN smf80.user_id IS NOT NULL THEN 'ACTIVE'
        ELSE 'INACTIVE'
    END as user_status,
    smf80.access_count
FROM racf_user_export racf
LEFT JOIN (
    SELECT user_id, COUNT(*) as access_count
    FROM smf80_security_events
    GROUP BY user_id
) smf80 ON racf.user_id = smf80.user_id
ORDER BY user_status, access_count DESC;
```

**AWS mapping**: 
- Active user access patterns → IAM policies and roles
- RACF profiles (from RACF export) → IAM users and groups
- Resource access rules → S3 bucket policies, resource-based policies

**Recommendation**: Combine SMF Type 80 (active usage) with RACF database exports (complete definitions) for comprehensive security migration planning.

### 5.5 Type 89 - TCP/IP Statistics

**What it provides**: Network traffic, connection statistics, packet counts, and bandwidth usage.

**Migration value**:
- Network bandwidth requirements for AWS Direct Connect or VPN
- Identify network-intensive applications
- Connection patterns for VPC design
- Latency requirements for hybrid cloud scenarios

**Potential queries**:
```sql
-- Network traffic analysis
SELECT 
    source_ip,
    destination_ip,
    port,
    SUM(bytes_sent) / 1024.0 / 1024.0 as total_mb_sent,
    SUM(bytes_received) / 1024.0 / 1024.0 as total_mb_received,
    COUNT(DISTINCT connection_id) as connection_count,
    AVG(connection_duration_seconds) as avg_connection_duration,
    -- AWS network recommendation
    CASE 
        WHEN SUM(bytes_sent + bytes_received) / 1024.0 / 1024.0 / 1024.0 > 1000 THEN 'DIRECT_CONNECT_10GBPS'
        WHEN SUM(bytes_sent + bytes_received) / 1024.0 / 1024.0 / 1024.0 > 100 THEN 'DIRECT_CONNECT_1GBPS'
        ELSE 'VPN_CONNECTION'
    END as recommended_connectivity
FROM smf89_tcp_connections
GROUP BY source_ip, destination_ip, port
ORDER BY total_mb_sent + total_mb_received DESC;

-- Connection patterns for VPC design
SELECT 
    application_name,
    COUNT(DISTINCT source_ip) as unique_sources,
    COUNT(DISTINCT destination_ip) as unique_destinations,
    AVG(concurrent_connections) as avg_concurrent_connections,
    MAX(concurrent_connections) as peak_concurrent_connections
FROM smf89_application_traffic
GROUP BY application_name
ORDER BY peak_concurrent_connections DESC;
```

**AWS mapping**: Network traffic → VPC design, Direct Connect sizing, security group rules.

### 5.6 Type 42 - DFSMShsm (HSM)

**What it provides**: Hierarchical Storage Management activity, migration, recall, and backup operations.

**Migration value**:
- Identify infrequently accessed data for S3 Glacier
- Data lifecycle policies for S3 Intelligent-Tiering
- Backup and archive requirements
- Storage tiering strategy

**Potential queries**:
```sql
-- Data access patterns for tiering
SELECT 
    dataset_name,
    last_access_date,
    CAST(JULIANDAY('now') - JULIANDAY(last_access_date) AS INTEGER) as days_since_access,
    migration_level,
    size_mb,
    -- S3 storage class recommendation
    CASE 
        WHEN JULIANDAY('now') - JULIANDAY(last_access_date) > 365 THEN 'S3_GLACIER_DEEP_ARCHIVE'
        WHEN JULIANDAY('now') - JULIANDAY(last_access_date) > 90 THEN 'S3_GLACIER_FLEXIBLE'
        WHEN JULIANDAY('now') - JULIANDAY(last_access_date) > 30 THEN 'S3_INTELLIGENT_TIERING'
        ELSE 'S3_STANDARD'
    END as recommended_s3_class
FROM smf42_hsm_activity
WHERE migration_level > 0  -- Migrated datasets
ORDER BY days_since_access DESC;

-- Backup and recovery patterns
SELECT 
    backup_type,
    COUNT(*) as backup_count,
    AVG(backup_size_mb) as avg_backup_size_mb,
    AVG(backup_duration_seconds) as avg_backup_duration,
    SUM(backup_size_mb) as total_backup_size_mb
FROM smf42_backup_activity
GROUP BY backup_type;
```

**AWS mapping**: HSM levels → S3 storage classes (Standard, IA, Glacier, Deep Archive).

---

## 6. Query Implementation Examples

### 6.1 Python API Usage

```python
from smf_queries import QueryEngine
from smf_loader.databases import SQLiteAdapter

# Initialize query engine
db = SQLiteAdapter('migration_analysis.db')
engine = QueryEngine(db)

# Execute artifact analysis queries
unreferenced_jcl = engine.execute_query('unreferenced_jcl', analysis_days=365)
unreferenced_programs = engine.execute_query('unreferenced_programs', analysis_days=365)
missing_programs = engine.execute_query('missing_programs', min_executions=10)

# Execute infrastructure sizing queries
batch_cpu_sizing = engine.execute_custom_query(batch_cpu_query)
cics_cpu_sizing = engine.execute_custom_query(cics_cpu_query)
storage_sizing = engine.execute_custom_query(storage_query)

# Calculate costs
mainframe_cost = calculate_mainframe_cost(batch_cpu_sizing, cics_cpu_sizing)
aws_cost = calculate_aws_cost(batch_cpu_sizing, cics_cpu_sizing, storage_sizing)
roi = calculate_roi(mainframe_cost, aws_cost, migration_effort)

print(f"Mainframe Annual Cost: ${mainframe_cost:,.0f}")
print(f"AWS Annual Cost: ${aws_cost:,.0f}")
print(f"Annual Savings: ${mainframe_cost - aws_cost:,.0f}")
print(f"ROI: {roi:.1f}%")
```

### 6.2 CLI Usage

```bash
# Artifact analysis
python -m smf_queries run --db migration.db --query unreferenced_jcl --analysis-days 365
python -m smf_queries run --db migration.db --query unreferenced_programs --min-size-kb 100
python -m smf_queries run --db migration.db --query missing_datasets --min-accesses 10

# Export results
python -m smf_queries run --db migration.db --query artifact_risk_assessment --output risk_report.csv

# Custom query execution
python -m smf_queries execute --db migration.db --sql-file batch_cpu_sizing.sql --output batch_sizing.json
```

---

## 7. Best Practices

### 7.1 Data Collection

1. **Collect at least 12 months of SMF data** for accurate workload patterns
2. **Include peak periods** (month-end, quarter-end, year-end)
3. **Capture all SMF record types** available (14, 15, 17, 30, 62, 64, 100, 101, 110)
4. **Maintain inventory accuracy** - keep JCL, program, dataset, and copybook inventories up-to-date

### 7.2 Analysis Approach

1. **Start with artifact analysis** - identify what needs to be migrated
2. **Eliminate unreferenced artifacts** - reduce migration scope
3. **Locate missing artifacts** - ensure complete inventory
4. **Calculate infrastructure sizing** - determine AWS requirements
5. **Estimate costs** - build business case
6. **Prioritize workloads** - plan migration waves

### 7.3 Validation

1. **Cross-reference multiple SMF types** - validate findings across different record types
2. **Compare with inventory** - ensure SMF data matches static inventory
3. **Review with business stakeholders** - validate artifact criticality
4. **Pilot test sizing calculations** - validate AWS sizing with proof-of-concept

### 7.4 Continuous Monitoring

1. **Re-run queries quarterly** - track workload changes
2. **Update cost estimates** - reflect AWS pricing changes
3. **Refine migration priorities** - adjust based on business needs
4. **Monitor post-migration** - compare actual vs. estimated AWS costs

---

## 8. Conclusion

This document provides a comprehensive set of queries for mainframe-to-AWS migration analysis. By combining SMF record analysis with static code analysis, organizations can:

- **Reduce migration scope** by identifying unreferenced artifacts
- **Accurately size AWS infrastructure** based on actual workload characteristics
- **Estimate costs** for both mainframe and AWS environments
- **Build a strong business case** with ROI analysis
- **Plan migration waves** based on complexity and dependencies

The queries in this document leverage **all currently implemented SMF record types** (14, 15, 17, 30, 62, 64, 100, 101, 110) and provide guidance on **additional SMF types** (70, 72, 74, 80, 89, 42) that would enhance migration planning capabilities.

For implementation details and API reference, see:
- [Query Reference](QUERY_REFERENCE.md)
- [API Reference](API_REFERENCE.md)
- [Field Mapping Reference](FIELD_MAPPING_REFERENCE.md)
