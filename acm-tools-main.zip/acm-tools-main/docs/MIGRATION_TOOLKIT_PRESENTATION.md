#  Agentic Code Migrator: Migration Toolkit
## Comprehensive Mainframe Modernization Solution

---

## Executive Summary

The **Migration Toolkit** is a comprehensive Python-based solution for IBM z/OS mainframe modernization and migration projects. It provides an integrated suite of tools that analyze both **legacy code** and **SMF performance records** to deliver actionable insights for cloud migration planning.

### Key Value Propositions
- **Complete Analysis Pipeline**: From raw mainframe data to migration roadmaps
- **AI-Ready Architecture**: Structured data output for LLM integration
- **ROI-Driven Approach**: Quantified business cases with effort estimates
- **Risk Mitigation**: Comprehensive dependency analysis and impact assessment

---

## Solution Architecture Overview

```mermaid
graph TB
    subgraph "Input Sources"
        A(Legacy Code<br/>COBOL, JCL, PL/I, ASM, RPG, Rexx)
        ATX(ATX provided dependencies)
        A2(DB, Scheduler etc.)
        A3(AWS Infrastructure Cost)
        B(SMF Records<br/>Performance Data)
        C(Inventory Data<br/>CSV Files)
    end
    
    subgraph "Agentic Code Migrator"
        D[Legacy Analyzer]
        ATXMP(ATX Mapper)
        E[SMF Analyzer]
        F[ACM Core]
        Y[ROI Calculator]
        X[Infrastructure]
        Z[Dashboard]
    
    end
    
    subgraph "Storage"
        G[(Unified Database<br/>SQLite)]
    end
    

    subgraph "Deliverables"
        J(Infrastructure Design)
        L(ROI Sizing Sheet)
        M(Infrastructure Scripts)
        N(☑ Migration Plan/Work Packages)
        O(☑ Business Specs)
        P(☑ Test Specs)
        Q(☑ DB / ☐ Scheduler and  ☑/☐ Migration Scripts)
        R(☑ Generated Code)
        S(☑ Generated Test Code)
    end
    ATX-->ATXMP
    ATXMP-->G
    A --> D
    A --> O
    B --> E
    C --> D
    A2 --> F
    A3 --> Y
    F --> Q
    
    D --> G
    E --> G
    G --> Y
    G --> Z
    G --> Z
    G --> F
    G --> X
    G --> N
    J --> M
    N --> O
    O --> P
    X --> J
    O --> R
    P --> S
    F --> N
    Y --> L

    
    style D fill:#90EE90
    style E fill:#90EE90
    style F fill:#90EE90
    style G fill:#90EE90
    style Y fill:#FFFF99
    style X fill:#FFFF99
    style Z fill:#FFFF99
    style J fill:#FFB6C1
    style L fill:#FFB6C1
    style M fill:#FFB6C1
    style N fill:#90EE90
    style O fill:#90EE90
    style P fill:#90EE90
    style Q fill:#90EE90
    style R fill:#90EE90
    style S fill:#90EE90

```

---

## Component Deep Dive

### 1. Legacy Analyzer
**Purpose**: Static code analysis and dependency mapping for mainframe applications

#### Key Features
- **Multi-Language Support**: COBOL, JCL, PL/I, RPG, Natural, REXX, Assembler
- **Intelligent Language Detection**: Auto-detects programming language from content
- **Dependency Analysis**: Maps CALL, COPY, INCLUDE, and dataset relationships
- **Complexity Assessment**: LOC, cyclomatic complexity, dependency metrics
- **Entry Point Detection**: Identifies CICS transactions and JCL entry points

#### Code Example
```python
from tools.legacy_analyzer.api import LegacyAnalyzerAPI

# Initialize analyzer with database
with LegacyAnalyzerAPI("migration_analysis.db") as api:
    
    # Analyze program flow from entry point
    flow = api.analyze_flow("PAYROLL1", max_depth=10)
    print(f"Flow contains {len(flow.programs)} programs")
    
    # Calculate complexity metrics
    with open("PAYROLL1.cbl") as f:
        source = f.read()
    
    complexity = api.analyze_complexity(
        program_name="PAYROLL1",
        source_code=source,
        language="COBOL"
    )
    print(f"Complexity tier: {complexity.complexity_tier}")
    
    # Detect missing artifacts
    missing = api.detect_all_missing()
    print(f"Found {len(missing)} missing artifacts")
    
    # Create migration package
    package = api.create_package(
        name="Payroll System",
        seed_artifacts=["PAYROLL1", "PAYCALC", "PAYFILE"]
    )
```

#### Database Schema
```sql
-- Core inventory tables
CREATE TABLE inventory (
    artifact_name TEXT PRIMARY KEY,
    artifact_type TEXT,
    location TEXT,
    last_modified DATE
);

-- Dependency relationships
CREATE TABLE artifact_dependencies (
    source_artifact_name TEXT,
    target_artifact_name TEXT,
    dependency_type TEXT,
    line_number INTEGER
);

-- CICS metadata
CREATE TABLE inventory_cics (
    transaction_id TEXT PRIMARY KEY,
    program_name TEXT,
    status TEXT,
    description TEXT
);
```

### 2. SMF Analyzer
**Purpose**: Parse, load, and analyze IBM z/OS SMF performance records

#### Architecture Components

```mermaid
graph LR
    subgraph "SMF Analyzer Components"
        A[SMF Parser<br/>Binary → JSON]
        B[SMF Loader<br/>JSON → Database]
        C[SMF Queries<br/>Analysis Engine]
        D[Test Data Generator<br/>Synthetic Data]
    end
    
    E[Binary SMF Files] --> A
    A --> F[Structured JSON]
    F --> B
    B --> G[(Unified Database)]
    G --> C
    C --> H[Analysis Results]
    
    D --> F
    
    style A fill:#ffebee
    style B fill:#e8f5e8
    style C fill:#e3f2fd
    style D fill:#fff8e1
```

#### SMF Record Parser
**Converts binary SMF files into structured JSON format using factory pattern and version-aware parsing**

##### Parser Factory Architecture

```mermaid
graph TD
    A[SMF File] --> B[Format Detector]
    B --> C[SMF File Parser]
    C --> D[Parser Factory]
    D --> E{Record Type & Version}
    
    E -->|Type 30 V3R2| F[SMF30_V3R2 Parser]
    E -->|Type 30 V2R5| G[SMF30_V2R5 Parser]
    E -->|Type 100 V10| H[SMF100_V10 Parser]
    E -->|Type 101 V12| I[SMF101_V12 Parser]
    E -->|Type 102 V13| J[SMF102_V13 Parser]
    E -->|Type 110 V3R2| K[SMF110_V3R2 Parser]
    E -->|Type 14 V3R2| L[SMF14_V3R2 Parser]
    E -->|Type 70 V3R2| M[SMF70_V3R2 Parser]
    E -->|40+ Others| N[Type-Specific Parsers]
    
    H --> O1{DB2 IFCID Registry}
    I --> O2{DB2 IFCID Registry}
    J --> O3{DB2 IFCID Registry}
    K --> O4{CICS IFCID Registry}
    
    O1 --> P1[100+ DB2 IFCID Parsers]
    O2 --> P2[200+ DB2 IFCID Parsers]
    O3 --> P3[300+ DB2 IFCID Parsers]
    O4 --> P4[200+ CICS IFCID Parsers]
    
    F --> Q[Structured JSON]
    G --> Q
    H --> Q
    I --> Q
    J --> Q
    K --> Q
    L --> Q
    M --> Q
    N --> Q
    P1 --> Q
    P2 --> Q
    P3 --> Q
    P4 --> Q
    
    style D fill:#e1f5fe
    style O1 fill:#fff3e0
    style O2 fill:#fff3e0
    style O3 fill:#fff3e0
    style O4 fill:#fff3e0
    style N fill:#f3e5f5
```

##### Implementation Example

```python
from tools.smf_analyzer.smf_record_parser import SMFFileParser
from tools.smf_analyzer.smf_record_parser.parsers import SMFParserFactory

# High-level API with auto-detection
parser = SMFFileParser(os_version="V3R2", encoding="EBCDIC")
for record in parser.parse_file("SMF.APR4.TRS.DECOMPRESS"):
    print(f"Type {record.record_type}: {record.system_id}")

# Factory pattern for specific parsers
factory = SMFParserFactory()

# Get parser for specific type and version
type30_v3r2_parser = factory.create_parser(
    record_type=30,
    os_version="V3R2"
)

# DB2 parser with version detection
db2_parser = factory.create_parser(
    record_type=101,
    db2_version="V12",
    os_version="V3R2"
)

# CICS parser with IFCID registry
cics_parser = factory.create_parser(
    record_type=110,
    os_version="V3R2",
    ifcid_filter=[1, 2, 3, 110]  # Specific IFCIDs only
)
```

##### Parser Registry System

**Version-Aware Parsing:**
- **z/OS Versions**: V2R4, V2R5, V3R1, V3R2 with version-specific field mappings
- **DB2 Versions**: V10, V11, V12, V13 with automatic version detection from QWHSRELN field
- **Fallback Strategy**: Uses nearest available parser when exact version unavailable

**IFCID Registries:**
- **Type 110 CICS**: 200+ IFCIDs documented with field mappings
- **Type 100 DB2 Statistics**: 100+ IFCIDs for DB2 statistics collection
- **Type 101 DB2 Accounting**: 200+ IFCIDs for DB2 accounting data
- **Type 102 DB2 Performance**: 300+ IFCIDs for DB2 performance monitoring
- **Selective parsing** - filter by specific IFCIDs for performance
- **Extensible registry** - easy to add new IFCID definitions

```python
# IFCID Registry examples
from tools.smf_analyzer.smf_record_parser.registries import IFCIDRegistry

# CICS IFCID Registry (Type 110)
cics_registry = IFCIDRegistry(record_type=110)
cics_registry.get_parser(ifcid=1)    # Transaction start
cics_registry.get_parser(ifcid=2)    # Transaction end
cics_registry.get_parser(ifcid=110)  # Performance data

# DB2 IFCID Registries
db2_stats_registry = IFCIDRegistry(record_type=100)
db2_stats_registry.get_parser(ifcid=1)   # DB2 Statistics
db2_stats_registry.get_parser(ifcid=2)   # DB2 Buffer Pool

db2_acct_registry = IFCIDRegistry(record_type=101)
db2_acct_registry.get_parser(ifcid=3)    # DB2 Accounting
db2_acct_registry.get_parser(ifcid=239)  # Package/DBRM Accounting

db2_perf_registry = IFCIDRegistry(record_type=102)
db2_perf_registry.get_parser(ifcid=5)    # DB2 Performance
db2_perf_registry.get_parser(ifcid=318)  # Lock Detail

# Register custom IFCID
db2_perf_registry.register_ifcid(
    ifcid=999,
    name="Custom DB2 Performance Data",
    fields=custom_field_mapping
)
```

**Key Capabilities:**
- **Dedicated Parsers**: Every supported SMF record type has its own parser implementation
- **Version-Specific**: Separate parsers for each z/OS version (V2R4, V2R5, V3R1, V3R2)
- **DB2 Version Awareness**: Automatic DB2 version detection with dedicated parsers per version
- **Multiple IFCID Registries**: 800+ total IFCIDs across CICS and DB2 record types
- **Format Flexibility**: VB, VBS, RDW formats with auto-detection
- **No Generic Fallback**: Each record type has purpose-built parsing logic

**Implemented Record Types** (40+ parsers with full support):

**Core Performance Records:**
- **Type 30**: Job/Step Accounting (CPU, I/O, Storage) - Full support
- **Type 110**: CICS Transaction Server (200+ IFCIDs) - Full support
- **Type 14/15**: Dataset Activity - Full support
- **Type 2/3**: Dump Header/Trailer - Parsed for metadata

**Database Records:**
- **Type 100**: DB2 Statistics (V10) - Auto version detection
- **Type 101**: DB2 Accounting (V11, V12) - Auto version detection  
- **Type 102**: DB2 Performance (V11, V12, V13) - Auto version detection

**Additional Coverage**: 30+ other record types with parsers implemented

**Documentation Available**: 80+ record types documented from IBM sources for future implementation

#### SMF Loader
**Loads parsed JSON into unified database for cross-type analysis**

```python
from tools.smf_analyzer.smf_loader import SMFLoader
from tools.smf_analyzer.smf_loader.databases import SQLiteAdapter
from tools.smf_analyzer.smf_loader.schemas import UnifiedSMFSchema

# Load all record types into single database
loader = SMFLoader(
    database=SQLiteAdapter('smf_analytics.db'),
    schema=UnifiedSMFSchema()
)
loader.create_schema()
loader.load_json_file('all_smf_records.json')
```

#### SMF Query Engine
**Pre-built queries with metadata-driven categorization and AI-friendly output**

##### Query Architecture

```mermaid
graph TD
    A[Query Engine] --> B[Query Registry]
    B --> C[SMF30 Queries]
    B --> D[SMF110 Queries]
    B --> E[Cross-Type Queries]
    B --> F[Artifact Queries]
    
    C --> G[Performance Category]
    C --> H[Resource Category]
    C --> I[Completion Category]
    
    D --> J[Transaction Category]
    D --> K[Response Time Category]
    D --> L[Volume Category]
    
    E --> M[Correlation Category]
    E --> N[Workload Category]
    
    F --> O[Lifecycle Category]
    F --> P[Risk Category]
    
    G --> Q[Query Metadata]
    H --> Q
    I --> Q
    J --> Q
    K --> Q
    L --> Q
    M --> Q
    N --> Q
    O --> Q
    P --> Q
    
    Q --> R[Structured Results]
    
    style A fill:#e3f2fd
    style B fill:#e8f5e8
    style Q fill:#fff3e0
```

##### Implementation with Metadata

```python
from tools.smf_analyzer.smf_queries import QueryEngine, QueryMetadata

engine = QueryEngine(database)

# Query with full metadata
result = engine.execute('top_cpu_consumers', limit=20)

# Access query metadata
print(f"Category: {result.metadata.category}")
print(f"Description: {result.metadata.description}")
print(f"Business Value: {result.metadata.business_value}")
print(f"AI Summary: {result.metadata.ai_summary}")

# Export with metadata for AI consumption
ai_ready_output = result.to_ai_format()
```

##### Query Categories with Metadata

**SMF Type 30 Queries (9 queries):**

| Query Name | Category | Business Value | AI Summary |
|------------|----------|----------------|------------|
| `top_cpu_consumers` | Performance | Identify optimization targets | "Programs consuming most CPU resources for modernization priority" |
| `cpu_statistics` | Performance | Resource planning | "Statistical analysis of CPU usage patterns across workloads" |
| `top_io_consumers` | Resource | I/O optimization | "Programs with highest I/O activity requiring storage optimization" |
| `dataset_activity` | Resource | Data access patterns | "Dataset usage frequency for data migration planning" |
| `job_completion_rate` | Completion | Reliability assessment | "Job success rates indicating system stability and risk" |
| `failed_jobs_analysis` | Completion | Risk identification | "Failed job patterns requiring attention in migration" |
| `storage_utilization` | Resource | Capacity planning | "Memory usage patterns for cloud sizing estimates" |
| `cpu_by_program` | Performance | Program-level analysis | "Per-program CPU consumption for detailed optimization" |
| `io_by_dataset` | Resource | Data-level analysis | "Dataset-specific I/O patterns for storage architecture" |

**SMF Type 110 Queries (11 queries):**

| Query Name | Category | Business Value | AI Summary |
|------------|----------|----------------|------------|
| `cics_transaction_summary` | Transaction | CICS workload overview | "Transaction volume and performance baseline for modernization" |
| `top_cics_transactions` | Volume | High-impact identification | "Most active CICS transactions requiring priority migration" |
| `cics_response_times` | Response Time | Performance analysis | "Transaction response time patterns for SLA planning" |
| `cics_performance_trends` | Response Time | Trend analysis | "Performance trends over time for capacity planning" |
| `cics_error_analysis` | Completion | Error pattern analysis | "CICS error patterns indicating modernization risks" |
| `cics_resource_usage` | Resource | Resource consumption | "CICS resource utilization for infrastructure sizing" |
| `cics_peak_hours` | Volume | Peak load analysis | "Peak usage patterns for auto-scaling configuration" |
| `cics_program_activity` | Transaction | Program usage analysis | "CICS program activity for migration package planning" |
| `cics_terminal_activity` | Volume | User access patterns | "Terminal/user activity for interface modernization" |
| `cics_storage_analysis` | Resource | Memory optimization | "CICS storage usage for memory allocation planning" |
| `cics_transaction_flow` | Transaction | Flow analysis | "Transaction flow patterns for microservices design" |

**Cross-Type Queries (7 queries):**

| Query Name | Category | Business Value | AI Summary |
|------------|----------|----------------|------------|
| `workload_distribution` | Workload | System-wide analysis | "Complete workload distribution across batch and online" |
| `batch_cics_correlation` | Correlation | Integration analysis | "Batch-CICS dependencies for migration sequencing" |
| `application_end_to_end` | Correlation | Complete app view | "End-to-end application performance across all tiers" |
| `resource_contention` | Resource | Contention analysis | "Resource conflicts requiring architecture changes" |
| `time_correlated_events` | Correlation | Event analysis | "Time-based event correlation for root cause analysis" |
| `system_cpu_utilization` | Performance | System capacity | "System-wide CPU utilization for infrastructure planning" |
| `storage_io_correlation` | Resource | I/O analysis | "Storage I/O correlation for performance optimization" |

**Artifact Lifecycle Queries (12+ queries):**

| Query Name | Category | Business Value | AI Summary |
|------------|----------|----------------|------------|
| `unreferenced_programs` | Lifecycle | Cleanup identification | "Programs not used in SMF data for archival consideration" |
| `unreferenced_datasets` | Lifecycle | Data cleanup | "Datasets not accessed for storage optimization" |
| `missing_artifacts` | Risk | Gap analysis | "Referenced artifacts missing from inventory" |
| `artifact_risk_assessment` | Risk | Risk evaluation | "Risk-based artifact classification for cleanup planning" |
| `cleanup_recommendations` | Lifecycle | Action planning | "Prioritized cleanup recommendations with effort estimates" |
| `dependency_analysis` | Risk | Impact analysis | "Artifact dependencies for safe cleanup planning" |

##### AI-Ready Output Format

```python
# Query result with AI-optimized metadata
result = engine.execute('top_cpu_consumers')

ai_output = {
    "query": {
        "name": "top_cpu_consumers",
        "category": "Performance",
        "business_value": "Identify optimization targets",
        "ai_summary": "Programs consuming most CPU resources for modernization priority"
    },
    "data": result.data,
    "insights": {
        "total_records": len(result.data),
        "key_findings": result.generate_insights(),
        "recommendations": result.generate_recommendations()
    },
    "metadata": {
        "execution_time": result.execution_time,
        "data_quality": result.data_quality_score,
        "confidence": result.confidence_level
    }
}
```

**Query Engine Features:**
- **Metadata-Driven**: Every query includes business context and AI summaries
- **Categorized Results**: Organized by business function for easy navigation
- **AI-Optimized Output**: Structured for LLM consumption and interpretation
- **Cross-Type Analysis**: Correlates data across multiple SMF record types
- **Parameterized Queries**: Flexible filtering and customization
- **Multiple Formats**: JSON, CSV, Markdown, and AI-ready formats

### 3. SMF Dashboard
**Web-based interface for SMF data management and analysis**

#### Features
- **File Upload**: Binary SMF files or pre-parsed JSON
- **Real-time Progress**: Parsing and loading progress tracking
- **Interactive Queries**: Dynamic parameter forms
- **Result Export**: JSON, CSV, Markdown formats
- **Session Management**: Persistent database selection

#### Usage Flow
```mermaid
sequenceDiagram
    participant U as User
    participant D as Dashboard
    participant P as Parser Service
    participant L as Loader Service
    participant Q as Query Service
    
    U->>D: Upload SMF File
    D->>P: Parse Binary File
    P-->>D: JSON Records
    D->>L: Load to Database
    L-->>D: Load Complete
    U->>D: Select Query
    D->>Q: Execute Query
    Q-->>D: Results
    D-->>U: Display Results
```

### 4. SMF Test Data Generator
**Creates synthetic SMF data for testing and development**

```python
from tools.smf_test_data_generator import SMF30Generator, SMF110Generator

# Generate Type 30 job accounting records
job_generator = SMF30Generator()
job_records = job_generator.generate_batch(
    count=1000,
    date_range=("2024-01-01", "2024-01-31"),
    job_patterns=["PAYROLL*", "BILLING*", "BACKUP*"]
)

# Generate Type 110 CICS transaction records
cics_generator = SMF110Generator()
cics_records = cics_generator.generate_batch(
    count=5000,
    transaction_ids=["PAY1", "BILL2", "INQR"],
    response_time_distribution="normal"
)
```

---

## Analysis Phase: Unified Intelligence

### Cross-Analysis Capabilities

The unified database enables powerful cross-analysis between code structure and performance data:

```sql
-- Find high-CPU programs with complex code structure
SELECT 
    p.program_name,
    p.complexity_tier,
    s.avg_cpu_time,
    s.execution_count
FROM program_complexity p
JOIN smf30_job_step s ON p.program_name = s.program_name
WHERE s.avg_cpu_time > 1000  -- High CPU consumers
  AND p.complexity_tier IN ('HIGH', 'VERY_HIGH')
ORDER BY s.avg_cpu_time DESC;

-- Correlate CICS transaction volumes with program dependencies
SELECT 
    c.transaction_id,
    c.avg_response_time,
    c.daily_volume,
    COUNT(d.target_artifact_name) as dependency_count
FROM smf110_performance c
JOIN artifact_dependencies d ON c.program_name = d.source_artifact_name
GROUP BY c.transaction_id
HAVING c.daily_volume > 10000  -- High volume transactions
ORDER BY dependency_count DESC;
```

### Migration Readiness Assessment

```python
# Comprehensive migration readiness analysis
def assess_migration_readiness(database_path):
    with LegacyAnalyzerAPI(database_path) as api:
        
        # Get entry points with metadata
        entry_points = api.get_entry_points_with_metadata()
        
        # Analyze complexity distribution
        complexity_metrics = {}
        for ep in entry_points:
            flow = api.analyze_flow(ep.program_name)
            complexity_metrics[ep.program_name] = {
                'flow_depth': flow.depth,
                'program_count': len(flow.programs),
                'entry_type': ep.entry_type,
                'business_domain': ep.business_domain
            }
        
        # Generate migration packages
        packages = []
        for domain in ['Finance', 'HR', 'Inventory']:
            domain_programs = [p for p, m in complexity_metrics.items() 
                             if m.get('business_domain') == domain]
            if domain_programs:
                package = api.create_package(
                    name=f"{domain} Migration",
                    seed_artifacts=domain_programs[:5]  # Top 5 programs
                )
                packages.append(package)
        
        return {
            'entry_points': len(entry_points),
            'complexity_distribution': complexity_metrics,
            'migration_packages': packages,
            'readiness_score': calculate_readiness_score(complexity_metrics)
        }
```

---

## Output Streams: Three-Pronged Approach

### 1. ROI & Sizing Stream

**Objective**: Quantify business value and migration effort with accurate cost modeling

#### Deliverables
- **ROI Sizing Sheet**: Cost-benefit analysis with migration scenarios
- **Mainframe Cost Analysis**: MIPS-based cost calculations with configurable rates
- **Effort Estimates**: Development hours by complexity tier and migration flow
- **Risk Assessment**: Technical and business risk factors
- **Timeline Projections**: Phased migration roadmap with dependencies

#### Key Metrics & Calculations

**Mainframe Cost Modeling:**
```python
# Accurate MIPS calculation (corrected in v2.0)
def calculate_mainframe_costs(smf_data):
    """
    Calculate mainframe costs using correct MIPS formula.
    MIPS is a RATE measured against wall-clock time, not CPU time.
    """
    # Get observation period (time span of SMF data)
    observation_period_hours = get_observation_period(smf_data)
    
    # Batch MIPS: Service Units per hour / 1M * 26
    batch_mips = (total_service_units / observation_period_hours) / 1_000_000 * 26
    
    # CICS MIPS: Transaction rate * CPU per transaction * MIPS factor
    cics_mips = (transactions / observation_period_hours) * avg_cpu_per_txn * 0.1 * 1_000_000
    
    # Total MIPS and costs
    total_mips = batch_mips + cics_mips
    mainframe_cost_per_mips_monthly = 4000  # Industry standard: $3K-$5K/MIPS/month
    
    return {
        'batch_mips': batch_mips,
        'cics_mips': cics_mips,
        'total_mips': total_mips,
        'monthly_cost': total_mips * mainframe_cost_per_mips_monthly,
        'annual_cost': total_mips * mainframe_cost_per_mips_monthly * 12
    }
```

**Migration Effort Estimation:**
```python
# ROI calculation with flow-based breakdown
def calculate_migration_roi(analysis_results):
    """
    Calculate comprehensive ROI with migration flow breakdown.
    """
    # Code migration costs (by flow)
    code_migration = {
        'migration_loc': sum(flow['loc'] for flow in migration_flows) + other_loc,
        'unique_loc': total_unique_artifacts_loc,
        'cost_per_loc': 1.0,  # Configurable
        'total_cost': migration_loc * cost_per_loc,
        'breakdown_by_flow': {
            flow['id']: {
                'loc': flow['loc'],
                'cost': flow['loc'] * cost_per_loc,
                'programs': flow['program_count'],
                'copybooks': flow['copybook_count']
            }
            for flow in migration_flows
        }
    }
    
    # Data migration costs (T-shirt sizing)
    data_migration = {
        'total_databases': len(databases),
        'total_size_gb': sum(db['size_gb'] for db in databases),
        'effort_hours': sum(db['effort_hours'] for db in databases),
        'total_cost': sum(db['cost'] for db in databases)
    }
    
    # Current mainframe costs
    mainframe_costs = calculate_mainframe_costs(analysis_results['smf_data'])
    
    # AWS runtime costs (from Infrastructure Sizing)
    aws_costs = {
        'ec2_monthly': ec2_batch_cost + ec2_cics_cost,
        'rds_monthly': rds_cost,
        'storage_monthly': storage_cost,
        'network_monthly': network_cost,
        'total_monthly': sum_of_above,
        'annual_cost': total_monthly * 12
    }
    
    # ROI calculations
    annual_savings = mainframe_costs['annual_cost'] - aws_costs['annual_cost']
    total_migration_cost = code_migration['total_cost'] + data_migration['total_cost']
    payback_period_months = total_migration_cost / (annual_savings / 12)
    
    return {
        'current_mainframe_costs': mainframe_costs,
        'aws_runtime_costs': aws_costs,
        'annual_savings': annual_savings,
        'migration_costs': {
            'code_migration': code_migration['total_cost'],
            'data_migration': data_migration['total_cost'],
            'total': total_migration_cost
        },
        'payback_period_months': payback_period_months,
        'net_present_value_5yr': calculate_npv(annual_savings, total_migration_cost, 5),
        'roi_percentage': (annual_savings * 5 - total_migration_cost) / total_migration_cost * 100
    }
```

**Dashboard Integration:**
The ROI Analysis tab provides:
- **Code Migration Effort**: LOC-based estimates with flow breakdown
- **Data Migration Effort**: T-shirt sizing for databases
- **Runtime Costs & ROI**: Mainframe vs AWS cost comparison with break-even analysis
- **Interactive Configuration**: Adjust cost parameters and see real-time impact
- **Export Capabilities**: JSON, CSV, Markdown formats for stakeholder presentations

### 2. Infrastructure Stream

**Objective**: Generate cloud infrastructure setup scripts

#### Deliverables
- **AWS CloudFormation Templates**: VPC, ECS, RDS configurations
- **Kubernetes Manifests**: Container orchestration
- **CI/CD Pipelines**: Automated deployment workflows
- **Monitoring Setup**: CloudWatch, Prometheus configurations

#### Example Infrastructure Code
```yaml
# CloudFormation template for migrated application
AWSTemplateFormatVersion: '2010-09-09'
Description: 'Migrated Mainframe Application Infrastructure'

Resources:
  ApplicationCluster:
    Type: AWS::ECS::Cluster
    Properties:
      ClusterName: !Sub '${ApplicationName}-cluster'
      
  PayrollService:
    Type: AWS::ECS::Service
    Properties:
      Cluster: !Ref ApplicationCluster
      TaskDefinition: !Ref PayrollTaskDefinition
      DesiredCount: 3
      
  PayrollDatabase:
    Type: AWS::RDS::DBInstance
    Properties:
      DBInstanceClass: db.r5.xlarge
      Engine: postgresql
      AllocatedStorage: 1000
```

### 3. Code Migration Stream

**Objective**: Transform legacy code to modern equivalents

#### Migration Flow Pipeline
```mermaid
graph TD
    A[Legacy Code Analysis] --> B[Business Rule Extraction]
    B --> C[Architecture Pattern Mapping]
    C --> D[Code Generation Templates]
    D --> E[Modern Code Output]
    
    F[SMF Performance Data] --> G[Optimization Patterns]
    G --> D
    
    H[Migration Plan] --> I[Business Specifications]
    I --> J[Test Specifications]
    J --> K[Validation Scripts]
    
    E --> L[Microservices]
    E --> M[REST APIs]
    E --> N[Event-Driven Architecture]
    
    style A fill:#ffebee
    style F fill:#e8f5e8
    style H fill:#fff3e0
```

#### Deliverables
- **Migration Plan**: Phased approach with dependencies
- **Business Specifications**: Functional requirements extraction
- **Test Specifications**: Automated test generation
- **Generated Code**: Modern language equivalents (Java, Python, Node.js)
- **Migration Scripts**: Data transformation and validation

#### Code Generation Example
```python
# COBOL to Java transformation
def transform_cobol_to_java(cobol_program, business_rules):
    """
    Transform COBOL program to Spring Boot microservice
    """
    java_service = JavaServiceGenerator()
    
    # Extract business logic
    business_logic = extract_business_logic(cobol_program)
    
    # Generate REST endpoints
    endpoints = []
    for paragraph in cobol_program.paragraphs:
        if is_entry_point(paragraph):
            endpoint = java_service.create_rest_endpoint(
                name=paragraph.name,
                logic=paragraph.logic,
                data_structures=paragraph.data_items
            )
            endpoints.append(endpoint)
    
    # Generate service class
    service_class = java_service.generate_service(
        name=f"{cobol_program.name}Service",
        endpoints=endpoints,
        business_rules=business_rules
    )
    
    return {
        'service_class': service_class,
        'controller_class': java_service.generate_controller(endpoints),
        'data_models': java_service.generate_models(cobol_program.data_items),
        'test_cases': java_service.generate_tests(endpoints)
    }
```

---

## Implementation Workflow

### Phase 1: Analysis Setup (Week 1-2)
```bash
# 1. Initialize project structure
git clone <smf-migration-toolkit>
cd smf-migration-toolkit
pip install -r requirements.txt

# 2. Load inventory data
python -m tools.legacy_analyzer load \
  --type programs --file inventory/programs.csv \
  --type jcl --file inventory/jcl.csv \
  --type datasets --file inventory/datasets.csv \
  --db migration_analysis.db

# 3. Analyze source code
python -m tools.legacy_analyzer analyze \
  --source-dir /mainframe/source \
  --db migration_analysis.db

# 4. Parse SMF records
python -m tools.smf_analyzer.smf_record_parser parse \
  SMF.MONTHLY.DATA --split both --output smf_parsed/

# 5. Load SMF data
python -m tools.smf_analyzer.smf_loader load \
  --unified --db migration_analysis.db \
  --file smf_parsed/SMF_ALL.json --create-schema
```

### Phase 2: Analysis Execution (Week 3-4)
```python
# Complete analysis pipeline
from tools.legacy_analyzer.api import LegacyAnalyzerAPI
from tools.smf_analyzer.api import SMFAnalyzer

# Initialize analyzers
legacy_api = LegacyAnalyzerAPI("migration_analysis.db")
smf_analyzer = SMFAnalyzer()

# Build migration flows
flow_ids = legacy_api.build_migration_flows()
print(f"Built {len(flow_ids)} migration flows")

# Export migration-ready flows
flows = legacy_api.export_migration_flows(
    output_file="Business_Flows.json",
    min_complexity="MEDIUM",
    sort_order="complexity-asc"
)

# Run SMF analysis queries
smf_results = smf_analyzer.run_analysis(
    db_path="migration_analysis.db",
    queries=[
        "workload_distribution",
        "resource_utilization_trends", 
        "batch_cics_correlation",
        "artifact_risk_assessment"
    ]
)
```

### Phase 3: Output Generation (Week 5-6)
```python
# Generate comprehensive migration package
def generate_migration_deliverables(analysis_db):
    
    # 1. ROI & Sizing Analysis
    roi_analysis = generate_roi_sizing_sheet(analysis_db)
    
    # 2. Infrastructure Scripts
    infrastructure_templates = generate_infrastructure_scripts(
        applications=roi_analysis['applications'],
        target_platform='aws',
        architecture_pattern='microservices'
    )
    
    # 3. Migration Plan
    migration_plan = generate_migration_plan(
        flows=flows['flows'],
        complexity_tiers=['LOW', 'MEDIUM', 'HIGH'],
        timeline_months=18
    )
    
    # 4. Business Specifications
    business_specs = extract_business_specifications(
        programs=analysis_db.get_programs(),
        smf_usage_patterns=smf_results
    )
    
    # 5. Test Specifications
    test_specs = generate_test_specifications(
        business_specs=business_specs,
        coverage_target=0.85
    )
    
    return {
        'roi_sizing': roi_analysis,
        'infrastructure': infrastructure_templates,
        'migration_plan': migration_plan,
        'business_specs': business_specs,
        'test_specs': test_specs,
        'generated_code': generate_modern_code(business_specs)
    }
```

---

## Key Differentiators

### 1. Unified Analysis Approach
- **Single Database**: All code and performance data in one place
- **Cross-Analysis**: Correlate code complexity with runtime performance
- **Holistic View**: Complete application ecosystem understanding

### 2. AI-Ready Architecture
- **Structured Output**: JSON/CSV formats for LLM consumption
- **Query Engine**: Natural language query translation capability
- **Metadata Rich**: Comprehensive context for AI decision-making

### 3. Business-Focused Outcomes
- **ROI Quantification**: Clear business case with metrics
- **Risk Assessment**: Comprehensive impact analysis
- **Phased Approach**: Manageable migration timeline

### 4. Production-Ready Tools
- **Web Dashboard**: User-friendly interface for non-technical stakeholders
- **CLI Tools**: Automation-friendly command-line interfaces
- **Extensible Architecture**: Easy to add new parsers and analyzers

---

## Success Metrics

### Technical Metrics
- **Code Coverage**: 95%+ of mainframe artifacts analyzed
- **Dependency Accuracy**: 98%+ dependency relationship accuracy
- **Performance Correlation**: SMF data linked to 90%+ of programs

### Business Metrics
- **Migration Readiness**: Clear go/no-go decisions for each application
- **Effort Estimation**: ±15% accuracy on development estimates
- **Risk Mitigation**: 80% reduction in migration surprises

### Operational Metrics
- **Analysis Speed**: Complete enterprise analysis in 2-4 weeks
- **Automation Level**: 90% automated analysis pipeline
- **Stakeholder Adoption**: Self-service analysis for business users

---

## Conclusion

The **Migration Toolkit** provides a comprehensive, data-driven approach to mainframe modernization. By combining static code analysis with runtime performance data, it delivers the insights needed for successful cloud migration projects.

### Next Steps
1. **Pilot Project**: Select 2-3 applications for initial analysis
2. **Stakeholder Training**: Dashboard and CLI tool workshops
3. **Integration Planning**: Connect with existing DevOps pipelines
4. **Scaling Strategy**: Enterprise-wide rollout planning

The toolkit transforms mainframe modernization from a risky, manual process into a systematic, data-driven initiative with quantifiable outcomes and clear success metrics.