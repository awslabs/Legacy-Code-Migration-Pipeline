# Troubleshooting Import Issues

## Overview

This document explains how Python module imports work in the SMF Migration Toolkit and how to troubleshoot common import issues.

## How Imports Work

The toolkit uses Python's module system with the following structure:

```
acm-tools/                    # Repository root
├── tools/                    # Tool packages
│   ├── smf_analyzer/
│   ├── legacy_analyzer/
│   └── migration_planner/
├── shared/                   # Shared infrastructure
│   └── database/
│       └── adapters/
└── scripts/                  # Shell scripts
```

### Import Requirements

For imports like `from shared.database.adapters import SQLiteAdapter` to work:

1. **Current directory must be the repository root** (or repo root must be in `sys.path`)
2. **All packages must have `__init__.py` files** (already in place)
3. **Python must be run with `-m` flag** for module execution

## Running Scripts from Outside the Project

### The Problem

When you run a script from outside the project directory:

```bash
cd /Users/kerimman/cardemo
bash /Users/kerimman/cardemo/tools/acm-tools/scripts/run_configurable_analysis.sh ...
```

Python needs to find the modules (`tools`, `shared`, etc.).

### The Solution

The scripts automatically handle this by:

1. **Detecting the repository root**:
   ```bash
   SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
   REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
   ```

2. **Changing to the repository root**:
   ```bash
   cd "$REPO_ROOT"
   ```

3. **Running Python from there**:
   ```bash
   python3 -m tools.legacy_analyzer analyze --source-dir ...
   ```

This ensures Python can find all modules regardless of where the script was invoked from.

## Common Import Errors and Solutions

### Error 1: ModuleNotFoundError: No module named 'tools'

**Cause**: Python is not running from the repository root.

**Solution**: Ensure scripts change to repository root before running Python commands.

### Error 2: ModuleNotFoundError: No module named 'shared'

**Cause**: The `shared` module is not in Python's search path.

**Solution**: Run from repository root or add it to `PYTHONPATH`:
```bash
export PYTHONPATH=/path/to/acm-tools:$PYTHONPATH
```

### Error 3: Cross-tool dependency errors

**Cause**: Tools importing from each other instead of using `shared`.

**Solution**: Use shared infrastructure:
- ✓ `from shared.database.adapters import SQLiteAdapter`
- ✗ `from tools.smf_analyzer.smf_loader.databases.sqlite_adapter import SQLiteAdapter`

## Verification

Test that imports work from outside the project:

```bash
cd /tmp
python3 -c "
import sys
sys.path.insert(0, '/path/to/acm-tools')
from shared.database.adapters import SQLiteAdapter
from tools.legacy_analyzer.api import LegacyAnalyzerAPI
print('✓ Imports work correctly')
"
```

## Best Practices

1. **Always run scripts from repository root** or ensure they change to it
2. **Use `-m` flag** for module execution: `python3 -m tools.legacy_analyzer`
3. **Import from shared** for common infrastructure
4. **Keep tools independent** - no cross-tool imports

## Architecture Compliance

The toolkit follows this import hierarchy:

```
tools/legacy_analyzer  ──→  shared/database/adapters
tools/smf_analyzer     ──→  shared/database/adapters
tools/migration_planner ──→  (independent)

✓ Tools can import from shared
✗ Tools should NOT import from other tools
```
