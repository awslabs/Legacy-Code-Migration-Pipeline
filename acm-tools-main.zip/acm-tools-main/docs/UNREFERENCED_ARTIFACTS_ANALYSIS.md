# Finding Unreferenced Artifacts Using SMF Data

## Question

**How to get a list of unreferenced JCL, programs, copybooks etc.? Given that SMF records only record things that happen, what record type would I query and what auxiliary information do I need?**

## The Core Problem

SMF records tell you:
- ✅ What JCL ran (Type 30)
- ✅ What programs executed (Type 30, 110)
- ✅ What datasets were accessed (Type 30, 110)

SMF records **don't** tell you:
- ❌ What JCL exists but never ran
- ❌ What programs are compiled but never called
- ❌ What copybooks exist but aren't used
- ❌ What datasets exist but aren't accessed

## Solution: Inventory - Usage = Dead Code

You've hit on a fundamental limitation of SMF data - it only captures what **executed**, not what **exists**. To find unreferenced artifacts, you need a **set difference** approach.

You need **two data sources**:

### 1. Inventory Data (What exists)
Sources outside SMF:
- **JCL**: ISPF catalog listings, PDS member lists
- **Programs**: Load library catalogs (LOADLIB, STEPLIB)
- **Copybooks**: Source library catalogs
- **Datasets**: VTOC listings, catalog entries
- **DB2 objects**: System catalog tables
- **CICS resources**: CSD definitions

### 2. Usage Data (What was used)
From SMF records

## SMF Record Types for Usage Analysis

### Type 30 (Job/Step Accounting) - Primary Source

```sql
-- Jobs that executed
SELECT DISTINCT job_name, program_name
FROM smf30_identification
WHERE record_date >= '2024-01-01';

-- Datasets accessed
SELECT DISTINCT dataset_name, job_name
FROM smf30_io_activity
WHERE record_date >= '2024-01-01';

-- Programs executed
SELECT DISTINCT program_name, COUNT(*) as executions
FROM smf30_identification
WHERE program_name IS NOT NULL
GROUP BY program_name;
```

**Captures**:
- Job names (JCL that ran)
- Program names (load modules executed)
- Dataset names (files accessed)
- Step names
- User IDs

### Type 110 (CICS Transactions) - For Online Programs

```sql
-- CICS programs executed
SELECT DISTINCT program_name, transaction_id
FROM smf110_performance
WHERE record_date >= '2024-01-01';

-- CICS transactions used
SELECT DISTINCT transaction_id, COUNT(*) as executions
FROM smf110_performance
GROUP BY transaction_id;
```

**Captures**:
- CICS transaction IDs
- CICS program names
- Terminal IDs
- User IDs

### Type 64/65 (VSAM) - Dataset Activity

**Captures**:
- VSAM dataset opens/closes
- Dataset access patterns

### Type 42 (DFSMShsm) - Dataset Management

**Captures**:
- Datasets backed up (implies they're active)
- Migration activity

### Type 80/81 (RACF) - Security Events

**Captures**:
- Dataset access attempts (even failures)
- Resource access patterns

## Auxiliary Information You Need

### 1. Source Code Repository Inventory

```bash
# Extract all JCL members
ISPF 3.4 → List PDS members → Export to file

# Or via REXX/batch:
//LISTJCL  EXEC PGM=IEBLIST
//SYSPRINT DD SYSOUT=*
//DD1      DD DSN=PROD.JCL.LIB,DISP=SHR
```

**Output**: List of all JCL member names

### 2. Load Library Inventory

```bash
# List all load modules
//LISTLOAD EXEC PGM=IEBLIST
//SYSPRINT DD SYSOUT=*
//DD1      DD DSN=PROD.LOAD.LIB,DISP=SHR
```

**Output**: List of all compiled programs

### 3. Copybook Inventory

```bash
# List all copybooks
//LISTCOPY EXEC PGM=IEBLIST
//SYSPRINT DD SYSOUT=*
//DD1      DD DSN=PROD.COPY.LIB,DISP=SHR
```

### 4. Dataset Catalog

```bash
# IDCAMS LISTCAT
//LISTCAT  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  LISTCAT ENTRIES('PROD.**') ALL
/*
```

**Output**: All datasets in catalog

### 5. CICS Resource Definitions

```bash
# Extract CSD definitions
CEDA EXTRACT GROUP(*) TO(dataset)
```

**Output**: All defined CICS transactions, programs, files

### 6. DB2 Catalog

```sql
-- All DB2 tables
SELECT NAME, CREATOR, TYPE 
FROM SYSIBM.SYSTABLES;

-- All DB2 programs
SELECT NAME, TIMESTAMP 
FROM SYSIBM.SYSPLAN;
```

### 7. Static Code Analysis (For copybook usage)

Parse COBOL/PL/I source to find:
```cobol
COPY COPYBOOK1.
CALL 'PROGRAM2'.
EXEC CICS LINK PROGRAM('PROG3').
```

## Complete Analysis Workflow

### Step 1: Build Inventory Database

```sql
CREATE TABLE inventory_jcl (
    member_name VARCHAR(8),
    library_name VARCHAR(44),
    last_modified DATE,
    source TEXT
);

CREATE TABLE inventory_programs (
    program_name VARCHAR(8),
    library_name VARCHAR(44),
    link_date DATE,
    size_bytes INTEGER
);

CREATE TABLE inventory_copybooks (
    copybook_name VARCHAR(8),
    library_name VARCHAR(44)
);

CREATE TABLE inventory_datasets (
    dataset_name VARCHAR(44),
    creation_date DATE,
    last_referenced DATE,
    size_mb DECIMAL
);
```

### Step 2: Build Usage Database from SMF

```sql
CREATE TABLE usage_jcl AS
SELECT DISTINCT job_name, MAX(record_date) as last_used
FROM smf30_identification
WHERE record_date >= DATE('now', '-365 days')  -- Last year
GROUP BY job_name;

CREATE TABLE usage_programs AS
SELECT DISTINCT program_name, MAX(record_date) as last_used
FROM smf30_identification
WHERE program_name IS NOT NULL
  AND record_date >= DATE('now', '-365 days')
GROUP BY program_name;

CREATE TABLE usage_datasets AS
SELECT DISTINCT dataset_name, MAX(record_date) as last_used
FROM smf30_io_activity
WHERE record_date >= DATE('now', '-365 days')
GROUP BY dataset_name;
```

### Step 3: Find Unreferenced Artifacts

```sql
-- Unreferenced JCL (never ran in last year)
SELECT i.member_name, i.library_name, i.last_modified
FROM inventory_jcl i
LEFT JOIN usage_jcl u ON i.member_name = u.job_name
WHERE u.job_name IS NULL
ORDER BY i.last_modified;

-- Unreferenced programs (never executed)
SELECT i.program_name, i.library_name, i.link_date
FROM inventory_programs i
LEFT JOIN usage_programs u ON i.program_name = u.program_name
WHERE u.program_name IS NULL
ORDER BY i.link_date;

-- Unreferenced datasets (never accessed)
SELECT i.dataset_name, i.creation_date, i.size_mb
FROM inventory_datasets i
LEFT JOIN usage_datasets u ON i.dataset_name = u.dataset_name
WHERE u.dataset_name IS NULL
ORDER BY i.size_mb DESC;

-- Copybooks: Need static analysis
-- Find all COPY statements in source, compare to inventory
```

## Important Caveats

### 1. Time Window Matters

- 1 year of SMF data might miss quarterly/annual jobs
- Consider 2-3 years for comprehensive analysis
- Check for seasonal patterns (year-end processing, etc.)

### 2. False Positives

Artifacts might appear unused but are actually:
- **Disaster recovery** JCL (only runs during incidents)
- **Year-end** processing (runs once annually)
- **Regulatory** programs (audit, compliance)
- **Emergency** procedures
- **Development/test** artifacts in production libraries

### 3. Indirect Usage

- **Copybooks**: Used at compile time, not runtime (need source analysis)
- **Called programs**: Might be CALLed dynamically (program name in variable)
- **Include members**: JCL INCLUDE statements
- **Procs**: Referenced by JCL but not directly in SMF

### 4. Name Variations

```sql
-- Handle aliases and variations
WHERE UPPER(i.program_name) = UPPER(u.program_name)
  OR i.program_name LIKE u.program_name || '%'
```

## Recommended Approach

### Phase 1: Quick Win (SMF Only)

```sql
-- Programs that haven't run in 2+ years
SELECT program_name, MAX(record_date) as last_used
FROM smf30_identification
GROUP BY program_name
HAVING MAX(record_date) < DATE('now', '-730 days');
```

### Phase 2: Full Inventory

1. Extract library catalogs (JCL, LOAD, COPY)
2. Load into database
3. Compare with SMF usage data

### Phase 3: Static Analysis

1. Parse source code for COPY/CALL/LINK statements
2. Build dependency graph
3. Find leaf nodes (nothing references them)

### Phase 4: Validation

1. Review with business owners
2. Check for DR/compliance requirements
3. Archive (don't delete) for 90 days
4. Monitor for access attempts

## Practical Example Query

```sql
-- High-value cleanup candidates
SELECT 
    i.program_name,
    i.library_name,
    i.size_bytes / 1024 as size_kb,
    i.link_date,
    u.last_used,
    JULIANDAY('now') - JULIANDAY(COALESCE(u.last_used, i.link_date)) as days_unused
FROM inventory_programs i
LEFT JOIN usage_programs u ON i.program_name = u.program_name
WHERE u.last_used IS NULL 
   OR u.last_used < DATE('now', '-730 days')
ORDER BY i.size_bytes DESC
LIMIT 100;
```

## Summary

**SMF alone isn't enough** - you need:

1. **SMF Type 30** (primary) + **Type 110** (CICS) for usage data
2. **Library catalogs** for inventory data
3. **Static code analysis** for copybook/include dependencies
4. **Business validation** to avoid deleting critical but infrequent code

The analysis period should be **2-3 years minimum** to avoid false positives from infrequent but legitimate workloads.

## Implementation Considerations for SMF Toolkit

### New Components Needed

1. **Inventory Loader** - Load mainframe catalog data into database
2. **Usage Analyzer** - Extract usage patterns from SMF records
3. **Artifact Analyzer** - Compare inventory vs usage
4. **Dependency Parser** - Static analysis of source code
5. **Reporting Engine** - Generate cleanup recommendations

### Database Schema Extensions

```sql
-- Inventory tables
CREATE TABLE inventory_jcl (...);
CREATE TABLE inventory_programs (...);
CREATE TABLE inventory_copybooks (...);
CREATE TABLE inventory_datasets (...);

-- Usage tracking tables
CREATE TABLE usage_jcl (...);
CREATE TABLE usage_programs (...);
CREATE TABLE usage_datasets (...);

-- Dependency tracking
CREATE TABLE dependencies (
    source_artifact VARCHAR(44),
    source_type VARCHAR(20),
    target_artifact VARCHAR(44),
    target_type VARCHAR(20),
    dependency_type VARCHAR(20)  -- CALL, COPY, INCLUDE, etc.
);
```

### Query Extensions

New query categories:
- **Artifact Usage Queries**: Last used date, frequency, users
- **Dependency Queries**: What calls what, what includes what
- **Cleanup Candidate Queries**: Unused artifacts by age, size, type
- **Risk Assessment Queries**: Identify DR/compliance artifacts
