"""Command-line interface for configuration management.

Usage:
    python -m config validate [--config-dir PATH]
    python -m config show [--config-dir PATH] [--type TYPE] [--key KEY]
    python -m config list-patterns [--config-dir PATH] [--risk-level LEVEL]
    python -m config info [--config-dir PATH] [--environment ENV]
"""

import sys
import argparse
import json
from pathlib import Path
from .config_loader import load_config, validate_config, ConfigValidationError


def cmd_validate(args):
    """Validate configuration files."""
    try:
        config_dir = args.config_dir or None
        validate_config(config_dir)
        print("✓ All configuration files are valid")
        print("  - config.yaml (system)")
        print("  - queries.yaml (queries)")
        print("  - inventory.yaml (inventory)")
        return 0
    except ConfigValidationError as e:
        print(f"✗ Configuration validation failed:")
        print(f"  {e}")
        return 1
    except FileNotFoundError as e:
        print(f"✗ Configuration files not found:")
        print(f"  {e}")
        return 1
    except Exception as e:
        print(f"✗ Error validating configuration:")
        print(f"  {e}")
        return 1


def cmd_show(args):
    """Show configuration values."""
    try:
        config = load_config(args.config_dir, args.environment)
        
        # Determine which config to show
        config_type = args.type or 'all'
        
        if args.key:
            # Show specific key from specific config type
            if config_type == 'all':
                print("Error: Must specify --type when using --key")
                return 1
            
            value = config.get(config_type, args.key)
            if value is None:
                print(f"Key '{args.key}' not found in {config_type} configuration")
                return 1
            
            if isinstance(value, (dict, list)):
                print(json.dumps(value, indent=2))
            else:
                print(value)
        else:
            # Show entire config(s)
            if config_type == 'all':
                all_config = config.get_all()
                print(json.dumps(all_config, indent=2))
            elif config_type == 'system':
                print(json.dumps(config.system, indent=2))
            elif config_type == 'queries':
                print(json.dumps(config.queries, indent=2))
            elif config_type == 'inventory':
                print(json.dumps(config.inventory, indent=2))
            else:
                print(f"Invalid config type: {config_type}")
                return 1
        
        return 0
    except Exception as e:
        print(f"✗ Error loading configuration:")
        print(f"  {e}")
        return 1


def cmd_list_patterns(args):
    """List risk patterns."""
    try:
        config = load_config(args.config_dir, args.environment)
        
        risk_level = args.risk_level or 'all'
        
        if risk_level in ['high', 'all']:
            print("\nHigh Risk Patterns:")
            print("-" * 80)
            patterns = config.get_risk_patterns('high_risk')
            for p in patterns:
                print(f"  {p['pattern']:20s} - {p['description']}")
                print(f"  {'':20s}   Reason: {p['reason']}")
                print()
        
        if risk_level in ['medium', 'all']:
            print("\nMedium Risk Patterns:")
            print("-" * 80)
            patterns = config.get_risk_patterns('medium_risk')
            for p in patterns:
                print(f"  {p['pattern']:20s} - {p['description']}")
                print(f"  {'':20s}   Reason: {p['reason']}")
                print()
        
        return 0
    except Exception as e:
        print(f"✗ Error loading configuration:")
        print(f"  {e}")
        return 1


def cmd_info(args):
    """Show configuration information."""
    try:
        config = load_config(args.config_dir, args.environment)
        
        print("\nConfiguration Information")
        print("=" * 80)
        print(f"Environment: {config.environment}")
        print(f"Config Directory: {config.config_dir}")
        print()
        
        print("System Configuration (config.yaml):")
        print(f"  Log Level: {config.get('system', 'logging.level')}")
        print(f"  Batch Size: {config.get('system', 'performance.batch_size')}")
        print(f"  Max Workers: {config.get('system', 'performance.max_workers')}")
        print()
        
        print("Query Configuration (queries.yaml):")
        print(f"  Default Analysis Window: {config.get_analysis_window()} days")
        print(f"  Min Executions: {config.get_usage_threshold('min_executions')}")
        print(f"  Min Dataset Accesses: {config.get_usage_threshold('min_dataset_accesses')}")
        print(f"  Max Recommendations: {config.get_cleanup_threshold('max_recommendations')}")
        print()
        
        print("Risk Patterns:")
        high_risk = config.get_risk_patterns('high_risk')
        medium_risk = config.get_risk_patterns('medium_risk')
        print(f"  High Risk: {len(high_risk)} patterns")
        print(f"  Medium Risk: {len(medium_risk)} patterns")
        print()
        
        print("Inventory Configuration (inventory.yaml):")
        languages = config.get('inventory', 'static_analysis.enabled_languages', [])
        print(f"  Enabled Languages: {', '.join(languages)}")
        print(f"  Parallel Processing: {config.get('inventory', 'static_analysis.parallel_processing')}")
        print()
        
        print("Features:")
        features = config.get('system', 'features', {})
        for feature, enabled in features.items():
            status = "✓" if enabled else "✗"
            print(f"  {status} {feature}")
        print()
        
        return 0
    except Exception as e:
        print(f"✗ Error loading configuration:")
        print(f"  {e}")
        return 1


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='Configuration management for artifact analysis',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Validate command
    validate_parser = subparsers.add_parser(
        'validate',
        help='Validate configuration files'
    )
    validate_parser.add_argument('--config-dir', help='Path to configuration directory')
    validate_parser.add_argument('--environment', choices=['development', 'test', 'production'], 
                                 default='production', help='Environment name')
    
    # Show command
    show_parser = subparsers.add_parser(
        'show',
        help='Show configuration values'
    )
    show_parser.add_argument('--config-dir', help='Path to configuration directory')
    show_parser.add_argument('--environment', choices=['development', 'test', 'production'], 
                            default='production', help='Environment name')
    show_parser.add_argument('--type', choices=['system', 'queries', 'inventory', 'all'],
                            help='Configuration type to show')
    show_parser.add_argument(
        '--key',
        help='Specific configuration key to show (dot notation, requires --type)'
    )
    
    # List patterns command
    patterns_parser = subparsers.add_parser(
        'list-patterns',
        help='List risk patterns'
    )
    patterns_parser.add_argument('--config-dir', help='Path to configuration directory')
    patterns_parser.add_argument('--environment', choices=['development', 'test', 'production'], 
                                default='production', help='Environment name')
    patterns_parser.add_argument(
        '--risk-level',
        choices=['high', 'medium', 'all'],
        default='all',
        help='Risk level to show'
    )
    
    # Info command
    info_parser = subparsers.add_parser(
        'info',
        help='Show configuration information'
    )
    info_parser.add_argument('--config-dir', help='Path to configuration directory')
    info_parser.add_argument('--environment', choices=['development', 'test', 'production'], 
                            default='production', help='Environment name')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    # Execute command
    if args.command == 'validate':
        return cmd_validate(args)
    elif args.command == 'show':
        return cmd_show(args)
    elif args.command == 'list-patterns':
        return cmd_list_patterns(args)
    elif args.command == 'info':
        return cmd_info(args)
    else:
        parser.print_help()
        return 1


if __name__ == '__main__':
    sys.exit(main())
