# Artifact Analysis Configuration

This directory contains configuration files for the Artifact Lifecycle Analysis system.

## Configuration File

The main configuration file is `artifact_analysis.yaml`, which controls all aspects of the artifact analysis system.

## Configuration Sections

### 1. Analysis Window Settings

Controls the time period for analyzing SMF data:

```yaml
analysis_window:
  default_window_days: 365  # Default: 1 year
  windows:
    short_term: 90          # 3 months
    standard: 365           # 1 year
    long_term: 730          # 2 years
    extended: 1095          # 3 years
```

**Usage:**
- `default_window_days`: Default number of days of SMF data to analyze
- `windows`: Predefined analysis windows for different scenarios

### 2. Usage Threshold Settings

Minimum usage counts to consider artifacts as "active":

```yaml
usage_thresholds:
  min_executions: 1                 # Minimum executions for JCL/programs
  min_dataset_accesses: 1           # Minimum accesses for datasets
  min_copybook_references: 1        # Minimum references for copybooks
  min_missing_executions: 5         # Threshold for missing artifact reporting
  min_program_size_kb: 0            # Minimum program size to report
  min_dataset_size_mb: 0            # Minimum dataset size to report
```

**Usage:**
- Set higher thresholds to focus on frequently used artifacts
- Set to 0 to include all artifacts regardless of size

### 3. Risk Classification Patterns

Patterns used to classify artifacts by risk level:

```yaml
risk_patterns:
  high_risk:
    - pattern: "DR%"
      description: "Disaster Recovery procedures"
      reason: "Critical for business continuity"
  
  medium_risk:
    - pattern: "MONTH%"
      description: "Monthly processing"
      reason: "Periodic processing - verify schedule"
```

**Usage:**
- Add patterns matching your organization's naming conventions
- Patterns use SQL LIKE syntax (% = wildcard)
- High risk artifacts are flagged for extra review before removal

**Default High Risk Patterns:**
- `DR%` - Disaster Recovery
- `YEAREND%` - Year-end processing
- `AUDIT%` - Audit and compliance
- `BACKUP%` - Backup procedures
- `EMERGENCY%` - Emergency procedures
- `RECOVERY%` - Recovery procedures
- `COMPLIANCE%` - Compliance reporting
- `REGULATORY%` - Regulatory reporting
- `SOX%` - Sarbanes-Oxley compliance
- `HIPAA%` - HIPAA compliance
- `PCI%` - PCI compliance
- `%CRITICAL%` - Explicitly marked as critical

**Default Medium Risk Patterns:**
- `MONTH%` - Monthly processing
- `QUARTER%` - Quarterly processing
- `ANNUAL%` - Annual processing
- `REPORT%` - Reporting procedures
- `BATCH%` - Batch processing
- `INTERFACE%` - Interface programs
- `CONVERSION%` - Data conversion
- `%TEST%` - Test artifacts
- `%UTIL%` - Utility programs

### 4. Cleanup Recommendation Settings

Controls how cleanup recommendations are prioritized:

```yaml
cleanup_thresholds:
  priority_weights:
    size_weight: 40           # Weight for artifact size
    age_weight: 30            # Weight for time since last use
    risk_weight: 20           # Weight for risk level
    dependency_weight: 10     # Weight for dependency count
  
  risk_scores:
    LOW: 100                  # Low risk = highest cleanup priority
    MEDIUM: 50                # Medium risk = moderate priority
    HIGH: 0                   # High risk = lowest priority
```

**Priority Calculation:**
The system calculates a priority score for each artifact using:
```
priority = (size_score * size_weight) + 
           (age_score * age_weight) + 
           (risk_score * risk_weight) + 
           (dependency_score * dependency_weight)
```

**Note:** Priority weights must sum to 100.

### 5. Artifact Naming Conventions

Patterns for identifying artifact types:

```yaml
naming_conventions:
  libraries:
    production:
      - "PROD.%"
      - "%.PROD.%"
    test:
      - "TEST.%"
      - "%.TEST.%"
```

**Usage:**
- Customize patterns to match your organization's naming standards
- Used for filtering and categorizing artifacts in reports

### 6. Export Settings

Controls output format and content:

```yaml
export_settings:
  default_format: "csv"
  formats:
    - csv
    - json
    - markdown
    - html
  
  csv:
    delimiter: ","
    quote_char: "\""
    include_header: true
    date_format: "%Y-%m-%d"
```

**Supported Formats:**
- **CSV**: Comma-separated values for Excel/spreadsheet import
- **JSON**: Structured data for programmatic processing
- **Markdown**: Human-readable reports with tables
- **HTML**: Web-based reports (future)

### 7. Environment-Specific Overrides

Different settings for different environments:

```yaml
environments:
  development:
    analysis_window:
      default_window_days: 90
    cleanup_thresholds:
      max_recommendations: 50
  
  production:
    analysis_window:
      default_window_days: 365
    cleanup_thresholds:
      max_recommendations: 200
```

**Usage:**
Set the environment using the `ARTIFACT_ANALYSIS_ENV` environment variable:
```bash
export ARTIFACT_ANALYSIS_ENV=development
python -m legacy_analyzer analyze ...
```

**Available Environments:**
- `development`: Shorter analysis windows, fewer recommendations
- `test`: Moderate settings for testing
- `production`: Full analysis with comprehensive recommendations

### 8. Feature Flags

Enable or disable specific features:

```yaml
features:
  enable_static_analysis: true
  enable_dependency_tracking: true
  enable_risk_assessment: true
  enable_cleanup_recommendations: true
  enable_lifecycle_tracking: true
  enable_trend_analysis: false
  enable_notifications: false
```

**Usage:**
- Disable features you don't need to improve performance
- Enable trend analysis when you have historical data

### 9. Performance Settings

Controls performance-related behavior:

```yaml
performance:
  batch_size: 1000              # Batch size for database operations
  enable_caching: true          # Enable query result caching
  cache_ttl_seconds: 3600       # Cache time-to-live
  max_workers: 4                # Parallel workers for analysis
  db_pool_size: 5               # Database connection pool size
  query_timeout: 300            # Query timeout in seconds
```

**Tuning Tips:**
- Increase `batch_size` for faster bulk operations
- Increase `max_workers` on multi-core systems
- Increase `db_pool_size` for concurrent queries
- Disable `enable_caching` if memory is limited

### 10. Logging Settings

Controls logging behavior:

```yaml
logging:
  level: "INFO"                 # DEBUG, INFO, WARNING, ERROR, CRITICAL
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  log_to_file: true
  log_file: "logs/artifact_analysis.log"
  log_to_console: true
```

**Log Levels:**
- `DEBUG`: Detailed diagnostic information
- `INFO`: General informational messages (default)
- `WARNING`: Warning messages for potential issues
- `ERROR`: Error messages for failures
- `CRITICAL`: Critical errors requiring immediate attention

## Using Configuration in Code

### Loading Configuration

```python
from config import load_config, get_config

# Load configuration (first time)
config = load_config()

# Get configuration instance (subsequent calls)
config = get_config()
```

### Accessing Configuration Values

```python
# Get analysis window
days = config.get_analysis_window('standard')  # Returns 365

# Get usage threshold
min_exec = config.get_usage_threshold('min_executions')  # Returns 1

# Get risk patterns
high_risk = config.get_high_risk_patterns()  # Returns list of patterns

# Get any configuration value using dot notation
value = config.get('cleanup_thresholds.max_recommendations', default=100)

# Check if feature is enabled
if config.is_feature_enabled('enable_static_analysis'):
    # Perform static analysis
    pass
```

### Environment-Specific Configuration

```python
# Load configuration for specific environment
config = load_config(environment='development')

# Or set via environment variable
import os
os.environ['ARTIFACT_ANALYSIS_ENV'] = 'development'
config = load_config()
```

### Validating Configuration

```python
from config import validate_config

try:
    validate_config('config/artifact_analysis.yaml')
    print("Configuration is valid")
except Exception as e:
    print(f"Configuration error: {e}")
```

## Configuration Validation

The system validates configuration on load:

1. **Analysis Window**: Must be between 1 and 3650 days
2. **Priority Weights**: Must sum to exactly 100
3. **Usage Thresholds**: Must be between 0 and 1000
4. **Required Fields**: All required fields must be present
5. **Data Types**: Values must be correct type (int, string, etc.)

## Customization Guide

### Adding New Risk Patterns

1. Edit `artifact_analysis.yaml`
2. Add pattern to `risk_patterns.high_risk` or `risk_patterns.medium_risk`:

```yaml
risk_patterns:
  high_risk:
    - pattern: "CUSTOM%"
      description: "Custom critical pattern"
      reason: "Your reason here"
```

### Adjusting Analysis Window

For longer historical analysis:

```yaml
analysis_window:
  default_window_days: 730  # 2 years instead of 1
```

### Changing Priority Weights

To prioritize size over age:

```yaml
cleanup_thresholds:
  priority_weights:
    size_weight: 60      # Increased from 40
    age_weight: 20       # Decreased from 30
    risk_weight: 15      # Decreased from 20
    dependency_weight: 5 # Decreased from 10
```

**Remember:** Weights must sum to 100!

### Adding Custom Naming Conventions

```yaml
naming_conventions:
  libraries:
    custom_env:
      - "CUSTOM.%"
      - "%.CUSTOM.%"
```

## Best Practices

1. **Start Conservative**: Use default settings initially
2. **Adjust Gradually**: Make small changes and observe results
3. **Document Changes**: Comment why you changed settings
4. **Test in Development**: Test configuration changes in dev environment first
5. **Version Control**: Keep configuration in version control
6. **Backup**: Keep backup of working configuration
7. **Review Regularly**: Review and update patterns as naming conventions change

## Troubleshooting

### Configuration Not Found

**Error:** `Configuration file not found`

**Solution:** Ensure `config/artifact_analysis.yaml` exists in workspace root

### Validation Errors

**Error:** `Priority weights must sum to 100`

**Solution:** Adjust weights in `cleanup_thresholds.priority_weights` to sum to 100

### Environment Not Applied

**Issue:** Environment-specific settings not taking effect

**Solution:** Set `ARTIFACT_ANALYSIS_ENV` environment variable:
```bash
export ARTIFACT_ANALYSIS_ENV=development
```

### Invalid YAML Syntax

**Error:** `Invalid YAML in configuration file`

**Solution:** Check YAML syntax:
- Proper indentation (use spaces, not tabs)
- Quoted strings with special characters
- Valid list and dictionary syntax

## Examples

### Example 1: Conservative Analysis

For initial analysis with high confidence:

```yaml
analysis_window:
  default_window_days: 730  # 2 years

usage_thresholds:
  min_executions: 5         # Only report if used 5+ times
  min_program_size_kb: 100  # Only report programs >= 100KB
```

### Example 2: Aggressive Cleanup

For aggressive cleanup with more recommendations:

```yaml
analysis_window:
  default_window_days: 365  # 1 year

usage_thresholds:
  min_executions: 1         # Report all unused

cleanup_thresholds:
  max_recommendations: 500  # More recommendations
  priority_weights:
    size_weight: 60         # Prioritize large artifacts
    age_weight: 20
    risk_weight: 15
    dependency_weight: 5
```

### Example 3: Risk-Focused Analysis

For risk-aware cleanup:

```yaml
cleanup_thresholds:
  priority_weights:
    size_weight: 20
    age_weight: 20
    risk_weight: 50         # Heavily weight risk
    dependency_weight: 10
```

## Support

For questions or issues with configuration:

1. Check this README
2. Review `artifact_analysis.yaml` comments
3. Validate configuration: `python -m config.config_loader`
4. Check logs in `logs/artifact_analysis.log`

## Version History

- **v1.0**: Initial configuration system
  - Analysis window settings
  - Risk patterns
  - Cleanup thresholds
  - Export settings
  - Environment overrides
