# Configuration Examples

This directory contains example configuration files for different use cases and scenarios.

## Available Examples

### 1. Small Project (`small_project.yaml`)

**Use Case**: Analyzing small codebases (< 1000 programs) with limited resources

**Key Features**:
- Single-threaded processing
- Reduced flow depth for faster analysis
- Smaller migration packages
- Simplified visualization
- Lower memory requirements

**When to Use**:
- Proof of concept projects
- Small legacy applications
- Limited hardware resources
- Quick analysis needs

**Example Usage**:
```bash
python -m legacy_analyzer --config config/examples/small_project.yaml analyze --source-dir src/
```

---

### 2. Large Enterprise (`large_enterprise.yaml`)

**Use Case**: Analyzing large mainframe systems (10,000+ programs) with high-performance requirements

**Key Features**:
- Multi-threaded processing (16 workers)
- Deep flow analysis (depth 15)
- Large migration packages
- All language parsers enabled
- Extensive caching (10 GB)
- SMF integration enabled
- Comprehensive reporting

**When to Use**:
- Enterprise mainframe migrations
- Large-scale modernization projects
- High-performance analysis requirements
- Complete system documentation

**Example Usage**:
```bash
python -m legacy_analyzer --config config/examples/large_enterprise.yaml analyze --source-dir /mainframe/source/
```

---

### 3. Migration-Focused (`migration_focused.yaml`)

**Use Case**: Migration planning with emphasis on packages and dependencies

**Key Features**:
- Strict package constraints (self-contained)
- High emphasis on dependency tracking
- Circular dependency detection
- SMF-based prioritization
- Migration wave generation
- Comprehensive dependency visualization

**When to Use**:
- Planning migration waves
- Creating migration packages
- Dependency analysis
- Risk assessment for migration
- Prioritizing migration order

**Example Usage**:
```bash
python -m legacy_analyzer --config config/examples/migration_focused.yaml package create --name "Wave 1" --seeds PAYROLL1,BILLING1
```

---

## Configuration File Structure

All configuration files follow the same structure:

```yaml
analysis:          # Analysis behavior settings
complexity:        # Complexity calculation settings
packages:          # Migration package settings
parsers:           # Language parser settings
dependencies:      # Dependency tracking settings
visualization:     # Graph and diagram settings
reporting:         # Report generation settings
cache:             # Caching settings
database:          # Database connection settings
logging:           # Logging configuration
performance:       # Performance tuning
smf:               # SMF integration (optional)
discovery:         # File discovery settings
validation:        # Validation rules
```

## Customizing Configurations

### Option 1: Copy and Modify

Copy an example that matches your use case and modify it:

```bash
cp config/examples/small_project.yaml config/my_project.yaml
# Edit config/my_project.yaml
python -m legacy_analyzer --config config/my_project.yaml analyze
```

### Option 2: Override Specific Settings

Use the default configuration and override specific settings:

```bash
python -m legacy_analyzer \
    --config config/legacy_analyzer.yaml \
    --set analysis.max_workers=8 \
    --set packages.max_artifacts=200 \
    analyze
```

### Option 3: Environment-Specific Overrides

The default configuration includes environment-specific overrides:

```bash
# Use development settings
export LEGACY_ANALYZER_ENV=dev
python -m legacy_analyzer analyze

# Use production settings
export LEGACY_ANALYZER_ENV=prod
python -m legacy_analyzer analyze
```

## Key Configuration Parameters

### Analysis Settings

- `max_flow_depth`: How deep to traverse program calls (5-15)
- `enable_circular_detection`: Detect circular dependencies (true/false)
- `parallel_processing`: Use multiple CPU cores (true/false)
- `max_workers`: Number of parallel workers (1-16)

### Complexity Settings

- `thresholds`: Complexity tier boundaries (low/medium/high)
- `weights`: Importance of LOC/cyclomatic/dependencies (sum to 1.0)
- `god_program_threshold`: Threshold for identifying overly complex programs

### Package Settings

- `max_artifacts`: Maximum artifacts per package
- `max_loc`: Maximum lines of code per package
- `max_complexity`: Maximum complexity score per package
- `allow_external_deps`: Allow packages with external dependencies
- `optimization_strategy`: How to optimize package boundaries

### Parser Settings

- `extensions`: File extensions to recognize
- `encoding`: Character encoding (cp037 for EBCDIC, utf-8 for ASCII)
- `fallback_encoding`: Alternative encoding if primary fails

### Performance Settings

- `batch_size`: Number of records to process at once
- `query_cache`: Cache query results (true/false)
- `memory_limit_mb`: Maximum memory for operations
- `show_progress`: Display progress indicators

## Common Scenarios

### Scenario 1: Quick Analysis

Use `small_project.yaml` with minimal settings:
- Single-threaded
- No caching
- Simplified visualization

### Scenario 2: Complete Documentation

Use `large_enterprise.yaml` with all features:
- All parsers enabled
- All report formats
- Comprehensive visualization
- SMF integration

### Scenario 3: Migration Planning

Use `migration_focused.yaml` with strict constraints:
- Self-contained packages
- Dependency emphasis
- Usage-based prioritization
- Wave generation

### Scenario 4: Performance Testing

Create custom config with:
- High worker count
- Large batch sizes
- Extensive caching
- Minimal reporting

## Validation

Validate your configuration before running:

```bash
python -m legacy_analyzer --config config/my_project.yaml validate-config
```

## Troubleshooting

### Configuration Not Found

```bash
# Use absolute path
python -m legacy_analyzer --config /full/path/to/config.yaml

# Or relative to current directory
python -m legacy_analyzer --config ./config/my_project.yaml
```

### Invalid Configuration

```bash
# Check for syntax errors
python -m legacy_analyzer --config config/my_project.yaml validate-config

# View effective configuration
python -m legacy_analyzer --config config/my_project.yaml show-config
```

### Performance Issues

- Reduce `max_workers` if CPU usage is too high
- Reduce `max_flow_depth` if analysis is too slow
- Increase `batch_size` for faster database operations
- Enable `cache` for repeated analyses

### Memory Issues

- Reduce `memory_limit_mb`
- Reduce `max_nodes` in visualization
- Disable `query_cache`
- Process in smaller batches

## Best Practices

1. **Start Small**: Begin with `small_project.yaml` and scale up
2. **Enable Caching**: Always enable caching for repeated analyses
3. **Tune Workers**: Set `max_workers` to number of CPU cores
4. **Validate First**: Always validate configuration before running
5. **Monitor Resources**: Watch CPU and memory usage during analysis
6. **Use Environments**: Leverage environment-specific overrides
7. **Document Changes**: Comment your customizations
8. **Version Control**: Keep configurations in version control

## Additional Resources

- [Main Configuration](../legacy_analyzer.yaml) - Default configuration with all options
- [Getting Started Guide](../../docs/GETTING_STARTED.md) - Quick start guide
- [CLI Reference](../../docs/CLI_REFERENCE.md) - Command-line options
- [API Reference](../../docs/API_REFERENCE.md) - Python API documentation
