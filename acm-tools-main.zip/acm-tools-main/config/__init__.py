"""Configuration management for artifact lifecycle analysis."""

from .config_loader import ConfigManager, get_config, load_config, validate_config

__all__ = ['ConfigManager', 'get_config', 'load_config', 'validate_config']
