"""Example usage of the configuration system.

This script demonstrates how to use the configuration loader in your code.
"""

from config import load_config, get_config


def example_basic_usage():
    """Basic configuration usage."""
    print("=" * 80)
    print("Example 1: Basic Configuration Usage")
    print("=" * 80)
    
    # Load configuration (first time)
    config = load_config()
    
    # Get analysis window
    days = config.get('analysis_window.default_window_days')
    print(f"Analysis window: {days} days")
    
    # Get usage thresholds
    min_exec = config.get_usage_threshold('min_executions')
    print(f"Minimum executions: {min_exec}")
    
    # Get cleanup settings
    max_recs = config.get_cleanup_threshold('max_recommendations')
    print(f"Maximum recommendations: {max_recs}")
    
    print()


def example_risk_patterns():
    """Working with risk patterns."""
    print("=" * 80)
    print("Example 2: Risk Pattern Usage")
    print("=" * 80)
    
    config = get_config()
    
    # Get high risk patterns
    high_risk = config.get_high_risk_patterns()
    print(f"High risk patterns ({len(high_risk)}):")
    for pattern in high_risk[:3]:  # Show first 3
        print(f"  - {pattern}")
    
    # Get medium risk patterns
    medium_risk = config.get_medium_risk_patterns()
    print(f"\nMedium risk patterns ({len(medium_risk)}):")
    for pattern in medium_risk[:3]:  # Show first 3
        print(f"  - {pattern}")
    
    print()


def example_feature_flags():
    """Using feature flags."""
    print("=" * 80)
    print("Example 3: Feature Flags")
    print("=" * 80)
    
    config = get_config()
    
    # Check if features are enabled
    if config.is_feature_enabled('enable_static_analysis'):
        print("✓ Static analysis is enabled")
    
    if config.is_feature_enabled('enable_dependency_tracking'):
        print("✓ Dependency tracking is enabled")
    
    if config.is_feature_enabled('enable_risk_assessment'):
        print("✓ Risk assessment is enabled")
    
    if not config.is_feature_enabled('enable_trend_analysis'):
        print("✗ Trend analysis is disabled")
    
    print()


def main():
    """Run all examples."""
    print("\nConfiguration System Usage Examples")
    print("=" * 80)
    print()
    
    example_basic_usage()
    example_risk_patterns()
    example_feature_flags()
    
    print("=" * 80)
    print("Examples complete!")
    print("=" * 80)


if __name__ == '__main__':
    main()
