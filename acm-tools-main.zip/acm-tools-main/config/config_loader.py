"""Configuration loader for artifact lifecycle analysis system.

This module provides functionality to load, validate, and access configuration
settings from multiple YAML files:
- config.yaml: System-wide settings (logging, performance, features)
- queries.yaml: Query defaults and parameters
- inventory.yaml: Inventory loading and static analysis settings
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass


@dataclass
class ConfigValidationError(Exception):
    """Raised when configuration validation fails."""
    message: str
    field: str
    
    def __str__(self):
        return f"Configuration validation error in '{self.field}': {self.message}"


class ConfigManager:
    """Manages configuration loading from multiple files."""
    
    def __init__(self, config_dir: Optional[str] = None, environment: str = "production"):
        """Initialize configuration manager.
        
        Args:
            config_dir: Path to configuration directory. If None, uses default location.
            environment: Environment name (development, test, production)
        """
        self.environment = environment
        self.config_dir = Path(config_dir) if config_dir else self._get_default_config_dir()
        
        # Configuration caches
        self._system: Optional[Dict[str, Any]] = None
        self._queries: Optional[Dict[str, Any]] = None
        self._inventory: Optional[Dict[str, Any]] = None
        
        # Load and validate all configurations
        self._load_all()
    
    def _get_default_config_dir(self) -> Path:
        """Get default configuration directory path."""
        # Try to find config relative to this file
        current_dir = Path(__file__).parent
        
        if (current_dir / "config.yaml").exists():
            return current_dir
        
        # Try workspace root
        workspace_root = current_dir.parent
        config_dir = workspace_root / "config"
        
        if (config_dir / "config.yaml").exists():
            return config_dir
        
        raise FileNotFoundError(
            "Configuration directory not found. Please ensure config/ directory exists with config.yaml"
        )
    
    def _load_yaml(self, filename: str) -> Dict[str, Any]:
        """Load YAML configuration file.
        
        Args:
            filename: Name of the YAML file to load
            
        Returns:
            Parsed configuration dictionary
        """
        path = self.config_dir / filename
        
        try:
            with open(path, 'r') as f:
                return yaml.safe_load(f) or {}
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Configuration file not found: {path}"
            )
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in {filename}: {e}")
    
    def _load_all(self) -> None:
        """Load all configuration files."""
        try:
            # Load system configuration
            self._system = self._load_yaml("config.yaml")
            
            # Load queries configuration
            self._queries = self._load_yaml("queries.yaml")
            
            # Load inventory configuration
            self._inventory = self._load_yaml("inventory.yaml")
            
            # Apply environment-specific overrides to system config
            self._apply_environment_overrides()
            
            # Validate all configurations
            self._validate()
            
        except Exception as e:
            raise RuntimeError(f"Failed to load configuration: {e}")
    
    @property
    def system(self) -> Dict[str, Any]:
        """Get system-wide configuration."""
        if self._system is None:
            raise RuntimeError("System configuration not loaded")
        return self._system
    
    @property
    def queries(self) -> Dict[str, Any]:
        """Get queries configuration."""
        if self._queries is None:
            raise RuntimeError("Queries configuration not loaded")
        return self._queries
    
    @property
    def inventory(self) -> Dict[str, Any]:
        """Get inventory configuration."""
        if self._inventory is None:
            raise RuntimeError("Inventory configuration not loaded")
        return self._inventory
    
    def _apply_environment_overrides(self) -> None:
        """Apply environment-specific configuration overrides to system config."""
        if 'environments' not in self._system:
            return
        
        env_config = self._system['environments'].get(self.environment)
        if not env_config:
            return
        
        # Deep merge environment config into system config
        self._deep_merge(self._system, env_config)
    
    def _deep_merge(self, base: Dict, override: Dict) -> None:
        """Deep merge override dict into base dict."""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value
    
    def _validate(self) -> None:
        """Validate configuration values."""
        # Validate queries configuration
        queries_validation = self._queries.get('validation', {})
        
        # Validate analysis windows
        if 'analysis_windows' in queries_validation:
            window_rules = queries_validation['analysis_windows']
            default_days = self._queries.get('analysis_windows', {}).get('default', 365)
            
            if default_days < window_rules.get('min_days', 1):
                raise ConfigValidationError(
                    f"default analysis window must be >= {window_rules['min_days']} days",
                    "queries.analysis_windows.default"
                )
            
            if default_days > window_rules.get('max_days', 3650):
                raise ConfigValidationError(
                    f"default analysis window must be <= {window_rules['max_days']} days",
                    "queries.analysis_windows.default"
                )
        
        # Validate priority weights sum to 100
        if 'cleanup' in queries_validation:
            weights = self._queries.get('cleanup', {}).get('priority_weights', {})
            if weights:
                total = sum(weights.values())
                expected = queries_validation['cleanup'].get('priority_weights_sum', 100)
                if total != expected:
                    raise ConfigValidationError(
                        f"Priority weights must sum to {expected}, got {total}",
                        "queries.cleanup.priority_weights"
                    )
        
        # Validate usage thresholds
        if 'usage_thresholds' in queries_validation:
            threshold_rules = queries_validation['usage_thresholds']
            min_val = threshold_rules.get('min_value', 0)
            max_val = threshold_rules.get('max_value', 1000)
            
            thresholds = self._queries.get('usage_thresholds', {})
            for key, value in thresholds.items():
                if isinstance(value, (int, float)):
                    if value < min_val or value > max_val:
                        raise ConfigValidationError(
                            f"{key} must be between {min_val} and {max_val}",
                            f"queries.usage_thresholds.{key}"
                        )
    
    def get(self, config_type: str, key: str, default: Any = None) -> Any:
        """Get configuration value by config type and dot-notation key.
        
        Args:
            config_type: Configuration type ('system', 'queries', 'inventory')
            key: Configuration key in dot notation
            default: Default value if key not found
        
        Returns:
            Configuration value or default
        
        Examples:
            >>> config.get('queries', 'analysis_windows.default')
            365
            >>> config.get('system', 'logging.level')
            'INFO'
        """
        # Get the appropriate config dict
        if config_type == 'system':
            config_dict = self._system
        elif config_type == 'queries':
            config_dict = self._queries
        elif config_type == 'inventory':
            config_dict = self._inventory
        else:
            raise ValueError(f"Invalid config type: {config_type}")
        
        # Navigate through dot notation
        keys = key.split('.')
        value = config_dict
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def get_analysis_window(self, window_type: str = 'default') -> int:
        """Get analysis window in days.
        
        Args:
            window_type: Type of window (default, recent, standard, comprehensive, extended)
        
        Returns:
            Number of days for the analysis window
        """
        if window_type == 'default':
            return self.get('queries', 'analysis_windows.default', 365)
        
        return self.get('queries', f'analysis_windows.presets.{window_type}', 
                       self.get('queries', 'analysis_windows.default', 365))
    
    def get_risk_patterns(self, risk_level: str) -> List[Dict[str, str]]:
        """Get risk patterns for a specific risk level.
        
        Args:
            risk_level: Risk level (high_risk, medium_risk)
        
        Returns:
            List of risk pattern dictionaries
        """
        return self.get('queries', f'risk_patterns.{risk_level}', [])
    
    def get_high_risk_patterns(self) -> List[str]:
        """Get list of high risk patterns.
        
        Returns:
            List of pattern strings
        """
        patterns = self.get_risk_patterns('high_risk')
        return [p['pattern'] for p in patterns]
    
    def get_medium_risk_patterns(self) -> List[str]:
        """Get list of medium risk patterns.
        
        Returns:
            List of pattern strings
        """
        patterns = self.get_risk_patterns('medium_risk')
        return [p['pattern'] for p in patterns]
    
    def get_cleanup_threshold(self, key: str, default: Any = None) -> Any:
        """Get cleanup threshold value.
        
        Args:
            key: Threshold key (e.g., 'max_recommendations')
            default: Default value if not found
        
        Returns:
            Threshold value
        """
        return self.get('queries', f'cleanup.{key}', default)
    
    def get_usage_threshold(self, key: str, default: Any = None) -> Any:
        """Get usage threshold value.
        
        Args:
            key: Threshold key (e.g., 'min_executions')
            default: Default value if not found
        
        Returns:
            Threshold value
        """
        return self.get('queries', f'usage_thresholds.{key}', default)
    
    def get_export_format(self, source: str = 'queries') -> str:
        """Get default export format.
        
        Args:
            source: Source of export ('queries' or 'inventory')
        
        Returns:
            Export format (csv, json, markdown)
        """
        return self.get(source, 'export.default_format', 'csv')
    
    def is_feature_enabled(self, feature: str) -> bool:
        """Check if a feature is enabled.
        
        Args:
            feature: Feature name (e.g., 'enable_static_analysis')
        
        Returns:
            True if feature is enabled
        """
        return self.get('system', f'features.{feature}', False)
    
    def get_all(self) -> Dict[str, Dict[str, Any]]:
        """Get all configuration dictionaries.
        
        Returns:
            Dictionary with system, queries, and inventory configurations
        """
        return {
            'system': self._system.copy(),
            'queries': self._queries.copy(),
            'inventory': self._inventory.copy()
        }
    
    def reload(self) -> None:
        """Reload all configuration files."""
        self._load_all()


# Global configuration instance
_config_instance: Optional[ConfigManager] = None


def load_config(config_dir: Optional[str] = None, 
                environment: Optional[str] = None) -> ConfigManager:
    """Load configuration from directory.
    
    Args:
        config_dir: Path to configuration directory
        environment: Environment name (development, test, production)
    
    Returns:
        ConfigManager instance
    """
    global _config_instance
    
    # Get environment from env var if not specified
    if environment is None:
        environment = os.environ.get('SMF_ENV', 'production')
    
    _config_instance = ConfigManager(config_dir, environment)
    return _config_instance


def get_config() -> ConfigManager:
    """Get global configuration instance.
    
    Returns:
        ConfigManager instance
    
    Raises:
        RuntimeError: If configuration not loaded yet
    """
    global _config_instance
    
    if _config_instance is None:
        # Auto-load with defaults
        _config_instance = load_config()
    
    return _config_instance


def validate_config(config_dir: Optional[str] = None) -> bool:
    """Validate configuration files.
    
    Args:
        config_dir: Path to configuration directory
    
    Returns:
        True if configuration is valid
    
    Raises:
        ConfigValidationError: If configuration is invalid
    """
    try:
        ConfigManager(config_dir)
        return True
    except (ConfigValidationError, FileNotFoundError, ValueError) as e:
        print(f"Configuration validation failed: {e}")
        raise
