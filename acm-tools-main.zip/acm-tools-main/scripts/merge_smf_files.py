#!/usr/bin/env python3
"""Merge all SMF JSON files into a single file."""

import json
import sys
from pathlib import Path


def merge_smf_files(input_dir, output_file):
    """Merge all SMF JSON files in a directory into one file.
    
    Args:
        input_dir: Directory containing SMF JSON files
        output_file: Output file path for merged data
    """
    input_path = Path(input_dir)
    
    if not input_path.exists():
        print(f"Error: Directory not found: {input_dir}")
        sys.exit(1)
    
    # Find all SMF JSON files
    smf_files = sorted(input_path.glob("smf*.json"))
    
    if not smf_files:
        print(f"Error: No SMF JSON files found in {input_dir}")
        sys.exit(1)
    
    print(f"Found {len(smf_files)} SMF files to merge:")
    for f in smf_files:
        print(f"  - {f.name}")
    
    # Merge all records
    all_records = []
    
    for smf_file in smf_files:
        print(f"\nReading {smf_file.name}...")
        try:
            with open(smf_file) as f:
                records = json.load(f)
                record_count = len(records)
                all_records.extend(records)
                print(f"  Added {record_count} records")
        except Exception as e:
            print(f"  Error reading {smf_file.name}: {e}")
            continue
    
    # Write merged file
    output_path = Path(output_file)
    print(f"\nWriting merged file: {output_path}")
    
    try:
        with open(output_path, 'w') as f:
            json.dump(all_records, f, indent=2)
        
        file_size = output_path.stat().st_size
        size_mb = file_size / (1024 * 1024)
        
        print(f"\n✓ Successfully merged {len(all_records)} records")
        print(f"  Output file: {output_path}")
        print(f"  File size: {size_mb:.1f} MB")
        
    except Exception as e:
        print(f"\nError writing merged file: {e}")
        sys.exit(1)


def main():
    if len(sys.argv) < 2:
        print("Usage: merge_smf_files.py <input_directory> [output_file]")
        print("\nExample:")
        print("  merge_smf_files.py examples/data/carddemo_smf_inventory")
        print("  merge_smf_files.py examples/data/carddemo_smf_inventory_merged.json")
        sys.exit(1)
    
    input_dir = sys.argv[1]
    
    # Default output file in same directory
    if len(sys.argv) >= 3:
        output_file = sys.argv[2]
    else:
        output_file = str(Path(input_dir) / "smf_all_carddemo.json")
    
    merge_smf_files(input_dir, output_file)


if __name__ == "__main__":
    main()
