#!/bin/bash

# Test Cost Queries
# Quick script to verify cost queries return data

set -e

DB_PATH="databases/carddemo_smf_test.db"

echo "=========================================="
echo "Testing Cost Queries"
echo "=========================================="
echo ""

if [ ! -f "$DB_PATH" ]; then
    echo "Error: Database not found: $DB_PATH"
    echo "Run ./regenerate_test_data.sh first"
    exit 1
fi

echo "Database: $DB_PATH"
echo ""

# Test MIPS Cost
echo "1. MIPS Cost Query"
echo "-------------------"
python3 -m tools.smf_analyzer.smf_queries run \
    --db "$DB_PATH" \
    --query mips_cost \
    --format table
echo ""

# Test MSU Cost
echo "2. MSU Cost Query"
echo "-------------------"
python3 -m tools.smf_analyzer.smf_queries run \
    --db "$DB_PATH" \
    --query msu_cost \
    --format table
echo ""

# Test Migration ROI
echo "3. Migration ROI Query"
echo "-------------------"
python3 -m tools.smf_analyzer.smf_queries run \
    --db "$DB_PATH" \
    --query migration_roi \
    --format table
echo ""

# Test Top CPU Consumers
echo "4. Top CPU Consumers Query"
echo "-------------------"
python3 -m tools.smf_analyzer.smf_queries run \
    --db "$DB_PATH" \
    --query top_cpu_consumers \
    --format table
echo ""

# Test Job Completion Rate
echo "5. Job Completion Rate Query"
echo "-------------------"
python3 -m tools.smf_analyzer.smf_queries run \
    --db "$DB_PATH" \
    --query job_completion_rate \
    --format table
echo ""

echo "=========================================="
echo "✓ All test queries completed"
echo "=========================================="
