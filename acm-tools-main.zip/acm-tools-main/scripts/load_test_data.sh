#!/bin/bash

# Load SMF Test Data into Database
# This script loads the generated SMF test data into a SQLite database

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Configuration
PYTHON_CMD="python3"
DATA_DIR="examples/data/carddemo_smf_inventory"
DB_FILE="databases/carddemo_smf_test.db"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}SMF Test Data Loader${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if data directory exists
if [ ! -d "$DATA_DIR" ]; then
    echo -e "${RED}Error: Data directory not found: $DATA_DIR${NC}"
    echo -e "${YELLOW}Please run ./run_smftestdata_inventory.sh first${NC}"
    exit 1
fi

# Remove existing database if it exists
if [ -f "$DB_FILE" ]; then
    echo -e "${YELLOW}Removing existing database: $DB_FILE${NC}"
    rm -f "$DB_FILE"
fi

echo -e "${YELLOW}Loading SMF test data into: $DB_FILE${NC}"
echo ""

# Load SMF Type 30 (Batch jobs) - Create schema
echo -e "${BLUE}Loading SMF Type 30 (Batch jobs)...${NC}"
$PYTHON_CMD -m tools.smf_analyzer.smf_loader load \
    --type 30 \
    --db "$DB_FILE" \
    --file "$DATA_DIR/smf30_carddemo.json" \
    --create-schema

if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to load SMF Type 30${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Loaded SMF Type 30${NC}"
echo ""

# Load SMF Type 110 (CICS transactions)
echo -e "${BLUE}Loading SMF Type 110 (CICS transactions)...${NC}"
$PYTHON_CMD -m tools.smf_analyzer.smf_loader load \
    --type 110 \
    --db "$DB_FILE" \
    --file "$DATA_DIR/smf110_carddemo.json"

if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to load SMF Type 110${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Loaded SMF Type 110${NC}"
echo ""

# Load SMF Type 14 (INPUT datasets)
echo -e "${BLUE}Loading SMF Type 14 (INPUT datasets)...${NC}"
$PYTHON_CMD -m tools.smf_analyzer.smf_loader load \
    --type 14 \
    --db "$DB_FILE" \
    --file "$DATA_DIR/smf14_carddemo.json"

if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to load SMF Type 14${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Loaded SMF Type 14${NC}"
echo ""

# Load SMF Type 15 (OUTPUT datasets)
echo -e "${BLUE}Loading SMF Type 15 (OUTPUT datasets)...${NC}"
$PYTHON_CMD -m tools.smf_analyzer.smf_loader load \
    --type 15 \
    --db "$DB_FILE" \
    --file "$DATA_DIR/smf15_carddemo.json"

if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to load SMF Type 15${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Loaded SMF Type 15${NC}"
echo ""

# Get database stats
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Loading Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "Database: ${BLUE}$DB_FILE${NC}"
echo ""

# Count records
echo -e "${YELLOW}Record counts:${NC}"
$PYTHON_CMD << EOF
import sqlite3
db = sqlite3.connect("$DB_FILE")
cursor = db.cursor()

# Get table names
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
tables = cursor.fetchall()

total = 0
for (table,) in tables:
    if table.startswith('smf'):
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = cursor.fetchone()[0]
        total += count
        print(f"  {table}: {count:,} records")

print(f"\n  Total: {total:,} records")
db.close()
EOF

echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo -e "1. View in dashboard:"
echo -e "   ${BLUE}Open http://localhost:5001${NC}"
echo -e "   ${BLUE}Select database: $DB_FILE${NC}"
echo ""
echo -e "2. Run queries:"
echo -e "   ${BLUE}python3 -m tools.smf_analyzer.smf_queries run --db $DB_FILE --query top_cpu_consumers${NC}"
echo ""

exit 0
