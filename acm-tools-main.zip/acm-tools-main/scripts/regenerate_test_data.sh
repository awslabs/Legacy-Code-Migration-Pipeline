#!/bin/bash

# Regenerate SMF Test Data with Current Dates
# This script regenerates all test data with current dates to fix empty query results

set -e  # Exit on error

echo "=========================================="
echo "SMF Test Data Regeneration"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Step 1: Clean up old data
echo -e "${YELLOW}Step 1: Cleaning up old test data...${NC}"
if [ -d "examples/data/carddemo_smf_inventory" ]; then
    echo "  Removing old JSON files..."
    rm -rf examples/data/carddemo_smf_inventory/*.json
    echo -e "  ${GREEN}✓ Old data removed${NC}"
else
    echo "  No old data to remove"
fi
echo ""

# Step 2: Generate new test data with current dates
echo -e "${YELLOW}Step 2: Generating new SMF records with current dates...${NC}"
echo "  Config: examples/config/carddemo_smf_generation_inventory.yaml"
echo "  Date range: 2025-01-01 to 2026-02-04 (current dates)"
echo ""

python3 -m tools.smf_test_data_generator \
    --config examples/config/carddemo_smf_generation_inventory.yaml \
    --verbose

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Test data generation failed${NC}"
    exit 1
fi
echo ""

# Step 3: Merge all JSON files
echo -e "${YELLOW}Step 3: Merging all SMF JSON files...${NC}"
python3 merge_smf_files.py examples/data/carddemo_smf_inventory

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ JSON merge failed${NC}"
    exit 1
fi
echo ""

# Step 4: Create fresh database
echo -e "${YELLOW}Step 4: Creating fresh test database...${NC}"
DB_PATH="databases/carddemo_smf_test.db"

if [ -f "$DB_PATH" ]; then
    echo "  Removing old database..."
    rm "$DB_PATH"
fi

echo "  Loading merged SMF data into database..."
python3 -m tools.smf_analyzer.smf_loader load \
    --db "$DB_PATH" \
    --file examples/data/carddemo_smf_inventory/smf_all_carddemo.json \
    --create-schema \
    --unified

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Database load failed${NC}"
    exit 1
fi
echo ""

# Step 5: Copy inventory data
echo -e "${YELLOW}Step 5: Copying inventory data to test database...${NC}"
./copy_inventory_to_test_db.sh

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Inventory copy failed${NC}"
    exit 1
fi
echo ""

# Step 6: Quick verification
echo -e "${YELLOW}Step 6: Quick verification...${NC}"
echo ""

echo "  Checking record counts..."
python3 -c "
import sqlite3
conn = sqlite3.connect('$DB_PATH')
cursor = conn.cursor()
cursor.execute('SELECT COUNT(*) FROM smf_records')
count = cursor.fetchone()[0]
print(f'  ✓ Total SMF records: {count}')
cursor.execute('SELECT COUNT(*) FROM inventory_programs')
count = cursor.fetchone()[0]
print(f'  ✓ Inventory programs: {count}')
conn.close()
"

echo ""
echo "=========================================="
echo -e "${GREEN}✓ Test Data Regeneration Complete!${NC}"
echo "=========================================="
echo ""
echo "Summary:"
echo "  Database: $DB_PATH"
echo "  Date range: 2025-01-01 to 2026-02-04"
echo "  Inventory: Included"
echo ""
echo "Next steps:"
echo "  1. Restart dashboard: ./restart_dashboard.sh"
echo "  2. Open browser: http://localhost:5001"
echo "  3. Test queries in dashboard"
echo ""
