#!/bin/bash

# Load SMF Test Data into Database (Unified Schema)
# This script loads SMF Type 30 and 110 data using the unified schema

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Configuration
PYTHON_CMD="python3"
DATA_DIR="examples/data/carddemo_smf_inventory"
DB_FILE="databases/carddemo_smf_test.db"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}SMF Test Data Loader (Unified Schema)${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if data directory exists
if [ ! -d "$DATA_DIR" ]; then
    echo -e "${RED}Error: Data directory not found: $DATA_DIR${NC}"
    echo -e "${YELLOW}Please run ./run_smftestdata_inventory.sh first${NC}"
    exit 1
fi

# Remove existing database if it exists
if [ -f "$DB_FILE" ]; then
    echo -e "${YELLOW}Removing existing database: $DB_FILE${NC}"
    rm -f "$DB_FILE"
fi

echo -e "${YELLOW}Loading SMF test data into: $DB_FILE${NC}"
echo -e "${BLUE}Using unified schema (smf_records table)${NC}"
echo ""

# Load all SMF records using the merged file (unified schema, no type filter)
echo -e "${BLUE}Loading all SMF records from merged file...${NC}"
echo -e "${YELLOW}Using unified schema - loading all record types${NC}"
$PYTHON_CMD -m tools.smf_analyzer.smf_loader load \
    --unified \
    --db "$DB_FILE" \
    --file "$DATA_DIR/smf_all_carddemo.json" \
    --create-schema \
    --stats

if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to load SMF records${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Loaded all SMF records${NC}"
echo ""

# Get database stats
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Loading Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "Database: ${BLUE}$DB_FILE${NC}"
echo ""

# Count records
echo -e "${YELLOW}Record counts:${NC}"
$PYTHON_CMD << 'EOF'
import sqlite3
import sys

db_file = "databases/carddemo_smf_test.db"
try:
    db = sqlite3.connect(db_file)
    cursor = db.cursor()
    
    # Check if smf_records table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='smf_records'")
    if cursor.fetchone():
        cursor.execute("SELECT record_type, COUNT(*) FROM smf_records GROUP BY record_type ORDER BY record_type")
        rows = cursor.fetchall()
        
        total = 0
        for record_type, count in rows:
            total += count
            print(f"  SMF Type {record_type}: {count:,} records")
        
        print(f"\n  Total: {total:,} records")
    else:
        print("  No smf_records table found")
    
    db.close()
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
EOF

echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo -e "1. View in dashboard:"
echo -e "   ${BLUE}Open http://localhost:5001${NC}"
echo -e "   ${BLUE}Select database: $DB_FILE${NC}"
echo ""
echo -e "2. Run queries:"
echo -e "   ${BLUE}python3 -m tools.smf_analyzer.smf_queries run --db $DB_FILE --query top_cpu_consumers${NC}"
echo ""

exit 0
