#!/bin/bash
set -e  # Exit on error

# Complete CICS Metadata Analysis Script
# This script performs a comprehensive analysis including:
# - CICS metadata discovery and loading
# - Static code analysis (COBOL, JCL, Assembler)
# - Complexity analysis
# - Report generation

# Configuration
SOURCE_DIR="${1:-./examples/code/cobol/carddemoV2}"
OUTPUT_DIR="${2:-./results/carddemoV2}"
DATABASE="$OUTPUT_DIR/analysis.db"

echo "================================================================================"
echo "  Complete CICS Metadata Analysis"
echo "================================================================================"
echo ""
echo "Configuration:"
echo "  Source:   $SOURCE_DIR"
echo "  Output:   $OUTPUT_DIR"
echo "  Database: $DATABASE"
echo ""

# Verify source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: Source directory not found: $SOURCE_DIR"
    echo ""
    echo "Usage: $0 <source-dir> <output-dir>"
    echo "Example: $0 ./my-app ./results"
    exit 1
fi

# Create directories
echo "Creating output directories..."
mkdir -p "$OUTPUT_DIR/cics"
mkdir -p "$OUTPUT_DIR/services"
mkdir -p "$OUTPUT_DIR/exports"
echo "✓ Directories created"
echo ""

# Step 1: CICS Metadata Analysis
echo "================================================================================"
echo "  Step 1: CICS Metadata Analysis"
echo "================================================================================"
echo ""
python3 examples/analyze_with_cics_metadata.py \
  --source-dir "$SOURCE_DIR" \
  --database "$DATABASE" \
  --output-dir "$OUTPUT_DIR" \
  --keep-csv "$OUTPUT_DIR/exports/cics_inventory.csv"

# Step 2: Static Code Analysis
echo ""
echo "================================================================================"
echo "  Step 2: Static Code Analysis"
echo "================================================================================"
echo ""

echo "Analyzing COBOL code..."
python3 -m legacy_analyzer analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language COBOL

echo ""
echo "Analyzing JCL code..."
python3 -m legacy_analyzer analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language JCL

echo ""
echo "Analyzing Assembler code..."
python3 -m legacy_analyzer analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language ASM

# Step 3: Complexity Analysis
echo ""
echo "================================================================================"
echo "  Step 3: Complexity Analysis"
echo "================================================================================"
echo ""

echo "Analyzing COBOL complexity..."
python3 -m legacy_analyzer complexity analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language COBOL

echo ""
echo "Analyzing Assembler complexity..."
python3 -m legacy_analyzer complexity analyze \
  --source-dir "$SOURCE_DIR" \
  --db "$DATABASE" \
  --language ASM

# Step 4: Re-detect Entry Points (now that dependencies are loaded)
echo ""
echo "================================================================================"
echo "  Step 4: Re-detect Entry Points"
echo "================================================================================"
echo ""
python3 -m legacy_analyzer flow entry-points \
  --db "$DATABASE" \
  --use-metadata \
  --format json \
  --output "$OUTPUT_DIR/entry_points_complete.json"

# Step 5: Generate Reports
echo ""
echo "================================================================================"
echo "  Step 5: Generating Reports"
echo "================================================================================"
echo ""

echo "Generating CICS transaction reports..."
python3 examples/generate_cics_reports.py \
  --database "$DATABASE" \
  --output-dir "$OUTPUT_DIR/cics" \
  --format both 2>&1 | grep -v "^Error"

echo ""
echo "Generating service grouping analysis..."
python3 examples/service_grouping_analysis.py \
  --database "$DATABASE" \
  --output-dir "$OUTPUT_DIR/services" \
  --strategy all \
  --min-confidence LOW

echo ""
echo "Generating dependency reports..."
python3 tmpscripts/generate_all_dependency_reports.py \
  "$DATABASE" \
  "$OUTPUT_DIR/dependencies"

echo ""
echo "Generating flow analysis for all entry points..."
python3 -m legacy_analyzer flow analyze \
  --all-entry-points \
  --db "$DATABASE" \
  --max-depth 10 \
  --output "$OUTPUT_DIR/flows" \
  --format json 2>&1 | tail -20

echo ""
echo "Generating call graphs..."
python3 -m legacy_analyzer flow graph \
  --db "$DATABASE" \
  --format mermaid \
  --output "$OUTPUT_DIR/dependencies/call_graph.mmd" 2>&1 | grep -v "^✓ Connected"

python3 -m legacy_analyzer flow graph \
  --db "$DATABASE" \
  --format dot \
  --output "$OUTPUT_DIR/dependencies/call_graph.dot" 2>&1 | grep -v "^✓ Connected"

# Summary
echo ""
echo "================================================================================"
echo "  Analysis Complete!"
echo "================================================================================"
echo ""
echo "Results saved to: $OUTPUT_DIR"
echo ""
echo "Generated files:"
echo "  - Entry points:     $OUTPUT_DIR/entry_points_*.json"
echo "  - CICS reports:     $OUTPUT_DIR/cics/"
echo "  - Service grouping: $OUTPUT_DIR/services/"
echo "  - Database:         $DATABASE"
echo "  - CICS inventory:   $OUTPUT_DIR/exports/cics_inventory.csv"
echo ""
echo "View results:"
echo "  1. Open HTML report:"
echo "     open $OUTPUT_DIR/cics/cics_transactions_*.html"
echo ""
echo "  2. Review service grouping:"
echo "     cat $OUTPUT_DIR/services/service_grouping_summary_*.md"
echo ""
echo "  3. Query database:"
echo "     sqlite3 $DATABASE"
echo ""
echo "  4. View entry points:"
echo "     cat $OUTPUT_DIR/entry_points_*.json | python3 -m json.tool | less"
echo ""
echo "For more information, see: docs/COMPLETE_ANALYSIS_GUIDE.md"
echo ""
