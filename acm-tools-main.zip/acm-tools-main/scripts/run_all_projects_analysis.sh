#!/bin/bash
set -e  # Exit on error

# Complete Analysis Script for Multiple Projects
# This script performs comprehensive analysis for:
# - CardDemo V2 (COBOL)
# - N-One (Natural)
# - CardDemo PLI (PL/I)
# - CBTapes File 647 (REXX)
# - CBT667 (RPG)

echo "================================================================================"
echo "  Multi-Project Legacy Code Analysis"
echo "================================================================================"
echo ""
echo "This script will analyze the following projects:"
echo "  1. CardDemo V2 (COBOL)"
echo "  2. N-One (Natural)"
echo "  3. CardDemo PLI (PL/I)"
echo "  4. CBTapes File 647 (REXX)"
echo "  5. CBT667 (RPG)"
echo ""

# Verify all source directories exist
echo "Verifying source directories..."
MISSING_DIRS=0

if [ ! -d "./examples/code/cobol/carddemoV2" ]; then
    echo "  ✗ Missing: ./examples/code/cobol/carddemoV2"
    MISSING_DIRS=$((MISSING_DIRS + 1))
else
    echo "  ✓ Found: ./examples/code/cobol/carddemoV2"
fi

if [ ! -d "./examples/code/natural/n-one" ]; then
    echo "  ✗ Missing: ./examples/code/natural/n-one"
    MISSING_DIRS=$((MISSING_DIRS + 1))
else
    echo "  ✓ Found: ./examples/code/natural/n-one"
fi

if [ ! -d "./examples/code/pli/carddemo/app" ]; then
    echo "  ✗ Missing: ./examples/code/pli/carddemo/app"
    MISSING_DIRS=$((MISSING_DIRS + 1))
else
    echo "  ✓ Found: ./examples/code/pli/carddemo/app"
fi

if [ ! -d "./examples/code/rexx/cbtapes_file_647" ]; then
    echo "  ✗ Missing: ./examples/code/rexx/cbtapes_file_647"
    MISSING_DIRS=$((MISSING_DIRS + 1))
else
    echo "  ✓ Found: ./examples/code/rexx/cbtapes_file_647"
fi

if [ ! -d "./examples/code/rpg/cbt667" ]; then
    echo "  ✗ Missing: ./examples/code/rpg/cbt667"
    MISSING_DIRS=$((MISSING_DIRS + 1))
else
    echo "  ✓ Found: ./examples/code/rpg/cbt667"
fi

if [ $MISSING_DIRS -gt 0 ]; then
    echo ""
    echo "Error: $MISSING_DIRS source director(ies) not found"
    exit 1
fi

echo ""
echo "All source directories verified!"
echo ""

# Function to analyze a single project
analyze_project() {
    local project_id=$1
    local source_dir=$2
    local project_name=$3
    
    local output_dir="./results/${project_id}_analysis"
    local database="$output_dir/${project_id}.db"
    
    echo ""
    echo "================================================================================"
    echo "  Analyzing: $project_name"
    echo "================================================================================"
    echo ""
    echo "Configuration:"
    echo "  Source:   $source_dir"
    echo "  Output:   $output_dir"
    echo "  Database: $database"
    echo ""
    
    # Create directories
    echo "Creating output directories..."
    mkdir -p "$output_dir"
    mkdir -p "$output_dir/flows"
    mkdir -p "$output_dir/reports"
    mkdir -p "$output_dir/jobs"
    echo "✓ Directories created"
    echo ""
    
    # Step 1: Complete Analysis
    echo "Step 1: Running complete static analysis..."
    python3 -m tools.legacy_analyzer analyze \
      --source-dir "$source_dir" \
      --db "$database" \
      --complexity
    echo "✓ Static analysis complete"
    echo ""
    
    # Step 2: Status Check
    echo "Step 2: Checking analysis status..."
    python3 -m tools.legacy_analyzer status --db "$database"
    echo ""
    
    # Step 3: Entry Point Detection
    echo "Step 3: Detecting entry points..."
    python3 -m tools.legacy_analyzer flow entry-points \
      --db "$database" \
      --use-metadata \
      --format json \
      --output "$output_dir/entry_points/entry_points.json" 2>/dev/null || echo "  (No entry points detected)"
    
    python3 -m tools.legacy_analyzer flow entry-points \
      --db "$database" \
      --use-metadata \
      --format markdown \
      --output "$output_dir/entry_points/entry_points.md" 2>/dev/null || echo "  (No entry points for markdown report)"
    
    echo "✓ Entry point detection complete"
    echo ""
    
    # Step 4: Build Migration Flows
    echo "Step 4: Building migration flows..."
    python3 -m tools.legacy_analyzer migration build-flows \
      --db "$database" \
      --utility-threshold 5 2>/dev/null || echo "  (No flows to build)"
    echo "✓ Migration flows built"
    echo ""
    
    # Step 5: Export Migration Flows
    echo "Step 5: Exporting migration flows (all sorting strategies)..."
    
    # Complexity Ascending
    python3 -m tools.legacy_analyzer migration export-flows \
      --db "$database" \
      --output "$output_dir/flows/flows_by_complexity_asc.json" \
      --extended-scope \
      --sort complexity-asc 2>/dev/null || echo "  (No flows for complexity-asc)"
    
    # Complexity Descending
    python3 -m tools.legacy_analyzer migration export-flows \
      --db "$database" \
      --output "$output_dir/flows/flows_by_complexity_desc.json" \
      --extended-scope \
      --sort complexity-desc 2>/dev/null || echo "  (No flows for complexity-desc)"
    
    # Independence
    python3 -m tools.legacy_analyzer migration export-flows \
      --db "$database" \
      --output "$output_dir/flows/flows_by_independence.json" \
      --extended-scope \
      --sort independence 2>/dev/null || echo "  (No flows for independence)"
    
    # Dependencies
    python3 -m tools.legacy_analyzer migration export-flows \
      --db "$database" \
      --output "$output_dir/flows/flows_by_dependencies.json" \
      --extended-scope \
      --sort dependencies 2>/dev/null || echo "  (No flows for dependencies)"
    
    # Name
    python3 -m tools.legacy_analyzer migration export-flows \
      --db "$database" \
      --output "$output_dir/flows/flows_by_name.json" \
      --extended-scope \
      --sort name 2>/dev/null || echo "  (No flows for name)"
    
    # Database order
    python3 -m tools.legacy_analyzer migration export-flows \
      --db "$database" \
      --output "$output_dir/flows/flows_database_order.json" \
      --extended-scope 2>/dev/null || echo "  (No flows for database order)"
    
    # Create symlink if complexity-asc exists
    if [ -f "$output_dir/flows/flows_by_complexity_asc.json" ]; then
        ln -sf flows_by_complexity_asc.json "$output_dir/flows/Business_Flows.json"
    fi
    
    echo "✓ Migration flows exported"
    echo ""
    
    # Step 6: Export JCL Jobs
    echo "Step 6: Exporting JCL jobs (all sorting strategies)..."
    
    python3 -m tools.legacy_analyzer migration export-jobs \
      --db "$database" \
      --output-dir "$output_dir/jobs" \
      --sort-by name 2>/dev/null || echo "  (No jobs for name sort)"
    
    python3 -m tools.legacy_analyzer migration export-jobs \
      --db "$database" \
      --output-dir "$output_dir/jobs" \
      --sort-by type 2>/dev/null || echo "  (No jobs for type sort)"
    
    python3 -m tools.legacy_analyzer migration export-jobs \
      --db "$database" \
      --output-dir "$output_dir/jobs" \
      --sort-by dependencies 2>/dev/null || echo "  (No jobs for dependencies sort)"
    
    python3 -m tools.legacy_analyzer migration export-jobs \
      --db "$database" \
      --output-dir "$output_dir/jobs" \
      --sort-by complexity 2>/dev/null || echo "  (No jobs for complexity sort)"
    
    # Create symlink if type exists
    if [ -f "$output_dir/jobs/jobs_by_type.json" ]; then
        ln -sf jobs_by_type.json "$output_dir/jobs/jobs.json"
    fi
    
    echo "✓ JCL jobs exported"
    echo ""
    
    # Step 7: Generate Summary Report
    echo "Step 7: Generating summary report..."
    
    python3 -m tools.legacy_analyzer report summary \
      --db "$database" \
      --output "$output_dir/reports/analysis_summary.md"
    
    echo ""
    echo "✓ Summary report generated"
    echo ""
    
    # Step 8: Generate Status Report
    echo "Step 8: Generating status report..."
    
    python3 -m tools.legacy_analyzer report status \
      --db "$database" \
      --output-dir "$output_dir"
    
    echo ""
    echo "✓ Status report generated"
    echo ""
    
    echo "================================================================================"
    echo "  ✓ Analysis Complete: $project_name"
    echo "================================================================================"
    echo "  Results: $output_dir"
    echo ""
}

# Analyze all projects
START_TIME=$(date +%s)

analyze_project "carddemo_v2" "./examples/code/cobol/carddemoV2" "CardDemo V2 (COBOL)"
analyze_project "n_one" "./examples/code/natural/n-one" "N-One (Natural)"
analyze_project "carddemo_pli" "./examples/code/pli/carddemo/app" "CardDemo PLI (PL/I)"
analyze_project "cbtapes_647" "./examples/code/rexx/cbtapes_file_647" "CBTapes File 647 (REXX)"
analyze_project "cbt667" "./examples/code/rpg/cbt667" "CBT667 (RPG)"

END_TIME=$(date +%s)
DURATION=$((END_TIME - START_TIME))

# Final Summary
echo ""
echo "================================================================================"
echo "  ALL PROJECTS ANALYZED SUCCESSFULLY!"
echo "================================================================================"
echo ""
echo "Total execution time: ${DURATION}s"
echo ""
echo "Results by project:"
echo ""
echo "  CardDemo V2 (COBOL):"
echo "    Location: ./results/carddemo_v2_analysis/"
echo "    Database: ./results/carddemo_v2_analysis/carddemo_v2.db"
echo "    Summary:  ./results/carddemo_v2_analysis/reports/analysis_summary.md"
echo ""
echo "  N-One (Natural):"
echo "    Location: ./results/n_one_analysis/"
echo "    Database: ./results/n_one_analysis/n_one.db"
echo "    Summary:  ./results/n_one_analysis/reports/analysis_summary.md"
echo ""
echo "  CardDemo PLI (PL/I):"
echo "    Location: ./results/carddemo_pli_analysis/"
echo "    Database: ./results/carddemo_pli_analysis/carddemo_pli.db"
echo "    Summary:  ./results/carddemo_pli_analysis/reports/analysis_summary.md"
echo ""
echo "  CBTapes File 647 (REXX):"
echo "    Location: ./results/cbtapes_647_analysis/"
echo "    Database: ./results/cbtapes_647_analysis/cbtapes_647.db"
echo "    Summary:  ./results/cbtapes_647_analysis/reports/analysis_summary.md"
echo ""
echo "  CBT667 (RPG):"
echo "    Location: ./results/cbt667_analysis/"
echo "    Database: ./results/cbt667_analysis/cbt667.db"
echo "    Summary:  ./results/cbt667_analysis/reports/analysis_summary.md"
echo ""
echo "View individual summaries:"
echo "  cat ./results/carddemo_v2_analysis/reports/analysis_summary.md"
echo "  cat ./results/n_one_analysis/reports/analysis_summary.md"
echo "  cat ./results/carddemo_pli_analysis/reports/analysis_summary.md"
echo "  cat ./results/cbtapes_647_analysis/reports/analysis_summary.md"
echo "  cat ./results/cbt667_analysis/reports/analysis_summary.md"
echo ""
echo "Done!"
echo ""
