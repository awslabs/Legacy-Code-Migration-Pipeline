#!/bin/bash

# SMF Dashboard Stop Script
# Gracefully stops the SMF Dashboard web interface

set -e

# Change to project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Configuration
PID_FILE=".dashboard.pid"
LOG_FILE="dashboard.log"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}SMF Dashboard Shutdown${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if PID file exists
if [ ! -f "$PID_FILE" ]; then
    echo -e "${YELLOW}Dashboard is not running (no PID file found)${NC}"
    exit 0
fi

# Read PID from file
DASHBOARD_PID=$(cat "$PID_FILE")

# Check if process is actually running
if ! ps -p "$DASHBOARD_PID" > /dev/null 2>&1; then
    echo -e "${YELLOW}Dashboard process (PID: $DASHBOARD_PID) is not running${NC}"
    echo -e "${YELLOW}Cleaning up PID file${NC}"
    rm -f "$PID_FILE"
    exit 0
fi

# Get process info
PROCESS_INFO=$(ps -p "$DASHBOARD_PID" -o comm= 2>/dev/null || echo "unknown")

echo -e "${YELLOW}Stopping dashboard (PID: $DASHBOARD_PID)...${NC}"

# Try graceful shutdown first (SIGTERM)
kill -TERM "$DASHBOARD_PID" 2>/dev/null

# Wait for process to terminate (max 10 seconds)
WAIT_COUNT=0
MAX_WAIT=10

while ps -p "$DASHBOARD_PID" > /dev/null 2>&1; do
    if [ $WAIT_COUNT -ge $MAX_WAIT ]; then
        echo -e "${YELLOW}Process did not terminate gracefully, forcing shutdown...${NC}"
        kill -KILL "$DASHBOARD_PID" 2>/dev/null
        sleep 1
        break
    fi
    sleep 1
    WAIT_COUNT=$((WAIT_COUNT + 1))
    echo -n "."
done

echo ""

# Verify process is stopped
if ps -p "$DASHBOARD_PID" > /dev/null 2>&1; then
    echo -e "${RED}✗ Failed to stop dashboard${NC}"
    echo -e "${YELLOW}You may need to manually kill the process:${NC}"
    echo -e "  ${BLUE}kill -9 $DASHBOARD_PID${NC}"
    exit 1
else
    echo -e "${GREEN}✓ Dashboard stopped successfully${NC}"
    rm -f "$PID_FILE"
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Dashboard has been shut down${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${YELLOW}To start the dashboard again, run:${NC}"
echo -e "  ${BLUE}./scripts/startDashboard.sh${NC}"
echo ""
echo -e "${YELLOW}Log file preserved at: ${LOG_FILE}${NC}"
echo ""

exit 0
