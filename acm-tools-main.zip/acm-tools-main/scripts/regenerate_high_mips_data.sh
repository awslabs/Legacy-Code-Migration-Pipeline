#!/bin/bash
# Regenerate test data with higher MIPS load (~250 MIPS average)

set -e

echo "========================================="
echo "Regenerating High MIPS Test Data"
echo "========================================="
echo ""

# Configuration
DB_PATH="./databases/carddemo_presentation.db"
CONFIG_PATH="./examples/config/carddemo_smf_generation_inventory.yaml"
OUTPUT_DIR="./examples/data/carddemo_smf_inventory"

echo "Step 1: Backup existing database..."
if [ -f "$DB_PATH" ]; then
    cp "$DB_PATH" "${DB_PATH}.backup_$(date +%Y%m%d_%H%M%S)"
    echo "✓ Backup created"
else
    echo "⚠ No existing database to backup"
fi

echo ""
echo "Step 2: Generate new SMF test data with higher MIPS..."
echo "Configuration: $CONFIG_PATH"
echo "Output directory: $OUTPUT_DIR"
echo ""

# Generate test data using the multi-type coordinator
python3 -m tools.smf_test_data_generator \
    --config "$CONFIG_PATH" \
    --verbose

echo ""
echo "Step 3: Load generated data into database..."
echo ""

# Find all generated JSON files
SMF30_FILE="${OUTPUT_DIR}/smf30_carddemo.json"
SMF110_FILE="${OUTPUT_DIR}/smf110_carddemo.json"
SMF14_FILE="${OUTPUT_DIR}/smf14_carddemo.json"
SMF15_FILE="${OUTPUT_DIR}/smf15_carddemo.json"
SMF17_FILE="${OUTPUT_DIR}/smf17_carddemo.json"
SMF62_FILE="${OUTPUT_DIR}/smf62_carddemo.json"
SMF64_FILE="${OUTPUT_DIR}/smf64_carddemo.json"
SMF100_FILE="${OUTPUT_DIR}/smf100_carddemo.json"
SMF101_FILE="${OUTPUT_DIR}/smf101_carddemo.json"
SMF102_FILE="${OUTPUT_DIR}/smf102_carddemo.json"

# Load SMF Type 30 (Batch Jobs)
if [ -f "$SMF30_FILE" ]; then
    echo "Loading SMF Type 30 (Batch Jobs)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 30 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF30_FILE" \
        --create-schema
    echo "✓ SMF Type 30 loaded"
else
    echo "⚠ SMF Type 30 file not found: $SMF30_FILE"
fi

# Load SMF Type 110 (CICS)
if [ -f "$SMF110_FILE" ]; then
    echo "Loading SMF Type 110 (CICS)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 110 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF110_FILE"
    echo "✓ SMF Type 110 loaded"
else
    echo "⚠ SMF Type 110 file not found: $SMF110_FILE"
fi

# Load SMF Type 14 (Input Datasets)
if [ -f "$SMF14_FILE" ]; then
    echo "Loading SMF Type 14 (Input Datasets)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 14 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF14_FILE"
    echo "✓ SMF Type 14 loaded"
else
    echo "⚠ SMF Type 14 file not found: $SMF14_FILE"
fi

# Load SMF Type 15 (Output Datasets)
if [ -f "$SMF15_FILE" ]; then
    echo "Loading SMF Type 15 (Output Datasets)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 15 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF15_FILE"
    echo "✓ SMF Type 15 loaded"
else
    echo "⚠ SMF Type 15 file not found: $SMF15_FILE"
fi

# Load SMF Type 17 (Dataset Deletion)
if [ -f "$SMF17_FILE" ]; then
    echo "Loading SMF Type 17 (Dataset Deletion)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 17 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF17_FILE"
    echo "✓ SMF Type 17 loaded"
else
    echo "⚠ SMF Type 17 file not found: $SMF17_FILE"
fi

# Load SMF Type 62 (VSAM Open)
if [ -f "$SMF62_FILE" ]; then
    echo "Loading SMF Type 62 (VSAM Open)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 62 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF62_FILE"
    echo "✓ SMF Type 62 loaded"
else
    echo "⚠ SMF Type 62 file not found: $SMF62_FILE"
fi

# Load SMF Type 64 (VSAM Close)
if [ -f "$SMF64_FILE" ]; then
    echo "Loading SMF Type 64 (VSAM Close)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 64 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF64_FILE"
    echo "✓ SMF Type 64 loaded"
else
    echo "⚠ SMF Type 64 file not found: $SMF64_FILE"
fi

# Load SMF Type 100 (DB2 Statistics)
if [ -f "$SMF100_FILE" ]; then
    echo "Loading SMF Type 100 (DB2 Statistics)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 100 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF100_FILE"
    echo "✓ SMF Type 100 loaded"
else
    echo "⚠ SMF Type 100 file not found: $SMF100_FILE"
fi

# Load SMF Type 101 (DB2 Accounting)
if [ -f "$SMF101_FILE" ]; then
    echo "Loading SMF Type 101 (DB2 Accounting)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 101 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF101_FILE"
    echo "✓ SMF Type 101 loaded"
else
    echo "⚠ SMF Type 101 file not found: $SMF101_FILE"
fi

# Load SMF Type 102 (DB2 Performance)
if [ -f "$SMF102_FILE" ]; then
    echo "Loading SMF Type 102 (DB2 Performance)..."
    python3 -m tools.smf_analyzer.smf_loader load \
        --type 102 \
        --unified \
        --db "$DB_PATH" \
        --file "$SMF102_FILE"
    echo "✓ SMF Type 102 loaded"
else
    echo "⚠ SMF Type 102 file not found: $SMF102_FILE"
fi

echo ""
echo "Step 4: Verify data load..."
echo ""

# Quick verification query
python3 << 'EOF'
import sqlite3

db_path = "./databases/carddemo_presentation.db"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

print("Record counts by type:")
print("-" * 50)

# Count SMF records by type
cursor.execute("""
    SELECT record_type, COUNT(*) as count
    FROM smf_records
    GROUP BY record_type
    ORDER BY record_type
""")

for row in cursor.fetchall():
    print(f"  Type {row[0]:3d}: {row[1]:,} records")

print("-" * 50)

# Calculate MIPS statistics
cursor.execute("""
    WITH daily_mips AS (
        SELECT 
            DATE(r.record_date) as date,
            SUM(p.service_units) / 3600000.0 / 24.0 as daily_mips
        FROM smf30_processor p
        JOIN smf_records r ON p.record_id = r.record_id
        GROUP BY DATE(r.record_date)
    )
    SELECT 
        ROUND(AVG(daily_mips), 2) as avg_mips,
        ROUND(MIN(daily_mips), 2) as min_mips,
        ROUND(MAX(daily_mips), 2) as max_mips,
        COUNT(*) as days
    FROM daily_mips
""")

row = cursor.fetchone()
if row and row[0]:
    print(f"\nMIPS Statistics:")
    print(f"  Average MIPS: {row[0]}")
    print(f"  Min MIPS:     {row[1]}")
    print(f"  Max MIPS:     {row[2]}")
    print(f"  Days:         {row[3]}")
else:
    print("\n⚠ No MIPS data available")

conn.close()
EOF

echo ""
echo "========================================="
echo "✓ High MIPS Test Data Generation Complete"
echo "========================================="
echo ""
echo "Database: $DB_PATH"
echo ""
echo "Next steps:"
echo "1. Restart the dashboard if running"
echo "2. Run the Comprehensive ROI Assessment query"
echo "3. Verify MIPS values are around 250 MIPS average"
echo ""
