#!/bin/bash

# Restart the SMF Dashboard
# This script stops and starts the dashboard to apply code changes

set -e

# Change to project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

echo "Restarting SMF Dashboard..."
echo

# Stop dashboard
./scripts/stopDashboard.sh

# Wait a moment
sleep 2

# Start dashboard
./scripts/startDashboard.sh

echo
echo "✓ Dashboard restarted successfully"
