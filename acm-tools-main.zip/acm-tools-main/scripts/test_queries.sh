#!/bin/bash

# Test queries with improved data

DB="databases/carddemo_smf_test.db"

echo "Testing SMF queries with improved test data..."
echo

echo "1. Top CPU Consumers (should show varied users):"
python3 -m tools.smf_analyzer.smf_queries run --db "$DB" --query top_cpu_consumers --params limit=10 --format table
echo

echo "2. CPU by User (should show 15-20 users):"
python3 -m tools.smf_analyzer.smf_queries run --db "$DB" --query cpu_by_user --params limit=15 --format table
echo

echo "3. Dataset Activity (should show standard DD names):"
python3 -m tools.smf_analyzer.smf_queries run --db "$DB" --query dataset_activity --params limit=15 --format table
echo

echo "4. Job Completion Rate (should show ~85% success):"
python3 -m tools.smf_analyzer.smf_queries run --db "$DB" --query job_completion_rate --format table
echo

echo "5. Top CPU Transactions (CICS):"
python3 -m tools.smf_analyzer.smf_queries run --db "$DB" --query top_cpu_transactions --params limit=10 --format table
echo

echo "6. Transaction Volume (CICS):"
python3 -m tools.smf_analyzer.smf_queries run --db "$DB" --query transaction_volume --params limit=10 --format table
echo
