#!/bin/bash

# Copy inventory data from carddemo_inventory.db to carddemo_smf_test.db

SOURCE_DB="databases/carddemo_inventory.db"
TARGET_DB="databases/carddemo_smf_test.db"

echo "Copying inventory data to test database..."
echo

# Check if source database exists
if [ ! -f "$SOURCE_DB" ]; then
    echo "Error: Source database not found: $SOURCE_DB"
    exit 1
fi

# Check if target database exists
if [ ! -f "$TARGET_DB" ]; then
    echo "Error: Target database not found: $TARGET_DB"
    exit 1
fi

# Copy inventory tables using SQLite
python3 << 'EOF'
import sqlite3
import sys

source_db = "databases/carddemo_inventory.db"
target_db = "databases/carddemo_smf_test.db"

# Connect to both databases
source_conn = sqlite3.connect(source_db)
target_conn = sqlite3.connect(target_db)

source_cursor = source_conn.cursor()
target_cursor = target_conn.cursor()

# List of inventory tables to copy
inventory_tables = [
    'inventory_jcl',
    'inventory_programs',
    'inventory_copybooks',
    'inventory_datasets',
    'inventory_cics',
    'artifact_dependencies',
]

print("Copying inventory tables...")
print()

for table in inventory_tables:
    # Check if table exists in source
    source_cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
    if not source_cursor.fetchone():
        print(f"  ⚠ Table {table} not found in source database")
        continue
    
    # Check if table exists in target
    target_cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
    if not target_cursor.fetchone():
        print(f"  ⚠ Table {table} not found in target database - skipping")
        continue
    
    # Get column info for both tables
    source_cursor.execute(f"PRAGMA table_info({table})")
    source_cols = [col[1] for col in source_cursor.fetchall()]
    
    target_cursor.execute(f"PRAGMA table_info({table})")
    target_cols = [col[1] for col in target_cursor.fetchall()]
    
    # Find common columns
    common_cols = [col for col in source_cols if col in target_cols]
    
    if not common_cols:
        print(f"  ⚠ No common columns in {table} - skipping")
        continue
    
    # Clear existing data in target
    target_cursor.execute(f"DELETE FROM {table}")
    
    # Copy data using common columns
    col_list = ', '.join(common_cols)
    placeholders = ', '.join(['?' for _ in common_cols])
    
    source_cursor.execute(f"SELECT {col_list} FROM {table}")
    rows = source_cursor.fetchall()
    
    if rows:
        # Insert data
        target_cursor.executemany(f"INSERT INTO {table} ({col_list}) VALUES ({placeholders})", rows)
        print(f"  ✓ Copied {len(rows)} rows to {table} ({len(common_cols)} columns)")
    else:
        print(f"  - No data in {table}")

# Commit changes
target_conn.commit()

print()
print("✓ Inventory data copied successfully")

# Show summary
print()
print("Summary:")
for table in inventory_tables:
    try:
        target_cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = target_cursor.fetchone()[0]
        if count > 0:
            print(f"  {table:30} {count:6,} rows")
    except:
        pass

# Close connections
source_conn.close()
target_conn.close()

EOF

echo
echo "✓ Complete!"
echo "  Database: $TARGET_DB"
echo
