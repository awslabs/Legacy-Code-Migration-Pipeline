#!/bin/bash

# SMF Test Data Generator - CardDemo Inventory Mode
# This script generates synthetic SMF records based on the CardDemo inventory database
# It generates all configured record types including CICS transactions (SMF 110)
# Now automatically creates both individual JSON files AND a merged smf_all_carddemo.json file

set -e  # Exit on error

# Use python3 explicitly
PYTHON_CMD="python3"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Configuration
CONFIG_FILE="examples/config/carddemo_smf_generation_inventory.yaml"
DATABASE_FILE="databases/carddemo_inventory.db"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}SMF Test Data Generator - Inventory Mode${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Step 1: Validate prerequisites
echo -e "${YELLOW}Step 1: Validating prerequisites...${NC}"

# Check if config file exists
if [ ! -f "$CONFIG_FILE" ]; then
    echo -e "${RED}Error: Configuration file not found: $CONFIG_FILE${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Configuration file found${NC}"

# Check if database exists
if [ ! -f "$DATABASE_FILE" ]; then
    echo -e "${RED}Error: Database file not found: $DATABASE_FILE${NC}"
    echo -e "${YELLOW}Please ensure the CardDemo inventory database exists at: $DATABASE_FILE${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Database file found${NC}"

# Check if Python module exists
$PYTHON_CMD -c "from tools.smf_test_data_generator import cli" 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "${RED}Error: SMF Test Data Generator module not found${NC}"
    echo -e "${YELLOW}Please ensure the toolkit is installed: pip install -e .${NC}"
    exit 1
fi
echo -e "${GREEN}✓ SMF Test Data Generator module available${NC}"
echo ""

# Step 2: Validate configuration
echo -e "${YELLOW}Step 2: Validating configuration...${NC}"
$PYTHON_CMD -m tools.smf_test_data_generator --config "$CONFIG_FILE" --validate-only

if [ $? -ne 0 ]; then
    echo -e "${RED}Configuration validation failed!${NC}"
    exit 1
fi
echo ""

# Step 3: Generate SMF records
echo -e "${YELLOW}Step 3: Generating SMF records...${NC}"
echo -e "${BLUE}This will generate the following record types:${NC}"
echo -e "  - Type 30: Batch job accounting"
echo -e "  - Type 110: CICS transaction performance"
echo -e "  - Type 14: INPUT dataset activity"
echo -e "  - Type 15: OUTPUT dataset activity"
echo -e "  - Type 17: Dataset deletion/scratch"
echo -e "  - Type 62: VSAM open operations"
echo -e "  - Type 64: VSAM close operations"
echo ""
echo -e "${BLUE}Output format:${NC}"
echo -e "  - Individual files: smf{type}_carddemo.json"
echo -e "  - Merged file: smf_all_carddemo.json (ALL TYPES)"
echo ""

$PYTHON_CMD -m tools.smf_test_data_generator --config "$CONFIG_FILE" --verbose

if [ $? -ne 0 ]; then
    echo -e "${RED}SMF record generation failed!${NC}"
    exit 1
fi
echo ""

# Step 4: Verify output files
echo -e "${YELLOW}Step 4: Verifying output files...${NC}"

OUTPUT_DIR="examples/data/carddemo_smf_inventory"
EXPECTED_FILES=(
    "smf30_carddemo.json"
    "smf110_carddemo.json"
    "smf14_carddemo.json"
    "smf15_carddemo.json"
    "smf17_carddemo.json"
    "smf62_carddemo.json"
    "smf64_carddemo.json"
    "smf_all_carddemo.json"
)

ALL_FILES_EXIST=true
for file in "${EXPECTED_FILES[@]}"; do
    filepath="$OUTPUT_DIR/$file"
    if [ -f "$filepath" ]; then
        # Get file size
        size=$(ls -lh "$filepath" | awk '{print $5}')
        echo -e "${GREEN}✓ $file${NC} ($size)"
    else
        echo -e "${RED}✗ $file - NOT FOUND${NC}"
        ALL_FILES_EXIST=false
    fi
done
echo ""

if [ "$ALL_FILES_EXIST" = false ]; then
    echo -e "${RED}Some output files are missing!${NC}"
    exit 1
fi

# Step 5: Verify CICS transactions in SMF 110
echo -e "${YELLOW}Step 5: Verifying CICS transactions (SMF 110)...${NC}"

SMF110_FILE="$OUTPUT_DIR/smf110_carddemo.json"
if [ -f "$SMF110_FILE" ]; then
    # Check for expected CICS transaction codes (actual IDs from CSD)
    EXPECTED_TRANS=("CAUP" "CM00" "CC00" "CR00" "CA00")
    
    echo -e "${BLUE}Checking for configured CICS transactions:${NC}"
    for trans in "${EXPECTED_TRANS[@]}"; do
        if grep -q "\"tran_name\": \"$trans\"" "$SMF110_FILE"; then
            echo -e "${GREEN}✓ Transaction $trans found${NC}"
        else
            echo -e "${YELLOW}⚠ Transaction $trans not found (may not have been generated)${NC}"
        fi
    done
else
    echo -e "${RED}Error: SMF 110 file not found!${NC}"
    exit 1
fi
echo ""

# Step 6: Verify merged file
echo -e "${YELLOW}Step 6: Verifying merged file...${NC}"

MERGED_FILE="$OUTPUT_DIR/smf_all_carddemo.json"
if [ -f "$MERGED_FILE" ]; then
    $PYTHON_CMD << EOF
import json
import sys

try:
    with open('$MERGED_FILE', 'r') as f:
        records = json.load(f)
    
    # Count by type
    type_counts = {}
    for record in records:
        rec_type = record.get('record_type', 0)
        type_counts[rec_type] = type_counts.get(rec_type, 0) + 1
    
    print("Record counts in merged file:")
    total = 0
    for rec_type in sorted(type_counts.keys()):
        count = type_counts[rec_type]
        total += count
        print(f"  Type {rec_type}: {count:,} records")
    
    print(f"\n  Total: {total:,} records")
    print(f"\n✓ Merged file contains all {len(type_counts)} record types")
    
except Exception as e:
    print(f"Error: {e}", file=sys.stderr)
    sys.exit(1)
EOF
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Merged file verification failed!${NC}"
        exit 1
    fi
else
    echo -e "${RED}Error: Merged file not found!${NC}"
    exit 1
fi
echo ""

# Step 7: Summary
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Generation Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "Configuration: $CONFIG_FILE"
echo -e "Database: $DATABASE_FILE"
echo -e "Output directory: $OUTPUT_DIR"
echo ""
echo -e "${BLUE}All SMF record types generated successfully!${NC}"
echo -e "${BLUE}Individual files AND merged file created.${NC}"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo -e "1. Load the merged data into a database (RECOMMENDED):"
echo -e "   ${BLUE}./load_test_data_unified.sh${NC}"
echo -e ""
echo -e "2. Or load individual types:"
echo -e "   ${BLUE}python -m tools.smf_analyzer.smf_loader load --type 30 --db test.db --file $OUTPUT_DIR/smf30_carddemo.json --create-schema${NC}"
echo -e ""
echo -e "3. View in the dashboard:"
echo -e "   ${BLUE}./startDashboard.sh${NC}"
echo -e "   ${BLUE}Open http://localhost:5001${NC}"
echo ""

exit 0
