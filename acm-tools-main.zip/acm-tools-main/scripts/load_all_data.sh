#!/bin/bash
# Load all SMF record types into database

set -e

DB_PATH="./databases/carddemo_presentation.db"
DATA_DIR="./examples/data/carddemo_smf_inventory"

echo "Loading all SMF record types..."

# Type 14
if [ -f "$DATA_DIR/smf14_carddemo.json" ]; then
    echo "Loading Type 14..."
    python3 -m tools.smf_analyzer.smf_loader load --type 14 --db "$DB_PATH" --file "$DATA_DIR/smf14_carddemo.json" --unified
fi

# Type 15
if [ -f "$DATA_DIR/smf15_carddemo.json" ]; then
    echo "Loading Type 15..."
    python3 -m tools.smf_analyzer.smf_loader load --type 15 --db "$DB_PATH" --file "$DATA_DIR/smf15_carddemo.json" --unified
fi

# Type 17
if [ -f "$DATA_DIR/smf17_carddemo.json" ]; then
    echo "Loading Type 17..."
    python3 -m tools.smf_analyzer.smf_loader load --type 17 --db "$DB_PATH" --file "$DATA_DIR/smf17_carddemo.json" --unified
fi

# Type 62
if [ -f "$DATA_DIR/smf62_carddemo.json" ]; then
    echo "Loading Type 62..."
    python3 -m tools.smf_analyzer.smf_loader load --type 62 --db "$DB_PATH" --file "$DATA_DIR/smf62_carddemo.json" --unified
fi

# Type 64
if [ -f "$DATA_DIR/smf64_carddemo.json" ]; then
    echo "Loading Type 64..."
    python3 -m tools.smf_analyzer.smf_loader load --type 64 --db "$DB_PATH" --file "$DATA_DIR/smf64_carddemo.json" --unified
fi

# Type 100
if [ -f "$DATA_DIR/smf100_carddemo.json" ]; then
    echo "Loading Type 100..."
    python3 -m tools.smf_analyzer.smf_loader load --type 100 --db "$DB_PATH" --file "$DATA_DIR/smf100_carddemo.json" --unified
fi

# Type 101
if [ -f "$DATA_DIR/smf101_carddemo.json" ]; then
    echo "Loading Type 101..."
    python3 -m tools.smf_analyzer.smf_loader load --type 101 --db "$DB_PATH" --file "$DATA_DIR/smf101_carddemo.json" --unified
fi

# Type 102
if [ -f "$DATA_DIR/smf102_carddemo.json" ]; then
    echo "Loading Type 102..."
    python3 -m tools.smf_analyzer.smf_loader load --type 102 --db "$DB_PATH" --file "$DATA_DIR/smf102_carddemo.json" --unified
fi

echo "✓ All data loaded successfully"
