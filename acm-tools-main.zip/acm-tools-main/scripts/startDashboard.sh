#!/bin/bash

# SMF Dashboard Startup Script
# Starts the SMF Dashboard web interface in the background

set -e

# Change to project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Configuration
PYTHON_CMD="python3"
PID_FILE=".dashboard.pid"
LOG_FILE="dashboard.log"
PORT=5001

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}SMF Dashboard Startup${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if dashboard is already running
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if ps -p "$OLD_PID" > /dev/null 2>&1; then
        echo -e "${YELLOW}Dashboard is already running (PID: $OLD_PID)${NC}"
        echo -e "${BLUE}Access it at: http://localhost:$PORT${NC}"
        echo ""
        echo -e "${YELLOW}To stop it, run: ./scripts/stopDashboard.sh${NC}"
        exit 0
    else
        echo -e "${YELLOW}Removing stale PID file${NC}"
        rm -f "$PID_FILE"
    fi
fi

# Check if port is already in use
if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "${RED}Error: Port $PORT is already in use${NC}"
    echo -e "${YELLOW}Please stop the process using port $PORT or change the port${NC}"
    exit 1
fi

# Check if dashboard module exists
$PYTHON_CMD -c "from tools.smf_dashboard import app" 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "${RED}Error: SMF Dashboard module not found${NC}"
    echo -e "${YELLOW}Please ensure the toolkit is installed: pip install -e .${NC}"
    exit 1
fi

# Start the dashboard
echo -e "${YELLOW}Starting SMF Dashboard...${NC}"

# Set environment variables for production-like settings
export FLASK_ENV=development
export FLASK_DEBUG=0

# Start dashboard in background and capture PID
nohup $PYTHON_CMD -m tools.smf_dashboard.app > "$LOG_FILE" 2>&1 &
DASHBOARD_PID=$!

# Save PID to file
echo "$DASHBOARD_PID" > "$PID_FILE"

# Wait a moment to check if it started successfully
sleep 2

# Check if process is still running
if ps -p "$DASHBOARD_PID" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Dashboard started successfully${NC}"
    echo -e "${BLUE}  PID: $DASHBOARD_PID${NC}"
    echo -e "${BLUE}  Port: $PORT${NC}"
    echo -e "${BLUE}  Log file: $LOG_FILE${NC}"
    echo ""
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}Dashboard is running!${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo -e "${BLUE}Access the dashboard at:${NC}"
    echo -e "  ${GREEN}http://localhost:$PORT${NC}"
    echo ""
    echo -e "${YELLOW}To stop the dashboard, run:${NC}"
    echo -e "  ${BLUE}./scripts/stopDashboard.sh${NC}"
    echo ""
    echo -e "${YELLOW}To view logs in real-time:${NC}"
    echo -e "  ${BLUE}tail -f $LOG_FILE${NC}"
    echo ""
else
    echo -e "${RED}✗ Dashboard failed to start${NC}"
    echo -e "${YELLOW}Check the log file for details: $LOG_FILE${NC}"
    rm -f "$PID_FILE"
    exit 1
fi

exit 0
